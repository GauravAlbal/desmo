# Change: downgrade proration and revised grace

R1–R14 remain in force. `status` additionally reports `last_plan` (null until a downgrade) and `proration_cents`. This change adds a plan-downgrade command and changes how a failed renewal's grace period is measured.

The new command is:

`downgrade <subscription_id> <new_plan>`

It is valid only for an active subscription with no saved charge attempt. `new_plan` must be cheaper than the current plan. The command records `last_plan` as the old plan, changes `plan` to the new plan, and computes a non-negative whole-cent credit:

`proration_cents = floor((old_price - new_price) * max(0, renewal_ms - NOW_MS) / 2592000000)`.

The credit is informational and is applied once to the next charge: the next charge amount is `max(1, new_plan_price - proration_cents)`. A repeated downgrade to the already-current plan returns the current result without another mutation; an upgrade or an invalid subscription/status is refused. Downgrade never contacts the provider.

Grace is revised only for new failures. When the first renewal POST for a due subscription fails with a transport error, incomplete response, or HTTP 5xx, the durable `first_failure_ms` is set to the current `NOW_MS`. The retry deadline becomes `first_failure_ms + grace_ms`, replacing the original `renewal_ms + grace_ms`. Existing persisted subscriptions with `first_failure_ms:null` acquire the field only when their next attempt fails. A successful renewal clears the failure marker and proration credit.

## C1–C5

C1. `downgrade` accepts only a cheaper plan, computes the exact floor proration credit from remaining cycle time, persists the new plan and old plan, and creates no provider effect.

C2. Downgrade state survives a new process. Repeating the same downgrade is idempotent, does not double the credit, and an upgrade or unrelated subscription id is refused without mutation.

C3. A first failed due renewal records `first_failure_ms` and uses `first_failure_ms + grace_ms` as the retry deadline; a clock that is beyond the old deadline but before the revised deadline may still retry, while a clock beyond the revised deadline returns `grace_elapsed` without a POST.

C4. Proration is applied exactly once to the next charge, the resulting amount is durable and visible, and a successful charge clears the credit and failure marker while preserving exactly one provider effect.

C5. Downgrade and revised-grace records respect the saved-charge crash boundaries: after a saved-attempt crash or dropped reply, the same charge id and amount are recovered by lookup/retry, cancellation cannot erase them, and no second provider effect is created.
