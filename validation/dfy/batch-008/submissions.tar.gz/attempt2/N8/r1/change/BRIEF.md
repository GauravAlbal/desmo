# Subscription renewal ledger

The program behind `./run` is a durable local ledger for one customer's software subscription. It records a plan, renewal date, grace period, retry limit, and the charge attempt made against an external card service. A renewal charge has an application-created id saved before the request; recovery looks up that id before any retry.

## Scope and invocation

One machine and one process at a time. One customer and one subscription are bound to a state directory. An unrelated writer may create or modify other files in `STATE_DIR`; those files must survive byte-for-byte. The tool may keep its durable files in `STATE_DIR` under any names. It must use `STATE_DIR`, `SERVICE_URL`, `NOW_MS`, and optional `CRASH_AT`. `SERVICE_URL` is required for every command, including status (status never contacts it). `NOW_MS` is a required non-negative integer epoch-millisecond clock for every command.

`./run <command> [args]` prints exactly one JSON object and nothing else (one trailing newline is allowed). Exit 0 is success. Refusals are nonzero and print `{ "error": "<code>" }`. Identifiers are 1–64 characters matching `A-Za-z0-9._-`. Plans are exactly `basic`, `pro`, or `team`, priced at 1000, 3000, and 6000 cents per 30-day cycle. Renewal, grace, and retry values are canonical non-negative decimal integers; renewal and grace are milliseconds, and retry limit is an integer from 1 through 10. `CRASH_AT` labels are:

* `after-charge-saved-before-request`: after saving a charge id and charge snapshot, before sending a request;
* `after-accept-before-record`: after reading a complete successful provider response, before saving the renewed record;
* `after-record-before-exit`: after saving the renewed record, before success JSON is written.

A process must kill itself with SIGKILL at a reached label. Durable commits are flushed before the command treats them as committed. A malformed owned state file is `corrupt_state` and is not rewritten. Refusals do not modify state except that a due renewal that reaches its retry deadline may durably become `expired`.

## Commands

`open <customer_id> <subscription_id> <plan> <renewal_ms> <grace_ms> <retry_limit>` binds the empty store. It returns `{customer_id,subscription_id,plan,renewal_ms,grace_ms,retry_limit,status:"active",payment:"none",charge_id:null}`. A second open is `already_open`; malformed values are `bad_args`, `bad_time`, `bad_retry`, or `bad_plan`.

`renew` evaluates the bound subscription at `NOW_MS`. Before `renewal_ms`, it refuses `not_due`. At or after renewal and no later than the original `renewal_ms + grace_ms`, it may charge. A first due attempt increments `attempts`, saves a generated charge id and its exact snapshot, then posts once. An attempt whose connection fails, has an incomplete response, or receives HTTP 5xx remains `payment:"attempt_saved"`, sets status `past_due`, and returns `service_unavailable`; it does not lookup in that invocation. When the retry limit is reached, another due renewal returns `retry_exhausted` without a provider request. Past the grace deadline, it durably sets status `expired` and returns `grace_elapsed` without a provider request. A matching successful response returns `{subscription_id,charge_id,amount_cents,status:"active",payment:"paid",renewal_ms}`. Repeating renew after paid is a success no-op without a provider call.

If a saved attempt exists, `renew` first `GET /v1/charges/<charge_id>`: a matching 200 is adopted without POST; a 404 causes one POST with the saved id only when the subscription is still within its grace deadline and attempts are below the limit. Never allocate a replacement id. A mismatching success is `lookup_conflict` and changes nothing. A wrong subscription or terminal subscription is refused without contacting the provider.

`cancel` is allowed before a charge attempt for an active or past-due subscription. It marks the subscription `cancelled`, returns `{subscription_id,status:"cancelled",payment:"none"}`, and never contacts the provider. Once an attempt is saved it returns `charge_started` and preserves the id and snapshot. A cancelled or expired subscription cannot renew.

`reconcile <charge_id>` never POSTs or allocates. No saved charge is `no_charge`; another id is `charge_mismatch`. Lookup 200 with matching ids, plan, renewal date, and amount commits the renewed state and returns the success object plus `lookup:"paid"`; 404 returns exit 0 `{lookup:"not_sent",subscription_id,charge_id,payment:"attempt_saved",status:"past_due"}`; a mismatch is `lookup_conflict`; transport failure is `service_unavailable`.

`status` never contacts the provider and returns `{customer_id,subscription_id,plan,renewal_ms,grace_ms,retry_limit,attempts,first_failure_ms,credit_cents,status,payment,charge_id,amount_cents}`. Empty fields are null, with `attempts:0`, `credit_cents:0`, `status:"none"`, and `payment:"none"`.

`callback <path>` reads one JSON callback. It must not POST or allocate. A malformed callback is `bad_callback`; a well-formed callback may be ignored. It must never overwrite active, cancelled, or expired state.

## Provider

The supplied service has `POST /v1/charges` and `GET /v1/charges/<charge_id>`. A first valid charge id records one effect and returns the body with `outcome:"charged"`; repeating the same id and identical fields returns the same object without another effect; any differing field is HTTP 409. Unknown lookup is 404. The provider may drop a reply after accepting, hold a reply, or return 5xx without storing. Control endpoints are not part of this contract.

## Requirements

R1. Open and every later committed record survive new processes, including a charge attempt killed at `after-charge-saved-before-request`.

R2. Opening validates customer, subscription, plan, renewal, grace, and retry fields, binds one subscription, and does not contact the provider.

R3. A due subscription makes legitimate progress: a healthy provider renews it with the plan price, advances the renewal date by one 30-day cycle, and records one durable attempt; a future renewal is refused as `not_due` without mutation.

R4. Cancellation is terminal, durable, provider-free, and cannot be renewed. Expiration after grace is terminal and cannot be renewed.

R5. A healthy provider permits renewal and exactly one external card effect; repeating renew is a no-op and does not add an effect.

R6. Callback files never overwrite local terminal outcomes and never cause provider effects.

R7. Renewing before the date, a cancelled/expired subscription, or an exhausted retry limit is refused without contacting the provider.

R8. A crash before POST leaves one saved charge id and zero effects; a later renew POSTs that same id and ends active exactly once.

R9. A crash after provider acceptance leaves `attempt_saved` locally and one provider effect; later renew adopts by lookup without a second effect.

R10. A crash after the durable active record leaves active state and later renew is a no-op; reconcile can likewise survive its record-before-exit crash.

R11. A dropped charge reply yields `service_unavailable` and `attempt_saved`; following reconcile adopts active by lookup, never reports `not_sent`, and never posts again.

R12. Reconcile never POSTs: a saved-but-unaccepted id returns `not_sent` with `attempt_saved`; a wrong id is `charge_mismatch` and leaves state unchanged.

R13. Unrelated files in STATE_DIR retain identical bytes through commits and refusals.

R14. Every invocation emits one JSON object; status on empty is the null shape; missing SERVICE_URL or NOW_MS is a refusal; the first open binds the only customer/subscription and no command can renew another.
