# Subscription renewal ledger

Requires Node 22. Install the supplied offline packages with:

`npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz`

Invoke `./run <command> ...` with `STATE_DIR`, `SERVICE_URL`, and `NOW_MS` set. The durable ledger is `subscription.json`; unrelated files are not touched. The lifecycle definition is `subscription.ik.toml` and the host delegates lifecycle persistence around that model.

Example: `STATE_DIR=/tmp/ledger SERVICE_URL=http://127.0.0.1:53000 NOW_MS=0 ./run open cust sub basic 0 1000 3`.
