# Subscription renewal ledger

Install the supplied offline runtime with:

```sh
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

Run commands with `STATE_DIR`, `SERVICE_URL`, and `NOW_MS` set (all are required, including for `status`):

```sh
STATE_DIR=.state SERVICE_URL=http://127.0.0.1:1234 NOW_MS=0 ./run status
STATE_DIR=.state SERVICE_URL=http://127.0.0.1:1234 NOW_MS=0 ./run open customer subscription basic 1000 1000 3
```

The ledger uses an atomic private state file and never rewrites unrelated files in `STATE_DIR`. `CRASH_AT` supports the three documented crash labels. `renew` uses the saved charge id for lookup and retries; `reconcile` only looks up.

`renewal.ik.toml` declares the lifecycle states and command topology used by the installed Ikaros toolchain; host-side HTTP and durable projection code remains in `app.mjs`.
