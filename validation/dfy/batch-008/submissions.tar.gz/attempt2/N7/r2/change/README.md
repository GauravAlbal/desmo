# Warehouse outbound shipment desk

Requires Node 22. Install offline with:

```sh
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

Set `STATE_DIR`, `SERVICE_URL`, and `NOW_MS` for each invocation, then run `./run facility ...`, `order`, `pack`, `book`, `cancel`, `expire`, `status`, `facility-status`, or `reconcile`. State is atomically persisted in `warehouse.json`; unrelated files are untouched. The lifecycle definition is `shipment.ik.toml` and is checked by the installed Ikaros runtime (`npx --no-install ik check shipment.ik.toml`).
