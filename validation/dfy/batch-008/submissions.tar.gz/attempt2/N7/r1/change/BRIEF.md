# Warehouse outbound shipment desk

A local warehouse desk owns outbound orders and their parcels. An order is picked, then packed, then booked for a carrier pickup through an external carrier service. Booking is one all-or-nothing external effect and is idempotent by a saved request id. A pickup window deadline is supplied by the caller; a packed order at or after its deadline cannot be booked. The desk never books an order that is not packed by that order, and facility parcel capacity is enforced.

The application is behind an executable `./run`, implemented in TypeScript/Node 22 or plain Node. Every invocation is one process and prints exactly one JSON object on stdout. Exit 0 means success. A refusal exits nonzero and prints `{"error":"..."}`. Extra fields are allowed. `STATE_DIR`, `SERVICE_URL`, `NOW_MS`, and optional `CRASH_AT` are described below. The provider contract is in `stub/CONTRACT.md`.

## Scope and command line

One machine and one desk process at a time. The operator does not overlap desk processes. Other writers may create files in `STATE_DIR`; the desk must preserve them byte-for-byte. Orders and facilities are independent. The desk does not receive callbacks. Recovery is by lookup of the saved carrier request id.

```
./run facility <facility_id> <capacity>
./run order <order_id> <facility_id> <parcel_id> <pickup_deadline_ms>
./run pack <order_id>
./run book <order_id>
./run cancel <order_id>
./run expire <order_id>
./run status <order_id>
./run facility-status <facility_id>
./run reconcile <order_id>
```

`STATE_DIR` is a durable directory chosen by the harness. The desk may create and write only its own files there. `SERVICE_URL` is the carrier service base URL with no required trailing slash. `NOW_MS` is a decimal non-negative integer supplied on every clock-sensitive invocation; the desk must use it rather than wall clock time. `CRASH_AT`, when equal to one named boundary below, kills the process with SIGKILL at that boundary. A crash boundary is honored only by the invocation that reaches it.

IDs use `^[A-Za-z0-9._-]{1,64}$`; `capacity` is a decimal integer 1..100000; `pickup_deadline_ms` is a decimal integer 0..9007199254740991. `parcel_id` uses `^[A-Za-z0-9._-]{1,32}$`. Invalid IDs are `bad_id`, invalid capacity is `bad_capacity`, invalid deadline is `bad_deadline`, invalid arity is `bad_args`. These refusals contact no provider and change no state.

## Crash boundaries

- `after-booking-saved-before-request`: on `book`, after a booking attempt (request id, order id, facility id and parcel id) is durably saved, before any provider request byte is sent. It is not honored on a retry or lookup.
- `after-accept-before-record`: after the provider has accepted the complete request body and the desk read the complete HTTP response, before the booked outcome is durably committed.
- `after-record-before-exit`: after this invocation durably commits `booked` and before writing its success result. It is not honored when this invocation only observes an already-booked record.

## Facility

`facility <facility_id> <capacity>` is local and contacts no provider. The first call stores an empty facility. Repeating it with the same capacity exits 0 unchanged. A different capacity is refused `conflict`. Success returns `{"facility_id":"north","capacity":3,"held":0,"available":3}`.

`facility-status <facility_id>` returns the same shape. It refuses `unknown_facility` when absent. Capacity counts every non-expired parcel in an order, including an order with an open booking attempt or a booked order. A parcel is available only when it is not currently held by another order. An expired order's parcels become available when expiration is durably observed.

## Orders

`order <order_id> <facility_id> <parcel_id> <pickup_deadline_ms>` creates one picked order without contacting the provider. It refuses `unknown_facility`, `conflict` if the order id already exists with different data, `parcel_taken` if that parcel is currently held by another non-expired order, and `capacity_exceeded` if the facility has no available capacity. A repeated identical order is idempotent and returns the stored object. A deadline equal to `NOW_MS` is already expired for commands that use it.

Success and `status` shape:

```json
{"order_id":"o1","facility_id":"north","parcel_ids":["P1"],"pickup_deadline_ms":5000,"state":"picked","request_id":null,"booking_id":null}
```

`state` is `picked`, `packed`, `attempt_saved`, `booked`, `cancelled`, or `expired`. `cancelled` and `expired` are terminal. A `status` of an unknown order is `unknown_order`; status does not contact the provider. A later process sees the same committed state.

`pack <order_id>` is local and contacts no provider. It refuses `unknown_order`, `expired`, `cancelled`, `attempt_saved`, or `booked`; a packed order is idempotent and returns the object. Packing a picked order before its deadline succeeds.

`cancel <order_id>` is local and contacts no provider. It refuses `unknown_order`, is idempotent for `cancelled` or `expired`, and refuses `cancel_open` when a booking attempt is saved or the order is booked. A picked order is cancelled and frees its parcels; a packed order is refused `not_picked`. `expire <order_id>` is local. It refuses `unknown_order`; before the deadline it refuses `not_due`; at or after the deadline it marks a picked or packed order `expired` and frees its parcels. It must not expire an open attempt or a booked order; those return `cancel_open` and retain their state. Expiration is also performed before `book`, `cancel`, or `status` uses a picked or packed order, so a past-due order cannot be booked.

## Booking and carrier recovery

`book <order_id>` books exactly the packed order. It refuses `unknown_order`, `expired`, `cancelled`, `picked`, `cancel_open`, or `not_due` as applicable. A `booked` order is idempotent: it exits 0, contacts no provider, and preserves `request_id` and `booking_id`.

When state is `packed`, the desk allocates a request id, durably saves the attempt, then honors `after-booking-saved-before-request`. It POSTs exactly that request id and parcel list. After a complete matching HTTP 200 response it honors `after-accept-before-record`, commits `booked`, and honors `after-record-before-exit`. When state is `attempt_saved`, it first GETs the saved request id. A matching HTTP 200 is adopted without POST. HTTP 404 means the request was not accepted and permits POST of the saved request id only. A lookup with mismatched order, facility or parcels is `conflict`; any other provider failure is `unavailable`. Never allocate a second request id for an open attempt.

Success shape:

```json
{"order_id":"o1","facility_id":"north","parcel_ids":["P1"],"pickup_deadline_ms":5000,"state":"booked","request_id":"...","booking_id":"..."}
```

A connection failure, dropped/incomplete response, or HTTP 500 leaves `attempt_saved`, exits `unavailable`, and never posts a different request id in that invocation. `reconcile <order_id>` never POSTs or allocates an id. With no attempt it returns `{"outcome":"not_applicable"}` for a non-booked order. With an attempt it looks up the saved request id: matching 200 commits `booked` and returns `outcome:"booked"`; 404 returns `outcome:"not_sent"` while retaining `attempt_saved`; mismatch is `conflict`; unavailable is `unavailable`. Only a 404 lookup may report `not_sent`.

## Requirements

R1. Durable facility and order persistence survives new processes and SIGKILL after any committed boundary.
R2. Facility and order creation are local, idempotent for identical data, and stable on conflicts.
R3. Facility capacity and parcel exclusivity prevent a second live order from taking a held parcel or exceeding capacity; no provider call is made for refusal.
R4. A healthy pack then book of a live picked order succeeds, records one booked outcome, and provider effect has exactly that order, facility, and parcel.
R5. Legitimate progress (facility, order, pack, then book before deadline) is accepted, not refused.
R6. Booking a booked order again is idempotent and adds no provider effect.
R7. `reconcile` never sends; a pre-request crash leaves an attempt and reconcile returns `not_sent` with zero effects.
R8. A crash after provider acceptance is recovered by lookup and adopts the same request id with one effect.
R9. A crash before the request is recovered by retrying the saved id and creates exactly one effect.
R10. A crash after the durable booked record leaves booked state and later book adds no effect.
R11. Orders and facilities are independent; actions on one do not change another.
R12. Every command has one JSON result; unknown order/facility and invalid arguments use the specified nonzero errors.
R13. An unrelated file in `STATE_DIR` is preserved byte-for-byte.
R14. A dropped provider reply leaves a resolvable saved request; reconcile adopts it without a second effect and never labels an accepted request `not_sent`.

## Out of scope

Overlapping desk processes, callbacks, moving parcels between facilities, changing a pickup deadline, deleting facilities, booking only part of one order, and refunds are outside this brief.
