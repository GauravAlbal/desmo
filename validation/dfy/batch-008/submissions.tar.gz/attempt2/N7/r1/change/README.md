# Warehouse outbound shipment desk

Install the supplied offline runtime with:

```sh
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

Run `./run <command> ...` with `STATE_DIR`, `SERVICE_URL`, and `NOW_MS` set as described in `BRIEF.md`. The durable desk state is stored in `warehouse.json` under `STATE_DIR`; writes use a temporary file and rename, preserving unrelated files. `warehouse.ik.toml` declares the lifecycle states used by the installed Ikaros runtime.

Example:

```sh
STATE_DIR=/tmp/desk SERVICE_URL=http://127.0.0.1:12345 NOW_MS=100 ./run facility north 3
```

No provider is contacted for local refusals. Booking recovery uses GET by the saved request id before retrying a POST.
