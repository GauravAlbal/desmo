# Change: consolidated parcels, packed cancellation, and unpack

R1 through R14 remain in force for existing one-parcel orders. This change adds multi-parcel consolidation: one order may own a list of parcels, and one carrier booking must cover the complete list or no booking is adopted. It also revises `cancel` so a packed order may be cancelled, and adds `unpack` to return an unbooked packed order to picked. Existing persisted one-parcel orders remain valid and keep their original behavior.

## Revised commands

### `./run order <order_id> <facility_id> <parcel_id> [parcel_id...] <pickup_deadline_ms>`

The changed form has one or more parcel ids followed by a deadline. For compatibility, the original form remains valid. Parcel ids must be unique. All capacity and exclusivity checks apply to the entire list atomically: if any parcel is unavailable, no parcel is saved and the refusal is `parcel_taken` (or `capacity_exceeded` when total live parcels would exceed capacity). Repeating the exact order id, facility, sorted parcel list and deadline is idempotent; any difference is `conflict`.

Success/status now reports all held parcels:

```json
{"order_id":"o1","facility_id":"north","parcel_ids":["P1","P2"],"pickup_deadline_ms":5000,"state":"picked","request_id":null,"booking_id":null}
```

### `./run book <order_id>`

For a consolidated order, booking is all-or-nothing. The saved attempt contains the complete parcel list and one request id. The POST body contains the complete list. A matching provider response must contain exactly the saved list (order-insensitive) and is adopted as one booking. A response with a missing, extra, or different parcel is `conflict`; the local attempt remains open and no partial parcel is marked booked. An order never books one parcel at a time and never allocates a second request id while an attempt is open. Existing crash boundaries and lookup-before-resubmit rules apply to the whole order.

### `./run cancel <order_id>`

Cancellation is allowed for a packed order as well as a picked order. It remains local and provider-free. A packed order is cancelled as a whole and frees every remaining parcel. An attempt_saved or booked order is refused `cancel_open`. Repeated cancellation of a cancelled or expired order remains an idempotent success.

### `./run unpack <order_id>`

This new local command changes a packed order back to `picked`. It refuses `unknown_order`, `picked`, `cancelled`, `expired`, `attempt_saved`, and `booked`; repeating it after another command is not a success. It contacts no provider and changes no parcel reservation.

## Requirements

C1. Consolidated order creation is atomic and durable. A valid list of parcels creates one order, reserves every listed parcel, survives restart, preserves one-parcel R behavior, and a collision rejects the whole list without changing facility counts or another order.
C2. Consolidated booking is all-or-nothing and exactly once. A healthy book produces one effect whose parcel list equals the complete held list; no per-parcel effects are allowed. A second book is idempotent. A mismatching provider body is a conflict with no partial adoption.
C3. An open consolidated attempt blocks all cancel, unpack, and book alternatives. A crash or dropped reply can be recovered by lookup/retry of the same request id; no different parcel subset or request id is posted, and a different command cannot replace the attempt.
C4. Packed cancellation is atomic and provider-free. Cancelling a packed order frees every parcel together, leaves no booking attempt, and permits another order to use the freed parcels; cancellation of an open attempt or booking is refused without mutation.
C5. Unpack and deadlines apply to consolidated orders. `unpack` changes only packed orders to picked, preserving all parcel reservations and the deadline. At/after the deadline, all remaining parcels expire together and cannot be packed or booked; a facility never exceeds capacity during consolidation, cancellation, unpack, expiry, or recovery.
