#!/usr/bin/env python3
import json, os, sys, signal, tempfile
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError

ROOT = Path(__file__).resolve().parent
STATE = Path(os.environ.get('STATE_DIR', './state')); STATE.mkdir(parents=True, exist_ok=True)
DB = STATE / 'envelopes.json'

def fail(code):
    print(json.dumps({'error': code}, separators=(',', ':')))
    raise SystemExit(1)

def load():
    try: return json.loads(DB.read_text())
    except FileNotFoundError: return {'envelopes': {}}

def save(x):
    fd, p = tempfile.mkstemp(dir=STATE, prefix='.env-', text=True)
    with os.fdopen(fd, 'w') as f:
        json.dump(x, f, separators=(',', ':')); f.flush(); os.fsync(f.fileno())
    os.replace(p, DB)

def valid_id(x): return isinstance(x, str) and 1 <= len(x) <= 64 and all(c.isalnum() or c in '._-' for c in x)
def valid_email(x):
    if not isinstance(x, str) or x.count('@') != 1: return False
    a, d = x.split('@'); return 1 <= len(a) <= 64 and all(c.isalnum() or c in '._+-' for c in a) and 1 <= len(d) <= 63 and all(c.isalnum() or c in '.-' for c in d)
def num(x): return isinstance(x, str) and (x == '0' or (x.isdigit() and not x.startswith('0'))) and int(x) <= 9999999999999

def crash(label):
    if os.environ.get('CRASH_AT') == label: os.kill(os.getpid(), signal.SIGKILL)

def request(method, path, obj=None):
    try:
        data = None if obj is None else json.dumps(obj, separators=(',', ':')).encode()
        r = urlopen(Request(os.environ.get('SERVICE_URL', '').rstrip('/') + path, data=data,
                            headers={'Content-Type': 'application/json'} if data else {}, method=method), timeout=5)
        return r.status, json.loads(r.read())
    except HTTPError as e:
        try: body = json.loads(e.read())
        except Exception: body = {}
        return e.code, body

def normalize(e):
    if 'signer2_id' not in e:
        e['requests'] = [{'request_id': e.get('request_id') or e['envelope_id'], 'signer_id': e['signer_id'], 'address': e['address'], 'send': e['send']}]
        e['two_signers'] = False
    else:
        if 'requests' not in e:
            e['requests'] = [{'request_id': e['envelope_id']+'.s1', 'signer_id': e['signer_id'], 'address': e['address'], 'send': 'none'}, {'request_id': e['envelope_id']+'.s2', 'signer_id': e['signer2_id'], 'address': e['address2'], 'send': 'none'}]
        e['two_signers'] = True

def payload(e, r):
    return {'request_id': r['request_id'], 'envelope_id': e['envelope_id'], 'document_id': e['document_id'], 'signer_id': r['signer_id'], 'address': r['address'], 'deadline_ms': e['deadline_ms'], 'kind': e['kind']}

def out(e):
    z = {'envelope_id': e['envelope_id'], 'document_id': e['document_id'], 'signer_id': e['signer_id'], 'address': e['address']}
    if e.get('two_signers'): z.update(signer2_id=e['signer2_id'], address2=e['address2'])
    z.update(deadline_ms=e['deadline_ms'], state=e['state'], send=e['send'], request_id=e.get('request_id'), now_ms=e.get('now_ms', 0))
    return z

def check_response(e, r, obj):
    p = payload(e, r)
    if not obj or any(obj.get(k) != v for k, v in p.items()): fail('conflict')

def resolve_one(e, r, allow_post):
    code, obj = request('GET', '/v1/requests/' + r['request_id'])
    if code == 200:
        check_response(e, r, obj); r['send'] = 'sent'; return True
    if code != 404:
        fail('service_unavailable' if code is None or code >= 500 else 'conflict')
    if not allow_post: return False
    code, obj = request('POST', '/v1/envelopes', payload(e, r))
    if code == 409: fail('conflict')
    if code != 200: fail('service_unavailable')
    check_response(e, r, obj); r['send'] = 'sent'; return True

def main(argv):
    if len(argv) < 2: fail('bad_args')
    cmd, x = argv[1], load(); es = x['envelopes']
    if cmd == 'create-envelope':
        if len(argv) not in (8, 10): fail('bad_args')
        if len(argv) == 8: eid, doc, s1, a1, dl, now = argv[2:]; s2 = a2 = None
        else: eid, doc, s1, a1, s2, a2, dl, now = argv[2:]
        if not all([valid_id(eid), valid_id(doc), valid_id(s1), valid_email(a1), num(dl), num(now)]) or int(dl) < int(now): fail('bad_args')
        if s2 is not None and (not valid_id(s2) or not valid_email(a2) or s1 == s2): fail('bad_args')
        if eid in es or any(e['document_id'] == doc or e['signer_id'] in (s1, s2) or e.get('signer2_id') in (s1, s2) for e in es.values()): fail('id_in_use')
        e = {'envelope_id': eid, 'document_id': doc, 'signer_id': s1, 'address': a1, 'deadline_ms': int(dl), 'state': 'draft', 'send': 'none', 'request_id': None, 'kind': 'signature_request', 'now_ms': int(now)}
        if s2 is not None: e.update(signer2_id=s2, address2=a2)
        normalize(e); es[eid] = e; save(x); print(json.dumps(out(e), separators=(',', ':'))); return
    if cmd == 'extend-deadline':
        if len(argv) != 5 or not valid_id(argv[2]) or not num(argv[3]) or not num(argv[4]): fail('bad_args')
        e = es.get(argv[2]);
        if e is None: fail('unknown_envelope')
        if e['state'] not in ('draft', 'sent') or int(argv[3]) <= e['deadline_ms'] or int(argv[3]) < int(argv[4]): fail('invalid_state' if e['state'] not in ('draft','sent') else 'bad_args')
        e['deadline_ms'] = int(argv[3]); e['now_ms'] = int(argv[4]); save(x); print(json.dumps({'envelope_id':e['envelope_id'],'deadline_ms':e['deadline_ms'],'state':e['state'],'now_ms':e['now_ms']}, separators=(',', ':'))); return
    if cmd not in ('status','send','sign','decline','archive','reconcile'): 
        if cmd == 'callback':
            if len(argv) != 3: fail('bad_args')
            try: c = json.loads(Path(argv[2]).read_text())
            except Exception: fail('bad_args')
            fields = ('callback_id','request_id','envelope_id','document_id','signer_id','address','deadline_ms','kind','outcome')
            if any(k not in c for k in fields) or c['outcome'] not in ('accepted','rejected'): fail('bad_args')
            print(json.dumps({'callback_id':c['callback_id'],'ignored':True}, separators=(',', ':'))); return
        fail('bad_args')
    need = 3 if cmd in ('status','send','reconcile') else 4
    if len(argv) != need or not valid_id(argv[2]): fail('bad_args')
    e = es.get(argv[2]);
    if e is None: fail('unknown_envelope')
    normalize(e)
    if cmd == 'status': print(json.dumps(out(e), separators=(',', ':'))); return
    if cmd == 'send':
        if e['state'] != 'draft': fail('invalid_state')
        for r in e['requests']:
            if r['send'] == 'sent': continue
            if r['send'] == 'none': r['send'] = 'attempt_saved'; e['send'] = 'attempt_saved'; e['request_id'] = r['request_id']; save(x); crash('after-attempt-saved-before-request')
            resolve_one(e, r, True); crash('after-accept-before-record'); save(x)
        e['send'] = 'sent'; e['state'] = 'sent'; save(x); crash('after-record-before-exit'); print(json.dumps(out(e), separators=(',', ':'))); return
    if cmd == 'reconcile':
        if e['send'] == 'none': print(json.dumps({'envelope_id':e['envelope_id'],'send':'none','request_id':None}, separators=(',', ':'))); return
        for r in e['requests']:
            if r['send'] != 'sent':
                if not resolve_one(e, r, False): print(json.dumps({'envelope_id':e['envelope_id'],'send':'not_sent','request_id':r['request_id']}, separators=(',', ':'))); return
        e['send']='sent'; e['state']='sent'; save(x); print(json.dumps(out(e), separators=(',', ':'))); return
    if len(argv) != 4 or not num(argv[3]): fail('bad_args')
    now = int(argv[3])
    if cmd in ('sign','decline'):
        if e['state'] == 'draft': fail('not_sent')
        if e['state'] != 'sent': fail('invalid_state')
        limit = e['deadline_ms'] + (86400000 if e.get('two_signers') else 0)
        if now > limit: fail('expired')
        e['state'] = 'signed' if cmd == 'sign' else 'declined'; e['now_ms'] = now; save(x); print(json.dumps({'envelope_id':e['envelope_id'],'state':e['state'],'now_ms':now}, separators=(',', ':'))); return
    if e['state'] not in ('signed','declined'): fail('invalid_state')
    e['state']='archived'; e['now_ms']=now; save(x); print(json.dumps({'envelope_id':e['envelope_id'],'state':'archived','now_ms':now}, separators=(',', ':')))

if __name__ == '__main__':
    try: main(sys.argv)
    except SystemExit: raise
    except Exception: fail('service_unavailable')
