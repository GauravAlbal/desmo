# E-signature envelope desk

Requires Node 22 for the supplied stub and Python 3.9+. Set up the bundled Ikaros client without network access:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
```

Run with `STATE_DIR`, `SERVICE_URL`, and optional `CRASH_AT`:

```sh
STATE_DIR=/tmp/envelopes SERVICE_URL=http://127.0.0.1:PORT ./run create-envelope env-1 doc-1 signer-1 a@b 100 0
```

The command emits one JSON object. `./run` locates the bundled Python package and `KIT/bin/ik` itself.
