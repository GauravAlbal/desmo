# E-signature envelope desk

A local signing desk manages document envelopes. Staff create a draft envelope for one required signer, send it through an external e-signature service, record a signer decision, and archive a terminal envelope. The desk is local: it has one durable state directory and does not coordinate with a remote document database.

The builder owns an executable `./run`, implemented in Python 3.9+ using only the standard library. The supplied e-signature service is specified in `stub/CONTRACT.md`.

## Scope and invocation

One process runs one command at a time. An unrelated writer may create or modify another file in `STATE_DIR`; the desk must preserve that file byte-for-byte. A fresh process with the same `STATE_DIR` sees committed records. The desk never reads the wall clock: every command that needs time receives `now_ms`.

`./run <command> [args]` prints exactly one JSON object to stdout (a trailing newline is allowed). Exit 0 means success. A refusal exits nonzero and prints one object with an `error` code from this brief. stderr is ignored. Extra JSON fields are allowed.

Environment:

- `STATE_DIR`: durable store, created if absent. The desk chooses its own filenames.
- `SERVICE_URL`: e-signature service base URL without a trailing slash.
- `CRASH_AT`: optional crash boundary; at a reached boundary the process must self-kill with SIGKILL.

Identifiers are 1–64 characters matching `[A-Za-z0-9._-]`. Email addresses are `local@domain`, where local is 1–64 `[A-Za-z0-9._+-]` and domain is 1–63 `[A-Za-z0-9.-]`. `now_ms` and `deadline_ms` are canonical decimal integers from 0 through 9999999999999 (zero or non-leading-zero digits). Malformed arguments are `bad_args`.

## Crash boundaries

The following labels apply to a send. A boundary is honored only when the command reaches it; a command that does not send must not kill itself.

- `after-attempt-saved-before-request`: on `send`, after the send attempt (envelope, signer, address, deadline, kind) is durably committed and before any request byte is sent. A retry finding the saved attempt does not crash here again.
- `after-accept-before-record`: after a complete successful POST response has been read, before `send` is committed `sent`. A lookup of an earlier acceptance does not crash here.
- `after-record-before-exit`: after a terminal send outcome is durably committed and before this invocation writes its JSON. It is not honored when the outcome was already committed before this invocation.

## Commands

### `create-envelope <envelope_id> <document_id> <signer_id> <address> <deadline_ms> <now_ms>`

Create a draft envelope. The exact document, signer, address, and supplied deadline are durably stored. `deadline_ms` must be at least `now_ms`. Success: `{"envelope_id":"...","document_id":"...","signer_id":"...","address":"...","deadline_ms":0,"state":"draft","send":"none","now_ms":0}`.

Refuse malformed arguments with `bad_args`, or any existing envelope/document id collision with `id_in_use`. No service request is made.

### `send <envelope_id>`

Send a draft envelope to its required signer. A draft whose `deadline_ms` is earlier than the supplied creation time is never created; sending a valid draft creates exactly one external effect with request id equal to `envelope_id`, kind `signature_request`, and payload `{"request_id":"envelope_id","envelope_id":"...","document_id":"...","signer_id":"...","address":"...","deadline_ms":0,"kind":"signature_request"}`. Save `send:"attempt_saved"` and `request_id` before POSTing, then honor the crash boundaries above.

For an attempt, first `GET /v1/requests/<request_id>`. A matching 200 response commits `send:"sent"` and state `sent` without POST. A 404 causes one POST. A lookup mismatch or POST 409 is `conflict`. A failed connection, incomplete response, HTTP 500, or other non-200 POST is `service_unavailable`; retain `attempt_saved` and never invent another request id. A sent envelope returns success without contacting the service. A signed, declined, or archived envelope is refused `invalid_state`.

### `sign <envelope_id> <now_ms>`

Record the required signer's decision. A sent envelope at or before its deadline becomes `signed`; success is `{"envelope_id":"...","state":"signed","now_ms":0}`. A draft is `not_sent`, a signed/declined/archived envelope is `invalid_state`, and a sent envelope after its deadline is `expired`. No service request is made.

### `decline <envelope_id> <now_ms>`

Record a sent envelope as `declined` at or before its deadline. Success is `{"envelope_id":"...","state":"declined","now_ms":0}`. Draft is `not_sent`, signed/declined/archived is `invalid_state`, and a late decision is `expired`. No service request is made.

### `archive <envelope_id> <now_ms>`

Archive a signed or declined envelope. Success is `{"envelope_id":"...","state":"archived","now_ms":0}`. Draft or sent is `invalid_state`; repeated archive is `invalid_state`. No service request is made.

### `reconcile <envelope_id>`

Resolve a saved send attempt by lookup only. It must never POST. If no attempt exists, return `{"envelope_id":"...","send":"none","request_id":null}`. A lookup 404 returns `send:"not_sent"` and leaves the attempt. A matching 200 commits `sent` and returns the normal terminal fields. A mismatch is `conflict`; service failure is `service_unavailable`. If already sent, return it unchanged without honoring a crash boundary.

### `status <envelope_id>`

Read-only; no deadline or state commit. Success includes `{"envelope_id":"...","document_id":"...","signer_id":"...","address":"...","deadline_ms":0,"state":"draft|sent|signed|declined|archived","send":"none|attempt_saved|sent","request_id":"...|null","now_ms":0}`. Refuse `unknown_envelope` or `bad_args`.

### `callback <callback_path>`

The file must be one JSON callback object with `callback_id`, `request_id`, `envelope_id`, `document_id`, `signer_id`, `address`, `deadline_ms`, `kind`, and `outcome` (`accepted` or `rejected`). Malformed files or missing fields are `bad_args`. The desk may ignore a valid callback. It must not POST or allocate an id. If an envelope is terminal, repeated or conflicting callbacks leave it unchanged and exit 0. A callback for an unknown request id also exits 0 without a change. A callback may be used only as a hint to lookup a saved attempt; it cannot make `sent` true without a matching service record.

## E-signature service

The service has `POST /v1/envelopes` and `GET /v1/requests/<request_id>`. A new request id is accepted once and counts one effect. Repeating the same id and exact document, signer, address, deadline, and kind returns the same 200 result without another effect; changing any payload field returns 409. The accepted object has `outcome:"accepted"`; kind for this family is `signature_request`. The service may drop a reply after accepting, delay, or return an unavailable status without storing. A dropped reply is not evidence of no acceptance.

## Requirements

R1. **Persistence.** Envelopes survive new processes. Signing, declining, archiving, and a send killed after its durable record remain visible after restart.

R2. **Envelope record.** `status` presents the exact document, signer, address, deadline, envelope id, state, send, and request fields saved by `create-envelope`.

R3. **Decision and archive progression.** A sent envelope can be signed or declined only before its deadline; each decision is durable, and a signed or declined envelope can be archived. Invalid transitions refuse without a store change.

R4. **Signing deadline.** A decision exactly at `deadline_ms` is accepted; one millisecond after is refused `expired`. No service call is made by decisions and the first terminal decision remains fixed.

R5. **Legitimate progress.** A valid create/send/sign/archive sequence is not refused; a healthy send creates exactly one accepted service effect.

R6. **Envelope identity.** Envelope and document ids are namespace-safe. Reusing an existing id is refused `id_in_use` and does not overwrite another envelope or document.

R7. **Terminal semantics.** Declined and signed envelopes preserve their terminal decision; archive is terminal, and sending or deciding an archived envelope is refused without contacting the service.

R8. **Crash after accept.** If killed at `after-accept-before-record`, the service has one effect and local state is `send:"attempt_saved"`; a later send adopts the same request by lookup and causes no second effect.

R9. **Crash before request.** If killed at `after-attempt-saved-before-request`, there is no service POST and the attempt is visible. A later send sends exactly one request for that same envelope id; no other envelope id can replace it.

R10. **Crash after durable record.** If killed at `after-record-before-exit`, later status is `sent`; another send adds no effect.

R11. **Lost reply.** An accepted send whose reply is dropped is reconciled by lookup. `reconcile` never POSTs, does not report `not_sent` after a 200 lookup, and leaves exactly one effect.

R12. **Result protocol.** Every invocation emits exactly one JSON object. Success exits 0; refusals exit nonzero with a listed error code.

R13. **Unrelated writer.** A file not owned by the desk in `STATE_DIR` keeps identical bytes across commands, including refusals, while desk records remain readable.

R14. **Late callback.** Repeated and conflicting valid callbacks after a sent envelope leave document, signer, address, deadline, state, and send unchanged and add no effect.

## Error codes

`bad_args`, `unknown_envelope`, `id_in_use`, `invalid_state`, `not_sent`, `expired`, `conflict`, `service_unavailable`.
