# E-signature envelope desk

Requires Python 3.9+ and the supplied Ikaros wheel. From this directory:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
export STATE_DIR=$PWD/state SERVICE_URL=http://127.0.0.1:PORT
./run create-envelope env-1 doc-1 signer-1 person@example.com 1000 0
```

`./run` emits one JSON object per invocation. The durable desk record is kept in
`STATE_DIR/envelopes.json`; unrelated files are not touched. Run the supplied
stub with `node stub/server.mjs` and use its printed `service_url`.
