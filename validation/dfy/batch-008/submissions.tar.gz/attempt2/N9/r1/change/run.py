#!/usr/bin/env python3
import os,sys,json,re,signal,tempfile,urllib.request,urllib.error
from pathlib import Path
import fcntl
ID=re.compile(r'^[A-Za-z0-9._-]{1,64}$'); ADDR=re.compile(r'^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$'); NUM=re.compile(r'^(0|[1-9][0-9]*)$')
root=Path(os.environ.get('STATE_DIR','')); root.mkdir(parents=True,exist_ok=True); sf=root/'envelopes.json'; lf=root/'.desk.lock'
def die(code): print(json.dumps({'error':code},separators=(',',':'))); sys.exit(1)
def validid(x): return isinstance(x,str) and bool(ID.fullmatch(x))
def validnum(x): return isinstance(x,str) and bool(NUM.fullmatch(x)) and int(x)<=9999999999999
def load():
 try: return json.loads(sf.read_text()) if sf.exists() else {'envelopes':{}}
 except Exception: return {'envelopes':{}}
def save(x):
 fd,tmp=tempfile.mkstemp(dir=root,prefix='.desk-',text=True)
 with os.fdopen(fd,'w') as f: json.dump(x,f,separators=(',',':'),sort_keys=True); f.flush(); os.fsync(f.fileno())
 os.replace(tmp,sf)
def crash(label):
 if os.environ.get('CRASH_AT')==label: os.kill(os.getpid(),signal.SIGKILL)
def req(method,path,data=None):
 u=os.environ.get('SERVICE_URL','').rstrip('/')+path; b=json.dumps(data,separators=(',',':')).encode() if data is not None else None
 r=urllib.request.Request(u,data=b,method=method,headers={'content-type':'application/json'})
 try:
  with urllib.request.urlopen(r,timeout=5) as z: return z.status,json.loads(z.read())
 except urllib.error.HTTPError as e:
  try: return e.code,json.loads(e.read())
  except Exception: return e.code,{}
 except Exception: return None,None
def result(x): print(json.dumps(x,separators=(',',':'))); return 0
def ids_in_use(d,doc): return any(v.get('document_id')==doc for v in d['envelopes'].values())
def is_two(e): return 'signer2_id' in e
def reqs(e):
 if is_two(e): return [{'request_id':e['envelope_id']+'.s1','signer_id':e['signer_id'],'address':e['address'],'key':'s1'},{'request_id':e['envelope_id']+'.s2','signer_id':e['signer2_id'],'address':e['address2'],'key':'s2'}]
 return [{'request_id':e['envelope_id'],'signer_id':e['signer_id'],'address':e['address'],'key':'s1'}]
def terminal_fields(e):
 x={'envelope_id':e['envelope_id'],'document_id':e['document_id'],'signer_id':e['signer_id'],'address':e['address'],'deadline_ms':e['deadline_ms'],'state':e['state'],'send':e['send'],'request_id':e.get('request_id')}
 if is_two(e): x.update(signer2_id=e['signer2_id'],address2=e['address2'])
 return x
def main(a):
 cmd=a[0] if a else ''; d=load()
 if cmd=='create-envelope':
  if len(a)==7:
   if not validid(a[1]) or not validid(a[2]) or not validid(a[3]) or not ADDR.fullmatch(a[4]) or not validnum(a[5]) or not validnum(a[6]) or int(a[5])<int(a[6]): die('bad_args')
   eid,doc,sig,addr,dl,now=a[1:]
   if eid in d['envelopes'] or ids_in_use(d,doc): die('id_in_use')
   e={'envelope_id':eid,'document_id':doc,'signer_id':sig,'address':addr,'deadline_ms':int(dl),'state':'draft','send':'none','request_id':None,'created_ms':int(now)}
  elif len(a)==9:
   if not all(validid(x) for x in (a[1],a[2],a[3],a[5])) or not ADDR.fullmatch(a[4]) or not ADDR.fullmatch(a[6]) or a[3]==a[5] or not validnum(a[7]) or not validnum(a[8]) or int(a[7])<int(a[8]): die('bad_args')
   eid,doc,sig,addr,sig2,addr2,dl,now=a[1:]
   if eid in d['envelopes'] or ids_in_use(d,doc): die('id_in_use')
   e={'envelope_id':eid,'document_id':doc,'signer_id':sig,'address':addr,'signer2_id':sig2,'address2':addr2,'deadline_ms':int(dl),'state':'draft','send':'none','request_id':None,'created_ms':int(now),'requests':{}}
  else: die('bad_args')
  d['envelopes'][eid]=e; save(d); out={k:e[k] for k in ('envelope_id','document_id','signer_id','address','deadline_ms','state','send')}; out.update({'now_ms':int(now)}); out.update({k:e[k] for k in ('signer2_id','address2') if k in e}); return result(out)
 if cmd=='extend-deadline':
  if len(a)!=4 or not validid(a[1]) or not validnum(a[2]) or not validnum(a[3]): die('bad_args')
  e=d['envelopes'].get(a[1]);
  if not e: die('unknown_envelope')
  if e['state'] not in ('draft','sent') or int(a[2])<=e['deadline_ms'] or int(a[2])<int(a[3]): die('invalid_state' if e['state'] not in ('draft','sent') else 'bad_args')
  e['deadline_ms']=int(a[2]); save(d); return result({'envelope_id':a[1],'deadline_ms':e['deadline_ms'],'state':e['state'],'now_ms':int(a[3])})
 if cmd=='callback':
  if len(a)!=2: die('bad_args')
  try: cb=json.loads(Path(a[1]).read_text())
  except Exception: die('bad_args')
  fields=('callback_id','request_id','envelope_id','document_id','signer_id','address','deadline_ms','kind','outcome')
  if any(k not in cb for k in fields) or cb['outcome'] not in ('accepted','rejected'): die('bad_args')
  return result({'callback_id':cb['callback_id'],'ignored':True})
 if cmd not in ('status','send','reconcile','sign','decline','archive') or len(a)<2: die('bad_args')
 if (cmd in ('status','send','reconcile') and len(a)!=2) or (cmd in ('sign','decline','archive') and len(a)!=3): die('bad_args')
 if not validid(a[1]): die('bad_args')
 eid=a[1]; e=d['envelopes'].get(eid)
 if not e: die('unknown_envelope')
 if cmd=='status': return result(terminal_fields(e)|{'now_ms':e.get('created_ms',0)})
 if cmd in ('send','reconcile'):
  if e['state'] in ('signed','declined','archived'): die('invalid_state')
  if cmd=='send' and e['state']=='sent': return result({'envelope_id':eid,'state':'sent','send':'sent','request_id':eid if not is_two(e) else None})
  if e['send']=='none':
   e['send']='attempt_saved'; e['request_id']=eid if not is_two(e) else None
   if is_two(e): e['requests']={r['key']:{'request_id':r['request_id'],'send':'attempt_saved'} for r in reqs(e)}
   save(d); crash('after-attempt-saved-before-request')
  all_done=True
  for r in reqs(e):
   rec=e.get('requests',{}).get(r['key'],{'request_id':r['request_id'],'send':'attempt_saved'})
   code,obj=req('GET','/v1/requests/'+rec['request_id'])
   if code==200:
    expected={'request_id':rec['request_id'],'envelope_id':eid,'document_id':e['document_id'],'signer_id':r['signer_id'],'address':r['address'],'deadline_ms':e['deadline_ms'],'kind':'signature_request'}
    if any(obj.get(k)!=v for k,v in expected.items()): die('conflict')
    rec['send']='sent'; e.setdefault('requests',{})[r['key']]=rec; continue
   if cmd=='reconcile' and code==404: return result({'envelope_id':eid,'send':'not_sent','request_id':rec['request_id']})
   if code not in (404,None): die('service_unavailable' if code!=409 else 'conflict')
   if cmd=='reconcile': return result({'envelope_id':eid,'send':'not_sent','request_id':rec['request_id']})
   payload={'request_id':rec['request_id'],'envelope_id':eid,'document_id':e['document_id'],'signer_id':r['signer_id'],'address':r['address'],'deadline_ms':e['deadline_ms'],'kind':'signature_request'}
   code,obj=req('POST','/v1/envelopes',payload)
   if code!=200: die('conflict' if code==409 else 'service_unavailable')
   crash('after-accept-before-record'); rec['send']='sent'; e.setdefault('requests',{})[r['key']]=rec
  if is_two(e): all_done=all(v.get('send')=='sent' for v in e['requests'].values())
  if not all_done: return result({'envelope_id':eid,'send':'attempt_saved','request_id':None})
  e['send']='sent'; e['state']='sent'; save(d); crash('after-record-before-exit'); return result({'envelope_id':eid,'state':'sent','send':'sent','request_id':eid if not is_two(e) else None})
 if cmd in ('sign','decline','archive'):
  if not validnum(a[2]): die('bad_args')
  now=int(a[2])
  if cmd=='archive':
   if e['state'] not in ('signed','declined'): die('invalid_state')
   e['state']='archived'; save(d); return result({'envelope_id':eid,'state':'archived','now_ms':now})
  if e['state']=='draft': die('not_sent')
  if e['state']!='sent': die('invalid_state')
  limit=e['deadline_ms']+(86400000 if is_two(e) else 0)
  if now>limit: die('expired')
  e['state']='signed' if cmd=='sign' else 'declined'; save(d); return result({'envelope_id':eid,'state':e['state'],'now_ms':now})
 die('bad_args')
with open(lf,'a+') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 try: sys.exit(main(sys.argv[1:]))
 except SystemExit: raise
 except Exception: die('service_unavailable')
