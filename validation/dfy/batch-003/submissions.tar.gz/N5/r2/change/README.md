# Freelancer payout desk

This is a single-process durable payout desk backed by the local Ikaros runtime.
The Ikaros machine (`payout_v1.ik.toml` and `payout_v2.ik.toml`) owns lifecycle
transitions and persistence; `app.mjs` owns CLI validation, filesystem
boundaries, and HTTP calls. New stores use v2; old v1 stores are not migrated.

## Setup

Node 22 is required. From this directory, install the supplied offline packages:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

(The platform package in that command is for macOS arm64.)

## Run

The environment variables `STATE_DIR` and `SERVICE_URL` are required for every
command, including `status`. `STATE_DIR` is created by `open`; the desk owns
`payout.json` there and the Ikaros runtime owns `payout.db`. The provider URL is
the URL printed by `node stub/server.mjs`.

```sh
SERVICE_URL=http://127.0.0.1:PORT STATE_DIR=/tmp/payout-state ./run status
SERVICE_URL=http://127.0.0.1:PORT STATE_DIR=/tmp/payout-state ./run open alice 2026-11 100000
SERVICE_URL=http://127.0.0.1:PORT STATE_DIR=/tmp/payout-state ./run submit 25000 "November work"
SERVICE_URL=http://127.0.0.1:PORT STATE_DIR=/tmp/payout-state ./run approve REQUEST_ID manager-1
SERVICE_URL=http://127.0.0.1:PORT STATE_DIR=/tmp/payout-state ./run approve-second REQUEST_ID manager-2
SERVICE_URL=http://127.0.0.1:PORT STATE_DIR=/tmp/payout-state ./run pay
```

`approve` amounts above 50000 cents enter `awaiting_second`; use
`approve-second` with a distinct manager to make them payable. `cancel` is
allowed for submitted, awaiting-second, and approved requests until a payment
attempt is saved. `apply` is an alias for `pay`. `CRASH_AT` is supported for
the three crash labels documented in `BRIEF.md`; the process terminates with
SIGKILL at the relevant durable boundary. `callback PATH` validates and ignores
a callback JSON file without contacting the provider.

All invocations print exactly one JSON object. Refusals print an `error` object
and exit nonzero. The provider is never contacted by `open`, `submit`,
`approve`, `reject`, `cancel`, `status`, or `callback`.
