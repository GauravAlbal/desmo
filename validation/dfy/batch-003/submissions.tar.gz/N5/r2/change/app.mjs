import { promises as fs } from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { Kernel } from "@ikaros/runtime";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const MACHINE = path.join(ROOT, "payout_v2.ik.toml");
const AGGREGATE_ID = "desk";
const STATE_FILE_NAME = "payout.json";
const DB_FILE_NAME = "payout.db";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const AMOUNT_RE = /^(0|[1-9][0-9]*)$/;
const MAX_CENTS = 100000000n;
const CLEARED = "~cleared~";

class AppError extends Error {
  constructor(code) { super(code); this.code = code; }
}

function fail(code) { throw new AppError(code); }

function amount(raw) {
  if (typeof raw !== "string" || !AMOUNT_RE.test(raw)) fail("bad_amount");
  const value = BigInt(raw);
  if (value < 1n || value > MAX_CENTS) fail("bad_amount");
  return Number(value);
}

function identifier(raw) {
  if (typeof raw !== "string" || !ID_RE.test(raw)) fail("bad_args");
  return raw;
}

function text(raw, code = "bad_args") {
  if (typeof raw !== "string" || Array.from(raw).length > 200) fail(code);
  return raw;
}

function asNumber(value) {
  if (typeof value === "bigint") return Number(value);
  return value ?? 0;
}

function newId(prefix) {
  return `${prefix}-${crypto.randomUUID()}`;
}

function paths() {
  const stateDir = process.env.STATE_DIR;
  if (!stateDir) fail("missing_state_dir");
  return {
    dir: path.resolve(stateDir),
    json: path.resolve(stateDir, STATE_FILE_NAME),
    db: path.resolve(stateDir, DB_FILE_NAME),
  };
}

async function exists(file) {
  try { await fs.access(file); return true; } catch { return false; }
}

async function readMeta(p) {
  const jsonExists = await exists(p.json);
  const dbExists = await exists(p.db);
  if (!jsonExists && !dbExists) return null;
  if (!jsonExists || !dbExists) fail("corrupt_state");
  let value;
  try { value = JSON.parse(await fs.readFile(p.json, "utf8")); } catch { fail("corrupt_state"); }
  if (!value || value.version !== 1 || value.aggregate_id !== AGGREGATE_ID) fail("corrupt_state");
  return value;
}

async function writeMeta(p) {
  const temporary = `${p.json}.tmp-${process.pid}`;
  await fs.writeFile(temporary, JSON.stringify({ version: 1, aggregate_id: AGGREGATE_ID }) + "\n", { encoding: "utf8", mode: 0o600 });
  await fs.rename(temporary, p.json);
}

async function openMachine(p) {
  const kernel = new Kernel(p.db);
  const machine = await kernel.machine(MACHINE);
  return { kernel, machine };
}

async function current(p, required = true) {
  const meta = await readMeta(p);
  if (!meta) { if (required) fail("no_request"); return null; }
  try {
    const opened = await openMachine(p);
    const aggregate = await opened.machine.show(AGGREGATE_ID);
    return { ...opened, aggregate, facts: aggregate.state ?? {} };
  } catch {
    fail("corrupt_state");
  }
}

function stateName(aggregate) { return aggregate.namedState(); }

function outputState(c) {
  if (!c) {
    return { freelancer_id: null, period_id: null, cap_cents: null, request_id: null,
      requested_cents: null, approved_cents: null, manager_id: null, second_manager_id: null,
      memo: null, status: "none", payment: "none", payment_id: null };
  }
  const { aggregate: a, facts: f } = c;
  const status = stateName(a);
  const hasRequest = ["submitted", "awaiting_second", "approved", "attempt_saved", "paid", "rejected", "cancelled"].includes(status);
  const hasApproval = ["awaiting_second", "approved", "attempt_saved", "paid"].includes(status);
  const hasPayment = ["attempt_saved", "paid"].includes(status);
  return {
    freelancer_id: f.freelancer_id ?? null,
    period_id: f.period_id ?? null,
    cap_cents: f.cap_cents === undefined ? null : asNumber(f.cap_cents),
    request_id: hasRequest ? (f.request_id ?? null) : null,
    requested_cents: hasRequest ? asNumber(f.requested_cents) : null,
    approved_cents: hasApproval ? asNumber(f.approved_cents) : (hasRequest ? 0 : null),
    manager_id: hasApproval ? (f.manager_id ?? null) : null,
    second_manager_id: ["approved", "attempt_saved", "paid"].includes(status) && asNumber(f.approved_cents) > 50000 ? (f.second_manager_id ?? null) : null,
    memo: hasRequest ? (f.memo ?? "") : null,
    status,
    payment: status === "paid" ? "paid" : (status === "attempt_saved" ? "attempt_saved" : "none"),
    payment_id: hasPayment ? (f.payment_id ?? null) : null,
  };
}

function requireService() {
  if (!process.env.SERVICE_URL) fail("missing_service_url");
  try { return new URL(process.env.SERVICE_URL); } catch { fail("bad_service_url"); }
}

async function requestJson(url, options) {
  let response;
  try {
    response = await fetch(url, { ...options, signal: AbortSignal.timeout(2500) });
  } catch {
    fail("service_unavailable");
  }
  let body;
  try { body = await response.json(); } catch { fail("service_unavailable"); }
  return { response, body };
}

function providerRoot() {
  const base = requireService();
  return base.toString().replace(/\/$/, "");
}

function paymentPayload(f, paymentId) {
  return {
    payment_id: paymentId,
    freelancer_id: f.freelancer_id,
    period_id: f.period_id,
    request_id: f.request_id,
    amount_cents: asNumber(f.approved_cents),
  };
}

function matchesPayment(body, expected) {
  return body && body.payment_id === expected.payment_id && body.freelancer_id === expected.freelancer_id &&
    body.period_id === expected.period_id && body.request_id === expected.request_id &&
    body.amount_cents === expected.amount_cents && body.outcome === "paid";
}

function crashIf(label) {
  if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL");
}

async function markPaid(c, expected) {
  crashIf("after-accept-before-record");
  try { await c.aggregate.command("record_paid"); } catch { fail("corrupt_state"); }
  crashIf("after-record-before-exit");
  return { request_id: expected.request_id, payment_id: expected.payment_id, amount_cents: expected.amount_cents, status: "paid", payment: "paid" };
}

async function lookup(c, paymentId) {
  const { response, body } = await requestJson(`${providerRoot()}/v1/payments/${encodeURIComponent(paymentId)}`, { method: "GET" });
  if (response.status === 404) return { found: false };
  if (response.status >= 500) fail("service_unavailable");
  if (response.status !== 200) return { conflict: true };
  return { found: true, body };
}

async function postPayment(c, expected) {
  const { response, body } = await requestJson(`${providerRoot()}/v1/payouts`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(expected),
  });
  if (response.status >= 500) fail("service_unavailable");
  if (response.status !== 200) return { conflict: true };
  return { body };
}

async function pay(c) {
  const status = stateName(c.aggregate);
  if (status === "paid") {
    const f = c.facts;
    return { request_id: f.request_id, payment_id: f.payment_id, amount_cents: asNumber(f.approved_cents), status: "paid", payment: "paid" };
  }
  if (status === "attempt_saved") {
    const expected = paymentPayload(c.facts, c.facts.payment_id);
    const found = await lookup(c, c.facts.payment_id);
    if (found.conflict) fail("lookup_conflict");
    if (found.found) {
      if (!matchesPayment(found.body, expected)) fail("lookup_conflict");
      return markPaid(c, expected);
    }
    const posted = await postPayment(c, expected);
    if (posted.conflict) fail("lookup_conflict");
    if (!matchesPayment(posted.body, expected)) fail("lookup_conflict");
    return markPaid(c, expected);
  }
  if (status === "none" || status === "open") fail("no_request");
  if (status !== "approved") fail("not_approved");
  const paymentId = newId("pay");
  try { c = { ...c, aggregate: await c.aggregate.command("start_payment", { payment_id: paymentId }) }; }
  catch { fail("corrupt_state"); }
  crashIf("after-payment-saved-before-request");
  const expected = paymentPayload(c.facts, paymentId);
  const posted = await postPayment(c, expected);
  if (posted.conflict) fail("lookup_conflict");
  if (!matchesPayment(posted.body, expected)) fail("lookup_conflict");
  return markPaid(c, expected);
}

async function reconcile(c, paymentId) {
  const status = stateName(c.aggregate);
  if (status === "none" || status === "open" || status === "submitted" || status === "approved") fail("no_payment");
  if (status === "paid") {
    if (paymentId !== c.facts.payment_id) fail("payment_mismatch");
    return { request_id: c.facts.request_id, payment_id: c.facts.payment_id, amount_cents: asNumber(c.facts.approved_cents), status: "paid", payment: "paid", lookup: "paid" };
  }
  if (status !== "attempt_saved") fail("no_payment");
  if (paymentId !== c.facts.payment_id) fail("payment_mismatch");
  const expected = paymentPayload(c.facts, paymentId);
  const found = await lookup(c, paymentId);
  if (found.conflict) fail("lookup_conflict");
  if (!found.found) return { lookup: "not_sent", request_id: c.facts.request_id, payment_id: paymentId, payment: "attempt_saved", status: "approved" };
  if (!matchesPayment(found.body, expected)) fail("lookup_conflict");
  const result = await markPaid(c, expected);
  return { ...result, lookup: "paid" };
}

async function command(args) {
  const p = paths();
  const name = args[0];
  requireService();
  if (name === "status") {
    if (args.length !== 1) fail("bad_args");
    return outputState(await current(p, false));
  }
  if (name === "open") {
    if (args.length !== 4) fail("bad_args");
    const freelancer = identifier(args[1]);
    const period = identifier(args[2]);
    const cap = amount(args[3]);
    if (await readMeta(p)) fail("already_open");
    await fs.mkdir(p.dir, { recursive: true });
    const opened = await openMachine(p);
    try {
      await (await opened.machine.create(AGGREGATE_ID)).command("open", { freelancer_id: freelancer, period_id: period, cap_cents: cap });
    } catch { fail("corrupt_state"); }
    await writeMeta(p);
    return { freelancer_id: freelancer, period_id: period, cap_cents: cap, request_id: null, status: "none", payment: "none" };
  }
  if (name === "callback") {
    if (args.length !== 2) fail("bad_args");
    try { JSON.parse(await fs.readFile(args[1], "utf8")); } catch { fail("bad_callback"); }
    return { callback: "ignored" };
  }
  const c = await current(p);
  if (name === "submit") {
    if (args.length < 2 || args.length > 3) fail("bad_args");
    const cents = amount(args[1]);
    const memo = args.length === 3 ? text(args[2]) : "";
    const status = stateName(c.aggregate);
    if (!["open", "rejected", "cancelled", "paid"].includes(status)) {
      if (status === "none") fail("no_request");
      fail("request_exists");
    }
    const cap = asNumber(c.facts.cap_cents);
    const reserved = asNumber(c.facts.reserved_cents);
    if (cents > cap - reserved) fail("over_cap");
    const requestId = newId("req");
    try { await c.aggregate.command("submit", { request_id: requestId, requested_cents: cents, remaining_cents: cap - reserved, memo, clear_manager_id: CLEARED, clear_second_manager_id: CLEARED, clear_payment_id: CLEARED }); }
    catch { fail("corrupt_state"); }
    return { request_id: requestId, freelancer_id: c.facts.freelancer_id, period_id: c.facts.period_id, requested_cents: cents, approved_cents: 0, memo, status: "submitted", payment: "none", payment_id: null };
  }
  if (name === "approve") {
    if (args.length < 3 || args.length > 4) fail("bad_args");
    const requestId = identifier(args[1]);
    const manager = identifier(args[2]);
    const status = stateName(c.aggregate);
    if (c.facts.request_id !== requestId) fail(c.facts.request_id ? "request_mismatch" : "no_request");
    if (status !== "submitted") fail("bad_status");
    const requested = asNumber(c.facts.requested_cents);
    const approved = args.length === 4 ? amount(args[3]) : requested;
    if (approved > requested) fail("bad_amount");
    const nextReserved = asNumber(c.facts.reserved_cents) + approved;
    if (nextReserved > asNumber(c.facts.cap_cents)) fail("over_cap");
    let next;
    try {
      next = await c.aggregate.command("approve", {
        manager_id: manager,
        approved_cents: approved,
        new_reserved_cents: nextReserved,
        clear_second_manager_id: CLEARED,
      });
    } catch { fail("corrupt_state"); }
    return { request_id: requestId, manager_id: manager, approved_cents: approved, status: stateName(next) };
  }
  if (name === "approve-second") {
    if (args.length !== 3) fail("bad_args");
    const requestId = identifier(args[1]);
    const manager = identifier(args[2]);
    const status = stateName(c.aggregate);
    if (c.facts.request_id !== requestId) fail(c.facts.request_id ? "request_mismatch" : "no_request");
    if (status === "approved" && asNumber(c.facts.approved_cents) > 50000 && c.facts.second_manager_id === manager) {
      return { request_id: requestId, manager_id: manager, approved_cents: asNumber(c.facts.approved_cents), status: "approved" };
    }
    if (status !== "awaiting_second") fail("bad_status");
    if (c.facts.manager_id === manager) fail("duplicate_manager");
    let next;
    try { next = await c.aggregate.command("approve_second", { manager_id: manager }); }
    catch { fail("corrupt_state"); }
    return { request_id: requestId, manager_id: manager, approved_cents: asNumber(c.facts.approved_cents), status: stateName(next) };
  }
  if (name === "reject") {
    if (args.length < 2 || args.length > 3) fail("bad_args");
    const requestId = identifier(args[1]);
    const reason = args.length === 3 ? text(args[2]) : "";
    if (c.facts.request_id !== requestId) fail(c.facts.request_id ? "request_mismatch" : "no_request");
    if (stateName(c.aggregate) !== "submitted") fail("bad_status");
    try { await c.aggregate.command("reject", { reason }); } catch { fail("corrupt_state"); }
    return { request_id: requestId, status: "rejected", payment: "none" };
  }
  if (name === "cancel") {
    if (args.length !== 2) fail("bad_args");
    const requestId = identifier(args[1]);
    if (c.facts.request_id !== requestId) fail(c.facts.request_id ? "request_mismatch" : "no_request");
    const status = stateName(c.aggregate);
    if (status === "attempt_saved") fail("payment_started");
    if (status === "paid" || status === "rejected" || status === "cancelled") fail("bad_status");
    if (status !== "submitted" && status !== "awaiting_second" && status !== "approved") fail("bad_status");
    try { await c.aggregate.command("cancel", { clear_manager_id: CLEARED, clear_second_manager_id: CLEARED, clear_payment_id: CLEARED }); } catch { fail("corrupt_state"); }
    return { request_id: requestId, status: "cancelled", payment: "none" };
  }
  if (name === "pay" || name === "apply") {
    if (args.length !== 1) fail("bad_args");
    return await pay(c);
  }
  if (name === "reconcile") {
    if (args.length !== 2) fail("bad_args");
    return await reconcile(c, identifier(args[1]));
  }
  fail("bad_args");
}

let result;
try {
  result = await command(process.argv.slice(2));
  process.stdout.write(JSON.stringify(result) + "\n");
} catch (error) {
  const code = error instanceof AppError ? error.code : "corrupt_state";
  process.stdout.write(JSON.stringify({ error: code }) + "\n");
  process.exitCode = 1;
}
