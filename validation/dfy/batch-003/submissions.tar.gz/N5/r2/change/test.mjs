import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";

const root = path.dirname(new URL(import.meta.url).pathname);
const server = spawn(process.execPath, [path.join(root, "stub/server.mjs")], { cwd: root, stdio: ["ignore", "pipe", "inherit"] });
let line = "";
const service = await new Promise((resolve, reject) => {
  server.stdout.on("data", (chunk) => {
    line += chunk.toString();
    const end = line.indexOf("\n");
    if (end >= 0) resolve(JSON.parse(line.slice(0, end)));
  });
  server.on("error", reject);
});

const run = (state, args, extra = {}) => {
  const result = spawnSync(path.join(root, "run"), args, {
    cwd: root,
    encoding: "utf8",
    env: { ...process.env, STATE_DIR: state, SERVICE_URL: service.service_url, ...extra },
  });
  const output = result.stdout.trim() ? JSON.parse(result.stdout) : null;
  return { ...result, output };
};
const control = (url, body) => fetch(`${service.control_url}${url}`, body ? {
  method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body),
} : {}).then((r) => r.json());
const newState = () => mkdtempSync(path.join(tmpdir(), "payout-test-"));

try {
  const first = newState();
  assert.equal(run(first, ["open", "restart-user", "period", "1000"]).output.status, "none");
  assert.equal(run(first, ["status"]).output.period_id, "period");
  const submitted = run(first, ["submit", "100", "restart memo"]).output;
  assert.equal(run(first, ["approve", submitted.request_id, "manager"]).output.status, "approved");

  const beforePost = newState();
  run(beforePost, ["open", "crash-user", "period", "1000"]);
  const crashRequest = run(beforePost, ["submit", "100"]).output.request_id;
  run(beforePost, ["approve", crashRequest, "manager"]);
  const crashed = run(beforePost, ["pay"], { CRASH_AT: "after-payment-saved-before-request" });
  assert.notEqual(crashed.status, 0);
  assert.equal(run(beforePost, ["status"]).output.payment, "attempt_saved");
  assert.equal(run(beforePost, ["pay"]).output.status, "paid");

  const dropped = newState();
  run(dropped, ["open", "drop-user", "period", "1000"]);
  const dropRequest = run(dropped, ["submit", "100"]).output.request_id;
  run(dropped, ["approve", dropRequest, "manager"]);
  await control("/fault", { drop_reply: true });
  const lost = run(dropped, ["pay"]);
  assert.equal(lost.output.error, "service_unavailable");
  const paymentId = run(dropped, ["status"]).output.payment_id;
  await control("/fault", {});
  assert.equal(run(dropped, ["reconcile", paymentId]).output.lookup, "paid");
} finally {
  const threshold = newState();
  run(threshold, ["open", "threshold-user", "period", "100000"]);
  const thresholdRequest = run(threshold, ["submit", "60000"]).output.request_id;
  assert.equal(run(threshold, ["approve", thresholdRequest, "first-manager"]).output.status, "awaiting_second");
  assert.equal(run(threshold, ["status"]).output.status, "awaiting_second");
  assert.equal(run(threshold, ["pay"]).output.error, "not_approved");
  assert.equal(run(threshold, ["approve-second", thresholdRequest, "first-manager"]).output.error, "duplicate_manager");
  assert.equal(run(threshold, ["approve-second", thresholdRequest, "second-manager"]).output.status, "approved");
  assert.equal(run(threshold, ["approve-second", thresholdRequest, "second-manager"]).output.status, "approved");
  assert.equal(run(threshold, ["pay"]).output.status, "paid");
  assert.equal(run(threshold, ["status"]).output.second_manager_id, "second-manager");

  const cancelled = newState();
  run(cancelled, ["open", "cancel-user", "period", "100000"]);
  const cancelledRequest = run(cancelled, ["submit", "60000"]).output.request_id;
  assert.equal(run(cancelled, ["approve", cancelledRequest, "first-manager"]).output.status, "awaiting_second");
  assert.equal(run(cancelled, ["cancel", cancelledRequest]).output.status, "cancelled");
  const cancelledStatus = run(cancelled, ["status"]).output;
  assert.equal(cancelledStatus.approved_cents, 0);
  assert.equal(cancelledStatus.manager_id, null);
  assert.equal(run(cancelled, ["pay"]).output.error, "not_approved");

  const cancelApproved = newState();
  run(cancelApproved, ["open", "cancel-approved-user", "period", "1000"]);
  const approvedRequest = run(cancelApproved, ["submit", "100"]).output.request_id;
  assert.equal(run(cancelApproved, ["approve", approvedRequest, "manager"]).output.status, "approved");
  assert.equal(run(cancelApproved, ["cancel", approvedRequest]).output.status, "cancelled");
  assert.equal(run(cancelApproved, ["submit", "100"]).output.status, "submitted");

  const cancelAttempt = newState();
  run(cancelAttempt, ["open", "cancel-attempt-user", "period", "1000"]);
  const attemptRequest = run(cancelAttempt, ["submit", "100"]).output.request_id;
  run(cancelAttempt, ["approve", attemptRequest, "manager"]);
  const attemptCrash = run(cancelAttempt, ["pay"], { CRASH_AT: "after-payment-saved-before-request" });
  assert.notEqual(attemptCrash.status, 0);
  assert.equal(run(cancelAttempt, ["cancel", attemptRequest]).output.error, "payment_started");
  assert.equal(run(cancelAttempt, ["pay"]).output.status, "paid");
  const accepted = newState();
  run(accepted, ["open", "accepted-user", "period", "1000"]);
  const acceptedRequest = run(accepted, ["submit", "100"]).output.request_id;
  run(accepted, ["approve", acceptedRequest, "manager"]);
  const acceptedCrash = run(accepted, ["pay"], { CRASH_AT: "after-accept-before-record" });
  assert.notEqual(acceptedCrash.status, 0);
  assert.equal(run(accepted, ["status"]).output.payment, "attempt_saved");
  assert.equal(run(accepted, ["cancel", acceptedRequest]).output.error, "payment_started");
  assert.equal(run(accepted, ["pay"]).output.status, "paid");
  server.kill("SIGTERM");
}
console.log("lifecycle recovery tests passed");
