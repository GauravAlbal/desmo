# Change: dual approval and cancellation window

R1–R14 remain in force. This change adds a fixed approval threshold and a second-approval command, and revises cancellation. The threshold is **50000 cents** and is compared with `approved_cents` (the amount that will be paid), not the requested amount.

`approve` keeps its old interface and behavior for amounts at or below the threshold. Above the threshold it records the first manager approval but leaves the request in `awaiting_second` and does not permit payment. The first manager cannot also be the second manager. A new command is:

`approve-second <request_id> <manager_id>`

It is valid only for `awaiting_second`, requires a distinct valid manager id, and changes the request to `approved`. It does not change approved cents, reserve cap again, or contact the provider. `approve-second` is idempotent only after the request is already `approved` with a second manager: it returns the current approved result when the same second manager is supplied; a different manager is `bad_status`.

Cancellation is revised: a request may be cancelled while `submitted`, `awaiting_second`, or `approved`, as long as no payment attempt has been saved. Cancellation after an attempt is saved (including after provider acceptance but before local paid record) remains `payment_started`; it must not erase the saved payment id or make a second request. Cancellation releases any cap reservation and clears approval fields. It still never contacts the provider.

## C1–C5

C1. An approval of 50000 cents or less reaches `approved` with one manager and is payable. An approval of 50001 cents or more reaches `awaiting_second`, remains unpayable with `not_approved`, and makes no provider request.

C2. `approve-second` completes a threshold approval. A distinct second manager changes `awaiting_second` to `approved`, preserves request id and approved cents, and permits exactly one provider effect. Reusing the first manager is refused as `duplicate_manager`; an invalid request/status is refused without mutation.

C3. Threshold and cap accounting are durable. A saved `awaiting_second` record survives restart and crash boundaries; a second approval does not double-count the cap. A second active request whose approved amount plus the awaiting/approved reservation exceeds the cap is `over_cap` and does not contact the provider.

C4. Cancellation now works before payment for submitted, awaiting_second, and approved requests. It returns `cancelled`, clears manager/approval fields, releases the reservation, and makes pay `not_approved`; a prior request id cannot cancel a later request. The provider remains at zero effects.

C5. Cancellation cannot defeat exactly-once payment. Once a payment attempt is saved, cancel returns `payment_started`, preserves the attempt and ids, and cannot alter it even if the provider has accepted. Reconcile or pay then reaches `paid` for that same payment id with one effect; no cancellation command adds an effect or changes paid state.
