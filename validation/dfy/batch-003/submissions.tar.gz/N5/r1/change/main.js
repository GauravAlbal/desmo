#!/usr/bin/env node
import { mkdir, readFile } from "node:fs/promises";
import { resolve, relative, join } from "node:path";
import { randomUUID } from "node:crypto";
import { Kernel, StoreNotFoundError, HistoricalResult } from "@ikaros/runtime";

const MACHINE_PATH = resolve(new URL("./payout_desk.ik.toml", import.meta.url).pathname);
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const MAX_CENTS = 100000000;
const MAX_MEMO = 200;
const REQUEST_ID = () => `req-${randomUUID()}`;
const PAYMENT_ID = () => `pay-${randomUUID()}`;

function error(code) { return { error: code }; }
function amount(value) {
  if (typeof value !== "string" || !/^(?:0|[1-9][0-9]*)$/.test(value)) return null;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= 1 && parsed <= MAX_CENTS ? parsed : null;
}
function validId(value) { return typeof value === "string" && ID_RE.test(value); }
function validMemo(value) { return typeof value === "string" && [...value].length <= MAX_MEMO; }
function fact(aggregate, key, fallback = undefined) {
  const raw = aggregate?.raw ?? {};
  const facts = raw.facts && typeof raw.facts === "object" ? raw.facts : (raw.state && typeof raw.state === "object" ? raw.state : raw);
  return Object.prototype.hasOwnProperty.call(facts, key) ? facts[key] : fallback;
}
function stateOf(aggregate) {
  const raw = aggregate?.raw ?? {};
  if (raw.state && typeof raw.state === "object" && typeof raw.state.state === "string") return raw.state.state;
  return aggregate?.namedState?.() ?? "none";
}
function current(aggregate) {
  const state = stateOf(aggregate);
  return {
    freelancer_id: fact(aggregate, "freelancer_id", null) || null,
    period_id: fact(aggregate, "period_id", null) || null,
    cap_cents: fact(aggregate, "cap_cents", null),
    request_id: state === "none" ? null : fact(aggregate, "request_id", null) || null,
    requested_cents: state === "none" ? null : fact(aggregate, "requested_cents", null),
    approved_cents: ["none", "submitted"].includes(state) ? (state === "submitted" ? 0 : null) : fact(aggregate, "approved_cents", 0),
    manager_id: ["none", "submitted"].includes(state) ? null : fact(aggregate, "manager_id", null) || null,
    second_manager_id: ["none", "submitted"].includes(state) ? null : fact(aggregate, "second_manager_id", null) || null,
    memo: state === "none" ? null : fact(aggregate, "memo", ""),
    status: state,
    payment: paymentState(aggregate),
    payment_id: paymentIdFor(aggregate),
  };
}
function paymentIdFor(aggregate) {
  const state = stateOf(aggregate);
  if (["none", "submitted", "rejected", "cancelled"].includes(state)) return null;
  return fact(aggregate, "payment_id", null) || null;
}
function paymentState(aggregate) {
  const state = stateOf(aggregate);
  if (state === "paid") return "paid";
  if (state === "approved" && paymentIdFor(aggregate)) return "attempt_saved";
  return "none";
}
function successPayment(aggregate, extra = {}) {
  return { request_id: fact(aggregate, "request_id"), payment_id: fact(aggregate, "payment_id"), amount_cents: fact(aggregate, "approved_cents"), status: "paid", payment: "paid", ...extra };
}
function isStoreMissing(err) { return err instanceof StoreNotFoundError || err?.code === "IK_STORE_NOT_FOUND"; }
function isCorrupt(err) { return err?.code === "IK_STORE_CORRUPT" || err?.code === "IK_JOURNAL_CORRUPT" || err?.code === "IK_PROTOCOL_INVALID"; }
function isNotFound(err) { return err?.code === "IK_ILLEGAL_STATE" || err?.rule === "aggregate.not_found"; }
function opId(kernel) { return kernel.newOperationId(); }
function unwrap(result) { return result instanceof HistoricalResult ? null : result; }

async function context(env) {
  const stateDir = env.STATE_DIR;
  if (typeof stateDir !== "string" || stateDir.length === 0) throw new Error("bad_state_dir");
  await mkdir(stateDir, { recursive: true });
  const store = join(resolve(stateDir), ".payout-desk.sqlite");
  const kernel = new Kernel(store);
  const machine = await kernel.machine(MACHINE_PATH);
  return { kernel, machine, stateDir: resolve(stateDir), store };
}
async function loadAggregate(ctx) {
  try { return await ctx.machine.show("desk"); }
  catch (err) { if (isStoreMissing(err) || isNotFound(err)) return null; throw err; }
}
async function requireAggregate(ctx) { return loadAggregate(ctx); }
function ensureService(env) { return typeof env.SERVICE_URL === "string" && env.SERVICE_URL.length > 0; }
function serviceUrl(env, path) { return new URL(path, env.SERVICE_URL.endsWith("/") ? env.SERVICE_URL : `${env.SERVICE_URL}/`).toString(); }
async function fetchJson(url, options = {}) {
  const controller = new AbortController(); const timeout = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal }); const text = await response.text(); let body = null;
    if (text.length > 0) { try { body = JSON.parse(text); } catch { return { response, body: null, malformed: true }; } }
    return { response, body, malformed: false };
  } catch { return { transport: true }; } finally { clearTimeout(timeout); }
}
function matchesPayment(body, aggregate) {
  return body && body.payment_id === fact(aggregate, "payment_id") && body.freelancer_id === fact(aggregate, "payment_freelancer_id") && body.period_id === fact(aggregate, "payment_period_id") && body.request_id === fact(aggregate, "payment_request_id") && body.amount_cents === fact(aggregate, "payment_amount_cents") && body.outcome === "paid";
}
async function lookupSaved(env, aggregate) { return fetchJson(serviceUrl(env, `/v1/payments/${encodeURIComponent(fact(aggregate, "payment_id"))}`)); }
async function postSaved(env, aggregate) {
  return fetchJson(serviceUrl(env, "/v1/payouts"), { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ payment_id: fact(aggregate, "payment_id"), freelancer_id: fact(aggregate, "payment_freelancer_id"), period_id: fact(aggregate, "payment_period_id"), request_id: fact(aggregate, "payment_request_id"), amount_cents: fact(aggregate, "payment_amount_cents") }) });
}
async function recordPaid(ctx, aggregate) {
  const paidTotal = Number(fact(aggregate, "paid_total_cents", 0)) + Number(fact(aggregate, "approved_cents", 0));
  const result = await aggregate.execute({ name: "record_paid", args: { payment_id: fact(aggregate, "payment_id"), paid_total_cents: paidTotal } }, { operationId: opId(ctx.kernel) });
  return unwrap(result) ?? aggregate;
}
function afterCrash(label) { if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL"); }
async function pay(ctx, env) {
  let aggregate = await requireAggregate(ctx); if (!aggregate) return error("no_request");
  const state = stateOf(aggregate); if (state === "paid") return successPayment(aggregate); if (state !== "approved") return error("not_approved");
  const hadAttempt = Boolean(fact(aggregate, "payment_id", ""));
  if (!hadAttempt) {
    const result = await aggregate.execute({ name: "save_payment", args: { payment_id: PAYMENT_ID(), snapshot_request_id: fact(aggregate, "request_id"), snapshot_freelancer_id: fact(aggregate, "freelancer_id"), snapshot_period_id: fact(aggregate, "period_id"), snapshot_amount_cents: fact(aggregate, "approved_cents") } }, { operationId: opId(ctx.kernel) });
    aggregate = unwrap(result) ?? aggregate; afterCrash("after-payment-saved-before-request");
  }
  if (!hadAttempt) {
    const posted = await postSaved(env, aggregate);
    if (posted.transport || posted.malformed || !posted.response) return error("service_unavailable");
    if (posted.response.status === 409) return error("lookup_conflict");
    if (posted.response.status >= 500) return error("service_unavailable");
    if (posted.response.status !== 200 || !matchesPayment(posted.body, aggregate)) return error("lookup_conflict");
    afterCrash("after-accept-before-record"); aggregate = await recordPaid(ctx, aggregate); afterCrash("after-record-before-exit"); return successPayment(aggregate);
  }
  const found = await lookupSaved(env, aggregate);
  if (found.transport || found.malformed || !found.response) return error("service_unavailable");
  if (found.response.status === 200) {
    if (!matchesPayment(found.body, aggregate)) return error("lookup_conflict");
    afterCrash("after-accept-before-record"); aggregate = await recordPaid(ctx, aggregate); afterCrash("after-record-before-exit"); return successPayment(aggregate);
  }
  if (found.response.status !== 404) return error("service_unavailable");
  const posted = await postSaved(env, aggregate);
  if (posted.transport || posted.malformed || !posted.response) return error("service_unavailable");
  if (posted.response.status === 409) return error("lookup_conflict");
  if (posted.response.status >= 500) return error("service_unavailable");
  if (posted.response.status !== 200 || !matchesPayment(posted.body, aggregate)) return error("lookup_conflict");
  afterCrash("after-accept-before-record"); aggregate = await recordPaid(ctx, aggregate); afterCrash("after-record-before-exit"); return successPayment(aggregate);
}
async function reconcile(ctx, env, payment) {
  const aggregate = await requireAggregate(ctx);
  if (!aggregate || !fact(aggregate, "payment_id", "")) return error("no_payment");
  if (payment !== fact(aggregate, "payment_id")) return error("payment_mismatch");
  if (stateOf(aggregate) === "paid") return { ...successPayment(aggregate), lookup: "paid" };
  const found = await lookupSaved(env, aggregate);
  if (found.transport || found.malformed || !found.response) return error("service_unavailable");
  if (found.response.status === 404) return { lookup: "not_sent", request_id: fact(aggregate, "request_id"), payment_id: fact(aggregate, "payment_id"), payment: "attempt_saved", status: "approved" };
  if (found.response.status !== 200) return error("service_unavailable");
  if (!matchesPayment(found.body, aggregate)) return error("lookup_conflict");
  const paid = await recordPaid(ctx, aggregate); afterCrash("after-record-before-exit"); return { ...successPayment(paid), lookup: "paid" };
}
function statusShape(aggregate) { return aggregate ? current(aggregate) : { freelancer_id: null, period_id: null, cap_cents: null, request_id: null, requested_cents: null, approved_cents: null, manager_id: null, second_manager_id: null, memo: null, status: "none", payment: "none", payment_id: null }; }
async function command(argv, env) {
  if (!ensureService(env)) return error("missing_service_url");
  const name = argv[0]; const ctx = await context(env);
  if (name === "status") return statusShape(await loadAggregate(ctx));
  if (name === "open") {
    if (argv.length !== 4 || !validId(argv[1]) || !validId(argv[2])) return error("bad_args");
    const cap = amount(argv[3]); if (cap === null) return error("bad_amount");
    if (await loadAggregate(ctx)) return error("already_open");
    const created = await ctx.machine.create("desk");
    await created.execute({ name: "open", args: { freelancer_id: argv[1], period_id: argv[2], cap_cents: cap, paid_total_cents: 0 } }, { operationId: opId(ctx.kernel) });
    return { freelancer_id: argv[1], period_id: argv[2], cap_cents: cap, request_id: null, status: "none", payment: "none" };
  }
  const aggregate = await requireAggregate(ctx);
  if (name === "callback") {
    if (argv.length !== 2) return error("bad_callback"); const path = resolve(argv[1]); const rel = relative(ctx.stateDir, path);
    if (rel.startsWith("..") || rel.includes(".." + "/")) return error("bad_callback");
    try { const parsed = JSON.parse(await readFile(path, "utf8")); if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return error("bad_callback"); return { callback: "ignored" }; } catch { return error("bad_callback"); }
  }
  if (name === "submit") {
    if (!aggregate) return error("no_request"); const state = stateOf(aggregate); if (!["none", "paid", "rejected", "cancelled"].includes(state)) return error("request_exists");
    if (argv.length < 2 || argv.length > 3) return error("bad_args"); const cents = amount(argv[1]); if (cents === null) return error("bad_amount");
    const cap = Number(fact(aggregate, "cap_cents", 0)); const total = Number(fact(aggregate, "paid_total_cents", 0)); if (total + cents > cap) return error("over_cap");
    const memo = argv.length === 3 ? argv[2] : ""; if (!validMemo(memo)) return error("bad_args");
    const result = await aggregate.execute({ name: "submit", args: { request_id: REQUEST_ID(), amount_cents: cents, memo, clear_manager_id: "", clear_second_manager_id: "", clear_reject_reason: "", empty_payment_id: "", empty_payment_request_id: "", empty_payment_freelancer_id: "", empty_payment_period_id: "", paid_total_cents: total } }, { operationId: opId(ctx.kernel) });
    const next = unwrap(result) ?? aggregate; return { request_id: fact(next, "request_id"), freelancer_id: fact(next, "freelancer_id"), period_id: fact(next, "period_id"), requested_cents: cents, approved_cents: 0, memo, status: "submitted", payment: "none", payment_id: null };
  }
  if (name === "approve") {
    if (!aggregate) return error("no_request"); if (argv.length < 3 || argv.length > 4 || !validId(argv[2])) return error("bad_args");
    const req = fact(aggregate, "request_id", ""); if (argv[1] !== req) return error("request_mismatch"); const state = stateOf(aggregate);
    if (state !== "submitted") return state === "approved" ? error("already_approved") : error("bad_status");
    const approved = argv.length === 4 ? amount(argv[3]) : Number(fact(aggregate, "requested_cents", 0)); if (approved === null) return error("bad_amount");
    if (approved > Number(fact(aggregate, "requested_cents", 0))) return error("bad_amount"); if (Number(fact(aggregate, "paid_total_cents", 0)) + approved > Number(fact(aggregate, "cap_cents", 0))) return error("over_cap");
    if (fact(aggregate, "manager_id", "") === argv[2]) return error("already_approved");
    const commandName = approved > 50000 ? "approve_high" : "approve";
    const result = await aggregate.execute({ name: commandName, args: { request_id: argv[1], manager_id: argv[2], approved_cents: approved } }, { operationId: opId(ctx.kernel) }); const next = unwrap(result) ?? aggregate;
    const status = approved > 50000 ? "awaiting_second" : "approved";
    return { request_id: req, approved_cents: approved, manager_id: argv[2], status, payment: "none", payment_id: null };
  }
  if (name === "approve-second") {
    if (!aggregate) return error("no_request"); if (argv.length !== 3 || !validId(argv[2])) return error("bad_args");
    const req = fact(aggregate, "request_id", ""); if (argv[1] !== req) return error("request_mismatch");
    const state = stateOf(aggregate);
    if (state === "approved") {
      if (fact(aggregate, "second_manager_id", "") === argv[2]) return { request_id: req, approved_cents: fact(aggregate, "approved_cents"), manager_id: fact(aggregate, "manager_id"), status: "approved", payment: paymentState(aggregate), payment_id: paymentIdFor(aggregate) };
      return error("bad_status");
    }
    if (state !== "awaiting_second") return error("bad_status");
    if (fact(aggregate, "manager_id", "") === argv[2]) return error("duplicate_manager");
    const result = await aggregate.execute({ name: "approve_second", args: { request_id: req, manager_id: argv[2] } }, { operationId: opId(ctx.kernel) }); const next = unwrap(result) ?? aggregate;
    return { request_id: req, approved_cents: fact(next, "approved_cents"), manager_id: fact(next, "manager_id"), status: "approved", payment: "none", payment_id: null };
  }
  if (name === "reject") {
    if (!aggregate || argv.length > 3 || argv.length < 2) return aggregate ? error("bad_args") : error("no_request"); if (argv[1] !== fact(aggregate, "request_id", "")) return error("request_mismatch"); if (stateOf(aggregate) !== "submitted") return error("bad_status");
    const reason = argv.length === 3 ? argv[2] : ""; if (!validMemo(reason)) return error("bad_args"); await aggregate.execute({ name: "reject", args: { request_id: argv[1], reason } }, { operationId: opId(ctx.kernel) }); return { request_id: argv[1], status: "rejected", payment: "none" };
  }
  if (name === "cancel") {
    if (!aggregate) return error("no_request"); if (argv.length !== 2 || !validId(argv[1])) return error("bad_args"); if (argv[1] !== fact(aggregate, "request_id", "")) return error("request_mismatch");
    const state = stateOf(aggregate); if (!["submitted", "awaiting_second", "approved"].includes(state)) return error("bad_status");
    if (fact(aggregate, "payment_id", "")) return error("payment_started");
    await aggregate.execute({ name: "cancel", args: { request_id: argv[1], clear_manager_id: "", clear_second_manager_id: "", clear_approved_cents: 0 } }, { operationId: opId(ctx.kernel) }); return { request_id: argv[1], status: "cancelled", payment: "none" };
  }
  if (name === "pay" || name === "apply") return pay(ctx, env);
  if (name === "reconcile") { if (argv.length !== 2 || !validId(argv[1])) return error("bad_args"); return reconcile(ctx, env, argv[1]); }
  return error("bad_args");
}
async function main() { let result; try { result = await command(process.argv.slice(2), process.env); } catch (err) { result = isCorrupt(err) ? error("corrupt_state") : error("service_unavailable"); } process.stdout.write(`${JSON.stringify(result)}\n`); if (result?.error) process.exitCode = 1; }
main();
