# Freelancer payout desk

`./run` is a single-process durable payout desk for one freelancer and accounting
period. The lifecycle state is persisted by the installed Ikaros runtime in
`STATE_DIR/.payout-desk.sqlite`; no other files in `STATE_DIR` are read or
rewritten. The provider URL is supplied by `SERVICE_URL` for every invocation.

## Setup

Node 22 is required. From this directory, install the supplied offline packages:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

The launcher uses `node` from `PATH` (the qualification environment provides
Node 22). `SERVICE_URL` is required even for `status`; `status` itself never
contacts the service.

## Commands

```sh
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50000 ./run open freelancer period 100000
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50000 ./run submit 12500 "April work"
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50000 ./run status
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50000 ./run approve REQUEST_ID manager 10000
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50000 ./run pay
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50000 ./run reconcile PAYMENT_ID
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50000 ./run callback /path/to/state/callback.json
```

Approvals above 50000 cents enter `awaiting_second` and require a distinct
manager:

```sh
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50000 ./run approve REQUEST_ID manager 60000
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50000 ./run approve-second REQUEST_ID second-manager
```

`cancel` is allowed for submitted, awaiting-second, and approved requests until
a payment attempt is saved; it releases the approval reservation and clears
approval fields. After an attempt is saved it returns `payment_started`.
```

`apply` is an alias for `pay`. Every invocation emits one JSON object. Refusals
emit `{ "error": "<code>" }` and exit nonzero. Payment IDs are durably saved
before the POST, so a process killed with `CRASH_AT=after-payment-saved-before-request`
can be resumed by `pay`. The other supported crash labels are
`after-accept-before-record` and `after-record-before-exit`.

Run the focused restart, crash-label, provider-deduplication, dropped-reply,
reconcile, and callback tests with:

```sh
npm test
```

## Ikaros checks

The authoritative lifecycle declaration is `payout_desk.ik.toml`. Inspect its
identity and run the developer check with:

```sh
node_modules/@ikaros/darwin-arm64/bin/ik identity payout_desk.ik.toml
node_modules/@ikaros/darwin-arm64/bin/ik laws payout_desk.ik.toml
node_modules/@ikaros/darwin-arm64/bin/ik check payout_desk.ik.toml
```
The last command is corpus-relative; the checked-in corpus covers the lifecycle
witnesses but does not claim exhaustive or unexamined-law proof.
