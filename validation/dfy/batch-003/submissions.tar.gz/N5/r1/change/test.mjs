import assert from "node:assert/strict";
import { createServer } from "node:http";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawn } from "node:child_process";

const effects = new Map();
const posts = [];
let dropReply = false;
const server = createServer(async (req, res) => {
  const url = new URL(req.url, "http://127.0.0.1");
  if (req.method === "GET" && url.pathname.startsWith("/v1/payments/")) {
    const payment = effects.get(decodeURIComponent(url.pathname.slice("/v1/payments/".length)));
    if (!payment) { res.writeHead(404); res.end(JSON.stringify({ error: "not_found" })); return; }
    res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify(payment)); return;
  }
  if (req.method === "POST" && url.pathname === "/v1/payouts") {
    const chunks = []; for await (const chunk of req) chunks.push(chunk);
    const body = JSON.parse(Buffer.concat(chunks).toString());
    const old = effects.get(body.payment_id);
    if (old && JSON.stringify(old) !== JSON.stringify({ ...body, outcome: "paid" })) { res.writeHead(409); res.end(); return; }
    const saved = old ?? { ...body, outcome: "paid" }; effects.set(body.payment_id, saved); posts.push(body);
    if (dropReply) { req.socket.destroy(); return; }
    res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify(saved)); return;
  }
  res.writeHead(404); res.end();
});
await new Promise((resolve) => server.listen(50500, "127.0.0.1", resolve));
const service = "http://127.0.0.1:50500";
function invoke(dir, args, extra = {}) {
  return new Promise((resolve) => {
    const child = spawn("./run", args, { cwd: process.cwd(), env: { ...process.env, STATE_DIR: dir, SERVICE_URL: service, ...extra } });
    const stdout = []; const stderr = [];
    child.stdout.on("data", (chunk) => stdout.push(chunk)); child.stderr.on("data", (chunk) => stderr.push(chunk));
    child.on("close", (status, signal) => {
      let value = null; try { value = JSON.parse(Buffer.concat(stdout)); } catch { /* crash labels have no JSON */ }
      resolve({ status: status ?? (signal === "SIGKILL" ? 137 : 1), signal, value, stderr: Buffer.concat(stderr).toString() });
    });
  });
}
async function setup(dir) {
  assert.equal((await invoke(dir, ["open", "alice", "period", "10000"])).status, 0);
  const submitted = await invoke(dir, ["submit", "1500"]); assert.equal(submitted.status, 0);
  const request = submitted.value.request_id;
  assert.equal((await invoke(dir, ["approve", request, "manager"])).status, 0);
  return request;
}
const base = await mkdtemp(join(tmpdir(), "payout-test-"));
try {
  const normal = join(base, "normal"); const request = await setup(normal);
  assert.equal((await invoke(normal, ["pay"])).value.status, "paid");
  assert.equal((await invoke(normal, ["pay"])).value.status, "paid");
  assert.equal(effects.size, 1); assert.equal(posts.length, 1);

  effects.clear(); posts.length = 0;
  const beforePost = join(base, "before-post"); const beforeRequest = await setup(beforePost);
  const crashed = await invoke(beforePost, ["pay"], { CRASH_AT: "after-payment-saved-before-request" });
  assert.equal(crashed.status, 137);
  const saved = (await invoke(beforePost, ["status"])).value; assert.equal(saved.payment, "attempt_saved"); assert.equal(effects.size, 0);
  assert.equal((await invoke(beforePost, ["cancel", beforeRequest])).value.error, "payment_started");
  assert.equal((await invoke(beforePost, ["pay"])).value.status, "paid"); assert.equal(posts[0].request_id, beforeRequest); assert.equal(effects.size, 1);

  effects.clear(); posts.length = 0;
  const afterAcceptance = join(base, "after-accept"); await setup(afterAcceptance);
  assert.equal((await invoke(afterAcceptance, ["pay"], { CRASH_AT: "after-accept-before-record" })).status, 137);
  assert.equal((await invoke(afterAcceptance, ["status"])).value.payment, "attempt_saved"); assert.equal(effects.size, 1);
  assert.equal((await invoke(afterAcceptance, ["pay"])).value.status, "paid"); assert.equal(posts.length, 1);

  effects.clear(); posts.length = 0;
  const afterRecord = join(base, "after-record"); await setup(afterRecord);
  assert.equal((await invoke(afterRecord, ["pay"], { CRASH_AT: "after-record-before-exit" })).status, 137);
  assert.equal((await invoke(afterRecord, ["status"])).value.status, "paid"); assert.equal(effects.size, 1);
  assert.equal((await invoke(afterRecord, ["pay"])).value.status, "paid"); assert.equal(posts.length, 1);

  effects.clear(); posts.length = 0;
  const dropped = join(base, "dropped"); await setup(dropped); dropReply = true;
  assert.equal((await invoke(dropped, ["pay"])).value.error, "service_unavailable"); dropReply = false;
  const droppedStatus = (await invoke(dropped, ["status"])).value; assert.equal(droppedStatus.payment, "attempt_saved");
  assert.equal((await invoke(dropped, ["reconcile", droppedStatus.payment_id])).value.lookup, "paid"); assert.equal(posts.length, 1);

  effects.clear(); posts.length = 0;
  const threshold = join(base, "threshold");
  assert.equal((await invoke(threshold, ["open", "alice", "period", "100000"])).status, 0);
  const high = await invoke(threshold, ["submit", "60000"]); const highRequest = high.value.request_id;
  assert.equal((await invoke(threshold, ["approve", highRequest, "first"])).value.status, "awaiting_second");
  assert.equal((await invoke(threshold, ["pay"])).value.error, "not_approved");
  assert.equal((await invoke(threshold, ["approve-second", highRequest, "first"])).value.error, "duplicate_manager");
  assert.equal((await invoke(threshold, ["approve-second", highRequest, "second"])).value.status, "approved");
  assert.equal((await invoke(threshold, ["pay"])).value.status, "paid"); assert.equal(posts.length, 1);

  effects.clear(); posts.length = 0;
  const cancelled = join(base, "cancelled");
  assert.equal((await invoke(cancelled, ["open", "alice", "period", "100000"])).status, 0);
  const cancelledSubmission = await invoke(cancelled, ["submit", "60000"]); const cancelledRequest = cancelledSubmission.value.request_id;
  assert.equal((await invoke(cancelled, ["approve", cancelledRequest, "first"])).value.status, "awaiting_second");
  assert.deepEqual((await invoke(cancelled, ["cancel", cancelledRequest])).value, { request_id: cancelledRequest, status: "cancelled", payment: "none" });
  assert.equal((await invoke(cancelled, ["pay"])).value.error, "not_approved"); assert.equal(posts.length, 0);
  const cancelledStatus = (await invoke(cancelled, ["status"])).value;
  assert.equal(cancelledStatus.approved_cents, 0); assert.equal(cancelledStatus.manager_id, null); assert.equal(cancelledStatus.second_manager_id, null);

  const callback = join(normal, "callback.json"); await writeFile(callback, "{\"payment_id\":\"foreign\"}\n");
  assert.equal((await invoke(normal, ["callback", callback])).value.callback, "ignored");
  assert.equal((await invoke(normal, ["status"])).value.request_id, request);
  console.log("lifecycle tests passed");
} finally { await rm(base, { recursive: true, force: true }); server.close(); }
