import { randomUUID } from "node:crypto";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { Kernel, HistoricalResult, KernelError, TransportError } from "@ikaros/runtime";

const ROOT = dirname(fileURLToPath(import.meta.url));
const MACHINE_PATH = join(ROOT, "hold.ik.toml");
const LEGACY_MACHINE_PATH = join(ROOT, "hold.v1.ik.toml");
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const SEAT_RE = /^[A-Za-z0-9._-]{1,32}$/;
const DECIMAL_RE = /^(?:0|[1-9][0-9]*)$/;
const MAX_SAFE = BigInt(Number.MAX_SAFE_INTEGER);
const MAX_DEADLINE = 9007199254740991n;
const INDEX_FILE = "desk.json";

function jsonValue(value) {
  if (typeof value === "bigint") return value <= MAX_SAFE ? Number(value) : value.toString();
  if (Array.isArray(value)) return value.map(jsonValue);
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, jsonValue(v)]));
  return value;
}

function output(value, code = 0) {
  process.stdout.write(JSON.stringify(jsonValue(value)) + "\n");
  process.exitCode = code;
}

function refusal(error) {
  output({ error }, 1);
}

function requireStateDir() {
  if (!process.env.STATE_DIR) throw new Error("missing_state_dir");
  return resolve(process.env.STATE_DIR);
}

function parseDecimal(value, error, max) {
  if (typeof value !== "string" || !DECIMAL_RE.test(value)) throw new UserError(error);
  const n = BigInt(value);
  if (n > max) throw new UserError(error);
  return n;
}

function validateId(value) {
  if (!ID_RE.test(value)) throw new UserError("bad_id");
}

function validateSeat(value) {
  if (!SEAT_RE.test(value)) throw new UserError("bad_id");
}

class UserError extends Error {}

function parseArgs(argv) {
  const [command, ...args] = argv;
  const arity = {
    section: 2,
    issue: 1,
    release: 1,
    expire: 1,
    status: 1,
    "section-status": 1,
    reconcile: 1,
  };
  if (command === "hold") {
    if (args.length < 4) throw new UserError("bad_args");
    validateId(args[0]);
    validateId(args[1]);
    const deadline = parseDecimal(args.at(-1), "bad_deadline", MAX_DEADLINE);
    const seatIds = args.slice(2, -1);
    if (seatIds.length === 0) throw new UserError("bad_args");
    for (const seatId of seatIds) validateSeat(seatId);
    if (new Set(seatIds).size !== seatIds.length) throw new UserError("bad_args");
    return {
      command,
      holdId: args[0],
      sectionId: args[1],
      seatIds: [...seatIds].sort(),
      deadline,
    };
  }
  if (command === "release") {
    if (args.length < 1) throw new UserError("bad_args");
    validateId(args[0]);
    const seatIds = args.slice(1);
    for (const seatId of seatIds) validateSeat(seatId);
    if (new Set(seatIds).size !== seatIds.length) throw new UserError("bad_args");
    return { command, holdId: args[0], seatIds };
  }
  if (!arity[command] || args.length !== arity[command]) throw new UserError("bad_args");
  if (command === "section") {
    validateId(args[0]);
    const capacity = parseDecimal(args[1], "bad_capacity", 100000n);
    if (capacity < 1n) throw new UserError("bad_capacity");
    return { command, sectionId: args[0], capacity };
  }
  validateId(args[0]);
  return { command, holdId: args[0] };
}

function nowMs(required = true) {
  if (process.env.NOW_MS === undefined) {
    if (required) throw new UserError("bad_deadline");
    return null;
  }
  return parseDecimal(process.env.NOW_MS, "bad_deadline", MAX_DEADLINE);
}

async function loadIndex(stateDir) {
  try {
    const text = await readFile(join(stateDir, INDEX_FILE), "utf8");
    const value = JSON.parse(text);
    if (!value || typeof value !== "object" || !value.sections || !value.holds) throw new Error("invalid desk index");
    return value;
  } catch (error) {
    if (error.code === "ENOENT") return { version: 1, sections: {}, holds: {} };
    throw error;
  }
}

async function saveIndex(stateDir, index) {
  const temporary = join(stateDir, `.${INDEX_FILE}.${process.pid}.tmp`);
  await writeFile(temporary, JSON.stringify(index, null, 2) + "\n", { mode: 0o600 });
  await rename(temporary, join(stateDir, INDEX_FILE));
}

async function ensureState() {
  const stateDir = requireStateDir();
  await mkdir(stateDir, { recursive: true });
  return { stateDir, index: await loadIndex(stateDir) };
}

function seatIdsOf(record) {
  if (Array.isArray(record?.seat_ids)) return [...record.seat_ids];
  if (typeof record?.seat_id === "string") return [record.seat_id];
  return [];
}

function allSeatIdsOf(record) {
  if (Array.isArray(record?.all_seat_ids)) return [...record.all_seat_ids];
  return seatIdsOf(record);
}
function holdFromAggregate(holdId, aggregate, record = null) {
  const state = aggregate.state;
  const deadline = state.deadline_ms;
  let seatIds = record ? seatIdsOf(record) : [];
  if (activeState(state.state) && typeof state.seat_ids_json === "string") {
    try { seatIds = JSON.parse(state.seat_ids_json); } catch { seatIds = []; }
  }
  if (seatIds.length === 0 && typeof state.seat_id === "string") seatIds = [state.seat_id];
  return {
    hold_id: holdId,
    section_id: state.section_id,
    seat_ids: seatIds,
    deadline_ms: jsonValue(deadline),
    state: state.state,
    request_id: state.request_id ?? null,
    ticket_id: state.ticket_id ?? null,
  };
}

function activeState(state) {
  return state === "held" || state === "attempt_saved" || state === "ticketed";
}
function indexRecord(holdId, value, state = "active", previous = null) {
  const seatIds = seatIdsOf(value);
  const allSeatIds = allSeatIdsOf(previous ?? value);
  return {
    hold_id: holdId,
    section_id: value.section_id,
    seat_id: previous?.seat_id ?? allSeatIds[0] ?? seatIds[0] ?? null,
    seat_ids: seatIds,
    all_seat_ids: allSeatIds,
    machine_version: previous && !Object.hasOwn(previous, "machine_version") ? 1 : (previous?.machine_version ?? value.machine_version ?? 2),
    deadline_ms: String(value.deadline_ms),
    state,
  };
}

function kernelFor(stateDir) {
  return new Kernel(join(stateDir, "holds.sqlite"));
}

async function machineFor(stateDir, machineVersion = 2) {
  const kernel = kernelFor(stateDir);
  return { kernel, machine: await kernel.machine(machineVersion === 1 ? LEGACY_MACHINE_PATH : MACHINE_PATH) };
}

async function showHold(stateDir, holdId, record = null) {
  const { machine } = await machineFor(stateDir, record?.machine_version ?? 1);
  try {
    return await machine.show(holdId);
  } catch (error) {
    if (error instanceof KernelError) throw new UserError("unknown_hold");
    throw error;
  }
}

async function refreshIndex(stateDir, index) {
  let changed = false;
  for (const [holdId, record] of Object.entries(index.holds)) {
    try {
      const aggregate = await showHold(stateDir, holdId, record);
      const current = holdFromAggregate(holdId, aggregate, record);
      const nextState = activeState(current.state) ? "active" : current.state;
      const next = indexRecord(holdId, current, nextState, record);
      if (JSON.stringify(record) !== JSON.stringify(next)) { index.holds[holdId] = next; changed = true; }
    } catch (error) {
      if (error instanceof UserError && error.message === "unknown_hold" && record.state === "pending") {
        delete index.holds[holdId]; changed = true;
      }
    }
  }
  if (changed) await saveIndex(stateDir, index);
  return index;
}

async function command(aggregate, name, args = undefined) {
  const commandBody = args === undefined ? { name } : { name, args };
  try {
    const result = await aggregate.execute(commandBody);
    if (result instanceof HistoricalResult) return await aggregate.machine.show(aggregate.id);
    return result;
  } catch (error) {
    if (error instanceof TransportError) throw new UserError("unavailable");
    throw error;
  }
}

async function maybeExpire(stateDir, index, holdId, aggregate, current) {
  if (current.state !== "held") return aggregate;
  const now = nowMs(true);
  const deadline = BigInt(current.deadline_ms);
  if (now < deadline) return aggregate;
  try {
    const expired = await command(aggregate, "expire", { now_ms: now });
    const value = { ...holdFromAggregate(holdId, expired, index.holds[holdId]), seat_ids: [] };
    index.holds[holdId] = indexRecord(holdId, value, "expired", index.holds[holdId]);
    await saveIndex(stateDir, index);
    return expired;
  } catch (error) {
    if (error instanceof KernelError) throw new UserError("unavailable");
    throw error;
  }
}

function crashAt(name) {
  if (process.env.CRASH_AT === name) process.kill(process.pid, "SIGKILL");
}

function serviceUrl() {
  if (!process.env.SERVICE_URL) throw new UserError("unavailable");
  try { return new URL(process.env.SERVICE_URL); } catch { throw new UserError("unavailable"); }
}

async function providerRequest(url, method, requestId, body = null) {
  const endpoint = new URL(`v1/tickets/${encodeURIComponent(requestId)}`, url);
  if (method === "POST") endpoint.pathname = "/v1/tickets";
  try {
    const response = await fetch(endpoint, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    let payload;
    try { payload = await response.json(); } catch { throw new UserError("unavailable"); }
    return { status: response.status, payload };
  } catch (error) {
    if (error instanceof UserError) throw error;
    throw new UserError("unavailable");
  }
}

function sameSeatSet(left, right) {
  return Array.isArray(left) && Array.isArray(right) &&
    left.length === right.length &&
    new Set(left).size === left.length &&
    new Set(right).size === right.length &&
    left.every((seatId) => right.includes(seatId));
}

function matchingTicket(payload, hold) {
  return payload &&
    payload.request_id === hold.request_id &&
    payload.hold_id === hold.hold_id &&
    payload.section_id === hold.section_id &&
    sameSeatSet(payload.seat_ids, hold.seat_ids) &&
    typeof payload.ticket_id === "string" &&
    payload.outcome === "ticketed";
}

async function recordTicket(stateDir, index, aggregate, holdId, ticketId, crashAfterRecord) {
  const recorded = await command(aggregate, "record_ticket", { ticket_id: ticketId });
  const value = holdFromAggregate(holdId, recorded, index.holds[holdId]);
  index.holds[holdId] = indexRecord(holdId, value, "ticketed", index.holds[holdId]);
  await saveIndex(stateDir, index);
  if (crashAfterRecord) crashAt("after-record-before-exit");
  return holdFromAggregate(holdId, recorded, index.holds[holdId]);
}

async function issue(stateDir, index, holdId) {
  let aggregate = await showHold(stateDir, holdId, index.holds[holdId]);
  let value = holdFromAggregate(holdId, aggregate, index.holds[holdId]);
  aggregate = await maybeExpire(stateDir, index, holdId, aggregate, value);
  value = holdFromAggregate(holdId, aggregate, index.holds[holdId]);
  if (value.state === "ticketed") return value;
  if (value.state === "expired") throw new UserError("expired");
  if (value.state === "released") throw new UserError("released");
  let newAttempt = false;
  if (value.state === "held") {
    const requestId = randomUUID();
    aggregate = await command(aggregate, "save_attempt", { request_id: requestId });
    value = holdFromAggregate(holdId, aggregate, index.holds[holdId]);
    index.holds[holdId] = indexRecord(holdId, value, "active", index.holds[holdId]);
    await saveIndex(stateDir, index);
    newAttempt = true;
    crashAt("after-hold-saved-before-request");
  }
  if (value.state !== "attempt_saved") throw new UserError("release_open");
  const url = serviceUrl();
  const body = { request_id: value.request_id, hold_id: value.hold_id, section_id: value.section_id, seat_ids: value.seat_ids };
  let ticket;
  if (newAttempt) {
    const posted = await providerRequest(url, "POST", value.request_id, body);
    if (posted.status === 409) throw new UserError("conflict");
    if (posted.status !== 200 || !matchingTicket(posted.payload, value)) throw new UserError(posted.status === 200 ? "conflict" : "unavailable");
    ticket = posted.payload;
    crashAt("after-accept-before-record");
  } else {
    const lookup = await providerRequest(url, "GET", value.request_id);
    if (lookup.status === 200) {
      if (!matchingTicket(lookup.payload, value)) throw new UserError("conflict");
      ticket = lookup.payload;
    } else if (lookup.status === 404) {
      const posted = await providerRequest(url, "POST", value.request_id, body);
      if (posted.status === 409) throw new UserError("conflict");
      if (posted.status !== 200 || !matchingTicket(posted.payload, value)) throw new UserError(posted.status === 200 ? "conflict" : "unavailable");
      ticket = posted.payload;
      crashAt("after-accept-before-record");
    } else {
      throw new UserError("unavailable");
    }
  }
  return await recordTicket(stateDir, index, aggregate, holdId, ticket.ticket_id, true);
}

async function reconcile(stateDir, index, holdId) {
  const aggregate = await showHold(stateDir, holdId, index.holds[holdId]);
  let value = holdFromAggregate(holdId, aggregate, index.holds[holdId]);
  if (value.state !== "attempt_saved") return { outcome: "not_applicable" };
  const response = await providerRequest(serviceUrl(), "GET", value.request_id);
  if (response.status === 404) return { outcome: "not_sent" };
  if (response.status !== 200) throw new UserError("unavailable");
  if (!matchingTicket(response.payload, value)) throw new UserError("conflict");
  value = await recordTicket(stateDir, index, aggregate, holdId, response.payload.ticket_id, false);
  return { outcome: "ticketed", ...value };
}

async function createSection(stateDir, index, sectionId, capacity) {
  const existing = index.sections[sectionId];
  if (existing) {
    if (BigInt(existing.capacity) !== capacity) throw new UserError("conflict");
  } else {
    index.sections[sectionId] = { section_id: sectionId, capacity: String(capacity) };
    await saveIndex(stateDir, index);
  }
  return sectionStatus(index, sectionId);
}

function sectionStatus(index, sectionId) {
  const section = index.sections[sectionId];
  if (!section) throw new UserError("unknown_section");
  const held = Object.values(index.holds)
    .filter((h) => h.section_id === sectionId && h.state === "active")
    .reduce((count, hold) => count + seatIdsOf(hold).length, 0);
  const capacity = BigInt(section.capacity);
  return { section_id: sectionId, capacity, held, available: capacity - BigInt(held) };
}

async function createHold(stateDir, index, input) {
  const existing = index.holds[input.holdId];
  if (existing) {
    const existingSeats = seatIdsOf(existing).sort();
    if (existing.section_id !== input.sectionId ||
        existingSeats.length !== input.seatIds.length ||
        existingSeats.some((seatId, index) => seatId !== input.seatIds[index]) ||
        BigInt(existing.deadline_ms) !== input.deadline) {
      throw new UserError("conflict");
    }
    const aggregate = await showHold(stateDir, input.holdId, existing);
    const refreshed = await maybeExpire(
      stateDir,
      index,
      input.holdId,
      aggregate,
      holdFromAggregate(input.holdId, aggregate, existing),
    );
    return holdFromAggregate(input.holdId, refreshed, index.holds[input.holdId]);
  }
  if (!index.sections[input.sectionId]) throw new UserError("unknown_section");
  for (const hold of Object.values(index.holds)) {
    if (hold.section_id !== input.sectionId || hold.state !== "active") continue;
    if (input.seatIds.some((seatId) => seatIdsOf(hold).includes(seatId))) {
      throw new UserError("seat_taken");
    }
  }
  const section = sectionStatus(index, input.sectionId);
  if (BigInt(section.available) < BigInt(input.seatIds.length)) throw new UserError("capacity_exceeded");
  const pending = {
    hold_id: input.holdId,
    section_id: input.sectionId,
    seat_ids: [...input.seatIds],
    all_seat_ids: [...input.seatIds],
    machine_version: 2,
    seat_id: input.seatIds[0],
    deadline_ms: String(input.deadline),
    state: "pending",
  };
  index.holds[input.holdId] = pending;
  await saveIndex(stateDir, index);
  const { machine } = await machineFor(stateDir);
  let aggregate;
  try {
    aggregate = await machine.createWith({
      aggregateId: input.holdId,
      command: {
        name: "initialize",
        args: { section_id: input.sectionId, seat_ids_json: JSON.stringify(input.seatIds), deadline_ms: input.deadline },
      },
    });
    if (aggregate instanceof HistoricalResult) aggregate = await machine.show(input.holdId);
  } catch (error) {
    try {
      aggregate = await machine.show(input.holdId);
    } catch {
      delete index.holds[input.holdId];
      await saveIndex(stateDir, index);
      throw error;
    }
  }
  const value = holdFromAggregate(input.holdId, aggregate, pending);
  index.holds[input.holdId] = indexRecord(input.holdId, value, "active", pending);
  await saveIndex(stateDir, index);
  return holdFromAggregate(input.holdId, aggregate, index.holds[input.holdId]);
}

async function release(stateDir, index, holdId, requestedSeats) {
  let aggregate = await showHold(stateDir, holdId, index.holds[holdId]);
  let value = holdFromAggregate(holdId, aggregate, index.holds[holdId]);
  aggregate = await maybeExpire(stateDir, index, holdId, aggregate, value);
  value = holdFromAggregate(holdId, aggregate, index.holds[holdId]);
  const record = index.holds[holdId];
  const allSeats = allSeatIdsOf(record);
  const currentSeats = seatIdsOf(record);
  if (requestedSeats.length === 0) {
    if (value.state === "released" || value.state === "expired") return value;
    if (value.state !== "held") throw new UserError("release_open");
    aggregate = await command(aggregate, "release");
    value = holdFromAggregate(holdId, aggregate, record);
    index.holds[holdId] = indexRecord(holdId, { ...value, seat_ids: [] }, "released", record);
    await saveIndex(stateDir, index);
    return holdFromAggregate(holdId, aggregate, index.holds[holdId]);
  }
  if (value.state === "attempt_saved" || value.state === "ticketed") throw new UserError("release_open");
  for (const seatId of requestedSeats) {
    if (!allSeats.includes(seatId)) throw new UserError("unknown_seat");
    if (!currentSeats.includes(seatId)) throw new UserError("already_released");
  }
  if (value.state !== "held") {
    if (value.state === "released" || value.state === "expired") throw new UserError("already_released");
    throw new UserError("release_open");
  }
  if (requestedSeats.length === currentSeats.length && currentSeats.length === allSeats.length) {
    throw new UserError("bad_args");
  }
  const remainingSeats = currentSeats.filter((seatId) => !requestedSeats.includes(seatId));
  if (remainingSeats.length > 0) {
    if (record.machine_version === 2) {
      aggregate = await command(aggregate, "set_seats", { seat_ids_json: JSON.stringify(remainingSeats) });
    }
    const next = { ...value, seat_ids: remainingSeats };
    index.holds[holdId] = indexRecord(holdId, next, "active", record);
    await saveIndex(stateDir, index);
    return next;
  }
  aggregate = await command(aggregate, "release");
  value = holdFromAggregate(holdId, aggregate, record);
  index.holds[holdId] = indexRecord(holdId, { ...value, seat_ids: [] }, "released", record);
  await saveIndex(stateDir, index);
  return holdFromAggregate(holdId, aggregate, index.holds[holdId]);
}

async function expire(stateDir, index, holdId) {
  let aggregate = await showHold(stateDir, holdId, index.holds[holdId]);
  let value = holdFromAggregate(holdId, aggregate, index.holds[holdId]);
  if (value.state === "released" || value.state === "expired") return value;
  if (value.state !== "held") throw new UserError("release_open");
  const now = nowMs(true);
  if (now < BigInt(value.deadline_ms)) throw new UserError("not_due");
  aggregate = await command(aggregate, "expire", { now_ms: now });
  value = holdFromAggregate(holdId, aggregate, index.holds[holdId]);
  index.holds[holdId] = indexRecord(holdId, { ...value, seat_ids: [] }, "expired", index.holds[holdId]);
  await saveIndex(stateDir, index);
  return holdFromAggregate(holdId, aggregate, index.holds[holdId]);
}

async function status(stateDir, index, holdId) {
  let aggregate = await showHold(stateDir, holdId, index.holds[holdId]);
  const current = holdFromAggregate(holdId, aggregate, index.holds[holdId]);
  aggregate = await maybeExpire(stateDir, index, holdId, aggregate, current);
  return holdFromAggregate(holdId, aggregate, index.holds[holdId]);
}

async function main() {
  let input;
  try { input = parseArgs(process.argv.slice(2)); } catch (error) {
    if (error instanceof UserError) return refusal(error.message);
    throw error;
  }
  try {
    if (input.command === "section") {
      const { stateDir, index } = await ensureState();
      return output(await createSection(stateDir, index, input.sectionId, input.capacity));
    }
    if (input.command === "hold") {
      const { stateDir, index } = await ensureState();
      await refreshIndex(stateDir, index);
      return output(await createHold(stateDir, index, input));
    }
    if (input.command === "section-status") {
      const { stateDir, index } = await ensureState();
      await refreshIndex(stateDir, index);
      return output(sectionStatus(index, input.holdId));
    }
    const { stateDir, index } = await ensureState();
    await refreshIndex(stateDir, index);
    if (input.command === "status") return output(await status(stateDir, index, input.holdId));
    if (input.command === "issue") return output(await issue(stateDir, index, input.holdId));
    if (input.command === "release") return output(await release(stateDir, index, input.holdId, input.seatIds));
    if (input.command === "expire") return output(await expire(stateDir, index, input.holdId));
    if (input.command === "reconcile") return output(await reconcile(stateDir, index, input.holdId));
    throw new UserError("bad_args");
  } catch (error) {
    if (error instanceof UserError) return refusal(error.message);
    if (error instanceof KernelError) {
      if (error.code.includes("NOT_FOUND")) return refusal("unknown_hold");
      return refusal("unavailable");
    }
    return refusal("unavailable");
  }
}

await main();
