# Conference seat-hold desk

A one-process command-line desk for durable conference sections and single- or multi-seat holds. Lifecycle transitions are defined in `hold.ik.toml` and persisted by Ikaros; section indexing, group seat ownership, and provider I/O remain in the Node host.

## Setup

Use Node 22. The supplied offline packages are already referenced by `package.json`:

```sh
npm install --offline --no-audit --no-fund
chmod +x run
```

A clean checkout with the supplied `KIT/npm/*.tgz` files can instead run the exact install used to qualify this project:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

## Running

Every invocation prints one JSON object. Set `STATE_DIR` to a durable writable directory. `NOW_MS` is required for `status`, `release`, `expire`, and `issue` because those commands observe deadlines. `SERVICE_URL` is required for `issue` and `reconcile`.

```sh
STATE_DIR=/tmp/seat-state ./run section hall-a 3
STATE_DIR=/tmp/seat-state ./run hold h1 hall-a A1 5000
NOW_MS=1000 STATE_DIR=/tmp/seat-state SERVICE_URL=http://127.0.0.1:49000 ./run issue h1
NOW_MS=1000 STATE_DIR=/tmp/seat-state ./run status h1
```

Commands are `section`, `hold`, `issue`, `release`, `expire`, `status`, `section-status`, and `reconcile`. `hold` accepts one or more seat ids followed by a deadline (`hold h1 hall-a A1 A2 5000`); seat ids are stored in sorted order. `release h1` releases all remaining seats, while `release h1 A1` releases one selected seat from a held group. The fake provider is in `stub/`; run `node stub/server.mjs` and use its printed `service_url` for `SERVICE_URL`. `CRASH_AT` accepts the three boundaries named in the brief and is intended for recovery tests.
The desk writes only `desk.json`, `holds.sqlite`, and its temporary files under `STATE_DIR`; unrelated files are not read or rewritten.

## Checks

The machine identity is obtained from the installed runtime, never by hashing in the host:

```sh
node_modules/@ikaros/darwin-arm64/bin/ik identity hold.ik.toml
node_modules/@ikaros/darwin-arm64/bin/ik check hold.ik.toml
```
