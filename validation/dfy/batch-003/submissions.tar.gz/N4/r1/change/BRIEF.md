# Conference seat-hold desk

A local ticket desk owns named seats in sections of a conference. Operators create a section with a fixed capacity, place a temporary hold on one seat, issue its ticket exactly once through an external ticketing provider, and release a hold when it is no longer wanted. Holds have an explicit deadline supplied by the caller. A hold past its deadline is expired before a command uses it. Issuing is an all-or-nothing external effect: a successful issuance makes the held seat ticketed; a failed or uncertain request never permits a second request id. The desk never issues a seat that is not held by that hold, and section capacity is enforced.

The application is behind an executable `./run`, implemented in TypeScript/Node 22 or plain Node. Every invocation is one process and prints exactly one JSON object on stdout. Exit 0 means success. A refusal exits nonzero and prints `{"error":"..."}`. Extra fields are allowed. `STATE_DIR`, `SERVICE_URL`, `NOW_MS`, and optional `CRASH_AT` are described below. The provider contract is in `stub/CONTRACT.md`.

## Scope and command line

One machine and one desk process at a time. The operator does not overlap desk processes. Other writers may create files in `STATE_DIR`; the desk must preserve them byte-for-byte. Holds and sections are independent. The desk does not receive callbacks. Recovery is by lookup of the saved provider request id.

```
./run section <section_id> <capacity>
./run hold <hold_id> <section_id> <seat_id> <deadline_ms>
./run issue <hold_id>
./run release <hold_id>
./run expire <hold_id>
./run status <hold_id>
./run section-status <section_id>
./run reconcile <hold_id>
```

`STATE_DIR` is a durable directory chosen by the harness. The desk may create and write only its own files there. `SERVICE_URL` is the provider base URL with no required trailing slash. `NOW_MS` is a decimal non-negative integer supplied on every clock-sensitive invocation; the desk must use it rather than wall clock time. `CRASH_AT`, when equal to one named boundary below, kills the process with SIGKILL at that boundary. A crash boundary is honored only by the invocation that reaches it.

IDs use `^[A-Za-z0-9._-]{1,64}$`; `capacity` is a decimal integer 1..100000; `deadline_ms` is a decimal integer 0..9007199254740991. `seat_id` uses `^[A-Za-z0-9._-]{1,32}$`. Invalid IDs are `bad_id`, invalid capacity is `bad_capacity`, invalid deadline is `bad_deadline`, invalid arity is `bad_args`. These refusals contact no provider and change no state.

## Crash boundaries

- `after-hold-saved-before-request`: on `issue`, after an issuance attempt (request id, hold id, section id and seat id) is durably saved, before any provider request byte is sent. It is not honored on a retry or lookup.
- `after-accept-before-record`: after the provider has accepted the complete request body and the desk read the complete HTTP response, before the ticketed outcome is durably committed.
- `after-record-before-exit`: after this invocation durably commits `ticketed` and before writing its success result. It is not honored when this invocation only observes an already-ticketed record.

## Section

`section <section_id> <capacity>` is local and contacts no provider. The first call stores an empty section. Repeating it with the same capacity exits 0 unchanged. A different capacity is refused `conflict`. Success returns:

```json
{"section_id":"hall-a","capacity":3,"held":0,"available":3}
```

`section-status <section_id>` returns the same shape. It refuses `unknown_section` when absent. Capacity counts every non-expired hold, including a hold with an open issuance attempt or a ticketed hold. Seats are unique within a section. A seat is available only when it is not currently held by another hold. An expired hold's seat becomes available when expiration is durably observed.

## Holds

`hold <hold_id> <section_id> <seat_id> <deadline_ms>` creates one hold without contacting the provider. It refuses `unknown_section`, `conflict` if the hold id already exists with different data, `seat_taken` if that seat is currently held by another non-expired hold, and `capacity_exceeded` if the section has no available capacity. A repeated identical hold is idempotent and returns the stored object. A hold deadline equal to `NOW_MS` is already expired for commands that use it.

Success and `status` shape:

```json
{"hold_id":"h1","section_id":"hall-a","seat_ids":["A1"],"deadline_ms":5000,"state":"held","request_id":null,"ticket_id":null}
```

`state` is `held`, `attempt_saved`, `ticketed`, `released`, or `expired`. `released` and `expired` are terminal. A `status` of an unknown hold is `unknown_hold`; status does not contact the provider. A later process sees the same committed state.

`release <hold_id>` is local and contacts no provider. It refuses `unknown_hold`, is idempotent for `released` or `expired`, and refuses `release_open` when an issuance attempt is saved or the hold is ticketed. Otherwise it marks the hold `released`, frees its seat, and returns the object with `state:"released"`. `expire <hold_id>` is local. It refuses `unknown_hold`; before the deadline it refuses `not_due`; at or after the deadline it marks a `held` hold `expired` and frees the seat. It must not expire an open attempt or a ticketed hold; those return `release_open` and retain their state. Expiration is also performed before `issue`, `release`, or `status` uses a `held` hold, so a past-due hold cannot be issued.

## Issue and provider recovery

`issue <hold_id>` issues exactly the held seat. It refuses `unknown_hold`, `expired`, `released`, `not_due` (deadline has not arrived? no: a held seat is issuable before its deadline), `release_open`, or `unknown_section` as applicable. A `ticketed` hold is idempotent: it exits 0, contacts no provider, and preserves `request_id` and `ticket_id`.

When state is `held`, the desk allocates a request id, durably saves the attempt, then honors `after-hold-saved-before-request`. It POSTs exactly that request id and seat. After a complete matching HTTP 200 response it honors `after-accept-before-record`, commits `ticketed`, and honors `after-record-before-exit`. When state is `attempt_saved`, it first GETs the saved request id. A matching HTTP 200 is adopted without POST. HTTP 404 means the request was not accepted and permits POST of the saved request id only. A lookup with mismatched hold, section or seats is `conflict`; any other provider failure is `unavailable`. Never allocate a second request id for an open attempt.

Success shape:

```json
{"hold_id":"h1","section_id":"hall-a","seat_ids":["A1"],"deadline_ms":5000,"state":"ticketed","request_id":"...","ticket_id":"..."}
```

A connection failure, dropped/incomplete response, or HTTP 500 leaves `attempt_saved`, exits `unavailable`, and never posts a different request id in that invocation. `reconcile <hold_id>` never POSTs or allocates an id. With no attempt it returns `{"outcome":"not_applicable"}` for a non-ticketed hold. With an attempt it looks up the saved request id: matching 200 commits `ticketed` and returns `outcome:"ticketed"`; 404 returns `outcome:"not_sent"` while retaining `attempt_saved`; mismatch is `conflict`; unavailable is `unavailable`. Only a 404 lookup may report `not_sent`.

## Requirements

R1. Durable section and hold persistence survives new processes and SIGKILL after any committed boundary.
R2. Section creation and hold creation are local, idempotent for identical data, and stable on conflicts.
R3. Section capacity and seat exclusivity prevent a second live hold from taking a held seat or exceeding capacity; no provider call is made for refusal.
R4. A healthy `issue` of a live held seat succeeds, records one ticketed outcome, and provider effect has exactly that hold, section, and seat.
R5. Legitimate progress (section, hold, then issue before deadline) is accepted, not refused.
R6. Issuing a ticketed hold again is idempotent and adds no provider effect.
R7. `reconcile` never sends; a pre-request crash leaves an attempt and reconcile returns `not_sent` with zero effects.
R8. A crash after provider acceptance is recovered by lookup and adopts the same request id with one effect.
R9. A crash before the request is recovered by retrying the saved id and creates exactly one effect.
R10. A crash after the durable ticketed record leaves ticketed state and later issue adds no effect.
R11. Holds and sections are independent; actions on one do not change another.
R12. Every command has one JSON result; unknown hold/section and invalid arguments use the specified nonzero errors.
R13. An unrelated file in `STATE_DIR` is preserved byte-for-byte.
R14. A dropped provider reply leaves a resolvable saved request; reconcile adopts it without a second effect and never labels an accepted request `not_sent`.

## Out of scope

Overlapping desk processes, callbacks, seat moves between sections, changing a deadline, deleting sections, issuing only part of one hold, and refunds are outside this brief. The change below adds group holds and partial release.
