# ik check

Developer analysis. Not a lifecycle operation.

```bash
ik check machine.ik.toml [--prior old.toml] [--corpus cases.json] [--baseline validation/verification_baseline.json]
```

Prints a repair packet and a `VERDICT` of `ACCEPT` or `REFUSED`.
Exit 0 on accept, 1 on refuse, 2 on transport/usage failure.

Python: `kernel.check(path, prior=..., corpus=..., baseline=...)`.
Go: `k.Check(ctx, path, prior, corpus, baseline)`.

## Developer verdict versus strict release

`ACCEPT` is a developer judgment: no newly introduced mandatory debt and no
falsified obligation. It is corpus-relative and may rest on a truncated
exploration. Add `--release` for the strict release policy (exit 1 unless both
hold), and `--json` for a machine-readable document with `report`, `judgment`
and `release`.

Each obligation carries exactly one status: `satisfied` (executed and
witnessed), `falsified`, `incomplete` (not witnessed and the exploration was
truncated, so absence proves nothing), `not_applicable` (stale evidence),
`not_examined` (outside the standard lane: no verifier looked at it, and it is
never counted as satisfied), `approved_debt` (baseline-listed) and `uncovered`.

A strict release passes only when the exploration completed within its bounds,
at least one outcome was executed, and no standard-lane obligation is
falsified, incomplete, stale, approved debt, or unwitnessed, with no surviving
challenge and no infrastructure failure. The release section records the corpus
digest, node/depth bounds, completion reason, engine versions and plan digest.
`runtime_artifact_digest` is `null` when the build supplies none; it is never
synthesized. Obligation kinds with no verifier are listed under excluded
assumptions.

`ik laws` links each invariant to its plan obligation and reports the honest
status (`not_examined` today: runtime enforcement is the only evidence).

## Trace export (`ikaros.trace.v2`)

Events are tagged: `commit`, `refusal`, `no-op`, `unknown`, `read`,
`historical` (an exact-duplicate response, not a new commit) and `witness` (a
bounded checker path, not a run). Bundles declare `origin`
(`observed`/`replayed`/`bounded-witness`), `reproducible` and `redacted`; a
redacted bundle cannot be reproducible and a replayed one must name its inputs.
`parseTraceBundle` rejects contradictory fields instead of rendering them.
This is a breaking change from `ikaros.trace.v1`, which could label a read as a
commit; the export is advisory and carries no authority.

## Running `ik check` without a corpus

Without `--corpus` and without a sibling `<machine>.ik.cases.json`, there are no cases to explore, so `ik check` reports `REFUSED` (for example "uncovered newly
introduced mandatory obligation": no command outcome was witnessed); this is a statement about missing evidence, not a defect in the machine. The runtime enforces the
machine's laws regardless. The refusal text adds one trailing `NEXT COMMAND` line, and `--json` adds a `next_actions` array, naming the exact command to generate an editable starter corpus. Exit codes and the existing JSON members stay as they were. A check that already has a corpus does not add that hint.

```bash
ik corpus init machine.ik.toml --out machine.ik.cases.json
ik check --corpus-template machine.ik.toml
```

The starter has `"_note": "example cases, not an exhaustive domain"`, one type-valid example per command, and, for each command with an `int` argument, `boundary_min` and `boundary_max` at the shared signed 64-bit ends. Edit it. It is not a domain proof. Supply `--corpus cases.json` (see `examples/publish-approval/machines/*.cases.json`) to
get an accept/refuse verdict that is bounded and corpus-relative.

## Check profiles

`--profile <file>` evaluates a version-1 TOML profile after the normal check.
`.ik/checks.toml` is only a conventional path; a profile is loaded only when
the flag is passed. Without `--profile` or `--plan`, text, `--json`, and exit
codes are unchanged.

```toml
profile_version = 1

[limits]
max_nodes = 4096
max_depth = 16

[[goals]]
id = "published"
kind = "reach_terminal"
terminal = "published"
required = true

[[goals]]
id = "not-stuck"
kind = "no_stuck_states"
allow_waiting = ["awaiting_review"]
```

`kind` is `reach_terminal` (field `terminal`), `reach_state` (field `state`),
`command_executes` (field `command`), or `no_stuck_states` (optional
`allow_waiting`). `required` defaults to true. Unknown fields, unknown kinds,
duplicate ids, and references to undeclared states or commands are usage
errors (exit 2).

`[limits]` may set `max_nodes` and `max_depth`. Omitted limits use 4096 and 16.
A profile has its own digest over the canonical profile, so reformatting the
file does not change it, and it does not change the machine spec hash. Each
goal carries a content digest over the canonical JSON of that goal. Changing
the goal content changes both digests even when the id stays the same.

`--plan` prints the goals, kinds, content digests, limits, corpus digest, and
this scope, and does not run exploration:

> search up to N nodes / depth D over the supplied corpus; a witness proves reachability, absence of a witness does not prove unreachability unless the search is complete

It exits 0. With `--json` it prints a plan object and no witness.

After a normal check, each goal has one status:

| Status | Meaning |
|---|---|
| `witness_found` | Shortest witness steps from the exploration. Satisfies a required goal. |
| `no_witness_found_complete` | Search completed and the target is unreachable within the supplied corpus. Does not satisfy a required goal. |
| `no_witness_found_incomplete` | Search was truncated by the node or depth bound. Absence of a witness is not unreachability. Does not satisfy a required goal. |
| `input_coverage_gap` | A command needed on a path has no corpus case, or every supplied case was refused. Not an unreachability result. Does not satisfy a required goal. |
| `stuck_states_found` | An executably reached, non-terminal, non-allowed state had no successful declared outgoing command. Each candidate is `no_corpus_case`, `all_cases_refused`, or `no_outgoing_command`. This is not a proven deadlock when the search is incomplete or the corpus is missing cases. Does not satisfy a required goal. |
| `no_stuck_states_found` | No such candidate among executably reached states. Satisfies a required goal only when the search completed. |

A terminal state with no outgoing command is not stuck. States listed in
`allow_waiting` are not stuck.

With `--profile`, exit 1 if the check would already be non-accept, or if any
required goal is not satisfied. Optional goals are reported and do not change
the exit code. `--json` adds a top-level `profile` object. Text output appends
a `PROFILE` section after the existing report.


## Prior baseline

`--prior` with `--profile` evaluates the same goals against the prior machine
where the referenced states and commands exist in both. A goal that cannot be
asked of the prior is `not_comparable`, with the reason. `profile.baseline`
shows the candidate status, the prior status, and `regression` when a goal
satisfied on the prior is not satisfied on the candidate. Without `--profile`,
`--prior` output is unchanged. See `docs/change-evidence.md`.
