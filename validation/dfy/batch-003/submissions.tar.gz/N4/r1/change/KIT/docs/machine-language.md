# Machine language

Declarative machines are `.ik.toml` files: facts, states, commands,
guards, effects, invariants. `ik identity` prints the kernel identity
`(machine_id, version, spec_hash)`. Clients must not compute the hash.

Commands are requested by **name and args**. Destination states are not
sent. The kernel selects the outcome.

Native machines (ArqDelegation today) stay in a thin product package
above the generic client. They are not a second protocol.

## Schema versions

Schema 1 declares flat states and commands. Its deserialization, runtime
semantics, and identity hash are unchanged by the schema-2 frontend.

Schema 1 requires an explicit `[facts]` table even when it has no entries; schema 2 defaults it to empty.

Schema 2 declares regions in the same `.ik.toml` file, then lowers them to
the existing schema-1 runtime definition. `schema_version = 2`, `machine_id`,
and `machine_version` are required; `name` is optional, and authored facts
and invariants default to empty maps. For example:

```toml
schema_version = 2
machine_id = "player"
machine_version = 1

[regions.playback.states.playing]
initial = true
[regions.playback.states.paused]
[regions.playback.commands.pause]
from = ["playing"]
to = "paused"

[regions.volume.states.unmuted]
initial = true
[regions.volume.states.muted]
[regions.volume.commands.mute]
from = ["unmuted"]
to = "muted"

[commands.pause_and_mute]
from = { playback = ["playing"], volume = ["unmuted"] }
to = { playback = "paused", volume = "muted" }
```

Local `pause` preserves volume; the explicit joint `pause_and_mute` changes
both regions atomically. Joint source regions omitted from `from` are
wildcards; target regions omitted from `to` remain unchanged. Region-local
commands retain schema-1 `from`, `to`/`when`/`then` or ordered `outcomes`,
plus `args` and `effect`. Joint commands use region maps for sources and
targets. This is deterministic named command-scoped execution, **not SCXML
broadcast or run-to-completion**. Command names have one region/joint owner,
except for a child/parent pair within one region.

A region may declare one nonrecursive parent with `name`, `children`, and
`commands`. Child outcomes precede parent fallback. All child guards must
evaluate false before fallback; an evaluation error refuses, and an
unconditional final child outcome suppresses fallback at that source.
Shared child/parent commands require exactly equal serialized `args` and
`effect` declarations.

Use generated string facts such as `region_playback == "playing"` in
cross-region guards and invariants. The authored `state` operand is refused
structurally in schema 2; unknown leaf strings in region comparisons are
also refused. Authored fact/invariant names starting `region_` and
assignments to generated region facts are forbidden. Generated hard
invariants enforce agreement with the flat canonical state.
Lowered outcomes guard source agreement too, and decoding refuses inconsistent
state/fact pairs. Schema-2 initial invariant violations are refused at parse
time using the runtime's shared invariant evaluator; schema 1 is unchanged.

Region, leaf, and parent names are ASCII identifiers without `__`.
Lexically ordered regions produce flat leaf names joined with `__`. Each
region has one nonterminal initial leaf; the aggregate is terminal only
when all leaves are terminal. Local commands cannot source terminal leaves.
Joints cannot explicitly source terminal leaves or target currently terminal
components through wildcard sources, even with same-leaf assignments;
omitted terminal siblings remain unchanged.
The current frontend limit is 64 product states, checked with overflow
detection before Cartesian-product allocation; it is not a CORE_LAW.

Save the example as `player.ik.toml`, then use:

```sh
ik identity player.ik.toml
ik check player.ik.toml
ik check player.ik.toml --corpus cases.json
```

These commands are examples, not validation evidence. Identity is the hash
of the lowered runtime definition; authoring metadata is not a second
machine identity. Check output prints the overall `VERDICT` before derived
region paths and Mermaid charts. A reachable invariant-refusal witness
means the kernel blocked an unsafe proposal, not that it committed an
unsafe state. Such a witness makes the region check REFUSED. ACCEPT remains
bounded and corpus-relative, not a proof over all inputs and unbounded paths.
“Complete within the supplied finite corpus” is not exhaustive. Invariant
refusals are included in the shared pipeline's flat judgment as well as the
overall verdict and text, not applied as a CLI-only override.
Charts are lossy structural views: guards, invariants, facts, and joint
atomicity are not shown.
The schema-1 `machines/invariant_probe.ik.toml` intentionally violates an
invariant and is expected to check as REFUSED; its hash remains unchanged.

See [Region lowering](region-lowering.md) for complete parent and joint
examples, resource limits, witness projection, and Rust loader/check APIs.
