No open candidates.
