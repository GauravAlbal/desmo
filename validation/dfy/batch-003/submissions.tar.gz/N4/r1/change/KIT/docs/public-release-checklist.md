# Public source release: owner clearance checklist (IK-12)

Nothing here publishes anything. The export tool builds a candidate; the owner decides whether and
when it becomes public. Items marked OWNER cannot be inferred or completed by tooling.

## Mechanical (tooling)

- [x] `python3 scripts/public_export.py --rev <commit> --out <empty dir>` exports an allowlisted,
  verbatim subset of one commit and writes `EXPORT_MANIFEST.json` (origin commit, allowlist digest,
  per-file sha256, exclusions, acknowledgements).
- [x] The export fails on private-workflow references, absolute user paths and secret patterns
  unless an exact (path, pattern) acknowledgement with a reason exists. Secrets cannot be
  acknowledged.
- [x] `scripts/public-verify` runs the Rust, Python, Go, TypeScript, mutant-manifest and example
  gates with no private tooling.
- [x] `.github/workflows/ci.yml` runs `scripts/public-verify` (not yet run on a public repository).

## OWNER decisions (open)

- [ ] **O-1 Disclosure and licensing authority.** Confirm you may disclose and license this code
  (employment/IP, third-party content). The manifests declare `MIT OR Apache-2.0`; **no LICENSE
  text file is in the repository**. Supply the license files and copyright holder; tooling will
  not invent either.
- [ ] **O-2 Branding.** Confirm the name `Ikaros` and the package names (`@ikaros/runtime`,
  `invariant-kernel`, the Go module path) are yours to publish.
- [ ] **O-3 Consumer references.** The export acknowledges references to the first internal
  consumer (see `acknowledged` in `export/allowlist.json`). Approve naming it or generalize.
- [ ] **O-4 Security channel.** `SECURITY.md` names GitHub private vulnerability reporting; enable it
  on the public repository or substitute your channel.
- [ ] **O-5 Support expectations.** `SECURITY.md` says best effort, latest release only; confirm.
- [ ] **O-6 History.** The export is a single-commit snapshot with lineage in `EXPORT_MANIFEST.json`;
  decide whether to publish git history (it contains private workflow references) or only the
  snapshot.
- [ ] **O-7 Release step.** Repository creation, visibility, tags, registry publication and the
  `LATEST_RELEASE` update are separate owner-authorized actions (IK-16).

Any change to the export's files after qualification invalidates earlier byte qualification: rerun
the export and `scripts/public-verify` on the new candidate.
