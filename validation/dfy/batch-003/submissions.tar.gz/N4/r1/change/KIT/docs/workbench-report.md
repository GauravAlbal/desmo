# Workbench report and regressions

`ik report` folds scenario runs, analysis results, and check profiles into one
finding list. `ik regression` copies a reviewed scenario bundle and re-runs it.
Promotion is explicit. A failing bundle is copied as it is; expectations are
not rewritten to make it pass.

## Report

```sh
ik report <path>... [--json] [--html <file>]
```

Each path is a run directory or a JSON document of a known kind:

| Kind | How it is recognized |
|---|---|
| `ik.scenario.result.v1` | `result.json` in a scenario bundle, or that document itself |
| `ik.analysis.host-report.v1` | `host-report.json` in an analysis run directory, or that document |
| `ik.analysis.result.v1` | an analysis result document |
| `ik.check.profile.v1` | an `ik check --json` document that has a `profile` object, or the profile object itself |

A directory is read as `host-report.json` when that file exists, otherwise as
`result.json`. Mixing kinds in one invocation is normal: every path contributes
findings to one `ik.report.v1` document. Text is the default. `--json` prints
the document. `--html` writes a self-contained page with no network scripts
and no external resources.

Unknown, missing, or malformed input is an `unreadable` finding. It is not
skipped. Exit `0` when every path was read, `1` when any path was unreadable,
`2` on usage.

### Finding

Each finding has a source kind, a stable id, a status, a scope sentence, an
evidence class, a completeness word, a source coordinate when the source has a
machine command or state, before/after facts when the source has them,
attempted versus committed behavior, the reproduction status, engine-native
artifact paths, and a next action.

A refused command is `committed: refused`. The state that remains is not a
destination of that command. A model finding stays `model-level` until
`reproduction_status` is `concrete_reproduced`. Reproduction status is copied
verbatim from an analysis result. A prefix/cycle validation is not an observed
infinite execution.

Evidence classes stay distinct:

| Class | How the report reads it |
|---|---|
| `sampled_execution` | a sample; not a proof. `holds_in_scope` from a sample is not adopted |
| `bounded_paths` | a bounded search, including native `ik check` exploration |
| `exhaustive_finite_model` | exhaustive only inside the declared finite model |
| `observed_trace` | a scenario run against the runtime |

A witness is the smallest found within the enumerated search. The report does
not call it minimal.

### Next action

The next action comes from a fixed table keyed by status. A command name is
filled in only for an input coverage gap. A detail is appended only when the
status says what to configure.

| Status | Next action |
|---|---|
| `witness_found` | promote as regression or continue |
| `input_coverage_gap` | add corpus cases for the named command |
| `no_witness_found_incomplete` | raise bounds or add cases |
| `no_witness_found` with incomplete coverage | raise bounds or add cases |
| `no_witness_found_complete` | unreachable within the supplied corpus; change the corpus or the goal |
| `violation`, `expectation_failed` | reproduce with `ik scenario reproduce` |
| `unsupported` | configure the unsupported capability |
| `tool_unavailable` | configure or install the missing tool |
| `refused` | refused, not a committed state |
| `unreadable` | replace or repair the input; it was not skipped |

`no_violation_found` is not a proof. `holds_in_scope` holds only in the
declared finite model.

## Handoff

```sh
ik handoff <behavior.json> --evidence <path>... [--kind delivery|change|recovery] [--json]
```

`behavior.json` (`behavior_version` 1, unknown fields refused) holds a `title`,
`outcomes` and `unchanged` items (`id`, `text`, `evidence`: finding ids from
`ik report`), `assumptions`, and an optional `decision` (`question`, `options`
with `label` and `consequence`, optional `recommended`). The command reads the
evidence as `ik report` does and prints one status per claim:

| Status | Meaning |
|---|---|
| `exercised` | every cited finding resolves and is `committed`, `refused`, or `holds_in_scope` |
| `incomplete` | a cited finding is partial, a sample, or a search without a witness, or some cited id is missing |
| `contradicted` | a cited finding is `expectation_failed`, `violation`, or `failed` |
| `cited_evidence_not_found` | none of the cited ids resolve |
| `no_evidence_cited` | the claim cites nothing |

Each cited finding's scope sentence is printed beside the claim, so a refusal
reads as "not committed". The evidence index lists every finding, including
ones no claim cites. Exit `1` when a claim is contradicted or any evidence path
was unreadable, `2` on a malformed behavior file or usage. A decision is
rendered as written; `ik handoff` never chooses an option.

## Regression

```sh
ik regression promote <bundle-dir> --name <name> --reason <reason> [--into <dir>]
ik regression run <dir>
```

`promote` checks `SHA256SUMS` against the bundle files. A mismatch, a missing
required file (`scenario.json`, `machine.ik.toml`, `result.json`), or an
existing `<into>/<name>/` is refused (exit `2`). The default directory is
`regressions/`. The copy includes every file named by `SHA256SUMS`, plus
`SHA256SUMS`, and writes `REGRESSION.json`:

| Field | Meaning |
|---|---|
| `source_bundle_digest` | SHA-256 of the source `SHA256SUMS` bytes |
| `reason` | the `--reason` text, stored unchanged |
| `spec_hash` | machine spec hash from the bundle `result.json` |
| `runtime_binary_sha256` | SHA-256 of the `ik` binary that performed the promotion |

`run` calls the scenario reproduction library on every promoted bundle under
`<dir>` (or on `<dir>` itself when it contains `REGRESSION.json`). It prints
`<name>: reproduced` or `<name>: not_reproduced`. Exit `0` when every case
reproduces, `1` when any does not, `2` on usage. A runtime binary difference
is reported and is not, by itself, a failure. Re-running does not edit the
promoted files.
