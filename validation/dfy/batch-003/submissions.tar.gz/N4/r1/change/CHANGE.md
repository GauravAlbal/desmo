# Change: group booking and partial release

R1 through R14 remain in force for existing single-seat holds. This change adds group holds: one hold may own a list of seats, and one provider issuance must cover the complete list or no ticket is adopted. It also revises `release` so an operator may release selected seats from a held group before issuance. Existing persisted holds with one seat remain valid and keep their original behavior.

## Revised commands

### `./run hold <hold_id> <section_id> <seat_id> [seat_id...] <deadline_ms>`

The changed form has one or more seat ids followed by a deadline. For compatibility, the original four-argument form remains valid. Seat ids must be unique. All seats must be in the same section and all capacity/exclusivity checks apply to the entire list atomically: if any seat is unavailable, no seat is saved and the refusal is `seat_taken` (or `capacity_exceeded` when total live holds would exceed capacity). Repeating the exact hold id, section, sorted seat list and deadline is idempotent; any difference is `conflict`.

Success/status now reports all held seats:

```json
{"hold_id":"g1","section_id":"hall-a","seat_ids":["A1","A2"],"deadline_ms":5000,"state":"held","request_id":null,"ticket_id":null}
```

### `./run issue <hold_id>`

For a group, issuance is all-or-nothing. The saved attempt contains the complete seat list and one request id. The POST body contains the complete list. A matching provider response must contain exactly the saved list (order-insensitive) and is adopted as one ticket. A response with a missing, extra, or different seat is `conflict`; the local attempt remains open and no partial seat is marked ticketed. A group never issues one seat at a time and never allocates a second request id while an attempt is open. Existing crash boundaries and lookup-before-resubmit rules apply to the whole group.

### `./run release <hold_id> [seat_id...]`

With no seat ids, release all seats as in the original brief. With seat ids, release only that subset. Partial release is allowed only while the hold is `held`; it is refused `release_open` for an attempt or ticketed hold, `unknown_seat` for a seat not in the hold, and `already_released` if a requested seat was previously released. A successful partial release must have at least one seat remaining. It returns the remaining `seat_ids` and `state:"held"`; if the final remaining seat is released, state becomes `released`. The operation is atomic: a bad list releases nothing. The released seats are immediately available for another hold.

`expire` continues to expire all remaining seats together. A partially released hold can still be issued for its remaining complete list. `status` and `section-status` count only remaining live seats. `release` of an already released or expired hold remains an idempotent success only for the no-argument form.

## Requirements

C1. Group hold creation is atomic and durable. A valid list of seats creates one hold, reserves every listed seat, survives restart, preserves one-seat R behavior, and a collision rejects the whole list without changing section counts or another hold.
C2. Group issuance is all-or-nothing and exactly once. A healthy issue produces one effect whose seat list equals the complete held list; no per-seat effects are allowed. A second issue is idempotent. A mismatching provider body is a conflict with no partial adoption.
C3. An open group attempt blocks all release and issue alternatives. A crash or dropped reply can be recovered by lookup/retry of the same request id; no different seat subset or request id is posted, and a different command cannot replace the attempt.
C4. Partial release is atomic and frees capacity. Releasing selected held seats makes exactly those seats available, keeps the remainder held, and permits another hold to use a freed seat. Invalid, repeated, empty, or all-seat partial lists are refused as specified without mutation; full release remains idempotent.
C5. Deadline and capacity apply to groups and revisions. At/after the deadline, all remaining seats expire together and cannot be issued; released seats do not count toward capacity, while an open attempt and ticketed group retain all remaining seats. A section never exceeds capacity during group hold, partial release, expiry, or recovery.
