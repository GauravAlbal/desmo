# DIAGNOSE

Entry: a symptom, an operation or aggregate id, and a declared mode. Read `skills/ikaros/routing.json` first.

- `investigate_only`: `read` and `scratch` only. No source edit. No store mutation. No `ik analysis run`.
- `authorized_repair`: source repair of the implicated seam, plus a store continuation only when the human explicitly authorized that continuation.

Inspect-only does not authorize writes. Do not widen the mode because a write would be convenient.

## Steps

1. Read the installed surface: Discover step 1 in `skills/ikaros/SKILL.md` (`ikaros` is `npx --no-install ikaros`, and a Python project has none). It does not open a store and does not execute an adapter. A missing store is not corruption; do not create one on a read.
2. Read current state with `ik --store <path> --machine <machine.ik.toml> show`. The envelope `op` is `show` and names `aggregate_id`. This is the current projection. It is not attribution of a past request and not proof that a command was refused.
3. Ask whether a specific operation id committed, using the original body and the capability that attempt used. TypeScript `Machine.lookupOperation`. Python `Machine.lookup_operation`. Go `Machine.LookupOperation`. Kernel op name is lookup_operation. See `docs/client-recovery.md`, `docs/typescript.md`, `docs/python.md`, `docs/go.md`, and `docs/operation-identity.md`.
   - `committed_exact` is history: not a new commit and not a current handle.
   - `conflict` means the same id was used with different semantics or a refreshed capability. Do not refresh and resend.
   - `not_recorded` is what that read saw. It is not a refusal, not a cancellation, and not permission to retry.
4. `ik --store <path> --machine <machine.ik.toml> replay` and `ik --store <path> --machine <machine.ik.toml> verify` audit the journal. They do not answer whether an operation committed. They are not permission to repair by rewriting rows.
5. Separate a few causes with different observable predictions. Run the cheapest discriminating test in scratch or on an allowed read before any repair.
6. `ik scenario run <machine.ik.toml> <scenario.json> --out <dir>` reproduces on a fresh scratch store. There is no `--store` flag. Confirm a requested crash or drop boundary fired; absence of injection is not a crash pass. `ik scenario reproduce <bundle-dir> --out <dir>` matches a bundle aside from runtime identity. See `docs/scenarios.md`.
7. `ik check <machine.ik.toml> --profile <checks.toml> [--plan] [--corpus <cases.json>] [--json]` explains which goals were examined. `--plan` does not explore. A missing corpus case is `input_coverage_gap`, not unreachability. This does not authorize a production commit. See `docs/ik-check.md`.
8. Classify: expected refusal, application mapping defect, runtime defect, external-service uncertainty, instrument defect, unsupported scope, or missing permission. Keep undecidable distinctions unknown.
   - A refusal that correctly applies a rule the application states, with state and provider agreeing, is not an incident. Report it as no incident and change nothing. Reserve a refusal label for a refusal the recorded state does not require.
   - An external lookup that returns not-found counts as "not sent" only after you have confirmed the route and id with the application's documented lookup path or with a lookup known to succeed. A not-found from an unverified route is unknown, not absence.
9. Optional specialist, chosen by the question, never by asking the human to pick a brand. `ik analysis describe <manifest.json>` does not spawn. `ik analysis run <manifest.json> --request <request.json> --out <dir> [--timeout-seconds <seconds>]` is scratch only and is not an investigate-only command. Never point it at a production store. Exit 0 is host acceptance of a result document, not a property pass and not a release approval. `ik analysis validate-result <request.json> <result.json>` does not spawn. `ik graph export <machine.ik.toml> [--corpus <cases.json>] [--max-nodes <n>] [--max-depth <d>] --out <graph.json>` is a finite graph; a cut is incomplete. An unavailable checker does not block native `ik check` or `ik scenario run`. See `docs/analysis-adapters.md`.
10. `ik report <path> [--json] [--html <file>]` is the finding list. `ik evidence verify <evidence.json> --machine <machine.ik.toml> [--profile <checks.toml>] [--corpus <cases.json>] [--runtime-binary <path>] [--json]` says whether cited evidence is still current. Stale evidence is not a pass. See `docs/workbench-report.md` and `docs/change-evidence.md`.
11. Repair only in `authorized_repair`, and only the implicated seam. Add a contract-derived regression: `ik regression promote <bundle-dir> --name <name> --reason <reason> [--into <dir>]`, then `ik regression run <dir>`. Promotion does not rewrite a failing expectation into a pass.
12. A store continuation requires an explicit authorization, the current capability, and the original operation id. Do not substitute a fresh capability into the old logical operation. Do not retry an uncertain effect. Do not forge an effect success. Do not claim an absent row proves refusal.
13. Re-read with `show` and re-run the relevant positive scenario in scratch. Then fill the recovery handoff in `skills/ikaros/SKILL.md`. Cite evidence ids and paths. List unknown and unrun claims. An exception-free run is not completion. `ik handoff <behavior.json> --evidence <path>... [--kind delivery|change|recovery] [--json]` renders the handoff from that evidence. A claim is `exercised` only when its cited finding ids resolve to supporting findings; uncited, missing, partial, or contradicted claims say so. See `docs/workbench-report.md`.

`ikaros trace <bundle.json> --out <file.html>` is advisory HTML for a bundle you already have. It is not authority.
