import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { spawn, spawnSync } from "node:child_process";

const root = dirname(fileURLToPath(import.meta.url));
const run = join(root, "run");
const state = await mkdtemp(join(tmpdir(), "seat-desk-"));
const provider = spawn(process.execPath, [join(root, "stub", "server.mjs")], { cwd: root, stdio: ["ignore", "pipe", "inherit"] });
const line = await new Promise((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error("provider startup timeout")), 5000);
  provider.stdout.once("data", (chunk) => { clearTimeout(timer); resolve(JSON.parse(String(chunk))); });
  provider.once("error", reject);
});
const env = (extra = {}) => ({ ...process.env, STATE_DIR: state, ...extra });
function invoke(args, extra = {}, allowEmpty = false) {
  const result = spawnSync(run, args, { cwd: root, env: env(extra), encoding: "utf8" });
  const lines = result.stdout.trim().split("\n").filter(Boolean);
  if (!allowEmpty) {
    assert.equal(lines.length, 1, `one JSON result for ${args.join(" ")}: ${result.stdout}`);
  }
  return { status: result.status, value: lines.length ? JSON.parse(lines[0]) : null };
}
async function fault(value) {
  const response = await fetch(`${line.control_url}/fault`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(value) });
  assert.equal(response.status, 200);
}

try {
  const unrelated = join(state, "unrelated.bin");
  const unrelatedBytes = Buffer.from("do not rewrite\0\xff", "binary");
  await writeFile(unrelated, unrelatedBytes);
  assert.deepEqual(invoke(["section", "hall-a", "5"]).value, { section_id: "hall-a", capacity: 5, held: 0, available: 5 });
  assert.equal(invoke(["hold", "h1", "hall-a", "A1", "5000"]).value.state, "held");
  assert.equal(invoke(["hold", "h2", "hall-a", "A1", "5000"]).value.error, "seat_taken");
  assert.equal(invoke(["hold", "h3", "hall-a", "A2", "5000"]).value.state, "held");
  assert.deepEqual(invoke(["section", "small", "1"]).value, { section_id: "small", capacity: 1, held: 0, available: 1 });
  assert.equal(invoke(["hold", "small-1", "small", "S1", "5000"]).value.state, "held");
  assert.equal(invoke(["hold", "small-2", "small", "S2", "5000"]).value.error, "capacity_exceeded");

  const issued = invoke(["issue", "h1"], { NOW_MS: "1000", SERVICE_URL: line.service_url });
  assert.equal(issued.value.state, "ticketed");
  const repeated = invoke(["issue", "h1"], { NOW_MS: "1000", SERVICE_URL: line.service_url });
  assert.equal(repeated.value.request_id, issued.value.request_id);
  assert.equal((await (await fetch(`${line.control_url}/effects`)).json()).count, 1);

  assert.equal(invoke(["release", "h3"], { NOW_MS: "1000" }).value.state, "released");
  assert.equal(invoke(["release", "h3"], { NOW_MS: "1000" }).value.state, "released");
  assert.deepEqual(invoke(["section-status", "hall-a"]).value, { section_id: "hall-a", capacity: 5, held: 1, available: 4 });

  // A pre-request crash leaves a durable attempt and no provider effect.
  assert.equal(invoke(["hold", "crash-pre", "hall-a", "A2", "5000"]).value.state, "held");
  const pre = invoke(["issue", "crash-pre"], { NOW_MS: "1000", SERVICE_URL: line.service_url, CRASH_AT: "after-hold-saved-before-request" }, true);
  assert.notEqual(pre.status, 0);
  assert.deepEqual(invoke(["reconcile", "crash-pre"], { SERVICE_URL: line.service_url }).value, { outcome: "not_sent" });
  assert.equal((await (await fetch(`${line.control_url}/effects`)).json()).count, 1);
  assert.equal(invoke(["issue", "crash-pre"], { NOW_MS: "1000", SERVICE_URL: line.service_url }).value.state, "ticketed");

  // Provider acceptance followed by a killed desk is recovered by lookup.
  assert.equal(invoke(["hold", "crash-accept", "hall-a", "A3", "5000"]).value.state, "held");
  const accepted = invoke(["issue", "crash-accept"], { NOW_MS: "1000", SERVICE_URL: line.service_url, CRASH_AT: "after-accept-before-record" }, true);
  assert.notEqual(accepted.status, 0);
  assert.equal(invoke(["reconcile", "crash-accept"], { SERVICE_URL: line.service_url }).value.outcome, "ticketed");

  // A dropped reply is uncertain, but reconciliation adopts the one accepted effect.
  assert.equal(invoke(["hold", "dropped", "hall-a", "A4", "5000"]).value.state, "held");
  await fault({ drop_reply: true });
  const dropped = invoke(["issue", "dropped"], { NOW_MS: "1000", SERVICE_URL: line.service_url });
  assert.equal(dropped.value.error, "unavailable");
  await fault({ drop_reply: false });
  assert.equal(invoke(["reconcile", "dropped"], { SERVICE_URL: line.service_url }).value.outcome, "ticketed");

  // Deadline equality expires before issue and frees the seat.
  assert.equal(invoke(["hold", "deadline", "hall-a", "A5", "10"]).value.state, "held");
  assert.equal(invoke(["status", "deadline"], { NOW_MS: "10" }).value.state, "expired");
  assert.equal(invoke(["hold", "reused", "hall-a", "A5", "5000"]).value.state, "held");
  assert.equal(invoke(["expire", "crash-accept"], { NOW_MS: "5000" }).value.error, "release_open");
  assert.deepEqual(invoke(["status", "crash-pre"], { NOW_MS: "5000" }).value.state, "ticketed");
  // Group holds reserve atomically, release selected seats, and issue the remaining set once.
  assert.deepEqual(invoke(["section", "group-hall", "4"]).value, { section_id: "group-hall", capacity: 4, held: 0, available: 4 });
  assert.deepEqual(invoke(["hold", "group-1", "group-hall", "G2", "G1", "5000"]).value.seat_ids, ["G1", "G2"]);
  assert.deepEqual(invoke(["hold", "group-1", "group-hall", "G1", "G2", "5000"], { NOW_MS: "1000" }).value.seat_ids, ["G1", "G2"]);
  assert.deepEqual(invoke(["release", "group-1", "G1"], { NOW_MS: "1000" }).value.seat_ids, ["G2"]);
  assert.equal(invoke(["hold", "group-2", "group-hall", "G1", "5000"]).value.state, "held");
  const groupTicket = invoke(["issue", "group-1"], { NOW_MS: "1000", SERVICE_URL: line.service_url });
  assert.deepEqual(groupTicket.value.seat_ids, ["G2"]);
  assert.equal((await (await fetch(`${line.control_url}/effects`)).json()).count, 5);

  // A mismatching complete response is a conflict, never a partial ticket.
  assert.equal(invoke(["hold", "group-3", "group-hall", "G3", "G4", "5000"]).value.state, "held");
  await fault({ mismatch: true });
  assert.equal(invoke(["issue", "group-3"], { NOW_MS: "1000", SERVICE_URL: line.service_url }).value.error, "conflict");
  await fault({ mismatch: false });
  assert.equal(invoke(["reconcile", "group-3"], { SERVICE_URL: line.service_url }).value.outcome, "ticketed");
  assert.equal((await (await fetch(`${line.control_url}/effects`)).json()).count, 6);

  console.log("lifecycle tests passed");
} finally {
  provider.kill("SIGTERM");
  await rm(state, { recursive: true, force: true });
}
