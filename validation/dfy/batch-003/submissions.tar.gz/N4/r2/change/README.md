# Conference seat-hold desk

This is a Node 22 command-line desk backed by the Ikaros 0.5.0 runtime. Each invocation is one process and writes exactly one JSON object to stdout.

## Setup

From this directory, use the supplied offline packages (no registry access is needed):

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

The included `run` launcher is executable and uses Node 22. Set `STATE_DIR` to a durable directory. Commands that contact the provider also require `SERVICE_URL`; clock-sensitive commands require `NOW_MS`.

```sh
export STATE_DIR="$PWD/.state"
export SERVICE_URL="http://127.0.0.1:49600"
export NOW_MS=1000
./run section hall-a 3
./run hold h1 hall-a A1 5000
./run hold group-1 hall-a A2 A3 5000
./run issue group-1
```

The provider is the supplied `stub/server.mjs`; it prints its service URL as its first JSON line. Keep any manually started server on permitted loopback ports 49600–49609, or let the supplied stub choose its ephemeral port.

## Commands

```text
./run section <section_id> <capacity>
./run hold <hold_id> <section_id> <seat_id> [seat_id...] <deadline_ms>
./run issue <hold_id>
./run release <hold_id> [seat_id...]
./run expire <hold_id>
./run status <hold_id>
./run section-status <section_id>
./run reconcile <hold_id>
```

Seat lists are canonicalized in sorted order and must not contain duplicates. A hold with more than one seat is issued as one provider request containing the complete list. `release` without seat ids releases all remaining seats; with seat ids it atomically releases a strict non-empty subset while the hold is still `held`.

`CRASH_AT` can be set to one of `after-hold-saved-before-request`, `after-accept-before-record`, or `after-record-before-exit` when exercising recovery. The desk never retries an uncertain provider request with a new request id; `reconcile` uses lookup only.

## Lifecycle checks

The current group-capable machine definition is `hold.ik.toml`. `hold_v1.ik.toml` is retained so stores created by the previous single-seat machine remain loadable and continue to use their original machine identity. With dependencies installed, inspect them with:

```sh
node_modules/@ikaros/darwin-arm64/bin/ik identity hold.ik.toml
node_modules/@ikaros/darwin-arm64/bin/ik check hold.ik.toml --corpus hold.ik.cases.json
node_modules/@ikaros/darwin-arm64/bin/ik identity hold_v1.ik.toml
```

The application uses `desk.json` for the section/index projection and `kernel.db` for durable hold lifecycle authority. It writes only those files under `STATE_DIR`; unrelated files are not touched.
