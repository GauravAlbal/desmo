import { promises as fs } from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { Kernel, HistoricalResult, TransportError } from "@ikaros/runtime";

const STATE_DIR = process.env.STATE_DIR;
const SERVICE_URL = (process.env.SERVICE_URL || "").replace(/\/$/, "");
const ROOT = path.dirname(new URL(import.meta.url).pathname);
const MACHINE_PATH = path.join(ROOT, "hold.ik.toml");
const LEGACY_MACHINE_PATH = path.join(ROOT, "hold_v1.ik.toml");
const STATE_FILE = STATE_DIR ? path.join(STATE_DIR, "desk.json") : null;

const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const SEAT_RE = /^[A-Za-z0-9._-]{1,32}$/;
const UINT_RE = /^(0|[1-9][0-9]*)$/;
const MAX_SAFE = Number.MAX_SAFE_INTEGER;

function fail(error) {
  const e = new Error(error);
  e.code = error;
  throw e;
}

function parseId(value, seat = false) {
  if (typeof value !== "string" || !(seat ? SEAT_RE : ID_RE).test(value)) fail("bad_id");
  return value;
}

function parseInteger(value, error, max) {
  if (typeof value !== "string" || !UINT_RE.test(value)) fail(error);
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n > max) fail(error);
  return n;
}

function nowMs(required = true) {
  if (process.env.NOW_MS === undefined) {
    if (required) fail("bad_args");
    return Date.now();
  }
  return parseInteger(process.env.NOW_MS, "bad_args", MAX_SAFE);
}

function jsonSafe(value) {
  if (typeof value === "bigint") return Number(value);
  if (Array.isArray(value)) return value.map(jsonSafe);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, jsonSafe(v)]));
  }
  return value;
}

function decodeSeats(value) {
  if (Array.isArray(value)) return value.slice();
  if (typeof value !== "string") fail("unavailable");
  let seats;
  try {
    seats = JSON.parse(value);
  } catch {
    fail("unavailable");
  }
  if (!Array.isArray(seats) || seats.some((seat) => typeof seat !== "string")) fail("unavailable");
  return seats;
}

function canonicalSeats(seats) {
  return seats.slice().sort();
}

function sameSeats(left, right) {
  const a = canonicalSeats(left);
  const b = canonicalSeats(right);
  return a.length === b.length && a.every((seat, index) => seat === b[index]);
}

function resultFor(aggregate) {
  const raw = jsonSafe(aggregate.raw);
  const state = raw.state || {};
  let seatIds;
  if (state.seat_ids !== undefined) seatIds = decodeSeats(state.seat_ids);
  else if (state.seat_id !== undefined) seatIds = [state.seat_id];
  else seatIds = [];
  return {
    hold_id: aggregate.id,
    section_id: state.section_id,
    seat_ids: seatIds,
    deadline_ms: state.deadline_ms,
    state: state.state,
    request_id: state.request_id ?? null,
    ticket_id: state.ticket_id ?? null,
  };
}

function isLive(state) {
  return state === "held" || state === "attempt_saved" || state === "ticketed";
}

function machineVersion(meta) {
  return meta?.machine_version === 2 ? 2 : 1;
}

function machineFor(machines, meta) {
  return machineVersion(meta) === 2 ? machines.v2 : machines.v1;
}

async function loadData() {
  if (!STATE_DIR) fail("bad_args");
  await fs.mkdir(STATE_DIR, { recursive: true });
  try {
    const text = await fs.readFile(STATE_FILE, "utf8");
    const data = JSON.parse(text);
    if (!data || typeof data !== "object" || !data.sections || !data.holds) fail("unavailable");
    return data;
  } catch (error) {
    if (error.code === "ENOENT") return { sections: {}, holds: {} };
    if (error.code === "unavailable") throw error;
    fail("unavailable");
  }
}

async function saveData(data) {
  const tmp = `${STATE_FILE}.${process.pid}.${crypto.randomBytes(6).toString("hex")}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(data) + "\n", { mode: 0o600 });
  await fs.rename(tmp, STATE_FILE);
}

function crashAt(label) {
  if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL");
}

async function openMachines() {
  const kernel = new Kernel(path.join(STATE_DIR, "kernel.db"));
  const [v1, v2] = await Promise.all([kernel.machine(LEGACY_MACHINE_PATH), kernel.machine(MACHINE_PATH)]);
  return { kernel, v1, v2 };
}

async function showHold(machines, holdId, meta) {
  try {
    return await machineFor(machines, meta).show(holdId);
  } catch (error) {
    const message = String(error?.message || "");
    if (message.includes("aggregate.not_found") || message.includes("not found") || error?.code === "IK_ILLEGAL_STATE") fail("unknown_hold");
    throw error;
  }
}

function holdRecord(data, holdId, aggregate, version, options = {}) {
  const item = resultFor(aggregate);
  const previous = data.holds[holdId] || {};
  if (version === 2) {
    data.holds[holdId] = {
      machine_version: 2,
      section_id: item.section_id,
      seat_ids: canonicalSeats(item.seat_ids),
      all_seat_ids: canonicalSeats(previous.all_seat_ids ?? previous.seat_ids ?? item.seat_ids),
      released_seat_ids: options.releasedSeatIds ?? previous.released_seat_ids ?? [],
    };
  } else {
    data.holds[holdId] = { section_id: item.section_id, seat_id: item.seat_ids[0] };
  }
  return item;
}

async function expireOne(machines, data, holdId, aggregate, current) {
  const meta = data.holds[holdId];
  const version = machineVersion(meta);
  const obj = resultFor(aggregate);
  if (obj.state === "held" && obj.deadline_ms <= current) {
    try {
      aggregate = await aggregate.command("expire");
    } catch (error) {
      if (error?.code === "IK_CAPABILITY_STALE") aggregate = await showHold(machines, holdId, meta);
      else throw error;
    }
    holdRecord(data, holdId, aggregate, version);
  }
  return aggregate;
}

async function expireDue(machines, data, current) {
  let changed = false;
  for (const holdId of Object.keys(data.holds)) {
    let aggregate = await showHold(machines, holdId, data.holds[holdId]);
    const before = resultFor(aggregate);
    if (before.state === "held" && before.deadline_ms <= current) {
      await expireOne(machines, data, holdId, aggregate, current);
      changed = true;
    }
  }
  if (changed) await saveData(data);
}

function ensureSection(data, sectionId) {
  if (!data.sections[sectionId]) fail("unknown_section");
  return data.sections[sectionId];
}

async function providerRequest(method, url, body) {
  if (!SERVICE_URL) fail("unavailable");
  let response;
  try {
    response = await fetch(`${SERVICE_URL}${url}`, {
      method,
      headers: body === undefined ? {} : { "content-type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    fail("unavailable");
  }
  let parsed;
  try {
    parsed = await response.json();
  } catch {
    fail("unavailable");
  }
  return { status: response.status, body: parsed };
}

function matchingTicket(body, expected) {
  if (!body || body.request_id !== expected.request_id || body.hold_id !== expected.hold_id || body.section_id !== expected.section_id || !Array.isArray(body.seat_ids) || !sameSeats(body.seat_ids, expected.seat_ids) || typeof body.ticket_id !== "string") fail("conflict");
  return body;
}

async function lookupProvider(requestId, expected) {
  const response = await providerRequest("GET", `/v1/tickets/${encodeURIComponent(requestId)}`);
  if (response.status === 404) return null;
  if (response.status !== 200) fail("unavailable");
  return matchingTicket(response.body, expected);
}

async function postProvider(expected) {
  const response = await providerRequest("POST", "/v1/tickets", {
    request_id: expected.request_id,
    hold_id: expected.hold_id,
    section_id: expected.section_id,
    seat_ids: expected.seat_ids,
  });
  if (response.status === 409) fail("conflict");
  if (response.status !== 200) fail("unavailable");
  return matchingTicket(response.body, expected);
}

async function adopt(machine, aggregate, expected, ticket) {
  return aggregate.command("adopt_ticket", { request_id: expected.request_id, ticket_id: ticket.ticket_id });
}

function liveSeatCount(items, sectionId) {
  return items.reduce((total, item) => total + (isLive(item.state) && item.section_id === sectionId ? item.seat_ids.length : 0), 0);
}

async function commandSection(args) {
  if (args.length !== 3) fail("bad_args");
  const data = await loadData();
  const sectionId = parseId(args[1]);
  const capacity = parseInteger(args[2], "bad_capacity", 100000);
  const existing = data.sections[sectionId];
  if (existing && existing.capacity !== capacity) fail("conflict");
  const machines = await openMachines();
  await expireDue(machines, data, nowMs());
  if (existing) {
    const items = [];
    for (const holdId of Object.keys(data.holds)) items.push(resultFor(await showHold(machines, holdId, data.holds[holdId])));
    const held = liveSeatCount(items, sectionId);
    return { section_id: sectionId, capacity, held, available: capacity - held };
  }
  data.sections[sectionId] = { capacity };
  await saveData(data);
  return { section_id: sectionId, capacity, held: 0, available: capacity };
}

async function commandHold(args) {
  if (args.length < 5) fail("bad_args");
  const data = await loadData();
  const holdId = parseId(args[1]);
  const sectionId = parseId(args[2]);
  const rawSeats = args.slice(3, -1);
  const seatIds = rawSeats.map((seat) => parseId(seat, true));
  if (new Set(seatIds).size !== seatIds.length) fail("bad_args");
  const sortedSeats = canonicalSeats(seatIds);
  const deadline = parseInteger(args.at(-1), "bad_deadline", MAX_SAFE);
  const current = nowMs();
  const machines = await openMachines();
  await expireDue(machines, data, current);
  const existingMeta = data.holds[holdId];
  if (existingMeta) {
    const existing = await showHold(machines, holdId, existingMeta);
    const obj = resultFor(existing);
    if (obj.section_id !== sectionId || !sameSeats(obj.seat_ids, sortedSeats) || obj.deadline_ms !== deadline) fail("conflict");
    return obj;
  }
  const section = ensureSection(data, sectionId);
  const occupied = new Set();
  const items = [];
  for (const id of Object.keys(data.holds)) {
    const item = resultFor(await showHold(machines, id, data.holds[id]));
    items.push(item);
    if (isLive(item.state) && item.section_id === sectionId) item.seat_ids.forEach((seat) => occupied.add(seat));
  }
  if (sortedSeats.some((seat) => occupied.has(seat))) fail("seat_taken");
  if (liveSeatCount(items, sectionId) + sortedSeats.length > section.capacity) fail("capacity_exceeded");

  let aggregate;
  try {
    const created = await machines.v2.createWith({
      aggregateId: holdId,
      command: { name: "initialize", args: { section_id: sectionId, seat_ids: JSON.stringify(sortedSeats), deadline_ms: deadline } },
    });
    aggregate = created instanceof HistoricalResult ? await showHold(machines, holdId, { machine_version: 2 }) : created;
  } catch (error) {
    if (error?.code === "IK_AGGREGATE_EXISTS" || String(error?.message || "").includes("already exists")) fail("conflict");
    throw error;
  }
  holdRecord(data, holdId, aggregate, 2);
  await saveData(data);
  return resultFor(aggregate);
}

async function commandStatus(args, sectionStatus = false) {
  if (args.length !== 2) fail("bad_args");
  const data = await loadData();
  const id = parseId(args[1]);
  if (sectionStatus) ensureSection(data, id);
  const machines = await openMachines();
  await expireDue(machines, data, nowMs());
  if (sectionStatus) {
    const section = data.sections[id];
    const items = [];
    for (const holdId of Object.keys(data.holds)) items.push(resultFor(await showHold(machines, holdId, data.holds[holdId])));
    const held = liveSeatCount(items, id);
    return { section_id: id, capacity: section.capacity, held, available: section.capacity - held };
  }
  const aggregate = await showHold(machines, id, data.holds[id]);
  const item = holdRecord(data, id, aggregate, machineVersion(data.holds[id]));
  await saveData(data);
  return item;
}

async function commandRelease(args) {
  if (args.length < 2) fail("bad_args");
  const data = await loadData();
  const holdId = parseId(args[1]);
  const requested = args.slice(2).map((seat) => parseId(seat, true));
  if (new Set(requested).size !== requested.length) fail("bad_args");
  const machines = await openMachines();
  const meta = data.holds[holdId];
  let aggregate = await showHold(machines, holdId, meta);
  const version = machineVersion(meta);
  const before = resultFor(aggregate);
  const current = nowMs();
  if (before.state === "held" && before.deadline_ms <= current) {
    aggregate = await aggregate.command("expire");
    holdRecord(data, holdId, aggregate, version);
    await saveData(data);
    return resultFor(aggregate);
  }
  if (before.state === "attempt_saved" || before.state === "ticketed") fail("release_open");
  if (requested.length === 0) {
    if (before.state === "released" || before.state === "expired") return before;
    if (version === 1) {
      aggregate = await aggregate.command("release");
      holdRecord(data, holdId, aggregate, version);
    } else {
      aggregate = await aggregate.command("release");
      holdRecord(data, holdId, aggregate, version, { releasedSeatIds: canonicalSeats(before.seat_ids) });
    }
    await saveData(data);
    return resultFor(aggregate);
  }
  if (before.state !== "held") {
    const released = meta?.released_seat_ids || [];
    if (requested.some((seat) => released.includes(seat))) fail("already_released");
    fail("unknown_seat");
  }
  if (version === 1) fail("unknown_seat");
  const originalSeats = meta?.all_seat_ids || meta?.seat_ids || before.seat_ids;
  const released = meta?.released_seat_ids || [];
  for (const seat of requested) {
    if (!originalSeats.includes(seat)) fail("unknown_seat");
    if (released.includes(seat) || !before.seat_ids.includes(seat)) fail("already_released");
  }
  if (requested.length === before.seat_ids.length) fail("bad_args");
  const remaining = before.seat_ids.filter((seat) => !requested.includes(seat));
  aggregate = await aggregate.command("release_subset", { seat_ids: JSON.stringify(canonicalSeats(remaining)) });
  holdRecord(data, holdId, aggregate, version, { releasedSeatIds: canonicalSeats([...released, ...requested]) });
  await saveData(data);
  return resultFor(aggregate);
}

async function commandExpire(args) {
  if (args.length !== 2) fail("bad_args");
  const data = await loadData();
  const holdId = parseId(args[1]);
  const machines = await openMachines();
  const meta = data.holds[holdId];
  let aggregate = await showHold(machines, holdId, meta);
  const version = machineVersion(meta);
  const before = resultFor(aggregate);
  const current = nowMs();
  if (before.state === "released" || before.state === "expired") return before;
  if (before.state === "attempt_saved" || before.state === "ticketed") fail("release_open");
  if (before.deadline_ms > current) fail("not_due");
  aggregate = await aggregate.command("expire");
  holdRecord(data, holdId, aggregate, version);
  await saveData(data);
  return resultFor(aggregate);
}

function providerExpected(item, holdId) {
  return { request_id: item.request_id, hold_id: holdId, section_id: item.section_id, seat_ids: canonicalSeats(item.seat_ids) };
}

async function commandIssue(args) {
  if (args.length !== 2) fail("bad_args");
  const data = await loadData();
  const holdId = parseId(args[1]);
  const machines = await openMachines();
  const meta = data.holds[holdId];
  const machine = machineFor(machines, meta);
  const version = machineVersion(meta);
  const current = nowMs();
  let aggregate = await showHold(machines, holdId, meta);
  let expected = resultFor(aggregate);
  if (expected.section_id && !data.sections[expected.section_id]) fail("unknown_section");
  if (expected.state === "held" && expected.deadline_ms <= current) {
    aggregate = await aggregate.command("expire");
    holdRecord(data, holdId, aggregate, version);
    await saveData(data);
    fail("expired");
  }
  if (expected.state === "expired") fail("expired");
  if (expected.state === "released") fail("released");
  if (expected.state === "ticketed") return expected;
  if (expected.state !== "attempt_saved" && expected.state !== "held") fail("unavailable");
  if (expected.state === "held") {
    const requestId = crypto.randomUUID().replace(/[^A-Za-z0-9._-]/g, "");
    try {
      aggregate = await aggregate.command("save_attempt", { request_id: requestId });
    } catch (error) {
      if (error instanceof TransportError) aggregate = await showHold(machines, holdId, meta);
      else throw error;
    }
    expected = resultFor(aggregate);
    if (expected.state !== "attempt_saved") {
      if (expected.state === "ticketed") return expected;
      fail("unavailable");
    }
    holdRecord(data, holdId, aggregate, version);
    await saveData(data);
    crashAt("after-hold-saved-before-request");
  }
  const provider = providerExpected(expected, holdId);
  let ticket = await lookupProvider(expected.request_id, provider);
  if (!ticket) ticket = await postProvider(provider);
  crashAt("after-accept-before-record");
  aggregate = await adopt(machine, aggregate, provider, ticket);
  holdRecord(data, holdId, aggregate, version);
  await saveData(data);
  crashAt("after-record-before-exit");
  return resultFor(aggregate);
}

async function commandReconcile(args) {
  if (args.length !== 2) fail("bad_args");
  const data = await loadData();
  const holdId = parseId(args[1]);
  const machines = await openMachines();
  const meta = data.holds[holdId];
  let aggregate = await showHold(machines, holdId, meta);
  const item = resultFor(aggregate);
  if (item.state === "ticketed") return { outcome: "ticketed", ...item };
  if (item.state !== "attempt_saved") return { outcome: "not_applicable" };
  const expected = providerExpected(item, holdId);
  const ticket = await lookupProvider(item.request_id, expected);
  if (!ticket) return { outcome: "not_sent" };
  aggregate = await adopt(machineFor(machines, meta), aggregate, expected, ticket);
  holdRecord(data, holdId, aggregate, machineVersion(meta));
  await saveData(data);
  return { outcome: "ticketed", ...resultFor(aggregate) };
}

async function main() {
  const args = process.argv.slice(2);
  if (args.length < 1) fail("bad_args");
  switch (args[0]) {
    case "section": return commandSection(args);
    case "hold": return commandHold(args);
    case "issue": return commandIssue(args);
    case "release": return commandRelease(args);
    case "expire": return commandExpire(args);
    case "status": return commandStatus(args);
    case "section-status": return commandStatus(args, true);
    case "reconcile": return commandReconcile(args);
    default: fail("bad_args");
  }
}

try {
  const value = await main();
  process.stdout.write(JSON.stringify(jsonSafe(await value)) + "\n");
} catch (error) {
  const code = error?.code && typeof error.code === "string" ? error.code : "unavailable";
  process.stdout.write(JSON.stringify({ error: code }) + "\n");
  process.exitCode = 1;
}
