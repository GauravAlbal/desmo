import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";

const root = path.dirname(new URL(import.meta.url).pathname);
const state = mkdtempSync(path.join(tmpdir(), "seat-desk-test-"));
const envBase = { ...process.env, STATE_DIR: state, NOW_MS: "1000" };
function runEnv(envExtra, ...args) {
  const result = spawnSync("./run", args, { cwd: root, env: { ...envBase, ...envExtra }, encoding: "utf8" });
  const lines = result.stdout.trim().split(/\n/).filter(Boolean);
  const value = lines.length ? JSON.parse(lines.at(-1)) : null;
  return { ...result, value };
}

function run(...args) {
  return runEnv({}, ...args);
}

const stub = spawn(process.execPath, ["stub/server.mjs"], { cwd: root, stdio: ["ignore", "pipe", "inherit"] });
const firstLine = await new Promise((resolve, reject) => {
  let text = "";
  stub.stdout.on("data", (chunk) => {
    text += chunk;
    const line = text.split("\n")[0];
    if (line) resolve(JSON.parse(line));
  });
  stub.once("error", reject);
});
const service = firstLine.service_url;
const control = firstLine.control_url;
const runWithService = (...args) => runEnv({ SERVICE_URL: service }, ...args);
function effects() {
  return JSON.parse(spawnSync("curl", ["-sS", `${control}/effects`], { encoding: "utf8" }).stdout);
}

try {
  assert.equal(run("section", "hall", "4").value.available, 4);
  assert.equal(run("hold", "pre", "hall", "A1", "5000").value.state, "held");
  assert.equal(run("status", "pre").value.state, "held", "state survives a new process");

  const crash = spawnSync("./run", ["issue", "pre"], { cwd: root, env: { ...envBase, SERVICE_URL: service, CRASH_AT: "after-hold-saved-before-request" }, encoding: "utf8" });
  assert.notEqual(crash.status, 0);
  assert.equal(run("status", "pre").value.state, "attempt_saved");
  assert.equal(effects().count, 0);
  assert.equal(runWithService("reconcile", "pre").value.outcome, "not_sent");
  assert.equal(runWithService("issue", "pre").value.state, "ticketed");

  assert.equal(run("hold", "accepted", "hall", "A2", "5000").value.state, "held");
  const acceptedCrash = spawnSync("./run", ["issue", "accepted"], { cwd: root, env: { ...envBase, SERVICE_URL: service, CRASH_AT: "after-accept-before-record" }, encoding: "utf8" });
  assert.notEqual(acceptedCrash.status, 0);
  assert.equal(runWithService("reconcile", "accepted").value.outcome, "ticketed");

  assert.equal(run("hold", "recorded", "hall", "A3", "5000").value.state, "held");
  const recordedCrash = spawnSync("./run", ["issue", "recorded"], { cwd: root, env: { ...envBase, SERVICE_URL: service, CRASH_AT: "after-record-before-exit" }, encoding: "utf8" });
  assert.notEqual(recordedCrash.status, 0);
  assert.equal(runWithService("issue", "recorded").value.state, "ticketed");

  assert.equal(run("hold", "dropped", "hall", "A4", "5000").value.state, "held");
  spawnSync("curl", ["-sS", "-X", "POST", "-H", "content-type: application/json", "-d", '{"drop_reply":true}', `${control}/fault`]);
  const dropped = runWithService("issue", "dropped");
  assert.equal(dropped.value.error, "unavailable");
  spawnSync("curl", ["-sS", "-X", "POST", "-H", "content-type: application/json", "-d", '{"drop_reply":false}', `${control}/fault`]);
  assert.equal(runWithService("reconcile", "dropped").value.outcome, "ticketed");

  assert.equal(run("hold", "pre", "hall", "A1", "5000").value.state, "ticketed");
  assert.equal(run("hold", "other", "hall", "A1", "5000").value.error, "seat_taken");
  assert.equal(run("section", "hall", "4").value.available, 0);

  assert.equal(run("section", "groups", "4").value.available, 4);
  assert.deepEqual(run("hold", "g1", "groups", "A2", "A1", "5000").value.seat_ids, ["A1", "A2"]);
  assert.deepEqual(run("status", "g1").value.seat_ids, ["A1", "A2"]);
  assert.equal(run("hold", "g2", "groups", "A2", "A3", "5000").value.error, "seat_taken");
  assert.deepEqual(run("section-status", "groups").value, { section_id: "groups", capacity: 4, held: 2, available: 2 });

  assert.deepEqual(run("release", "g1", "A1").value, {
    hold_id: "g1", section_id: "groups", seat_ids: ["A2"], deadline_ms: 5000,
    state: "held", request_id: null, ticket_id: null,
  });
  assert.deepEqual(run("section-status", "groups").value, { section_id: "groups", capacity: 4, held: 1, available: 3 });
  assert.deepEqual(run("hold", "g2", "groups", "A1", "A3", "5000").value.seat_ids, ["A1", "A3"]);
  assert.equal(run("release", "g1").value.state, "released");
  assert.deepEqual(run("hold", "g3", "groups", "A2", "A4", "5000").value.seat_ids, ["A2", "A4"]);

  const groupIssue = runWithService("issue", "g2");
  assert.deepEqual(groupIssue.value.seat_ids, ["A1", "A3"]);
  assert.equal(groupIssue.value.state, "ticketed");
  assert.deepEqual(runWithService("issue", "g2").value, groupIssue.value, "ticketed group is idempotent");
  const groupEffect = effects();
  assert.equal(groupEffect.count, 5);
  assert.deepEqual(groupEffect.effects.at(-1).seat_ids, ["A1", "A3"]);
  assert.equal(run("release", "g2", "A1").value.error, "release_open");
  assert.equal(run("release", "g3", "A2", "A4").value.error, "bad_args");
  assert.equal(run("release", "g3", "A2").value.state, "held");
  assert.equal(run("release", "g3", "A2").value.error, "already_released");
  assert.deepEqual(run("status", "g3").value.seat_ids, ["A4"]);
  assert.equal(run("release", "g3", "A4").value.error, "bad_args");
  assert.equal(run("release", "g3").value.state, "released");

  assert.equal(runEnv({ NOW_MS: "5000" }, "hold", "late", "groups", "A2", "5000").value.state, "held");
  assert.equal(runEnv({ NOW_MS: "5000" }, "issue", "late").value.error, "expired");
  assert.equal(run("status", "late").value.state, "expired");
  console.log("recovery and group tests passed");
} finally {
  stub.kill("SIGTERM");
  rmSync(state, { recursive: true, force: true });
}
