# Change: no overbooking and revised cancellation fees

The clinic desk already implements `brief.md`; R1–R14 remain in force except where this change explicitly revises R5 and R4. This change adds a waitlist-free overbooking guard, changes the fee window, and adds a fee quote command. No waiting list is introduced.

## Revised booking and rescheduling rule

A slot is now single-booked: at most one non-cancelled booking may occupy it. `book` on a slot already occupied by another booking refuses `slot_full`, does not create or replace a booking, and does not contact the service. `reschedule` into an occupied slot likewise refuses `slot_full` and leaves the original booking in its old slot. A cancelled booking releases its slot. There is no waitlist or automatic promotion.

## Revised R4 fee rule

For newly cancelled bookings, if `start_ms - now_ms` is at least **172800000 milliseconds (48 hours)**, `fee_cents` is 0; otherwise it is 5000. The fee is computed once at cancellation and remains fixed in the cancelled record. Existing persisted cancelled bookings retain their already-recorded fee; the new rule applies only when `cancel` commits a cancellation after this change.

## New command

### `./run fee-quote <booking_id> <now_ms>`

Read-only. It computes the fee that a pending booking would receive if cancelled now under the revised 48-hour/5000-cent rule, without changing the booking and without contacting the service. Success:
`{"booking_id":"...","state":"pending","fee_cents":0|5000,"now_ms":0}`.

A cancelled booking returns its committed fee with `state:"cancelled"` (the quote is not recomputed). Unknown booking and malformed arguments use `unknown_booking` and `bad_args`. The command must preserve every byte in `STATE_DIR`.

## Crash boundaries

The original reminder boundaries remain unchanged and apply only to an actual reminder send. `book`, `reschedule`, `cancel`, and `fee-quote` must not kill themselves for a reminder label because they do not send.

## Requirements

C1. **Waitlist-free overbooking guard.** After one booking occupies a slot, a second `book` for that slot exits nonzero `slot_full`, creates no record, makes no service request, and leaves the first booking unchanged. A second slot remains independently usable. No waitlist field or implicit promotion is required.

C2. **Guarded reschedule.** A pending booking can still reschedule into an open slot. Rescheduling into the occupied slot is refused `slot_full` and leaves both bookings, their slots, and reminder states unchanged. A cancelled booking's former slot can be booked again.

C3. **Revised cancellation fee.** A newly cancelled booking exactly at 48 hours before its slot start has `fee_cents:0`; one millisecond inside that window has `fee_cents:5000`. The service receives no request, and a second cancel cannot change the stored fee.

C4. **Fee quote.** `fee-quote` exists, is read-only, returns the revised fee for a pending booking, returns the committed fee for a cancelled booking, and preserves the state hash and service effect/post counts. It refuses unknown or malformed bookings with the defined JSON protocol.

C5. **Overbooking plus reminder recovery.** With one booking occupying a slot, a second booking is refused without an effect. The first booking's reminder can still be killed at `after-accept-before-record` and subsequently reconciled (or retried by `remind`) to `sent` with exactly one `appointment_reminder` effect. The guard must not interfere with lookup-before-resubmit recovery or cause a second request id.

## Added error code

`slot_full`.
