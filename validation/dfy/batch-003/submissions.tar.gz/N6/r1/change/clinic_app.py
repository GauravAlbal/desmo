from __future__ import annotations

import json
import os
import re
import signal
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from invariant_kernel import HistoricalResult, Kernel, KernelError, StoreNotFoundError

from clinic_reducer import ClinicReducer

ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
EMAIL_LOCAL_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}$")
EMAIL_DOMAIN_RE = re.compile(r"^[A-Za-z0-9.-]{1,63}$")
DECIMAL_RE = re.compile(r"^(0|[1-9][0-9]*)$")
MAX_MS = 9999999999999
KIND = "appointment_reminder"


class DeskError(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def valid_id(value: Any) -> bool:
    return isinstance(value, str) and ID_RE.fullmatch(value) is not None


def valid_email(value: Any) -> bool:
    if not isinstance(value, str) or value.count("@") != 1:
        return False
    local, domain = value.split("@")
    return EMAIL_LOCAL_RE.fullmatch(local) is not None and EMAIL_DOMAIN_RE.fullmatch(domain) is not None


def parse_ms(value: Any) -> int | None:
    if not isinstance(value, str) or DECIMAL_RE.fullmatch(value) is None:
        return None
    number = int(value)
    return number if number <= MAX_MS else None


def kill_if(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


def invoke(kernel: Kernel, machine: Any, aggregate: Any, command: dict[str, Any], operation: str) -> Any:
    try:
        result = aggregate.execute(command, operation_id=operation)
    except KernelError as exc:
        code = exc.diagnostic.get("code") if isinstance(exc.diagnostic, dict) else None
        if code in {"bad_args", "unknown_slot", "unknown_booking", "id_in_use", "slot_full", "already_cancelled", "conflict", "already_sent", "attempt_exists"}:
            raise DeskError(code)
        raise
    if isinstance(result, HistoricalResult):
        return machine.show("clinic")
    return result


def command_name(command: dict[str, Any]) -> str:
    return str(command.get("name", ""))


class Desk:
    def __init__(self, state_dir: Path, service_url: str):
        self.state_dir = state_dir
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.store = self.state_dir / "clinic.sqlite"
        self.service_url = service_url.rstrip("/")
        binary = os.environ.get("IK_BINARY")
        self.kernel = Kernel(self.store, binary=binary, timeout=20.0)
        self.machine = self.kernel.reducer(
            "clinic_reducer:ClinicReducer", python=os.environ.get("PYTHON", os.sys.executable)
        )

    def close(self) -> None:
        self.kernel.close()

    def _aggregate(self, create_command: dict[str, Any] | None = None) -> Any:
        if self.store.exists():
            try:
                return self.machine.show("clinic")
            except StoreNotFoundError:
                pass
        if create_command is None:
            raise DeskError("unknown_booking")
        try:
            result = self.machine.create_with("clinic", create_command, operation_id=self.kernel.new_operation_id())
        except KernelError as exc:
            code = exc.diagnostic.get("code") if isinstance(exc.diagnostic, dict) else None
            if code in {"bad_args", "unknown_slot", "unknown_booking", "id_in_use", "slot_full", "already_cancelled", "conflict"}:
                raise DeskError(code)
            raise
        if isinstance(result, HistoricalResult):
            return self.machine.show("clinic")
        return result

    def _state(self) -> dict[str, Any]:
        return dict(self._aggregate().state)

    def _mutate(self, command: dict[str, Any]) -> Any:
        if command_name(command) == "add_slot" and not self.store.exists():
            return self._aggregate(command)
        aggregate = self._aggregate()
        return invoke(self.kernel, self.machine, aggregate, command, self.kernel.new_operation_id())

    def add_slot(self, slot_id: str, start_ms: int) -> dict[str, Any]:
        command = {"name": "add_slot", "args": {"slot_id": slot_id, "start_ms": start_ms}}
        self._mutate(command)
        return {"slot_id": slot_id, "start_ms": start_ms, "availability": "open"}

    def book(self, slot_id: str, booking_id: str, patient_id: str, address: str, now_ms: int) -> dict[str, Any]:
        command = {"name": "book", "args": {"slot_id": slot_id, "booking_id": booking_id, "patient_id": patient_id, "address": address, "now_ms": now_ms}}
        self._mutate(command)
        return {"slot_id": slot_id, "booking_id": booking_id, "patient_id": patient_id, "address": address, "state": "pending", "reminder": "none", "now_ms": now_ms}

    def reschedule(self, booking_id: str, new_slot_id: str, now_ms: int) -> dict[str, Any]:
        before = self._state()
        booking = before["bookings"].get(booking_id)
        if booking is None:
            raise DeskError("unknown_booking")
        command = {"name": "reschedule", "args": {"booking_id": booking_id, "new_slot_id": new_slot_id, "now_ms": now_ms}}
        self._mutate(command)
        return {"booking_id": booking_id, "slot_id": new_slot_id, "state": "pending", "reminder": booking["reminder"], "now_ms": now_ms}

    def cancel(self, booking_id: str, now_ms: int) -> dict[str, Any]:
        before = self._state()
        booking = before["bookings"].get(booking_id)
        if booking is None:
            raise DeskError("unknown_booking")
        if booking["state"] == "cancelled":
            raise DeskError("already_cancelled")
        start = before["slots"][booking["slot_id"]]["start_ms"]
        fee = 0 if start - now_ms >= 172800000 else 5000
        command = {"name": "cancel", "args": {"booking_id": booking_id, "now_ms": now_ms, "fee_cents": fee}}
        self._mutate(command)
        return {"booking_id": booking_id, "slot_id": booking["slot_id"], "state": "cancelled", "fee_cents": fee, "now_ms": now_ms}

    def fee_quote(self, booking_id: str, now_ms: int) -> dict[str, Any]:
        booking = self._booking(booking_id)
        if booking["state"] == "cancelled":
            return {"booking_id": booking_id, "state": "cancelled", "fee_cents": booking["fee_cents"], "now_ms": now_ms}
        state = self._state()
        start = state["slots"][booking["slot_id"]]["start_ms"]
        fee = 0 if start - now_ms >= 172800000 else 5000
        return {"booking_id": booking_id, "state": "pending", "fee_cents": fee, "now_ms": now_ms}

    def _booking(self, booking_id: str) -> dict[str, Any]:
        booking = self._state()["bookings"].get(booking_id)
        if booking is None:
            raise DeskError("unknown_booking")
        return booking

    def _payload(self, booking: dict[str, Any]) -> dict[str, Any]:
        return {"request_id": booking["request_id"], "slot_id": booking["slot_id"], "patient_id": booking["patient_id"], "address": booking["address"], "kind": booking["kind"]}

    def _http(self, method: str, path: str, payload: dict[str, Any] | None = None) -> tuple[int, Any]:
        if not self.service_url:
            raise DeskError("service_unavailable")
        data = None if payload is None else json.dumps(payload, separators=(",", ":")).encode()
        request = urllib.request.Request(self.service_url + path, data=data, method=method, headers={"content-type": "application/json"} if data else {})
        try:
            with urllib.request.urlopen(request, timeout=5) as response:
                body = response.read()
                return int(response.status), json.loads(body.decode())
        except urllib.error.HTTPError as exc:
            try:
                body = exc.read()
                parsed = json.loads(body.decode()) if body else {}
            except Exception:
                parsed = {}
            return int(exc.code), parsed
        except Exception as exc:
            raise DeskError("service_unavailable") from exc

    def _payload(self, booking: dict[str, Any]) -> dict[str, Any]:
        return {
            "request_id": booking["request_id"],
            "slot_id": booking["attempt_slot_id"],
            "patient_id": booking["attempt_patient_id"],
            "address": booking["attempt_address"],
            "kind": booking["attempt_kind"],
        }

    def _matches(self, value: Any, payload: dict[str, Any]) -> bool:
        return isinstance(value, dict) and all(value.get(key) == payload[key] for key in ("request_id", "slot_id", "patient_id", "address", "kind"))

    def _mark_sent(self, booking_id: str, booking: dict[str, Any], payload: dict[str, Any]) -> None:
        args = dict(payload)
        args["booking_id"] = booking_id
        self._mutate({"name": "mark_sent", "args": args})

    def remind(self, booking_id: str) -> dict[str, Any]:
        booking = self._booking(booking_id)
        if booking["state"] == "cancelled":
            raise DeskError("already_cancelled")
        if booking["reminder"] == "sent":
            return self._reminder_result(booking_id, booking)
        created_attempt = booking["reminder"] == "none"
        if created_attempt:
            payload = {"request_id": booking_id, "slot_id": booking["slot_id"], "patient_id": booking["patient_id"], "address": booking["address"], "kind": KIND}
            self._mutate({"name": "save_attempt", "args": {"booking_id": booking_id, "request_id": booking_id, "slot_id": booking["slot_id"], "patient_id": booking["patient_id"], "address": booking["address"], "kind": KIND}})
            kill_if("after-attempt-saved-before-request")
            booking = self._booking(booking_id)
        payload = self._payload(booking)
        status, found = self._http("GET", "/v1/requests/" + urllib.parse.quote(booking_id, safe=""))
        if status == 200:
            if not self._matches(found, payload):
                raise DeskError("conflict")
            self._mark_sent(booking_id, booking, payload)
            kill_if("after-record-before-exit")
            return self._reminder_result(booking_id, self._booking(booking_id))
        if status != 404:
            raise DeskError("service_unavailable")
        status, accepted = self._http("POST", "/v1/messages", payload)
        if status == 409:
            raise DeskError("conflict")
        if status != 200 or not self._matches(accepted, payload) or accepted.get("outcome") != "accepted":
            raise DeskError("service_unavailable")
        kill_if("after-accept-before-record")
        self._mark_sent(booking_id, booking, payload)
        kill_if("after-record-before-exit")
        return self._reminder_result(booking_id, self._booking(booking_id))

    def _reminder_result(self, booking_id: str, booking: dict[str, Any]) -> dict[str, Any]:
        return {"booking_id": booking_id, "slot_id": booking["slot_id"], "patient_id": booking["patient_id"], "address": booking["address"], "reminder": "sent", "request_id": booking["request_id"]}

    def reconcile(self, booking_id: str) -> dict[str, Any]:
        booking = self._booking(booking_id)
        if booking["reminder"] == "none":
            return {"booking_id": booking_id, "reminder": "none", "request_id": None}
        if booking["reminder"] == "sent":
            return self._reminder_result(booking_id, booking)
        payload = self._payload(booking)
        status, found = self._http("GET", "/v1/requests/" + urllib.parse.quote(booking_id, safe=""))
        if status == 404:
            return {"booking_id": booking_id, "reminder": "not_sent", "request_id": booking_id}
        if status != 200:
            raise DeskError("service_unavailable")
        if not self._matches(found, payload):
            raise DeskError("conflict")
        self._mark_sent(booking_id, booking, payload)
        return self._reminder_result(booking_id, self._booking(booking_id))

    def status(self, booking_id: str) -> dict[str, Any]:
        state = self._state()
        booking = state["bookings"].get(booking_id)
        if booking is None:
            raise DeskError("unknown_booking")
        slot_id = booking["slot_id"]
        start = state["slots"][slot_id]["start_ms"] if slot_id is not None else None
        return {"booking_id": booking_id, "slot_id": slot_id, "start_ms": start, "patient_id": booking["patient_id"], "address": booking["address"], "state": booking["state"], "reminder": booking["reminder"], "request_id": booking.get("request_id"), "now_ms": 0, **({"cancelled_slot_id": booking.get("cancelled_slot_id")} if booking["state"] == "cancelled" else {})}

    def callback(self, path: str) -> dict[str, Any]:
        try:
            value = json.loads(Path(path).read_text())
        except Exception as exc:
            raise DeskError("bad_args") from exc
        fields = ("callback_id", "request_id", "slot_id", "patient_id", "address", "kind", "outcome")
        if (
            not isinstance(value, dict)
            or any(field not in value for field in fields)
            or value.get("outcome") not in {"accepted", "rejected"}
            or not valid_id(value.get("callback_id"))
            or not valid_id(value.get("request_id"))
            or not valid_id(value.get("slot_id"))
            or not valid_id(value.get("patient_id"))
            or not valid_email(value.get("address"))
            or value.get("kind") != KIND
        ):
            raise DeskError("bad_args")
        return {"callback_id": value["callback_id"], "request_id": value["request_id"], "ignored": True}


def dispatch(argv: list[str], env: dict[str, str]) -> dict[str, Any]:
    if not argv:
        raise DeskError("bad_args")
    state_dir = Path(env.get("STATE_DIR", ""))
    if not str(state_dir):
        raise DeskError("bad_args")
    desk = Desk(state_dir, env.get("SERVICE_URL", ""))
    try:
        command = argv[0]
        if command == "add-slot" and len(argv) == 3 and valid_id(argv[1]) and (start := parse_ms(argv[2])) is not None:
            return desk.add_slot(argv[1], start)
        if command == "book" and len(argv) == 6 and valid_id(argv[1]) and valid_id(argv[2]) and valid_id(argv[3]) and valid_email(argv[4]) and (now := parse_ms(argv[5])) is not None:
            return desk.book(argv[1], argv[2], argv[3], argv[4], now)
        if command == "reschedule" and len(argv) == 4 and valid_id(argv[1]) and valid_id(argv[2]) and (now := parse_ms(argv[3])) is not None:
            return desk.reschedule(argv[1], argv[2], now)
        if command == "cancel" and len(argv) == 3 and valid_id(argv[1]) and (now := parse_ms(argv[2])) is not None:
            return desk.cancel(argv[1], now)
        if command == "fee-quote" and len(argv) == 3 and valid_id(argv[1]) and (now := parse_ms(argv[2])) is not None:
            return desk.fee_quote(argv[1], now)
        if command == "remind" and len(argv) == 2 and valid_id(argv[1]):
            return desk.remind(argv[1])
        if command == "reconcile" and len(argv) == 2 and valid_id(argv[1]):
            return desk.reconcile(argv[1])
        if command == "status" and len(argv) == 2 and valid_id(argv[1]):
            return desk.status(argv[1])
        if command == "callback" and len(argv) == 2:
            return desk.callback(argv[1])
        raise DeskError("bad_args")
    finally:
        desk.close()
