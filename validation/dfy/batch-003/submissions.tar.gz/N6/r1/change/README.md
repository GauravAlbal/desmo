# Clinic appointment desk

The desk is a Python standard-library CLI. Lifecycle state is persisted by the
packed Ikaros runtime through `clinic_reducer.py`; `STATE_DIR/clinic.sqlite` is
owned by the desk. Other files in `STATE_DIR` are not read or rewritten.

## Setup

Node is only needed for the supplied fake service. Python setup is local and
requires no registry access:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
chmod +x run
```

`./run` locates `.venv/bin/python` and the packed `KIT/bin/ik` automatically.
It accepts `STATE_DIR`, `SERVICE_URL`, and optional `CRASH_AT`; no other setup
is needed after the commands above. `SERVICE_URL` is the stub's
`service_url`, without a trailing slash:

```sh
node stub/server.mjs
STATE_DIR=/tmp/clinic-state SERVICE_URL=http://127.0.0.1:PORT ./run add-slot room-a 1730000000
```

Commands, including the read-only `fee-quote <booking_id> <now_ms>` command, and JSON result/error shapes are defined in `BRIEF.md` and `CHANGE.md`.

## Verification

The focused test script uses a loopback fake service and exercises restart
persistence, both crash labels, lost-reply reconciliation, overbooking and
reschedule refusals, fee boundaries and read-only quotes, and unrelated-file
preservation:

```sh
.venv/bin/python tests/test_clinic.py
```
