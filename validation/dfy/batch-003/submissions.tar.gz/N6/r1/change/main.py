from __future__ import annotations

import json
import sys

from clinic_app import DeskError, dispatch


def main() -> int:
    try:
        result = dispatch(sys.argv[1:], dict(__import__("os").environ))
    except DeskError as exc:
        print(json.dumps({"error": exc.code}, separators=(",", ":")))
        return 1
    except Exception:
        print(json.dumps({"error": "service_unavailable"}, separators=(",", ":")))
        return 1
    print(json.dumps(result, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
