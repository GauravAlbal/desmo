from __future__ import annotations

from typing import Any, Mapping

from invariant_kernel import ApplyOutcome, Decision, DomainEvent, ReducerDiagnostic, ReducerIdentity
from invariant_kernel.reducer import thaw


_HEX = "0" * 64


class ClinicReducer:
    identity = ReducerIdentity(
        reducer_name="clinic_appointment_desk",
        reducer_version=1,
        code_digest=_HEX,
        command_schema_digest=_HEX,
        state_schema_digest=_HEX,
    )

    def initial_state(self) -> Any:
        return {"slots": {}, "bookings": {}}

    def decide(
        self, state: Any, observation: Any, effect: Any, command: Any
    ) -> Decision | ReducerDiagnostic:
        del observation, effect
        data = thaw(state)
        request = thaw(command)
        if not isinstance(request, dict) or not isinstance(request.get("name"), str):
            return ReducerDiagnostic("bad_args", "command name is required")
        name = request["name"]
        args = request.get("args", {})
        if not isinstance(args, dict):
            return ReducerDiagnostic("bad_args", "command args must be an object")
        diagnostic = self._validate(data, name, args)
        if diagnostic is not None:
            return diagnostic
        return Decision.emit(DomainEvent("clinic.command", 1, {"name": name, "args": args}))

    def apply(self, state: Any, event: DomainEvent) -> ApplyOutcome | ReducerDiagnostic:
        data = thaw(state)
        if event.event_type != "clinic.command" or event.event_version != 1:
            return ReducerDiagnostic("bad_args", "unknown clinic event")
        payload = thaw(event.payload)
        if not isinstance(payload, dict) or not isinstance(payload.get("name"), str):
            return ReducerDiagnostic("bad_args", "malformed clinic event")
        name = payload["name"]
        args = payload.get("args", {})
        self._apply(data, name, args)
        return ApplyOutcome.new(data)

    def _validate(self, data: dict[str, Any], name: str, args: dict[str, Any]) -> ReducerDiagnostic | None:
        slots = data["slots"]
        bookings = data["bookings"]
        if name == "add_slot":
            sid, start = args.get("slot_id"), args.get("start_ms")
            if not isinstance(sid, str) or type(start) is not int:
                return ReducerDiagnostic("bad_args", "invalid slot")
            if sid in slots or sid in bookings:
                return ReducerDiagnostic("id_in_use", "identifier already exists")
            return None
        if name == "book":
            sid, bid = args.get("slot_id"), args.get("booking_id")
            if sid not in slots:
                return ReducerDiagnostic("unknown_slot", "slot does not exist")
            if bid in slots or bid in bookings:
                return ReducerDiagnostic("id_in_use", "identifier already exists")
            if any(
                booking.get("state") != "cancelled" and booking.get("slot_id") == sid
                for booking in bookings.values()
            ):
                return ReducerDiagnostic("slot_full", "slot is already booked")
            return None
        if name in {"reschedule", "cancel", "save_attempt", "mark_sent"}:
            bid = args.get("booking_id")
            booking = bookings.get(bid)
            if booking is None:
                return ReducerDiagnostic("unknown_booking", "booking does not exist")
            if name in {"reschedule", "cancel"} and booking["state"] == "cancelled":
                return ReducerDiagnostic("already_cancelled", "booking is cancelled")
            if name == "reschedule":
                new_slot_id = args.get("new_slot_id")
                if new_slot_id not in slots:
                    return ReducerDiagnostic("unknown_slot", "slot does not exist")
                if any(
                    other_id != bid
                    and other.get("state") != "cancelled"
                    and other.get("slot_id") == new_slot_id
                    for other_id, other in bookings.items()
                ):
                    return ReducerDiagnostic("slot_full", "slot is already booked")
            if name == "save_attempt":
                if booking["state"] == "cancelled":
                    return ReducerDiagnostic("already_cancelled", "booking is cancelled")
                if booking["reminder"] == "sent":
                    return ReducerDiagnostic("already_sent", "reminder is already sent")
                if booking["reminder"] == "attempt_saved":
                    return ReducerDiagnostic("attempt_exists", "reminder attempt exists")
            if name == "mark_sent":
                if booking["state"] == "cancelled":
                    return ReducerDiagnostic("already_cancelled", "booking is cancelled")
                if booking["reminder"] != "attempt_saved":
                    return ReducerDiagnostic("conflict", "reminder attempt is not saved")
                for field in ("slot_id", "patient_id", "address", "kind", "request_id"):
                    expected = booking.get("attempt_" + field) if field != "request_id" else booking.get("request_id")
                    if args.get(field) != expected:
                        return ReducerDiagnostic("conflict", "accepted request does not match attempt")
                if args.get("kind") != "appointment_reminder":
                    return ReducerDiagnostic("conflict", "accepted request kind does not match")
            return None
        return ReducerDiagnostic("bad_args", "unknown command")

    def _apply(self, data: dict[str, Any], name: str, args: dict[str, Any]) -> None:
        slots = data["slots"]
        bookings = data["bookings"]
        if name == "add_slot":
            slots[args["slot_id"]] = {"start_ms": args["start_ms"]}
        elif name == "book":
            bookings[args["booking_id"]] = {
                "slot_id": args["slot_id"],
                "patient_id": args["patient_id"],
                "address": args["address"],
                "state": "pending",
                "reminder": "none",
                "now_ms": args["now_ms"],
            }
        elif name == "reschedule":
            bookings[args["booking_id"]]["slot_id"] = args["new_slot_id"]
            bookings[args["booking_id"]]["now_ms"] = args["now_ms"]
        elif name == "cancel":
            booking = bookings[args["booking_id"]]
            booking["cancelled_slot_id"] = booking["slot_id"]
            booking["cancelled_start_ms"] = slots[booking["slot_id"]]["start_ms"]
            booking["slot_id"] = None
            booking["state"] = "cancelled"
            booking["fee_cents"] = args["fee_cents"]
            booking["now_ms"] = args["now_ms"]
        elif name == "save_attempt":
            booking = bookings[args["booking_id"]]
            booking.update({
                "reminder": "attempt_saved",
                "request_id": args["request_id"],
                "attempt_slot_id": args["slot_id"],
                "attempt_patient_id": args["patient_id"],
                "attempt_address": args["address"],
                "attempt_kind": args["kind"],
            })
        elif name == "mark_sent":
            bookings[args["booking_id"]]["reminder"] = "sent"
