from __future__ import annotations

import json
import os
import signal
import subprocess
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class FakeService:
    def __init__(self) -> None:
        self.records: dict[str, dict[str, str]] = {}
        self.effects: list[str] = []
        self.drop_reply = False

    def handler(self):
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args):
                pass

            def send_json(self, status: int, body: dict[str, str]) -> None:
                raw = json.dumps(body).encode()
                self.send_response(status)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self):
                if self.path.startswith("/v1/requests/"):
                    request_id = self.path.rsplit("/", 1)[-1]
                    value = owner.records.get(request_id)
                    self.send_json(200 if value else 404, value or {"error": "not_found"})
                else:
                    self.send_json(404, {"error": "not_found"})

            def do_POST(self):
                if self.path != "/v1/messages":
                    self.send_json(404, {"error": "not_found"})
                    return
                size = int(self.headers.get("content-length", "0"))
                value = json.loads(self.rfile.read(size))
                request_id = value["request_id"]
                old = owner.records.get(request_id)
                if old is not None:
                    if any(old[key] != value[key] for key in ("slot_id", "patient_id", "address", "kind")):
                        self.send_json(409, {"error": "conflict"})
                        return
                    result = old
                else:
                    result = dict(value)
                    result["outcome"] = "accepted"
                    owner.records[request_id] = result
                    owner.effects.append(request_id)
                if owner.drop_reply:
                    self.close_connection = True
                    return
                self.send_json(200, result)

        return Handler


class ClinicTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.service = FakeService()
        cls.server = ThreadingHTTPServer(("127.0.0.1", 51501), cls.service.handler())
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.url = "http://127.0.0.1:51501"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.state = Path(self.tmp.name)
        (self.state / "unrelated.bin").write_bytes(b"preserve\x00bytes")
        self.service.records.clear()
        self.service.effects.clear()
        self.service.drop_reply = False

    def tearDown(self):
        self.tmp.cleanup()

    def run_cli(self, *args: str, crash: str | None = None) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ)
        env.update({"STATE_DIR": str(self.state), "SERVICE_URL": self.url, "IK_BINARY": str(ROOT / "KIT/bin/ik")})
        if crash is not None:
            env["CRASH_AT"] = crash
        else:
            env.pop("CRASH_AT", None)
        return subprocess.run([str(ROOT / "run"), *args], env=env, text=True, capture_output=True)

    def result(self, *args: str, crash: str | None = None) -> dict:
        completed = self.run_cli(*args, crash=crash)
        self.assertEqual(completed.returncode, 0, completed.stderr + completed.stdout)
        return json.loads(completed.stdout)

    def prepare(self, slot: str, booking: str) -> None:
        self.result("add-slot", slot, "100000")
        self.result("book", slot, booking, "patient", "patient@example.com", "0")

    def test_restart_and_unrelated_bytes(self):
        self.prepare("room", "booking")
        self.assertEqual(self.result("status", "booking")["slot_id"], "room")
        self.assertEqual((self.state / "unrelated.bin").read_bytes(), b"preserve\x00bytes")
        self.assertNotEqual(self.run_cli("add-slot", "bad!", "1").returncode, 0)
        self.assertEqual((self.state / "unrelated.bin").read_bytes(), b"preserve\x00bytes")

    def test_crash_before_request(self):
        self.prepare("room", "before")
        crashed = self.run_cli("remind", "before", crash="after-attempt-saved-before-request")
        self.assertEqual(crashed.returncode, -signal.SIGKILL)
        self.assertEqual(self.result("status", "before")["reminder"], "attempt_saved")
        self.assertEqual(self.service.effects, [])
        self.result("remind", "before")
        self.assertEqual(self.service.effects, ["before"])

    def test_crash_after_accept_and_lost_reply(self):
        self.prepare("room", "accepted")
        crashed = self.run_cli("remind", "accepted", crash="after-accept-before-record")
        self.assertEqual(crashed.returncode, -signal.SIGKILL)
        self.assertEqual(self.result("status", "accepted")["reminder"], "attempt_saved")
        self.result("remind", "accepted")
        self.assertEqual(self.service.effects, ["accepted"])

        self.prepare("room2", "lost")
        self.service.drop_reply = True
        failed = self.run_cli("remind", "lost")
        self.assertNotEqual(failed.returncode, 0)
        self.assertEqual(json.loads(failed.stdout)["error"], "service_unavailable")
        self.service.drop_reply = False
        self.result("reconcile", "lost")
        self.assertEqual(self.service.effects, ["accepted", "lost"])

    def test_overbooking_reschedule_guard_and_fee_quote(self):
        self.result("add-slot", "room", "172800000")
        self.result("add-slot", "room2", "200000")
        self.result("book", "room", "first", "patient", "patient@example.com", "0")

        refused = self.run_cli("book", "room", "second", "patient2", "second@example.com", "0")
        self.assertNotEqual(refused.returncode, 0)
        self.assertEqual(json.loads(refused.stdout)["error"], "slot_full")
        self.assertEqual(self.result("status", "first")["slot_id"], "room")

        self.result("book", "room2", "second", "patient2", "second@example.com", "0")
        refused = self.run_cli("reschedule", "second", "room", "0")
        self.assertNotEqual(refused.returncode, 0)
        self.assertEqual(json.loads(refused.stdout)["error"], "slot_full")
        self.assertEqual(self.result("status", "second")["slot_id"], "room2")
        unknown = self.run_cli("fee-quote", "missing", "0")
        self.assertNotEqual(unknown.returncode, 0)
        self.assertEqual(json.loads(unknown.stdout)["error"], "unknown_booking")
        malformed = self.run_cli("fee-quote", "first", "+1")
        self.assertNotEqual(malformed.returncode, 0)
        self.assertEqual(json.loads(malformed.stdout)["error"], "bad_args")

        before = {path.name: path.read_bytes() for path in self.state.iterdir()}
        self.assertEqual(self.result("fee-quote", "first", "0"), {
            "booking_id": "first", "state": "pending", "fee_cents": 0, "now_ms": 0,
        })
        self.assertEqual(self.result("fee-quote", "first", "1"), {
            "booking_id": "first", "state": "pending", "fee_cents": 5000, "now_ms": 1,
        })
        after = {path.name: path.read_bytes() for path in self.state.iterdir()}
        self.assertEqual(after, before)

        self.assertEqual(self.result("cancel", "first", "0")["fee_cents"], 0)
        self.assertEqual(self.result("fee-quote", "first", "999")["fee_cents"], 0)
        self.assertEqual(self.result("reschedule", "second", "room", "0")["slot_id"], "room")
        self.assertEqual(self.result("book", "room2", "third", "patient3", "third@example.com", "0")["state"], "pending")


if __name__ == "__main__":
    unittest.main()
