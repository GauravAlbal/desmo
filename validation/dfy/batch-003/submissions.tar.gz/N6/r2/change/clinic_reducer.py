from __future__ import annotations

import copy
import hashlib
import re
from typing import Any, Mapping, Optional

from invariant_kernel import ApplyOutcome, Decision, DomainEvent, ReducerDiagnostic, ReducerIdentity

_ID = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
_EMAIL = re.compile(r"^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$")
_DECIMAL = re.compile(r"^(0|[1-9][0-9]*)$")
_MAX_MS = 9999999999999
_KIND = "appointment_reminder"


def _digest(label: str) -> str:
    return hashlib.sha256(label.encode("ascii")).hexdigest()


def _plain(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, tuple):
        return [_plain(v) for v in value]
    return value


def _bad(message: str) -> ReducerDiagnostic:
    return ReducerDiagnostic("bad_args", message)


def _text(value: Any, pattern: re.Pattern[str]) -> bool:
    return isinstance(value, str) and pattern.fullmatch(value) is not None


def _time(value: Any) -> bool:
    if not isinstance(value, str) or _DECIMAL.fullmatch(value) is None:
        return False
    return int(value) <= _MAX_MS

def _args(command: Mapping[str, Any]) -> Optional[Mapping[str, Any]]:
    if not isinstance(command, Mapping) or set(command) != {"name", "args"}:
        return None
    if not isinstance(command["name"], str) or not isinstance(command["args"], Mapping):
        return None
    return command["args"]


class ClinicReducer:
    identity = ReducerIdentity(
        "clinic_lifecycle",
        1,
        _digest("clinic_lifecycle/code/1"),
        _digest("clinic_lifecycle/commands/1"),
        _digest("clinic_lifecycle/state/1"),
    )

    def initial_state(self) -> Any:
        return {"slots": {}, "bookings": {}}

    def decide(self, state: Any, observation: Any, effect: Any, command: Any) -> Decision | ReducerDiagnostic:
        del state, observation, effect
        args = _args(command)
        if args is None:
            return _bad("command must contain name and args")
        name = command["name"]
        expected = {
            "add_slot": {"slot_id", "start_ms"},
            "book": {"slot_id", "booking_id", "patient_id", "address", "now_ms"},
            "reschedule": {"booking_id", "new_slot_id", "now_ms"},
            "cancel": {"booking_id", "now_ms"},
            "save_attempt": {"booking_id"},
            "mark_sent": {"booking_id"},
        }.get(name)
        if expected is None or set(args) != expected:
            return _bad("malformed command arguments")
        for key, value in args.items():
            pattern = _EMAIL if key == "address" else _ID
            if key in {"slot_id", "booking_id", "new_slot_id", "patient_id"} and not _text(value, pattern):
                return _bad("malformed identifier")
            if key == "address" and not _text(value, _EMAIL):
                return _bad("malformed address")
            if key in {"start_ms", "now_ms"} and not _time(value):
                return _bad("malformed time")
        return Decision.emit(DomainEvent("clinic_command", 1, _plain(command)))

    def apply(self, state: Any, event: DomainEvent) -> ApplyOutcome | ReducerDiagnostic:
        if event.event_type != "clinic_command" or event.event_version != 1:
            return ReducerDiagnostic("bad_args", "unknown lifecycle event")
        command = _plain(event.payload)
        args = command["args"]
        name = command["name"]
        next_state = copy.deepcopy(_plain(state))
        slots = next_state.setdefault("slots", {})
        bookings = next_state.setdefault("bookings", {})

        if name == "add_slot":
            sid = args["slot_id"]
            if sid in slots or sid in bookings:
                return ReducerDiagnostic("id_in_use", "identifier already exists")
            slots[sid] = {"start_ms": int(args["start_ms"]), "availability": "open"}
        elif name == "book":
            sid, bid = args["slot_id"], args["booking_id"]
            if sid not in slots:
                return ReducerDiagnostic("unknown_slot", "slot does not exist")
            if bid in slots or bid in bookings:
                return ReducerDiagnostic("id_in_use", "identifier already exists")
            if any(
                other.get("state") != "cancelled" and other.get("slot_id") == sid
                for other in bookings.values()
            ):
                return ReducerDiagnostic("slot_full", "slot is already occupied")
            slot = slots[sid]
            bookings[bid] = {
                "slot_id": sid,
                "start_ms": slot["start_ms"],
                "patient_id": args["patient_id"],
                "address": args["address"],
                "state": "pending",
                "reminder": "none",
                "request_id": None,
                "attempt": None,
                "now_ms": int(args["now_ms"]),
            }
        elif name == "reschedule":
            bid, sid = args["booking_id"], args["new_slot_id"]
            if bid not in bookings:
                return ReducerDiagnostic("unknown_booking", "booking does not exist")
            booking = bookings[bid]
            if booking["state"] == "cancelled":
                return ReducerDiagnostic("already_cancelled", "booking is cancelled")
            if sid not in slots:
                return ReducerDiagnostic("unknown_slot", "slot does not exist")
            if any(
                other_id != bid
                and other.get("state") != "cancelled"
                and other.get("slot_id") == sid
                for other_id, other in bookings.items()
            ):
                return ReducerDiagnostic("slot_full", "slot is already occupied")
            booking["slot_id"] = sid
            booking["start_ms"] = slots[sid]["start_ms"]
        elif name == "cancel":
            bid = args["booking_id"]
            if bid not in bookings:
                return ReducerDiagnostic("unknown_booking", "booking does not exist")
            booking = bookings[bid]
            if booking["state"] == "cancelled":
                return ReducerDiagnostic("already_cancelled", "booking is cancelled")
            booking["cancelled_slot_id"] = booking["slot_id"]
            booking["slot_id"] = None
            booking["state"] = "cancelled"
            booking["fee_cents"] = 0 if booking["start_ms"] - int(args["now_ms"]) >= 172800000 else 5000
        elif name == "save_attempt":
            bid = args["booking_id"]
            if bid not in bookings:
                return ReducerDiagnostic("unknown_booking", "booking does not exist")
            booking = bookings[bid]
            if booking["state"] == "cancelled":
                return ReducerDiagnostic("already_cancelled", "booking is cancelled")
            if booking["reminder"] == "none":
                booking["reminder"] = "attempt_saved"
                booking["request_id"] = bid
                booking["attempt"] = {
                    "request_id": bid,
                    "slot_id": booking["slot_id"],
                    "patient_id": booking["patient_id"],
                    "address": booking["address"],
                    "kind": _KIND,
                }
        elif name == "mark_sent":
            bid = args["booking_id"]
            if bid not in bookings:
                return ReducerDiagnostic("unknown_booking", "booking does not exist")
            booking = bookings[bid]
            if booking["state"] == "cancelled":
                return ReducerDiagnostic("already_cancelled", "booking is cancelled")
            if booking["reminder"] == "attempt_saved":
                booking["reminder"] = "sent"
            elif booking["reminder"] != "sent":
                return ReducerDiagnostic("conflict", "no saved reminder attempt")
        return ApplyOutcome.new(next_state)
