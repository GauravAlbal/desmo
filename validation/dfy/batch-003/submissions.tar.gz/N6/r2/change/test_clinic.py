import json
import os
import signal
import subprocess
import tempfile
import unittest


ROOT = os.path.dirname(os.path.abspath(__file__))


class ClinicSmoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = subprocess.Popen(
            ["node", "stub/server.mjs"],
            cwd=ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        line = cls.server.stdout.readline()
        cls.service_url = json.loads(line)["service_url"]

    @classmethod
    def tearDownClass(cls):
        cls.server.send_signal(signal.SIGTERM)
        cls.server.wait(timeout=5)

    def setUp(self):
        self.state = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.state.cleanup()

    def run_cli(self, *args, crash_at=None):
        env = dict(os.environ, STATE_DIR=self.state.name, SERVICE_URL=self.service_url)
        if crash_at is not None:
            env["CRASH_AT"] = crash_at
        else:
            env.pop("CRASH_AT", None)
        return subprocess.run(["./run", *args], cwd=ROOT, env=env, text=True, capture_output=True)

    def test_restart_and_pre_request_crash(self):
        self.assertEqual(self.run_cli("add-slot", "room", "2000000000000").returncode, 0)
        self.assertEqual(self.run_cli("book", "room", "b", "p", "p@example.com", "0").returncode, 0)
        crashed = self.run_cli("remind", "b", crash_at="after-attempt-saved-before-request")
        self.assertNotEqual(crashed.returncode, 0)
        saved = json.loads(self.run_cli("status", "b").stdout)
        self.assertEqual(saved["reminder"], "attempt_saved")
        self.assertEqual(json.loads(self.run_cli("remind", "b").stdout)["reminder"], "sent")
        self.assertEqual(json.loads(self.run_cli("status", "b").stdout)["reminder"], "sent")

    def test_lost_reply_reconcile_does_not_post_again(self):
        self.assertEqual(self.run_cli("add-slot", "room", "2000000000000").returncode, 0)
        self.assertEqual(self.run_cli("book", "room", "b", "p", "p@example.com", "0").returncode, 0)
        crashed = self.run_cli("remind", "b", crash_at="after-accept-before-record")
        self.assertNotEqual(crashed.returncode, 0)
        reconciled = json.loads(self.run_cli("reconcile", "b").stdout)
        self.assertEqual(reconciled["reminder"], "sent")
        self.assertEqual(json.loads(self.run_cli("remind", "b").stdout)["reminder"], "sent")

    def test_fee_and_cancel_persistence(self):
        self.assertEqual(self.run_cli("add-slot", "room", "100").returncode, 0)
        self.assertEqual(self.run_cli("book", "room", "b", "p", "p@example.com", "0").returncode, 0)
        result = json.loads(self.run_cli("cancel", "b", "0").stdout)
        self.assertEqual(result["fee_cents"], 5000)
        repeat = self.run_cli("cancel", "b", "0")
        self.assertNotEqual(repeat.returncode, 0)
        self.assertEqual(json.loads(self.run_cli("status", "b").stdout)["state"], "cancelled")

    def test_overbooking_guard_and_released_slot(self):
        self.assertEqual(self.run_cli("add-slot", "room", "1000000000000").returncode, 0)
        self.assertEqual(self.run_cli("add-slot", "room2", "2000000000000").returncode, 0)
        self.assertEqual(self.run_cli("book", "room", "b1", "p1", "p1@example.com", "0").returncode, 0)

        full = self.run_cli("book", "room", "b2", "p2", "p2@example.com", "0")
        self.assertNotEqual(full.returncode, 0)
        self.assertEqual(json.loads(full.stdout)["error"], "slot_full")
        self.assertEqual(json.loads(self.run_cli("status", "b1").stdout)["slot_id"], "room")

        self.assertEqual(self.run_cli("book", "room2", "b2", "p2", "p2@example.com", "0").returncode, 0)
        full_reschedule = self.run_cli("reschedule", "b2", "room", "0")
        self.assertNotEqual(full_reschedule.returncode, 0)
        self.assertEqual(json.loads(full_reschedule.stdout)["error"], "slot_full")
        self.assertEqual(json.loads(self.run_cli("status", "b2").stdout)["slot_id"], "room2")

        self.assertEqual(self.run_cli("cancel", "b1", "0").returncode, 0)
        self.assertEqual(self.run_cli("book", "room", "b3", "p3", "p3@example.com", "0").returncode, 0)

    def test_fee_quote_is_read_only_and_uses_48_hours(self):
        self.assertEqual(self.run_cli("add-slot", "room", "172800000").returncode, 0)
        self.assertEqual(self.run_cli("book", "room", "b", "p", "p@example.com", "0").returncode, 0)
        store = os.path.join(self.state.name, "clinic.sqlite")
        with open(store, "rb") as handle:
            before = handle.read()
        exact = json.loads(self.run_cli("fee-quote", "b", "0").stdout)
        inside = json.loads(self.run_cli("fee-quote", "b", "1").stdout)
        self.assertEqual(exact["fee_cents"], 0)
        self.assertEqual(inside["fee_cents"], 5000)
        with open(store, "rb") as handle:
            after = handle.read()
        self.assertEqual(after, before)

        cancelled = json.loads(self.run_cli("cancel", "b", "0").stdout)
        self.assertEqual(cancelled["fee_cents"], 0)
        committed = json.loads(self.run_cli("fee-quote", "b", "9999999999999").stdout)
        self.assertEqual(committed, {"booking_id": "b", "state": "cancelled", "fee_cents": 0, "now_ms": 9999999999999})


if __name__ == "__main__":
    unittest.main()
