# Clinic appointment desk

The desk is a Python 3.9+ command line application. Durable lifecycle state is
stored by the supplied Ikaros runtime in `STATE_DIR/clinic.sqlite`; the
application uses its reducer API for every slot and booking transition.

## Setup

The checkout includes the released Ikaros wheel and binary. From this
directory, create the documented local environment:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
```

No npm package is required. `./run` locates `.venv/bin/python`, the wheel, and
`KIT/bin/ik` relative to the checkout; if the environment is absent, it
creates and installs the local wheel automatically. It can also run with an
explicit `PYTHON` or `IK_BINARY`.

## Running

Set `STATE_DIR` to a durable directory and `SERVICE_URL` to the stub service
base URL (without a trailing slash):

```sh
STATE_DIR=/tmp/clinic-state SERVICE_URL=http://127.0.0.1:PORT ./run add-slot room-a 1700000000000
STATE_DIR=/tmp/clinic-state SERVICE_URL=http://127.0.0.1:PORT ./run book room-a booking-a patient-a patient@example.com 1699900000000
STATE_DIR=/tmp/clinic-state SERVICE_URL=http://127.0.0.1:PORT ./run status booking-a
```

`book` and `reschedule` refuse with `slot_full` when a non-cancelled booking
already occupies the target slot. `cancel` now charges 0 cents only when the
appointment is at least 48 hours away, and 5000 cents otherwise; the value is
fixed in the cancelled record. Use the read-only fee quote command to preview
the current rule:

```sh
STATE_DIR=/tmp/clinic-state SERVICE_URL=http://127.0.0.1:PORT ./run fee-quote booking-a 1699900000000
```

Start the supplied fake service with `node stub/server.mjs`; it prints the
service URL. Every invocation emits exactly one JSON object. `CRASH_AT` may be
set to one of the crash labels from `BRIEF.md` to exercise recovery behavior.

The callback command reads one JSON file and intentionally treats a valid
callback as a hint only; reminder truth is established by service lookup.
