from __future__ import annotations

import json
import os
import re
import signal
import sys
import urllib.error
import urllib.request
import urllib.parse
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from invariant_kernel import Kernel, KernelError, HistoricalResult, TransportError

from clinic_reducer import _EMAIL, _ID, _MAX_MS, _DECIMAL

ROOT = Path(__file__).resolve().parent
STATE_DIR = Path(os.environ.get("STATE_DIR", str(ROOT / ".state")))
STORE = STATE_DIR / "clinic.sqlite"
SERVICE_URL = os.environ.get("SERVICE_URL", "").rstrip("/")
CRASH_AT = os.environ.get("CRASH_AT", "")
STATE_DIR.mkdir(parents=True, exist_ok=True)


def _die() -> None:
    os.kill(os.getpid(), signal.SIGKILL)


def _json(value: Any) -> None:
    sys.stdout.write(json.dumps(value, separators=(",", ":"), sort_keys=True) + "\n")


def _machine():
    binary = os.environ.get("IK_BINARY") or str(ROOT / "KIT" / "bin" / "ik")
    python = sys.executable
    kernel = Kernel(store=str(STORE), binary=binary)
    machine = kernel.reducer("clinic_reducer:ClinicReducer", python=python)
    return kernel, machine


def _state(machine) -> Optional[Tuple[Any, Dict[str, Any]]]:
    if not STORE.exists():
        return None
    try:
        aggregate = machine.show("clinic")
    except KernelError:
        return None
    return aggregate, aggregate.state


def _transition(machine, command: Dict[str, Any]):
    if STORE.exists():
        aggregate = machine.show("clinic")
        result = aggregate.execute(command)
    else:
        result = machine.create_with("clinic", command)
    if isinstance(result, HistoricalResult):
        return machine.show("clinic")
    return result


def _diagnostic_code(exc: Exception) -> str:
    allowed = (
        "bad_args",
        "unknown_slot",
        "unknown_booking",
        "id_in_use",
        "slot_full",
        "already_cancelled",
        "conflict",
        "service_unavailable",
    )
    for obj in (exc, getattr(exc, "diagnostic", None), getattr(exc, "details", None), getattr(exc, "raw", None)):
        if isinstance(obj, dict):
            for key in ("code", "diagnostic_code", "error"):
                value = obj.get(key)
                if value in allowed:
                    return value
        value = getattr(obj, "code", None)
        if value in allowed:
            return value
    text = str(exc)
    for code in allowed:
        if code in text:
            return code
    return "service_unavailable"


def _error(code: str) -> int:
    _json({"error": code})
    return 1


def _valid_id(value: str) -> bool:
    return isinstance(value, str) and _ID.fullmatch(value) is not None


def _valid_time(value: str) -> bool:
    return isinstance(value, str) and _DECIMAL.fullmatch(value) is not None and int(value) <= _MAX_MS


def _valid_address(value: str) -> bool:
    return isinstance(value, str) and _EMAIL.fullmatch(value) is not None


def _check(args: list[str], count: int) -> bool:
    return len(args) == count


def _booking(state: Dict[str, Any], booking_id: str) -> Optional[Dict[str, Any]]:
    return state.get("bookings", {}).get(booking_id)


def _success_for(command: str, result: Any, args: list[str]) -> Dict[str, Any]:
    state = result.state
    if command == "add-slot":
        slot = state["slots"][args[0]]
        return {"slot_id": args[0], "start_ms": slot["start_ms"], "availability": "open"}
    if command == "book":
        booking = state["bookings"][args[1]]
        return {"slot_id": booking["slot_id"], "booking_id": args[1], "patient_id": booking["patient_id"], "address": booking["address"], "state": booking["state"], "reminder": booking["reminder"], "now_ms": booking["now_ms"]}
    if command == "reschedule":
        booking = state["bookings"][args[0]]
        return {"booking_id": args[0], "slot_id": booking["slot_id"], "state": booking["state"], "reminder": booking["reminder"], "now_ms": int(args[2])}
    if command == "cancel":
        booking = state["bookings"][args[0]]
        return {"booking_id": args[0], "slot_id": None, "state": booking["state"], "fee_cents": booking["fee_cents"], "now_ms": int(args[1])}
    raise ValueError(command)


def _http(method: str, url: str, payload: Optional[Dict[str, Any]] = None) -> Tuple[Optional[int], Optional[Dict[str, Any]]]:
    data = None if payload is None else json.dumps(payload, separators=(",", ":")).encode("utf-8")
    request = urllib.request.Request(url, data=data, method=method)
    if data is not None:
        request.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            body = response.read()
            parsed = json.loads(body.decode("utf-8"))
            return response.status, parsed if isinstance(parsed, dict) else None
    except urllib.error.HTTPError as exc:
        try:
            body = exc.read()
            parsed = json.loads(body.decode("utf-8"))
            return exc.code, parsed if isinstance(parsed, dict) else None
        except Exception:
            return exc.code, None
    except Exception:
        return None, None


def _matching(attempt: Dict[str, Any], response: Optional[Dict[str, Any]]) -> bool:
    if not isinstance(response, dict):
        return False
    return all(response.get(k) == attempt.get(k) for k in ("request_id", "slot_id", "patient_id", "address", "kind"))


def _terminal_result(booking_id: str, attempt: Dict[str, Any]) -> Dict[str, Any]:
    return {"booking_id": booking_id, "slot_id": attempt["slot_id"], "patient_id": attempt["patient_id"], "address": attempt["address"], "reminder": "sent", "request_id": attempt["request_id"]}


def _remind(machine, booking_id: str) -> int:
    current = _state(machine)
    if current is None:
        return _error("unknown_booking")
    aggregate, state = current
    booking = _booking(state, booking_id)
    if booking is None:
        return _error("unknown_booking")
    if booking["state"] == "cancelled":
        return _error("already_cancelled")
    if booking["reminder"] == "sent":
        _json(_terminal_result(booking_id, booking["attempt"]))
        return 0
    if booking["reminder"] == "none":
        try:
            aggregate = _transition(machine, {"name": "save_attempt", "args": {"booking_id": booking_id}})
        except KernelError as exc:
            return _error(_diagnostic_code(exc))
        booking = aggregate.state["bookings"][booking_id]
        if CRASH_AT == "after-attempt-saved-before-request":
            _die()
    attempt = booking.get("attempt")
    if not isinstance(attempt, dict) or not SERVICE_URL:
        return _error("service_unavailable")
    status, response = _http("GET", SERVICE_URL + "/v1/requests/" + urllib.parse.quote(attempt["request_id"], safe=""))
    if status == 200:
        if not _matching(attempt, response):
            return _error("conflict")
        try:
            aggregate = _transition(machine, {"name": "mark_sent", "args": {"booking_id": booking_id}})
        except KernelError as exc:
            return _error(_diagnostic_code(exc))
        if CRASH_AT == "after-record-before-exit":
            _die()
        _json(_terminal_result(booking_id, attempt))
        return 0
    if status != 404:
        return _error("service_unavailable")
    status, response = _http("POST", SERVICE_URL + "/v1/messages", attempt)
    if status == 409:
        return _error("conflict")
    if status != 200 or not _matching(attempt, response) or response.get("outcome") != "accepted":
        return _error("service_unavailable")
    if CRASH_AT == "after-accept-before-record":
        _die()
    try:
        aggregate = _transition(machine, {"name": "mark_sent", "args": {"booking_id": booking_id}})
    except KernelError as exc:
        return _error(_diagnostic_code(exc))
    if CRASH_AT == "after-record-before-exit":
        _die()
    _json(_terminal_result(booking_id, attempt))
    return 0


def _reconcile(machine, booking_id: str) -> int:
    current = _state(machine)
    if current is None:
        return _error("unknown_booking")
    aggregate, state = current
    booking = _booking(state, booking_id)
    if booking is None:
        return _error("unknown_booking")
    if booking["state"] == "cancelled":
        return _error("already_cancelled")
    if booking["reminder"] == "none":
        _json({"booking_id": booking_id, "reminder": "none", "request_id": None})
        return 0
    attempt = booking["attempt"]
    if not SERVICE_URL:
        return _error("service_unavailable")
    status, response = _http("GET", SERVICE_URL + "/v1/requests/" + urllib.parse.quote(attempt["request_id"], safe=""))
    if status == 404:
        _json({"booking_id": booking_id, "reminder": "not_sent", "request_id": booking_id})
        return 0
    if status != 200:
        return _error("service_unavailable")
    if not _matching(attempt, response):
        return _error("conflict")
    if booking["reminder"] != "sent":
        try:
            _transition(machine, {"name": "mark_sent", "args": {"booking_id": booking_id}})
        except KernelError as exc:
            return _error(_diagnostic_code(exc))
    _json(_terminal_result(booking_id, attempt))
    return 0


def _status(machine, booking_id: str) -> int:
    current = _state(machine)
    if current is None:
        return _error("unknown_booking")
    _aggregate, state = current
    booking = _booking(state, booking_id)
    if booking is None:
        return _error("unknown_booking")
    out = {
        "booking_id": booking_id,
        "slot_id": booking["slot_id"],
        "start_ms": booking["start_ms"] if booking["slot_id"] is not None else None,
        "patient_id": booking["patient_id"],
        "address": booking["address"],
        "state": booking["state"],
        "reminder": booking["reminder"],
        "request_id": booking["request_id"],
        "now_ms": booking["now_ms"],
    }
    if "cancelled_slot_id" in booking:
        out["cancelled_slot_id"] = booking["cancelled_slot_id"]
    _json(out)
    return 0

def _fee_quote(machine, booking_id: str, now_ms: str) -> int:
    current = _state(machine)
    if current is None:
        return _error("unknown_booking")
    _aggregate, state = current
    booking = _booking(state, booking_id)
    if booking is None:
        return _error("unknown_booking")
    if booking["state"] == "cancelled":
        fee_cents = booking["fee_cents"]
        state_name = "cancelled"
    else:
        fee_cents = 0 if booking["start_ms"] - int(now_ms) >= 172800000 else 5000
        state_name = "pending"
    _json({"booking_id": booking_id, "state": state_name, "fee_cents": fee_cents, "now_ms": int(now_ms)})
    return 0


def _callback(path: str) -> int:
    try:
        with open(path, "rb") as handle:
            callback = json.loads(handle.read().decode("utf-8"))
        required = {"callback_id", "request_id", "slot_id", "patient_id", "address", "kind", "outcome"}
        if not isinstance(callback, dict) or set(callback) != required:
            return _error("bad_args")
        if not all(_valid_id(callback[k]) for k in ("callback_id", "request_id", "slot_id", "patient_id")) or not _valid_address(callback["address"]):
            return _error("bad_args")
        if callback["kind"] != "appointment_reminder" or callback["outcome"] not in {"accepted", "rejected"}:
            return _error("bad_args")
    except Exception:
        return _error("bad_args")
    _json({"callback_id": callback["callback_id"], "request_id": callback["request_id"], "accepted": True})
    return 0


def main(argv: list[str]) -> int:
    if not argv:
        return _error("bad_args")
    command, args = argv[0], argv[1:]
    try:
        kernel, machine = _machine()
        del kernel
        if command == "add-slot":
            if not _check(args, 2) or not _valid_id(args[0]) or not _valid_time(args[1]):
                return _error("bad_args")
            result = _transition(machine, {"name": "add_slot", "args": {"slot_id": args[0], "start_ms": args[1]}})
            _json(_success_for(command, result, args))
            return 0
        if command == "book":
            if not _check(args, 5) or not _valid_id(args[0]) or not _valid_id(args[1]) or not _valid_id(args[2]) or not _valid_address(args[3]) or not _valid_time(args[4]):
                return _error("bad_args")
            result = _transition(machine, {"name": "book", "args": {"slot_id": args[0], "booking_id": args[1], "patient_id": args[2], "address": args[3], "now_ms": args[4]}})
            _json(_success_for(command, result, args))
            return 0
        if command == "reschedule":
            if not _check(args, 3) or not _valid_id(args[0]) or not _valid_id(args[1]) or not _valid_time(args[2]):
                return _error("bad_args")
            result = _transition(machine, {"name": "reschedule", "args": {"booking_id": args[0], "new_slot_id": args[1], "now_ms": args[2]}})
            _json(_success_for(command, result, args))
            return 0
        if command == "cancel":
            if not _check(args, 2) or not _valid_id(args[0]) or not _valid_time(args[1]):
                return _error("bad_args")
            result = _transition(machine, {"name": "cancel", "args": {"booking_id": args[0], "now_ms": args[1]}})
            _json(_success_for(command, result, args))
            return 0
        if command == "fee-quote":
            if not _check(args, 2) or not _valid_id(args[0]) or not _valid_time(args[1]):
                return _error("bad_args")
            return _fee_quote(machine, args[0], args[1])
        if command == "remind":
            if not _check(args, 1) or not _valid_id(args[0]):
                return _error("bad_args")
            return _remind(machine, args[0])
        if command == "reconcile":
            if not _check(args, 1) or not _valid_id(args[0]):
                return _error("bad_args")
            return _reconcile(machine, args[0])
        if command == "status":
            if not _check(args, 1) or not _valid_id(args[0]):
                return _error("bad_args")
            return _status(machine, args[0])
        if command == "callback":
            if not _check(args, 1):
                return _error("bad_args")
            return _callback(args[0])
        return _error("bad_args")
    except KernelError as exc:
        return _error(_diagnostic_code(exc))
    except (OSError, ValueError, TypeError):
        return _error("service_unavailable")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
