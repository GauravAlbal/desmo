import { runCommand } from "./desk.mjs";

const result = await runCommand(process.env, process.argv.slice(2));
process.stdout.write(JSON.stringify(result.body) + "\n");
process.exit(result.ok ? 0 : 1);
