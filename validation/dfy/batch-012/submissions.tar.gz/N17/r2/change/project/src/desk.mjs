import { randomBytes } from "node:crypto";
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Kernel,
  StoreNotFoundError,
  classify,
} from "@ikaros/runtime";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const MACHINE_V1 = join(ROOT, "machines", "payout_desk.ik.toml");
const MACHINE_V2 = join(ROOT, "machines", "payout_desk_v2.ik.toml");
const AGGREGATE_ID = "desk";
const STORE_NAME = "payout.sqlite";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const MONEY_RE = /^(0|[1-9][0-9]*)$/;
const TIME_RE = /^(0|[1-9][0-9]*)$/;
const MAX_TIME = 9007199254740991;
const COMMANDS = new Set([
  "open",
  "edit-amount",
  "approve",
  "place-hold",
  "release-hold",
  "risk-clear",
  "pay",
  "reconcile",
  "status",
  "callback",
]);

class DomainError extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
}

function fail(code) {
  throw new DomainError(code);
}

function crashIf(env, label) {
  if ((env.CRASH_AT || "") === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

function parseNow(raw) {
  if (raw === undefined || raw === "") return null;
  if (!TIME_RE.test(raw)) return null;
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0 || n > MAX_TIME) return null;
  return n;
}

function parseId(raw) {
  return typeof raw === "string" && ID_RE.test(raw) ? raw : null;
}

function parseMoney(raw, { min } = { min: 0 }) {
  if (typeof raw !== "string" || !MONEY_RE.test(raw)) return null;
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < min) return null;
  return n;
}

function storePath(stateDir) {
  return join(stateDir, STORE_NAME);
}

function emptyStatus() {
  return {
    payout_id: null,
    merchant_id: null,
    amount_cents: null,
    fee_pct: null,
    review_span_ms: null,
    dual_threshold: null,
    revision: null,
    approval_count: 0,
    approver1: null,
    approver2: null,
    approved_revision: null,
    hold_active: 0,
    hold_until_ms: null,
    hold_reason: null,
    hold_reviewer: null,
    fee_cents: null,
    payout_req_id: null,
    phase: "none",
    payout: "none",
    edition: null,
  };
}

function num(v, fallback = 0) {
  if (v === undefined || v === null || v === "") return fallback;
  if (typeof v === "bigint") return Number(v);
  if (typeof v === "number") return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function str(v) {
  if (v === undefined || v === null) return "";
  return String(v);
}

function factsOf(agg) {
  const state = agg.state;
  if (!state || typeof state !== "object" || Array.isArray(state)) return {};
  if (state.facts && typeof state.facts === "object") return state.facts;
  const { state: _ignored, ...rest } = state;
  return rest;
}

function phaseOf(named) {
  if (named === "idle") return "none";
  return named;
}

function payoutOf(named) {
  if (named === "paid") return "sent";
  if (named === "payout_pending") return "attempt_saved";
  return "none";
}

function nullIfEmpty(v) {
  if (v === undefined || v === null) return null;
  if (typeof v === "bigint") {
    const n = Number(v);
    return n === 0 ? null : n;
  }
  if (typeof v === "number") return v === 0 ? null : v;
  const s = String(v);
  if (s === "" || s === "0") return null;
  return s;
}

function nullIfBlank(v) {
  if (v === undefined || v === null) return null;
  const s = String(v);
  return s === "" ? null : s;
}

function project(agg) {
  if (!agg) return emptyStatus();
  const named = agg.namedState();
  const f = factsOf(agg);
  const holdActive = num(f.hold_active, 0);
  return {
    payout_id: nullIfBlank(f.payout_id),
    merchant_id: nullIfBlank(f.merchant_id),
    amount_cents: f.amount_cents === undefined || f.amount_cents === null ? null : num(f.amount_cents),
    fee_pct: f.fee_pct === undefined || f.fee_pct === null ? null : num(f.fee_pct),
    review_span_ms: f.review_span_ms === undefined || f.review_span_ms === null ? null : num(f.review_span_ms),
    dual_threshold: f.dual_threshold === undefined || f.dual_threshold === null ? null : num(f.dual_threshold),
    revision: f.revision === undefined || f.revision === null ? null : num(f.revision),
    approval_count: num(f.approval_count, 0),
    approver1: nullIfBlank(f.approver1),
    approver2: nullIfBlank(f.approver2),
    approved_revision: nullIfEmpty(f.approved_revision),
    hold_active: holdActive,
    hold_until_ms: holdActive === 1 ? num(f.hold_until_ms) : nullIfEmpty(f.hold_until_ms),
    hold_reason: holdActive === 1 ? (nullIfBlank(f.hold_reason) || "fraud_review") : nullIfBlank(f.hold_reason),
    hold_reviewer: nullIfBlank(f.hold_reviewer),
    fee_cents: f.fee_cents === undefined || f.fee_cents === null ? null : num(f.fee_cents),
    payout_req_id: nullIfBlank(f.payout_req_id),
    phase: phaseOf(named),
    payout: payoutOf(named),
    edition: nullIfBlank(f.edition),
  };
}

function mapKernel(err) {
  if (err instanceof DomainError) throw err;
  if (err instanceof StoreNotFoundError) return "not_open";
  const kind = classify(err);
  if (kind === "corrupt") fail("corrupt_state");
  if (kind === "not_found") fail("not_open");
  if (kind === "contract_mismatch") fail("corrupt_state");
  return "held_busy";
}

async function openMachines(stateDir) {
  const kernel = new Kernel(storePath(stateDir));
  const v1 = await kernel.machine(MACHINE_V1);
  const v2 = await kernel.machine(MACHINE_V2);
  return { kernel, v1, v2 };
}

function routeMachine(probe, v1, v2) {
  if (probe.owner.equals(v1.identity)) return v1;
  if (probe.owner.equals(v2.identity)) return v2;
  fail("corrupt_state");
}

async function loadDesk(stateDir) {
  const path = storePath(stateDir);
  if (!existsSync(path)) return { machine: null, agg: null, missing: true, v1: null, v2: null };
  try {
    const { v1, v2 } = await openMachines(stateDir);
    try {
      const probe = await v1.show(AGGREGATE_ID);
      const machine = routeMachine(probe, v1, v2);
      const agg = machine === v1 ? probe : await machine.show(AGGREGATE_ID);
      return { machine, agg, missing: false, v1, v2 };
    } catch (err) {
      const kind = classify(err);
      if (kind === "corrupt") fail("corrupt_state");
      if (kind === "not_found") return { machine: v2, agg: null, missing: false, v1, v2 };
      if (err instanceof StoreNotFoundError) return { machine: null, agg: null, missing: true, v1: null, v2: null };
      fail("corrupt_state");
    }
  } catch (err) {
    if (err instanceof DomainError) throw err;
    if (err instanceof StoreNotFoundError) return { machine: null, agg: null, missing: true, v1: null, v2: null };
    const kind = classify(err);
    if (kind === "corrupt") fail("corrupt_state");
    if (kind === "not_found") return { machine: null, agg: null, missing: true, v1: null, v2: null };
    fail("corrupt_state");
  }
}

function requireBound(agg) {
  if (!agg || agg.namedState() === "idle") fail("not_open");
  return agg;
}

function named(agg) {
  return agg ? agg.namedState() : "idle";
}

async function cmd(agg, name, args) {
  try {
    return await agg.command(name, args);
  } catch (err) {
    if (err instanceof DomainError) throw err;
    fail(mapKernel(err));
  }
}

function newPayoutReqId() {
  return `PRQ.${randomBytes(12).toString("hex")}`;
}

function feeOf(amountCents) {
  return Math.trunc(amountCents / 50);
}

function snapshot(view) {
  return {
    payout_id: view.payout_id,
    merchant_id: view.merchant_id,
    amount_cents: view.amount_cents,
    fee_cents: view.fee_cents,
    payout_req_id: view.payout_req_id,
  };
}

function providerMatch(body, snap) {
  if (!body || typeof body !== "object") return false;
  return (
    body.payout_req_id === snap.payout_req_id &&
    body.payout_id === snap.payout_id &&
    body.merchant_id === snap.merchant_id &&
    body.amount_cents === snap.amount_cents &&
    body.fee_cents === snap.fee_cents
  );
}

async function httpJson(url, options = {}) {
  let res;
  try {
    res = await fetch(url, {
      ...options,
      headers: { "content-type": "application/json", ...(options.headers || {}) },
    });
  } catch {
    fail("service_unavailable");
  }
  let text = "";
  try {
    text = await res.text();
  } catch {
    fail("service_unavailable");
  }
  if (text === "") {
    if (res.status >= 500) fail("service_unavailable");
    fail("service_unavailable");
  }
  let body;
  try {
    body = JSON.parse(text);
  } catch {
    fail("service_unavailable");
  }
  return { status: res.status, body };
}

async function lookupPayout(serviceUrl, payoutReqId) {
  const url = `${serviceUrl.replace(/\/$/, "")}/v1/payouts/${encodeURIComponent(payoutReqId)}`;
  return httpJson(url);
}

async function postPayout(serviceUrl, snap) {
  const url = `${serviceUrl.replace(/\/$/, "")}/v1/payouts`;
  return httpJson(url, { method: "POST", body: JSON.stringify(snap) });
}

function paySuccess(view) {
  return {
    payout_id: view.payout_id,
    payout_req_id: view.payout_req_id,
    amount_cents: view.amount_cents,
    fee_cents: view.fee_cents,
    phase: "paid",
    payout: "sent",
  };
}

async function markPaid(agg, view) {
  return cmd(agg, "mark_paid", {
    payout_req_id: view.payout_req_id,
    payout_id: view.payout_id,
    merchant_id: view.merchant_id,
    amount_cents: view.amount_cents,
    fee_cents: view.fee_cents,
  });
}

function adoptOrConflict(result, snap) {
  if (result.status === 404) return "missing";
  if (result.status >= 500) fail("service_unavailable");
  if (result.status !== 200) fail("lookup_conflict");
  if (!providerMatch(result.body, snap)) fail("lookup_conflict");
  return "match";
}

export async function runCommand(env, argv) {
  try {
    const now = parseNow(env.NOW_MS);
    if (now === null) return { ok: false, body: { error: "bad_time" } };
    const stateDir = env.STATE_DIR;
    const serviceUrl = env.SERVICE_URL;
    if (!stateDir || !serviceUrl) return { ok: false, body: { error: "bad_args" } };

    let loaded;
    try {
      loaded = await loadDesk(stateDir);
    } catch (err) {
      if (err instanceof DomainError) return { ok: false, body: { error: err.code } };
      return { ok: false, body: { error: "corrupt_state" } };
    }

    const command = argv[0];
    if (!command || !COMMANDS.has(command)) {
      return { ok: false, body: { error: "unknown_command" } };
    }

    const body = await dispatch(command, argv.slice(1), {
      now,
      stateDir,
      serviceUrl,
      env,
      loaded,
    });
    return { ok: true, body };
  } catch (err) {
    if (err instanceof DomainError) return { ok: false, body: { error: err.code } };
    return { ok: false, body: { error: "corrupt_state" } };
  }
}

async function dispatch(command, args, ctx) {
  switch (command) {
    case "open":
      return doOpen(args, ctx);
    case "edit-amount":
      return doEdit(args, ctx);
    case "approve":
      return doApprove(args, ctx);
    case "place-hold":
      return doPlaceHold(args, ctx);
    case "release-hold":
      return doReleaseHold(args, ctx);
    case "risk-clear":
      return doRiskClear(args, ctx);
    case "pay":
      return doPay(args, ctx);
    case "reconcile":
      return doReconcile(args, ctx);
    case "status":
      return doStatus(args, ctx);
    case "callback":
      return doCallback(args, ctx);
    default:
      fail("unknown_command");
  }
}

async function doOpen(args, ctx) {
  if (args.length !== 3) fail("bad_args");
  const payoutId = parseId(args[0]);
  const merchantId = parseId(args[1]);
  if (!payoutId || !merchantId) fail("bad_args");
  const amount = parseMoney(args[2], { min: 1 });
  if (amount === null) fail("bad_money");
  if (ctx.loaded.agg && named(ctx.loaded.agg) !== "idle") fail("already_open");
  mkdirSync(ctx.stateDir, { recursive: true });
  const machine = ctx.loaded.v2 || (await openMachines(ctx.stateDir)).v2;
  let agg;
  try {
    agg = await machine.createWith({
      aggregateId: AGGREGATE_ID,
      command: {
        name: "open",
        args: {
          payout_id: payoutId,
          merchant_id: merchantId,
          amount_cents: amount,
          fee_pct: 2,
          review_span_ms: 5000,
          dual_threshold: 5000,
        },
      },
    });
  } catch (err) {
    if (err instanceof DomainError) throw err;
    const kind = classify(err);
    if (kind === "corrupt") fail("corrupt_state");
    fail("already_open");
  }
  const view = project(agg);
  return {
    payout_id: view.payout_id,
    merchant_id: view.merchant_id,
    amount_cents: view.amount_cents,
    fee_pct: 2,
    review_span_ms: 5000,
    dual_threshold: 5000,
    revision: view.revision,
    approval_count: 0,
    phase: "opened",
    hold_active: 0,
    hold_until_ms: null,
    hold_reason: null,
    payout: "none",
    payout_req_id: null,
    fee_cents: null,
    edition: "revised",
  };
}

async function doEdit(args, ctx) {
  if (args.length !== 1) fail("bad_args");
  const amount = parseMoney(args[0], { min: 1 });
  if (amount === null) fail("bad_money");
  const agg0 = requireBound(ctx.loaded.agg);
  const state = named(agg0);
  if (state === "paid") fail("already_paid");
  if (state === "held" || state === "payout_pending") fail("held_busy");
  if (state !== "opened" && state !== "approved") fail("held_busy");
  const agg = await cmd(agg0, "edit_amount", { amount_cents: amount });
  const view = project(agg);
  return {
    payout_id: view.payout_id,
    amount_cents: view.amount_cents,
    revision: view.revision,
    approval_count: 0,
    phase: "opened",
  };
}

async function doApprove(args, ctx) {
  if (args.length !== 1) fail("bad_args");
  const approverId = parseId(args[0]);
  if (!approverId) fail("bad_args");
  const agg0 = requireBound(ctx.loaded.agg);
  const state = named(agg0);
  if (state === "paid") fail("already_paid");
  if (state === "held" || state === "payout_pending") fail("held_busy");
  if (state === "approved") fail("already_approved");
  const view0 = project(agg0);
  if (view0.approver1 === approverId || view0.approver2 === approverId) fail("duplicate_approver");
  if (state !== "opened") fail("held_busy");
  const agg = await cmd(agg0, "approve", {
    approver_id: approverId,
    approved_revision: view0.revision,
  });
  const view = project(agg);
  return {
    payout_id: view.payout_id,
    approver_id: approverId,
    approval_count: view.approval_count,
    phase: view.phase,
  };
}

async function doPlaceHold(args, ctx) {
  if (args.length !== 0) fail("bad_args");
  const agg0 = requireBound(ctx.loaded.agg);
  const state = named(agg0);
  if (state === "paid") fail("already_paid");
  if (state === "held") fail("already_held");
  if (state === "payout_pending") fail("held_busy");
  if (state !== "opened" && state !== "approved") fail("held_busy");
  const view0 = project(agg0);
  const holdUntil = ctx.now + view0.review_span_ms;
  const agg = await cmd(agg0, "place_hold", {
    now_ms: ctx.now,
    hold_placed_ms: ctx.now,
    hold_until_ms: holdUntil,
  });
  const view = project(agg);
  return {
    payout_id: view.payout_id,
    phase: "held",
    hold_active: 1,
    hold_until_ms: view.hold_until_ms,
    hold_reason: "fraud_review",
  };
}

async function doReleaseHold(args, ctx) {
  if (args.length !== 0) fail("bad_args");
  const agg0 = requireBound(ctx.loaded.agg);
  const state = named(agg0);
  if (state !== "held") fail("not_held");
  const view0 = project(agg0);
  if (ctx.now < view0.hold_until_ms) fail("hold_until");
  const agg = await cmd(agg0, "release_hold", { now_ms: ctx.now });
  const view = project(agg);
  return {
    payout_id: view.payout_id,
    phase: view.phase,
    hold_active: 0,
  };
}

async function doRiskClear(args, ctx) {
  if (args.length !== 1) fail("bad_args");
  const reviewerId = parseId(args[0]);
  if (!reviewerId) fail("bad_args");
  const agg0 = requireBound(ctx.loaded.agg);
  const view0 = project(agg0);
  if (view0.edition === "original") fail("legacy_request");
  if (named(agg0) !== "held") fail("not_held");
  const agg = await cmd(agg0, "risk_clear", { reviewer_id: reviewerId });
  const view = project(agg);
  return {
    payout_id: view.payout_id,
    phase: view.phase,
    hold_active: 0,
    hold_until_ms: null,
    hold_reason: null,
    hold_reviewer: reviewerId,
    edition: "revised",
  };
}

async function doPay(args, ctx) {
  if (args.length !== 0) fail("bad_args");
  const agg0 = requireBound(ctx.loaded.agg);
  const state = named(agg0);
  if (state === "paid") {
    const view = project(agg0);
    return paySuccess(view);
  }
  if (state === "held") fail("held_busy");
  if (state === "opened") fail("approvals_required");
  if (state !== "approved" && state !== "payout_pending") fail("held_busy");
  if (state === "approved") {
    const view0 = project(agg0);
    if (view0.hold_active === 1) fail("hold_until");
    if (view0.approved_revision !== view0.revision) fail("approvals_required");
    const fee = feeOf(view0.amount_cents);
    const payoutReqId = newPayoutReqId();
    const saved = await cmd(agg0, "save_payout", {
      payout_req_id: payoutReqId,
      fee_cents: fee,
    });
    crashIf(ctx.env, "after-pay-saved-before-request");
    return finishPay(saved, ctx, { lookupFirst: false });
  }
  return finishPay(agg0, ctx, { lookupFirst: true });
}

async function finishPay(agg, ctx, { lookupFirst }) {
  const view = project(agg);
  const snap = snapshot(view);
  if (lookupFirst) {
    const looked = await lookupPayout(ctx.serviceUrl, snap.payout_req_id);
    const kind = adoptOrConflict(looked, snap);
    if (kind === "match") return acceptPaid(agg, view, ctx);
    const posted = await postPayout(ctx.serviceUrl, snap);
    return handlePost(agg, view, ctx, posted);
  }
  const posted = await postPayout(ctx.serviceUrl, snap);
  return handlePost(agg, view, ctx, posted);
}

async function handlePost(agg, view, ctx, posted) {
  if (posted.status >= 500) fail("service_unavailable");
  if (posted.status === 409) fail("lookup_conflict");
  if (posted.status !== 200) fail("service_unavailable");
  if (!providerMatch(posted.body, snapshot(view))) fail("lookup_conflict");
  return acceptPaid(agg, view, ctx);
}

async function acceptPaid(agg, view, ctx) {
  crashIf(ctx.env, "after-accept-before-record");
  const paid = await markPaid(agg, view);
  crashIf(ctx.env, "after-record-before-exit");
  return paySuccess(project(paid));
}

async function doReconcile(args, ctx) {
  if (args.length !== 1) fail("bad_args");
  const payoutReqId = parseId(args[0]);
  if (!payoutReqId) fail("bad_args");
  const agg0 = requireBound(ctx.loaded.agg);
  const view0 = project(agg0);
  if (!view0.payout_req_id) fail("no_payout");
  if (view0.payout_req_id !== payoutReqId) fail("payout_mismatch");
  if (named(agg0) === "paid") {
    return { ...paySuccess(view0), lookup: "sent" };
  }
  const looked = await lookupPayout(ctx.serviceUrl, payoutReqId);
  const kind = adoptOrConflict(looked, snapshot(view0));
  if (kind === "missing") {
    return {
      lookup: "not_sent",
      payout_id: view0.payout_id,
      payout_req_id: view0.payout_req_id,
      payout: "attempt_saved",
      phase: "payout_pending",
    };
  }
  const paid = await markPaid(agg0, view0);
  return { ...paySuccess(project(paid)), lookup: "sent" };
}

async function doStatus(args, ctx) {
  if (args.length !== 0) fail("bad_args");
  return project(ctx.loaded.agg);
}

async function doCallback(args, ctx) {
  if (args.length !== 1) fail("bad_args");
  const path = args[0];
  let raw;
  try {
    raw = readFileSync(path, "utf8");
  } catch {
    fail("bad_callback");
  }
  try {
    JSON.parse(raw);
  } catch {
    fail("bad_callback");
  }
  return { ok: true };
}

