import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import {
  createHash,
  randomBytes,
} from "node:crypto";
import {
  existsSync,
  mkdirSync,
  mkdtempSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { Kernel } from "@ikaros/runtime";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { test } from "node:test";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const NODE = process.execPath;
const RUN = join(ROOT, "run");
const SERVER = join(ROOT, "stub", "server.mjs");

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [SERVER], { cwd: ROOT, stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    const onData = (chunk) => {
      buf += chunk;
      const nl = buf.indexOf("\n");
      if (nl === -1) return;
      child.stdout.off("data", onData);
      try {
        const info = JSON.parse(buf.slice(0, nl));
        resolve({ child, ...info });
      } catch (err) {
        reject(err);
      }
    };
    child.stdout.on("data", onData);
    child.once("error", reject);
    child.once("exit", (code) => {
      if (!child.service_url) reject(new Error(`stub exited ${code}`));
    });
  });
}

async function stopStub(stub) {
  stub.child.kill("SIGTERM");
  await new Promise((r) => stub.child.once("exit", r));
}

function deskDir() {
  return mkdtempSync(join(tmpdir(), "payout-desk-"));
}

function invoke(env, args, extra = {}) {
  return spawnSync(RUN, args, {
    cwd: ROOT,
    env: { PATH: process.env.PATH, NODE_BIN: NODE, ...env },
    encoding: "utf8",
    timeout: extra.timeout ?? 20000,
    killSignal: "SIGKILL",
  });
}

function parse(proc) {
  const text = (proc.stdout || "").trim();
  assert.equal((proc.stdout.match(/\{/g) || []).length >= 1, true, proc.stdout + proc.stderr);
  return JSON.parse(text.split("\n").filter(Boolean).at(-1));
}

function ok(env, args) {
  const proc = invoke(env, args);
  assert.equal(proc.status, 0, proc.stdout + proc.stderr);
  assert.equal(proc.signal, null);
  return parse(proc);
}

function refused(env, args, code) {
  const proc = invoke(env, args);
  assert.notEqual(proc.status, 0, proc.stdout);
  const body = parse(proc);
  assert.deepEqual(body, { error: code });
  return body;
}

async function effects(stub) {
  const res = await fetch(`${stub.control_url}/effects`);
  return res.json();
}

async function posts(stub) {
  const res = await fetch(`${stub.control_url}/posts`);
  return res.json();
}

async function setFault(stub, fault) {
  const res = await fetch(`${stub.control_url}/fault`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(fault),
  });
  return res.json();
}

function baseEnv(stateDir, serviceUrl, now = "1000") {
  return { STATE_DIR: stateDir, SERVICE_URL: serviceUrl, NOW_MS: String(now) };
}

async function approveDual(env) {
  ok(env, ["open", "PAY-1", "MER-9", "15000"]);
  ok(env, ["approve", "APR-A"]);
  ok(env, ["approve", "APR-B"]);
}

test("R14 empty status, env refusals, unknown command", () => {
  const dir = deskDir();
  const env = baseEnv(dir, "http://127.0.0.1:1");
  assert.deepEqual(ok(env, ["status"]), {
    payout_id: null,
    merchant_id: null,
    amount_cents: null,
    fee_pct: null,
    review_span_ms: null,
    dual_threshold: null,
    revision: null,
    approval_count: 0,
    approver1: null,
    approver2: null,
    approved_revision: null,
    hold_active: 0,
    hold_until_ms: null,
    hold_reason: null,
    hold_reviewer: null,
    fee_cents: null,
    payout_req_id: null,
    phase: "none",
    payout: "none",
    edition: null,
  });
  refused({ STATE_DIR: dir, SERVICE_URL: env.SERVICE_URL }, ["status"], "bad_time");
  refused({ NOW_MS: "1000", SERVICE_URL: env.SERVICE_URL }, ["status"], "bad_args");
  refused({ NOW_MS: "1000", STATE_DIR: dir }, ["status"], "bad_args");
  refused(env, ["nope"], "unknown_command");
  refused({ NOW_MS: "nope", STATE_DIR: dir }, ["status"], "bad_time");
});

test("R2 open persists constants and refuses a second bind", () => {
  const dir = deskDir();
  const env = baseEnv(dir, "http://127.0.0.1:1");
  const opened = ok(env, ["open", "PAY-1", "MER-9", "15000"]);
  assert.equal(opened.phase, "opened");
  assert.equal(opened.fee_pct, 2);
  assert.equal(opened.review_span_ms, 5000);
  assert.equal(opened.dual_threshold, 5000);
  assert.equal(opened.revision, 1);
  assert.equal(opened.edition, "revised");
  refused(env, ["open", "PAY-N", "MER-O", "8000"], "already_open");
  refused(env, ["open", "PAY-1", "MER-9", "0"], "bad_money");
  refused(env, ["open", "bad id", "MER-9", "8000"], "bad_args");
});

test("R3 dual vs single approval and fee", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    ok(env, ["open", "PAY-1", "MER-9", "15000"]);
    const first = ok(env, ["approve", "APR-A"]);
    assert.equal(first.phase, "opened");
    assert.equal(first.approval_count, 1);
    refused(env, ["approve", "APR-A"], "duplicate_approver");
    const second = ok(env, ["approve", "APR-B"]);
    assert.equal(second.phase, "approved");
    assert.equal(second.approval_count, 2);
    refused(env, ["approve", "APR-C"], "already_approved");
    const paid = ok(env, ["pay"]);
    assert.equal(paid.fee_cents, 300);
    assert.equal(paid.phase, "paid");
    const dir2 = deskDir();
    const env2 = baseEnv(dir2, stub.service_url);
    ok(env2, ["open", "PAY-O", "MER-O", "4000"]);
    const one = ok(env2, ["approve", "APR-A"]);
    assert.equal(one.phase, "approved");
    const dir3 = deskDir();
    const env3 = baseEnv(dir3, stub.service_url);
    ok(env3, ["open", "PAY-N", "MER-O", "8000"]);
    assert.equal(ok(env3, ["approve", "APR-A"]).phase, "opened");
    assert.equal(ok(env3, ["approve", "APR-B"]).phase, "approved");
  } finally {
    await stopStub(stub);
  }
});

test("R4 hold clocks", () => {
  const dir = deskDir();
  const env = baseEnv(dir, "http://127.0.0.1:1", 1000);
  ok(env, ["open", "PAY-1", "MER-9", "8000"]);
  const held = ok(env, ["place-hold"]);
  assert.equal(held.phase, "held");
  assert.equal(held.hold_until_ms, 6000);
  assert.equal(held.hold_reason, "fraud_review");
  refused({ ...env, NOW_MS: "5999" }, ["release-hold"], "hold_until");
  assert.equal(ok({ ...env, NOW_MS: "5999" }, ["status"]).hold_active, 1);
  const released = ok({ ...env, NOW_MS: "6000" }, ["release-hold"]);
  assert.equal(released.hold_active, 0);
  assert.equal(released.phase, "opened");
});

test("R5 edit after approval clears authority", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    ok(env, ["open", "PAY-1", "MER-9", "8000"]);
    ok(env, ["approve", "APR-A"]);
    const edited = ok(env, ["edit-amount", "15000"]);
    assert.equal(edited.phase, "opened");
    assert.equal(edited.approval_count, 0);
    assert.equal(edited.revision, 2);
    refused(env, ["pay"], "approvals_required");
  } finally {
    await stopStub(stub);
  }
});

test("R6 healthy pay is one effect; paid pay is a no-op", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    await approveDual(env);
    const paid = ok(env, ["pay"]);
    assert.equal(paid.payout, "sent");
    const before = await effects(stub);
    const again = ok(env, ["pay"]);
    assert.equal(again.payout, "sent");
    const after = await effects(stub);
    assert.equal(after.count, before.count);
    assert.equal(after.count, 1);
  } finally {
    await stopStub(stub);
  }
});

test("R7 status-gated commands do not contact the provider", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    refused(env, ["approve", "APR-A"], "not_open");
    refused(env, ["release-hold"], "not_open");
    ok(env, ["open", "PAY-1", "MER-9", "4000"]);
    refused(env, ["release-hold"], "not_held");
    ok(env, ["approve", "APR-A"]);
    ok(env, ["pay"]);
    refused(env, ["place-hold"], "already_paid");
    const p = await posts(stub);
    assert.equal(p.count, 1);
  } finally {
    await stopStub(stub);
  }
});

test("R1/R8 crash after save, later pay recovers the same id", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    await approveDual(env);
    const crashed = invoke({ ...env, CRASH_AT: "after-pay-saved-before-request" }, ["pay"]);
    assert.equal(crashed.signal, "SIGKILL");
    const st = ok(env, ["status"]);
    assert.equal(st.payout, "attempt_saved");
    assert.equal(typeof st.payout_req_id, "string");
    const saved = st.payout_req_id;
    const paid = ok(env, ["pay"]);
    assert.equal(paid.payout_req_id, saved);
    assert.equal(paid.phase, "paid");
    const eff = await effects(stub);
    assert.equal(eff.count, 1);
  } finally {
    await stopStub(stub);
  }
});

test("R9 crash after accept before record is recovered by pay", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    await approveDual(env);
    const crashed = invoke({ ...env, CRASH_AT: "after-accept-before-record" }, ["pay"]);
    assert.equal(crashed.signal, "SIGKILL");
    const st = ok(env, ["status"]);
    assert.equal(st.payout, "attempt_saved");
    const paid = ok(env, ["pay"]);
    assert.equal(paid.phase, "paid");
    const eff = await effects(stub);
    assert.equal(eff.count, 1);
  } finally {
    await stopStub(stub);
  }
});

test("R10 crash after record before exit leaves paid", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    await approveDual(env);
    const crashed = invoke({ ...env, CRASH_AT: "after-record-before-exit" }, ["pay"]);
    assert.equal(crashed.signal, "SIGKILL");
    const st = ok(env, ["status"]);
    assert.equal(st.phase, "paid");
    assert.equal(st.payout, "sent");
  } finally {
    await stopStub(stub);
  }
});

test("R11 dropped reply then reconcile", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    await approveDual(env);
    await setFault(stub, { drop_reply: true });
    refused(env, ["pay"], "service_unavailable");
    const st = ok(env, ["status"]);
    assert.equal(st.payout, "attempt_saved");
    await setFault(stub, { drop_reply: false });
    const rec = ok(env, ["reconcile", st.payout_req_id]);
    assert.equal(rec.lookup, "sent");
    assert.equal(rec.phase, "paid");
    const eff = await effects(stub);
    assert.equal(eff.count, 1);
  } finally {
    await stopStub(stub);
  }
});

test("R12 reconcile never POSTs after pre-request crash", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    await approveDual(env);
    invoke({ ...env, CRASH_AT: "after-pay-saved-before-request" }, ["pay"]);
    const st = ok(env, ["status"]);
    const before = await posts(stub);
    const rec = ok(env, ["reconcile", st.payout_req_id]);
    assert.equal(rec.lookup, "not_sent");
    assert.equal(rec.payout, "attempt_saved");
    const after = await posts(stub);
    assert.equal(after.count, before.count);
  } finally {
    await stopStub(stub);
  }
});

test("R13 unrelated files survive byte-for-byte", () => {
  const dir = deskDir();
  const env = baseEnv(dir, "http://127.0.0.1:1");
  const extra = join(dir, "unrelated.bin");
  const bytes = randomBytes(64);
  writeFileSync(extra, bytes);
  const digest = () => createHash("sha256").update(readFileSync(extra)).digest("hex");
  const before = digest();
  ok(env, ["open", "PAY-1", "MER-9", "8000"]);
  ok(env, ["approve", "APR-A"]);
  ok(env, ["status"]);
  assert.equal(digest(), before);
  assert.equal(existsSync(extra), true);
});

test("R9 reconcile recovers accept-before-record", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    await approveDual(env);
    invoke({ ...env, CRASH_AT: "after-accept-before-record" }, ["pay"]);
    const st = ok(env, ["status"]);
    const rec = ok(env, ["reconcile", st.payout_req_id]);
    assert.equal(rec.lookup, "sent");
    assert.equal((await effects(stub)).count, 1);
  } finally {
    await stopStub(stub);
  }
});

test("callback ignores well-formed JSON and refuses malformed", () => {
  const dir = deskDir();
  const env = baseEnv(dir, "http://127.0.0.1:1");
  ok(env, ["open", "PAY-1", "MER-9", "8000"]);
  const good = join(dir, "cb.json");
  writeFileSync(good, JSON.stringify({ event: "ignored" }));
  assert.deepEqual(ok(env, ["callback", good]), { ok: true });
  assert.equal(ok(env, ["status"]).phase, "opened");
  const bad = join(dir, "bad.json");
  writeFileSync(bad, "{");
  refused(env, ["callback", bad], "bad_callback");
});

test("process restart preserves opened payout", () => {
  const dir = deskDir();
  const env = baseEnv(dir, "http://127.0.0.1:1");
  ok(env, ["open", "PAY-1", "MER-9", "15000"]);
  ok(env, ["approve", "APR-A"]);
  const st = ok(env, ["status"]);
  assert.equal(st.approval_count, 1);
  assert.equal(st.phase, "opened");
  const st2 = ok(env, ["status"]);
  assert.deepEqual(st2, st);
});

test("hold after approval releases to approved; pay while held is held_busy", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url, 1000);
    ok(env, ["open", "PAY-1", "MER-9", "8000"]);
    ok(env, ["approve", "APR-A"]);
    ok(env, ["approve", "APR-B"]);
    ok(env, ["place-hold"]);
    refused(env, ["pay"], "held_busy");
    refused(env, ["place-hold"], "already_held");
    refused(env, ["edit-amount", "9000"], "held_busy");
    const released = ok({ ...env, NOW_MS: "6000" }, ["release-hold"]);
    assert.equal(released.phase, "approved");
    const paid = ok({ ...env, NOW_MS: "6000" }, ["pay"]);
    assert.equal(paid.fee_cents, 160);
  } finally {
    await stopStub(stub);
  }
});

test("5xx on pay leaves attempt_saved; later pay completes one effect", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    await approveDual(env);
    await setFault(stub, { error_status: 500 });
    refused(env, ["pay"], "service_unavailable");
    const st = ok(env, ["status"]);
    assert.equal(st.payout, "attempt_saved");
    await setFault(stub, { error_status: 0 });
    const paid = ok(env, ["pay"]);
    assert.equal(paid.phase, "paid");
    assert.equal((await effects(stub)).count, 1);
  } finally {
    await stopStub(stub);
  }
});

test("reconcile refuses no_payout and payout_mismatch", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url);
    refused(env, ["reconcile", "PRQ.1"], "not_open");
    ok(env, ["open", "PAY-1", "MER-9", "4000"]);
    refused(env, ["reconcile", "PRQ.1"], "no_payout");
    ok(env, ["approve", "APR-A"]);
    invoke({ ...env, CRASH_AT: "after-pay-saved-before-request" }, ["pay"]);
    const st = ok(env, ["status"]);
    refused(env, ["reconcile", "PRQ.other"], "payout_mismatch");
    const rec = ok(env, ["reconcile", st.payout_req_id]);
    assert.equal(rec.lookup, "not_sent");
  } finally {
    await stopStub(stub);
  }
});

test("corrupt owned store is corrupt_state and not rewritten", () => {
  const dir = deskDir();
  const env = baseEnv(dir, "http://127.0.0.1:1");
  ok(env, ["open", "PAY-1", "MER-9", "8000"]);
  const store = join(dir, "payout.sqlite");
  const before = readFileSync(store);
  writeFileSync(store, "not-a-store");
  refused(env, ["status"], "corrupt_state");
  assert.equal(readFileSync(store).toString(), "not-a-store");
  writeFileSync(store, before);
});

async function seedOriginal(dir, amount = 6000) {
  mkdirSync(dir, { recursive: true });
  const kernel = new Kernel(join(dir, "payout.sqlite"));
  const machine = await kernel.machine(join(ROOT, "machines", "payout_desk.ik.toml"));
  await machine.createWith({
    aggregateId: "desk",
    command: {
      name: "open",
      args: {
        payout_id: "PAY-O",
        merchant_id: "MER-O",
        amount_cents: amount,
        fee_pct: 2,
        review_span_ms: 5000,
        dual_threshold: 10000,
      },
    },
  });
}

test("C1 risk-clear on revised held payout", () => {
  const dir = deskDir();
  const env = baseEnv(dir, "http://127.0.0.1:1", 1000);
  ok(env, ["open", "PAY-1", "MER-9", "4000"]);
  ok(env, ["place-hold"]);
  const cleared = ok({ ...env, NOW_MS: "2000" }, ["risk-clear", "REV-K"]);
  assert.equal(cleared.hold_active, 0);
  assert.equal(cleared.hold_until_ms, null);
  assert.equal(cleared.hold_reason, null);
  assert.equal(cleared.hold_reviewer, "REV-K");
  assert.equal(cleared.edition, "revised");
  assert.equal(cleared.phase, "opened");
  refused(env, ["risk-clear", ""], "bad_args");
});

test("C2 cleared hold survives restart; original refuses risk-clear", async () => {
  const dir = deskDir();
  const env = baseEnv(dir, "http://127.0.0.1:1", 1000);
  ok(env, ["open", "PAY-1", "MER-9", "4000"]);
  ok(env, ["place-hold"]);
  ok({ ...env, NOW_MS: "2000" }, ["risk-clear", "REV-K"]);
  const st = ok(env, ["status"]);
  assert.equal(st.hold_active, 0);
  assert.equal(st.hold_until_ms, null);
  assert.equal(st.hold_reason, null);
  assert.equal(st.hold_reviewer, "REV-K");

  const orig = deskDir();
  await seedOriginal(orig, 6000);
  const oenv = baseEnv(orig, "http://127.0.0.1:1", 1000);
  ok(oenv, ["place-hold"]);
  const before = ok(oenv, ["status"]);
  refused(oenv, ["risk-clear", "REV-K"], "legacy_request");
  const after = ok(oenv, ["status"]);
  assert.equal(after.hold_active, 1);
  assert.equal(after.hold_until_ms, before.hold_until_ms);
  assert.equal(after.hold_reason, before.hold_reason);
  assert.equal(after.edition, "original");
});

test("C3 revised 6000 needs two approvers; risk-clear unlocks pay", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url, 1000);
    ok(env, ["open", "PAY-1", "MER-9", "6000"]);
    ok(env, ["approve", "APR-A"]);
    refused(env, ["pay"], "approvals_required");
    ok(env, ["approve", "APR-B"]);
    ok(env, ["place-hold"]);
    refused({ ...env, NOW_MS: "2000" }, ["pay"], "held_busy");
    ok({ ...env, NOW_MS: "2000" }, ["risk-clear", "REV-K"]);
    const paid = ok({ ...env, NOW_MS: "2000" }, ["pay"]);
    assert.equal(paid.fee_cents, 120);
    assert.equal(paid.phase, "paid");
    assert.equal((await effects(stub)).count, 1);
  } finally {
    await stopStub(stub);
  }
});

test("C4 original store keeps dual_threshold 10000", async () => {
  const dir = deskDir();
  await seedOriginal(dir, 6000);
  const env = baseEnv(dir, "http://127.0.0.1:1");
  const st = ok(env, ["status"]);
  assert.equal(st.dual_threshold, 10000);
  assert.equal(st.edition, "original");
  const approved = ok(env, ["approve", "APR-A"]);
  assert.equal(approved.phase, "approved");
  refused(env, ["risk-clear", "REV-K"], "legacy_request");
});

test("C5 recovery after risk-clear keeps one effect; new open is revised", async () => {
  const stub = await startStub();
  try {
    const dir = deskDir();
    const env = baseEnv(dir, stub.service_url, 1000);
    ok(env, ["open", "PAY-1", "MER-9", "4000"]);
    ok(env, ["approve", "APR-A"]);
    ok(env, ["place-hold"]);
    ok({ ...env, NOW_MS: "2000" }, ["risk-clear", "REV-K"]);
    const crashed = invoke({ ...env, NOW_MS: "2000", CRASH_AT: "after-pay-saved-before-request" }, ["pay"]);
    assert.notEqual(crashed.status, 0);
    const pending = ok({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.equal(pending.payout, "attempt_saved");
    const paid = ok({ ...env, NOW_MS: "2000" }, ["pay"]);
    assert.equal(paid.phase, "paid");
    assert.equal(paid.payout_req_id, pending.payout_req_id);
    assert.equal((await effects(stub)).count, 1);

    const dir2 = deskDir();
    const env2 = baseEnv(dir2, stub.service_url);
    const opened = ok(env2, ["open", "PAY-N", "MER-O", "6000"]);
    assert.equal(opened.dual_threshold, 5000);
    assert.equal(opened.edition, "revised");
    ok(env2, ["place-hold"]);
    const cleared = ok(env2, ["risk-clear", "REV-K"]);
    assert.equal(cleared.hold_active, 0);
  } finally {
    await stopStub(stub);
  }
});
