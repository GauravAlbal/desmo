# Payout desk

Durable local desk for one merchant payout: dual approval, fraud hold, early
`risk-clear`, and one external payout send. New payouts use
`machines/payout_desk_v2.ik.toml` (`dual_threshold` 5000, `edition` `"revised"`).
Payouts opened under the original program stay on
`machines/payout_desk.ik.toml`. `src/desk.mjs` is the host (CLI, HTTP, crash
labels, version routing).

## Setup

Node 22 is required. Offline install of the bundled runtime:

```bash
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

On this workstation the Node binary is
`<node-bin>/node`. `./run` uses that path
when present, otherwise `node` on `PATH`. Override with `NODE_BIN`.

## Run

Start the fake provider (prints `{service_url, control_url}`):

```bash
node stub/server.mjs
```

Then:

```bash
export STATE_DIR=/tmp/payout-desk
export SERVICE_URL=http://127.0.0.1:<port>
export NOW_MS=1000
mkdir -p "$STATE_DIR"
./run open PAY-1 MER-9 15000
./run approve APR-A
./run approve APR-B
./run place-hold
./run risk-clear REV-K
./run pay
./run status
```

`SERVICE_URL` is required for every command, including `status` (status never
contacts it). `NOW_MS` is a required non-negative integer epoch-millisecond
clock. Optional `CRASH_AT` labels: `after-pay-saved-before-request`,
`after-accept-before-record`, `after-record-before-exit`.

`./run` prints one JSON object. Exit 0 is success; refusals are nonzero
`{ "error": "<code>" }`.

## Tests

```bash
npm test
```
