import {createServer} from "node:http";
const payouts=new Map(),effects=[],posts=[];let fault={drop_reply:false,delay_ms:0,error_status:0};
const send=(r,s,o)=>{const b=JSON.stringify(o);r.writeHead(s,{"content-type":"application/json","content-length":Buffer.byteLength(b),connection:"close"});r.end(b)};
const bodyOf=q=>new Promise((ok,no)=>{const a=[];q.on("data",c=>a.push(c));q.on("end",()=>ok(Buffer.concat(a).toString()));q.on("error",no)});
const valid=x=>x&&typeof x.payout_req_id==="string"&&typeof x.payout_id==="string"&&typeof x.merchant_id==="string"&&Number.isSafeInteger(x.amount_cents)&&x.amount_cents>0&&Number.isSafeInteger(x.fee_cents)&&x.fee_cents>=0;
const same=(a,b)=>a.payout_req_id===b.payout_req_id&&a.payout_id===b.payout_id&&a.merchant_id===b.merchant_id&&a.amount_cents===b.amount_cents&&a.fee_cents===b.fee_cents;
async function finish(r,s,o,d){if(fault.delay_ms)await new Promise(x=>setTimeout(x,fault.delay_ms));if(d||fault.drop_reply&&s===200){r.socket.destroy();return}send(r,s,o)}
async function data(q,r){
  const u=new URL(q.url,"http://x");
  if(q.method==="POST"&&u.pathname==="/v1/payouts"){
    let p=null;try{p=JSON.parse(await bodyOf(q))}catch{}
    if(!valid(p)){send(r,400,{error:"bad_request"});return}
    if(fault.error_status>=500){posts.push({...p,http_status:fault.error_status});await finish(r,fault.error_status,{error:"unavailable"},fault.drop_reply);return}
    const old=payouts.get(p.payout_req_id);
    if(old&&!same(old,p)){posts.push({...p,http_status:409});send(r,409,{error:"conflict"});return}
    const saved=old||{...p,outcome:"sent"};
    if(!old){payouts.set(p.payout_req_id,saved);effects.push(saved)}
    const drop=fault.drop_reply===true;
    posts.push({...p,http_status:200,dropped:drop});
    await finish(r,200,saved,drop);return;
  }
  if(q.method==="GET"&&u.pathname.startsWith("/v1/payouts/")){
    const id=decodeURIComponent(u.pathname.slice("/v1/payouts/".length));
    const v=payouts.get(id);
    if(v)send(r,200,v);else send(r,404,{error:"not_found"});
    return;
  }
  send(r,404,{error:"not_found"});
}
async function control(q,r){
  const u=new URL(q.url,"http://x");
  if(q.method==="GET"&&u.pathname==="/effects"){send(r,200,{count:effects.length,effects});return}
  if(q.method==="GET"&&u.pathname==="/posts"){send(r,200,{count:posts.length,posts});return}
  if(q.method==="POST"&&u.pathname==="/fault"){
    let x={};try{x=JSON.parse(await bodyOf(q)||"{}")}catch{}
    fault={drop_reply:x.drop_reply===true,delay_ms:Number.isInteger(x.delay_ms)&&x.delay_ms>=0?x.delay_ms:0,error_status:Number.isInteger(x.error_status)?x.error_status:0};
    send(r,200,fault);return;
  }
  if(q.method==="GET"&&u.pathname==="/health"){send(r,200,{ok:true});return}
  send(r,404,{error:"not_found"});
}
const d=createServer((q,r)=>data(q,r).catch(()=>{if(!r.headersSent)send(r,400,{error:"bad_request"})}));
const c=createServer((q,r)=>control(q,r).catch(()=>{if(!r.headersSent)send(r,400,{error:"bad_request"})}));
d.listen(0,"127.0.0.1",()=>c.listen(0,"127.0.0.1",()=>process.stdout.write(JSON.stringify({service_url:`http://127.0.0.1:${d.address().port}`,control_url:`http://127.0.0.1:${c.address().port}`})+"\n")));
