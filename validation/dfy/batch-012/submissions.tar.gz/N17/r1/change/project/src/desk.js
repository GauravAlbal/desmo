import { createHash, randomBytes } from "node:crypto";
import { mkdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Capability,
  HistoricalResult,
  Kernel,
  StoreNotFoundError,
  TransportError,
  classify,
} from "@ikaros/runtime";

const ROOT_DIR = join(dirname(fileURLToPath(import.meta.url)), "..");
const MACHINE_V1 = join(ROOT_DIR, "payout.ik.toml");
const MACHINE_V2 = join(ROOT_DIR, "payout_v2.ik.toml");
const AGGREGATE_ID = "desk";
const STORE_NAME = "desk.ik.sqlite";
const MAX_TIME = 9007199254740991n;
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const CANON_INT = /^(0|[1-9][0-9]*)$/;

const EMPTY_STATUS = {
  payout_id: null,
  merchant_id: null,
  amount_cents: null,
  fee_pct: null,
  review_span_ms: null,
  dual_threshold: null,
  revision: null,
  approval_count: 0,
  approver1: null,
  approver2: null,
  approved_revision: null,
  hold_active: 0,
  hold_until_ms: null,
  hold_reason: null,
  hold_reviewer: null,
  fee_cents: null,
  payout_req_id: null,
  phase: "none",
  payout: "none",
  edition: null,
};

function succeed(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(0);
}

function refuse(code) {
  process.stdout.write(JSON.stringify({ error: code }) + "\n");
  process.exit(1);
}

function crashIf(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

function num(v) {
  if (typeof v === "bigint") return Number(v);
  if (typeof v === "number") return v;
  if (typeof v === "string" && CANON_INT.test(v)) return Number(v);
  return v;
}

function has(state, key) {
  return state != null && Object.prototype.hasOwnProperty.call(state, key);
}

function emptyNull(v) {
  if (v === undefined || v === null || v === "") return null;
  return v;
}

function zeroNull(v) {
  if (v === undefined || v === null) return null;
  const n = num(v);
  if (n === 0) return null;
  return n;
}

function parseNow() {
  const raw = process.env.NOW_MS;
  if (raw === undefined || !CANON_INT.test(raw)) refuse("bad_time");
  try {
    const n = BigInt(raw);
    if (n < 0n || n > MAX_TIME) refuse("bad_time");
  } catch {
    refuse("bad_time");
  }
  return Number(raw);
}

function requireEnv() {
  if (!process.env.STATE_DIR || !process.env.SERVICE_URL) refuse("bad_args");
}

function storePath() {
  return join(process.env.STATE_DIR, STORE_NAME);
}

function serviceBase() {
  return String(process.env.SERVICE_URL).replace(/\/+$/, "");
}

function isIdent(v) {
  return typeof v === "string" && ID_RE.test(v);
}

function parseMoney(raw) {
  if (raw === undefined) return { missing: true };
  if (!CANON_INT.test(raw)) return { bad: true };
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0) return { bad: true };
  return { value: n };
}

function phaseOf(state) {
  const s = state.state;
  if (s === "held_opened" || s === "held_approved") return "held";
  if (s === "idle") return "none";
  return s;
}

function statusObject(state) {
  if (!state || state.state === "idle") return { ...EMPTY_STATUS };
  return {
    payout_id: emptyNull(state.payout_id),
    merchant_id: emptyNull(state.merchant_id),
    amount_cents: has(state, "amount_cents") ? num(state.amount_cents) : null,
    fee_pct: has(state, "fee_pct") ? num(state.fee_pct) : null,
    review_span_ms: has(state, "review_span_ms") ? num(state.review_span_ms) : null,
    dual_threshold: has(state, "dual_threshold") ? num(state.dual_threshold) : null,
    revision: has(state, "revision") ? num(state.revision) : null,
    approval_count: num(state.approval_count ?? 0),
    approver1: emptyNull(state.approver1),
    approver2: emptyNull(state.approver2),
    approved_revision: num(state.approved_revision ?? 0) > 0 ? num(state.approved_revision) : null,
    hold_active: num(state.hold_active ?? 0),
    hold_until_ms: zeroNull(state.hold_until_ms),
    hold_reason: emptyNull(state.hold_reason),
    hold_reviewer: emptyNull(state.hold_reviewer),
    fee_cents: has(state, "fee_cents") ? num(state.fee_cents) : null,
    payout_req_id: emptyNull(state.payout_req_id),
    phase: phaseOf(state),
    payout: emptyNull(state.payout) || "none",
    edition: emptyNull(state.edition),
  };
}

function payObject(state, extra) {
  return {
    payout_id: state.payout_id,
    payout_req_id: state.payout_req_id,
    amount_cents: num(state.amount_cents),
    fee_cents: num(state.fee_cents),
    phase: "paid",
    payout: "sent",
    ...extra,
  };
}

function sha256(s) {
  return createHash("sha256").update(s).digest("hex");
}

function snapshotOf(state, payoutReqId, feeCents) {
  return {
    payout_req_id: payoutReqId,
    payout_id: state.payout_id,
    merchant_id: state.merchant_id,
    amount_cents: num(state.amount_cents),
    fee_cents: num(feeCents),
  };
}

function payloadDigest(snap) {
  return sha256(
    JSON.stringify({
      payout_req_id: snap.payout_req_id,
      payout_id: snap.payout_id,
      merchant_id: snap.merchant_id,
      amount_cents: snap.amount_cents,
      fee_cents: snap.fee_cents,
    }),
  );
}

function matchingBody(json, snap) {
  return (
    json != null &&
    typeof json === "object" &&
    json.payout_req_id === snap.payout_req_id &&
    json.payout_id === snap.payout_id &&
    json.merchant_id === snap.merchant_id &&
    json.amount_cents === snap.amount_cents &&
    json.fee_cents === snap.fee_cents
  );
}

function mapKernel(err) {
  if (!err) return null;
  if (err instanceof StoreNotFoundError) return "not_found";
  try {
    return classify(err);
  } catch {
    return null;
  }
}

function isMissing(err) {
  const cls = mapKernel(err);
  if (cls === "not_found") return true;
  return err && err.code === "IK_ILLEGAL_STATE" && err.rule === "aggregate.not_found";
}

async function unwrap(agg, result) {
  if (result instanceof HistoricalResult) return agg.machine.show(agg.id);
  return result;
}

async function loadMachines() {
  const kernel = new Kernel(storePath());
  const v2 = await kernel.machine(MACHINE_V2);
  const v1 = await kernel.machine(MACHINE_V1);
  return { kernel, v1, v2 };
}

function routeMachine(v1, v2, agg) {
  if (v2.identity.equals(agg.owner)) return v2;
  if (v1.identity.equals(agg.owner)) return v1;
  return null;
}

async function showDesk() {
  try {
    const { kernel, v1, v2 } = await loadMachines();
    let probe;
    try {
      probe = await v2.show(AGGREGATE_ID);
    } catch (err) {
      const cls = mapKernel(err);
      if (cls === "corrupt") refuse("corrupt_state");
      if (isMissing(err)) return { missing: true, kernel, v1, v2 };
      throw err;
    }
    const machine = routeMachine(v1, v2, probe);
    if (!machine) refuse("corrupt_state");
    const agg = machine === v2 ? probe : await machine.show(AGGREGATE_ID);
    return { kernel, machine, agg, state: agg.state, v1, v2 };
  } catch (err) {
    const cls = mapKernel(err);
    if (cls === "corrupt") refuse("corrupt_state");
    if (isMissing(err)) return { missing: true };
    throw err;
  }
}

async function inspectOwned() {
  try {
    await showDesk();
  } catch (err) {
    if (err && err.exitCode) throw err;
    const cls = mapKernel(err);
    if (cls === "corrupt") refuse("corrupt_state");
    throw err;
  }
}

function ensureStateDir() {
  try {
    mkdirSync(process.env.STATE_DIR, { recursive: true });
  } catch {
    refuse("bad_args");
  }
}

function newReqId() {
  return randomBytes(16).toString("hex");
}

async function httpJson(method, url) {
  try {
    const res = await fetch(url, {
      method,
      headers: { "content-type": "application/json", connection: "close" },
    });
    const text = await res.text();
    if (res.status >= 500) return { kind: "unavailable", status: res.status, text };
    let json = null;
    try {
      json = text === "" ? null : JSON.parse(text);
    } catch {
      return { kind: "incomplete", status: res.status, text };
    }
    return { kind: "http", status: res.status, json, text };
  } catch {
    return { kind: "unavailable" };
  }
}

async function httpPost(url, body) {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json", connection: "close" },
      body: JSON.stringify(body),
    });
    const text = await res.text();
    if (res.status >= 500) return { kind: "unavailable", status: res.status, text };
    let json = null;
    try {
      json = text === "" ? null : JSON.parse(text);
    } catch {
      return { kind: "incomplete", status: res.status, text };
    }
    return { kind: "http", status: res.status, json, text };
  } catch {
    return { kind: "unavailable" };
  }
}

async function lookupPayout(reqId) {
  const url = `${serviceBase()}/v1/payouts/${encodeURIComponent(reqId)}`;
  return httpJson("GET", url);
}

async function postPayout(snap) {
  const url = `${serviceBase()}/v1/payouts`;
  return httpPost(url, snap);
}

async function recordAndComplete(agg, responseText) {
  let cur = agg;
  if (cur.pendingIntent) {
    const digest = sha256(responseText);
    const opId = cur.machine.kernel.newOperationId();
    const cap = cur.capability.toWire();
    try {
      const rec = await cur.recordEffectOutcome(digest, {
        operationId: opId,
        intent: cur.pendingIntent,
      });
      cur = await unwrap(cur, rec);
    } catch (err) {
      if (err instanceof TransportError) {
        const found = await cur.machine.lookupOperation(
          cur.id,
          Capability.fromWire(cap),
          opId,
          {
            effect: {
              effect_id: cur.pendingIntent.effectId,
              aggregate_id: cur.pendingIntent.aggregateId,
              planned_generation: cur.pendingIntent.generation,
              payload_digest: cur.pendingIntent.payloadDigest,
              idempotency_key: cur.pendingIntent.idempotencyKey,
              outcome_digest: digest,
            },
          },
        );
        if (found.outcome === "committed_exact") {
          cur = await cur.machine.show(cur.id);
        } else {
          refuse("service_unavailable");
        }
      } else {
        refuse("service_unavailable");
      }
    }
  }
  if (cur.namedState() === "paid") return cur;
  try {
    const done = await cur.command("complete_pay");
    return await unwrap(cur, done);
  } catch (err) {
    if (mapKernel(err) === "corrupt") refuse("corrupt_state");
    const again = await cur.machine.show(cur.id);
    if (again.namedState() === "paid") return again;
    refuse("service_unavailable");
  }
}

function holdBusyOrPaid(state) {
  const s = state.state;
  if (s === "paid") return "already_paid";
  if (s === "held_opened" || s === "held_approved" || s === "payout_pending") return "held_busy";
  return null;
}

async function cmdOpen(argv) {
  if (argv.length !== 3) refuse("bad_args");
  const [payoutId, merchantId, amountRaw] = argv;
  if (!isIdent(payoutId) || !isIdent(merchantId)) refuse("bad_args");
  const money = parseMoney(amountRaw);
  if (money.missing) refuse("bad_args");
  if (money.bad || money.value < 1) refuse("bad_money");
  const existing = await showDesk();
  if (!existing.missing) refuse("already_open");
  ensureStateDir();
  const { v2 } = await loadMachines();
  let created;
  try {
    created = await v2.createWith({
      aggregateId: AGGREGATE_ID,
      command: {
        name: "open",
        args: {
          payout_id: payoutId,
          merchant_id: merchantId,
          amount_cents: money.value,
          fee_pct: 2,
          review_span_ms: 5000,
          dual_threshold: 5000,
          revision: 1,
        },
      },
    });
  } catch (err) {
    if (mapKernel(err) === "corrupt") refuse("corrupt_state");
    if (err && err.code === "IK_ILLEGAL_STATE") refuse("already_open");
    refuse("already_open");
  }
  const agg = created instanceof HistoricalResult ? await v2.show(AGGREGATE_ID) : created;
  const st = agg.state;
  succeed({
    payout_id: st.payout_id,
    merchant_id: st.merchant_id,
    amount_cents: num(st.amount_cents),
    fee_pct: 2,
    review_span_ms: 5000,
    dual_threshold: 5000,
    revision: num(st.revision),
    approval_count: 0,
    phase: "opened",
    hold_active: 0,
    hold_until_ms: null,
    hold_reason: null,
    payout: "none",
    payout_req_id: null,
    fee_cents: null,
    edition: "revised",
  });
}

async function cmdEdit(argv) {
  if (argv.length !== 1) refuse("bad_args");
  const money = parseMoney(argv[0]);
  if (money.missing) refuse("bad_args");
  if (money.bad || money.value < 1) refuse("bad_money");
  const desk = await showDesk();
  if (desk.missing) refuse("not_open");
  const gated = holdBusyOrPaid(desk.state);
  if (gated === "already_paid") refuse("already_paid");
  if (gated === "held_busy") refuse("held_busy");
  const nextRev = num(desk.state.revision) + 1;
  let next;
  try {
    next = await unwrap(
      desk.agg,
      await desk.agg.command("edit_amount", { amount_cents: money.value, revision: nextRev }),
    );
  } catch (err) {
    if (mapKernel(err) === "corrupt") refuse("corrupt_state");
    const s = (await desk.machine.show(AGGREGATE_ID)).state;
    const again = holdBusyOrPaid(s);
    if (again) refuse(again);
    refuse("held_busy");
  }
  succeed({
    payout_id: next.state.payout_id,
    amount_cents: num(next.state.amount_cents),
    revision: num(next.state.revision),
    approval_count: 0,
    phase: "opened",
  });
}

async function cmdApprove(argv) {
  if (argv.length !== 1) refuse("bad_args");
  const approverId = argv[0];
  if (!isIdent(approverId)) refuse("bad_args");
  const desk = await showDesk();
  if (desk.missing) refuse("not_open");
  const gated = holdBusyOrPaid(desk.state);
  if (gated === "already_paid") refuse("already_paid");
  if (gated === "held_busy") refuse("held_busy");
  if (desk.state.state === "approved") refuse("already_approved");
  let next;
  try {
    next = await unwrap(
      desk.agg,
      await desk.agg.command("approve", {
        approver_id: approverId,
        approved_revision: num(desk.state.revision),
      }),
    );
  } catch (err) {
    if (mapKernel(err) === "corrupt") refuse("corrupt_state");
    const s = (await desk.machine.show(AGGREGATE_ID)).state;
    const g = holdBusyOrPaid(s);
    if (g === "already_paid") refuse("already_paid");
    if (g === "held_busy") refuse("held_busy");
    if (s.state === "approved") refuse("already_approved");
    if (s.approver1 === approverId || s.approver2 === approverId) refuse("duplicate_approver");
    refuse("duplicate_approver");
  }
  succeed({
    payout_id: next.state.payout_id,
    approver_id: approverId,
    approval_count: num(next.state.approval_count),
    phase: phaseOf(next.state),
  });
}

async function cmdPlaceHold(argv) {
  if (argv.length !== 0) refuse("bad_args");
  const desk = await showDesk();
  if (desk.missing) refuse("not_open");
  if (desk.state.state === "paid") refuse("already_paid");
  if (desk.state.state === "held_opened" || desk.state.state === "held_approved") refuse("already_held");
  if (desk.state.state === "payout_pending") refuse("held_busy");
  const now = parseNow();
  const until = now + num(desk.state.review_span_ms);
  let next;
  try {
    next = await unwrap(
      desk.agg,
      await desk.agg.command("place_hold", {
        now_ms: now,
        hold_until_ms: until,
        hold_placed_ms: now,
      }),
    );
  } catch (err) {
    if (mapKernel(err) === "corrupt") refuse("corrupt_state");
    const s = (await desk.machine.show(AGGREGATE_ID)).state;
    if (s.state === "paid") refuse("already_paid");
    if (s.state === "held_opened" || s.state === "held_approved") refuse("already_held");
    refuse("held_busy");
  }
  succeed({
    payout_id: next.state.payout_id,
    phase: "held",
    hold_active: 1,
    hold_until_ms: num(next.state.hold_until_ms),
    hold_reason: "fraud_review",
  });
}

async function cmdReleaseHold(argv) {
  if (argv.length !== 0) refuse("bad_args");
  const desk = await showDesk();
  if (desk.missing) refuse("not_open");
  const s0 = desk.state.state;
  if (s0 !== "held_opened" && s0 !== "held_approved") refuse("not_held");
  const now = parseNow();
  let next;
  try {
    next = await unwrap(desk.agg, await desk.agg.command("release_hold", { now_ms: now }));
  } catch (err) {
    if (mapKernel(err) === "corrupt") refuse("corrupt_state");
    const s = (await desk.machine.show(AGGREGATE_ID)).state;
    if (s.state !== "held_opened" && s.state !== "held_approved") refuse("not_held");
    refuse("hold_until");
  }
  succeed({
    payout_id: next.state.payout_id,
    phase: phaseOf(next.state),
    hold_active: 0,
  });
}

async function cmdRiskClear(argv) {
  if (argv.length !== 1) refuse("bad_args");
  const reviewerId = argv[0];
  if (!isIdent(reviewerId)) refuse("bad_args");
  const desk = await showDesk();
  if (desk.missing) refuse("not_open");
  if (emptyNull(desk.state.edition) === "original") refuse("legacy_request");
  const s0 = desk.state.state;
  if (s0 !== "held_opened" && s0 !== "held_approved") refuse("not_held");
  let next;
  try {
    next = await unwrap(desk.agg, await desk.agg.command("risk_clear", { reviewer_id: reviewerId }));
  } catch (err) {
    if (mapKernel(err) === "corrupt") refuse("corrupt_state");
    const s = (await desk.machine.show(AGGREGATE_ID)).state;
    if (emptyNull(s.edition) === "original") refuse("legacy_request");
    if (s.state !== "held_opened" && s.state !== "held_approved") refuse("not_held");
    refuse("not_held");
  }
  succeed({
    payout_id: next.state.payout_id,
    phase: phaseOf(next.state),
    hold_active: 0,
    hold_until_ms: null,
    hold_reason: null,
    hold_reviewer: reviewerId,
    edition: "revised",
  });
}

async function recoverOrSend(desk, lookupFirst) {
  const state = desk.state;
  const reqId = state.payout_req_id;
  const fee = num(state.fee_cents);
  const snap = snapshotOf(state, reqId, fee);
  if (lookupFirst) {
    const looked = await lookupPayout(reqId);
    if (looked.kind === "unavailable" || looked.kind === "incomplete") refuse("service_unavailable");
    if (looked.status === 200) {
      if (!matchingBody(looked.json, snap)) refuse("lookup_conflict");
      const paid = await recordAndComplete(desk.agg, looked.text);
      succeed(payObject(paid.state));
    }
    if (looked.status !== 404) refuse("service_unavailable");
  }
  crashIf("after-pay-saved-before-request");
  const posted = await postPayout(snap);
  if (posted.kind === "unavailable" || posted.kind === "incomplete") refuse("service_unavailable");
  if (posted.status >= 500) refuse("service_unavailable");
  if (posted.status === 409) refuse("lookup_conflict");
  if (posted.status !== 200) refuse("service_unavailable");
  if (!matchingBody(posted.json, snap)) refuse("lookup_conflict");
  crashIf("after-accept-before-record");
  const paid = await recordAndComplete(desk.agg, posted.text);
  crashIf("after-record-before-exit");
  succeed(payObject(paid.state));
}

async function cmdPay(argv) {
  if (argv.length !== 0) refuse("bad_args");
  const desk = await showDesk();
  if (desk.missing) refuse("not_open");
  const s = desk.state.state;
  if (s === "paid") succeed(payObject(desk.state));
  if (s === "held_opened" || s === "held_approved") refuse("held_busy");
  if (num(desk.state.hold_active) === 1) refuse("hold_until");
  if (s === "payout_pending" && !emptyNull(desk.state.payout_req_id)) refuse("service_unavailable");
  if (s === "payout_pending") {
    const fresh = await desk.machine.show(AGGREGATE_ID);
    await recoverOrSend({ ...desk, agg: fresh, state: fresh.state }, true);
    return;
  }
  if (s !== "approved") refuse("approvals_required");
  const fee = Math.trunc(num(desk.state.amount_cents) / 50);
  const reqId = newReqId();
  const snap = snapshotOf(desk.state, reqId, fee);
  let prepared;
  try {
    prepared = await unwrap(
      desk.agg,
      await desk.agg.command("prepare_pay", {
        payout_req_id: reqId,
        fee_cents: fee,
        effect_id: reqId,
        payload_digest: payloadDigest(snap),
        idempotency_key: reqId,
      }),
    );
  } catch (err) {
    if (mapKernel(err) === "corrupt") refuse("corrupt_state");
    const now = (await desk.machine.show(AGGREGATE_ID)).state;
    if (now.state === "paid") succeed(payObject(now));
    if (now.state === "payout_pending") {
      await recoverOrSend({ kernel: desk.kernel, machine: desk.machine, agg: await desk.machine.show(AGGREGATE_ID), state: now }, true);
      return;
    }
    if (now.state === "held_opened" || now.state === "held_approved") refuse("held_busy");
    if (num(now.hold_active) === 1) refuse("hold_until");
    refuse("approvals_required");
  }
  await recoverOrSend(
    { kernel: desk.kernel, machine: desk.machine, agg: prepared, state: prepared.state },
    false,
  );
}

async function cmdReconcile(argv) {
  if (argv.length !== 1) refuse("bad_args");
  const reqId = argv[0];
  if (!isIdent(reqId)) refuse("bad_args");
  const desk = await showDesk();
  if (desk.missing) refuse("not_open");
  if (!emptyNull(desk.state.payout_req_id)) refuse("no_payout");
  if (desk.state.payout_req_id !== reqId) refuse("payout_mismatch");
  if (desk.state.state === "paid") succeed(payObject(desk.state, { lookup: "sent" }));
  const snap = snapshotOf(desk.state, reqId, num(desk.state.fee_cents));
  const looked = await lookupPayout(reqId);
  if (looked.kind === "unavailable" || looked.kind === "incomplete") refuse("service_unavailable");
  if (looked.status === 404) {
    succeed({
      lookup: "not_sent",
      payout_id: desk.state.payout_id,
      payout_req_id: reqId,
      payout: "attempt_saved",
      phase: "payout_pending",
    });
  }
  if (looked.status === 200) {
    if (!matchingBody(looked.json, snap)) refuse("lookup_conflict");
    const paid = await recordAndComplete(desk.agg, looked.text);
    succeed(payObject(paid.state, { lookup: "sent" }));
  }
  refuse("service_unavailable");
}

async function cmdStatus(argv) {
  if (argv.length !== 0) refuse("bad_args");
  const desk = await showDesk();
  if (desk.missing) succeed({ ...EMPTY_STATUS });
  succeed(statusObject(desk.state));
}

async function cmdCallback(argv) {
  if (argv.length !== 1) refuse("bad_args");
  const path = argv[0];
  let text;
  try {
    text = readFileSync(path, "utf8");
  } catch {
    refuse("bad_callback");
  }
  try {
    JSON.parse(text);
  } catch {
    refuse("bad_callback");
  }
  succeed({ ok: true });
}

const COMMANDS = {
  open: cmdOpen,
  "edit-amount": cmdEdit,
  approve: cmdApprove,
  "place-hold": cmdPlaceHold,
  "release-hold": cmdReleaseHold,
  "risk-clear": cmdRiskClear,
  pay: cmdPay,
  reconcile: cmdReconcile,
  status: cmdStatus,
  callback: cmdCallback,
};

async function main() {
  parseNow();
  requireEnv();
  const argv = process.argv.slice(2);
  const name = argv[0];
  await inspectOwned();
  if (!name || !Object.prototype.hasOwnProperty.call(COMMANDS, name)) refuse("unknown_command");
  await COMMANDS[name](argv.slice(1));
}

main().catch((err) => {
  const cls = mapKernel(err);
  if (cls === "corrupt") refuse("corrupt_state");
  if (isMissing(err)) refuse("not_open");
  refuse("bad_args");
});
