import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { cpSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const RUN = join(ROOT, "run");
const NODE = process.execPath;
const STUB = join(ROOT, "stub", "server.mjs");
let failures = 0;
let passed = 0;

function log(name, ok, detail) {
  if (ok) {
    passed += 1;
    console.log(`ok  ${name}`);
  } else {
    failures += 1;
    console.error(`fail  ${name}${detail ? ": " + detail : ""}`);
  }
}

function freshDir(name) {
  const dir = join(tmpdir(), `payout-desk-${name}-${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2)}`);
  mkdirSync(dir, { recursive: true });
  return dir;
}

function parseLine(s) {
  const line = String(s || "").trim().split("\n").filter(Boolean).pop() || "";
  try {
    return JSON.parse(line);
  } catch {
    return { _raw: s };
  }
}

function invoke(env, args, extra = {}) {
  const result = spawnSync(RUN, args, {
    env: { ...process.env, NODE, ...env },
    encoding: "utf8",
    timeout: extra.timeout ?? 15000,
  });
  return {
    status: result.status,
    signal: result.signal,
    stdout: result.stdout,
    stderr: result.stderr,
    json: parseLine(result.stdout),
  };
}

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [STUB], { stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error("stub start timeout"));
    }, 5000);
    child.stdout.on("data", (chunk) => {
      buf += chunk.toString();
      const nl = buf.indexOf("\n");
      if (nl === -1) return;
      clearTimeout(timer);
      try {
        const urls = JSON.parse(buf.slice(0, nl));
        resolve({ child, ...urls });
      } catch (err) {
        child.kill("SIGKILL");
        reject(err);
      }
    });
    child.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

async function fault(control, body) {
  const res = await fetch(`${control}/fault`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  return res.json();
}

async function effects(control) {
  const res = await fetch(`${control}/effects`);
  return res.json();
}

async function posts(control) {
  const res = await fetch(`${control}/posts`);
  return res.json();
}

function envFor(state, service, now, extra = {}) {
  return { STATE_DIR: state, SERVICE_URL: service, NOW_MS: String(now), ...extra };
}

function expectError(name, got, code, status) {
  const ok = got.json && got.json.error === code && got.status !== 0 && (status === undefined || got.status === status);
  log(name, ok, JSON.stringify({ status: got.status, json: got.json, signal: got.signal, stderr: got.stderr }));
}

function expectOk(name, got, pred) {
  const ok = got.status === 0 && got.json && !got.json.error && pred(got.json);
  log(name, ok, JSON.stringify({ status: got.status, json: got.json, stderr: got.stderr }));
}

const stub = await startStub();
const service = stub.service_url;
const control = stub.control_url;

try {
  {
    const state = freshDir("empty");
    const got = invoke(envFor(state, service, 1), ["status"]);
    expectOk("R14 empty status", got, (j) =>
      j.payout_id === null &&
      j.phase === "none" &&
      j.payout === "none" &&
      j.edition === null &&
      j.approval_count === 0 &&
      j.hold_active === 0 &&
      j.hold_until_ms === null &&
      j.fee_cents === null &&
      j.payout_req_id === null,
    );
  }

  {
    const got = invoke({ SERVICE_URL: service, STATE_DIR: freshDir("t") }, ["status"]);
    expectError("missing NOW_MS is bad_time", got, "bad_time");
  }

  {
    const got = invoke({ NOW_MS: "nope", SERVICE_URL: service, STATE_DIR: freshDir("t") }, ["status"]);
    expectError("malformed NOW_MS is bad_time", got, "bad_time");
  }

  {
    const got = invoke({ NOW_MS: "1", STATE_DIR: freshDir("t") }, ["status"]);
    expectError("missing SERVICE_URL is bad_args", got, "bad_args");
  }

  {
    const got = invoke({ NOW_MS: "1", SERVICE_URL: service }, ["status"]);
    expectError("missing STATE_DIR is bad_args", got, "bad_args");
  }

  {
    const got = invoke(envFor(freshDir("t"), service, 1), ["nope"]);
    expectError("unknown command", got, "unknown_command");
  }

  {
    const state = freshDir("open");
    const env = envFor(state, service, 1000);
    const opened = invoke(env, ["open", "PAY-1", "MER-9", "15000"]);
    expectOk("R2 open dual", opened, (j) =>
      j.payout_id === "PAY-1" &&
      j.merchant_id === "MER-9" &&
      j.amount_cents === 15000 &&
      j.fee_pct === 2 &&
      j.review_span_ms === 5000 &&
      j.dual_threshold === 5000 &&
      j.revision === 1 &&
      j.approval_count === 0 &&
      j.phase === "opened" &&
      j.hold_active === 0 &&
      j.hold_until_ms === null &&
      j.payout === "none" &&
      j.edition === "revised" &&
      j.fee_cents === null,
    );
    const again = invoke(env, ["open", "PAY-N", "MER-O", "8000"]);
    expectError("R2 second open", again, "already_open");
    const restarted = invoke(env, ["status"]);
    expectOk("R1 restart after open", restarted, (j) => j.payout_id === "PAY-1" && j.phase === "opened" && j.amount_cents === 15000);

    const a1 = invoke(env, ["approve", "APR-A"]);
    expectOk("R3 first dual approve stays opened", a1, (j) => j.approval_count === 1 && j.phase === "opened");
    const dup = invoke(env, ["approve", "APR-A"]);
    expectError("duplicate approver", dup, "duplicate_approver");
    const a2 = invoke(env, ["approve", "APR-B"]);
    expectOk("R3 second dual approve", a2, (j) => j.approval_count === 2 && j.phase === "approved");
    const third = invoke(env, ["approve", "APR-C"]);
    expectError("already approved", third, "already_approved");
  }

  {
    const state = freshDir("single");
    const env = envFor(state, service, 1);
    invoke(env, ["open", "PAY-O", "MER-O", "4000"]);
    const a = invoke(env, ["approve", "APR-A"]);
    expectOk("R3 single 4000 one approver", a, (j) => j.phase === "approved" && j.approval_count === 1);
  }

  {
    const state = freshDir("th");
    const env = envFor(state, service, 1);
    invoke(env, ["open", "PAY-N", "MER-9", "4000"]);
    const a = invoke(env, ["approve", "APR-A"]);
    expectOk("revised 4000 one approver", a, (j) => j.phase === "approved");
  }

  {
    const state = freshDir("hold");
    const env = envFor(state, service, 1000);
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    const placed = invoke(env, ["place-hold"]);
    expectOk("R4 place-hold until 6000", placed, (j) =>
      j.phase === "held" && j.hold_active === 1 && j.hold_until_ms === 6000 && j.hold_reason === "fraud_review",
    );
    const early = invoke(envFor(state, service, 5999), ["release-hold"]);
    expectError("R4 release at 5999", early, "hold_until");
    const still = invoke(envFor(state, service, 5999), ["status"]);
    expectOk("R4 still held", still, (j) => j.hold_active === 1 && j.phase === "held");
    const released = invoke(envFor(state, service, 6000), ["release-hold"]);
    expectOk("R4 release at 6000", released, (j) => j.hold_active === 0 && j.phase === "opened");
  }

  {
    const state = freshDir("edit");
    const env = envFor(state, service, 5);
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    invoke(env, ["approve", "APR-A"]);
    const edited = invoke(env, ["edit-amount", "15000"]);
    expectOk("R5 edit clears approvals", edited, (j) =>
      j.amount_cents === 15000 && j.approval_count === 0 && j.phase === "opened" && j.revision === 2,
    );
    const pay = invoke(env, ["pay"]);
    expectError("R5 pay after edit needs approvals", pay, "approvals_required");
  }

  {
    const state = freshDir("gates");
    const env = envFor(state, service, 1);
    expectError("R7 approve on none", invoke(env, ["approve", "APR-A"]), "not_open");
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    expectError("R7 release on opened", invoke(env, ["release-hold"]), "not_held");
    invoke(env, ["approve", "APR-A"]);
    invoke(env, ["pay"]);
    expectError("R7 place-hold on paid", invoke(env, ["place-hold"]), "already_paid");
    const paidAgain = invoke(env, ["pay"]);
    expectOk("R6 pay no-op after paid", paidAgain, (j) => j.phase === "paid" && j.payout === "sent" && j.fee_cents === 80);
    const fx = await effects(control);
    log("R6 exactly one effect after no-op", fx.count === 1, JSON.stringify(fx));
  }

  {
    const state = freshDir("fee");
    const env = envFor(state, service, 1);
    invoke(env, ["open", "PAY-1", "MER-9", "15000"]);
    invoke(env, ["approve", "APR-A"]);
    invoke(env, ["approve", "APR-B"]);
    const paid = invoke(env, ["pay"]);
    expectOk("R3 fee 300 on 15000", paid, (j) => j.fee_cents === 300 && j.phase === "paid" && j.payout === "sent");
  }

  {
    const state = freshDir("crash-save");
    const env = envFor(state, service, 9, { CRASH_AT: "after-pay-saved-before-request" });
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    invoke(env, ["approve", "APR-A"]);
    const crashed = invoke(env, ["pay"]);
    log(
      "R8 kill after-pay-saved-before-request",
      crashed.signal === "SIGKILL" || crashed.status === null,
      JSON.stringify({ status: crashed.status, signal: crashed.signal, stdout: crashed.stdout }),
    );
    const st = invoke(envFor(state, service, 9), ["status"]);
    expectOk("R8 attempt_saved survives", st, (j) =>
      j.payout === "attempt_saved" && j.phase === "payout_pending" && typeof j.payout_req_id === "string",
    );
    const before = await effects(control);
    const recovered = invoke(envFor(state, service, 9), ["pay"]);
    expectOk("R8 recover same id", recovered, (j) =>
      j.phase === "paid" && j.payout === "sent" && j.payout_req_id === st.json.payout_req_id,
    );
    const after = await effects(control);
    log("R8 one provider effect", after.count === before.count + 1, JSON.stringify({ before: before.count, after: after.count }));
  }

  {
    const state = freshDir("crash-accept");
    const env = envFor(state, service, 9, { CRASH_AT: "after-accept-before-record" });
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    invoke(env, ["approve", "APR-A"]);
    const crashed = invoke(env, ["pay"]);
    log(
      "R9 kill after-accept-before-record",
      crashed.signal === "SIGKILL",
      JSON.stringify({ status: crashed.status, signal: crashed.signal }),
    );
    const before = await effects(control);
    const recovered = invoke(envFor(state, service, 9), ["pay"]);
    expectOk("R9 recover via later pay", recovered, (j) => j.phase === "paid" && j.payout === "sent");
    const after = await effects(control);
    log("R9 no second effect", after.count === before.count, JSON.stringify({ before: before.count, after: after.count }));
  }

  {
    const state = freshDir("crash-record");
    const env = envFor(state, service, 9, { CRASH_AT: "after-record-before-exit" });
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    invoke(env, ["approve", "APR-A"]);
    const crashed = invoke(env, ["pay"]);
    log(
      "R10 kill after-record-before-exit",
      crashed.signal === "SIGKILL",
      JSON.stringify({ status: crashed.status, signal: crashed.signal }),
    );
    const st = invoke(envFor(state, service, 9), ["status"]);
    expectOk("R10 paid survives new process", st, (j) => j.phase === "paid" && j.payout === "sent");
  }

  {
    const state = freshDir("drop");
    const env = envFor(state, service, 4);
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    invoke(env, ["approve", "APR-A"]);
    await fault(control, { drop_reply: true });
    const dropped = invoke(env, ["pay"]);
    expectError("R11 dropped reply is service_unavailable", dropped, "service_unavailable");
    const st = invoke(env, ["status"]);
    expectOk("R11 attempt_saved after drop", st, (j) => j.payout === "attempt_saved" && j.phase === "payout_pending");
    await fault(control, { drop_reply: false });
    const before = await effects(control);
    const rec = invoke(env, ["reconcile", st.json.payout_req_id]);
    expectOk("R11 reconcile lookup sent", rec, (j) => j.lookup === "sent" && j.phase === "paid" && j.payout === "sent");
    const after = await effects(control);
    log("R11 reconcile does not POST", after.count === before.count, JSON.stringify({ before: before.count, after: after.count, posts: await posts(control) }));
  }

  {
    const state = freshDir("pre-req");
    const env = envFor(state, service, 4, { CRASH_AT: "after-pay-saved-before-request" });
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    invoke(env, ["approve", "APR-A"]);
    invoke(env, ["pay"]);
    const st = invoke(envFor(state, service, 4), ["status"]);
    const beforePosts = await posts(control);
    const rec = invoke(envFor(state, service, 4), ["reconcile", st.json.payout_req_id]);
    expectOk("R12 reconcile not_sent after pre-request crash", rec, (j) =>
      j.lookup === "not_sent" && j.payout === "attempt_saved" && j.phase === "payout_pending",
    );
    const afterPosts = await posts(control);
    log("R12 reconcile never POSTs", afterPosts.count === beforePosts.count, JSON.stringify({ before: beforePosts.count, after: afterPosts.count }));
  }

  {
    const state = freshDir("unrelated");
    const marker = join(state, "keep-me.bin");
    const bytes = Buffer.from([0, 1, 2, 255, 10, 0]);
    writeFileSync(marker, bytes);
    const env = envFor(state, service, 1);
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    invoke(env, ["status"]);
    const after = readFileSync(marker);
    log("R13 unrelated bytes survive", Buffer.compare(bytes, after) === 0, after.toString("hex"));
  }

  {
    const state = freshDir("corrupt");
    writeFileSync(join(state, "desk.ik.sqlite"), "not-a-store");
    const got = invoke(envFor(state, service, 1), ["status"]);
    expectError("corrupt_state not rewritten", got, "corrupt_state");
    log("corrupt file left in place", readFileSync(join(state, "desk.ik.sqlite"), "utf8") === "not-a-store");
  }

  {
    const state = freshDir("ids");
    const env = envFor(state, service, 1);
    expectError("bad identifier", invoke(env, ["open", "PAY 1", "MER-9", "8"]), "bad_args");
    expectError("bad money", invoke(env, ["open", "PAY-1", "MER-9", "0"]), "bad_money");
    expectError("bad money format", invoke(env, ["open", "PAY-1", "MER-9", "08"]), "bad_money");
  }

  {
    const state = freshDir("cb");
    const env = envFor(state, service, 1);
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    const good = join(state, "cb.json");
    writeFileSync(good, JSON.stringify({ event: "ignored", payout_id: "PAY-X" }));
    const cb = invoke(env, ["callback", good]);
    expectOk("callback well-formed ignored", cb, (j) => j.ok === true);
    const st = invoke(env, ["status"]);
    expectOk("callback does not overwrite", st, (j) => j.payout_id === "PAY-1" && j.phase === "opened");
    const bad = invoke(env, ["callback", join(state, "missing.json")]);
    expectError("callback missing is bad_callback", bad, "bad_callback");
  }

  {
    const state = freshDir("held-busy");
    const env = envFor(state, service, 1000);
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    invoke(env, ["place-hold"]);
    expectError("approve while held", invoke(env, ["approve", "APR-A"]), "held_busy");
    expectError("edit while held", invoke(env, ["edit-amount", "9000"]), "held_busy");
    expectError("pay while held", invoke(env, ["pay"]), "held_busy");
    expectError("second hold", invoke(env, ["place-hold"]), "already_held");
  }

  {
    const state = freshDir("5xx");
    const env = envFor(state, service, 3);
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    invoke(env, ["approve", "APR-A"]);
    await fault(control, { error_status: 503 });
    const got = invoke(env, ["pay"]);
    expectError("5xx is service_unavailable", got, "service_unavailable");
    const st = invoke(env, ["status"]);
    expectOk("5xx leaves attempt_saved", st, (j) => j.payout === "attempt_saved");
    await fault(control, { error_status: 0 });
  }

  {
    const state = freshDir("rec-mismatch");
    const env = envFor(state, service, 3);
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    expectError("reconcile with no payout", invoke(env, ["reconcile", "abc"]), "no_payout");
    invoke(env, ["approve", "APR-A"]);
    invoke(env, ["pay"]);
    const st = invoke(env, ["status"]);
    expectError("reconcile other id", invoke(env, ["reconcile", "other-id"]), "payout_mismatch");
    const rec = invoke(env, ["reconcile", st.json.payout_req_id]);
    expectOk("reconcile after paid", rec, (j) => j.lookup === "sent" && j.phase === "paid");
  }

  {
    const state = freshDir("c1");
    const env = envFor(state, service, 1000);
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    invoke(env, ["place-hold"]);
    const beforeFx = await effects(control);
    const cleared = invoke(envFor(state, service, 2000), ["risk-clear", "REV-K"]);
    expectOk("C1 risk-clear", cleared, (j) =>
      j.phase === "opened" &&
      j.hold_active === 0 &&
      j.hold_until_ms === null &&
      j.hold_reason === null &&
      j.hold_reviewer === "REV-K" &&
      j.edition === "revised",
    );
    const afterFx = await effects(control);
    log("C1 no provider effect", afterFx.count === beforeFx.count, JSON.stringify({ before: beforeFx.count, after: afterFx.count }));
    const restarted = invoke(envFor(state, service, 2000), ["status"]);
    expectOk("C2 cleared hold survives process", restarted, (j) =>
      j.hold_active === 0 && j.hold_until_ms === null && j.hold_reason === null && j.hold_reviewer === "REV-K",
    );
  }

  {
    const state = freshDir("c3");
    const env = envFor(state, service, 1);
    invoke(env, ["open", "PAY-1", "MER-9", "6000"]);
    const one = invoke(env, ["approve", "APR-A"]);
    expectOk("C3 first of two on 6000", one, (j) => j.phase === "opened" && j.approval_count === 1);
    expectError("C3 pay with one approver", invoke(env, ["pay"]), "approvals_required");
    invoke(env, ["approve", "APR-B"]);
    invoke(env, ["place-hold"]);
    expectError("C3 release-hold still clocked", invoke(envFor(state, service, 2000), ["release-hold"]), "hold_until");
    const cleared = invoke(envFor(state, service, 2000), ["risk-clear", "REV-K"]);
    expectOk("C3 risk-clear before until", cleared, (j) => j.hold_active === 0 && j.phase === "approved");
    const paid = invoke(envFor(state, service, 2000), ["pay"]);
    expectOk("C3 fee 120 on 6000", paid, (j) => j.fee_cents === 120 && j.phase === "paid");
  }

  {
    const src = "/tmp/payout-desk-n17-r1-old-opened6000";
    const state = freshDir("c4");
    cpSync(src, state, { recursive: true });
    const env = envFor(state, service, 1000);
    const st = invoke(env, ["status"]);
    expectOk("C4 original edition and threshold", st, (j) =>
      j.edition === "original" && j.dual_threshold === 10000 && j.amount_cents === 6000 && j.phase === "opened",
    );
    const a = invoke(env, ["approve", "APR-A"]);
    expectOk("C4 single approver on original 6000", a, (j) => j.phase === "approved");
    expectError("C4 risk-clear original opened is legacy_request", invoke(env, ["risk-clear", "REV-K"]), "legacy_request");
    const paid = invoke(env, ["pay"]);
    expectOk("C4 original 6000 pay after one approver", paid, (j) => j.phase === "paid" && j.fee_cents === 120);
  }

  {
    const src = "/tmp/payout-desk-n17-r1-old-held";
    const state = freshDir("c2-old");
    cpSync(src, state, { recursive: true });
    const env = envFor(state, service, 2000);
    const before = invoke(env, ["status"]);
    expectOk("old held status", before, (j) => j.edition === "original" && j.hold_active === 1 && j.hold_until_ms === 6000);
    expectError("C2 old risk-clear is legacy_request", invoke(env, ["risk-clear", "REV-K"]), "legacy_request");
    const after = invoke(env, ["status"]);
    expectOk("C2 old hold unchanged", after, (j) =>
      j.hold_active === 1 && j.hold_until_ms === 6000 && j.hold_reason === "fraud_review",
    );
  }

  {
    const state = freshDir("c5");
    const env = envFor(state, service, 1000);
    invoke(env, ["open", "PAY-1", "MER-9", "4000"]);
    invoke(env, ["approve", "APR-A"]);
    invoke(env, ["place-hold"]);
    invoke(envFor(state, service, 2000), ["risk-clear", "REV-K"]);
    const crashed = invoke(envFor(state, service, 2000, { CRASH_AT: "after-pay-saved-before-request" }), ["pay"]);
    log(
      "C5 crash after save",
      crashed.signal === "SIGKILL" || crashed.status === null,
      JSON.stringify({ status: crashed.status, signal: crashed.signal }),
    );
    const st = invoke(envFor(state, service, 2000), ["status"]);
    const reqId = st.json.payout_req_id;
    expectOk("C5 attempt saved", st, (j) => j.payout === "attempt_saved" && typeof j.payout_req_id === "string");
    const before = await effects(control);
    const recovered = invoke(envFor(state, service, 2000), ["pay"]);
    expectOk("C5 recover same id", recovered, (j) => j.payout_req_id === reqId && j.phase === "paid");
    const after = await effects(control);
    log("C5 one effect", after.count === before.count + 1, JSON.stringify({ before: before.count, after: after.count }));
  }
} finally {
  stub.child.kill("SIGKILL");
}

console.log(`${passed} passed, ${failures} failed`);
if (failures > 0) process.exit(1);
