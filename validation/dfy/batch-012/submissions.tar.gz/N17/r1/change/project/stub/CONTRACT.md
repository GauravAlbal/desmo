# Payout transfer service contract

The service URL printed by `server.mjs` is the only URL an application may use. It exposes `POST /v1/payouts` and `GET /v1/payouts/<payout_req_id>`.

POST requires JSON with `payout_req_id`, `payout_id`, `merchant_id`, `amount_cents`, and `fee_cents`. `amount_cents` and `fee_cents` are positive integers (`fee_cents` may be zero). The first accepted payout request stores one effect and returns HTTP 200 with those fields plus `outcome:"sent"`. Repeating the same payout request id with identical fields returns the same result and does not add an effect. Reusing an id with different fields returns 409. Invalid bodies return 400. A configured 5xx stores nothing. The provider may drop a successful reply after storing it or delay a reply.

GET returns the stored 200 object or 404 `{error:"not_found"}`. The application must use its saved payout request id for lookup and retry, and must not use the control URL.
