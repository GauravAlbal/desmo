# Payout desk

Durable local desk for one merchant payout. Lifecycle authority is the Ikaros
runtime; this program owns CLI parsing, HTTP, and files.

## Setup

Node 22 is required (`<node-bin>/node` on
this machine, or another Node 22 on `PATH`). npm registry access is not needed.

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x run
```

## Run

Start the fake payout service from another shell (it prints `service_url`):

```sh
node stub/server.mjs
```

Then:

```sh
export STATE_DIR=/tmp/payout-desk
export SERVICE_URL=http://127.0.0.1:<port>
export NOW_MS=1000
./run open PAY-1 MER-9 4000
./run approve APR-A
./run approve APR-B
./run pay
./run status
```

`./run` prints one JSON object. Exit 0 is success. Refusals are nonzero with
`{"error":"<code>"}`. Optional `CRASH_AT` is one of
`after-pay-saved-before-request`, `after-accept-before-record`,
`after-record-before-exit`.

## Tests

```sh
node tests/desk.test.mjs
```

The suite starts `stub/server.mjs` itself and covers process restart, crash
labels, dropped replies, and the named refusals.
