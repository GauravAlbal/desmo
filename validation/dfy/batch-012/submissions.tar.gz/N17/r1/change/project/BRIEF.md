# Payout desk with dual approval and fraud hold

The program behind `./run` is a durable local desk for one merchant payout. A payout is opened with an amount, may need one or two distinct approvers, may be placed on a fraud-review hold, and is sent through one external payout API. The fee, the hold deadline, and the approval bar are evaluated from stored values and `NOW_MS`. A payout request has an application-created id saved before the HTTP request; recovery looks up that id before any retry.

## Scope and invocation

One machine and one process at a time. At most one payout is bound to a state directory. An unrelated writer may create or modify other files in `STATE_DIR`; those files must survive byte-for-byte. The tool may keep its durable files in `STATE_DIR` under any names. It must use `STATE_DIR`, `SERVICE_URL`, `NOW_MS`, and optional `CRASH_AT`. `SERVICE_URL` is required for every command, including status (status never contacts it). `NOW_MS` is a required non-negative integer epoch-millisecond clock for every command.

`./run <command> [args]` prints exactly one JSON object and nothing else (one trailing newline is allowed). Exit 0 is success. Refusals are nonzero and print `{ "error": "<code>" }`. Identifiers (`payout_id`, `merchant_id`, `approver_id`, `payout_req_id`, `reviewer_id`) are 1–64 characters matching `A-Za-z0-9._-`. Money values (`amount_cents`, `fee_cents`) are canonical non-negative decimal integers; `amount_cents` on `open` and `edit-amount` must be at least 1. `CRASH_AT` labels are:

* `after-pay-saved-before-request`: after saving a payout request id and its snapshot, before sending a request;
* `after-accept-before-record`: after reading a complete successful provider response, before saving the paid record;
* `after-record-before-exit`: after saving the paid record, before success JSON is written.

A process must kill itself with SIGKILL at a reached label. Durable commits are flushed before the command treats them as committed. A malformed owned state file is `corrupt_state` and is not rewritten. Refusals do not modify state except that a transmit path named below may durably record a saved payout-request attempt.

## Clock, environment, and precedence

Missing or non-canonical `NOW_MS` (not a decimal integer in `0` through `9007199254740991`) is `bad_time` and wins every other refusal. Missing `STATE_DIR` or missing `SERVICE_URL` is `bad_args`. An unknown command is `unknown_command`. Identifier parse failures are `bad_args` and win status-gated codes on the same invocation. Malformed or non-positive money is `bad_money`. When two domain refusals could apply, the first matching code in the list at the end of this file wins.

## Commands

`open <payout_id> <merchant_id> <amount_cents>` binds the empty-or-idle desk to one payout. It stores `fee_pct` as `2`, `review_span_ms` as `5000`, and `dual_threshold` as `10000`. It returns `{payout_id,merchant_id,amount_cents,fee_pct:2,review_span_ms:5000,dual_threshold:10000,revision:1,approval_count:0,phase:"opened",hold_active:0,hold_until_ms:null,hold_reason:null,payout:"none",payout_req_id:null,fee_cents:null,edition:"original"}`. A second open is `already_open`. It never contacts the provider.

`edit-amount <amount_cents>` is valid for `opened` or `approved`. It records the new amount, increments `revision` by 1, and clears every recorded approver so prior approvals do not authorize a later payout. It returns `{payout_id,amount_cents,revision,approval_count:0,phase:"opened"}`. `held`, `payout_pending`, or `paid` is `held_busy` (already `paid` is `already_paid`). `none` is `not_open`. It never contacts the provider.

`approve <approver_id>` records one approver. A payout whose `amount_cents` is greater than `dual_threshold` needs two distinct approvers before it is `approved`; a payout whose `amount_cents` is `dual_threshold` or less needs one. Repeating the same `approver_id` as an already recorded approver on this revision is `duplicate_approver`. A third distinct approver on an already `approved` payout is `already_approved`. Success returns `{payout_id,approver_id,approval_count,phase}` where `phase` is `"approved"` once the required number of distinct approvers is present, otherwise `"opened"`. `held` is `held_busy`. `payout_pending` or `paid` is `already_paid` when paid, else `held_busy`. It never contacts the provider.

`place-hold` is valid for `opened` or `approved` when `hold_active` is `0`. It records `hold_placed_ms` as the current `NOW_MS`, `hold_reason` as `fraud_review`, and `hold_until_ms` as `NOW_MS + review_span_ms` (the span stored at open). It returns `{payout_id,phase:"held",hold_active:1,hold_until_ms,hold_reason:"fraud_review"}`. A second live hold is `already_held`. Any other phase is `held_busy` except `not_open` when none. It never contacts the provider. Worked clock: `place-hold` at `NOW_MS` 1000 records `hold_until_ms` 6000.

`release-hold` is valid only for `held`. It succeeds only when `hold_active` is `1` and `NOW_MS` is greater than or equal to `hold_until_ms`. It sets `hold_active` to `0` and returns `{payout_id,phase,hold_active:0}` where `phase` is `"approved"` if this revision is already fully approved, otherwise `"opened"`. If `NOW_MS` is less than `hold_until_ms`, the command returns `hold_until` and changes nothing. Not held is `not_held`. Worked clocks: `release-hold` at 5999 is `hold_until`; at 6000 it succeeds. It never contacts the provider.

`pay` sends the payout. It is valid only when `hold_active` is `0` and the current revision is fully approved. The payout fee is two percent of `amount_cents`, rounded down (`fee_pct` 2 stored at open). Worked amount: `amount_cents` 15000 yields `fee_cents` 300. Before a saved attempt, it generates a `payout_req_id` and saves its snapshot (`payout_id`, `merchant_id`, `amount_cents`, `fee_cents`), then posts once. A matching successful response sets `payout:"sent"`, `phase:"paid"`, and returns `{payout_id,payout_req_id,amount_cents,fee_cents,phase:"paid",payout:"sent"}`. Repeating `pay` after `phase:"paid"` is a success no-op without a provider call. Connection failure, an incomplete response, or HTTP 5xx leaves `payout:"attempt_saved"`, keeps `phase:"payout_pending"`, and returns `service_unavailable`; that invocation does not lookup. Missing approvals is `approvals_required`. An active hold is `hold_until`. `held` is `held_busy`. Not open is `not_open`.

If a saved attempt exists, `pay` first `GET /v1/payouts/<payout_req_id>`: a matching 200 is adopted without POST; a 404 causes one POST with the saved id only. Never allocate a replacement id. A mismatching success is `lookup_conflict` and changes nothing.

`reconcile <payout_req_id>` never POSTs or allocates. No saved payout request is `no_payout`; another id is `payout_mismatch`. Lookup 200 with matching ids, merchant, amount, and fee commits the paid state and returns the pay success object plus `lookup:"sent"`; 404 returns exit 0 `{lookup:"not_sent",payout_id,payout_req_id,payout:"attempt_saved",phase:"payout_pending"}`; a mismatch is `lookup_conflict`; transport failure is `service_unavailable`. After `risk-clear` or any other command that ends a hold, a following `reconcile` or `status` is not `corrupt_state`.

`status` never contacts the provider and returns `{payout_id,merchant_id,amount_cents,fee_pct,review_span_ms,dual_threshold,revision,approval_count,approver1,approver2,approved_revision,hold_active,hold_until_ms,hold_reason,hold_reviewer,fee_cents,payout_req_id,phase,payout,edition}`. Empty fields are null, with `phase:"none"`, `payout:"none"`, `hold_active:0`, `approval_count:0`. `edition` is `null` on an empty store and `"original"` on a payout opened by this initial program. `hold_until_ms` and `hold_reason` are null when no live hold deadline is stored (zero or empty). `fee_cents` is null until a payout attempt records it.

`callback <path>` reads one JSON callback. It must not POST or allocate. A malformed callback is `bad_callback`. A well-formed callback is ignored and returns `{ok:true}`. It must never overwrite opened, approved, held, payout_pending, or paid state.

Example identifiers used in this contract: `payout_id` values `PAY-1`, `PAY-O`, `PAY-N`; `merchant_id` values `MER-9`, `MER-O`; `approver_id` values `APR-A`, `APR-B`; `reviewer_id` value `REV-K`. Worked amounts: 15000 (needs two approvers, fee 300), 8000 (needs one approver, fee 160), 10000 (needs one approver).

## Provider

The supplied service has `POST /v1/payouts` and `GET /v1/payouts/<payout_req_id>`. POST requires JSON with `payout_req_id`, `payout_id`, `merchant_id`, `amount_cents`, and `fee_cents`. A first valid id records one effect and returns those fields plus `outcome:"sent"`. Repeating the same id with identical fields returns the same object without another effect; any differing field is HTTP 409. Unknown lookup is 404 `{error:"not_found"}`. Invalid bodies are 400. A configured 5xx stores nothing. The provider may drop a successful reply after storing it or delay a reply. Control endpoints are not part of this contract.

## Refusal precedence

When more than one refusal condition holds, the first matching code in this list wins.

1. Missing or malformed `NOW_MS` → `bad_time`.
2. Missing `SERVICE_URL` or `STATE_DIR` → `bad_args`.
3. Malformed owned state → `corrupt_state`.
4. Unknown command name → `unknown_command`.
5. Wrong arity or malformed identifier → `bad_args`.
6. Malformed or non-positive money where a money argument is present → `bad_money`.
7. No bound payout (except `open` and `status`) → `not_open`.
8. `open` on a bound payout → `already_open`.
9. Command-specific, in the order written below.

`edit-amount`: `already_paid`; `held_busy`.

`approve`: `already_paid`; `held_busy`; `already_approved`; `duplicate_approver`.

`place-hold`: `already_paid`; `held_busy`; `already_held`.

`release-hold`: `not_held`; `hold_until`.

`pay`: `already_paid` (paid no-op is success, not a refusal); `not_open`; `held_busy`; `hold_until`; `approvals_required`.

`reconcile`: `no_payout`; `payout_mismatch`; then provider codes `lookup_conflict` or `service_unavailable`.

`callback`: `bad_callback` only for a malformed file; a well-formed callback is success.

## Requirements

R1. Open and every later committed record survive new processes, including a payout attempt killed at `after-pay-saved-before-request`.

R2. `open` validates identifiers and amount, persists `fee_pct` 2, `review_span_ms` 5000, and `dual_threshold` 10000, and refuses a second bind with `already_open`.

R3. A payout of `amount_cents` 15000 needs two distinct approvers (`APR-A` then `APR-B`) before `phase` is `"approved"`. A payout of 8000 or 10000 becomes `"approved"` after one approver. `pay` of 15000 records `fee_cents` 300.

R4. `place-hold` at `NOW_MS` 1000 records `hold_until_ms` 6000. `release-hold` at 5999 is `hold_until` and leaves `hold_active` 1. `release-hold` at 6000 sets `hold_active` 0.

R5. Editing the amount after an approval returns the desk to `opened` with `approval_count` 0 and a higher `revision`. `pay` after that edit without new approvals is `approvals_required`.

R6. A healthy provider permits `pay` and exactly one external send effect; repeating `pay` after `phase:"paid"` is a no-op and does not add an effect.

R7. Status-gated commands (`approve` on `none`, `place-hold` on `paid`, `release-hold` on `opened`) return the codes named above and do not contact the provider.

R8. A kill at `after-pay-saved-before-request` leaves `payout:"attempt_saved"` and the saved `payout_req_id`. A later `pay` recovers that same id; provider effect count is 1.

R9. A kill at `after-accept-before-record` is recovered by a later `pay` or `reconcile` using the saved id; provider effect count is 1.

R10. A kill at `after-record-before-exit` leaves `phase:"paid"` and `payout:"sent"` for a new process.

R11. A dropped successful reply returns `service_unavailable` with `payout:"attempt_saved"`. Later `reconcile` of the saved id returns `lookup:"sent"` and does not create a second effect.

R12. `reconcile` never POSTs. After a pre-request crash, `reconcile` of the saved id returns `lookup:"not_sent"` with zero POSTs in that invocation.

R13. Unrelated files in `STATE_DIR` survive byte-for-byte.

R14. The program prints one JSON object, requires `NOW_MS` (`bad_time` when missing) and `SERVICE_URL`, and binds at most one payout (`already_open`). `status` on an empty desk is `{payout_id:null,merchant_id:null,amount_cents:null,fee_pct:null,review_span_ms:null,dual_threshold:null,revision:null,approval_count:0,approver1:null,approver2:null,approved_revision:null,hold_active:0,hold_until_ms:null,hold_reason:null,hold_reviewer:null,fee_cents:null,payout_req_id:null,phase:"none",payout:"none",edition:null}`.
