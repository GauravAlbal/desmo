# Change: early risk-clear and a lower dual-approval bar

R1–R14 remain in force except where this file supersedes the dual-approval threshold stored at `open` and adds an early hold-clear command. Those two original rules continue to apply to payouts opened before this change; they do not apply to payouts opened after this change. `status` still reports `edition`, which is `null` on an empty store, `"original"` on a payout opened by the pre-change program, and `"revised"` on a payout opened by the changed program.

The new command is:

`risk-clear <reviewer_id>`

It is valid only for a `held` payout whose `edition` is `"revised"`. It records `hold_reviewer` as that `reviewer_id`, ends the hold immediately (`hold_active` 0) even when `NOW_MS` is still less than the stored `hold_until_ms`, and clears `hold_until_ms` and `hold_reason` so a later `status` or `reconcile` shows `hold_until_ms:null` and `hold_reason:null` (not the old deadline or `fraud_review`). It returns `{payout_id,phase,hold_active:0,hold_until_ms:null,hold_reason:null,hold_reviewer,edition:"revised"}` where `phase` is `"approved"` if this revision is already fully approved, otherwise `"opened"`. `risk-clear` never contacts the provider. An empty or malformed `reviewer_id` is `bad_args`. A payout that is not `held` is `not_held`. An `edition:"original"` payout is `legacy_request` even if it is `held` (`legacy_request` wins `not_held`) and nothing mutates.

`open` is revised only for payouts opened under the new definition. It stores `dual_threshold` as `5000` instead of `10000`. The success object shape is unchanged except `dual_threshold` is 5000 and `edition` is `"revised"`. A new payout of `amount_cents` 6000 therefore needs two distinct approvers. An original payout of 6000 still needs one. Worked amounts on a revised payout: 4000 needs one approver; 6000 and 15000 need two. `fee_pct` remains 2 and `review_span_ms` remains 5000. `place-hold` / `release-hold` clocks are unchanged: hold at 1000 still records `hold_until_ms` 6000, and `release-hold` at 5999 remains `hold_until`. `risk-clear` at 2000 on a revised held payout succeeds and clears the hold facts.

## Old-instance policy

For every changed or new behavior:

* `risk-clear` on a payout opened under the original program is `legacy_request` and nothing mutates. Observable: `status.hold_active` stays `1` if it was held, and `status.hold_until_ms` / `status.hold_reason` stay as they were.
* `open` under the original program is not replayed. A payout already stored with `dual_threshold` 10000 keeps that bar. Observable: after the changed program runs against that store, `status.dual_threshold` is 10000 and `status.edition` is `"original"`; `approve` of a single approver on amount 6000 still yields `phase:"approved"`; `pay` after that single approval is allowed.
* `pay`, `place-hold`, `release-hold`, `edit-amount`, `reconcile`, `status`, and `callback` on original payouts keep the original fee (two percent, 15000 → 300), the original hold deadline (`NOW_MS + 5000`), and the original release bar (`NOW_MS >= hold_until_ms`).
* Saved payout-request attempts keep the same `payout_req_id`, snapshot, and R8–R12 recovery rules. `risk-clear` does not allocate or POST.

Old instances remain fully usable to completion under the original rules. The changed program must not require a new field, command, or rule of them.

## C1–C5

C1. `risk-clear` on a new `held` payout persists `hold_reviewer`, returns `hold_active` 0 with `hold_until_ms` null and `hold_reason` null, and creates no provider effect.

C2. Cleared hold state survives a new process. A payout created by the pre-change program (`OLD_PROJECT_DIR`) refuses `risk-clear` with `legacy_request` without mutation.

C3. On a new payout, `pay` of amount 6000 with a single approver is `approvals_required`. After a second distinct approver, `pay` records `fee_cents` 120. `risk-clear` at a clock before `hold_until_ms` allows a later `pay` that would have been `hold_until` without it.

C4. A payout opened by the pre-change program keeps `dual_threshold` 10000 when the changed program runs against that same store: amount 6000 still becomes `"approved"` after one approver, and `status` reports `edition:"original"`. `risk-clear` on that payout is `legacy_request`.

C5. After `risk-clear` on a revised payout, a saved-attempt crash or dropped reply still recovers the same `payout_req_id` by lookup/retry, and no second provider effect is created. After that recovery, a new payout still uses `dual_threshold` 5000 and accepts `risk-clear`.
