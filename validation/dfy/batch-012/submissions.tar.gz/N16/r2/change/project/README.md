# Card authorization desk

Durable local desk for one merchant card payment: open → authorize → capture (exactly one provider POST) → settlement hold → refund. Lifecycle rules and persistence are owned by an Ikaros machine (`machines/card_desk.ik.toml`). The host (`src/desk.mjs`) parses the CLI, talks HTTP, and proposes derived amounts/deadlines; guards check those relationships.

## Setup

Node 22 is required (`<node-bin>/node` on this machine). There is no public npm registry in this environment.

```sh
npm install --offline --no-audit --no-fund
chmod +x run
```

The install uses the local tarballs already listed in `package.json` (`KIT/npm/ikaros-runtime-0.5.0.tgz` and `KIT/npm/ikaros-darwin-arm64-0.5.0.tgz`).

## Run

```sh
export STATE_DIR=/tmp/desk-state
export SERVICE_URL=http://127.0.0.1:PORT
export NOW_MS=1000
./run open MERCH-1
./run authorize AUTH-1 10000 250 3600000
./run capture 4000
./run status
./run release-hold
NOW_MS=86402001 ./run refund 4000
```

`SERVICE_URL` is the URL printed by `node stub/server.mjs` (ephemeral port). Every command, including `status`, requires `STATE_DIR`, `SERVICE_URL`, and `NOW_MS`. Optional `CRASH_AT` labels are `after-capture-saved-before-request`, `after-accept-before-record`, and `after-record-before-exit`.

`./run` prints exactly one JSON object. Exit 0 is success. Refusals are nonzero `{ "error": "<code>" }`.

## Tests

```sh
npm test
```

The suite starts `stub/server.mjs`, then covers process restart, crash labels, lost replies, R1–R14, and status-gated refusals.

## Workbench

```sh
node_modules/@ikaros/darwin-arm64/bin/ik identity machines/card_desk.ik.toml
node_modules/@ikaros/darwin-arm64/bin/ik check machines/card_desk.ik.toml --profile .ik/checks.toml --corpus machines/card_desk.ik.cases.json
node_modules/@ikaros/darwin-arm64/bin/ik scenario run machines/card_desk.ik.toml scenarios/normal.json --out /tmp/card-desk-normal
```
