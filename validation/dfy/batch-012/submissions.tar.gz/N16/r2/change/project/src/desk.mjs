#!/usr/bin/env node
import { createHash, randomBytes } from "node:crypto";
import { mkdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Aggregate,
  Kernel,
  KernelError,
  StoreNotFoundError,
  classify,
} from "@ikaros/runtime";

const ROOT_DIR = join(dirname(fileURLToPath(import.meta.url)), "..");
const V1_PATH = join(ROOT_DIR, "machines", "card_desk.ik.toml");
const V2_PATH = join(ROOT_DIR, "machines", "card_desk_v2.ik.toml");
const AGGREGATE_ID = "desk";
const STORE_NAME = "desk.sqlite";
const HOLD_MS = 86400000;
const DAILY_CAP = 50000;
const MAX_SAFE = 9007199254740991;
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const INT_RE = /^(0|[1-9][0-9]*)$/;

const COMMANDS = new Set([
  "open",
  "authorize",
  "capture",
  "release-hold",
  "refund",
  "reconcile",
  "status",
  "callback",
  "void",
]);

function fail(code) {
  process.stdout.write(JSON.stringify({ error: code }) + "\n");
  process.exit(1);
}

function succeed(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(0);
}

function parseNow(raw) {
  if (raw === undefined || raw === "") return null;
  if (!INT_RE.test(raw)) return null;
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0 || n > MAX_SAFE) return null;
  return n;
}

function parseCanonicalInt(raw) {
  if (raw === undefined || raw === "") return null;
  if (!INT_RE.test(raw)) return null;
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0) return null;
  return n;
}

function parseId(raw) {
  if (typeof raw !== "string" || !ID_RE.test(raw)) return null;
  return raw;
}

function crashAt(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

function digestOf(value) {
  const body = typeof value === "string" ? value : JSON.stringify(value);
  return createHash("sha256").update(body).digest("hex");
}

function snapshotDigest(snap) {
  return digestOf({
    amount_cents: snap.amount_cents,
    auth_id: snap.auth_id,
    capture_id: snap.capture_id,
    merchant_id: snap.merchant_id,
  });
}

function outcomeDigest(obj) {
  return digestOf({
    amount_cents: obj.amount_cents,
    auth_id: obj.auth_id,
    capture_id: obj.capture_id,
    merchant_id: obj.merchant_id,
    outcome: obj.outcome,
  });
}

function serviceRoot(url) {
  return String(url).replace(/\/+$/, "");
}

function named(agg) {
  return agg.namedState();
}

function domainPhase(stateName) {
  if (stateName === "capturing") return "authorized";
  return stateName;
}

function domainNetwork(stateName) {
  if (stateName === "capturing") return "attempt_saved";
  if (stateName === "captured") return "accepted";
  return "none";
}

function n(v, fallback = null) {
  return v === undefined || v === null ? fallback : v;
}

function emptyStatus() {
  return {
    merchant_id: null,
    auth_id: null,
    phase: "none",
    network: "none",
    authorized_cents: null,
    fee_bps: null,
    window_ms: null,
    authorized_ms: null,
    capture_deadline_ms: null,
    captured_cents: 0,
    fee_cents: 0,
    remaining_hold: 0,
    hold_until_ms: null,
    settlement_hold: 0,
    refunded_cents: 0,
    capture_id: null,
    void_reason: null,
  };
}

function statusFrom(agg) {
  if (!agg) return emptyStatus();
  const st = agg.state;
  const stateName = named(agg);
  const phase = domainPhase(stateName);
  const capturingOrCaptured = stateName === "capturing" || stateName === "captured";
  return {
    merchant_id: n(st.merchant_id),
    auth_id: n(st.auth_id),
    phase,
    network: domainNetwork(stateName),
    authorized_cents: n(st.authorized_cents),
    fee_bps: n(st.fee_bps),
    window_ms: n(st.window_ms),
    authorized_ms: n(st.authorized_ms),
    capture_deadline_ms: n(st.capture_deadline_ms),
    captured_cents: n(st.captured_cents, 0),
    fee_cents: n(st.fee_cents, 0),
    remaining_hold: n(st.remaining_hold, 0),
    hold_until_ms: n(st.hold_until_ms),
    settlement_hold: n(st.settlement_hold, 0),
    refunded_cents: n(st.refunded_cents, 0),
    capture_id: capturingOrCaptured ? n(st.capture_id) : null,
    void_reason: stateName === "captured" || st.void_reason === "" ? n(st.void_reason, "") : n(st.void_reason),
  };
}

function openView(agg) {
  const s = statusFrom(agg);
  return {
    merchant_id: s.merchant_id,
    phase: "open",
    auth_id: null,
    authorized_cents: null,
    fee_bps: null,
    window_ms: null,
    authorized_ms: null,
    capture_deadline_ms: null,
    captured_cents: 0,
    fee_cents: 0,
    remaining_hold: 0,
    hold_until_ms: null,
    settlement_hold: 0,
    refunded_cents: 0,
    capture_id: null,
    void_reason: null,
    network: "none",
  };
}

function authorizeView(agg) {
  const st = agg.state;
  return {
    auth_id: st.auth_id,
    merchant_id: st.merchant_id,
    phase: "authorized",
    authorized_cents: st.authorized_cents,
    fee_bps: st.fee_bps,
    window_ms: st.window_ms,
    authorized_ms: st.authorized_ms,
    capture_deadline_ms: st.capture_deadline_ms,
    remaining_hold: st.authorized_cents,
    network: "none",
  };
}

function captureView(agg) {
  const st = agg.state;
  return {
    auth_id: st.auth_id,
    capture_id: st.capture_id,
    phase: "captured",
    captured_cents: st.captured_cents,
    fee_cents: st.fee_cents,
    remaining_hold: st.remaining_hold,
    hold_until_ms: st.hold_until_ms,
    settlement_hold: st.settlement_hold,
    network: "accepted",
  };
}

function isAggregate(value) {
  return value instanceof Aggregate || (value && typeof value.namedState === "function");
}

function asAggregate(value, machine) {
  if (isAggregate(value)) return value;
  return null;
}

function kernelFail(err, fallback = "bad_status") {
  if (err instanceof StoreNotFoundError) fail(fallback);
  const cls = err instanceof KernelError ? classify(err) : undefined;
  if (cls === "corrupt" || (err instanceof KernelError && err.code === "IK_STORE_CORRUPT")) {
    fail("corrupt_state");
  }
  fail(fallback);
}

function mapStoreError(err) {
  if (err instanceof StoreNotFoundError) return "missing";
  if (!(err instanceof KernelError)) throw err;
  const cls = classify(err);
  if (cls === "corrupt" || err.code === "IK_STORE_CORRUPT") fail("corrupt_state");
  if (cls === "not_found") return "missing";
  if (err.code === "IK_ILLEGAL_STATE" && err.rule === "aggregate.not_found") return "missing";
  throw err;
}

async function loadMachines(storePath) {
  const kernel = new Kernel(storePath);
  const v1 = await kernel.machine(V1_PATH);
  const v2 = await kernel.machine(V2_PATH);
  return { kernel, v1, v2 };
}

function routeMachine(agg, machines) {
  if (!agg) return machines.v2;
  if (agg.owner.equals(machines.v1.identity)) return machines.v1;
  if (agg.owner.equals(machines.v2.identity)) return machines.v2;
  fail("corrupt_state");
}

function isLegacy(agg, machines) {
  return Boolean(agg && agg.owner.equals(machines.v1.identity));
}

async function showDesk(machine) {
  try {
    return await machine.show(AGGREGATE_ID);
  } catch (err) {
    const kind = mapStoreError(err);
    if (kind === "missing") return null;
    throw err;
  }
}

function addSafe(a, b) {
  const n = a + b;
  if (!Number.isSafeInteger(n) || n < 0 || n > MAX_SAFE) return null;
  return n;
}

function feeCents(amount) {
  return Math.trunc(amount / 40);
}

function voidReasonFor(remaining) {
  return remaining === 0 ? "" : "open_remainder";
}

function matchesSnapshot(obj, snap) {
  return (
    obj &&
    obj.capture_id === snap.capture_id &&
    obj.auth_id === snap.auth_id &&
    obj.merchant_id === snap.merchant_id &&
    obj.amount_cents === snap.amount_cents
  );
}

function snapshotOf(st) {
  return {
    capture_id: st.capture_id,
    auth_id: st.auth_id,
    merchant_id: st.merchant_id,
    amount_cents: st.capture_amount,
  };
}

function mintCaptureId() {
  return `c-${randomBytes(16).toString("hex")}`;
}

async function httpJson(method, url, body) {
  try {
    const res = await fetch(url, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }
    return { ok: true, status: res.status, text, json };
  } catch {
    return { ok: false };
  }
}

async function providerGet(root, captureId) {
  return httpJson("GET", `${root}/v1/captures/${encodeURIComponent(captureId)}`);
}

async function providerPost(root, snap) {
  return httpJson("POST", `${root}/v1/captures`, snap);
}

async function commitAccepted(agg, digest) {
  let current = agg;
  if (current.effect && current.effect.status === "pending") {
    const recorded = await current.recordEffectOutcome(digest);
    current = asAggregate(recorded) || (await current.machine.show(AGGREGATE_ID));
  }
  if (named(current) !== "captured") {
    const st = current.state;
    const accepted = await current.command("accept_capture", {
      captured_cents: st.capture_amount,
      fee_cents: st.intended_fee_cents,
      remaining_hold: st.intended_remaining,
      hold_until_ms: st.intended_hold_until,
      void_reason: st.intended_void_reason,
    });
    current = asAggregate(accepted) || (await current.machine.show(AGGREGATE_ID));
  }
  return current;
}

async function main() {
  const nowMs = parseNow(process.env.NOW_MS);
  if (nowMs === null) fail("bad_time");
  const stateDir = process.env.STATE_DIR;
  const serviceUrl = process.env.SERVICE_URL;
  if (!stateDir || !serviceUrl) fail("bad_args");
  const argv = process.argv.slice(2);
  const command = argv[0];
  if (!command || !COMMANDS.has(command)) fail("bad_args");
  const storePath = join(stateDir, STORE_NAME);
  const root = serviceRoot(serviceUrl);

  if (command === "callback") {
    const path = argv[1];
    if (!path) fail("bad_args");
    let raw;
    try {
      raw = readFileSync(path, "utf8");
    } catch {
      fail("bad_callback");
    }
    try {
      JSON.parse(raw);
    } catch {
      fail("bad_callback");
    }
    succeed({ ok: true });
  }

  let machines;
  try {
    machines = await loadMachines(storePath);
  } catch (err) {
    kernelFail(err, "bad_args");
  }
  const machineV2 = machines.v2;

  if (command === "status") {
    const agg = await showDesk(machineV2);
    succeed(statusFrom(agg));
  }

  if (command === "open") {
    const merchantId = parseId(argv[1]);
    if (!merchantId) fail("bad_args");
    mkdirSync(stateDir, { recursive: true });
    const existing = await showDesk(machineV2);
    if (existing && named(existing) !== "none") fail("already_open");
    try {
      let agg;
      if (!existing) {
        const created = await machineV2.createWith({
          aggregateId: AGGREGATE_ID,
          command: { name: "open", args: { merchant_id: merchantId } },
        });
        agg = asAggregate(created) || (await machineV2.show(AGGREGATE_ID));
      } else {
        const owner = routeMachine(existing, machines);
        const live = owner === machineV2 ? existing : await owner.show(AGGREGATE_ID);
        agg = await live.command("open", { merchant_id: merchantId });
        agg = asAggregate(agg) || (await owner.show(AGGREGATE_ID));
      }
      succeed(openView(agg));
    } catch (err) {
      if (err instanceof KernelError && err.code === "IK_ILLEGAL_STATE") fail("already_open");
      kernelFail(err, "already_open");
    }
  }

  const aggProbe = await showDesk(machineV2);
  const ownerMachine = routeMachine(aggProbe, machines);
  const agg0 = aggProbe ? (ownerMachine === machineV2 ? aggProbe : await showDesk(ownerMachine)) : null;
  const stateName = agg0 ? named(agg0) : "none";
  const machine = ownerMachine;

  if (command === "authorize") {
    const authId = parseId(argv[1]);
    if (!authId) fail("bad_args");
    const amount = parseCanonicalInt(argv[2]);
    const feeBps = parseCanonicalInt(argv[3]);
    const windowMs = parseCanonicalInt(argv[4]);
    if (amount === null || feeBps === null || windowMs === null) fail("bad_args");
    if (stateName === "authorized" || stateName === "capturing" || stateName === "captured") {
      fail("already_authorized");
    }
    if (stateName !== "open") fail("bad_status");
    if (feeBps !== 250) fail("bad_fee_bps");
    if (amount < 1) fail("bad_money");
    const deadline = addSafe(nowMs, windowMs);
    if (deadline === null) fail("bad_args");
    const args = {
      auth_id: authId,
      amount_cents: amount,
      fee_bps: feeBps,
      window_ms: windowMs,
      authorized_ms: nowMs,
      capture_deadline_ms: deadline,
    };
    if (!isLegacy(agg0, machines)) {
      const prior = n(agg0.state.day_authorized_cents, 0);
      const dayAfter = addSafe(prior, amount);
      if (dayAfter === null) fail("bad_args");
      if (dayAfter > DAILY_CAP) fail("daily_cap");
      args.day_after = dayAfter;
    }
    try {
      const next = await agg0.command("authorize", args);
      succeed(authorizeView(asAggregate(next) || (await machine.show(AGGREGATE_ID))));
    } catch (err) {
      if (err instanceof KernelError && err.code === "IK_ILLEGAL_STATE") fail("bad_status");
      if (err instanceof KernelError && err.code === "IK_INVARIANT_FAILED") {
        if (feeBps !== 250) fail("bad_fee_bps");
        if (amount < 1) fail("bad_money");
        if (!isLegacy(agg0, machines)) fail("daily_cap");
      }
      kernelFail(err, "bad_status");
    }
  }

  if (command === "capture") {
    const amount = parseCanonicalInt(argv[1]);
    if (amount === null) fail("bad_args");
    if (stateName === "none" || stateName === "open") fail("bad_status");
    if (stateName === "captured") {
      if (amount < 1) fail("bad_money");
      succeed(captureView(agg0));
    }
    if (stateName !== "authorized" && stateName !== "capturing") fail("bad_status");
    if (amount < 1) fail("bad_money");
    const st = agg0.state;
    const authorized = st.authorized_cents;
    const deadline = st.capture_deadline_ms;

    if (stateName === "capturing") {
      const snap = snapshotOf(st);
      const looked = await providerGet(root, snap.capture_id);
      if (!looked.ok) fail("service_unavailable");
      if (looked.status === 200) {
        if (!matchesSnapshot(looked.json, snap)) fail("lookup_conflict");
        crashAt("after-accept-before-record");
        const next = await commitAccepted(agg0, outcomeDigest(looked.json));
        crashAt("after-record-before-exit");
        succeed(captureView(next));
      }
      if (looked.status === 404) {
        if (nowMs > deadline) fail("capture_elapsed");
        crashAt("after-capture-saved-before-request");
        const posted = await providerPost(root, snap);
        if (!posted.ok || posted.status >= 500) fail("service_unavailable");
        if (posted.status === 409) fail("lookup_conflict");
        if (posted.status !== 200 || !matchesSnapshot(posted.json, snap)) fail("lookup_conflict");
        crashAt("after-accept-before-record");
        const next = await commitAccepted(agg0, outcomeDigest(posted.json));
        crashAt("after-record-before-exit");
        succeed(captureView(next));
      }
      fail("service_unavailable");
    }

    if (amount > authorized) fail("amount_exceeds_auth");
    if (nowMs > deadline) fail("capture_elapsed");
    const remaining = authorized - amount;
    const fee = feeCents(amount);
    const holdUntil = addSafe(nowMs, HOLD_MS);
    if (holdUntil === null) fail("bad_args");
    const captureId = mintCaptureId();
    const snap = {
      capture_id: captureId,
      auth_id: st.auth_id,
      merchant_id: st.merchant_id,
      amount_cents: amount,
    };
    mkdirSync(stateDir, { recursive: true });
    let planned;
    try {
      planned = await agg0.command("save_capture", {
        capture_id: captureId,
        amount_cents: amount,
        fee_cents: fee,
        remaining_hold: remaining,
        hold_until_ms: holdUntil,
        void_reason: voidReasonFor(remaining),
        now_ms: nowMs,
        payload_digest: snapshotDigest(snap),
      });
      planned = asAggregate(planned) || (await machine.show(AGGREGATE_ID));
    } catch (err) {
      if (err instanceof KernelError && err.code === "IK_ILLEGAL_STATE") fail("bad_status");
      if (err instanceof KernelError && err.code === "IK_INVARIANT_FAILED") {
        if (amount > authorized) fail("amount_exceeds_auth");
        if (nowMs > deadline) fail("capture_elapsed");
        if (amount < 1) fail("bad_money");
      }
      kernelFail(err, "bad_status");
    }
    crashAt("after-capture-saved-before-request");
    const posted = await providerPost(root, snap);
    if (!posted.ok || posted.status >= 500) fail("service_unavailable");
    if (posted.status === 409) fail("lookup_conflict");
    if (posted.status !== 200 || !matchesSnapshot(posted.json, snap)) fail("lookup_conflict");
    crashAt("after-accept-before-record");
    const next = await commitAccepted(planned, outcomeDigest(posted.json));
    crashAt("after-record-before-exit");
    succeed(captureView(next));
  }

  if (command === "release-hold") {
    if (stateName !== "captured") fail("bad_status");
    try {
      const next = await agg0.command("release_hold");
      const agg = asAggregate(next) || (await machine.show(AGGREGATE_ID));
      const st = agg.state;
      succeed({
        auth_id: st.auth_id,
        phase: "captured",
        settlement_hold: 0,
        hold_until_ms: st.hold_until_ms,
      });
    } catch (err) {
      if (err instanceof KernelError && err.code === "IK_ILLEGAL_STATE") fail("bad_status");
      kernelFail(err, "bad_status");
    }
  }

  if (command === "refund") {
    const amount = parseCanonicalInt(argv[1]);
    if (amount === null) fail("bad_args");
    if (stateName !== "captured") fail("bad_status");
    const st = agg0.state;
    if (st.settlement_hold === 1 || !(nowMs > st.hold_until_ms)) fail("hold_active");
    const after = addSafe(st.refunded_cents || 0, amount);
    if (after === null) fail("bad_args");
    if (after > st.captured_cents) fail("amount_exceeds_refundable");
    try {
      const next = await agg0.command("refund", {
        amount_cents: amount,
        refunded_after: after,
        now_ms: nowMs,
      });
      const agg = asAggregate(next) || (await machine.show(AGGREGATE_ID));
      succeed({
        auth_id: agg.state.auth_id,
        phase: "captured",
        refund_cents: amount,
        refunded_cents: agg.state.refunded_cents,
        captured_cents: agg.state.captured_cents,
      });
    } catch (err) {
      if (err instanceof KernelError && err.code === "IK_ILLEGAL_STATE") fail("bad_status");
      if (err instanceof KernelError && err.code === "IK_INVARIANT_FAILED") {
        if (st.settlement_hold === 1 || !(nowMs > st.hold_until_ms)) fail("hold_active");
        if (after > st.captured_cents) fail("amount_exceeds_refundable");
      }
      kernelFail(err, "bad_status");
    }
  }

  if (command === "void") {
    if (isLegacy(agg0, machines)) fail("legacy_desk");
    if (stateName !== "captured") fail("not_captured");
    const remaining = n(agg0.state.remaining_hold, 0);
    if (!(remaining > 0)) fail("nothing_to_void");
    try {
      const next = await agg0.command("void");
      const agg = asAggregate(next) || (await machine.show(AGGREGATE_ID));
      const st = agg.state;
      succeed({
        merchant_id: st.merchant_id,
        phase: "open",
        remaining_hold: 0,
        capture_deadline_ms: 0,
        void_reason: "",
        captured_cents: n(st.captured_cents, 0),
        refunded_cents: n(st.refunded_cents, 0),
        network: "none",
      });
    } catch (err) {
      if (err instanceof KernelError && err.code === "IK_ILLEGAL_STATE") fail("not_captured");
      kernelFail(err, "not_captured");
    }
  }

  if (command === "reconcile") {
    const captureId = parseId(argv[1]);
    if (!captureId) fail("bad_args");
    if (!agg0 || !agg0.state.capture_id) fail("no_capture");
    if (agg0.state.capture_id !== captureId) fail("capture_mismatch");
    if (stateName === "captured") {
      succeed({ ...captureView(agg0), lookup: "local" });
    }
    if (stateName !== "capturing") fail("no_capture");
    const snap = snapshotOf(agg0.state);
    const looked = await providerGet(root, snap.capture_id);
    if (!looked.ok) fail("service_unavailable");
    if (looked.status === 200) {
      if (!matchesSnapshot(looked.json, snap)) fail("lookup_conflict");
      crashAt("after-accept-before-record");
      const next = await commitAccepted(agg0, outcomeDigest(looked.json));
      crashAt("after-record-before-exit");
      succeed({ ...captureView(next), lookup: "accepted" });
    }
    if (looked.status === 404) {
      succeed({
        lookup: "not_sent",
        auth_id: agg0.state.auth_id,
        capture_id: snap.capture_id,
        network: "attempt_saved",
        phase: "authorized",
      });
    }
    fail("service_unavailable");
  }

  fail("bad_args");
}

main().catch((err) => {
  if (err instanceof KernelError) {
    const cls = classify(err);
    if (cls === "corrupt" || err.code === "IK_STORE_CORRUPT") fail("corrupt_state");
    fail("bad_status");
  }
  fail("bad_status");
});
