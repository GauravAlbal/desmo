import { spawn, spawnSync } from "node:child_process";
import { mkdirSync, mkdtempSync, readFileSync, writeFileSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const RUN = join(ROOT, "run");
const OLD_ROOT = process.env.OLD_PROJECT_DIR || "/tmp/card-desk-n16-r2-old";
const OLD_RUN = join(OLD_ROOT, "run");
const STUB = join(ROOT, "stub", "server.mjs");
const NODE = process.execPath;

let failed = 0;
let passed = 0;
function check(name, cond, detail) {
  if (cond) {
    passed += 1;
    console.log(`ok ${name}`);
  } else {
    failed += 1;
    console.error(`FAIL ${name}${detail ? ` :: ${detail}` : ""}`);
  }
}

function eq(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}

function parseJson(text) {
  const line = String(text || "").trim().split("\n").filter(Boolean).at(-1);
  try {
    return JSON.parse(line);
  } catch {
    return { _raw: text };
  }
}

function tmpDir(prefix) {
  return mkdtempSync(join(tmpdir(), `card-desk-${prefix}`));
}

function runDesk({ stateDir, serviceUrl, nowMs, crashAt, args, extraEnv = {} }) {
  const env = {
    PATH: process.env.PATH,
    HOME: process.env.HOME,
    STATE_DIR: stateDir,
    SERVICE_URL: serviceUrl,
    NOW_MS: nowMs === undefined ? undefined : String(nowMs),
    ...extraEnv,
  };
  if (crashAt) env.CRASH_AT = crashAt;
  else delete env.CRASH_AT;
  Object.keys(env).forEach((k) => {
    if (env[k] === undefined) delete env[k];
  });
  return spawnSync(NODE, [RUN, ...args], {
    env,
    encoding: "utf8",
    timeout: 20000,
    cwd: ROOT,
  });
}

function runOldDesk({ stateDir, serviceUrl, nowMs, crashAt, args, extraEnv = {} }) {
  const env = {
    PATH: process.env.PATH,
    HOME: process.env.HOME,
    STATE_DIR: stateDir,
    SERVICE_URL: serviceUrl,
    NOW_MS: nowMs === undefined ? undefined : String(nowMs),
    ...extraEnv,
  };
  if (crashAt) env.CRASH_AT = crashAt;
  else delete env.CRASH_AT;
  Object.keys(env).forEach((k) => {
    if (env[k] === undefined) delete env[k];
  });
  return spawnSync(NODE, [OLD_RUN, ...args], {
    env,
    encoding: "utf8",
    timeout: 20000,
    cwd: OLD_ROOT,
  });
}

function jsonOf(res) {
  return parseJson(res.stdout);
}

async function startStub() {
  const child = spawn(NODE, [STUB], { cwd: ROOT, stdio: ["ignore", "pipe", "pipe"] });
  const line = await new Promise((resolve, reject) => {
    let buf = "";
    const t = setTimeout(() => reject(new Error("stub timeout")), 5000);
    child.stdout.on("data", (c) => {
      buf += c;
      const i = buf.indexOf("\n");
      if (i >= 0) {
        clearTimeout(t);
        resolve(buf.slice(0, i));
      }
    });
    child.on("error", reject);
    child.stderr.on("data", () => {});
  });
  const urls = JSON.parse(line);
  return { child, ...urls };
}

async function control(url, method, path, body) {
  const res = await fetch(`${url}${path}`, {
    method,
    headers: body ? { "content-type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  return res.json();
}

function kill(child) {
  try {
    child.kill("SIGKILL");
  } catch {}
}

async function main() {
  const stub = await startStub();
  const serviceUrl = stub.service_url;
  const controlUrl = stub.control_url;
  try {
    await caseEmptyStatus(serviceUrl);
    await casePrecedence(serviceUrl);
    await caseOpenAuthorize(serviceUrl, controlUrl);
    await caseCaptureRefund(serviceUrl, controlUrl);
    await caseStatusGated(serviceUrl);
    await caseCallback(serviceUrl);
    await caseRestart(serviceUrl);
    await caseCrashSaved(serviceUrl, controlUrl);
    await caseCrashBeforeRecord(serviceUrl, controlUrl);
    await caseCrashAfterRecord(serviceUrl, controlUrl);
    await caseLostReply(serviceUrl, controlUrl);
    await caseFiveHundred(serviceUrl, controlUrl);
    await caseReconcileNotSent(serviceUrl, controlUrl);
    await caseUnrelatedFiles(serviceUrl);
    await caseCorrupt(serviceUrl);
    await caseIdentifierWins(serviceUrl);
    await caseVoidAndCap(serviceUrl, controlUrl);
    await caseLegacyDesk(serviceUrl, controlUrl);
  } finally {
    kill(stub.child);
  }

  console.log(`${passed} passed, ${failed} failed`);
  if (failed) process.exit(1);
}

async function caseEmptyStatus(serviceUrl) {
  const dir = tmpDir("empty-");
  const r = runDesk({ stateDir: dir, serviceUrl, nowMs: 0, args: ["status"] });
  check("R14 empty status exit 0", r.status === 0, `status=${r.status} err=${r.stderr}`);
  check(
    "R14 empty status body",
    eq(jsonOf(r), {
      merchant_id: null,
      auth_id: null,
      phase: "none",
      network: "none",
      authorized_cents: null,
      fee_bps: null,
      window_ms: null,
      authorized_ms: null,
      capture_deadline_ms: null,
      captured_cents: 0,
      fee_cents: 0,
      remaining_hold: 0,
      hold_until_ms: null,
      settlement_hold: 0,
      refunded_cents: 0,
      capture_id: null,
      void_reason: null,
    }),
    JSON.stringify(jsonOf(r)),
  );
}

async function casePrecedence(serviceUrl) {
  const r = spawnSync(NODE, [RUN, "status"], {
    env: { PATH: process.env.PATH, HOME: process.env.HOME },
    encoding: "utf8",
    cwd: ROOT,
    timeout: 10000,
  });
  check("R14 missing NOW_MS is bad_time", r.status !== 0 && jsonOf(r).error === "bad_time", JSON.stringify(jsonOf(r)));

  const r2 = runDesk({
    stateDir: tmpDir("no-svc-"),
    serviceUrl: "",
    nowMs: 1,
    args: ["status"],
    extraEnv: { SERVICE_URL: "" },
  });
  const r2b = spawnSync(NODE, [RUN, "status"], {
    env: {
      PATH: process.env.PATH,
      HOME: process.env.HOME,
      STATE_DIR: tmpDir("no-svc2-"),
      NOW_MS: "1",
    },
    encoding: "utf8",
    cwd: ROOT,
    timeout: 10000,
  });
  check("missing SERVICE_URL is bad_args", r2b.status !== 0 && jsonOf(r2b).error === "bad_args", JSON.stringify(jsonOf(r2b)));

  const r3 = runDesk({ stateDir: tmpDir("unk-"), serviceUrl, nowMs: 1, args: ["nope"] });
  check("unknown command is bad_args", r3.status !== 0 && jsonOf(r3).error === "bad_args");
}

async function caseOpenAuthorize(serviceUrl, controlUrl) {
  const dir = tmpDir("open-");
  const posts0 = await control(controlUrl, "GET", "/posts");
  const open = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  check("open exit 0", open.status === 0, open.stderr);
  const oj = jsonOf(open);
  check("open phase", oj.phase === "open" && oj.merchant_id === "MERCH-1" && oj.network === "none" && oj.auth_id === null);
  const open2 = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  check("second open already_open", open2.status !== 0 && jsonOf(open2).error === "already_open");
  const badId = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "bad id"] });
  check("bad merchant id bad_args", badId.status !== 0 && jsonOf(badId).error === "bad_args");

  const fee = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "251", "3600000"] });
  check("bad_fee_bps", fee.status !== 0 && jsonOf(fee).error === "bad_fee_bps");
  const money = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "0", "250", "3600000"] });
  check("bad_money", money.status !== 0 && jsonOf(money).error === "bad_money");
  const auth = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  check("authorize exit 0", auth.status === 0, auth.stderr);
  const aj = jsonOf(auth);
  check(
    "R2/R3 deadline",
    aj.authorized_ms === 1000 && aj.capture_deadline_ms === 3601000 && aj.authorized_cents === 10000 && aj.remaining_hold === 10000 && aj.fee_bps === 250,
    JSON.stringify(aj),
  );
  const auth2 = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-2", "10000", "250", "3600000"] });
  check("already_authorized", auth2.status !== 0 && jsonOf(auth2).error === "already_authorized");
  const posts1 = await control(controlUrl, "GET", "/posts");
  check("open/authorize never POST", posts1.count === posts0.count, `${posts0.count} -> ${posts1.count}`);
}

async function caseCaptureRefund(serviceUrl, controlUrl) {
  const dir = tmpDir("cap-");
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  const over = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["capture", "10001"] });
  check("amount_exceeds_auth", over.status !== 0 && jsonOf(over).error === "amount_exceeds_auth");
  const lateDir = tmpDir("late-");
  runDesk({ stateDir: lateDir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: lateDir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  const postsBefore = await control(controlUrl, "GET", "/posts");
  const late = runDesk({ stateDir: lateDir, serviceUrl, nowMs: 3601001, args: ["capture", "4000"] });
  check("capture_elapsed", late.status !== 0 && jsonOf(late).error === "capture_elapsed");
  const postsAfter = await control(controlUrl, "GET", "/posts");
  check("elapsed does not POST", postsAfter.count === postsBefore.count);

  const cap = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["capture", "4000"] });
  check("capture exit 0", cap.status === 0, `${cap.stderr} ${cap.stdout}`);
  const cj = jsonOf(cap);
  check(
    "R3 fee and remaining",
    cj.fee_cents === 100 && cj.remaining_hold === 6000 && cj.phase === "captured" && cj.network === "accepted" && cj.settlement_hold === 1 && cj.hold_until_ms === 86402000 && cj.captured_cents === 4000,
    JSON.stringify(cj),
  );
  const st = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["status"] }));
  check("void_reason open_remainder", st.void_reason === "open_remainder", JSON.stringify(st));

  const effects1 = await control(controlUrl, "GET", "/effects");
  const cap2 = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["capture", "4000"] });
  check("second capture no-op", cap2.status === 0 && jsonOf(cap2).network === "accepted");
  const effects2 = await control(controlUrl, "GET", "/effects");
  check("R5 second capture no extra effect", effects2.count === effects1.count, `${effects1.count} -> ${effects2.count}`);

  const hold = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["refund", "4000"] });
  check("refund while held is hold_active", hold.status !== 0 && jsonOf(hold).error === "hold_active");
  const rel = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["release-hold"] });
  check("release-hold", rel.status === 0 && jsonOf(rel).settlement_hold === 0);
  const rel2 = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["release-hold"] });
  check("release-hold no-op", rel2.status === 0 && jsonOf(rel2).settlement_hold === 0);
  const early = runDesk({ stateDir: dir, serviceUrl, nowMs: 86401999, args: ["refund", "4000"] });
  check("R4 clock hold_active", early.status !== 0 && jsonOf(early).error === "hold_active");
  const tooMuch = runDesk({ stateDir: dir, serviceUrl, nowMs: 86402001, args: ["refund", "4001"] });
  check("amount_exceeds_refundable", tooMuch.status !== 0 && jsonOf(tooMuch).error === "amount_exceeds_refundable");
  const refund = runDesk({ stateDir: dir, serviceUrl, nowMs: 86402001, args: ["refund", "4000"] });
  check("refund 4000", refund.status === 0 && jsonOf(refund).refunded_cents === 4000 && jsonOf(refund).refund_cents === 4000, JSON.stringify(jsonOf(refund)));

  const fullDir = tmpDir("full-");
  runDesk({ stateDir: fullDir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: fullDir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  const full = runDesk({ stateDir: fullDir, serviceUrl, nowMs: 2000, args: ["capture", "10000"] });
  check("full capture remaining 0", full.status === 0 && jsonOf(full).remaining_hold === 0 && jsonOf(full).fee_cents === 250);
  const fst = jsonOf(runDesk({ stateDir: fullDir, serviceUrl, nowMs: 2000, args: ["status"] }));
  check("full capture void_reason empty", fst.void_reason === "", JSON.stringify(fst));
}

async function caseStatusGated(serviceUrl) {
  const empty = tmpDir("sg-empty-");
  const a = runDesk({ stateDir: empty, serviceUrl, nowMs: 1, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  check("R7 authorize on none", a.status !== 0 && jsonOf(a).error === "bad_status");
  const openDir = tmpDir("sg-open-");
  runDesk({ stateDir: openDir, serviceUrl, nowMs: 1, args: ["open", "MERCH-1"] });
  const c = runDesk({ stateDir: openDir, serviceUrl, nowMs: 1, args: ["capture", "4000"] });
  check("R7 capture on open", c.status !== 0 && jsonOf(c).error === "bad_status");
  const rh = runDesk({ stateDir: openDir, serviceUrl, nowMs: 1, args: ["release-hold"] });
  check("R7 release-hold on open", rh.status !== 0 && jsonOf(rh).error === "bad_status");
  runDesk({ stateDir: openDir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  const rf = runDesk({ stateDir: openDir, serviceUrl, nowMs: 1, args: ["refund", "1"] });
  check("R7 refund on authorized", rf.status !== 0 && jsonOf(rf).error === "bad_status");
}

async function caseCallback(serviceUrl) {
  const dir = tmpDir("cb-");
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  const before = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["status"] }));
  const good = join(dir, "cb.json");
  writeFileSync(good, JSON.stringify({ capture_id: "x", amount_cents: 1 }));
  const cb = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["callback", good] });
  check("callback well-formed", cb.status === 0 && jsonOf(cb).ok === true);
  const after = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["status"] }));
  check("R6 callback does not overwrite", eq(before, after), JSON.stringify(after));
  const bad = join(dir, "bad.json");
  writeFileSync(bad, "{not json");
  const cb2 = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["callback", bad] });
  check("malformed callback", cb2.status !== 0 && jsonOf(cb2).error === "bad_callback");
}

async function caseRestart(serviceUrl) {
  const dir = tmpDir("rs-");
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  const st = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["status"] }));
  check("R1 restart keeps authorize", st.phase === "authorized" && st.auth_id === "AUTH-1" && st.capture_deadline_ms === 3601000, JSON.stringify(st));
}

async function caseCrashSaved(serviceUrl, controlUrl) {
  const dir = tmpDir("crash-save-");
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  const effects0 = await control(controlUrl, "GET", "/effects");
  const crashed = runDesk({
    stateDir: dir,
    serviceUrl,
    nowMs: 2000,
    crashAt: "after-capture-saved-before-request",
    args: ["capture", "4000"],
  });
  check("R8 crash SIGKILL", crashed.signal === "SIGKILL" || crashed.status === null, `sig=${crashed.signal} status=${crashed.status}`);
  const st = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["status"] }));
  check("R8 network attempt_saved", st.network === "attempt_saved" && st.phase === "authorized" && typeof st.capture_id === "string" && st.capture_id.length > 0, JSON.stringify(st));
  const savedId = st.capture_id;
  const rec = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["capture", "4000"] });
  check("R8 recover capture", rec.status === 0 && jsonOf(rec).capture_id === savedId && jsonOf(rec).phase === "captured", JSON.stringify(jsonOf(rec)));
  const effects1 = await control(controlUrl, "GET", "/effects");
  check("R8 one provider effect", effects1.count === effects0.count + 1, `${effects0.count} -> ${effects1.count}`);
}

async function caseCrashBeforeRecord(serviceUrl, controlUrl) {
  const dir = tmpDir("crash-accept-");
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  const effects0 = await control(controlUrl, "GET", "/effects");
  const crashed = runDesk({
    stateDir: dir,
    serviceUrl,
    nowMs: 2000,
    crashAt: "after-accept-before-record",
    args: ["capture", "4000"],
  });
  check("R9 crash SIGKILL", crashed.signal === "SIGKILL" || crashed.status === null, `sig=${crashed.signal}`);
  const st = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["status"] }));
  check("R9 still attempt_saved", st.network === "attempt_saved" && st.phase === "authorized", JSON.stringify(st));
  const rec = runDesk({ stateDir: dir, serviceUrl, nowMs: 3000, args: ["reconcile", st.capture_id] });
  check("R9 reconcile adopts", rec.status === 0 && jsonOf(rec).lookup === "accepted" && jsonOf(rec).phase === "captured", JSON.stringify(jsonOf(rec)));
  const effects1 = await control(controlUrl, "GET", "/effects");
  check("R9 one provider effect", effects1.count === effects0.count + 1, `${effects0.count} -> ${effects1.count}`);
}

async function caseCrashAfterRecord(serviceUrl) {
  const dir = tmpDir("crash-rec-");
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  const crashed = runDesk({
    stateDir: dir,
    serviceUrl,
    nowMs: 2000,
    crashAt: "after-record-before-exit",
    args: ["capture", "4000"],
  });
  check("R10 crash SIGKILL", crashed.signal === "SIGKILL" || crashed.status === null, `sig=${crashed.signal}`);
  const st = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["status"] }));
  check("R10 captured accepted", st.phase === "captured" && st.network === "accepted", JSON.stringify(st));
}

async function caseLostReply(serviceUrl, controlUrl) {
  const dir = tmpDir("drop-");
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  await control(controlUrl, "POST", "/fault", { drop_reply: true });
  const effects0 = await control(controlUrl, "GET", "/effects");
  const cap = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["capture", "4000"] });
  await control(controlUrl, "POST", "/fault", { drop_reply: false });
  check("R11 dropped reply service_unavailable", cap.status !== 0 && jsonOf(cap).error === "service_unavailable", JSON.stringify(jsonOf(cap)));
  const st = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["status"] }));
  check("R11 attempt_saved after drop", st.network === "attempt_saved" && st.phase === "authorized", JSON.stringify(st));
  const rec = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["reconcile", st.capture_id] });
  check("R11 reconcile accepted", rec.status === 0 && jsonOf(rec).lookup === "accepted" && jsonOf(rec).phase === "captured", JSON.stringify(jsonOf(rec)));
  const effects1 = await control(controlUrl, "GET", "/effects");
  check("R11 no second effect", effects1.count === effects0.count + 1, `${effects0.count} -> ${effects1.count}`);
}

async function caseFiveHundred(serviceUrl, controlUrl) {
  const dir = tmpDir("fivexx-");
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  await control(controlUrl, "POST", "/fault", { error_status: 503 });
  const effects0 = await control(controlUrl, "GET", "/effects");
  const cap = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["capture", "4000"] });
  await control(controlUrl, "POST", "/fault", { error_status: 0 });
  check("5xx service_unavailable", cap.status !== 0 && jsonOf(cap).error === "service_unavailable", JSON.stringify(jsonOf(cap)));
  const st = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["status"] }));
  check("5xx leaves attempt_saved", st.network === "attempt_saved" && st.phase === "authorized", JSON.stringify(st));
  const effects1 = await control(controlUrl, "GET", "/effects");
  check("5xx stores no effect", effects1.count === effects0.count);
  const rec = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["capture", "4000"] });
  check("5xx later capture recovers", rec.status === 0 && jsonOf(rec).capture_id === st.capture_id && jsonOf(rec).phase === "captured", JSON.stringify(jsonOf(rec)));
  const effects2 = await control(controlUrl, "GET", "/effects");
  check("5xx retry one effect", effects2.count === effects0.count + 1, `${effects0.count} -> ${effects2.count}`);
}

async function caseReconcileNotSent(serviceUrl, controlUrl) {
  const dir = tmpDir("notsent-");
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  runDesk({
    stateDir: dir,
    serviceUrl,
    nowMs: 2000,
    crashAt: "after-capture-saved-before-request",
    args: ["capture", "4000"],
  });
  const st = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["status"] }));
  const posts0 = await control(controlUrl, "GET", "/posts");
  const rec = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["reconcile", st.capture_id] });
  const posts1 = await control(controlUrl, "GET", "/posts");
  check(
    "R12 not_sent",
    rec.status === 0 && jsonOf(rec).lookup === "not_sent" && jsonOf(rec).network === "attempt_saved" && jsonOf(rec).phase === "authorized",
    JSON.stringify(jsonOf(rec)),
  );
  check("R12 reconcile never POSTs", posts1.count === posts0.count, `${posts0.count} -> ${posts1.count}`);
  const none = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["reconcile", "OTHER-ID"] });
  check("capture_mismatch", none.status !== 0 && jsonOf(none).error === "capture_mismatch");
  const empty = tmpDir("nocap-");
  runDesk({ stateDir: empty, serviceUrl, nowMs: 1, args: ["open", "MERCH-1"] });
  const nc = runDesk({ stateDir: empty, serviceUrl, nowMs: 1, args: ["reconcile", "cap-1"] });
  check("no_capture", nc.status !== 0 && jsonOf(nc).error === "no_capture");
}

async function caseUnrelatedFiles(serviceUrl) {
  const dir = tmpDir("files-");
  const marker = join(dir, "unrelated.bin");
  const bytes = Buffer.from([0, 1, 2, 3, 255, 10, 0]);
  mkdirSync(dir, { recursive: true });
  writeFileSync(marker, bytes);
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  const after = readFileSync(marker);
  check("R13 unrelated bytes survive", Buffer.compare(bytes, after) === 0);
}

async function caseCorrupt(serviceUrl) {
  const dir = tmpDir("corrupt-");
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  const store = join(dir, "desk.sqlite");
  const original = existsSync(store) ? readFileSync(store) : Buffer.from("x");
  writeFileSync(store, "this is not a sqlite store");
  const damaged = readFileSync(store);
  const st = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["status"] });
  check("corrupt_state", st.status !== 0 && jsonOf(st).error === "corrupt_state", JSON.stringify(jsonOf(st)));
  const after = readFileSync(store);
  check("corrupt file not rewritten", Buffer.compare(damaged, after) === 0);
  void original;
}

async function caseIdentifierWins(serviceUrl) {
  const dir = tmpDir("idwin-");
  const r = runDesk({ stateDir: dir, serviceUrl, nowMs: 1, args: ["reconcile", "bad id"] });
  check("identifier parse wins over no_capture", r.status !== 0 && jsonOf(r).error === "bad_args", JSON.stringify(jsonOf(r)));
  const r2 = runDesk({ stateDir: dir, serviceUrl, nowMs: 1, args: ["open", ""] });
  check("empty merchant bad_args", r2.status !== 0 && jsonOf(r2).error === "bad_args");
}

async function caseVoidAndCap(serviceUrl, controlUrl) {
  const dir = tmpDir("void-");
  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  const over = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "50001", "250", "3600000"] });
  check("C3 authorize 50001 daily_cap", over.status !== 0 && jsonOf(over).error === "daily_cap", JSON.stringify(jsonOf(over)));
  const capMax = tmpDir("capmax-");
  runDesk({ stateDir: capMax, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  const ok50 = runDesk({ stateDir: capMax, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "50000", "250", "3600000"] });
  check("C3 authorize 50000", ok50.status === 0 && jsonOf(ok50).authorized_cents === 50000, JSON.stringify(jsonOf(ok50)));

  const nc = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["void"] });
  check("void on open is not_captured", nc.status !== 0 && jsonOf(nc).error === "not_captured");

  runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "40000", "250", "3600000"] });
  const posts0 = await control(controlUrl, "GET", "/posts");
  const cap = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["capture", "4000"] });
  check("C1 capture before void", cap.status === 0 && jsonOf(cap).remaining_hold === 36000 && jsonOf(cap).fee_cents === 100, JSON.stringify(jsonOf(cap)));
  const v = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["void"] });
  check("C1 void exit 0", v.status === 0, `${v.stderr} ${v.stdout}`);
  const vj = jsonOf(v);
  check(
    "C1 void fields",
    vj.phase === "open" && vj.remaining_hold === 0 && vj.capture_deadline_ms === 0 && vj.void_reason === "" && vj.captured_cents === 4000 && vj.network === "none" && vj.merchant_id === "MERCH-1",
    JSON.stringify(vj),
  );
  const posts1 = await control(controlUrl, "GET", "/posts");
  check("C1 void no provider effect", posts1.count === posts0.count + 1, `${posts0.count} -> ${posts1.count}`);

  const st = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["status"] }));
  check(
    "C5 status after void",
    st.status === undefined && st.phase === "open" && st.remaining_hold === 0 && st.capture_deadline_ms === 0 && st.void_reason !== "open_remainder" && st.error !== "corrupt_state",
    JSON.stringify(st),
  );
  const rec = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["reconcile", "cap-x"] });
  check("C5 reconcile after void not corrupt", jsonOf(rec).error !== "corrupt_state", JSON.stringify(jsonOf(rec)));

  const over2 = runDesk({ stateDir: dir, serviceUrl, nowMs: 3000, args: ["authorize", "AUTH-2", "20000", "250", "3600000"] });
  check("C3 after void 20000 daily_cap", over2.status !== 0 && jsonOf(over2).error === "daily_cap", JSON.stringify(jsonOf(over2)));
  const ok10 = runDesk({ stateDir: dir, serviceUrl, nowMs: 3000, args: ["authorize", "AUTH-2", "10000", "250", "3600000"] });
  check("C3 after void 10000", ok10.status === 0 && jsonOf(ok10).authorized_cents === 10000, JSON.stringify(jsonOf(ok10)));

  const effects0 = await control(controlUrl, "GET", "/effects");
  const crashed = runDesk({
    stateDir: dir,
    serviceUrl,
    nowMs: 4000,
    crashAt: "after-capture-saved-before-request",
    args: ["capture", "4000"],
  });
  check("C5 crash after void+auth", crashed.signal === "SIGKILL" || crashed.status === null, `sig=${crashed.signal}`);
  const st2 = jsonOf(runDesk({ stateDir: dir, serviceUrl, nowMs: 4000, args: ["status"] }));
  const savedId = st2.capture_id;
  check("C5 saved id after new auth", st2.network === "attempt_saved" && typeof savedId === "string" && savedId.length > 0, JSON.stringify(st2));
  const rec2 = runDesk({ stateDir: dir, serviceUrl, nowMs: 4000, args: ["capture", "4000"] });
  check("C5 recover same id", rec2.status === 0 && jsonOf(rec2).capture_id === savedId, JSON.stringify(jsonOf(rec2)));
  const effects1 = await control(controlUrl, "GET", "/effects");
  check("C5 one effect for recovered id", effects1.count === effects0.count + 1, `${effects0.count} -> ${effects1.count}`);

  const fullDir = tmpDir("void-full-");
  runDesk({ stateDir: fullDir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runDesk({ stateDir: fullDir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  runDesk({ stateDir: fullDir, serviceUrl, nowMs: 2000, args: ["capture", "10000"] });
  const nv = runDesk({ stateDir: fullDir, serviceUrl, nowMs: 2000, args: ["void"] });
  check("nothing_to_void on full capture", nv.status !== 0 && jsonOf(nv).error === "nothing_to_void", JSON.stringify(jsonOf(nv)));
}

async function caseLegacyDesk(serviceUrl, controlUrl) {
  if (!existsSync(OLD_RUN)) {
    check("OLD_PROJECT_DIR present", false, `missing ${OLD_RUN}`);
    return;
  }
  const dir = tmpDir("legacy-");
  check("old open", runOldDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] }).status === 0);
  const vOpen = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["void"] });
  check("C2 void on old open is legacy_desk", vOpen.status !== 0 && jsonOf(vOpen).error === "legacy_desk", JSON.stringify(jsonOf(vOpen)));
  const auth60 = runDesk({ stateDir: dir, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-O", "60000", "250", "3600000"] });
  check("C4 old desk authorize 60000", auth60.status === 0 && jsonOf(auth60).authorized_cents === 60000 && jsonOf(auth60).phase === "authorized", JSON.stringify(jsonOf(auth60)));
  const cap60 = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["capture", "60000"] });
  check("C4 capture 60000 fee 1500", cap60.status === 0 && jsonOf(cap60).fee_cents === 1500 && jsonOf(cap60).phase === "captured", JSON.stringify(jsonOf(cap60)));
  const vCap = runDesk({ stateDir: dir, serviceUrl, nowMs: 2000, args: ["void"] });
  check("C4 void on old captured is legacy_desk", vCap.status !== 0 && jsonOf(vCap).error === "legacy_desk", JSON.stringify(jsonOf(vCap)));

  const mid = tmpDir("legacy-mid-");
  runOldDesk({ stateDir: mid, serviceUrl, nowMs: 1000, args: ["open", "MERCH-1"] });
  runOldDesk({ stateDir: mid, serviceUrl, nowMs: 1000, args: ["authorize", "AUTH-1", "10000", "250", "3600000"] });
  const exceeds = runDesk({ stateDir: mid, serviceUrl, nowMs: 2000, args: ["capture", "10001"] });
  check("legacy amount_exceeds_auth still", exceeds.status !== 0 && jsonOf(exceeds).error === "amount_exceeds_auth", JSON.stringify(jsonOf(exceeds)));
  const oldCap = runOldDesk({ stateDir: mid, serviceUrl, nowMs: 2000, args: ["capture", "4000"] });
  check("old mid capture", oldCap.status === 0 && jsonOf(oldCap).remaining_hold === 6000 && jsonOf(oldCap).fee_cents === 100, JSON.stringify(jsonOf(oldCap)));
  const before = jsonOf(runDesk({ stateDir: mid, serviceUrl, nowMs: 2000, args: ["status"] }));
  const vMid = runDesk({ stateDir: mid, serviceUrl, nowMs: 2000, args: ["void"] });
  check("C2 void mid-lifecycle legacy_desk", vMid.status !== 0 && jsonOf(vMid).error === "legacy_desk", JSON.stringify(jsonOf(vMid)));
  const after = jsonOf(runDesk({ stateDir: mid, serviceUrl, nowMs: 2000, args: ["status"] }));
  check(
    "C2 no mutation on legacy void",
    after.remaining_hold === before.remaining_hold && after.capture_deadline_ms === before.capture_deadline_ms && after.phase === "captured",
    JSON.stringify(after),
  );
  void controlUrl;
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});

