import { createHash, randomBytes } from "node:crypto";
import { existsSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Kernel,
  classify,
  HistoricalResult,
  StoreNotFoundError,
} from "@ikaros/runtime";

const ROOT = join(fileURLToPath(new URL("..", import.meta.url)));
const MACHINE_V1 = join(ROOT, "machines", "card_desk.ik.toml");
const MACHINE_V2 = join(ROOT, "machines", "card_desk_v2.ik.toml");
const AGGREGATE_ID = "desk";
const STORE_NAME = "desk.sqlite";
const HOLD_MS = 86400000;
const FEE_BPS = 250;
const DAILY_CAP_CENTS = 50000;
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const CANON_INT_RE = /^(0|[1-9][0-9]*)$/;
const MAX_SAFE = 9007199254740991;

function refuse(code) {
  process.stdout.write(JSON.stringify({ error: code }) + "\n");
  process.exit(1);
}

function succeed(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(0);
}

function crashIf(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
    process.exit(137);
  }
}

function isCanonInt(raw) {
  return typeof raw === "string" && CANON_INT_RE.test(raw);
}

function parseNow(raw) {
  if (raw === undefined || raw === "") return { error: "bad_time" };
  if (!isCanonInt(raw)) return { error: "bad_time" };
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0 || n > MAX_SAFE) return { error: "bad_time" };
  return { value: n };
}

function parseCanonInt(raw) {
  if (raw === undefined || raw === "") return { error: "bad_args" };
  if (!isCanonInt(raw)) return { error: "bad_args" };
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0 || n > MAX_SAFE) return { error: "bad_args" };
  return { value: n };
}

function parseId(raw) {
  if (typeof raw !== "string" || !ID_RE.test(raw)) return { error: "bad_args" };
  return { value: raw };
}

function num(v, fallback = null) {
  if (v === undefined || v === null) return fallback;
  if (typeof v === "bigint") {
    const n = Number(v);
    return Number.isSafeInteger(n) ? n : fallback;
  }
  return v;
}

function str(v, fallback = null) {
  if (v === undefined || v === null) return fallback;
  return String(v);
}

function publicPhase(named) {
  if (!named || named === "idle") return "none";
  if (named === "capturing") return "authorized";
  return named;
}

function emptyStatus() {
  return {
    merchant_id: null,
    auth_id: null,
    phase: "none",
    network: "none",
    authorized_cents: null,
    fee_bps: null,
    window_ms: null,
    authorized_ms: null,
    capture_deadline_ms: null,
    captured_cents: 0,
    fee_cents: 0,
    remaining_hold: 0,
    hold_until_ms: null,
    settlement_hold: 0,
    refunded_cents: 0,
    capture_id: null,
    void_reason: null,
  };
}

function project(agg) {
  const st = agg && typeof agg.state === "object" && agg.state ? agg.state : {};
  const named = agg.namedState();
  const phase = publicPhase(named);
  const network = str(st.network, phase === "none" ? "none" : "none");
  return {
    merchant_id: str(st.merchant_id, null),
    auth_id: str(st.auth_id, null),
    phase,
    named,
    network,
    authorized_cents: num(st.authorized_cents, null),
    fee_bps: num(st.fee_bps, null),
    window_ms: num(st.window_ms, null),
    authorized_ms: num(st.authorized_ms, null),
    capture_deadline_ms: num(st.capture_deadline_ms, null),
    captured_cents: num(st.captured_cents, 0),
    fee_cents: num(st.fee_cents, 0),
    remaining_hold: num(st.remaining_hold, 0),
    hold_until_ms: num(st.hold_until_ms, null),
    settlement_hold: num(st.settlement_hold, 0),
    refunded_cents: num(st.refunded_cents, 0),
    capture_id: str(st.capture_id, null) || null,
    capture_amount_cents: num(st.capture_amount_cents, null),
    void_reason: Object.prototype.hasOwnProperty.call(st, "void_reason") ? str(st.void_reason, "") : null,
    day_authorized_cents: num(st.day_authorized_cents, 0),
  };
}

function statusView(p) {
  return {
    merchant_id: p.merchant_id,
    auth_id: p.auth_id,
    phase: p.phase,
    network: p.network,
    authorized_cents: p.authorized_cents,
    fee_bps: p.fee_bps,
    window_ms: p.window_ms,
    authorized_ms: p.authorized_ms,
    capture_deadline_ms: p.capture_deadline_ms,
    captured_cents: p.captured_cents,
    fee_cents: p.fee_cents,
    remaining_hold: p.remaining_hold,
    hold_until_ms: p.hold_until_ms,
    settlement_hold: p.settlement_hold,
    refunded_cents: p.refunded_cents,
    capture_id: p.capture_id,
    void_reason: p.void_reason,
  };
}

function openView(p) {
  return {
    merchant_id: p.merchant_id,
    phase: "open",
    auth_id: null,
    authorized_cents: null,
    fee_bps: null,
    window_ms: null,
    authorized_ms: null,
    capture_deadline_ms: null,
    captured_cents: 0,
    fee_cents: 0,
    remaining_hold: 0,
    hold_until_ms: null,
    settlement_hold: 0,
    refunded_cents: 0,
    capture_id: null,
    void_reason: null,
    network: "none",
  };
}

function authorizeView(p) {
  return {
    auth_id: p.auth_id,
    merchant_id: p.merchant_id,
    phase: "authorized",
    authorized_cents: p.authorized_cents,
    fee_bps: p.fee_bps,
    window_ms: p.window_ms,
    authorized_ms: p.authorized_ms,
    capture_deadline_ms: p.capture_deadline_ms,
    remaining_hold: p.remaining_hold,
    network: "none",
  };
}

function captureView(p) {
  return {
    auth_id: p.auth_id,
    capture_id: p.capture_id,
    phase: "captured",
    captured_cents: p.captured_cents,
    fee_cents: p.fee_cents,
    remaining_hold: p.remaining_hold,
    hold_until_ms: p.hold_until_ms,
    settlement_hold: p.settlement_hold,
    network: "accepted",
  };
}

function storePath(stateDir) {
  return join(stateDir, STORE_NAME);
}

function kernelFor(stateDir) {
  return new Kernel(storePath(stateDir));
}

function mapKernelFailure(err) {
  if (err instanceof StoreNotFoundError) return "not_found";
  try {
    const c = classify(err);
    if (c === "corrupt") return "corrupt_state";
    if (c === "not_found") return "not_found";
    if (c === "uncertain") return "uncertain";
    if (c === "refused") return "refused";
    if (c === "contract_mismatch") return "corrupt_state";
    if (c === "not_sent") return "uncertain";
  } catch {
    /* fall through */
  }
  return "refused";
}

async function routeDesk(kernel, probeMachine, probe) {
  const owner = probe.owner;
  const v1 = await kernel.machine(MACHINE_V1);
  const v2 = await kernel.machine(MACHINE_V2);
  if (v1.identity.equals(owner)) {
    const agg = probeMachine.identity.equals(owner) ? probe : await v1.show(AGGREGATE_ID);
    return { machine: v1, agg, legacy: true };
  }
  if (v2.identity.equals(owner)) {
    const agg = probeMachine.identity.equals(owner) ? probe : await v2.show(AGGREGATE_ID);
    return { machine: v2, agg, legacy: false };
  }
  refuse("corrupt_state");
}

async function showDesk(kernel) {
  try {
    const probeMachine = await kernel.machine(MACHINE_V2);
    const probe = await probeMachine.show(AGGREGATE_ID);
    return await routeDesk(kernel, probeMachine, probe);
  } catch (err) {
    const mapped = mapKernelFailure(err);
    if (mapped === "not_found") return { missing: true };
    if (mapped === "corrupt_state") refuse("corrupt_state");
    try {
      const probeMachine = await kernel.machine(MACHINE_V1);
      const probe = await probeMachine.show(AGGREGATE_ID);
      return await routeDesk(kernel, probeMachine, probe);
    } catch (err2) {
      const mapped2 = mapKernelFailure(err2);
      if (mapped2 === "not_found") return { missing: true };
      refuse("corrupt_state");
    }
  }
}

async function asAggregate(machine, result) {
  if (result instanceof HistoricalResult) {
    return machine.show(AGGREGATE_ID);
  }
  return result;
}

async function dispatch(machine, agg, name, args) {
  const command = args === undefined ? { name } : { name, args };
  const operationId = machine.kernel.newOperationId();
  const capability = agg.capability;
  try {
    const result = await agg.execute(command, { operationId });
    return asAggregate(machine, result);
  } catch (err) {
    const mapped = mapKernelFailure(err);
    if (mapped === "uncertain") {
      const found = await machine.lookupOperation(AGGREGATE_ID, capability, operationId, { command });
      if (found.outcome === "committed_exact") {
        return machine.show(AGGREGATE_ID);
      }
      const wrapped = new Error("uncertain");
      wrapped.domain = mapped;
      wrapped.cause = err;
      throw wrapped;
    }
    if (mapped === "corrupt_state") refuse("corrupt_state");
    err.domain = mapped;
    throw err;
  }
}

function snapshotOf(p, amount) {
  return {
    capture_id: p.capture_id,
    auth_id: p.auth_id,
    merchant_id: p.merchant_id,
    amount_cents: amount,
  };
}

function payloadDigest(snap) {
  return createHash("sha256")
    .update(JSON.stringify({
      auth_id: snap.auth_id,
      merchant_id: snap.merchant_id,
      amount_cents: snap.amount_cents,
    }))
    .digest("hex");
}

function outcomeDigest(body) {
  return createHash("sha256").update(body).digest("hex");
}

function sameCapture(json, snap) {
  return json
    && json.capture_id === snap.capture_id
    && json.auth_id === snap.auth_id
    && json.merchant_id === snap.merchant_id
    && json.amount_cents === snap.amount_cents;
}

function baseUrl() {
  return String(process.env.SERVICE_URL || "").replace(/\/$/, "");
}

async function getCapture(id) {
  try {
    const res = await fetch(`${baseUrl()}/v1/captures/${encodeURIComponent(id)}`);
    const text = await res.text();
    if (res.status === 404) return { kind: "missing" };
    if (res.status >= 500) return { kind: "unavailable" };
    if (res.status !== 200) return { kind: "unavailable" };
    let json;
    try { json = JSON.parse(text); } catch { return { kind: "unavailable" }; }
    return { kind: "ok", json, text };
  } catch {
    return { kind: "unavailable" };
  }
}

async function postCapture(body) {
  try {
    const res = await fetch(`${baseUrl()}/v1/captures`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const text = await res.text();
    if (res.status >= 500) return { kind: "unavailable" };
    if (res.status === 409) return { kind: "conflict" };
    if (res.status !== 200) return { kind: "unavailable" };
    let json;
    try { json = JSON.parse(text); } catch { return { kind: "unavailable" }; }
    return { kind: "ok", json, text };
  } catch {
    return { kind: "unavailable" };
  }
}

function completeArgs(p, nowMs) {
  const captured = p.capture_amount_cents;
  const feeNumerator = captured * FEE_BPS;
  const feeCents = Math.trunc(feeNumerator / 10000);
  const remaining = p.authorized_cents - captured;
  return {
    captured_cents: captured,
    fee_cents: feeCents,
    fee_numerator: feeNumerator,
    remaining_hold: remaining,
    hold_until_ms: nowMs + HOLD_MS,
    now_ms: nowMs,
    void_reason: remaining === 0 ? "" : "open_remainder",
    settlement_hold: 1,
  };
}

async function recordAndComplete(machine, agg, bodyText, nowMs) {
  let current = agg;
  if (current.pendingIntent) {
    const opId = machine.kernel.newOperationId();
    const capability = current.capability;
    const intent = current.pendingIntent;
    try {
      const recorded = await current.recordEffectOutcome(outcomeDigest(bodyText), {
        operationId: opId,
        intent,
      });
      current = await asAggregate(machine, recorded);
    } catch (err) {
      const mapped = mapKernelFailure(err);
      if (mapped === "uncertain") {
        const found = await machine.lookupOperation(AGGREGATE_ID, capability, opId, {
          effect: {
            effect_id: intent.effectId,
            aggregate_id: intent.aggregateId,
            planned_generation: intent.generation,
            payload_digest: intent.payloadDigest,
            idempotency_key: intent.idempotencyKey,
            outcome_digest: outcomeDigest(bodyText),
          },
        });
        if (found.outcome !== "committed_exact") refuse("service_unavailable");
        current = await machine.show(AGGREGATE_ID);
      } else if (mapped === "refused") {
        current = await machine.show(AGGREGATE_ID);
      } else if (mapped === "corrupt_state") {
        refuse("corrupt_state");
      } else {
        refuse("service_unavailable");
      }
    }
  }
  current = await machine.show(AGGREGATE_ID);
  const p = project(current);
  current = await dispatch(machine, current, "complete_capture", completeArgs(p, nowMs));
  return current;
}

async function adoptFromLookup(machine, agg, json, text, snap, nowMs) {
  if (!sameCapture(json, snap)) refuse("lookup_conflict");
  const done = await recordAndComplete(machine, agg, text, nowMs);
  return done;
}

async function cmdOpen(stateDir, merchantId) {
  const id = parseId(merchantId);
  if (id.error) refuse(id.error);
  const kernel = kernelFor(stateDir);
  const path = storePath(stateDir);
  if (existsSync(path)) {
    const loaded = await showDesk(kernel);
    if (loaded.agg) {
      const named = loaded.agg.namedState();
      if (named !== "idle") refuse("already_open");
      const opened = await dispatch(loaded.machine, loaded.agg, "open", { merchant_id: id.value });
      succeed(openView(project(opened)));
    }
  }
  try {
    const machine = await kernel.machine(MACHINE_V2);
    const created = await machine.createWith({
      aggregateId: AGGREGATE_ID,
      command: { name: "open", args: { merchant_id: id.value } },
    });
    const agg = await asAggregate(machine, created);
    succeed(openView(project(agg)));
  } catch (err) {
    const mapped = mapKernelFailure(err);
    if (mapped === "corrupt_state") refuse("corrupt_state");
    if (mapped === "refused") refuse("already_open");
    if (mapped === "uncertain") {
      const machine = await kernel.machine(MACHINE_V2);
      try {
        const agg = await machine.show(AGGREGATE_ID);
        succeed(openView(project(agg)));
      } catch {
        refuse("already_open");
      }
    }
    refuse("already_open");
  }
}

async function cmdAuthorize(stateDir, authId, amountRaw, feeRaw, windowRaw, nowMs) {
  const id = parseId(authId);
  if (id.error) refuse(id.error);
  const amount = parseCanonInt(amountRaw);
  if (amount.error) refuse(amount.error);
  const fee = parseCanonInt(feeRaw);
  if (fee.error) refuse(fee.error);
  const window = parseCanonInt(windowRaw);
  if (window.error) refuse(window.error);
  if (fee.value !== FEE_BPS) refuse("bad_fee_bps");
  if (amount.value < 1) refuse("bad_money");
  const kernel = kernelFor(stateDir);
  const loaded = await showDesk(kernel);
  if (loaded.missing) refuse("bad_status");
  const named = loaded.agg.namedState();
  if (named === "authorized" || named === "capturing" || named === "captured") {
    refuse("already_authorized");
  }
  if (named !== "open") refuse("bad_status");
  const p = project(loaded.agg);
  const daySoFar = p.day_authorized_cents == null ? 0 : p.day_authorized_cents;
  const dayAfter = daySoFar + amount.value;
  if (!loaded.legacy && dayAfter > DAILY_CAP_CENTS) refuse("daily_cap");
  const args = {
    auth_id: id.value,
    amount_cents: amount.value,
    fee_bps: fee.value,
    window_ms: window.value,
    now_ms: nowMs,
    authorized_ms: nowMs,
    capture_deadline_ms: nowMs + window.value,
  };
  if (!loaded.legacy) args.day_authorized_after = dayAfter;
  try {
    const agg = await dispatch(loaded.machine, loaded.agg, "authorize", args);
    succeed(authorizeView(project(agg)));
  } catch (err) {
    if (err.domain === "refused") refuse("bad_status");
    if (err.domain === "uncertain") refuse("bad_status");
    refuse("bad_status");
  }
}

function newCaptureId() {
  return randomBytes(16).toString("hex");
}

async function finishCaptureSuccess(agg) {
  crashIf("after-record-before-exit");
  succeed(captureView(project(agg)));
}

async function cmdCapture(stateDir, amountRaw, nowMs) {
  const amount = parseCanonInt(amountRaw);
  if (amount.error) refuse(amount.error);
  if (amount.value < 1) refuse("bad_money");
  const kernel = kernelFor(stateDir);
  const loaded = await showDesk(kernel);
  if (loaded.missing) refuse("bad_status");
  let agg = loaded.agg;
  let machine = loaded.machine;
  let p = project(agg);
  const named = agg.namedState();

  if (named === "captured" && p.network === "accepted") {
    agg = await dispatch(machine, agg, "ack_capture");
    succeed(captureView(project(agg)));
  }

  if (named === "open" || named === "idle") refuse("bad_status");
  if (named !== "authorized" && named !== "capturing") refuse("bad_status");

  if (named === "capturing" && p.capture_id) {
    await recoverCapture(machine, agg, p, nowMs);
    return;
  }

  if (p.authorized_cents !== null && amount.value > p.authorized_cents) {
    refuse("amount_exceeds_auth");
  }
  if (p.capture_deadline_ms !== null && nowMs > p.capture_deadline_ms) {
    refuse("capture_elapsed");
  }

  const captureId = newCaptureId();
  const snap = {
    capture_id: captureId,
    auth_id: p.auth_id,
    merchant_id: p.merchant_id,
    amount_cents: amount.value,
  };
  try {
    agg = await dispatch(machine, agg, "save_capture", {
      capture_id: captureId,
      amount_cents: amount.value,
      now_ms: nowMs,
      effect_id: captureId,
      payload_digest: payloadDigest(snap),
      idempotency_key: captureId,
    });
  } catch (err) {
    if (p.authorized_cents !== null && amount.value > p.authorized_cents) refuse("amount_exceeds_auth");
    if (p.capture_deadline_ms !== null && nowMs > p.capture_deadline_ms) refuse("capture_elapsed");
    refuse("bad_status");
  }
  crashIf("after-capture-saved-before-request");
  const posted = await postCapture(snap);
  if (posted.kind !== "ok") refuse("service_unavailable");
  if (!sameCapture(posted.json, snap)) refuse("lookup_conflict");
  crashIf("after-accept-before-record");
  const done = await recordAndComplete(machine, agg, posted.text, nowMs);
  await finishCaptureSuccess(done);
}

async function recoverCapture(machine, agg, p, nowMs) {
  const snap = snapshotOf(p, p.capture_amount_cents);
  const looked = await getCapture(p.capture_id);
  if (looked.kind === "ok") {
    const done = await adoptFromLookup(machine, agg, looked.json, looked.text, snap, nowMs);
    await finishCaptureSuccess(done);
  }
  if (looked.kind === "unavailable") refuse("service_unavailable");
  if (looked.kind === "missing") {
    if (p.capture_deadline_ms !== null && nowMs > p.capture_deadline_ms) {
      refuse("capture_elapsed");
    }
    const posted = await postCapture(snap);
    if (posted.kind !== "ok") refuse("service_unavailable");
    if (!sameCapture(posted.json, snap)) refuse("lookup_conflict");
    crashIf("after-accept-before-record");
    const done = await recordAndComplete(machine, agg, posted.text, nowMs);
    await finishCaptureSuccess(done);
  }
  refuse("service_unavailable");
}

async function cmdReleaseHold(stateDir) {
  const kernel = kernelFor(stateDir);
  const loaded = await showDesk(kernel);
  if (loaded.missing) refuse("bad_status");
  const named = loaded.agg.namedState();
  if (named !== "captured") refuse("bad_status");
  const p = project(loaded.agg);
  try {
    const name = p.settlement_hold === 0 ? "ack_release" : "release_hold";
    const agg = await dispatch(loaded.machine, loaded.agg, name);
    const out = project(agg);
    succeed({
      auth_id: out.auth_id,
      phase: "captured",
      settlement_hold: out.settlement_hold,
      hold_until_ms: out.hold_until_ms,
    });
  } catch {
    refuse("bad_status");
  }
}

async function cmdVoid(stateDir) {
  const kernel = kernelFor(stateDir);
  const loaded = await showDesk(kernel);
  if (loaded.missing) refuse("not_captured");
  if (loaded.legacy) refuse("legacy_desk");
  const named = loaded.agg.namedState();
  if (named !== "captured") refuse("not_captured");
  const p = project(loaded.agg);
  if (p.remaining_hold === 0) refuse("nothing_to_void");
  try {
    const agg = await dispatch(loaded.machine, loaded.agg, "void");
    const out = project(agg);
    succeed({
      merchant_id: out.merchant_id,
      phase: "open",
      remaining_hold: 0,
      capture_deadline_ms: 0,
      void_reason: "",
      captured_cents: out.captured_cents,
      refunded_cents: out.refunded_cents,
      network: "none",
    });
  } catch {
    refuse("not_captured");
  }
}

async function cmdRefund(stateDir, amountRaw, nowMs) {
  const amount = parseCanonInt(amountRaw);
  if (amount.error) refuse(amount.error);
  const kernel = kernelFor(stateDir);
  const loaded = await showDesk(kernel);
  if (loaded.missing) refuse("bad_status");
  const named = loaded.agg.namedState();
  if (named !== "captured") refuse("bad_status");
  const p = project(loaded.agg);
  if (p.settlement_hold === 1 || p.hold_until_ms === null || nowMs <= p.hold_until_ms) {
    refuse("hold_active");
  }
  const refundable = p.captured_cents - p.refunded_cents;
  if (amount.value > refundable) refuse("amount_exceeds_refundable");
  try {
    const agg = await dispatch(loaded.machine, loaded.agg, "refund", {
      amount_cents: amount.value,
      now_ms: nowMs,
      refunded_after: p.refunded_cents + amount.value,
    });
    const out = project(agg);
    succeed({
      auth_id: out.auth_id,
      phase: "captured",
      refund_cents: amount.value,
      refunded_cents: out.refunded_cents,
      captured_cents: out.captured_cents,
    });
  } catch {
    refuse("amount_exceeds_refundable");
  }
}

async function cmdReconcile(stateDir, captureIdRaw, nowMs) {
  const id = parseId(captureIdRaw);
  if (id.error) refuse(id.error);
  const kernel = kernelFor(stateDir);
  const loaded = await showDesk(kernel);
  if (loaded.missing) refuse("no_capture");
  const named = loaded.agg.namedState();
  const p = project(loaded.agg);
  if (!p.capture_id) refuse("no_capture");
  if (p.capture_id !== id.value) refuse("capture_mismatch");
  if (named === "captured") {
    succeed({ ...captureView(p), lookup: "local" });
  }
  if (named === "open" && p.remaining_hold === 0) {
    succeed({
      lookup: "local",
      auth_id: p.auth_id,
      capture_id: p.capture_id,
      phase: "open",
      captured_cents: p.captured_cents,
      remaining_hold: 0,
      capture_deadline_ms: p.capture_deadline_ms,
      void_reason: p.void_reason === null ? "" : p.void_reason,
      network: p.network,
    });
  }
  if (named !== "capturing") refuse("no_capture");
  const snap = snapshotOf(p, p.capture_amount_cents);
  const looked = await getCapture(p.capture_id);
  if (looked.kind === "unavailable") refuse("service_unavailable");
  if (looked.kind === "missing") {
    succeed({
      lookup: "not_sent",
      auth_id: p.auth_id,
      capture_id: p.capture_id,
      network: "attempt_saved",
      phase: "authorized",
    });
  }
  if (looked.kind === "ok") {
    const done = await adoptFromLookup(loaded.machine, loaded.agg, looked.json, looked.text, snap, nowMs);
    succeed({ ...captureView(project(done)), lookup: "accepted" });
  }
  refuse("service_unavailable");
}

async function cmdStatus(stateDir) {
  const path = storePath(stateDir);
  if (!existsSync(path)) succeed(emptyStatus());
  const kernel = kernelFor(stateDir);
  const loaded = await showDesk(kernel);
  if (loaded.missing) succeed(emptyStatus());
  succeed(statusView(project(loaded.agg)));
}

async function cmdCallback(stateDir, filePath) {
  if (typeof filePath !== "string" || filePath.length === 0) refuse("bad_args");
  let raw;
  try {
    raw = readFileSync(filePath, "utf8");
  } catch {
    refuse("bad_callback");
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    refuse("bad_callback");
  }
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
    refuse("bad_callback");
  }
  const path = storePath(stateDir);
  if (existsSync(path)) {
    const kernel = kernelFor(stateDir);
    const loaded = await showDesk(kernel);
    if (!loaded.missing) project(loaded.agg);
  }
  succeed({ ok: true });
}

async function main() {
  const now = parseNow(process.env.NOW_MS);
  if (now.error) refuse(now.error);
  const stateDir = process.env.STATE_DIR;
  const serviceUrl = process.env.SERVICE_URL;
  if (!stateDir || !serviceUrl) refuse("bad_args");
  try {
    if (!statSync(stateDir).isDirectory()) refuse("bad_args");
  } catch {
    refuse("bad_args");
  }
  const argv = process.argv.slice(2);
  const command = argv[0];
  if (!command) refuse("bad_args");
  switch (command) {
    case "open":
      if (argv.length !== 2) refuse("bad_args");
      await cmdOpen(stateDir, argv[1]);
      break;
    case "authorize":
      if (argv.length !== 5) refuse("bad_args");
      await cmdAuthorize(stateDir, argv[1], argv[2], argv[3], argv[4], now.value);
      break;
    case "capture":
      if (argv.length !== 2) refuse("bad_args");
      await cmdCapture(stateDir, argv[1], now.value);
      break;
    case "release-hold":
      if (argv.length !== 1) refuse("bad_args");
      await cmdReleaseHold(stateDir);
      break;
    case "void":
      if (argv.length !== 1) refuse("bad_args");
      await cmdVoid(stateDir);
      break;
    case "refund":
      if (argv.length !== 2) refuse("bad_args");
      await cmdRefund(stateDir, argv[1], now.value);
      break;
    case "reconcile":
      if (argv.length !== 2) refuse("bad_args");
      await cmdReconcile(stateDir, argv[1], now.value);
      break;
    case "status":
      if (argv.length !== 1) refuse("bad_args");
      await cmdStatus(stateDir);
      break;
    case "callback":
      if (argv.length !== 2) refuse("bad_args");
      await cmdCallback(stateDir, argv[1]);
      break;
    default:
      refuse("bad_args");
  }
}

main().catch((err) => {
  const mapped = mapKernelFailure(err);
  if (mapped === "corrupt_state") refuse("corrupt_state");
  refuse("bad_args");
});
