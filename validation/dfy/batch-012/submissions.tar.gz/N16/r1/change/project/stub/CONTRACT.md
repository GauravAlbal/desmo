# Card capture service contract

The service URL printed by `server.mjs` is the only URL an application may use. It exposes `POST /v1/captures` and `GET /v1/captures/<capture_id>`.

POST requires JSON with `capture_id`, `auth_id`, `merchant_id`, and positive integer `amount_cents`. The first accepted capture stores one effect and returns HTTP 200 with those fields plus `outcome:"captured"`. Repeating the same capture id with identical fields returns the same result and does not add an effect. Reusing an id with different fields returns 409. Invalid bodies return 400. A configured 5xx stores nothing. The provider may drop a successful reply after storing it or delay a reply.

GET returns the stored 200 object or 404 `{error:"not_found"}`. The application must use its saved capture id for lookup and retry.
