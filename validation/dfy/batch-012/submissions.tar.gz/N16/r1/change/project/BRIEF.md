# Card authorization, capture and refund desk

The program behind `./run` is a durable local desk for one merchant card payment. A merchant is bound, a card authorization holds an amount for a stored window, a capture posts once to an external card network, a settlement hold then blocks refunds until it is cleared and the hold deadline has passed, and a refund may return captured funds that have not already been refunded.

## Scope and invocation

One machine and one process at a time. One merchant desk is bound to a state directory. An unrelated writer may create or modify other files in `STATE_DIR`; those files must survive byte-for-byte. The tool may keep its durable files in `STATE_DIR` under any names. It must use `STATE_DIR`, `SERVICE_URL`, `NOW_MS`, and optional `CRASH_AT`. `SERVICE_URL` is required for every command, including status (status never contacts it). `NOW_MS` is a required non-negative integer epoch-millisecond clock for every command.

`./run <command> [args]` prints exactly one JSON object and nothing else (one trailing newline is allowed). Exit 0 is success. Refusals are nonzero and print `{ "error": "<code>" }`. Identifiers (`merchant_id`, `auth_id`, `capture_id`) are 1–64 characters matching `A-Za-z0-9._-`. Money values (`amount_cents`, `captured_cents`, `refund_cents`, `fee_cents`) are canonical non-negative decimal integers; authorization and capture amounts must be at least 1. Time values (`authorized_ms`, `window_ms`, `capture_deadline_ms`, `hold_until_ms`) are canonical non-negative decimal integers. `CRASH_AT` labels are:

* `after-capture-saved-before-request`: after saving a capture id and capture snapshot, before sending a request;
* `after-accept-before-record`: after reading a complete successful provider response, before saving the captured record;
* `after-record-before-exit`: after saving the captured record, before success JSON is written.

A process must kill itself with SIGKILL at a reached label. Durable commits are flushed before the command treats them as committed. A malformed owned state file is `corrupt_state` and is not rewritten. Refusals do not modify state except that a transmit path named below may durably record a saved capture attempt.

## Clock, environment, and precedence

Missing or non-canonical `NOW_MS` (not a decimal integer in `0` through `9007199254740991`) is `bad_time` and wins every other refusal. Missing `STATE_DIR` or missing `SERVICE_URL` is `bad_args`. An unknown command is `bad_args`. Identifier parse failures are `bad_args` and win status-gated codes on the same invocation. When two domain refusals could apply, the code named first in that command's paragraph wins.

## Commands

`open <merchant_id>` binds the empty-or-idle desk to one merchant and returns `{merchant_id,phase:"open",auth_id:null,authorized_cents:null,fee_bps:null,window_ms:null,authorized_ms:null,capture_deadline_ms:null,captured_cents:0,fee_cents:0,remaining_hold:0,hold_until_ms:null,settlement_hold:0,refunded_cents:0,capture_id:null,void_reason:null,network:"none"}`. A second open is `already_open`. It never contacts the provider.

`authorize <auth_id> <amount_cents> <fee_bps> <window_ms>` is valid only for `open` with no live authorization. It records `authorized_ms` as the current `NOW_MS`, stores `amount_cents`, `fee_bps`, and `window_ms`, and records `capture_deadline_ms` as `authorized_ms + window_ms`. The processing rate stored at authorization in this contract is `250` basis points; any other `fee_bps` is `bad_fee_bps`. `amount_cents` below 1 is `bad_money`. Success returns `{auth_id,merchant_id,phase:"authorized",authorized_cents,fee_bps,window_ms,authorized_ms,capture_deadline_ms,remaining_hold:authorized_cents,network:"none"}`. A second authorize while `authorized`, `capturing`, or `captured` is `already_authorized`. Any other phase is `bad_status`. It never contacts the provider. Worked values: `NOW_MS` 1000, `amount_cents` 10000, `fee_bps` 250, `window_ms` 3600000 records `authorized_ms` 1000 and `capture_deadline_ms` 3601000.

`capture <amount_cents>` captures part or all of the authorization through the card network. It is valid for `authorized` when no capture is accepted yet. `amount_cents` may not exceed `authorized_cents`; otherwise `amount_exceeds_auth`. If `NOW_MS` is greater than `capture_deadline_ms`, the command returns `capture_elapsed` without a provider request. The processing fee is `captured_cents` times the stored `fee_bps`, divided by 10000, rounded down; for the worked capture of 4000 cents at `fee_bps` 250 that fee is 100 cents. `remaining_hold` becomes `authorized_cents` minus the captured amount. Capture also stores `hold_until_ms` as `NOW_MS + 86400000` (one day) and sets `settlement_hold` to 1 (held). Before a saved attempt, it generates a `capture_id` and its exact snapshot (`auth_id`, `merchant_id`, `amount_cents`), then posts once. A matching successful response sets `network:"accepted"` and `phase:"captured"` and returns `{auth_id,capture_id,phase:"captured",captured_cents,fee_cents,remaining_hold,hold_until_ms,settlement_hold:1,network:"accepted"}`. Repeating `capture` after `network:"accepted"` is a success no-op without a provider call. Connection failure, an incomplete response, or HTTP 5xx leaves `network:"attempt_saved"`, keeps `phase:"authorized"`, and returns `service_unavailable`; that invocation does not lookup. Worked remaining hold: authorize 10000 then capture 4000 leaves `remaining_hold` 6000 and `void_reason` `open_remainder`. A full capture of 10000 leaves `remaining_hold` 0 and `void_reason` empty. `open` or `none` is `bad_status`.

If a saved attempt exists, `capture` first `GET /v1/captures/<capture_id>`: a matching 200 is adopted without POST; a 404 causes one POST with the saved id only while the deadline still holds. Never allocate a replacement id. A mismatching success is `lookup_conflict` and changes nothing.

`release-hold` is valid only for `captured` with `settlement_hold` 1. It records `settlement_hold` as 0 (cleared) and returns `{auth_id,phase:"captured",settlement_hold:0,hold_until_ms}`. Repeating after the flag is already 0 is a success no-op. Any other phase is `bad_status`. It never contacts the provider.

`refund <amount_cents>` is valid only while `phase` is `captured`, `settlement_hold` is 0, and `NOW_MS` is greater than `hold_until_ms`. If the flag is still 1, or `NOW_MS` is not past `hold_until_ms`, the command returns `hold_active` and changes nothing. `amount_cents` may not exceed `captured_cents` minus `refunded_cents`; otherwise `amount_exceeds_refundable`. Success adds the amount to `refunded_cents` and returns `{auth_id,phase:"captured",refund_cents,refunded_cents,captured_cents}`. Worked refund: capture 4000, `release-hold`, then `NOW_MS` 86402001 allows a refund of 4000; a refund of 4001 is `amount_exceeds_refundable`; `NOW_MS` 86401999 is `hold_active` even after `release-hold`. It never contacts the provider.

`reconcile <capture_id>` never POSTs or allocates. No saved capture is `no_capture`; another id is `capture_mismatch`. Lookup 200 with matching ids, `auth_id`, `merchant_id`, and amount commits the captured state and returns the capture success object plus `lookup:"accepted"`; 404 returns exit 0 `{lookup:"not_sent",auth_id,capture_id,network:"attempt_saved",phase:"authorized"}`; a mismatch is `lookup_conflict`; transport failure is `service_unavailable`. After a void (this version has no void) reconcile of a captured desk returns the captured object with `lookup:"local"` and does not contact the provider.

`status` never contacts the provider and returns `{merchant_id,auth_id,phase,network,authorized_cents,fee_bps,window_ms,authorized_ms,capture_deadline_ms,captured_cents,fee_cents,remaining_hold,hold_until_ms,settlement_hold,refunded_cents,capture_id,void_reason}`. Empty fields are null, with `phase:"none"`, `network:"none"`, `captured_cents` 0, `fee_cents` 0, `remaining_hold` 0, `settlement_hold` 0, `refunded_cents` 0.

`callback <path>` reads one JSON callback. It must not POST or allocate. A malformed callback is `bad_callback`. A well-formed callback is ignored and returns `{ok:true}`. It must never overwrite authorized, captured, or open state.

Example identifiers used in this contract: `merchant_id` `MERCH-1`; `auth_id` `AUTH-1`; `capture_id` values are application-created. An authorize issued at `NOW_MS` 1000 records `authorized_ms` 1000.

## Provider

The supplied service has `POST /v1/captures` and `GET /v1/captures/<capture_id>`. POST requires JSON with `capture_id`, `auth_id`, `merchant_id`, and `amount_cents` (positive integer). A first valid id records one effect and returns those fields plus `outcome:"captured"`. Repeating the same id with identical fields returns the same object without another effect; any differing field is HTTP 409. Unknown lookup is 404 `{error:"not_found"}`. Invalid bodies are 400. A configured 5xx stores nothing. The provider may drop a successful reply after storing it or delay a reply. Control endpoints are not part of this contract.

## Requirements

R1. Open and every later committed record survive new processes, including a capture attempt killed at `after-capture-saved-before-request`.

R2. `open` validates the merchant id, binds one desk, and does not contact the provider. `authorize` stores the amount, `fee_bps` 250, `window_ms`, `authorized_ms = NOW_MS`, and `capture_deadline_ms = authorized_ms + window_ms`.

R3. A live authorization makes legitimate progress: authorize 10000 at clock 1000 with window 3600000 records deadline 3601000; capture 4000 records `fee_cents` 100 and `remaining_hold` 6000; capture 10001 is `amount_exceeds_auth`; capture at clock 3601001 is `capture_elapsed` without a POST.

R4. After a successful capture, `release-hold` clears `settlement_hold` to 0. `refund` while the flag is 1, or while `NOW_MS` is not greater than `hold_until_ms`, is `hold_active`. After both the flag is cleared and the clock is past `hold_until_ms`, a refund no larger than captured-minus-refunded succeeds. A refund of 4001 after capturing 4000 is `amount_exceeds_refundable`.

R5. A successful `capture` records exactly one provider effect. Repeating `capture` after `network:"accepted"` does not add an effect.

R6. A well-formed `callback` does not overwrite authorized or captured desk state.

R7. Status-gated commands (`authorize` on `none`, `capture` on `open`, `refund` on `authorized`, `release-hold` on `open`) return `bad_status` and do not contact the provider.

R8. A kill at `after-capture-saved-before-request` leaves `network:"attempt_saved"` and the saved `capture_id`. A later `capture` recovers that same id; provider effect count is 1.

R9. A kill at `after-accept-before-record` is recovered by a later `capture` or `reconcile` using the saved id; provider effect count is 1.

R10. A kill at `after-record-before-exit` leaves `phase:"captured"` and `network:"accepted"` for a new process.

R11. A dropped successful reply returns `service_unavailable` with `network:"attempt_saved"`. Later `reconcile` of the saved id returns `lookup:"accepted"` and does not create a second effect.

R12. `reconcile` never POSTs. After a pre-request crash, `reconcile` of the saved id returns `lookup:"not_sent"` with zero POSTs in that invocation.

R13. Unrelated files in `STATE_DIR` survive byte-for-byte.

R14. The program prints one JSON object, requires `NOW_MS` (`bad_time` when missing) and `SERVICE_URL`, and binds at most one merchant (`already_open`). `status` on an empty desk is `{merchant_id:null,auth_id:null,phase:"none",network:"none",authorized_cents:null,fee_bps:null,window_ms:null,authorized_ms:null,capture_deadline_ms:null,captured_cents:0,fee_cents:0,remaining_hold:0,hold_until_ms:null,settlement_hold:0,refunded_cents:0,capture_id:null,void_reason:null}`.
