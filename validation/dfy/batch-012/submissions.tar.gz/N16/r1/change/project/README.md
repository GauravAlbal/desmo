# Card authorization desk

Durable local desk for one merchant card payment. Lifecycle authority lives in
Ikaros (`machines/card_desk.ik.toml`); this process owns CLI parsing, HTTP to
the fake card network, and crash labels.

## Setup

Node 22. From this directory, with npm registry access unavailable:

```bash
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x run
```

The platform tarball is `darwin-arm64`. Set `IK_BINARY` if `ik` is not found
through `@ikaros/darwin-arm64`.

## Run

Start the fake network (prints `{service_url, control_url}`):

```bash
node stub/server.mjs
```

Then:

```bash
export STATE_DIR=/tmp/card-desk
export SERVICE_URL='http://127.0.0.1:<port>'
export NOW_MS=1000
mkdir -p "$STATE_DIR"
./run open MERCH-1
./run authorize AUTH-1 10000 250 3600000
NOW_MS=2000 ./run capture 4000
./run status
```

`SERVICE_URL` and `NOW_MS` are required on every command, including `status`.
Optional `CRASH_AT` is one of `after-capture-saved-before-request`,
`after-accept-before-record`, `after-record-before-exit`.

New desks (v2) cap running `day_authorized_cents` at 50000 and support `./run void`
after a partial capture. Desks opened by the pre-change program stay on v1: no
daily cap, and `void` is `legacy_desk`.

## Test

```bash
node --test tests/desk.test.mjs
```

Ikaros checks (scratch only):

```bash
node_modules/@ikaros/darwin-arm64/bin/ik check machines/card_desk.ik.toml \
  --profile .ik/checks.toml --corpus machines/card_desk.ik.cases.json
node_modules/@ikaros/darwin-arm64/bin/ik scenario run machines/card_desk.ik.toml \
  scenarios/normal.json --out /tmp/card-desk-normal
```
