# Change: partial-capture void and merchant daily cap

R1–R14 remain in force except where this file supersedes the authorize amount rule for new desks. Those original rules continue to apply to desks opened under the original program; they do not apply to merchants opened after this change. `status` still reports `remaining_hold`, `capture_deadline_ms`, and `void_reason`. This change adds a void command and a per-merchant daily cap on new authorizations.

The new command is:

`void`

It is valid only for a `captured` payment whose remaining uncaptured hold is greater than 0 and whose owning machine is the post-change definition. Voiding releases the uncaptured remainder. It records `remaining_hold` as 0, `capture_deadline_ms` as 0, and `void_reason` as empty, returns the desk to `phase:"open"` so another authorization may be filed on the same merchant day, and returns `{merchant_id,phase:"open",remaining_hold:0,capture_deadline_ms:0,void_reason:"",captured_cents,refunded_cents,network:"none"}`. Repeating `void` when `remaining_hold` is already 0 is `nothing_to_void`. A desk opened under the original program is `legacy_desk` even if it is not `captured` (`legacy_desk` wins `nothing_to_void`). A post-change desk that is not `captured` is `not_captured`. The command never contacts the provider. After `void`, `status` and `reconcile` must not be `corrupt_state` and must not still show the pre-void remainder, the old capture deadline, or `open_remainder`.

Worked void: authorize 10000, capture 4000 (`remaining_hold` 6000, `void_reason` `open_remainder`, `capture_deadline_ms` 3601000). Then `void` leaves `remaining_hold` 0, `capture_deadline_ms` 0, and `void_reason` empty.

Authorize is revised only for desks opened under the new definition. A merchant may not newly authorize an amount that would make the desk's running `day_authorized_cents` exceed 50000. The first authorization of 50000 succeeds; 50001 is `daily_cap`. After a void, a further authorization is counted against the same running total: 40000 then, after void, 20000 is `daily_cap`; 10000 after a 40000 void succeeds. An original desk keeps the original authorize rule (no daily cap): 60000 is accepted. Existing persisted desks opened by the pre-change program keep that original rule. A successful capture does not rewrite `day_authorized_cents`.

## Old-instance policy

For every changed or new behavior:

* `void` on a desk opened under the original program is `legacy_desk` and nothing mutates. Observable: `status.remaining_hold` and `status.capture_deadline_ms` stay as they were.
* `authorize` on a desk opened under the original program has no daily cap. Observable: `authorize AUTH-O 60000 250 3600000` on a pre-change `open` desk returns `phase:"authorized"` with `authorized_cents` 60000, and a later `capture 60000` under the changed program still succeeds.
* Capture fee, capture deadline, capture amount, refund hold, and refund amount on a pre-change desk stay the original rules. Observable: capture of 4000 on a pre-change 10000 authorization still records `fee_cents` 100; capture of 10001 is still `amount_exceeds_auth`.
* Saved capture attempts keep the same `capture_id`, snapshot, and R8–R12 recovery rules. `void` does not allocate or POST.

Old instances remain fully usable to completion under the original rules. The changed program must not require a new field, command, or rule of them.

## C1–C5

C1. `void` on a new captured payment with remainder persists `remaining_hold` 0, `capture_deadline_ms` 0, and empty `void_reason`, returns `phase:"open"`, and creates no provider effect.

C2. Void state survives a new process. A desk created by the pre-change program (`OLD_PROJECT_DIR`) refuses `void` with `legacy_desk` without mutation.

C3. On a new desk, `authorize` of 50001 is `daily_cap`. `authorize` of 50000 succeeds. After authorize 40000, capture 4000, and void, `authorize` of 20000 is `daily_cap` and `authorize` of 10000 succeeds.

C4. A desk opened by the pre-change program has no daily cap when the changed program runs against that same store: `authorize` of 60000 succeeds, `status` does not apply `daily_cap` to that authorization, and `capture 60000` succeeds with `fee_cents` 1500. `void` on that desk is `legacy_desk`.

C5. After void on a new desk, a following `status` or `reconcile` is not `corrupt_state` and does not show the old remainder, the old capture deadline, or `open_remainder`. A later capture crash or dropped reply on a new authorization still recovers the same `capture_id` by lookup/retry, and no second provider effect is created for that id.
