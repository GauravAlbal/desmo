import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import {
  existsSync,
  mkdtempSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";

const ROOT = join(fileURLToPath(new URL("..", import.meta.url)));
const RUN = join(ROOT, "run");
const STUB = join(ROOT, "stub", "server.mjs");
const NODE = existsSync("<node-bin>/node")
  ? "<node-bin>/node"
  : process.execPath;

function tempDir() {
  return mkdtempSync(join(tmpdir(), "card-desk-"));
}

function parseJsonLine(text) {
  const line = String(text).trim();
  return JSON.parse(line);
}

function runDesk(env, args) {
  return new Promise((resolve) => {
    const child = spawn(RUN, args, {
      env: { ...process.env, ...env },
      cwd: ROOT,
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => { stdout += d; });
    child.stderr.on("data", (d) => { stderr += d; });
    child.on("close", (status, signal) => {
      resolve({ status, signal, stdout, stderr });
    });
  });
}

async function desk(env, args) {
  const r = await runDesk(env, args);
  assert.equal(r.signal, null, r.stderr);
  const json = parseJsonLine(r.stdout);
  return { ...r, json };
}

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [STUB], { cwd: ROOT });
    let buf = "";
    const onData = (d) => {
      buf += d;
      const nl = buf.indexOf("\n");
      if (nl >= 0) {
        child.stdout.off("data", onData);
        try {
          const urls = JSON.parse(buf.slice(0, nl));
          resolve({ child, ...urls });
        } catch (err) {
          reject(err);
        }
      }
    };
    child.stdout.on("data", onData);
    child.on("error", reject);
  });
}

async function control(url, path, body) {
  const res = await fetch(`${url}${path}`, {
    method: body === undefined ? "GET" : "POST",
    headers: body === undefined ? undefined : { "content-type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return res.json();
}

test("status on empty desk and bad_time wins", async () => {
  const state = tempDir();
  const env = { STATE_DIR: state, SERVICE_URL: "http://127.0.0.1:9", NOW_MS: "1000" };
  const empty = await desk(env, ["status"]);
  assert.equal(empty.status, 0);
  assert.deepEqual(empty.json, {
    merchant_id: null,
    auth_id: null,
    phase: "none",
    network: "none",
    authorized_cents: null,
    fee_bps: null,
    window_ms: null,
    authorized_ms: null,
    capture_deadline_ms: null,
    captured_cents: 0,
    fee_cents: 0,
    remaining_hold: 0,
    hold_until_ms: null,
    settlement_hold: 0,
    refunded_cents: 0,
    capture_id: null,
    void_reason: null,
  });
  const missingTime = await desk({ STATE_DIR: state, SERVICE_URL: "http://127.0.0.1:9" }, ["status"]);
  assert.notEqual(missingTime.status, 0);
  assert.deepEqual(missingTime.json, { error: "bad_time" });
  const badTime = await desk({ ...env, NOW_MS: "01" }, ["open", "MERCH-1"]);
  assert.deepEqual(badTime.json, { error: "bad_time" });
  const unknown = await desk(env, ["nope"]);
  assert.deepEqual(unknown.json, { error: "bad_args" });
});

test("open authorize persist across process restart", async () => {
  const state = tempDir();
  writeFileSync(join(state, "unrelated.txt"), "keep-me");
  const env = { STATE_DIR: state, SERVICE_URL: "http://127.0.0.1:9", NOW_MS: "1000" };
  const opened = await desk(env, ["open", "MERCH-1"]);
  assert.equal(opened.status, 0);
  assert.equal(opened.json.phase, "open");
  assert.equal(opened.json.merchant_id, "MERCH-1");
  assert.equal(opened.json.auth_id, null);
  assert.equal(opened.json.network, "none");
  const again = await desk(env, ["open", "MERCH-2"]);
  assert.deepEqual(again.json, { error: "already_open" });
  const auth = await desk(env, ["authorize", "AUTH-1", "10000", "250", "3600000"]);
  assert.equal(auth.status, 0);
  assert.equal(auth.json.authorized_ms, 1000);
  assert.equal(auth.json.capture_deadline_ms, 3601000);
  assert.equal(auth.json.remaining_hold, 10000);
  assert.equal(auth.json.phase, "authorized");
  const status = await desk(env, ["status"]);
  assert.equal(status.json.phase, "authorized");
  assert.equal(status.json.authorized_cents, 10000);
  assert.equal(status.json.fee_bps, 250);
  assert.equal(readFileSync(join(state, "unrelated.txt"), "utf8"), "keep-me");
});

test("status-gated refusals and authorize money/fee", async () => {
  const state = tempDir();
  const env = { STATE_DIR: state, SERVICE_URL: "http://127.0.0.1:9", NOW_MS: "1000" };
  assert.deepEqual((await desk(env, ["authorize", "AUTH-1", "10000", "250", "3600000"])).json, { error: "bad_status" });
  assert.deepEqual((await desk(env, ["capture", "4000"])).json, { error: "bad_status" });
  assert.deepEqual((await desk(env, ["refund", "1"])).json, { error: "bad_status" });
  assert.deepEqual((await desk(env, ["release-hold"])).json, { error: "bad_status" });
  await desk(env, ["open", "MERCH-1"]);
  assert.deepEqual((await desk(env, ["capture", "4000"])).json, { error: "bad_status" });
  assert.deepEqual((await desk(env, ["release-hold"])).json, { error: "bad_status" });
  assert.deepEqual((await desk(env, ["authorize", "AUTH-1", "10000", "100", "3600000"])).json, { error: "bad_fee_bps" });
  assert.deepEqual((await desk(env, ["authorize", "AUTH-1", "0", "250", "3600000"])).json, { error: "bad_money" });
  await desk(env, ["authorize", "AUTH-1", "10000", "250", "3600000"]);
  assert.deepEqual((await desk(env, ["authorize", "AUTH-2", "10000", "250", "3600000"])).json, { error: "already_authorized" });
  assert.deepEqual((await desk(env, ["refund", "1"])).json, { error: "bad_status" });
});

test("capture hold refund and provider effect count", async () => {
  const stub = await startStub();
  try {
    const state = tempDir();
    writeFileSync(join(state, "other.bin"), Buffer.from([1, 2, 3, 4]));
    const env = {
      STATE_DIR: state,
      SERVICE_URL: stub.service_url,
      NOW_MS: "1000",
    };
    await desk(env, ["open", "MERCH-1"]);
    await desk(env, ["authorize", "AUTH-1", "10000", "250", "3600000"]);
    assert.deepEqual((await desk({ ...env, NOW_MS: "2000" }, ["capture", "10001"])).json, { error: "amount_exceeds_auth" });
    assert.deepEqual((await desk({ ...env, NOW_MS: "3601001" }, ["capture", "4000"])).json, { error: "capture_elapsed" });
    const cap = await desk({ ...env, NOW_MS: "2000" }, ["capture", "4000"]);
    assert.equal(cap.status, 0);
    assert.equal(cap.json.phase, "captured");
    assert.equal(cap.json.captured_cents, 4000);
    assert.equal(cap.json.fee_cents, 100);
    assert.equal(cap.json.remaining_hold, 6000);
    assert.equal(cap.json.settlement_hold, 1);
    assert.equal(cap.json.network, "accepted");
    assert.equal(cap.json.hold_until_ms, 86402000);
    const status = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.equal(status.json.void_reason, "open_remainder");
    const repeat = await desk({ ...env, NOW_MS: "2000" }, ["capture", "4000"]);
    assert.equal(repeat.status, 0);
    assert.equal(repeat.json.capture_id, cap.json.capture_id);
    const effects = await control(stub.control_url, "/effects");
    assert.equal(effects.count, 1);
    assert.deepEqual((await desk({ ...env, NOW_MS: "2000" }, ["refund", "4000"])).json, { error: "hold_active" });
    const released = await desk({ ...env, NOW_MS: "2000" }, ["release-hold"]);
    assert.equal(released.json.settlement_hold, 0);
    const releasedAgain = await desk({ ...env, NOW_MS: "2000" }, ["release-hold"]);
    assert.equal(releasedAgain.status, 0);
    assert.equal(releasedAgain.json.settlement_hold, 0);
    assert.deepEqual((await desk({ ...env, NOW_MS: "86401999" }, ["refund", "4000"])).json, { error: "hold_active" });
    assert.deepEqual((await desk({ ...env, NOW_MS: "86402001" }, ["refund", "4001"])).json, { error: "amount_exceeds_refundable" });
    const refunded = await desk({ ...env, NOW_MS: "86402001" }, ["refund", "4000"]);
    assert.equal(refunded.status, 0);
    assert.equal(refunded.json.refund_cents, 4000);
    assert.equal(refunded.json.refunded_cents, 4000);
    const local = await desk({ ...env, NOW_MS: "86402001" }, ["reconcile", cap.json.capture_id]);
    assert.equal(local.json.lookup, "local");
    assert.equal(local.json.phase, "captured");
    assert.equal(readFileSync(join(state, "other.bin")).equals(Buffer.from([1, 2, 3, 4])), true);
    const cbPath = join(state, "cb.json");
    writeFileSync(cbPath, JSON.stringify({ event: "ignored" }));
    const cb = await desk(env, ["callback", cbPath]);
    assert.deepEqual(cb.json, { ok: true });
    const afterCb = await desk(env, ["status"]);
    assert.equal(afterCb.json.phase, "captured");
    assert.equal(afterCb.json.captured_cents, 4000);
    assert.deepEqual((await desk(env, ["callback", join(state, "missing.json")])).json, { error: "bad_callback" });
  } finally {
    stub.child.kill("SIGTERM");
  }
});

test("crash after save before request recovers same id", async () => {
  const stub = await startStub();
  try {
    const state = tempDir();
    const env = { STATE_DIR: state, SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    await desk(env, ["open", "MERCH-1"]);
    await desk(env, ["authorize", "AUTH-1", "10000", "250", "3600000"]);
    const crashed = await runDesk({ ...env, NOW_MS: "2000", CRASH_AT: "after-capture-saved-before-request" }, ["capture", "4000"]);
    assert.equal(crashed.signal, "SIGKILL");
    const status = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.equal(status.json.network, "attempt_saved");
    assert.equal(typeof status.json.capture_id, "string");
    assert.ok(status.json.capture_id.length >= 1);
    assert.equal(status.json.phase, "authorized");
    const before = await control(stub.control_url, "/effects");
    assert.equal(before.count, 0);
    const recovered = await desk({ ...env, NOW_MS: "2000" }, ["capture", "4000"]);
    assert.equal(recovered.status, 0);
    assert.equal(recovered.json.capture_id, status.json.capture_id);
    assert.equal(recovered.json.network, "accepted");
    const after = await control(stub.control_url, "/effects");
    assert.equal(after.count, 1);
    const posts = await control(stub.control_url, "/posts");
    assert.equal(posts.count, 1);
  } finally {
    stub.child.kill("SIGTERM");
  }
});

test("crash after accept before record recovers with one effect", async () => {
  const stub = await startStub();
  try {
    const state = tempDir();
    const env = { STATE_DIR: state, SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    await desk(env, ["open", "MERCH-1"]);
    await desk(env, ["authorize", "AUTH-1", "10000", "250", "3600000"]);
    const crashed = await runDesk({ ...env, NOW_MS: "2000", CRASH_AT: "after-accept-before-record" }, ["capture", "4000"]);
    assert.equal(crashed.signal, "SIGKILL");
    const status = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.equal(status.json.network, "attempt_saved");
    const effects = await control(stub.control_url, "/effects");
    assert.equal(effects.count, 1);
    const recovered = await desk({ ...env, NOW_MS: "2000" }, ["capture", "4000"]);
    assert.equal(recovered.status, 0);
    assert.equal(recovered.json.phase, "captured");
    assert.equal(recovered.json.capture_id, status.json.capture_id);
    const after = await control(stub.control_url, "/effects");
    assert.equal(after.count, 1);
  } finally {
    stub.child.kill("SIGTERM");
  }
});

test("crash after record before exit leaves captured", async () => {
  const stub = await startStub();
  try {
    const state = tempDir();
    const env = { STATE_DIR: state, SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    await desk(env, ["open", "MERCH-1"]);
    await desk(env, ["authorize", "AUTH-1", "10000", "250", "3600000"]);
    const crashed = await runDesk({ ...env, NOW_MS: "2000", CRASH_AT: "after-record-before-exit" }, ["capture", "4000"]);
    assert.equal(crashed.signal, "SIGKILL");
    const status = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.equal(status.json.phase, "captured");
    assert.equal(status.json.network, "accepted");
    assert.equal(status.json.captured_cents, 4000);
  } finally {
    stub.child.kill("SIGTERM");
  }
});

test("dropped reply then reconcile accepted without second effect", async () => {
  const stub = await startStub();
  try {
    const state = tempDir();
    const env = { STATE_DIR: state, SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    await desk(env, ["open", "MERCH-1"]);
    await desk(env, ["authorize", "AUTH-1", "10000", "250", "3600000"]);
    await control(stub.control_url, "/fault", { drop_reply: true });
    const dropped = await desk({ ...env, NOW_MS: "2000" }, ["capture", "4000"]);
    assert.deepEqual(dropped.json, { error: "service_unavailable" });
    const status = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.equal(status.json.network, "attempt_saved");
    const effects = await control(stub.control_url, "/effects");
    assert.equal(effects.count, 1);
    await control(stub.control_url, "/fault", { drop_reply: false });
    const rec = await desk({ ...env, NOW_MS: "2000" }, ["reconcile", status.json.capture_id]);
    assert.equal(rec.status, 0);
    assert.equal(rec.json.lookup, "accepted");
    assert.equal(rec.json.phase, "captured");
    assert.equal(rec.json.network, "accepted");
    const after = await control(stub.control_url, "/effects");
    assert.equal(after.count, 1);
  } finally {
    stub.child.kill("SIGTERM");
  }
});

test("reconcile after pre-request crash is not_sent with zero posts", async () => {
  const stub = await startStub();
  try {
    const state = tempDir();
    const env = { STATE_DIR: state, SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    await desk(env, ["open", "MERCH-1"]);
    await desk(env, ["authorize", "AUTH-1", "10000", "250", "3600000"]);
    const crashed = await runDesk({ ...env, NOW_MS: "2000", CRASH_AT: "after-capture-saved-before-request" }, ["capture", "4000"]);
    assert.equal(crashed.signal, "SIGKILL");
    const status = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    const rec = await desk({ ...env, NOW_MS: "2000" }, ["reconcile", status.json.capture_id]);
    assert.equal(rec.status, 0);
    assert.equal(rec.json.lookup, "not_sent");
    assert.equal(rec.json.network, "attempt_saved");
    assert.equal(rec.json.phase, "authorized");
    const posts = await control(stub.control_url, "/posts");
    assert.equal(posts.count, 0);
    assert.deepEqual((await desk({ ...env, NOW_MS: "2000" }, ["reconcile", "OTHER-ID"])).json, { error: "capture_mismatch" });
    const none = tempDir();
    assert.deepEqual((await desk({ ...env, STATE_DIR: none }, ["reconcile", "CAP-1"])).json, { error: "no_capture" });
  } finally {
    stub.child.kill("SIGTERM");
  }
});

test("full capture remaining hold zero and 5xx does not lookup", async () => {
  const stub = await startStub();
  try {
    const state = tempDir();
    const env = { STATE_DIR: state, SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    await desk(env, ["open", "MERCH-1"]);
    await desk(env, ["authorize", "AUTH-1", "10000", "250", "3600000"]);
    await control(stub.control_url, "/fault", { error_status: 503 });
    const fail = await desk({ ...env, NOW_MS: "2000" }, ["capture", "10000"]);
    assert.deepEqual(fail.json, { error: "service_unavailable" });
    const status = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.equal(status.json.network, "attempt_saved");
    const posts = await control(stub.control_url, "/posts");
    assert.equal(posts.count, 1);
    await control(stub.control_url, "/fault", { error_status: 0 });
    const recovered = await desk({ ...env, NOW_MS: "2000" }, ["capture", "10000"]);
    assert.equal(recovered.json.remaining_hold, 0);
    assert.equal(recovered.json.fee_cents, 250);
    const after = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.equal(after.json.void_reason, "");
    const effects = await control(stub.control_url, "/effects");
    assert.equal(effects.count, 1);
  } finally {
    stub.child.kill("SIGTERM");
  }
});

test("corrupt owned state is not rewritten", async () => {
  const state = tempDir();
  const store = join(state, "desk.sqlite");
  writeFileSync(store, "not-a-sqlite-file");
  const env = { STATE_DIR: state, SERVICE_URL: "http://127.0.0.1:9", NOW_MS: "1000" };
  const r = await desk(env, ["status"]);
  assert.deepEqual(r.json, { error: "corrupt_state" });
  assert.equal(readFileSync(store, "utf8"), "not-a-sqlite-file");
});

const OLD_RUN = "/tmp/n16-r1-prechange-desk/run";

function runOldDesk(env, args) {
  return new Promise((resolve) => {
    const child = spawn(OLD_RUN, args, {
      env: { ...process.env, ...env },
      cwd: "/tmp/n16-r1-prechange-desk",
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => { stdout += d; });
    child.stderr.on("data", (d) => { stderr += d; });
    child.on("close", (status, signal) => {
      resolve({ status, signal, stdout, stderr });
    });
  });
}

async function oldDesk(env, args) {
  const r = await runOldDesk(env, args);
  assert.equal(r.signal, null, r.stderr);
  return { ...r, json: parseJsonLine(r.stdout) };
}

test("void on new partial capture and daily cap", async () => {
  const stub = await startStub();
  try {
    const state = tempDir();
    const env = { STATE_DIR: state, SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    assert.deepEqual((await desk(env, ["void"])).json, { error: "not_captured" });
    await desk(env, ["open", "MERCH-1"]);
    assert.deepEqual((await desk(env, ["void"])).json, { error: "not_captured" });
    assert.deepEqual((await desk(env, ["authorize", "AUTH-1", "50001", "250", "3600000"])).json, { error: "daily_cap" });
    const capOk = await desk(env, ["authorize", "AUTH-C", "50000", "250", "3600000"]);
    assert.equal(capOk.status, 0);
    assert.equal(capOk.json.authorized_cents, 50000);
    await desk({ ...env, NOW_MS: "2000" }, ["capture", "50000"]);
    assert.deepEqual((await desk({ ...env, NOW_MS: "2000" }, ["void"])).json, { error: "nothing_to_void" });
  } finally {
    stub.child.kill("SIGTERM");
  }
});

test("void remainder then further authorize against running day total", async () => {
  const stub = await startStub();
  try {
    const state = tempDir();
    const env = { STATE_DIR: state, SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    await desk(env, ["open", "MERCH-1"]);
    await desk(env, ["authorize", "AUTH-1", "40000", "250", "3600000"]);
    const cap = await desk({ ...env, NOW_MS: "2000" }, ["capture", "4000"]);
    assert.equal(cap.json.remaining_hold, 36000);
    const statusBefore = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.equal(statusBefore.json.void_reason, "open_remainder");
    assert.equal(statusBefore.json.capture_deadline_ms, 3601000);
    const voided = await desk({ ...env, NOW_MS: "2000" }, ["void"]);
    assert.equal(voided.status, 0);
    assert.equal(voided.json.phase, "open");
    assert.equal(voided.json.remaining_hold, 0);
    assert.equal(voided.json.capture_deadline_ms, 0);
    assert.equal(voided.json.void_reason, "");
    assert.equal(voided.json.captured_cents, 4000);
    assert.equal(voided.json.network, "none");
    const after = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.equal(after.json.phase, "open");
    assert.equal(after.json.remaining_hold, 0);
    assert.equal(after.json.capture_deadline_ms, 0);
    assert.equal(after.json.void_reason, "");
    assert.notEqual(after.json.void_reason, "open_remainder");
    const rec = await desk({ ...env, NOW_MS: "2000" }, ["reconcile", cap.json.capture_id]);
    assert.notEqual(rec.json.error, "corrupt_state");
    assert.notEqual(rec.json.remaining_hold, 36000);
    assert.notEqual(rec.json.void_reason, "open_remainder");
    assert.deepEqual((await desk({ ...env, NOW_MS: "2000" }, ["void"])).json, { error: "not_captured" });
    assert.deepEqual((await desk(env, ["authorize", "AUTH-2", "20000", "250", "3600000"])).json, { error: "daily_cap" });
    const next = await desk(env, ["authorize", "AUTH-2", "10000", "250", "3600000"]);
    assert.equal(next.status, 0);
    assert.equal(next.json.authorized_cents, 10000);
    const crashed = await runDesk({ ...env, NOW_MS: "2000", CRASH_AT: "after-capture-saved-before-request" }, ["capture", "4000"]);
    assert.equal(crashed.signal, "SIGKILL");
    const saved = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    const recovered = await desk({ ...env, NOW_MS: "2000" }, ["capture", "4000"]);
    assert.equal(recovered.status, 0);
    assert.equal(recovered.json.capture_id, saved.json.capture_id);
    const effects = await control(stub.control_url, "/effects");
    assert.equal(effects.count, 2);
  } finally {
    stub.child.kill("SIGTERM");
  }
});

test("prechange desk has no daily cap and refuses void as legacy_desk", async () => {
  const stub = await startStub();
  try {
    const state = tempDir();
    const env = { STATE_DIR: state, SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    const opened = await oldDesk(env, ["open", "MERCH-1"]);
    assert.equal(opened.status, 0);
    assert.deepEqual((await desk(env, ["void"])).json, { error: "legacy_desk" });
    const before = await desk(env, ["status"]);
    const auth = await desk(env, ["authorize", "AUTH-O", "60000", "250", "3600000"]);
    assert.equal(auth.status, 0);
    assert.equal(auth.json.authorized_cents, 60000);
    assert.equal(auth.json.phase, "authorized");
    const afterAuth = await desk(env, ["status"]);
    assert.equal(afterAuth.json.authorized_cents, 60000);
    assert.notEqual(afterAuth.json.error, "daily_cap");
    const cap = await desk({ ...env, NOW_MS: "2000" }, ["capture", "60000"]);
    assert.equal(cap.status, 0);
    assert.equal(cap.json.fee_cents, 1500);
    const hold = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.deepEqual((await desk({ ...env, NOW_MS: "2000" }, ["void"])).json, { error: "legacy_desk" });
    const afterVoid = await desk({ ...env, NOW_MS: "2000" }, ["status"]);
    assert.equal(afterVoid.json.remaining_hold, hold.json.remaining_hold);
    assert.equal(afterVoid.json.capture_deadline_ms, hold.json.capture_deadline_ms);
    assert.equal(before.json.phase, "open");
  } finally {
    stub.child.kill("SIGTERM");
  }
});
