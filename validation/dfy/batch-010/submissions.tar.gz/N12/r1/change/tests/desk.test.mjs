import { spawn, spawnSync } from "node:child_process";
import { createWriteStream, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createServer } from "node:net";

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const NODE = process.env.NODE_BIN || "<home>/.nvm/versions/node/v22.17.1/bin/node";
const RUN = join(ROOT, "run");

function waitPort(proc) {
  return new Promise((resolve, reject) => {
    let buf = "";
    const on = (c) => {
      buf += c;
      const nl = buf.indexOf("\n");
      if (nl >= 0) {
        proc.stdout.off("data", on);
        try {
          resolve(JSON.parse(buf.slice(0, nl)));
        } catch (e) {
          reject(e);
        }
      }
    };
    proc.stdout.on("data", on);
    proc.on("error", reject);
  });
}

function run(env, args) {
  const r = spawnSync(RUN, args, { env: { ...process.env, ...env }, encoding: "utf8" });
  let json;
  try {
    json = JSON.parse((r.stdout || "").trim().split("\n").filter(Boolean).pop());
  } catch {
    json = { parse_error: r.stdout, stderr: r.stderr };
  }
  return { status: r.status, signal: r.signal, json, stdout: r.stdout };
}

function assert(cond, msg) {
  if (!cond) throw new Error(msg);
}

async function main() {
  const stub = spawn(NODE, [join(ROOT, "stub", "server.mjs")], { stdio: ["ignore", "pipe", "inherit"] });
  const urls = await waitPort(stub);
  const SERVICE_URL = urls.service_url;
  const CONTROL = urls.control_url;
  let failed = 0;
  const cases = [];

  async function fault(body) {
    await fetch(`${CONTROL}/fault`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
  }
  async function effects() {
    return (await fetch(`${CONTROL}/effects`)).json();
  }

  function fresh() {
    const STATE_DIR = mkdtempSync(join(tmpdir(), "desk-"));
    return { STATE_DIR, SERVICE_URL, NOW_MS: "1000" };
  }

  try {
    {
      const env = fresh();
      const s = run(env, ["status"]);
      assert(s.status === 0 && s.json.status === "none" && s.json.desk_id === null, "empty status");
      cases.push("empty status");
    }
    {
      const env = fresh();
      writeFileSync(join(env.STATE_DIR, "keep.bin"), Buffer.from([1, 2, 3, 4]));
      const o = run(env, ["open", "desk1"]);
      assert(o.status === 0 && o.json.status === "open", "open");
      const o2 = run(env, ["open", "desk1"]);
      assert(o2.status !== 0 && o2.json.error === "already_open", "already_open");
      const p = run(env, ["post-shift", "s1", "1000", "2000", "2"]);
      assert(p.status === 0 && p.json.filled === 0, "post");
      const missing = { ...env };
      delete missing.NOW_MS;
      const bad = run(missing, ["status"]);
      assert(bad.status !== 0, "missing NOW_MS");
      const keep = readFileSync(join(env.STATE_DIR, "keep.bin"));
      assert(Buffer.compare(keep, Buffer.from([1, 2, 3, 4])) === 0, "unrelated bytes");
      cases.push("open/post/unrelated");
    }
    {
      const env = fresh();
      run(env, ["open", "d"]);
      run(env, ["post-shift", "s1", "0", "100", "1"]);
      run(env, ["post-shift", "s2", "50", "150", "1"]);
      const a = run(env, ["assign", "s1", "v1"]);
      assert(a.status === 0 && a.json.notice === "sent", "assign");
      const ov = run(env, ["assign", "s2", "v1"]);
      assert(ov.json.error === "overlap", "overlap");
      const nop = run(env, ["assign", "s1", "v1"]);
      assert(nop.status === 0 && nop.json.notice === "sent", "noop");
      const e0 = await effects();
      const n1 = e0.count;
      run(env, ["assign", "s1", "v1"]);
      const e1 = await effects();
      assert(e1.count === n1, "noop no extra effect");
      cases.push("assign overlap noop");
    }
    {
      const env = fresh();
      run(env, ["open", "d"]);
      run(env, ["post-shift", "s1", "0", "100", "2"]);
      const cr = run({ ...env, CRASH_AT: "after-notice-saved-before-request" }, ["assign", "s1", "v1"]);
      assert(cr.status !== 0 || cr.signal === "SIGKILL", "crash1 signal");
      const st = run(env, ["status"]);
      assert(st.json.notice === "attempt_saved" && st.json.assignments === 0, "crash1 state");
      const before = (await effects()).count;
      const rec = run(env, ["assign", "s1", "v1"]);
      assert(rec.status === 0 && rec.json.notice === "sent", "crash1 recover");
      const after = (await effects()).count;
      assert(after === before + 1, "crash1 one effect");
      cases.push("crash after-notice-saved-before-request");
    }
    {
      const env = fresh();
      run(env, ["open", "d"]);
      run(env, ["post-shift", "s1", "0", "100", "1"]);
      const cr = run({ ...env, CRASH_AT: "after-accept-before-record" }, ["assign", "s1", "v1"]);
      assert(cr.status !== 0 || cr.signal === "SIGKILL", "crash2");
      const st = run(env, ["status"]);
      assert(st.json.notice === "attempt_saved" && st.json.assignments === 0, "crash2 state");
      const before = (await effects()).count;
      const rec = run(env, ["assign", "s1", "v1"]);
      assert(rec.status === 0 && rec.json.notice === "sent", "crash2 recover");
      const after = (await effects()).count;
      assert(after === before, "crash2 lookup no second effect");
      cases.push("crash after-accept-before-record");
    }
    {
      const env = fresh();
      run(env, ["open", "d"]);
      run(env, ["post-shift", "s1", "0", "100", "1"]);
      const cr = run({ ...env, CRASH_AT: "after-record-before-exit" }, ["assign", "s1", "v1"]);
      assert(cr.status !== 0 || cr.signal === "SIGKILL", "crash3");
      const st = run(env, ["status"]);
      assert(st.json.notice === "sent" && st.json.assignments === 1, "crash3 sent");
      const before = (await effects()).count;
      const rec = run(env, ["assign", "s1", "v1"]);
      assert(rec.status === 0, "crash3 noop");
      const after = (await effects()).count;
      assert(after === before, "crash3 no extra");
      cases.push("crash after-record-before-exit");
    }
    {
      await fault({ drop_reply: true });
      const env = fresh();
      run(env, ["open", "d"]);
      run(env, ["post-shift", "s1", "0", "100", "1"]);
      const d = run(env, ["assign", "s1", "vz"]);
      assert(d.json.error === "service_unavailable", "drop");
      const st = run(env, ["status"]);
      assert(st.json.notice === "attempt_saved", "drop saved");
      await fault({});
      const rec = run(env, ["reconcile", st.json.notice_id]);
      assert(rec.status === 0 && rec.json.lookup === "sent" && rec.json.notice === "sent", "reconcile sent");
      cases.push("lost-reply reconcile");
    }
    {
      const env = fresh();
      run(env, ["open", "d"]);
      run(env, ["post-shift", "a", "0", "100", "1"]);
      run(env, ["post-shift", "b", "200", "300", "1"]);
      run(env, ["assign", "a", "r1"]);
      run(env, ["assign", "b", "c1"]);
      const off = run(env, ["offer-swap", "sw", "a", "b", "r1", "c1", "5000"]);
      assert(off.status === 0 && off.json.status === "pending" && off.json.era === 2, "offer");
      const dec = run(env, ["respond-swap", "sw", "decline"]);
      assert(dec.json.status === "declined", "decline");
      const off2 = run(env, ["offer-swap", "sw2", "a", "b", "r1", "c1", "1500"]);
      const exp = run({ ...env, NOW_MS: "2000" }, ["respond-swap", "sw2", "accept"]);
      assert(exp.json.error === "swap_expired", "expired");
      const st = run({ ...env, NOW_MS: "2000" }, ["status"]);
      assert(st.json.swap && st.json.swap.status === "expired", "expired durable");
      cases.push("swap decline/expire");
    }
    {
      const env = fresh();
      run(env, ["open", "d"]);
      const c = run(env, ["cancel-shift", "nope"]);
      assert(c.json.error === "unknown_shift", "unknown cancel");
      cases.push("unknown shift");
    }
    {
      const env = fresh();
      run(env, ["open", "d"]);
      run(env, ["post-shift", "a", "0", "100", "1"]);
      run(env, ["post-shift", "b", "200", "300", "1"]);
      run(env, ["post-shift", "c", "400", "500", "1"]);
      run(env, ["assign", "a", "r1"]);
      run(env, ["assign", "b", "c1"]);
      run(env, ["assign", "c", "buddy"]);
      const beforeConfirm = run(env, ["confirm-swap", "sw", "buddy"]);
      assert(beforeConfirm.json.error === "swap_mismatch", "confirm missing swap");
      run(env, ["offer-swap", "sw", "a", "b", "r1", "c1", "5000"]);
      const tooSoon = run(env, ["confirm-swap", "sw", "buddy"]);
      assert(tooSoon.json.error === "not_accepted", "confirm before accept");
      const hold = run(env, ["assign", "c", "r1"]);
      assert(hold.json.error === "swap_hold", "era2 pending hold");
      const acc = run(env, ["respond-swap", "sw", "accept"]);
      assert(acc.status === 0 && acc.json.status === "accepted" && acc.json.era === 2, "era2 accept only");
      const stAcc = run(env, ["status"]);
      assert(stAcc.json.assignments === 3 && stAcc.json.buddy_id === null, "no exchange yet");
      const hold2 = run(env, ["assign", "c", "c1"]);
      assert(hold2.json.error === "swap_hold", "era2 accepted hold");
      const nb = run(env, ["respond-swap", "sw", "accept"]);
      assert(nb.json.error === "needs_buddy", "needs_buddy");
      const before = (await effects()).count;
      const conf = run(env, ["confirm-swap", "sw", "buddy"]);
      assert(conf.status === 0 && conf.json.notice === "sent" && conf.json.buddy_id === "buddy", "confirm");
      const after = (await effects()).count;
      assert(after === before + 1, "one swap sms");
      const st = run(env, ["status"]);
      assert(st.json.buddy_id === "buddy", "buddy persisted");
      const asg = st.json.assignments;
      assert(asg === 3, "still three placements");
      const rep = run(env, ["confirm-swap", "sw", "buddy"]);
      assert(rep.status === 0 && rep.json.notice === "sent", "confirm noop");
      const after2 = (await effects()).count;
      assert(after2 === after, "no second sms");
      const mis = run(env, ["confirm-swap", "sw", "c1"]);
      assert(mis.json.error === "buddy_mismatch" || mis.json.error === "not_assigned", "buddy mismatch");
      cases.push("era2 confirm/hold");
    }
    {
      const env = fresh();
      run(env, ["open", "d"]);
      run(env, ["post-shift", "a", "0", "100", "1"]);
      run(env, ["post-shift", "b", "200", "300", "1"]);
      run(env, ["post-shift", "c", "400", "500", "1"]);
      run(env, ["post-shift", "d", "600", "700", "1"]);
      run(env, ["assign", "a", "r1"]);
      run(env, ["assign", "b", "c1"]);
      run(env, ["assign", "c", "buddy"]);
      const { Kernel } = await import("@ikaros/runtime");
      const k = new Kernel(join(env.STATE_DIR, "roster.sqlite"));
      const machine = await k.machine(join(ROOT, "machines", "desk.ik.toml"));
      const agg = await machine.show("desk");
      const facts = agg.state && agg.state.facts ? agg.state.facts : agg.state;
      const era1 = {
        swap_id: "legacy",
        status: "pending",
        offered_shift: "a",
        wanted_shift: "b",
        requester_id: "r1",
        counterpart_id: "c1",
        deadline_ms: 5000,
        era: 1,
      };
      await agg.command("offer_swap", { swap_json: JSON.stringify(era1) });
      const leg = run(env, ["confirm-swap", "legacy", "buddy"]);
      assert(leg.json.error === "legacy_swap", "legacy confirm");
      const other = run(env, ["assign", "d", "c1"]);
      assert(other.status === 0 && other.json.notice === "sent", "era1 no hold");
      const before = (await effects()).count;
      const acc = run(env, ["respond-swap", "legacy", "accept"]);
      assert(acc.status === 0 && acc.json.notice === "sent", "era1 accept completes");
      const after = (await effects()).count;
      assert(after === before + 1, "era1 one sms");
      cases.push("era1 continuity");
    }
    {
      const env = fresh();
      run(env, ["open", "d"]);
      run(env, ["post-shift", "a", "0", "100", "1"]);
      run(env, ["post-shift", "b", "200", "300", "1"]);
      run(env, ["post-shift", "c", "400", "500", "1"]);
      run(env, ["assign", "a", "r1"]);
      run(env, ["assign", "b", "c1"]);
      run(env, ["assign", "c", "buddy"]);
      run(env, ["offer-swap", "sw", "a", "b", "r1", "c1", "5000"]);
      run(env, ["respond-swap", "sw", "accept"]);
      const cr = run({ ...env, CRASH_AT: "after-notice-saved-before-request" }, ["confirm-swap", "sw", "buddy"]);
      assert(cr.status !== 0 || cr.signal === "SIGKILL", "confirm crash");
      const st = run(env, ["status"]);
      assert(st.json.notice === "attempt_saved", "confirm attempt saved");
      const before = (await effects()).count;
      const rec = run(env, ["confirm-swap", "sw", "buddy"]);
      assert(rec.status === 0 && rec.json.notice === "sent", "confirm recover");
      const after = (await effects()).count;
      assert(after === before + 1, "confirm one effect");
      cases.push("confirm crash recover");
    }
    console.log(JSON.stringify({ ok: true, cases }));
  } catch (e) {
    console.error(e);
    failed = 1;
  } finally {
    stub.kill("SIGKILL");
  }
  process.exit(failed);
}

main();
