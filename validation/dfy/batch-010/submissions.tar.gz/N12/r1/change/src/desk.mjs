import { createHash, randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, statSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { Kernel, StoreNotFoundError, classify } from "@ikaros/runtime";

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = dirname(HERE);
const MACHINE = join(ROOT, "machines", "desk.ik.toml");
const AGG = "desk";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;

class AppError extends Error {
  constructor(code, exit = 1) {
    super(code);
    this.code = code;
    this.exit = exit;
  }
}

function fail(code) {
  throw new AppError(code);
}

function env(name) {
  const v = process.env[name];
  return v === undefined ? undefined : v;
}

function requireEnv() {
  if (env("SERVICE_URL") === undefined || env("NOW_MS") === undefined || env("STATE_DIR") === undefined) {
    fail("bad_args");
  }
  const nowRaw = env("NOW_MS");
  if (!isCanonInt(nowRaw)) fail("bad_args");
  const now = BigInt(nowRaw);
  if (now < 0n) fail("bad_args");
  const service = env("SERVICE_URL");
  if (!service) fail("bad_args");
  const stateDir = env("STATE_DIR");
  if (!stateDir) fail("bad_args");
  return { now, service: service.replace(/\/$/, ""), stateDir, crashAt: env("CRASH_AT") || "" };
}

function isCanonInt(s) {
  if (typeof s !== "string" || s.length === 0) return false;
  if (s === "0") return true;
  return /^[1-9][0-9]*$/.test(s);
}

function parseId(s) {
  if (typeof s !== "string" || !ID_RE.test(s)) fail("bad_args");
  return s;
}

function parseTime(s) {
  if (!isCanonInt(s)) fail("bad_time");
  return BigInt(s);
}

function parseSlots(s) {
  if (!isCanonInt(s)) fail("bad_slots");
  const n = Number(s);
  if (n < 1 || n > 8) fail("bad_slots");
  return n;
}

function crash(label, want) {
  if (want && want === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

function storePath(stateDir) {
  return join(stateDir, "roster.sqlite");
}

function factsOf(agg) {
  const st = agg.state;
  if (st && typeof st === "object" && st.facts && typeof st.facts === "object") return st.facts;
  if (st && typeof st === "object") return st;
  return {};
}

function strFact(facts, k, d = "") {
  const v = facts[k];
  if (v === undefined || v === null) return d;
  return String(v);
}

function intFact(facts, k) {
  const v = facts[k];
  if (v === undefined || v === null) return 0;
  return Number(v);
}

function parseShifts(facts) {
  const raw = strFact(facts, "shifts_json", "{}");
  try {
    const o = JSON.parse(raw);
    return o && typeof o === "object" && !Array.isArray(o) ? o : fail("corrupt_state");
  } catch {
    fail("corrupt_state");
  }
}

function parseAssignments(facts) {
  const raw = strFact(facts, "assignments_json", "[]");
  try {
    const a = JSON.parse(raw);
    return Array.isArray(a) ? a : fail("corrupt_state");
  } catch {
    fail("corrupt_state");
  }
}

function parseSwap(facts) {
  const raw = strFact(facts, "swap_json", "null");
  try {
    return JSON.parse(raw);
  } catch {
    fail("corrupt_state");
  }
}

function postedCount(shifts) {
  return Object.values(shifts).filter((s) => s.status === "posted").length;
}

function overlap(a, b) {
  return BigInt(a.starts_ms) < BigInt(b.ends_ms) && BigInt(a.ends_ms) > BigInt(b.starts_ms);
}

function digestNotice(snap) {
  const body = JSON.stringify({
    notice_id: snap.notice_id,
    volunteer_id: snap.volunteer_id,
    shift_id: snap.shift_id,
    kind: snap.kind,
  });
  return createHash("sha256").update(body).digest("hex");
}

function snapshotOf(facts) {
  const id = strFact(facts, "notice_id", "");
  if (!id) return null;
  return {
    notice_id: id,
    volunteer_id: strFact(facts, "notice_volunteer"),
    shift_id: strFact(facts, "notice_shift"),
    kind: strFact(facts, "notice_kind"),
  };
}

function outcomeDigest(body) {
  return createHash("sha256").update(body).digest("hex");
}

function mapKernel(err) {
  if (err instanceof AppError) throw err;
  if (err instanceof StoreNotFoundError) fail("not_open");
  const c = classify(err);
  if (c === "corrupt") fail("corrupt_state");
  if (c === "not_found") fail("not_open");
  fail("corrupt_state");
}

async function openKernel(stateDir) {
  mkdirSync(stateDir, { recursive: true });
  const store = storePath(stateDir);
  try {
    if (existsSync(store)) {
      const st = statSync(store);
      if (st.size > 0) {
        const fd = readFileSync(store);
        if (fd.length >= 16 && fd.subarray(0, 15).toString() !== "SQLite format 3") fail("corrupt_state");
      }
    }
  } catch (e) {
    if (e instanceof AppError) throw e;
  }
  const kernel = new Kernel(store);
  const machine = await kernel.machine(MACHINE);
  return { kernel, machine, store };
}

async function loadDesk(stateDir, { mustExist = false } = {}) {
  const store = storePath(stateDir);
  if (!existsSync(store)) {
    if (mustExist) fail("not_open");
    return { missing: true };
  }
  try {
    const { kernel, machine } = await openKernel(stateDir);
    try {
      const agg = await machine.show(AGG);
      return { kernel, machine, agg, facts: factsOf(agg) };
    } catch (e) {
      mapKernel(e);
    }
  } catch (e) {
    mapKernel(e);
  }
}

function statusPayload(facts, named) {
  const desk_id = strFact(facts, "desk_id", "") || null;
  const notice = strFact(facts, "notice", "none") || "none";
  const nid = strFact(facts, "notice_id", "");
  const last_shift = strFact(facts, "last_shift", "") || null;
  const last_volunteer = strFact(facts, "last_volunteer", "") || null;
  const shifts = named === "vacant" || !desk_id ? 0 : postedCount(parseShifts(facts));
  const assignments = named === "vacant" || !desk_id ? 0 : parseAssignments(facts).length;
  const swap = named === "vacant" || !desk_id ? null : parseSwap(facts);
  return {
    desk_id: named === "vacant" ? null : desk_id,
    status: named === "vacant" || !desk_id ? "none" : "open",
    shifts,
    assignments,
    swap: swap && typeof swap === "object" ? swap : null,
    notice_id: nid || null,
    notice: desk_id ? notice : "none",
    last_shift: desk_id ? last_shift : null,
    last_volunteer: desk_id ? last_volunteer : null,
    buddy_id: desk_id && swap && swap.buddy_id ? swap.buddy_id : null,
  };
}

function emptyStatus() {
  return {
    desk_id: null,
    status: "none",
    shifts: 0,
    assignments: 0,
    swap: null,
    notice_id: null,
    notice: "none",
    last_shift: null,
    last_volunteer: null,
    buddy_id: null,
  };
}

function swapHolds(swap) {
  return swap && Number(swap.era) === 2 && (swap.status === "pending" || swap.status === "accepted");
}

async function maybeExpire(ctx, now) {
  const swap = parseSwap(ctx.facts);
  if (!swap || (swap.status !== "pending" && swap.status !== "accepted")) return ctx;
  if (now <= BigInt(swap.deadline_ms)) return ctx;
  const next = { ...swap, status: "expired" };
  const agg = await ctx.agg.command("expire_swap", { swap_json: JSON.stringify(next) });
  return { ...ctx, agg, facts: factsOf(agg) };
}

async function getJson(url) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), 8000);
  try {
    const res = await fetch(url, { signal: ac.signal });
    const text = await res.text();
    let body = null;
    try {
      body = JSON.parse(text);
    } catch {
      body = null;
    }
    return { res, text, body };
  } finally {
    clearTimeout(t);
  }
}

async function postNotice(service, snap) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), 8000);
  try {
    const res = await fetch(`${service}/v1/notices`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(snap),
      signal: ac.signal,
    });
    const text = await res.text();
    let body = null;
    try {
      body = JSON.parse(text);
    } catch {
      body = null;
    }
    return { res, text, body };
  } finally {
    clearTimeout(t);
  }
}

function matchingBody(body, snap) {
  return (
    body &&
    body.notice_id === snap.notice_id &&
    body.volunteer_id === snap.volunteer_id &&
    body.shift_id === snap.shift_id &&
    body.kind === snap.kind &&
    body.outcome === "sent"
  );
}

async function recordAndCommit(ctx, snap, outcomeDig, assignments, shifts, swapObj, crashAt) {
  if (ctx.agg.pendingIntent) {
    const rec = await ctx.agg.recordEffectOutcome(outcomeDig, { intent: ctx.agg.pendingIntent });
    if (typeof rec.namedState === "function") ctx = { ...ctx, agg: rec, facts: factsOf(rec) };
    else ctx = { ...ctx, agg: await ctx.machine.show(AGG) };
    ctx.facts = factsOf(ctx.agg);
  } else {
    ctx = { ...ctx, agg: await ctx.machine.show(AGG) };
    ctx.facts = factsOf(ctx.agg);
  }
  const lastShift = snap.shift_id;
  const lastVol = snap.volunteer_id;
  const committed = await ctx.agg.command("commit_sent", {
    notice_status: "sent",
    assignments_json: JSON.stringify(assignments),
    assignments_count: assignments.length,
    shifts_json: JSON.stringify(shifts),
    shifts_count: postedCount(shifts),
    last_shift: lastShift,
    last_volunteer: lastVol,
    swap_json: JSON.stringify(swapObj ?? null),
  });
  crash("after-record-before-exit", crashAt);
  return { ...ctx, agg: committed, facts: factsOf(committed) };
}

function applyCallout(shifts, assignments, snap) {
  const sh = shifts[snap.shift_id];
  const filled = (sh.filled || 0) + 1;
  const nextShifts = { ...shifts, [snap.shift_id]: { ...sh, filled } };
  const nextAsg = [...assignments, { shift_id: snap.shift_id, volunteer_id: snap.volunteer_id }];
  return { shifts: nextShifts, assignments: nextAsg, filled };
}

function applySwap(shifts, assignments, swap, extra = {}) {
  const next = assignments.map((a) => {
    if (a.volunteer_id === swap.requester_id && a.shift_id === swap.offered_shift) {
      return { shift_id: swap.wanted_shift, volunteer_id: swap.requester_id };
    }
    if (a.volunteer_id === swap.counterpart_id && a.shift_id === swap.wanted_shift) {
      return { shift_id: swap.offered_shift, volunteer_id: swap.counterpart_id };
    }
    return a;
  });
  const nextShifts = { ...shifts };
  return { shifts: nextShifts, assignments: next, swap: { ...swap, status: "accepted", ...extra } };
}

async function adoptOrPost(ctx, envx, snap, buildCommit) {
  const { service, crashAt } = envx;
  const notice = strFact(ctx.facts, "notice");
  const saved = snapshotOf(ctx.facts);
  const pending = notice === "attempt_saved" && saved;

  if (pending) {
    if (
      saved.notice_id !== snap.notice_id ||
      saved.volunteer_id !== snap.volunteer_id ||
      saved.shift_id !== snap.shift_id ||
      saved.kind !== snap.kind
    ) {
      fail("lookup_conflict");
    }
    let looked;
    try {
      looked = await getJson(`${service}/v1/notices/${encodeURIComponent(saved.notice_id)}`);
    } catch {
      fail("service_unavailable");
    }
    if (looked.res.status === 200) {
      if (!matchingBody(looked.body, saved)) fail("lookup_conflict");
      const built = buildCommit();
      ctx = await recordAndCommit(
        ctx,
        saved,
        outcomeDigest(looked.text),
        built.assignments,
        built.shifts,
        built.swap,
        crashAt,
      );
      return { ctx, notice_id: saved.notice_id, notice: "sent", filled: built.filled };
    }
    if (looked.res.status !== 404) fail("service_unavailable");
  } else {
    const payload_digest = digestNotice(snap);
    ctx = {
      ...ctx,
      agg: await ctx.agg.command("begin_notice", {
        notice_id: snap.notice_id,
        volunteer_id: snap.volunteer_id,
        shift_id: snap.shift_id,
        kind: snap.kind,
        notice_status: "attempt_saved",
        effect_id: snap.notice_id,
        payload_digest,
        idempotency_key: snap.notice_id,
      }),
    };
    ctx.facts = factsOf(ctx.agg);
  }

  crash("after-notice-saved-before-request", crashAt);

  let posted;
  try {
    posted = await postNotice(service, snap);
  } catch {
    fail("service_unavailable");
  }
  if (!posted.res || posted.res.status >= 500 || posted.body == null || posted.text === "") {
    fail("service_unavailable");
  }
  if (posted.res.status === 409) fail("lookup_conflict");
  if (posted.res.status !== 200 || !matchingBody(posted.body, snap)) fail("service_unavailable");
  crash("after-accept-before-record", crashAt);
  const built = buildCommit();
  ctx = await recordAndCommit(
    ctx,
    snap,
    outcomeDigest(posted.text),
    built.assignments,
    built.shifts,
    built.swap,
    crashAt,
  );
  return { ctx, notice_id: snap.notice_id, notice: "sent", filled: built.filled };
}

async function cmdOpen(args, envx) {
  const desk_id = parseId(args[0] ?? fail("bad_args"));
  if (args.length !== 1) fail("bad_args");
  const store = storePath(envx.stateDir);
  if (existsSync(store)) {
    const loaded = await loadDesk(envx.stateDir);
    if (!loaded.missing && loaded.facts && strFact(loaded.facts, "desk_id")) fail("already_open");
  }
  const { machine } = await openKernel(envx.stateDir);
  const created = await machine.createWith({
    aggregateId: AGG,
    command: { name: "open", args: { desk_id } },
  });
  const agg = created.namedState ? created : await machine.show(AGG);
  return {
    desk_id,
    status: "open",
    shifts: 0,
    assignments: 0,
    swap: null,
    notice_id: null,
    notice: "none",
  };
}

async function requireOpen(envx) {
  const loaded = await loadDesk(envx.stateDir, { mustExist: true });
  if (loaded.missing) fail("not_open");
  if (loaded.agg.namedState() === "vacant" || !strFact(loaded.facts, "desk_id")) fail("not_open");
  return loaded;
}

async function cmdPost(args, envx) {
  if (args.length !== 4) fail("bad_args");
  const shift_id = parseId(args[0]);
  const starts_ms = parseTime(args[1]);
  const ends_ms = parseTime(args[2]);
  const slots = parseSlots(args[3]);
  if (starts_ms >= ends_ms) fail("bad_time");
  let ctx = await requireOpen(envx);
  const shifts = parseShifts(ctx.facts);
  if (shifts[shift_id]) fail("shift_exists");
  shifts[shift_id] = {
    shift_id,
    starts_ms: starts_ms.toString(),
    ends_ms: ends_ms.toString(),
    slots,
    filled: 0,
    status: "posted",
  };
  const agg = await ctx.agg.command("post_shift", {
    shifts_json: JSON.stringify(shifts),
    shifts_count: postedCount(shifts),
  });
  return {
    shift_id,
    starts_ms: Number(starts_ms),
    ends_ms: Number(ends_ms),
    slots,
    filled: 0,
    status: "posted",
  };
}

async function cmdAssign(args, envx) {
  if (args.length !== 2) fail("bad_args");
  const shift_id = parseId(args[0]);
  const volunteer_id = parseId(args[1]);
  let ctx = await requireOpen(envx);
  ctx = await maybeExpire(ctx, envx.now);
  const shifts = parseShifts(ctx.facts);
  const assignments = parseAssignments(ctx.facts);
  const sh = shifts[shift_id];
  if (!sh || sh.status !== "posted") fail("unknown_shift");
  const occupying = assignments.some((a) => a.shift_id === shift_id && a.volunteer_id === volunteer_id);
  const notice = strFact(ctx.facts, "notice");
  const saved = snapshotOf(ctx.facts);
  if (occupying && notice === "sent" && saved && saved.shift_id === shift_id && saved.volunteer_id === volunteer_id) {
    return {
      shift_id,
      volunteer_id,
      filled: sh.filled,
      notice_id: saved.notice_id,
      notice: "sent",
      status: "assigned",
    };
  }
  if (occupying) fail("already_assigned");
  const hold = parseSwap(ctx.facts);
  if (swapHolds(hold) && (volunteer_id === hold.requester_id || volunteer_id === hold.counterpart_id)) {
    fail("swap_hold");
  }
  if (sh.filled >= sh.slots) fail("shift_full");
  for (const a of assignments) {
    if (a.volunteer_id !== volunteer_id) continue;
    const other = shifts[a.shift_id];
    if (other && other.status === "posted" && overlap(sh, other)) fail("overlap");
  }
  let snap;
  if (notice === "attempt_saved" && saved) {
    snap = saved;
    if (saved.shift_id !== shift_id || saved.volunteer_id !== volunteer_id || saved.kind !== "callout") {
      fail("lookup_conflict");
    }
  } else {
    snap = { notice_id: `n-${randomUUID()}`, volunteer_id, shift_id, kind: "callout" };
  }
  const out = await adoptOrPost(ctx, envx, snap, () => {
    const curSh = parseShifts(ctx.facts);
    const curAs = parseAssignments(ctx.facts);
    const applied = applyCallout(curSh, curAs, snap);
    return { ...applied, swap: parseSwap(ctx.facts), filled: applied.shifts[shift_id].filled };
  });
  return {
    shift_id,
    volunteer_id,
    filled: out.filled,
    notice_id: out.notice_id,
    notice: "sent",
    status: "assigned",
  };
}

async function cmdOffer(args, envx) {
  if (args.length !== 6) fail("bad_args");
  const swap_id = parseId(args[0]);
  const offered_shift = parseId(args[1]);
  const wanted_shift = parseId(args[2]);
  const requester_id = parseId(args[3]);
  const counterpart_id = parseId(args[4]);
  const deadline_ms = parseTime(args[5]);
  if (deadline_ms <= envx.now) fail("bad_time");
  let ctx = await requireOpen(envx);
  ctx = await maybeExpire(ctx, envx.now);
  const swap = parseSwap(ctx.facts);
  if (swap && (swap.status === "pending" || swap.status === "accepted")) fail("swap_open");
  const assignments = parseAssignments(ctx.facts);
  const reqOk = assignments.some((a) => a.shift_id === offered_shift && a.volunteer_id === requester_id);
  const cOk = assignments.some((a) => a.shift_id === wanted_shift && a.volunteer_id === counterpart_id);
  if (!reqOk || !cOk) fail("not_assigned");
  const rec = {
    swap_id,
    status: "pending",
    offered_shift,
    wanted_shift,
    requester_id,
    counterpart_id,
    deadline_ms: Number(deadline_ms),
    era: 2,
  };
  await ctx.agg.command("offer_swap", { swap_json: JSON.stringify(rec) });
  return rec;
}

async function cmdRespond(args, envx) {
  if (args.length !== 2) fail("bad_args");
  const swap_id = parseId(args[0]);
  const decision = args[1];
  if (decision !== "accept" && decision !== "decline") fail("bad_args");
  let ctx = await requireOpen(envx);
  ctx = await maybeExpire(ctx, envx.now);
  let swap = parseSwap(ctx.facts);
  if (!swap || swap.swap_id !== swap_id) fail("swap_mismatch");
  if (swap.status === "expired") fail("swap_expired");
  if (swap.status === "declined") fail("swap_mismatch");
  if (swap.status === "accepted") {
    if (Number(swap.era) === 2) fail("needs_buddy");
    fail("swap_mismatch");
  }
  if (envx.now > BigInt(swap.deadline_ms)) {
    await ctx.agg.command("expire_swap", { swap_json: JSON.stringify({ ...swap, status: "expired" }) });
    fail("swap_expired");
  }
  if (decision === "decline") {
    const next = { ...swap, status: "declined" };
    await ctx.agg.command("decline_swap", { swap_json: JSON.stringify(next) });
    return next;
  }
  if (Number(swap.era) === 2) {
    const next = { ...swap, status: "accepted", era: 2 };
    await ctx.agg.command("offer_swap", { swap_json: JSON.stringify(next) });
    return { swap_id, status: "accepted", era: 2 };
  }
  const notice = strFact(ctx.facts, "notice");
  const saved = snapshotOf(ctx.facts);
  let snap;
  if (notice === "attempt_saved" && saved && saved.kind === "swap") {
    snap = saved;
    if (saved.volunteer_id !== swap.requester_id || saved.shift_id !== swap.wanted_shift) fail("lookup_conflict");
  } else {
    snap = {
      notice_id: `n-${randomUUID()}`,
      volunteer_id: swap.requester_id,
      shift_id: swap.wanted_shift,
      kind: "swap",
    };
  }
  const out = await adoptOrPost(ctx, envx, snap, () => {
    const applied = applySwap(parseShifts(ctx.facts), parseAssignments(ctx.facts), swap);
    const wanted = applied.shifts[swap.wanted_shift];
    return { ...applied, filled: wanted ? wanted.filled : 0 };
  });
  return {
    swap_id,
    status: "accepted",
    offered_shift: swap.offered_shift,
    wanted_shift: swap.wanted_shift,
    requester_id: swap.requester_id,
    counterpart_id: swap.counterpart_id,
    deadline_ms: swap.deadline_ms,
    era: swap.era,
    notice_id: out.notice_id,
    notice: "sent",
  };
}

async function cmdReconcile(args, envx) {
  if (args.length !== 1) fail("bad_args");
  const notice_id = parseId(args[0]);
  let ctx = await requireOpen(envx);
  const notice = strFact(ctx.facts, "notice");
  const saved = snapshotOf(ctx.facts);
  if (!saved || notice === "none" || !strFact(ctx.facts, "notice_id")) fail("no_notice");
  if (saved.notice_id !== notice_id) fail("notice_mismatch");
  if (notice === "sent") {
    const shifts = parseShifts(ctx.facts);
    const sh = shifts[saved.shift_id];
    return {
      shift_id: saved.shift_id,
      volunteer_id: saved.volunteer_id,
      filled: sh ? sh.filled : 0,
      notice_id,
      notice: "sent",
      status: saved.kind === "swap" ? "swapped" : "assigned",
      lookup: "sent",
    };
  }
  let looked;
  try {
    looked = await getJson(`${envx.service}/v1/notices/${encodeURIComponent(notice_id)}`);
  } catch {
    fail("service_unavailable");
  }
  if (looked.res.status === 404) {
    return { lookup: "not_sent", notice_id, notice: "attempt_saved" };
  }
  if (looked.res.status !== 200) fail("service_unavailable");
  if (!matchingBody(looked.body, saved)) fail("lookup_conflict");
  const built =
    saved.kind === "swap"
      ? applySwap(parseShifts(ctx.facts), parseAssignments(ctx.facts), parseSwap(ctx.facts))
      : applyCallout(parseShifts(ctx.facts), parseAssignments(ctx.facts), saved);
  ctx = await recordAndCommit(
    ctx,
    saved,
    outcomeDigest(looked.text),
    built.assignments,
    built.shifts,
    built.swap ?? parseSwap(ctx.facts),
    envx.crashAt,
  );
  const sh = built.shifts[saved.shift_id];
  return {
    shift_id: saved.shift_id,
    volunteer_id: saved.volunteer_id,
    filled: sh ? sh.filled : 0,
    notice_id,
    notice: "sent",
    status: saved.kind === "swap" ? "swapped" : "assigned",
    lookup: "sent",
  };
}

async function cmdCancel(args, envx) {
  if (args.length !== 1) fail("bad_args");
  const shift_id = parseId(args[0]);
  const ctx = await requireOpen(envx);
  const shifts = parseShifts(ctx.facts);
  const sh = shifts[shift_id];
  if (!sh || sh.status !== "posted") fail("unknown_shift");
  if (sh.filled > 0) fail("shift_occupied");
  const asg = parseAssignments(ctx.facts).some((a) => a.shift_id === shift_id);
  if (asg) fail("shift_occupied");
  sh.status = "cancelled";
  await ctx.agg.command("cancel_shift", {
    shifts_json: JSON.stringify(shifts),
    shifts_count: postedCount(shifts),
  });
  return { shift_id, status: "cancelled" };
}

async function cmdStatus(_args, envx) {
  const store = storePath(envx.stateDir);
  if (!existsSync(store)) return emptyStatus();
  const loaded = await loadDesk(envx.stateDir);
  if (loaded.missing) return emptyStatus();
  return statusPayload(loaded.facts, loaded.agg.namedState());
}

async function cmdCallback(args, envx) {
  if (args.length !== 1) fail("bad_args");
  const p = args[0];
  let raw;
  try {
    raw = readFileSync(p, "utf8");
  } catch {
    fail("bad_callback");
  }
  let obj;
  try {
    obj = JSON.parse(raw);
  } catch {
    fail("bad_callback");
  }
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) fail("bad_callback");
  await requireOpen(envx);
  return { ignored: true };
}

function validBuddy(assignments, shifts, swap, buddy_id) {
  if (buddy_id === swap.requester_id || buddy_id === swap.counterpart_id) return false;
  return assignments.some((a) => {
    const sh = shifts[a.shift_id];
    return a.volunteer_id === buddy_id && sh && sh.status === "posted";
  });
}

async function cmdConfirm(args, envx) {
  if (args.length !== 2) fail("bad_args");
  const swap_id = parseId(args[0]);
  const buddy_id = parseId(args[1]);
  let ctx = await requireOpen(envx);
  ctx = await maybeExpire(ctx, envx.now);
  let swap = parseSwap(ctx.facts);
  if (!swap || swap.swap_id !== swap_id) fail("swap_mismatch");
  if (swap.status === "expired") fail("swap_expired");
  if (Number(swap.era) !== 2) fail("legacy_swap");
  if (swap.status === "declined") fail("swap_mismatch");
  if (swap.status !== "accepted") fail("not_accepted");
  const assignments = parseAssignments(ctx.facts);
  const shifts = parseShifts(ctx.facts);
  if (!validBuddy(assignments, shifts, swap, buddy_id)) fail("not_assigned");
  const notice = strFact(ctx.facts, "notice");
  const saved = snapshotOf(ctx.facts);
  if (notice === "sent" && swap.buddy_id === buddy_id) {
    return {
      swap_id,
      status: "accepted",
      era: 2,
      offered_shift: swap.offered_shift,
      wanted_shift: swap.wanted_shift,
      requester_id: swap.requester_id,
      counterpart_id: swap.counterpart_id,
      deadline_ms: swap.deadline_ms,
      buddy_id,
      notice_id: saved ? saved.notice_id : strFact(ctx.facts, "notice_id"),
      notice: "sent",
    };
  }
  if (swap.buddy_id && swap.buddy_id !== buddy_id) fail("buddy_mismatch");
  if (notice === "sent" && saved && saved.kind === "swap" && swap.buddy_id && swap.buddy_id !== buddy_id) {
    fail("buddy_mismatch");
  }
  let snap;
  if (notice === "attempt_saved" && saved && saved.kind === "swap") {
    snap = saved;
    if (saved.volunteer_id !== swap.requester_id || saved.shift_id !== swap.wanted_shift) fail("lookup_conflict");
  } else {
    snap = {
      notice_id: `n-${randomUUID()}`,
      volunteer_id: swap.requester_id,
      shift_id: swap.wanted_shift,
      kind: "swap",
    };
  }
  const out = await adoptOrPost(ctx, envx, snap, () => {
    const applied = applySwap(parseShifts(ctx.facts), parseAssignments(ctx.facts), swap, { buddy_id, era: 2 });
    const wanted = applied.shifts[swap.wanted_shift];
    return { ...applied, filled: wanted ? wanted.filled : 0 };
  });
  return {
    swap_id,
    status: "accepted",
    era: 2,
    offered_shift: swap.offered_shift,
    wanted_shift: swap.wanted_shift,
    requester_id: swap.requester_id,
    counterpart_id: swap.counterpart_id,
    deadline_ms: swap.deadline_ms,
    buddy_id,
    notice_id: out.notice_id,
    notice: "sent",
  };
}

const COMMANDS = {
  open: cmdOpen,
  "post-shift": cmdPost,
  assign: cmdAssign,
  "offer-swap": cmdOffer,
  "respond-swap": cmdRespond,
  "confirm-swap": cmdConfirm,
  reconcile: cmdReconcile,
  "cancel-shift": cmdCancel,
  status: cmdStatus,
  callback: cmdCallback,
};

async function main() {
  try {
    const argv = process.argv.slice(2);
    const name = argv[0];
    if (!name || !COMMANDS[name]) fail("bad_args");
    const envx = requireEnv();
    const out = await COMMANDS[name](argv.slice(1), envx);
    process.stdout.write(JSON.stringify(out) + "\n");
  } catch (e) {
    if (e instanceof AppError) {
      process.stdout.write(JSON.stringify({ error: e.code }) + "\n");
      process.exit(e.exit);
    }
    const code = e && e.code === "corrupt_state" ? "corrupt_state" : "bad_args";
    process.stdout.write(JSON.stringify({ error: typeof e?.code === "string" && e.code.length < 40 ? e.code : code }) + "\n");
    process.exit(1);
  }
}

main();
