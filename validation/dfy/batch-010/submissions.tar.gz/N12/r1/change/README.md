# Volunteer shift roster desk

Durable local desk for one volunteer roster. Lifecycle and notice-attempt identity are stored in Ikaros (`machines/desk.ik.toml`). SMS call-outs go to the fake gateway in `stub/`.

## Setup

Node 22 (`<home>/.nvm/versions/node/v22.17.1/bin/node`). npm registry is not required.

```bash
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

## Run

Every command needs `STATE_DIR`, `SERVICE_URL`, and `NOW_MS` (non-negative decimal epoch ms). Optional `CRASH_AT` labels: `after-notice-saved-before-request`, `after-accept-before-record`, `after-record-before-exit`.

```bash
node stub/server.mjs   # prints {"service_url":"...","control_url":"..."}
export STATE_DIR=/tmp/desk SERVICE_URL='<service_url>' NOW_MS=1000
./run open desk1
./run post-shift s1 1000 2000 2
./run assign s1 volunteer.1
./run confirm-swap <swap_id> <buddy_id>
./run status
```

`./run` uses Node 22 when present, otherwise `node` on `PATH`. Override with `NODE_BIN`.

## Tests

```bash
<home>/.nvm/versions/node/v22.17.1/bin/node tests/desk.test.mjs
```
