# Volunteer shift roster desk

The program behind `./run` is a durable local desk for one volunteer roster. It posts shifts with a fixed slot count, assigns volunteers, records a two-party swap request with a response deadline measured against `NOW_MS`, and sends at most one SMS call-out per assignment change through an external gateway. A notice id is saved before the SMS request; recovery looks up that id before any retry.

## Scope and invocation

One machine and one process at a time. One desk is bound to a state directory. An unrelated writer may create or modify other files in `STATE_DIR`; those files must survive byte-for-byte. The tool may keep its durable files in `STATE_DIR` under any names. It must use `STATE_DIR`, `SERVICE_URL`, `NOW_MS`, and optional `CRASH_AT`. `SERVICE_URL` is required for every command, including status (status never contacts it). `NOW_MS` is a required non-negative integer epoch-millisecond clock for every command.

`./run <command> [args]` prints exactly one JSON object and nothing else (one trailing newline is allowed). Exit 0 is success. Refusals are nonzero and print `{ "error": "<code>" }`. Identifiers are 1–64 characters matching `A-Za-z0-9._-`. Times and slot counts are canonical non-negative decimal integers. Slot counts are integers from 1 through 8. `starts_ms` must be strictly less than `ends_ms`. `CRASH_AT` labels are:

* `after-notice-saved-before-request`: after saving a notice id and notice snapshot, before sending a request;
* `after-accept-before-record`: after reading a complete successful provider response, before saving the assigned or swapped record;
* `after-record-before-exit`: after saving that record, before success JSON is written.

A process must kill itself with SIGKILL at a reached label. Durable commits are flushed before the command treats them as committed. A malformed owned state file is `corrupt_state` and is not rewritten. Refusals do not modify state except that a pending swap whose deadline is already past `NOW_MS` may durably become `expired`.

## Commands

`open <desk_id>` binds the empty store. It returns `{desk_id,status:"open",shifts:0,assignments:0,swap:null,notice_id:null,notice:"none"}`. A second open is `already_open`; a malformed id is `bad_args`. It never contacts the provider.

`post-shift <shift_id> <starts_ms> <ends_ms> <slots>` records a posted shift. It returns `{shift_id,starts_ms,ends_ms,slots,filled:0,status:"posted"}`. A duplicate id is `shift_exists`. Malformed times are `bad_time`; a slot count outside 1–8 is `bad_slots`. It never contacts the provider.

`assign <shift_id> <volunteer_id>` places a volunteer into an open posted shift that still has a free slot. Overlapping assignments for the same volunteer (two posted shifts with `starts_ms < other.ends_ms` and `ends_ms > other.starts_ms`) are `overlap`. A full shift is `shift_full`. An unknown or cancelled shift is `unknown_shift`. A duplicate volunteer already occupying that shift before a send is `already_assigned`. Commands that require a bound desk on an empty store are `not_open`. The same volunteer already on that shift after a successful send is a success no-op without a provider call.

A first assignment for that pair generates a notice id, saves the exact snapshot `{notice_id,volunteer_id,shift_id,kind:"callout"}`, then POSTs once. Connection failure, an incomplete response, or HTTP 5xx leaves `notice:"attempt_saved"` and returns `service_unavailable`; that invocation does not lookup. A matching successful response returns `{shift_id,volunteer_id,filled,notice_id,notice:"sent",status:"assigned"}`.

If a saved attempt exists, `assign` first `GET /v1/notices/<notice_id>`: a matching 200 is adopted without POST; a 404 causes one POST with the saved id only. Never allocate a replacement id. A mismatching success is `lookup_conflict` and changes nothing.

`offer-swap <swap_id> <offered_shift> <wanted_shift> <requester_id> <counterpart_id> <deadline_ms>` opens the one allowed pending swap. The requester must already be assigned to `offered_shift` and the counterpart to `wanted_shift`. `deadline_ms` must be strictly greater than `NOW_MS`. A second pending swap is `swap_open`. Parties or shifts that do not match the roster are `not_assigned`. It returns `{swap_id,status:"pending",offered_shift,wanted_shift,requester_id,counterpart_id,deadline_ms,era:1}` and never contacts the provider.

`respond-swap <swap_id> <decision>` where `decision` is exactly `accept` or `decline`. A wrong id is `swap_mismatch`. `decline` marks the swap `declined` with no provider call. `accept` exchanges the two assignments, saves a notice snapshot `{notice_id,volunteer_id:requester_id,shift_id:wanted_shift,kind:"swap"}`, and POSTs once under the same crash and lookup rules as `assign`. After `NOW_MS` is greater than `deadline_ms`, the swap durably becomes `expired` and the command returns `swap_expired` without a provider request.

`reconcile <notice_id>` never POSTs or allocates. No saved notice is `no_notice`; another id is `notice_mismatch`. Lookup 200 with matching ids, volunteer, shift, and kind commits `notice:"sent"` and returns the success object plus `lookup:"sent"`; 404 returns exit 0 `{lookup:"not_sent",notice_id,notice:"attempt_saved"}`; a mismatch is `lookup_conflict`; transport failure is `service_unavailable`.

`cancel-shift <shift_id>` is allowed only for a posted shift with `filled:0`. It marks the shift `cancelled`, returns `{shift_id,status:"cancelled"}`, and never contacts the provider. A shift with any assignment is `shift_occupied`.

`status` never contacts the provider and returns `{desk_id,status,shifts,assignments,swap,notice_id,notice,last_shift,last_volunteer}`. Empty fields are null, with `shifts:0`, `assignments:0`, `status:"none"`, `notice:"none"`, and `swap:null`. `shifts` counts posted (not cancelled) shifts. `assignments` counts current volunteer placements. `swap` is null or `{swap_id,status,offered_shift,wanted_shift,requester_id,counterpart_id,deadline_ms,era}`.

`callback <path>` reads one JSON callback. It must not POST or allocate. A malformed callback is `bad_callback`; a well-formed callback may be ignored. It must never overwrite `notice:"sent"` or a declined, expired, or cancelled outcome.

## Provider

The supplied service has `POST /v1/notices` and `GET /v1/notices/<notice_id>`. A first valid notice id records one effect and returns the body with `outcome:"sent"`; repeating the same id and identical fields returns the same object without another effect; any differing field is HTTP 409. Unknown lookup is 404. The provider may drop a reply after accepting, hold a reply, or return 5xx without storing. Control endpoints are not part of this contract.

POST JSON fields are `notice_id`, `volunteer_id`, `shift_id`, and `kind` (`callout` or `swap`).

## Requirements

R1. Open and every later committed record survive new processes, including a notice attempt killed at `after-notice-saved-before-request`.

R2. Opening validates `desk_id`, binds one desk, and does not contact the provider. `post-shift` validates times and slots without contacting the provider.

R3. A healthy provider assigns a volunteer into a free slot, records one durable notice attempt, and increments `filled`; a full shift is `shift_full` without mutation or a provider call.

R4. Cancelling an empty shift is terminal for that shift and provider-free. A filled shift cannot be cancelled. An overlapping second assignment is `overlap` without a provider call.

R5. A healthy provider permits an assignment and exactly one external SMS effect; repeating the same assign is a no-op and does not add an effect.

R6. Callback files never overwrite local terminal outcomes (`notice:"sent"`, declined/expired swaps, cancelled shifts) and never cause provider effects.

R7. Unknown shifts, occupied cancels, a second pending swap, and a swap response after the deadline are refused without contacting the provider. Past-deadline pending swaps durably become `expired`.

R8. A crash before POST leaves one saved notice id and zero effects; a later assign POSTs that same id and ends `notice:"sent"` exactly once.

R9. A crash after provider acceptance leaves `attempt_saved` locally and one provider effect; later assign adopts by lookup without a second effect.

R10. A crash after the durable sent record leaves `notice:"sent"` and later assign of that pair is a no-op; reconcile can likewise survive its record-before-exit crash.

R11. A dropped notice reply yields `service_unavailable` and `attempt_saved`; following reconcile adopts `sent` by lookup, never reports `not_sent`, and never posts again.

R12. Reconcile never POSTs: a saved-but-unaccepted id returns `not_sent` with `attempt_saved`; a wrong id is `notice_mismatch` and leaves state unchanged.

R13. Unrelated files in STATE_DIR retain identical bytes through commits and refusals.

R14. Every invocation emits one JSON object; status on empty is the null shape; missing SERVICE_URL or NOW_MS is a refusal; the first open binds the only desk and no command can open another.
