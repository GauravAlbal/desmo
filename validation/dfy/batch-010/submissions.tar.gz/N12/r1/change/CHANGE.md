# Change: buddy confirmation and swap hold

R1–R14 remain in force except where a numbered item below explicitly supersedes assignment or swap completion. `status` additionally reports `buddy_id` (null until a new-era swap is confirmed). This change adds `confirm-swap` and changes how new swaps complete and how they interact with `assign`.

The new command is:

`confirm-swap <swap_id> <buddy_id>`

`buddy_id` must be a volunteer currently assigned to some posted shift who is neither the requester nor the counterpart. The command never contacts the provider except when it is the command that sends the swap SMS (new-era swaps only).

## Behavior change

Every swap record carries `era`. Swaps created by `offer-swap` **before this change** persist `era:1`. Swaps created **after this change** persist `era:2`.

**Old-instance policy (era:1, including pending swaps already in STATE_DIR):**

* `respond-swap accept` still exchanges the two assignments immediately and sends the swap SMS under R8–R12, exactly as before the change.
* `confirm-swap` on an era:1 swap returns `legacy_swap` and changes nothing.
* `assign` is **not** blocked by an era:1 pending swap. Requester and counterpart may still be assigned to other non-overlapping shifts.
* Declined, expired, and completed era:1 swaps keep their recorded outcomes; they are never rewritten into era:2 and never require a buddy.

**New-instance policy (era:2):**

* `respond-swap accept` does **not** exchange assignments and does **not** send SMS. It marks the swap `accepted` and returns `{swap_id,status:"accepted",era:2}`. Completing the swap without `confirm-swap` is `needs_buddy`. An unknown command name is `unknown_command` on the pre-change program.
* `confirm-swap` on `accepted` exchanges the assignments, records `buddy_id`, saves the swap notice snapshot, and POSTs once under the same crash and lookup rules as `assign`.
* Repeating `confirm-swap` with the same buddy after `notice:"sent"` is a success no-op with no provider call. A different buddy is `buddy_mismatch`. Confirm before accept is `not_accepted`.
* `assign` of the requester or counterpart of a pending or accepted era:2 swap is `swap_hold` without a provider call, including assignments to other shifts. Completed, declined, and expired era:2 swaps do not hold.

Quiet facts: `offer-swap` after the change still validates the same roster conditions and still refuses `swap_open` while any pending or accepted swap exists. `decline` is unchanged for both eras. Deadlines still expire pending or accepted swaps to `expired` on `respond-swap` or `confirm-swap` when `NOW_MS` is past `deadline_ms`, without a provider call.

## C1–C5

C1. `confirm-swap` on an era:2 accepted swap with a valid buddy exchanges the two assignments, persists `buddy_id`, sends exactly one swap SMS, and does not send a second effect on a same-buddy repeat.

C2. Confirm state survives a new process. Confirm on the wrong swap id is `swap_mismatch`. Confirm on era:1 is `legacy_swap` without mutation. Confirm before accept is `not_accepted`.

C3. After the change, `assign` of a party to an era:2 pending or accepted swap is `swap_hold` with no provider call. An era:1 pending swap left by the old program does **not** hold; `assign` of that counterpart to another non-overlapping shift succeeds.

C4. An era:1 pending swap created by the old program still completes on `respond-swap accept` (assignments exchange, one swap SMS). The same command on an era:2 pending swap does not exchange assignments and does not send SMS (`accepted` only).

C5. Swap SMS and assignment call-outs still respect the saved-notice crash boundaries after the change: a crash before POST or a dropped reply recovers the same notice id by lookup/retry, and no second provider effect is created. Cancellation of an empty unrelated shift cannot erase a saved notice.
