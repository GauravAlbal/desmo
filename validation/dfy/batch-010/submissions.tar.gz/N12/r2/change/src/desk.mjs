import { createHash, randomBytes } from "node:crypto";
import { existsSync } from "node:fs";
import { readFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Kernel,
  StoreNotFoundError,
  classify,
} from "@ikaros/runtime";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const MACHINE_V1 = join(ROOT, "machines", "desk.v1.ik.toml");
const MACHINE_V2 = join(ROOT, "machines", "desk.ik.toml");
const AGG = "desk";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const CRASH_LABELS = new Set([
  "after-notice-saved-before-request",
  "after-accept-before-record",
  "after-record-before-exit",
]);

export function fail(code, exit = 1) {
  process.stdout.write(JSON.stringify({ error: code }) + "\n");
  process.exit(exit);
}

function crash(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

function parseNow(raw) {
  if (raw === undefined || raw === "") fail("bad_args");
  if (!/^[0-9]+$/.test(raw)) fail("bad_args");
  return raw;
}

function parseNonneg(raw, code = "bad_args") {
  if (raw === undefined || !/^[0-9]+$/.test(raw)) fail(code);
  return raw;
}

function checkId(id) {
  if (typeof id !== "string" || !ID_RE.test(id)) fail("bad_args");
}

function facts(agg) {
  const s = agg.state && typeof agg.state === "object" ? agg.state : {};
  return s;
}

function storePath(stateDir) {
  return join(stateDir, "desk.sqlite");
}

function emptyRoster() {
  return { shifts: {} };
}

function parseRoster(raw) {
  if (!raw) return emptyRoster();
  const o = JSON.parse(raw);
  if (!o || typeof o !== "object" || typeof o.shifts !== "object") {
    throw new Error("bad roster");
  }
  return o;
}

function rosterStr(r) {
  return JSON.stringify(r);
}

function postedCount(r) {
  return Object.values(r.shifts).filter((s) => s.status === "posted").length;
}

function assignmentCount(r) {
  let n = 0;
  for (const s of Object.values(r.shifts)) {
    if (s.status === "posted") n += s.volunteers.length;
  }
  return n;
}

function overlaps(a, b) {
  return Number(a.starts_ms) < Number(b.ends_ms) && Number(a.ends_ms) > Number(b.starts_ms);
}

function volunteerShifts(r, volunteerId) {
  return Object.entries(r.shifts)
    .filter(([, s]) => s.status === "posted" && s.volunteers.includes(volunteerId))
    .map(([id, s]) => ({ id, ...s }));
}

function digestOf(snapshot) {
  return createHash("sha256")
    .update(
      JSON.stringify({
        notice_id: snapshot.notice_id,
        volunteer_id: snapshot.volunteer_id,
        shift_id: snapshot.shift_id,
        kind: snapshot.kind,
      }),
    )
    .digest("hex");
}

function newNoticeId() {
  return `n_${randomBytes(16).toString("hex")}`;
}

function snapshotFromFacts(f) {
  return {
    notice_id: f.notice_id,
    volunteer_id: f.notice_volunteer,
    shift_id: f.notice_shift,
    kind: f.notice_kind,
  };
}

function swapView(f) {
  if (!f.swap_id || f.swap_status === "none" || f.swap_status === "") return null;
  return {
    swap_id: f.swap_id,
    status: f.swap_status,
    offered_shift: f.offered_shift,
    wanted_shift: f.wanted_shift,
    requester_id: f.requester_id,
    counterpart_id: f.counterpart_id,
    deadline_ms: Number(f.deadline_ms),
    era: Number(f.era),
  };
}

function buddyOf(f) {
  return f.buddy_id ? f.buddy_id : null;
}

function statusPayload(f) {
  if (!f.desk_id) {
    return {
      desk_id: null,
      status: "none",
      shifts: 0,
      assignments: 0,
      swap: null,
      notice_id: null,
      notice: "none",
      last_shift: null,
      last_volunteer: null,
      buddy_id: null,
    };
  }
  return {
    desk_id: f.desk_id,
    status: "open",
    shifts: Number(f.shift_count || 0),
    assignments: Number(f.assignment_count || 0),
    swap: swapView(f),
    notice_id: f.notice_id || null,
    notice: f.notice || "none",
    last_shift: f.last_shift || null,
    last_volunteer: f.last_volunteer || null,
    buddy_id: buddyOf(f),
  };
}

function ikBinary() {
  if (process.env.IK_BINARY) return process.env.IK_BINARY;
  return join(ROOT, "node_modules", "@ikaros", "darwin-arm64", "bin", "ik");
}

function mapKernelError(e) {
  if (e instanceof StoreNotFoundError) return "not_open";
  const c = classify(e);
  if (c === "corrupt") return "corrupt_state";
  if (c === "not_found") return "not_open";
  if (c === "refused") return "bad_args";
  if (c === "uncertain") return "service_unavailable";
  return "corrupt_state";
}

function eraOf(f) {
  return Number(f.era || 0);
}

function swapHolds(f) {
  if (eraOf(f) !== 2) return false;
  return f.swap_status === "pending" || f.swap_status === "accepted";
}

function swapCompletedSms(f) {
  return f.notice === "sent" && f.notice_kind === "swap" && f.swap_status === "accepted";
}

async function openKernel(stateDir) {
  const store = storePath(stateDir);
  const kernel = new Kernel(store, { binary: ikBinary(), timeoutMs: 15000 });
  return { kernel, store };
}

async function showOrNull(machine) {
  try {
    return await machine.show(AGG);
  } catch (e) {
    if (e instanceof StoreNotFoundError) return null;
    const c = classify(e);
    if (c === "not_found") return null;
    if (c === "corrupt") fail("corrupt_state");
    throw e;
  }
}

async function bindExisting(kernel) {
  const m2 = await kernel.machine(MACHINE_V2);
  let agg = await showOrNull(m2);
  if (!agg) return { machine: m2, agg: null };
  if (agg.owner && m2.identity && agg.owner.equals(m2.identity)) {
    return { machine: m2, agg };
  }
  const m1 = await kernel.machine(MACHINE_V1);
  agg = await showOrNull(m1);
  return { machine: m1, agg };
}

async function httpJson(method, url, body) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), 8000);
  try {
    const res = await fetch(url, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      signal: ac.signal,
    });
    const text = await res.text();
    if (!text) return { status: res.status, json: null, incomplete: true };
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      return { status: res.status, json: null, incomplete: true };
    }
    return { status: res.status, json, incomplete: false };
  } catch {
    return { status: 0, json: null, incomplete: true, fail: true };
  } finally {
    clearTimeout(t);
  }
}

function matchingNotice(json, snap) {
  return (
    json &&
    json.notice_id === snap.notice_id &&
    json.volunteer_id === snap.volunteer_id &&
    json.shift_id === snap.shift_id &&
    json.kind === snap.kind &&
    json.outcome === "sent"
  );
}

async function maybeExpire(agg, now, f) {
  const st = f.swap_status;
  const can = st === "pending" || (eraOf(f) === 2 && st === "accepted");
  if (can && Number(now) > Number(f.deadline_ms) && Number(f.pending_sms) === 0) {
    return await agg.command("expire_swap", { swap_id: f.swap_id, swap_status: "expired" });
  }
  return agg;
}

function applyAssignment(r, shiftId, volunteerId) {
  const s = r.shifts[shiftId];
  if (!s.volunteers.includes(volunteerId)) {
    s.volunteers = [...s.volunteers, volunteerId];
    s.filled = s.volunteers.length;
  }
}

function applySwap(r, f) {
  const off = r.shifts[f.offered_shift];
  const wan = r.shifts[f.wanted_shift];
  off.volunteers = off.volunteers.filter((v) => v !== f.requester_id);
  if (!off.volunteers.includes(f.counterpart_id)) off.volunteers.push(f.counterpart_id);
  wan.volunteers = wan.volunteers.filter((v) => v !== f.counterpart_id);
  if (!wan.volunteers.includes(f.requester_id)) wan.volunteers.push(f.requester_id);
  off.filled = off.volunteers.length;
  wan.filled = wan.volunteers.length;
}

async function recordAndCommit(agg, snap, roster, swapStatus) {
  crash("after-accept-before-record");
  const pending = agg.pendingIntent;
  if (pending) {
    const settled = await agg.recordEffectOutcome(digestOf(snap));
    agg = typeof settled.namedState === "function" ? settled : await agg.machine.show(AGG);
  }
  const next = await agg.command("commit_sms", {
    roster: rosterStr(roster),
    assignment_count: assignmentCount(roster),
    last_shift: snap.shift_id,
    last_volunteer: snap.volunteer_id,
    swap_status: swapStatus,
    notice: "sent",
    pending_sms: 0,
  });
  crash("after-record-before-exit");
  return next;
}

function assignedResult(shift, volunteer, filled, noticeId) {
  return {
    shift_id: shift,
    volunteer_id: volunteer,
    filled,
    notice_id: noticeId,
    notice: "sent",
    status: "assigned",
  };
}

async function recoverSms(agg, f, service, roster) {
  const snap = snapshotFromFacts(f);
  const got = await httpJson("GET", `${service}/v1/notices/${encodeURIComponent(snap.notice_id)}`);
  if (got.fail || got.incomplete) fail("service_unavailable");
  if (got.status === 200) {
    if (!matchingNotice(got.json, snap)) fail("lookup_conflict");
    if (snap.kind === "callout") applyAssignment(roster, snap.shift_id, snap.volunteer_id);
    else applySwap(roster, f);
    const swapStatus = snap.kind === "swap" ? "accepted" : f.swap_status || "none";
    await recordAndCommit(agg, snap, roster, swapStatus);
    return { adopted: true, snap, roster };
  }
  if (got.status === 404) {
    crash("after-notice-saved-before-request");
    const posted = await httpJson("POST", `${service}/v1/notices`, snap);
    if (posted.fail || posted.incomplete || posted.status >= 500) fail("service_unavailable");
    if (posted.status === 409) fail("lookup_conflict");
    if (posted.status !== 200 || !matchingNotice(posted.json, snap)) fail("lookup_conflict");
    if (snap.kind === "callout") applyAssignment(roster, snap.shift_id, snap.volunteer_id);
    else applySwap(roster, f);
    const swapStatus = snap.kind === "swap" ? "accepted" : f.swap_status || "none";
    await recordAndCommit(agg, snap, roster, swapStatus);
    return { adopted: true, snap, roster };
  }
  fail("service_unavailable");
}

async function sendNewSms(agg, snap, service, roster, swapStatus) {
  const payload_digest = digestOf(snap);
  agg = await agg.command("prepare_sms", {
    notice_id: snap.notice_id,
    volunteer_id: snap.volunteer_id,
    shift_id: snap.shift_id,
    kind: snap.kind,
    effect_id: snap.notice_id,
    payload_digest,
    idempotency_key: snap.notice_id,
    notice: "attempt_saved",
    pending_sms: 1,
  });
  crash("after-notice-saved-before-request");
  const posted = await httpJson("POST", `${service}/v1/notices`, snap);
  if (posted.fail || posted.incomplete || posted.status >= 500) fail("service_unavailable");
  if (posted.status === 409) fail("lookup_conflict");
  if (posted.status !== 200 || !matchingNotice(posted.json, snap)) fail("lookup_conflict");
  await recordAndCommit(agg, snap, roster, swapStatus);
}

function volunteerOnPosted(roster, volunteerId) {
  return volunteerShifts(roster, volunteerId).length > 0;
}

export async function main(argv) {
  const cmd = argv[0];
  const stateDir = process.env.STATE_DIR;
  const service = process.env.SERVICE_URL;
  if (!stateDir) fail("bad_args");
  if (service === undefined || service === "") fail("bad_args");
  const now = parseNow(process.env.NOW_MS);
  if (process.env.CRASH_AT && !CRASH_LABELS.has(process.env.CRASH_AT)) fail("bad_args");

  if (!cmd) fail("bad_args");

  try {
    if (cmd === "open") {
      const deskId = argv[1];
      checkId(deskId);
      const store = storePath(stateDir);
      if (existsSync(store)) fail("already_open");
      const { kernel } = await openKernel(stateDir);
      const machine = await kernel.machine(MACHINE_V2);
      await machine.createWith({
        aggregateId: AGG,
        command: {
          name: "open",
          args: {
            desk_id: deskId,
            roster: rosterStr(emptyRoster()),
            notice: "none",
            swap_status: "none",
            pending_sms: 0,
          },
        },
      });
      process.stdout.write(
        JSON.stringify({
          desk_id: deskId,
          status: "open",
          shifts: 0,
          assignments: 0,
          swap: null,
          notice_id: null,
          notice: "none",
        }) + "\n",
      );
      return;
    }

    if (cmd === "status" && !existsSync(storePath(stateDir))) {
      process.stdout.write(
        JSON.stringify({
          desk_id: null,
          status: "none",
          shifts: 0,
          assignments: 0,
          swap: null,
          notice_id: null,
          notice: "none",
          last_shift: null,
          last_volunteer: null,
          buddy_id: null,
        }) + "\n",
      );
      return;
    }

    const { kernel } = await openKernel(stateDir);
    if (!existsSync(storePath(stateDir))) fail("not_open");
    let { machine, agg } = await bindExisting(kernel);
    if (!agg) fail("not_open");
    let f = facts(agg);
    if (!f.desk_id) fail("not_open");
    let roster;
    try {
      roster = parseRoster(f.roster);
    } catch {
      fail("corrupt_state");
    }
    agg = await maybeExpire(agg, now, f);
    f = facts(agg);
    roster = parseRoster(f.roster);

    if (cmd === "status") {
      process.stdout.write(JSON.stringify(statusPayload(f)) + "\n");
      return;
    }

    if (cmd === "post-shift") {
      const shiftId = argv[1];
      checkId(shiftId);
      const starts = parseNonneg(argv[2], "bad_time");
      const ends = parseNonneg(argv[3], "bad_time");
      if (!(BigInt(starts) < BigInt(ends))) fail("bad_time");
      const slots = parseNonneg(argv[4], "bad_slots");
      const n = Number(slots);
      if (n < 1 || n > 8) fail("bad_slots");
      if (roster.shifts[shiftId]) fail("shift_exists");
      roster.shifts[shiftId] = {
        starts_ms: starts,
        ends_ms: ends,
        slots: n,
        filled: 0,
        status: "posted",
        volunteers: [],
      };
      const rosterCmd = Number(f.pending_sms) === 1 ? "replace_roster_pending" : "replace_roster";
      await agg.command(rosterCmd, {
        roster: rosterStr(roster),
        shift_count: postedCount(roster),
        assignment_count: assignmentCount(roster),
      });
      process.stdout.write(
        JSON.stringify({
          shift_id: shiftId,
          starts_ms: Number(starts),
          ends_ms: Number(ends),
          slots: n,
          filled: 0,
          status: "posted",
        }) + "\n",
      );
      return;
    }

    if (cmd === "cancel-shift") {
      const shiftId = argv[1];
      checkId(shiftId);
      const s = roster.shifts[shiftId];
      if (!s || s.status !== "posted") fail("unknown_shift");
      if (s.volunteers.length > 0) fail("shift_occupied");
      s.status = "cancelled";
      const cancelCmd = Number(f.pending_sms) === 1 ? "replace_roster_pending" : "replace_roster";
      await agg.command(cancelCmd, {
        roster: rosterStr(roster),
        shift_count: postedCount(roster),
        assignment_count: assignmentCount(roster),
      });
      process.stdout.write(JSON.stringify({ shift_id: shiftId, status: "cancelled" }) + "\n");
      return;
    }

    if (cmd === "assign") {
      const shiftId = argv[1];
      const volunteerId = argv[2];
      checkId(shiftId);
      checkId(volunteerId);
      const shift = roster.shifts[shiftId];
      if (!shift || shift.status !== "posted") fail("unknown_shift");

      if (Number(f.pending_sms) === 1) {
        const rec = await recoverSms(agg, f, service, roster);
        if (rec.snap.shift_id === shiftId && rec.snap.volunteer_id === volunteerId && rec.snap.kind === "callout") {
          const sh = rec.roster.shifts[shiftId];
          process.stdout.write(
            JSON.stringify(assignedResult(shiftId, volunteerId, sh.filled, rec.snap.notice_id)) + "\n",
          );
          return;
        }
        agg = await machine.show(AGG);
        f = facts(agg);
        roster = parseRoster(f.roster);
      }

      const shift2 = roster.shifts[shiftId];
      if (!shift2 || shift2.status !== "posted") fail("unknown_shift");
      if (shift2.volunteers.includes(volunteerId)) {
        process.stdout.write(
          JSON.stringify(
            assignedResult(shiftId, volunteerId, shift2.filled, f.notice_id || null),
          ) + "\n",
        );
        return;
      }
      if (swapHolds(f) && (volunteerId === f.requester_id || volunteerId === f.counterpart_id)) {
        fail("swap_hold");
      }
      if (shift2.volunteers.length >= shift2.slots) fail("shift_full");
      for (const other of volunteerShifts(roster, volunteerId)) {
        if (other.id !== shiftId && overlaps(other, shift2)) fail("overlap");
      }
      const snap = {
        notice_id: newNoticeId(),
        volunteer_id: volunteerId,
        shift_id: shiftId,
        kind: "callout",
      };
      applyAssignment(roster, shiftId, volunteerId);
      await sendNewSms(agg, snap, service, roster, f.swap_status || "none");
      process.stdout.write(
        JSON.stringify(assignedResult(shiftId, volunteerId, roster.shifts[shiftId].filled, snap.notice_id)) +
          "\n",
      );
      return;
    }

    if (cmd === "offer-swap") {
      const swapId = argv[1];
      const offered = argv[2];
      const wanted = argv[3];
      const requester = argv[4];
      const counterpart = argv[5];
      const deadline = parseNonneg(argv[6]);
      checkId(swapId);
      checkId(offered);
      checkId(wanted);
      checkId(requester);
      checkId(counterpart);
      if (!(BigInt(deadline) > BigInt(now))) fail("bad_args");
      if (Number(f.pending_sms) === 1) fail("service_unavailable");
      if (f.swap_status === "pending" || f.swap_status === "accepted") fail("swap_open");
      const os = roster.shifts[offered];
      const ws = roster.shifts[wanted];
      if (!os || os.status !== "posted" || !ws || ws.status !== "posted") fail("not_assigned");
      if (!os.volunteers.includes(requester) || !ws.volunteers.includes(counterpart)) fail("not_assigned");
      const v2 = Number(machine.identity.version) === 2;
      const era = v2 ? 2 : Number(f.era || 0) + 1;
      await agg.command("offer_swap", {
        swap_id: swapId,
        offered_shift: offered,
        wanted_shift: wanted,
        requester_id: requester,
        counterpart_id: counterpart,
        deadline_ms: Number(deadline),
        era,
        swap_status: "pending",
      });
      process.stdout.write(
        JSON.stringify({
          swap_id: swapId,
          status: "pending",
          offered_shift: offered,
          wanted_shift: wanted,
          requester_id: requester,
          counterpart_id: counterpart,
          deadline_ms: Number(deadline),
          era,
        }) + "\n",
      );
      return;
    }

    if (cmd === "respond-swap") {
      const swapId = argv[1];
      const decision = argv[2];
      checkId(swapId);
      if (decision !== "accept" && decision !== "decline") fail("bad_args");
      if (f.swap_status === "expired" && f.swap_id === swapId) fail("swap_expired");
      if (!f.swap_id || f.swap_id !== swapId) fail("swap_mismatch");
      if (f.swap_status === "accepted" && eraOf(f) === 2) {
        if (decision === "accept") fail("needs_buddy");
        fail("swap_mismatch");
      }
      if (f.swap_status !== "pending") {
        if (f.swap_status === "expired") fail("swap_expired");
        fail("swap_mismatch");
      }
      if (Number(now) > Number(f.deadline_ms)) {
        if (Number(f.pending_sms) === 0) await agg.command("expire_swap", { swap_id: swapId, swap_status: "expired" });
        fail("swap_expired");
      }
      if (decision === "decline") {
        if (Number(f.pending_sms) === 1) fail("service_unavailable");
        await agg.command("decline_swap", { swap_id: swapId, swap_status: "declined" });
        process.stdout.write(JSON.stringify({ swap_id: swapId, status: "declined" }) + "\n");
        return;
      }
      if (eraOf(f) === 2) {
        await agg.command("accept_swap", { swap_id: swapId, swap_status: "accepted" });
        process.stdout.write(JSON.stringify({ swap_id: swapId, status: "accepted", era: 2 }) + "\n");
        return;
      }
      if (Number(f.pending_sms) === 1) {
        const rec = await recoverSms(agg, f, service, roster);
        if (rec.snap.kind === "swap" && rec.snap.notice_id === f.notice_id) {
          process.stdout.write(
            JSON.stringify(
              assignedResult(
                rec.snap.shift_id,
                rec.snap.volunteer_id,
                rec.roster.shifts[rec.snap.shift_id].filled,
                rec.snap.notice_id,
              ),
            ) + "\n",
          );
          return;
        }
      }
      const snap = {
        notice_id: newNoticeId(),
        volunteer_id: f.requester_id,
        shift_id: f.wanted_shift,
        kind: "swap",
      };
      applySwap(roster, f);
      await sendNewSms(agg, snap, service, roster, "accepted");
      process.stdout.write(
        JSON.stringify(
          assignedResult(snap.shift_id, snap.volunteer_id, roster.shifts[snap.shift_id].filled, snap.notice_id),
        ) + "\n",
      );
      return;
    }

    if (cmd === "confirm-swap") {
      const swapId = argv[1];
      const buddyId = argv[2];
      checkId(swapId);
      checkId(buddyId);
      if (eraOf(f) !== 2) fail("legacy_swap");
      if (!f.swap_id || f.swap_id !== swapId) fail("swap_mismatch");
      if (f.swap_status === "expired") fail("swap_expired");
      if (Number(now) > Number(f.deadline_ms) && (f.swap_status === "pending" || f.swap_status === "accepted")) {
        if (Number(f.pending_sms) === 0) await agg.command("expire_swap", { swap_id: swapId, swap_status: "expired" });
        fail("swap_expired");
      }
      if (f.swap_status === "pending") fail("not_accepted");
      if (f.swap_status !== "accepted") fail("swap_mismatch");
      if (buddyOf(f) && buddyOf(f) !== buddyId) fail("buddy_mismatch");
      if (buddyId === f.requester_id || buddyId === f.counterpart_id) fail("not_assigned");
      if (!volunteerOnPosted(roster, buddyId)) fail("not_assigned");
      if (swapCompletedSms(f)) {
        process.stdout.write(
          JSON.stringify({
            swap_id: swapId,
            status: "accepted",
            era: 2,
            buddy_id: buddyId,
            notice_id: f.notice_id,
            notice: "sent",
          }) + "\n",
        );
        return;
      }
      if (buddyOf(f) && buddyOf(f) !== buddyId) fail("buddy_mismatch");
      if (Number(f.pending_sms) === 1) {
        const rec = await recoverSms(agg, f, service, roster);
        process.stdout.write(
          JSON.stringify({
            swap_id: swapId,
            status: "accepted",
            era: 2,
            buddy_id: buddyId,
            notice_id: rec.snap.notice_id,
            notice: "sent",
          }) + "\n",
        );
        return;
      }
      if (!buddyOf(f)) {
        agg = await agg.command("set_buddy", { swap_id: swapId, buddy_id: buddyId });
        f = facts(agg);
      }
      const snap = {
        notice_id: newNoticeId(),
        volunteer_id: f.requester_id,
        shift_id: f.wanted_shift,
        kind: "swap",
      };
      applySwap(roster, f);
      await sendNewSms(agg, snap, service, roster, "accepted");
      process.stdout.write(
        JSON.stringify({
          swap_id: swapId,
          status: "accepted",
          era: 2,
          buddy_id: buddyId,
          notice_id: snap.notice_id,
          notice: "sent",
        }) + "\n",
      );
      return;
    }

    if (cmd === "reconcile") {
      const noticeId = argv[1];
      checkId(noticeId);
      if (!f.notice_id || f.notice === "none") fail("no_notice");
      if (f.notice_id !== noticeId) fail("notice_mismatch");
      if (f.notice === "sent") {
        process.stdout.write(
          JSON.stringify({
            ...assignedResult(f.notice_shift, f.notice_volunteer, roster.shifts[f.notice_shift]?.filled ?? 0, noticeId),
            lookup: "sent",
          }) + "\n",
        );
        return;
      }
      const snap = snapshotFromFacts(f);
      const got = await httpJson("GET", `${service}/v1/notices/${encodeURIComponent(noticeId)}`);
      if (got.fail || got.incomplete) fail("service_unavailable");
      if (got.status === 404) {
        process.stdout.write(
          JSON.stringify({ lookup: "not_sent", notice_id: noticeId, notice: "attempt_saved" }) + "\n",
        );
        return;
      }
      if (got.status === 200) {
        if (!matchingNotice(got.json, snap)) fail("lookup_conflict");
        if (snap.kind === "callout") applyAssignment(roster, snap.shift_id, snap.volunteer_id);
        else applySwap(roster, f);
        const swapStatus = snap.kind === "swap" ? "accepted" : f.swap_status || "none";
        await recordAndCommit(agg, snap, roster, swapStatus);
        process.stdout.write(
          JSON.stringify({
            ...assignedResult(snap.shift_id, snap.volunteer_id, roster.shifts[snap.shift_id].filled, noticeId),
            lookup: "sent",
          }) + "\n",
        );
        return;
      }
      fail("service_unavailable");
    }

    if (cmd === "callback") {
      const path = argv[1];
      if (!path) fail("bad_args");
      let raw;
      try {
        raw = await readFile(path, "utf8");
      } catch {
        fail("bad_callback");
      }
      let body;
      try {
        body = JSON.parse(raw);
      } catch {
        fail("bad_callback");
      }
      if (!body || typeof body !== "object" || Array.isArray(body)) fail("bad_callback");
      const terminalNotice = f.notice === "sent";
      const terminalSwap = f.swap_status === "declined" || f.swap_status === "expired";
      if (terminalNotice || terminalSwap) {
        process.stdout.write(JSON.stringify({ callback: "ignored" }) + "\n");
        return;
      }
      process.stdout.write(JSON.stringify({ callback: "ignored" }) + "\n");
      return;
    }

    fail("bad_args");
  } catch (e) {
    if (e && e.message && String(e.message).includes("corrupt")) fail("corrupt_state");
    fail(mapKernelError(e));
  }
}

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMain) {
  await main(process.argv.slice(2));
}
