import { spawn, spawnSync } from "node:child_process";
import { once } from "node:events";
import { mkdtemp, mkdir, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import assert from "node:assert/strict";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const NODE = process.execPath;
const RUN = join(ROOT, "run");
const STUB = join(ROOT, "stub", "server.mjs");

function startStub() {
  const child = spawn(NODE, [STUB], { stdio: ["ignore", "pipe", "pipe"] });
  return new Promise((resolve, reject) => {
    let buf = "";
    child.stdout.on("data", (c) => {
      buf += c;
      const nl = buf.indexOf("\n");
      if (nl >= 0) {
        try {
          resolve({ child, ...JSON.parse(buf.slice(0, nl)) });
        } catch (e) {
          reject(e);
        }
      }
    });
    child.on("error", reject);
  });
}

async function fault(control, body) {
  const r = await fetch(`${control}/fault`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  return r.json();
}

async function effects(control) {
  const r = await fetch(`${control}/effects`);
  return r.json();
}

function invoke(state, service, now, args, extra = {}) {
  const r = spawnSync(NODE, [RUN, ...args], {
    encoding: "utf8",
    env: {
      ...process.env,
      STATE_DIR: state,
      SERVICE_URL: service,
      NOW_MS: String(now),
      ...extra,
    },
  });
  let json = null;
  try {
    json = JSON.parse((r.stdout || "").trim());
  } catch {
    json = null;
  }
  return { status: r.status, signal: r.signal, stdout: r.stdout, stderr: r.stderr, json };
}

test("open, post, assign, restart, no-op, unrelated bytes", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = await mkdtemp(join(tmpdir(), "desk-"));
    const marker = join(state, "unrelated.txt");
    await writeFile(marker, "keep-me-bytes");
    let r = invoke(state, service_url, 1000, ["status"]);
    assert.equal(r.status, 0);
    assert.equal(r.json.status, "none");
    r = invoke(state, service_url, 1000, ["open", "desk1"]);
    assert.equal(r.status, 0);
    assert.equal(r.json.status, "open");
    r = invoke(state, service_url, 1000, ["open", "desk1"]);
    assert.notEqual(r.status, 0);
    assert.equal(r.json.error, "already_open");
    r = invoke(state, service_url, 1000, ["post-shift", "s1", "10", "20", "2"]);
    assert.equal(r.status, 0);
    r = invoke(state, service_url, 1000, ["assign", "s1", "v1"]);
    assert.equal(r.status, 0, r.stdout + r.stderr);
    assert.equal(r.json.notice, "sent");
    assert.equal(r.json.filled, 1);
    const notice = r.json.notice_id;
    r = invoke(state, service_url, 1000, ["assign", "s1", "v1"]);
    assert.equal(r.status, 0);
    assert.equal(r.json.status, "assigned");
    r = invoke(state, service_url, 1000, ["status"]);
    assert.equal(r.json.assignments, 1);
    assert.equal(r.json.notice_id, notice);
    const fx = await effects(control_url);
    assert.equal(fx.count, 1);
    assert.equal(await readFile(marker, "utf8"), "keep-me-bytes");
  } finally {
    child.kill("SIGKILL");
  }
});

test("refusals: full, overlap, unknown, occupied cancel, swap deadline", async () => {
  const { child, service_url } = await startStub();
  try {
    const state = await mkdtemp(join(tmpdir(), "desk-"));
    invoke(state, service_url, 1000, ["open", "d"]);
    invoke(state, service_url, 1000, ["post-shift", "a", "0", "10", "1"]);
    invoke(state, service_url, 1000, ["post-shift", "b", "5", "15", "1"]);
    invoke(state, service_url, 1000, ["post-shift", "c", "100", "200", "1"]);
    let r = invoke(state, service_url, 1000, ["assign", "a", "v1"]);
    assert.equal(r.status, 0, r.stdout);
    r = invoke(state, service_url, 1000, ["assign", "a", "v2"]);
    assert.equal(r.json.error, "shift_full");
    r = invoke(state, service_url, 1000, ["assign", "b", "v1"]);
    assert.equal(r.json.error, "overlap");
    r = invoke(state, service_url, 1000, ["assign", "missing", "v9"]);
    assert.equal(r.json.error, "unknown_shift");
    r = invoke(state, service_url, 1000, ["cancel-shift", "a"]);
    assert.equal(r.json.error, "shift_occupied");
    r = invoke(state, service_url, 1000, ["assign", "c", "v2"]);
    assert.equal(r.status, 0);
    r = invoke(state, service_url, 1000, [
      "offer-swap",
      "sw1",
      "a",
      "c",
      "v1",
      "v2",
      "1500",
    ]);
    assert.equal(r.status, 0, r.stdout);
    r = invoke(state, service_url, 1000, ["offer-swap", "sw2", "a", "c", "v1", "v2", "1900"]);
    assert.equal(r.json.error, "swap_open");
    r = invoke(state, service_url, 2000, ["respond-swap", "sw1", "accept"]);
    assert.equal(r.json.error, "swap_expired");
    r = invoke(state, service_url, 2000, ["status"]);
    assert.equal(r.json.swap.status, "expired");
    r = invoke(state, service_url, 2000, ["cancel-shift", "c"]);
    assert.equal(r.json.error, "shift_occupied");
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash after-notice-saved-before-request then recover same id", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = await mkdtemp(join(tmpdir(), "desk-"));
    invoke(state, service_url, 1, ["open", "d"]);
    invoke(state, service_url, 1, ["post-shift", "s1", "1", "2", "2"]);
    let r = invoke(state, service_url, 1, ["assign", "s1", "v1"], {
      CRASH_AT: "after-notice-saved-before-request",
    });
    assert.equal(r.status, null);
    assert.equal(r.signal, "SIGKILL");
    let fx = await effects(control_url);
    assert.equal(fx.count, 0);
    r = invoke(state, service_url, 1, ["status"]);
    assert.equal(r.json.notice, "attempt_saved");
    const nid = r.json.notice_id;
    r = invoke(state, service_url, 1, ["assign", "s1", "v1"]);
    assert.equal(r.status, 0, r.stdout + r.stderr);
    assert.equal(r.json.notice, "sent");
    assert.equal(r.json.notice_id, nid);
    fx = await effects(control_url);
    assert.equal(fx.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash after-accept-before-record then lookup adopt", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = await mkdtemp(join(tmpdir(), "desk-"));
    invoke(state, service_url, 1, ["open", "d"]);
    invoke(state, service_url, 1, ["post-shift", "s1", "1", "2", "2"]);
    let r = invoke(state, service_url, 1, ["assign", "s1", "v1"], {
      CRASH_AT: "after-accept-before-record",
    });
    assert.equal(r.signal, "SIGKILL");
    const fx = await effects(control_url);
    assert.equal(fx.count, 1);
    r = invoke(state, service_url, 1, ["status"]);
    assert.equal(r.json.notice, "attempt_saved");
    r = invoke(state, service_url, 1, ["assign", "s1", "v1"]);
    assert.equal(r.status, 0, r.stdout);
    assert.equal(r.json.notice, "sent");
    const fx2 = await effects(control_url);
    assert.equal(fx2.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash after-record-before-exit then no-op", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = await mkdtemp(join(tmpdir(), "desk-"));
    invoke(state, service_url, 1, ["open", "d"]);
    invoke(state, service_url, 1, ["post-shift", "s1", "1", "2", "2"]);
    let r = invoke(state, service_url, 1, ["assign", "s1", "v1"], {
      CRASH_AT: "after-record-before-exit",
    });
    assert.equal(r.signal, "SIGKILL");
    r = invoke(state, service_url, 1, ["status"]);
    assert.equal(r.json.notice, "sent");
    r = invoke(state, service_url, 1, ["assign", "s1", "v1"]);
    assert.equal(r.status, 0);
    const fx = await effects(control_url);
    assert.equal(fx.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("dropped reply then reconcile adopts sent", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = await mkdtemp(join(tmpdir(), "desk-"));
    invoke(state, service_url, 1, ["open", "d"]);
    invoke(state, service_url, 1, ["post-shift", "s1", "1", "2", "2"]);
    await fault(control_url, { drop_reply: true });
    let r = invoke(state, service_url, 1, ["assign", "s1", "v1"]);
    assert.notEqual(r.status, 0);
    assert.equal(r.json.error, "service_unavailable");
    await fault(control_url, {});
    r = invoke(state, service_url, 1, ["status"]);
    const nid = r.json.notice_id;
    assert.equal(r.json.notice, "attempt_saved");
    r = invoke(state, service_url, 1, ["reconcile", nid]);
    assert.equal(r.status, 0, r.stdout);
    assert.equal(r.json.lookup, "sent");
    assert.equal(r.json.notice, "sent");
    const fx = await effects(control_url);
    assert.equal(fx.count, 1);
    r = invoke(state, service_url, 1, ["reconcile", "other-id"]);
    assert.equal(r.json.error, "notice_mismatch");
  } finally {
    child.kill("SIGKILL");
  }
});

test("reconcile not_sent when provider never accepted", async () => {
  const { child, service_url } = await startStub();
  try {
    const state = await mkdtemp(join(tmpdir(), "desk-"));
    invoke(state, service_url, 1, ["open", "d"]);
    invoke(state, service_url, 1, ["post-shift", "s1", "1", "2", "2"]);
    invoke(state, service_url, 1, ["assign", "s1", "v1"], {
      CRASH_AT: "after-notice-saved-before-request",
    });
    const st = invoke(state, service_url, 1, ["status"]);
    const r = invoke(state, service_url, 1, ["reconcile", st.json.notice_id]);
    assert.equal(r.status, 0);
    assert.equal(r.json.lookup, "not_sent");
    assert.equal(r.json.notice, "attempt_saved");
  } finally {
    child.kill("SIGKILL");
  }
});

test("era2 confirm-swap buddy and swap_hold", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = await mkdtemp(join(tmpdir(), "desk-"));
    invoke(state, service_url, 1, ["open", "d"]);
    invoke(state, service_url, 1, ["post-shift", "a", "0", "10", "2"]);
    invoke(state, service_url, 1, ["post-shift", "b", "20", "30", "2"]);
    invoke(state, service_url, 1, ["post-shift", "c", "40", "50", "1"]);
    invoke(state, service_url, 1, ["assign", "a", "v1"]);
    invoke(state, service_url, 1, ["assign", "b", "v2"]);
    invoke(state, service_url, 1, ["assign", "a", "v3"]);
    let r = invoke(state, service_url, 1, ["offer-swap", "sw", "a", "b", "v1", "v2", "100"]);
    assert.equal(r.status, 0, r.stdout);
    assert.equal(r.json.era, 2);
    r = invoke(state, service_url, 1, ["confirm-swap", "sw", "v3"]);
    assert.equal(r.json.error, "not_accepted");
    r = invoke(state, service_url, 1, ["assign", "c", "v1"]);
    assert.equal(r.json.error, "swap_hold");
    r = invoke(state, service_url, 1, ["respond-swap", "sw", "accept"]);
    assert.equal(r.status, 0, r.stdout);
    assert.equal(r.json.status, "accepted");
    assert.equal(r.json.era, 2);
    let fx = await effects(control_url);
    const before = fx.count;
    r = invoke(state, service_url, 1, ["confirm-swap", "other", "v3"]);
    assert.equal(r.json.error, "swap_mismatch");
    r = invoke(state, service_url, 1, ["confirm-swap", "sw", "v3"]);
    assert.equal(r.status, 0, r.stdout + r.stderr);
    assert.equal(r.json.buddy_id, "v3");
    assert.equal(r.json.notice, "sent");
    fx = await effects(control_url);
    assert.equal(fx.count, before + 1);
    r = invoke(state, service_url, 1, ["confirm-swap", "sw", "v3"]);
    assert.equal(r.status, 0);
    fx = await effects(control_url);
    assert.equal(fx.count, before + 1);
    r = invoke(state, service_url, 1, ["confirm-swap", "sw", "v9"]);
    assert.equal(r.json.error, "buddy_mismatch");
    r = invoke(state, service_url, 1, ["status"]);
    assert.equal(r.json.buddy_id, "v3");
    assert.equal(r.json.swap.status, "accepted");
  } finally {
    child.kill("SIGKILL");
  }
});

test("v1 pending store continues without swap_hold", async () => {
  const { child, service_url } = await startStub();
  try {
    const priorRun = join("/tmp/desk-prior-N12r2", "run");
    const state = await mkdtemp(join(tmpdir(), "desk-old-"));
    const env = {
      STATE_DIR: state,
      SERVICE_URL: service_url,
      NOW_MS: "1",
    };
    function oldInvoke(args) {
      return spawnSync(NODE, [priorRun, ...args], { encoding: "utf8", env: { ...process.env, ...env } });
    }
    oldInvoke(["open", "d"]);
    oldInvoke(["post-shift", "a", "0", "10", "2"]);
    oldInvoke(["post-shift", "b", "20", "30", "1"]);
    oldInvoke(["post-shift", "c", "40", "50", "1"]);
    oldInvoke(["assign", "a", "v1"]);
    oldInvoke(["assign", "b", "v2"]);
    let o = oldInvoke(["offer-swap", "sw", "a", "b", "v1", "v2", "500"]);
    const oj = JSON.parse(o.stdout.trim());
    assert.equal(oj.era, 1);
    let r = invoke(state, service_url, 1, ["status"]);
    assert.equal(r.status, 0, r.stdout + r.stderr);
    assert.equal(r.json.swap.era, 1);
    r = invoke(state, service_url, 1, ["confirm-swap", "sw", "v1"]);
    assert.equal(r.json.error, "legacy_swap");
    r = invoke(state, service_url, 1, ["assign", "c", "v2"]);
    assert.equal(r.status, 0, r.stdout + r.stderr);
    r = invoke(state, service_url, 1, ["respond-swap", "sw", "accept"]);
    assert.equal(r.status, 0, r.stdout + r.stderr);
    assert.equal(r.json.notice, "sent");
  } finally {
    child.kill("SIGKILL");
  }
});
