# Volunteer shift roster desk

Durable local desk for one volunteer roster. Lifecycle (open, SMS notice, swap terminal flags) is stored in Ikaros; HTTP call-outs go to the stub SMS gateway.

## Setup

Use Node 22 (`<home>/.nvm/versions/node/v22.17.1/bin/node`). From this directory:

```bash
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x ./run
```

Start the fake gateway (prints `service_url`):

```bash
node stub/server.mjs
```

## Run

Every command needs `STATE_DIR`, `SERVICE_URL`, and `NOW_MS` (epoch milliseconds). Optional `CRASH_AT` for recovery drills.

```bash
export STATE_DIR=/tmp/desk-state
export SERVICE_URL=http://127.0.0.1:<port>
export NOW_MS=1000
./run open desk1
./run post-shift s1 1000 5000 2
./run assign s1 volunteer_a
./run status
```

Commands: `open`, `post-shift`, `assign`, `offer-swap`, `respond-swap`, `reconcile`, `cancel-shift`, `status`, `callback`.

## Tests

```bash
node --test tests/desk.test.mjs
```
