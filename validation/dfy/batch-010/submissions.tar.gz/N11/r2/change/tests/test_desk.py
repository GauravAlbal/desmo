# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import tempfile
import time
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NODE = os.environ.get("NODE", "<home>/.nvm/versions/node/v22.17.1/bin/node")
RUN = str(ROOT / "run")


def start_stub():
    proc = subprocess.Popen(
        [NODE, str(ROOT / "stub" / "server.mjs")],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    line = proc.stdout.readline()
    info = json.loads(line)
    return proc, info["service_url"], info["control_url"]


def http_json(method, url, body=None):
    data = None
    headers = {}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode("utf-8"))


class DeskTest(unittest.TestCase):
    def setUp(self):
        self.stub, self.service, self.control = start_stub()
        self.state = tempfile.mkdtemp(prefix="claim-desk-")
        Path(self.state, "unrelated.txt").write_bytes(b"keep-me-bytes")
        self._unrelated = b"keep-me-bytes"

    def tearDown(self):
        self.stub.send_signal(signal.SIGTERM)
        try:
            self.stub.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.stub.kill()
        shutil.rmtree(self.state, ignore_errors=True)

    def run_cmd(self, args, now="1000", crash=None, check=False):
        env = os.environ.copy()
        env["STATE_DIR"] = self.state
        env["SERVICE_URL"] = self.service
        env["NOW_MS"] = str(now)
        if crash:
            env["CRASH_AT"] = crash
        elif "CRASH_AT" in env:
            del env["CRASH_AT"]
        proc = subprocess.run(
            [RUN] + args,
            cwd=str(ROOT),
            env=env,
            capture_output=True,
            text=True,
        )
        if check and proc.returncode != 0:
            raise AssertionError(proc.stdout + proc.stderr)
        lines = [ln for ln in proc.stdout.splitlines() if ln.strip()]
        body = json.loads(lines[-1]) if lines else None
        self.assertEqual(Path(self.state, "unrelated.txt").read_bytes(), self._unrelated)
        return proc.returncode, body

    def file_happy(self):
        code, body = self.run_cmd(["file", "c1", "p1", "1000", "5000"], now="100")
        self.assertEqual(code, 0)
        self.assertEqual(body["status"], "filed")
        self.assertEqual(body["filed_ms"], 100)
        return body

    def assess_approve(self, amount="400"):
        self.file_happy()
        code, body = self.run_cmd(["assess", amount])
        self.assertEqual(code, 0)
        self.assertEqual(body["status"], "assessed")
        code, body = self.run_cmd(["approve"])
        self.assertEqual(code, 0)
        self.assertEqual(body["amount_cents"], min(1000, int(amount)))
        return body

    def test_status_empty(self):
        code, body = self.run_cmd(["status"])
        self.assertEqual(code, 0)
        self.assertEqual(body["status"], "none")
        self.assertEqual(body["payment"], "none")
        self.assertIsNone(body["claim_id"])
        self.assertEqual(body["appeal_used"], 0)
        self.assertEqual(body["salvage_cents"], 0)
        self.assertIsNone(body["denied_ms"])

    def test_missing_env(self):
        env = os.environ.copy()
        env["STATE_DIR"] = self.state
        env["SERVICE_URL"] = self.service
        proc = subprocess.run([RUN, "status"], cwd=str(ROOT), env=env, capture_output=True, text=True)
        self.assertNotEqual(proc.returncode, 0)
        self.assertEqual(json.loads(proc.stdout)["error"], "bad_time")

    def test_file_and_restart(self):
        self.file_happy()
        code, body = self.run_cmd(["status"])
        self.assertEqual(code, 0)
        self.assertEqual(body["claim_id"], "c1")
        self.assertEqual(body["status"], "filed")
        code, body = self.run_cmd(["file", "c2", "p2", "10", "1"])
        self.assertNotEqual(code, 0)
        self.assertEqual(body["error"], "already_open")

    def test_bad_args_amount_id(self):
        code, body = self.run_cmd(["file", "bad id", "p1", "10", "1"])
        self.assertEqual(body["error"], "bad_args")
        code, body = self.run_cmd(["file", "c1", "p1", "01", "1"])
        self.assertEqual(body["error"], "bad_amount")
        code, body = self.run_cmd(["file", "c1", "p1", "0", "1"])
        self.assertEqual(body["error"], "bad_amount")

    def test_assess_approve_payout_healthy(self):
        self.assess_approve("400")
        code, body = self.run_cmd(["payout"])
        self.assertEqual(code, 0, body)
        self.assertEqual(body["status"], "paid")
        self.assertEqual(body["amount_cents"], 400)
        effects = http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], 1)
        code, body2 = self.run_cmd(["payout"])
        self.assertEqual(code, 0)
        self.assertEqual(body2["status"], "paid")
        effects = http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], 1)

    def test_refusals_no_provider(self):
        code, body = self.run_cmd(["assess", "10"])
        self.assertEqual(body["error"], "bad_status")
        self.file_happy()
        code, body = self.run_cmd(["approve"])
        self.assertEqual(body["error"], "bad_status")
        code, body = self.run_cmd(["payout"])
        self.assertEqual(body["error"], "bad_status")
        posts = http_json("GET", self.control + "/posts")
        self.assertEqual(posts["count"], 0)

    def test_deny_appeal(self):
        self.file_happy()
        self.run_cmd(["assess", "400"])
        code, body = self.run_cmd(["deny"], now="1000")
        self.assertEqual(code, 0)
        self.assertEqual(body["status"], "denied")
        code, st = self.run_cmd(["status"])
        self.assertEqual(st["denied_ms"], 1000)
        # deny-clock deadline is 1000+5000=6000 (filed window would have closed at 5100)
        code, body = self.run_cmd(["appeal"], now="5101")
        self.assertEqual(code, 0, body)
        self.assertEqual(body["status"], "assessed")
        self.assertEqual(body["appeal_used"], 1)
        code, body = self.run_cmd(["appeal"], now="200")
        self.assertEqual(body["error"], "appeal_used")
        self.run_cmd(["approve"])
        self.run_cmd(["payout"])
        code, body = self.run_cmd(["appeal"])
        self.assertEqual(body["error"], "bad_status")
        code, body = self.run_cmd(["deny"])
        self.assertEqual(body["error"], "bad_status")
        code, body = self.run_cmd(["assess", "1"])
        self.assertEqual(body["error"], "bad_status")

    def test_callback_ignored(self):
        self.assess_approve()
        cb = Path(self.state, "cb.json")
        cb.write_text('{"payout_id":"x","claim_id":"c1","amount_cents":1}', encoding="utf-8")
        code, body = self.run_cmd(["callback", str(cb)])
        self.assertEqual(code, 0)
        self.assertTrue(body["ignored"])
        code, st = self.run_cmd(["status"])
        self.assertEqual(st["status"], "approved")
        self.assertEqual(st["payment"], "none")
        cb.write_text("not-json", encoding="utf-8")
        code, body = self.run_cmd(["callback", str(cb)])
        self.assertEqual(body["error"], "bad_callback")
        posts = http_json("GET", self.control + "/posts")
        self.assertEqual(posts["count"], 0)

    def test_crash_before_request(self):
        self.assess_approve("400")
        proc_code, body = self.run_cmd(["payout"], crash="after-payout-saved-before-request")
        self.assertNotEqual(proc_code, 0)
        code, st = self.run_cmd(["status"])
        self.assertEqual(st["status"], "approved")
        self.assertEqual(st["payment"], "attempt_saved")
        self.assertIsNotNone(st["payout_id"])
        effects = http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], 0)
        saved = st["payout_id"]
        code, body = self.run_cmd(["payout"])
        self.assertEqual(code, 0, body)
        self.assertEqual(body["payout_id"], saved)
        self.assertEqual(body["status"], "paid")
        effects = http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], 1)

    def test_crash_after_accept_before_record(self):
        self.assess_approve("400")
        self.run_cmd(["payout"], crash="after-accept-before-record")
        code, st = self.run_cmd(["status"])
        self.assertEqual(st["payment"], "attempt_saved")
        effects = http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], 1)
        code, body = self.run_cmd(["payout"])
        self.assertEqual(code, 0, body)
        self.assertEqual(body["status"], "paid")
        effects = http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], 1)

    def test_crash_after_record(self):
        self.assess_approve("400")
        self.run_cmd(["payout"], crash="after-record-before-exit")
        code, st = self.run_cmd(["status"])
        self.assertEqual(st["status"], "paid")
        self.assertEqual(st["payment"], "paid")
        code, body = self.run_cmd(["payout"])
        self.assertEqual(code, 0)
        self.assertEqual(body["status"], "paid")
        effects = http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], 1)

    def test_dropped_reply_then_reconcile(self):
        self.assess_approve("400")
        http_json("POST", self.control + "/fault", {"drop_reply": True})
        code, body = self.run_cmd(["payout"])
        self.assertEqual(body["error"], "service_unavailable")
        code, st = self.run_cmd(["status"])
        self.assertEqual(st["payment"], "attempt_saved")
        effects = http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], 1)
        http_json("POST", self.control + "/fault", {})
        code, body = self.run_cmd(["reconcile", st["payout_id"]])
        self.assertEqual(code, 0, body)
        self.assertEqual(body["lookup"], "paid")
        self.assertEqual(body["status"], "paid")
        posts = http_json("GET", self.control + "/posts")
        # first payout POSTed once; reconcile must not POST
        self.assertEqual(posts["count"], 1)

    def test_reconcile_not_sent_and_mismatch(self):
        self.assess_approve("400")
        self.run_cmd(["payout"], crash="after-payout-saved-before-request")
        code, st = self.run_cmd(["status"])
        pid = st["payout_id"]
        code, body = self.run_cmd(["reconcile", pid])
        self.assertEqual(code, 0)
        self.assertEqual(body["lookup"], "not_sent")
        self.assertEqual(body["payment"], "attempt_saved")
        code, body = self.run_cmd(["reconcile", "other-id"])
        self.assertEqual(body["error"], "payout_mismatch")
        code, st2 = self.run_cmd(["status"])
        self.assertEqual(st2["payout_id"], pid)
        code, body = self.run_cmd(["reconcile", pid])
        self.assertEqual(body["lookup"], "not_sent")

    def test_reconcile_crash_after_record(self):
        self.assess_approve("400")
        http_json("POST", self.control + "/fault", {"drop_reply": True})
        self.run_cmd(["payout"])
        http_json("POST", self.control + "/fault", {})
        code, st = self.run_cmd(["status"])
        self.run_cmd(["reconcile", st["payout_id"]], crash="after-record-before-exit")
        code, st2 = self.run_cmd(["status"])
        self.assertEqual(st2["status"], "paid")
        self.assertEqual(st2["payment"], "paid")

    def test_five_xx_leaves_attempt(self):
        self.assess_approve("400")
        http_json("POST", self.control + "/fault", {"error_status": 503})
        code, body = self.run_cmd(["payout"])
        self.assertEqual(body["error"], "service_unavailable")
        code, st = self.run_cmd(["status"])
        self.assertEqual(st["payment"], "attempt_saved")
        effects = http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], 0)

    def test_min_limit(self):
        self.file_happy()
        self.run_cmd(["assess", "5000"])
        code, body = self.run_cmd(["approve"])
        self.assertEqual(body["amount_cents"], 1000)

    def test_deny_clock_closed(self):
        self.file_happy()
        self.run_cmd(["assess", "400"])
        self.run_cmd(["deny"], now="1000")
        code, body = self.run_cmd(["appeal"], now="6001")
        self.assertEqual(body["error"], "appeal_closed")
        code, st = self.run_cmd(["status"])
        self.assertEqual(st["status"], "denied")
        code, body = self.run_cmd(["appeal"], now="6000")
        self.assertEqual(code, 0, body)
        self.assertEqual(body["status"], "assessed")

    def test_salvage_and_payout(self):
        self.file_happy()
        self.run_cmd(["assess", "400"])
        code, body = self.run_cmd(["salvage", "50"])
        self.assertEqual(code, 0, body)
        self.assertEqual(body["salvage_cents"], 50)
        self.assertEqual(body["status"], "assessed")
        code, body = self.run_cmd(["salvage", "50"])
        self.assertEqual(code, 0)
        self.assertEqual(body["salvage_cents"], 50)
        code, body = self.run_cmd(["salvage", "51"])
        self.assertEqual(body["error"], "salvage_locked")
        code, body = self.run_cmd(["approve"])
        self.assertEqual(body["amount_cents"], 400)
        code, body = self.run_cmd(["payout"])
        self.assertEqual(code, 0, body)
        self.assertEqual(body["amount_cents"], 350)
        self.assertEqual(body["status"], "paid")
        effects = http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], 1)
        code, st = self.run_cmd(["status"])
        self.assertEqual(st["salvage_cents"], 50)
        self.assertEqual(st["amount_cents"], 350)
        code, body = self.run_cmd(["salvage", "1"])
        self.assertEqual(body["error"], "salvage_closed")
        code, body = self.run_cmd(["payout"])
        self.assertEqual(code, 0)
        effects = http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], 1)

    def test_salvage_refusals(self):
        code, body = self.run_cmd(["salvage", "1"])
        self.assertEqual(body["error"], "bad_status")
        self.file_happy()
        code, body = self.run_cmd(["salvage", "1"])
        self.assertEqual(body["error"], "salvage_closed")
        self.run_cmd(["assess", "400"])
        code, body = self.run_cmd(["salvage", "400"])
        self.assertEqual(body["error"], "bad_amount")
        code, body = self.run_cmd(["salvage", "01"])
        self.assertEqual(body["error"], "bad_amount")
        self.run_cmd(["deny"])
        code, body = self.run_cmd(["salvage", "1"])
        self.assertEqual(body["error"], "salvage_closed")

    def test_salvage_inflight_closed(self):
        self.assess_approve("400")
        self.run_cmd(["payout"], crash="after-payout-saved-before-request")
        code, body = self.run_cmd(["salvage", "1"])
        self.assertEqual(body["error"], "salvage_closed")
        code, st = self.run_cmd(["status"])
        self.assertEqual(st["payment"], "attempt_saved")
        code, body = self.run_cmd(["payout"])
        self.assertEqual(code, 0, body)
        self.assertEqual(body["amount_cents"], 400)


if __name__ == "__main__":
    unittest.main()
