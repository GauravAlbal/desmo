# Insurance claim adjudication desk

Durable one-claim desk. Lifecycle authority is the Ikaros store under `STATE_DIR`.
Payout talks to the fake HTTP service from `stub/`.

## Setup

Node 22 is not required for `./run`; it is used only to start `stub/server.mjs`.

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
```

`IK_BINARY` defaults to `KIT/bin/ik` via `./run`.

## Run

Required environment on every command:

- `STATE_DIR` — existing directory for this claim
- `SERVICE_URL` — payout service URL (status never calls it)
- `NOW_MS` — non-negative canonical integer epoch milliseconds

Optional: `CRASH_AT` with `after-payout-saved-before-request`,
`after-accept-before-record`, or `after-record-before-exit`.

```sh
export STATE_DIR=/tmp/claim-1
export SERVICE_URL=http://127.0.0.1:PORT
export NOW_MS=1000
mkdir -p "$STATE_DIR"
./run file c1 p1 1000 5000
./run assess 400
./run approve
./run payout
./run status
```

Start the fake provider (prints JSON with `service_url`):

```sh
<home>/.nvm/versions/node/v22.17.1/bin/node stub/server.mjs
```

## Tests

```sh
.venv/bin/python -m unittest tests.test_desk
```
