# -*- coding: utf-8 -*-
from __future__ import annotations

import hashlib
import json
import os
import re
import signal
import sys
import urllib.error
import urllib.request
from typing import Any, Dict, Optional, Tuple

from invariant_kernel import (
    Aggregate,
    HistoricalResult,
    Kernel,
    KernelError,
    StoreNotFoundError,
    classify,
)

AGGREGATE_ID = "claim"
STORE_NAME = "claim.sqlite"
EXT_NAME = "claim.ext.json"
ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
POS_INT_RE = re.compile(r"^[1-9][0-9]*$")
NONNEG_INT_RE = re.compile(r"^(0|[1-9][0-9]*)$")
I64_MAX = 2 ** 63 - 1
CRASH_LABELS = (
    "after-payout-saved-before-request",
    "after-accept-before-record",
    "after-record-before-exit",
)


class AppError(Exception):
    def __init__(self, code):
        # type: (str) -> None
        self.code = code


def _json_out(obj, code=0):
    # type: (Dict[str, Any], int) -> int
    sys.stdout.write(json.dumps(obj, separators=(",", ":")) + "\n")
    sys.stdout.flush()
    return code


def _crash_if(label):
    # type: (str) -> None
    if os.environ.get("CRASH_AT") == label:
        sys.stdout.flush()
        sys.stderr.flush()
        os.kill(os.getpid(), signal.SIGKILL)


def _env_required():
    # type: () -> Tuple[str, str, int]
    state_dir = os.environ.get("STATE_DIR")
    service = os.environ.get("SERVICE_URL")
    now_raw = os.environ.get("NOW_MS")
    if not state_dir or not os.path.isdir(state_dir):
        raise AppError("bad_args")
    if service is None or service == "":
        raise AppError("bad_args")
    if now_raw is None or now_raw == "":
        raise AppError("bad_time")
    if not NONNEG_INT_RE.match(now_raw):
        raise AppError("bad_time")
    now_ms = int(now_raw)
    if now_ms > I64_MAX:
        raise AppError("bad_time")
    crash = os.environ.get("CRASH_AT")
    if crash is not None and crash != "" and crash not in CRASH_LABELS:
        raise AppError("bad_args")
    return state_dir, service, now_ms


def _ident(value):
    # type: (str) -> str
    if not isinstance(value, str) or not ID_RE.match(value):
        raise AppError("bad_args")
    return value


def _pos_int(raw):
    # type: (str) -> int
    if not isinstance(raw, str) or not POS_INT_RE.match(raw):
        raise AppError("bad_amount")
    n = int(raw)
    if n > I64_MAX:
        raise AppError("bad_amount")
    return n


def _nonneg_int(raw):
    # type: (str) -> int
    if not isinstance(raw, str) or not NONNEG_INT_RE.match(raw):
        raise AppError("bad_amount")
    n = int(raw)
    if n > I64_MAX:
        raise AppError("bad_amount")
    return n


def _project_root():
    # type: () -> str
    return os.path.dirname(os.path.abspath(__file__))


def _machine_path_v1():
    # type: () -> str
    return os.path.join(_project_root(), "machines", "claim_desk_v1.ik.toml")


def _machine_path_v2():
    # type: () -> str
    return os.path.join(_project_root(), "machines", "claim_desk.ik.toml")


def _machine_path():
    # type: () -> str
    return _machine_path_v2()


def _store_path(state_dir):
    # type: (str) -> str
    return os.path.join(state_dir, STORE_NAME)


def _ik_binary():
    # type: () -> str
    env = os.environ.get("IK_BINARY")
    if env:
        return env
    return os.path.join(_project_root(), "KIT", "bin", "ik")


def _open_kernel(state_dir):
    # type: (str) -> Kernel
    return Kernel(_store_path(state_dir), binary=_ik_binary())


def _create_machine(kernel):
    # type: (Kernel) -> Any
    return kernel.machine(_machine_path_v2())


def _route_machine(kernel, agg):
    # type: (Kernel, Aggregate) -> Any
    owner = agg.owner
    for path in (_machine_path_v1(), _machine_path_v2()):
        machine = kernel.machine(path)
        if machine.identity == owner:
            return machine
    raise AppError("corrupt_state")


def _state_dir_of(kernel):
    # type: (Kernel) -> str
    return str(kernel.store.parent)


def _ext_path(kernel):
    # type: (Kernel) -> str
    return os.path.join(_state_dir_of(kernel), EXT_NAME)


def _load_ext(kernel):
    # type: (Kernel) -> Dict[str, Any]
    path = _ext_path(kernel)
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "rb") as handle:
            raw = handle.read()
        obj = json.loads(raw.decode("utf-8"))
    except Exception:
        raise AppError("corrupt_state")
    if not isinstance(obj, dict):
        raise AppError("corrupt_state")
    return obj


def _save_ext(kernel, data):
    # type: (Kernel, Dict[str, Any]) -> None
    path = _ext_path(kernel)
    tmp = path + ".tmp"
    blob = json.dumps(data, separators=(",", ":"), sort_keys=True) + "\n"
    with open(tmp, "w") as handle:
        handle.write(blob)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def _settle(machine, result):
    # type: (Any, Any) -> Aggregate
    if isinstance(result, HistoricalResult):
        return machine.show(AGGREGATE_ID)
    return result


def _map_kernel(exc):
    # type: (BaseException) -> AppError
    if isinstance(exc, AppError):
        return exc
    if isinstance(exc, StoreNotFoundError):
        return AppError("bad_status")
    if not isinstance(exc, KernelError):
        return AppError("corrupt_state")
    kind = classify(exc)
    if kind == "corrupt":
        return AppError("corrupt_state")
    if kind == "not_found":
        return AppError("bad_status")
    if exc.code in ("IK_COMMAND_INVALID",):
        return AppError("bad_args")
    return AppError("bad_status")


def _show_or_none(kernel):
    # type: (Kernel) -> Optional[Aggregate]
    store = kernel.store
    if not store.exists():
        return None
    last_exc = None
    agg = None
    for path in (_machine_path_v2(), _machine_path_v1()):
        try:
            machine = kernel.machine(path)
            agg = machine.show(AGGREGATE_ID)
            last_exc = None
            break
        except StoreNotFoundError:
            return None
        except KernelError as exc:
            last_exc = exc
            kind = classify(exc)
            if kind == "corrupt":
                raise AppError("corrupt_state")
            if kind == "not_found":
                return None
            continue
        except Exception:
            raise AppError("corrupt_state")
    if agg is None:
        if last_exc is not None:
            raise AppError("corrupt_state")
        return None
    try:
        routed = _route_machine(kernel, agg)
        if routed.identity != agg._machine.identity:
            return routed.show(AGGREGATE_ID)
        return agg
    except AppError:
        raise
    except KernelError as exc:
        raise _map_kernel(exc)


def _status_name(agg):
    # type: (Aggregate) -> Tuple[str, str]
    st = agg.state
    if st == "payout_saved":
        return "approved", "attempt_saved"
    if st == "paid":
        return "paid", "paid"
    if st == "unbound":
        return "none", "none"
    if st in ("filed", "assessed", "approved", "denied"):
        return st, "none"
    return "none", "none"


def _fact(agg, name, default=None):
    # type: (Aggregate, str, Any) -> Any
    facts = agg.facts
    if name not in facts:
        return default
    return facts[name]


def _is_v2(agg):
    # type: (Aggregate) -> bool
    try:
        return int(agg.owner.version) == 2
    except Exception:
        return False


def _salvage_cents(agg, kernel):
    # type: (Aggregate, Optional[Kernel]) -> int
    val = _fact(agg, "salvage_cents")
    if val is not None:
        return int(val)
    if kernel is not None and not _is_v2(agg):
        ext = _load_ext(kernel)
        if "salvage_cents" in ext:
            return int(ext["salvage_cents"])
    return 0


def _salvage_locked(agg, kernel):
    # type: (Aggregate, Optional[Kernel]) -> bool
    if int(_fact(agg, "salvage_set", 0) or 0) == 1:
        return True
    if kernel is not None and not _is_v2(agg):
        ext = _load_ext(kernel)
        return bool(ext.get("salvage_set"))
    return False


def _snapshot_amount(agg, kernel):
    # type: (Aggregate, Optional[Kernel]) -> Optional[int]
    if kernel is not None and not _is_v2(agg):
        ext = _load_ext(kernel)
        if "payout_amount_cents" in ext:
            return int(ext["payout_amount_cents"])
    return None


def _status_payload(agg, kernel=None):
    # type: (Optional[Aggregate], Optional[Kernel]) -> Dict[str, Any]
    if agg is None or agg.state == "unbound":
        return {
            "claim_id": None,
            "policy_id": None,
            "limit_cents": None,
            "appeal_window_ms": None,
            "filed_ms": None,
            "assessed_cents": None,
            "salvage_cents": 0,
            "denied_ms": None,
            "appeal_used": 0,
            "status": "none",
            "payment": "none",
            "payout_id": None,
            "amount_cents": None,
        }
    status, payment = _status_name(agg)
    return {
        "claim_id": _fact(agg, "claim_id"),
        "policy_id": _fact(agg, "policy_id"),
        "limit_cents": _fact(agg, "limit_cents"),
        "appeal_window_ms": _fact(agg, "appeal_window_ms"),
        "filed_ms": _fact(agg, "filed_ms"),
        "assessed_cents": _fact(agg, "assessed_cents"),
        "salvage_cents": _salvage_cents(agg, kernel),
        "denied_ms": _fact(agg, "denied_ms"),
        "appeal_used": int(_fact(agg, "appeal_used", 0) or 0),
        "status": status,
        "payment": payment,
        "payout_id": _fact(agg, "payout_id"),
        "amount_cents": _status_amount(agg, kernel),
    }


def _status_amount(agg, kernel):
    # type: (Aggregate, Optional[Kernel]) -> Any
    snap = _snapshot_amount(agg, kernel)
    if snap is not None:
        return snap
    return _fact(agg, "amount_cents")


def _payable(agg, kernel=None):
    # type: (Aggregate, Optional[Kernel]) -> int
    limit_cents = int(_fact(agg, "limit_cents"))
    assessed_cents = int(_fact(agg, "assessed_cents"))
    return min(limit_cents, assessed_cents) - _salvage_cents(agg, kernel)


def _amount(agg, kernel=None):
    # type: (Aggregate, Optional[Kernel]) -> int
    st = agg.state
    snap = _snapshot_amount(agg, kernel)
    if snap is not None and st in ("payout_saved", "paid"):
        return snap
    if st in ("payout_saved", "paid"):
        existing = _fact(agg, "amount_cents")
        if existing is not None:
            return int(existing)
    return _payable(agg, kernel)


def _payload_digest(payout_id, claim_id, amount_cents):
    # type: (str, str, int) -> str
    blob = json.dumps(
        {"amount_cents": amount_cents, "claim_id": claim_id, "payout_id": payout_id},
        separators=(",", ":"),
        sort_keys=True,
    )
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _join_url(base, path):
    # type: (str, str) -> str
    return base.rstrip("/") + path


def _http(method, url, body=None):
    # type: (str, str, Optional[Dict[str, Any]]) -> Tuple[Optional[int], Optional[bytes], Optional[str]]
    data = None
    headers = {}
    if body is not None:
        data = json.dumps(body, separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        resp = urllib.request.urlopen(req, timeout=20)
        raw = resp.read()
        return resp.getcode(), raw, None
    except urllib.error.HTTPError as exc:
        try:
            raw = exc.read()
        except Exception:
            raw = b""
        return exc.code, raw, None
    except Exception as exc:
        return None, None, str(exc)


def _parse_paid_body(raw):
    # type: (Optional[bytes]) -> Optional[Dict[str, Any]]
    if raw is None:
        return None
    try:
        obj = json.loads(raw.decode("utf-8"))
    except Exception:
        return None
    if not isinstance(obj, dict):
        return None
    if obj.get("outcome") != "paid":
        return None
    if not isinstance(obj.get("payout_id"), str):
        return None
    if not isinstance(obj.get("claim_id"), str):
        return None
    amt = obj.get("amount_cents")
    if isinstance(amt, bool) or not isinstance(amt, int) or amt <= 0:
        return None
    return obj


def _matches(body, payout_id, claim_id, amount_cents):
    # type: (Dict[str, Any], str, str, int) -> bool
    return (
        body.get("payout_id") == payout_id
        and body.get("claim_id") == claim_id
        and body.get("amount_cents") == amount_cents
        and body.get("outcome") == "paid"
    )


def _new_payout_id():
    # type: () -> str
    return os.urandom(16).hex()


def cmd_file(kernel, args, now_ms):
    # type: (Kernel, list, int) -> Dict[str, Any]
    if len(args) != 4:
        raise AppError("bad_args")
    claim_id = _ident(args[0])
    policy_id = _ident(args[1])
    limit_cents = _pos_int(args[2])
    appeal_window_ms = _nonneg_int(args[3])
    deadline_ms = now_ms + appeal_window_ms
    if deadline_ms > I64_MAX:
        raise AppError("bad_time")
    agg = _show_or_none(kernel)
    if agg is not None and agg.state != "unbound":
        raise AppError("already_open")
    machine = _create_machine(kernel)
    payload = {
        "name": "file",
        "args": {
            "claim_id": claim_id,
            "policy_id": policy_id,
            "limit_cents": limit_cents,
            "appeal_window_ms": appeal_window_ms,
            "filed_ms": now_ms,
            "deadline_ms": deadline_ms,
        },
    }
    try:
        if agg is None:
            result = machine.create_with(AGGREGATE_ID, payload)
        else:
            result = agg.command("file", **payload["args"])
        agg = _settle(machine, result)
    except KernelError as exc:
        raise _map_kernel(exc)
    return {
        "claim_id": claim_id,
        "policy_id": policy_id,
        "limit_cents": limit_cents,
        "appeal_window_ms": appeal_window_ms,
        "filed_ms": now_ms,
        "status": "filed",
        "payment": "none",
        "payout_id": None,
    }


def cmd_assess(kernel, args):
    # type: (Kernel, list) -> Dict[str, Any]
    if len(args) != 1:
        raise AppError("bad_args")
    amount = _pos_int(args[0])
    agg = _show_or_none(kernel)
    if agg is None:
        raise AppError("bad_status")
    status, payment = _status_name(agg)
    if status != "filed" or payment != "none":
        raise AppError("bad_status")
    try:
        agg = _settle(agg._machine, agg.command("assess", assessed_cents=amount))
    except KernelError as exc:
        raise _map_kernel(exc)
    return {
        "claim_id": _fact(agg, "claim_id"),
        "assessed_cents": amount,
        "status": "assessed",
        "payment": "none",
    }


def cmd_approve(kernel, args):
    # type: (Kernel, list) -> Dict[str, Any]
    if args:
        raise AppError("bad_args")
    agg = _show_or_none(kernel)
    if agg is None:
        raise AppError("bad_status")
    status, payment = _status_name(agg)
    if status != "assessed" or payment != "none":
        raise AppError("bad_status")
    amount = min(int(_fact(agg, "limit_cents")), int(_fact(agg, "assessed_cents")))
    try:
        agg = _settle(agg._machine, agg.command("approve", amount_cents=amount))
    except KernelError as exc:
        raise _map_kernel(exc)
    return {
        "claim_id": _fact(agg, "claim_id"),
        "status": "approved",
        "payment": "none",
        "amount_cents": amount,
    }


def cmd_deny(kernel, args, now_ms):
    # type: (Kernel, list, int) -> Dict[str, Any]
    if args:
        raise AppError("bad_args")
    agg = _show_or_none(kernel)
    if agg is None:
        raise AppError("bad_status")
    status, payment = _status_name(agg)
    if status != "assessed" or payment != "none":
        raise AppError("bad_status")
    try:
        if _is_v2(agg):
            window = int(_fact(agg, "appeal_window_ms"))
            deadline_ms = now_ms + window
            if deadline_ms > I64_MAX:
                raise AppError("bad_time")
            agg = _settle(
                agg._machine,
                agg.command("deny", denied_ms=now_ms, deadline_ms=deadline_ms),
            )
        else:
            agg = _settle(agg._machine, agg.command("deny"))
    except KernelError as exc:
        raise _map_kernel(exc)
    return {
        "claim_id": _fact(agg, "claim_id"),
        "status": "denied",
        "payment": "none",
    }


def cmd_appeal(kernel, args, now_ms):
    # type: (Kernel, list, int) -> Dict[str, Any]
    if args:
        raise AppError("bad_args")
    agg = _show_or_none(kernel)
    if agg is None:
        raise AppError("bad_status")
    status, _payment = _status_name(agg)
    used = int(_fact(agg, "appeal_used", 0) or 0)
    if status == "paid":
        raise AppError("bad_status")
    if used == 1:
        raise AppError("appeal_used")
    if status != "denied":
        raise AppError("bad_status")
    window = int(_fact(agg, "appeal_window_ms"))
    denied_ms = _fact(agg, "denied_ms")
    if denied_ms is not None:
        deadline = int(denied_ms) + window
    else:
        deadline = int(_fact(agg, "filed_ms")) + window
    if now_ms > deadline:
        raise AppError("appeal_closed")
    try:
        agg = _settle(agg._machine, agg.command("appeal", now_ms=now_ms, appeal_used=1))
    except KernelError as exc:
        raise _map_kernel(exc)
    return {
        "claim_id": _fact(agg, "claim_id"),
        "status": "assessed",
        "payment": "none",
        "appeal_used": 1,
    }


def cmd_salvage(kernel, args):
    # type: (Kernel, list) -> Dict[str, Any]
    if len(args) != 1:
        raise AppError("bad_args")
    amount = _nonneg_int(args[0])
    agg = _show_or_none(kernel)
    if agg is None:
        raise AppError("bad_status")
    status, payment = _status_name(agg)
    if payment == "attempt_saved" or status in ("paid", "denied", "filed"):
        raise AppError("salvage_closed")
    if status not in ("assessed", "approved") or payment != "none":
        raise AppError("bad_status")
    payable_base = min(int(_fact(agg, "limit_cents")), int(_fact(agg, "assessed_cents")))
    if amount >= payable_base:
        raise AppError("bad_amount")
    current = _salvage_cents(agg, kernel)
    locked = _salvage_locked(agg, kernel)
    if locked and current != amount:
        raise AppError("salvage_locked")
    if locked and current == amount:
        return {
            "claim_id": _fact(agg, "claim_id"),
            "status": status,
            "payment": payment,
            "salvage_cents": current,
        }
    if _is_v2(agg):
        name = "salvage_assessed" if status == "assessed" else "salvage_approved"
        try:
            agg = _settle(
                agg._machine,
                agg.command(name, salvage_cents=amount, salvage_set=1),
            )
        except KernelError as exc:
            raise _map_kernel(exc)
    else:
        ext = _load_ext(kernel)
        ext["salvage_cents"] = amount
        ext["salvage_set"] = 1
        _save_ext(kernel, ext)
    status, payment = _status_name(agg)
    return {
        "claim_id": _fact(agg, "claim_id"),
        "status": status,
        "payment": payment,
        "salvage_cents": amount,
    }


def _finish_paid(agg, payout_id, raw_body):
    # type: (Aggregate, str, bytes) -> Aggregate
    digest = hashlib.sha256(raw_body).hexdigest()
    if agg.pending_intent is not None:
        recorded = agg.record_effect_outcome(digest, intent=agg.pending_intent)
        agg = _settle(agg._machine, recorded)
    if agg.state != "paid":
        agg = _settle(agg._machine, agg.command("complete_payout", payout_id=payout_id))
    return agg


def _paid_obj(agg, kernel=None):
    # type: (Aggregate, Optional[Kernel]) -> Dict[str, Any]
    return {
        "claim_id": _fact(agg, "claim_id"),
        "payout_id": _fact(agg, "payout_id"),
        "amount_cents": _amount(agg, kernel),
        "status": "paid",
        "payment": "paid",
    }


def cmd_payout(kernel, service_url, args):
    # type: (Kernel, str, list) -> Dict[str, Any]
    if args:
        raise AppError("bad_args")
    agg = _show_or_none(kernel)
    if agg is None:
        raise AppError("bad_status")
    status, payment = _status_name(agg)
    if status == "paid" and payment == "paid":
        return _paid_obj(agg, kernel)
    if payment != "attempt_saved" and not (status == "approved" and payment == "none"):
        raise AppError("bad_status")
    amount = _amount(agg, kernel)
    claim_id = str(_fact(agg, "claim_id"))
    if payment == "attempt_saved":
        payout_id = str(_fact(agg, "payout_id"))
        code, raw, err = _http("GET", _join_url(service_url, "/v1/payouts/" + urllib.request.quote(payout_id, safe="")))
        if err is not None or code is None:
            raise AppError("service_unavailable")
        if code == 200:
            body = _parse_paid_body(raw)
            if body is None:
                raise AppError("service_unavailable")
            if not _matches(body, payout_id, claim_id, amount):
                raise AppError("lookup_conflict")
            _crash_if("after-accept-before-record")
            try:
                agg = _finish_paid(agg, payout_id, raw or b"")
            except KernelError as exc:
                raise _map_kernel(exc)
            _crash_if("after-record-before-exit")
            return _paid_obj(agg, kernel)
        if code != 404:
            raise AppError("service_unavailable")
        post_body = {"payout_id": payout_id, "claim_id": claim_id, "amount_cents": amount}
        code, raw, err = _http("POST", _join_url(service_url, "/v1/payouts"), post_body)
        if err is not None or code is None:
            raise AppError("service_unavailable")
        if code >= 500:
            raise AppError("service_unavailable")
        if code == 409:
            raise AppError("lookup_conflict")
        if code != 200:
            raise AppError("service_unavailable")
        body = _parse_paid_body(raw)
        if body is None:
            raise AppError("service_unavailable")
        if not _matches(body, payout_id, claim_id, amount):
            raise AppError("lookup_conflict")
        _crash_if("after-accept-before-record")
        try:
            agg = _finish_paid(agg, payout_id, raw or b"")
        except KernelError as exc:
            raise _map_kernel(exc)
        _crash_if("after-record-before-exit")
        return _paid_obj(agg, kernel)
    payout_id = _new_payout_id()
    digest = _payload_digest(payout_id, claim_id, amount)
    try:
        if _is_v2(agg):
            agg = _settle(
                agg._machine,
                agg.command(
                    "save_payout",
                    payout_id=payout_id,
                    payload_digest=digest,
                    idempotency_key=payout_id,
                    amount_cents=amount,
                ),
            )
        else:
            agg = _settle(
                agg._machine,
                agg.command(
                    "save_payout",
                    payout_id=payout_id,
                    payload_digest=digest,
                    idempotency_key=payout_id,
                ),
            )
            ext = _load_ext(kernel)
            ext["payout_amount_cents"] = amount
            _save_ext(kernel, ext)
    except KernelError as exc:
        raise _map_kernel(exc)
    _crash_if("after-payout-saved-before-request")
    post_body = {"payout_id": payout_id, "claim_id": claim_id, "amount_cents": amount}
    code, raw, err = _http("POST", _join_url(service_url, "/v1/payouts"), post_body)
    if err is not None or code is None or (code is not None and code >= 500):
        raise AppError("service_unavailable")
    if code == 409:
        raise AppError("lookup_conflict")
    if code != 200:
        raise AppError("service_unavailable")
    body = _parse_paid_body(raw)
    if body is None:
        raise AppError("service_unavailable")
    if not _matches(body, payout_id, claim_id, amount):
        raise AppError("lookup_conflict")
    _crash_if("after-accept-before-record")
    try:
        agg = _finish_paid(agg, payout_id, raw or b"")
    except KernelError as exc:
        raise _map_kernel(exc)
    _crash_if("after-record-before-exit")
    return _paid_obj(agg, kernel)


def cmd_reconcile(kernel, service_url, args):
    # type: (Kernel, str, list) -> Dict[str, Any]
    if len(args) != 1:
        raise AppError("bad_args")
    given = _ident(args[0])
    agg = _show_or_none(kernel)
    if agg is None:
        raise AppError("no_payout")
    status, payment = _status_name(agg)
    saved = _fact(agg, "payout_id")
    if saved is None or payment == "none":
        raise AppError("no_payout")
    if str(saved) != given:
        raise AppError("payout_mismatch")
    if status == "paid":
        obj = _paid_obj(agg, kernel)
        obj["lookup"] = "paid"
        return obj
    claim_id = str(_fact(agg, "claim_id"))
    amount = _amount(agg, kernel)
    code, raw, err = _http("GET", _join_url(service_url, "/v1/payouts/" + urllib.request.quote(given, safe="")))
    if err is not None or code is None:
        raise AppError("service_unavailable")
    if code == 404:
        return {
            "lookup": "not_sent",
            "claim_id": claim_id,
            "payout_id": given,
            "payment": "attempt_saved",
            "status": "approved",
        }
    if code != 200:
        raise AppError("service_unavailable")
    body = _parse_paid_body(raw)
    if body is None:
        raise AppError("service_unavailable")
    if not _matches(body, given, claim_id, amount):
        raise AppError("lookup_conflict")
    _crash_if("after-accept-before-record")
    try:
        agg = _finish_paid(agg, given, raw or b"")
    except KernelError as exc:
        raise _map_kernel(exc)
    _crash_if("after-record-before-exit")
    obj = _paid_obj(agg, kernel)
    obj["lookup"] = "paid"
    return obj


def cmd_callback(kernel, args):
    # type: (Kernel, list) -> Dict[str, Any]
    if len(args) != 1:
        raise AppError("bad_args")
    path = args[0]
    try:
        with open(path, "rb") as handle:
            raw = handle.read()
        obj = json.loads(raw.decode("utf-8"))
    except Exception:
        raise AppError("bad_callback")
    if not isinstance(obj, dict):
        raise AppError("bad_callback")
    agg = _show_or_none(kernel)
    payload = _status_payload(agg, kernel)
    payload["ignored"] = True
    return {
        "ignored": True,
        "status": payload["status"],
        "payment": payload["payment"],
        "claim_id": payload["claim_id"],
        "payout_id": payload["payout_id"],
    }


def dispatch(argv):
    # type: (list) -> int
    if not argv:
        raise AppError("bad_args")
    command = argv[0]
    rest = argv[1:]
    state_dir, service_url, now_ms = _env_required()
    kernel = _open_kernel(state_dir)
    try:
        if command == "file":
            return _json_out(cmd_file(kernel, rest, now_ms))
        if command == "assess":
            return _json_out(cmd_assess(kernel, rest))
        if command == "approve":
            return _json_out(cmd_approve(kernel, rest))
        if command == "deny":
            return _json_out(cmd_deny(kernel, rest, now_ms))
        if command == "appeal":
            return _json_out(cmd_appeal(kernel, rest, now_ms))
        if command == "salvage":
            return _json_out(cmd_salvage(kernel, rest))
        if command == "payout":
            return _json_out(cmd_payout(kernel, service_url, rest))
        if command == "reconcile":
            return _json_out(cmd_reconcile(kernel, service_url, rest))
        if command == "status":
            if rest:
                raise AppError("bad_args")
            return _json_out(_status_payload(_show_or_none(kernel), kernel))
        if command == "callback":
            return _json_out(cmd_callback(kernel, rest))
        raise AppError("bad_args")
    finally:
        kernel.close()


def main():
    # type: () -> int
    try:
        return dispatch(sys.argv[1:])
    except AppError as exc:
        return _json_out({"error": exc.code}, 1)
    except KernelError as exc:
        mapped = _map_kernel(exc)
        return _json_out({"error": mapped.code}, 1)


if __name__ == "__main__":
    sys.exit(main())
