from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NODE = os.environ.get("NODE", "node")
RUN = str(ROOT / "run")


def _decode_line(proc: subprocess.Popen) -> dict:
    line = proc.stdout.readline()
    return json.loads(line.decode("utf-8"))


class Stub:
    def __init__(self) -> None:
        self.proc = subprocess.Popen(
            [NODE, str(ROOT / "stub" / "server.mjs")],
            cwd=str(ROOT),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        info = _decode_line(self.proc)
        self.service_url = info["service_url"]
        self.control_url = info["control_url"]

    def close(self) -> None:
        self.proc.send_signal(signal.SIGTERM)
        try:
            self.proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            self.proc.kill()
        if self.proc.stdout:
            self.proc.stdout.close()
        if self.proc.stderr:
            self.proc.stderr.close()

    def get(self, path: str) -> dict:
        with urllib.request.urlopen(self.control_url + path, timeout=5) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def fault(self, **body: object) -> None:
        data = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(
            self.control_url + "/fault",
            data=data,
            method="POST",
            headers={"content-type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            resp.read()


class Desk:
    def __init__(self, stub: Stub, now: int = 1000) -> None:
        self.stub = stub
        self.now = now
        self.dir = tempfile.mkdtemp(prefix="claim-desk-")
        self.marker = os.path.join(self.dir, "unrelated.bin")
        with open(self.marker, "wb") as handle:
            handle.write(b"keep-me-bytes")
        with open(self.marker, "rb") as handle:
            self.marker_bytes = handle.read()

    def env(self, crash=None):
        env = os.environ.copy()
        env["STATE_DIR"] = self.dir
        env["SERVICE_URL"] = self.stub.service_url
        env["NOW_MS"] = str(self.now)
        env["IK_BINARY"] = str(ROOT / "KIT" / "bin" / "ik")
        if crash:
            env["CRASH_AT"] = crash
        elif "CRASH_AT" in env:
            del env["CRASH_AT"]
        return env

    def run(self, args, crash=None, expect_ok=True):
        proc = subprocess.run(
            [RUN, *args],
            cwd=str(ROOT),
            env=self.env(crash),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        if crash:
            self.assert_marker()
            return proc
        text = proc.stdout.decode("utf-8")
        self.assert_one_json(text)
        obj = json.loads(text.strip())
        if expect_ok:
            if proc.returncode != 0:
                raise AssertionError((proc.returncode, obj, proc.stderr.decode("utf-8")))
        else:
            if proc.returncode == 0:
                raise AssertionError(("expected refusal", obj))
        self.assert_marker()
        return obj, proc.returncode

    def assert_one_json(self, text: str) -> None:
        stripped = text.strip()
        json.loads(stripped)
        if text.count("{") == 0:
            raise AssertionError(text)

    def assert_marker(self) -> None:
        with open(self.marker, "rb") as handle:
            if handle.read() != self.marker_bytes:
                raise AssertionError("unrelated file mutated")


class ClaimDeskTests(unittest.TestCase):
    def setUp(self) -> None:
        self.stub = Stub()
        self.desk = Desk(self.stub)

    def tearDown(self) -> None:
        self.stub.close()

    def test_empty_status_and_file(self) -> None:
        obj, code = self.desk.run(["status"])
        self.assertEqual(code, 0)
        self.assertEqual(obj["status"], "none")
        self.assertEqual(obj["payment"], "none")
        self.assertEqual(obj["salvage_cents"], 0)
        self.assertEqual(obj["appeal_used"], 0)
        self.assertIsNone(obj["claim_id"])
        filed, _ = self.desk.run(["file", "c1", "p1", "10000", "5000"])
        self.assertEqual(filed["status"], "filed")
        self.assertEqual(filed["filed_ms"], 1000)
        err, code = self.desk.run(["file", "c2", "p2", "1", "1"], expect_ok=False)
        self.assertEqual(err["error"], "already_open")

    def test_happy_payout_and_noop(self) -> None:
        self.desk.run(["file", "c1", "p1", "10000", "5000"])
        self.desk.run(["assess", "8000"])
        approved, _ = self.desk.run(["approve"])
        self.assertEqual(approved["amount_cents"], 8000)
        paid, _ = self.desk.run(["payout"])
        self.assertEqual(paid["status"], "paid")
        self.assertEqual(paid["amount_cents"], 8000)
        again, _ = self.desk.run(["payout"])
        self.assertEqual(again["status"], "paid")
        effects = self.stub.get("/effects")
        self.assertEqual(effects["count"], 1)
        posts = self.stub.get("/posts")
        self.assertEqual(posts["count"], 1)

    def test_refusals_and_appeal(self) -> None:
        err, _ = self.desk.run(["assess", "1"], expect_ok=False)
        self.assertEqual(err["error"], "bad_status")
        self.desk.run(["file", "c1", "p1", "100", "10"])
        err, _ = self.desk.run(["approve"], expect_ok=False)
        self.assertEqual(err["error"], "bad_status")
        err, _ = self.desk.run(["payout"], expect_ok=False)
        self.assertEqual(err["error"], "bad_status")
        self.assertEqual(self.stub.get("/posts")["count"], 0)
        self.desk.run(["assess", "50"])
        self.desk.run(["deny"])
        self.desk.now = 1011
        closed, _ = self.desk.run(["appeal"], expect_ok=False)
        self.assertEqual(closed["error"], "appeal_closed")
        self.desk.now = 1010
        reopened, _ = self.desk.run(["appeal"])
        self.assertEqual(reopened["status"], "assessed")
        self.assertEqual(reopened["appeal_used"], 1)
        self.desk.run(["deny"])
        used, _ = self.desk.run(["appeal"], expect_ok=False)
        self.assertEqual(used["error"], "appeal_used")

    def test_crash_before_request(self) -> None:
        self.desk.run(["file", "c1", "p1", "100", "10"])
        self.desk.run(["assess", "40"])
        self.desk.run(["approve"])
        proc = self.desk.run(["payout"], crash="after-payout-saved-before-request")
        self.assertNotEqual(proc.returncode, 0)
        self.assertEqual(self.stub.get("/effects")["count"], 0)
        st, _ = self.desk.run(["status"])
        self.assertEqual(st["payment"], "attempt_saved")
        self.assertEqual(st["status"], "approved")
        payout_id = st["payout_id"]
        paid, _ = self.desk.run(["payout"])
        self.assertEqual(paid["payout_id"], payout_id)
        self.assertEqual(paid["status"], "paid")
        self.assertEqual(self.stub.get("/effects")["count"], 1)

    def test_crash_after_accept_then_lookup(self) -> None:
        self.desk.run(["file", "c1", "p1", "100", "10"])
        self.desk.run(["assess", "40"])
        self.desk.run(["approve"])
        proc = self.desk.run(["payout"], crash="after-accept-before-record")
        self.assertNotEqual(proc.returncode, 0)
        self.assertEqual(self.stub.get("/effects")["count"], 1)
        st, _ = self.desk.run(["status"])
        self.assertEqual(st["payment"], "attempt_saved")
        paid, _ = self.desk.run(["payout"])
        self.assertEqual(paid["status"], "paid")
        self.assertEqual(self.stub.get("/effects")["count"], 1)
        posts = self.stub.get("/posts")
        self.assertEqual(posts["count"], 1)

    def test_crash_after_record_noop(self) -> None:
        self.desk.run(["file", "c1", "p1", "100", "10"])
        self.desk.run(["assess", "40"])
        self.desk.run(["approve"])
        proc = self.desk.run(["payout"], crash="after-record-before-exit")
        self.assertNotEqual(proc.returncode, 0)
        st, _ = self.desk.run(["status"])
        self.assertEqual(st["status"], "paid")
        self.assertEqual(st["payment"], "paid")
        paid, _ = self.desk.run(["payout"])
        self.assertEqual(paid["status"], "paid")
        rec, _ = self.desk.run(["reconcile", st["payout_id"]])
        self.assertEqual(rec["lookup"], "paid")

    def test_dropped_reply_reconcile(self) -> None:
        self.desk.run(["file", "c1", "p1", "100", "10"])
        self.desk.run(["assess", "40"])
        self.desk.run(["approve"])
        self.stub.fault(drop_reply=True)
        err, _ = self.desk.run(["payout"], expect_ok=False)
        self.assertEqual(err["error"], "service_unavailable")
        st, _ = self.desk.run(["status"])
        self.assertEqual(st["payment"], "attempt_saved")
        self.stub.fault(drop_reply=False)
        rec, _ = self.desk.run(["reconcile", st["payout_id"]])
        self.assertEqual(rec["lookup"], "paid")
        self.assertEqual(rec["status"], "paid")
        self.assertEqual(self.stub.get("/effects")["count"], 1)
        self.assertNotEqual(rec.get("lookup"), "not_sent")

    def test_reconcile_not_sent_and_mismatch(self) -> None:
        err, _ = self.desk.run(["reconcile", "x"], expect_ok=False)
        self.assertEqual(err["error"], "no_payout")
        self.desk.run(["file", "c1", "p1", "100", "10"])
        self.desk.run(["assess", "40"])
        self.desk.run(["approve"])
        self.desk.run(["payout"], crash="after-payout-saved-before-request")
        st, _ = self.desk.run(["status"])
        rec, _ = self.desk.run(["reconcile", st["payout_id"]])
        self.assertEqual(rec["lookup"], "not_sent")
        self.assertEqual(rec["payment"], "attempt_saved")
        bad, _ = self.desk.run(["reconcile", "other-id"], expect_ok=False)
        self.assertEqual(bad["error"], "payout_mismatch")
        self.assertEqual(self.stub.get("/posts")["count"], 0)

    def test_callback_ignored(self) -> None:
        self.desk.run(["file", "c1", "p1", "100", "10"])
        self.desk.run(["assess", "40"])
        self.desk.run(["approve"])
        path = os.path.join(self.desk.dir, "cb.json")
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(json.dumps({"payout_id": "x", "status": "paid"}))
        obj, _ = self.desk.run(["callback", path])
        self.assertTrue(obj["ignored"])
        st, _ = self.desk.run(["status"])
        self.assertEqual(st["status"], "approved")
        self.assertEqual(st["payment"], "none")
        self.assertEqual(self.stub.get("/posts")["count"], 0)
        bad, _ = self.desk.run(["callback", path + ".missing"], expect_ok=False)
        self.assertEqual(bad["error"], "bad_callback")

    def test_bad_args_and_missing_env(self) -> None:
        err, _ = self.desk.run(["file", "bad id", "p1", "1", "1"], expect_ok=False)
        self.assertEqual(err["error"], "bad_args")
        err, _ = self.desk.run(["file", "c1", "p1", "01", "1"], expect_ok=False)
        self.assertEqual(err["error"], "bad_amount")
        env = self.desk.env()
        del env["NOW_MS"]
        proc = subprocess.run([RUN, "status"], cwd=str(ROOT), env=env, stdout=subprocess.PIPE)
        self.assertNotEqual(proc.returncode, 0)
        self.assertEqual(json.loads(proc.stdout.decode())["error"], "bad_time")

    def test_paid_is_terminal(self) -> None:
        self.desk.run(["file", "c1", "p1", "100", "10"])
        self.desk.run(["assess", "40"])
        self.desk.run(["approve"])
        self.desk.run(["payout"])
        for cmd in (["assess", "1"], ["approve"], ["deny"], ["appeal"]):
            err, _ = self.desk.run(cmd, expect_ok=False)
            self.assertEqual(err["error"], "bad_status")
        closed, _ = self.desk.run(["salvage", "1"], expect_ok=False)
        self.assertEqual(closed["error"], "salvage_closed")

    def test_salvage_and_payout_offset(self) -> None:
        self.desk.run(["file", "c1", "p1", "10000", "5000"])
        err, _ = self.desk.run(["salvage", "1"], expect_ok=False)
        self.assertEqual(err["error"], "bad_status")
        self.desk.run(["assess", "8000"])
        err, _ = self.desk.run(["salvage", "8000"], expect_ok=False)
        self.assertEqual(err["error"], "bad_amount")
        salv, _ = self.desk.run(["salvage", "300"])
        self.assertEqual(salv["salvage_cents"], 300)
        again, _ = self.desk.run(["salvage", "300"])
        self.assertEqual(again["salvage_cents"], 300)
        locked, _ = self.desk.run(["salvage", "301"], expect_ok=False)
        self.assertEqual(locked["error"], "salvage_locked")
        st, _ = self.desk.run(["status"])
        self.assertEqual(st["salvage_cents"], 300)
        self.desk.run(["approve"])
        paid, _ = self.desk.run(["payout"])
        self.assertEqual(paid["amount_cents"], 7700)
        self.assertEqual(self.stub.get("/effects")["count"], 1)
        st, _ = self.desk.run(["status"])
        self.assertEqual(st["salvage_cents"], 300)
        self.assertEqual(st["amount_cents"], 7700)
        closed, _ = self.desk.run(["salvage", "300"], expect_ok=False)
        self.assertEqual(closed["error"], "salvage_closed")

    def test_deny_clock_appeal_window(self) -> None:
        self.desk.run(["file", "c1", "p1", "100", "10"])
        self.desk.run(["assess", "50"])
        self.desk.now = 2000
        self.desk.run(["deny"])
        st, _ = self.desk.run(["status"])
        self.assertEqual(st["denied_ms"], 2000)
        self.desk.now = 2005
        reopened, _ = self.desk.run(["appeal"])
        self.assertEqual(reopened["status"], "assessed")
        self.desk.run(["deny"])
        self.desk.now = 3000
        too_late, _ = self.desk.run(["appeal"], expect_ok=False)
        self.assertEqual(too_late["error"], "appeal_closed")

    def test_salvage_closed_inflight(self) -> None:
        self.desk.run(["file", "c1", "p1", "100", "10"])
        self.desk.run(["assess", "40"])
        self.desk.run(["approve"])
        self.desk.run(["salvage", "5"])
        proc = self.desk.run(["payout"], crash="after-payout-saved-before-request")
        self.assertNotEqual(proc.returncode, 0)
        err, _ = self.desk.run(["salvage", "5"], expect_ok=False)
        self.assertEqual(err["error"], "salvage_closed")
        paid, _ = self.desk.run(["payout"])
        self.assertEqual(paid["amount_cents"], 35)
        self.assertEqual(self.stub.get("/effects")["count"], 1)

    def test_restart_survives(self) -> None:
        self.desk.run(["file", "c1", "p1", "100", "10"])
        st, _ = self.desk.run(["status"])
        self.assertEqual(st["claim_id"], "c1")
        time.sleep(0.05)
        st2, _ = self.desk.run(["status"])
        self.assertEqual(st2["filed_ms"], 1000)


if __name__ == "__main__":
    unittest.main()
