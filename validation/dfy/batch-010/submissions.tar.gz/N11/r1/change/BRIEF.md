# Insurance claim adjudication desk

The program behind `./run` is a durable local desk for one insurance claim. A claim is filed against a policy limit, assessed by an adjuster, approved or denied, and if approved is paid through an external payout service. A payout uses an application-created id saved before the request; recovery looks up that id before any retry. A denied claim may be reopened once while an appeal window measured from `NOW_MS` remains open.

## Scope and invocation

One machine and one process at a time. One claim is bound to a state directory. An unrelated writer may create or modify other files in `STATE_DIR`; those files must survive byte-for-byte. The tool may keep its durable files in `STATE_DIR` under any names. It must use `STATE_DIR`, `SERVICE_URL`, `NOW_MS`, and optional `CRASH_AT`. `SERVICE_URL` is required for every command, including status (status never contacts it). `NOW_MS` is a required non-negative integer epoch-millisecond clock for every command.

`./run <command> [args]` prints exactly one JSON object and nothing else (one trailing newline is allowed). Exit 0 is success. Refusals are nonzero and print `{ "error": "<code>" }`. Identifiers are 1–64 characters matching `A-Za-z0-9._-`. `limit_cents` and `assessed_cents` are canonical positive decimal integers. `appeal_window_ms` is a canonical non-negative decimal integer. `CRASH_AT` labels are:

* `after-payout-saved-before-request`: after saving a payout id and payout snapshot, before sending a request;
* `after-accept-before-record`: after reading a complete successful provider response, before saving the paid record;
* `after-record-before-exit`: after saving the paid record, before success JSON is written.

A process must kill itself with SIGKILL at a reached label. Durable commits are flushed before the command treats them as committed. A malformed owned state file is `corrupt_state` and is not rewritten. Refusals do not modify state except that an appeal whose window has elapsed may be refused without mutation.

Lifecycle authority for the bound claim lives in the Ikaros runtime store under `STATE_DIR`. Application JSON sidecars must not be the source of status after a mutating command.

## Commands

`file <claim_id> <policy_id> <limit_cents> <appeal_window_ms>` binds the empty store at `NOW_MS`. It returns `{claim_id,policy_id,limit_cents,appeal_window_ms,filed_ms,status:"filed",payment:"none",payout_id:null}`. `filed_ms` equals the `NOW_MS` of this command. A second file is `already_open`; malformed values are `bad_args`, `bad_time`, or `bad_amount`.

`assess <amount_cents>` is valid only for `status:"filed"`. It records `assessed_cents` and returns `{claim_id,assessed_cents,status:"assessed",payment:"none"}`. It never contacts the provider. A claim that is not filed is `bad_status`.

`approve` is valid only for `status:"assessed"` with `payment:"none"`. It marks the claim `approved` and returns `{claim_id,status:"approved",payment:"none",amount_cents}` where `amount_cents` is `min(limit_cents, assessed_cents)`. It never contacts the provider.

`deny` is valid only for `status:"assessed"` with `payment:"none"`. It marks the claim `denied` and returns `{claim_id,status:"denied",payment:"none"}`. It never contacts the provider. This initial program does not persist a separate deny clock; the appeal deadline is `filed_ms + appeal_window_ms`.

`payout` is valid for an approved unpaid claim, or for a saved attempt. Before any provider call it computes `amount_cents = min(limit_cents, assessed_cents)`. A first attempt saves a generated `payout_id` and that exact snapshot, then posts once. An attempt whose connection fails, has an incomplete response, or receives HTTP 5xx remains `payment:"attempt_saved"`, keeps `status:"approved"`, and returns `service_unavailable`; it does not lookup in that invocation. A matching successful response returns `{claim_id,payout_id,amount_cents,status:"paid",payment:"paid"}`. Repeating payout after paid is a success no-op without a provider call.

If a saved attempt exists, `payout` first `GET /v1/payouts/<payout_id>`: a matching 200 is adopted without POST; a 404 causes one POST with the saved id. Never allocate a replacement id. A mismatching success is `lookup_conflict` and changes nothing. A claim that is not approved and has no saved attempt is `bad_status` without contacting the provider.

`appeal` is valid only for `status:"denied"`. If `NOW_MS` is greater than `filed_ms + appeal_window_ms` it returns `appeal_closed` without mutation. A second appeal after a successful reopen is `appeal_used` without mutation. A successful appeal sets `appeal_used` to 1, returns the claim to `status:"assessed"` keeping `assessed_cents`, and returns `{claim_id,status:"assessed",payment:"none",appeal_used:1}`. Appeal never contacts the provider.

`reconcile <payout_id>` never POSTs or allocates. No saved payout is `no_payout`; another id is `payout_mismatch`. Lookup 200 with matching ids and amount commits paid and returns the success object plus `lookup:"paid"`; 404 returns exit 0 `{lookup:"not_sent",claim_id,payout_id,payment:"attempt_saved",status:"approved"}`; a mismatch is `lookup_conflict`; transport failure is `service_unavailable`.

`status` never contacts the provider and returns `{claim_id,policy_id,limit_cents,appeal_window_ms,filed_ms,assessed_cents,salvage_cents,denied_ms,appeal_used,status,payment,payout_id,amount_cents}`. Empty fields are null, with `appeal_used:0`, `salvage_cents:0`, `denied_ms:null`, `status:"none"`, and `payment:"none"`.

`callback <path>` reads one JSON callback. It must not POST or allocate. A malformed callback is `bad_callback`; a well-formed callback may be ignored. It must never overwrite paid, denied, or approved-with-saved-attempt state.

## Provider

The supplied service has `POST /v1/payouts` and `GET /v1/payouts/<payout_id>`. A first valid payout id records one effect and returns the body with `outcome:"paid"`; repeating the same id and identical fields returns the same object without another effect; any differing field is HTTP 409. Unknown lookup is 404. The provider may drop a reply after accepting, hold a reply, or return 5xx without storing. Control endpoints are not part of this contract.

POST JSON fields are `payout_id`, `claim_id`, and positive integer `amount_cents`.

## Requirements

R1. File and every later committed record survive new processes, including a payout attempt killed at `after-payout-saved-before-request`.

R2. Filing validates claim, policy, limit, and appeal-window fields, binds one claim, and does not contact the provider.

R3. A filed claim can be assessed then approved; payout then records one durable attempt and pays `min(limit_cents, assessed_cents)` on a healthy provider. Assess before file, approve before assess, or payout before approve is refused without a provider call.

R4. Deny is durable and provider-free. Appeal within `filed_ms + appeal_window_ms` reopens once to assessed. A second appeal is `appeal_used`. Past the deadline is `appeal_closed`. Paid is terminal for assess, approve, deny, and appeal.

R5. A healthy provider permits payout and exactly one external payout effect; repeating payout is a no-op and does not add an effect.

R6. Callback files never overwrite local terminal or in-flight payout outcomes and never cause provider effects.

R7. Payout on a denied or unapproved claim, appeal on a non-denied claim, and assess after a non-filed status are refused without contacting the provider.

R8. A crash before POST leaves one saved payout id and zero effects; a later payout POSTs that same id and ends paid exactly once.

R9. A crash after provider acceptance leaves `attempt_saved` locally and one provider effect; later payout adopts by lookup without a second effect.

R10. A crash after the durable paid record leaves paid state and later payout is a no-op; reconcile can likewise survive its record-before-exit crash.

R11. A dropped payout reply yields `service_unavailable` and `attempt_saved`; following reconcile adopts paid by lookup, never reports `not_sent`, and never posts again.

R12. Reconcile never POSTs: a saved-but-unaccepted id returns `not_sent` with `attempt_saved`; a wrong id is `payout_mismatch` and leaves state unchanged.

R13. Unrelated files in STATE_DIR retain identical bytes through commits and refusals.

R14. Every invocation emits one JSON object; status on empty is the null shape; missing SERVICE_URL or NOW_MS is a refusal; the first file binds the only claim and no command can file another.
