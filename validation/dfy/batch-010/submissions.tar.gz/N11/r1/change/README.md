# Insurance claim adjudication desk

Durable one-claim desk. Lifecycle lives in Ikaros; `./run` is the CLI.

## Setup

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index --no-deps KIT/python/*.whl
chmod +x run
```

`./run` also creates the venv if it is missing. Set `IK_BINARY` only to override `KIT/bin/ik`.

## Run

Start the stub (prints `service_url`):

```sh
node stub/server.mjs
```

Every command needs `STATE_DIR`, `SERVICE_URL`, and `NOW_MS`. Optional `CRASH_AT`.

```sh
export STATE_DIR=/tmp/claim-desk
export SERVICE_URL=http://127.0.0.1:PORT
export NOW_MS=1000
mkdir -p "$STATE_DIR"
./run file c1 p1 10000 60000
./run assess 8000
./run salvage 300
./run approve
./run payout
./run status
```

Commands: `file`, `assess`, `approve`, `deny`, `salvage`, `payout`, `appeal`, `reconcile`, `status`, `callback`.

## Tests

```sh
.venv/bin/python tests/test_claim_desk.py
```
