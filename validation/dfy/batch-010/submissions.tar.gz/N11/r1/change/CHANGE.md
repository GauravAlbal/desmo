# Change: salvage offset and deny-clock appeal window

R1–R14 remain in force except where this file names a superseding rule. `status` already reports `salvage_cents` and `denied_ms` (null until a post-change deny). This change adds a salvage command and changes how a denied claim's appeal deadline is measured. It also changes the payout amount formula.

The new command is:

`salvage <amount_cents>`

It is valid only for an assessed or approved claim with `payment:"none"`. `amount_cents` is a canonical non-negative decimal integer strictly less than `min(limit_cents, assessed_cents)` so that a later payout remains at least 1 cent. The command records `salvage_cents` and returns `{claim_id,status,payment,salvage_cents}`. Salvage never contacts the provider. Repeating the same salvage amount is a success no-op. A different amount after salvage is already set is `salvage_locked`. Paid, denied, filed, empty, or in-flight payout claims return `salvage_closed` or `bad_status` as applicable without mutation.

Payout amount is revised for every payout that has not yet saved an attempt:

`amount_cents = min(limit_cents, assessed_cents) - salvage_cents`.

A saved attempt keeps its original snapshot and id. A successful payout leaves `salvage_cents` unchanged (informational).

Appeal is revised only for new denials. When `deny` runs under this change it persists `denied_ms` as the current `NOW_MS`. The appeal deadline becomes `denied_ms + appeal_window_ms`. Existing persisted denials with `denied_ms:null` (the initial program never wrote a deny clock) continue under their original rule `filed_ms + appeal_window_ms`. They may still appeal once if that original window is open. They may receive `salvage` only after a successful appeal returns them to assessed. Pre-change assessed or approved unpaid claims may `salvage` under the new command (salvage starts at 0). Pre-change paid claims refuse `salvage` with `salvage_closed` and keep their original paid amount.

## C1–C5

C1. `salvage` accepts only a strictly-smaller-than-payable non-negative amount on an unpaid assessed or approved claim, persists it, and creates no provider effect.

C2. Salvage state survives a new process. Repeating the same salvage is idempotent; a different amount is `salvage_locked`; filed, denied, paid, or in-flight claims are refused without mutation.

C3. A post-change `deny` records `denied_ms` and uses `denied_ms + appeal_window_ms` as the appeal deadline. A clock beyond the original `filed_ms + appeal_window_ms` but at or before the revised deadline may still appeal. A clock beyond the revised deadline returns `appeal_closed`. Pre-change denials with `denied_ms:null` keep `filed_ms + appeal_window_ms`.

C4. Payout after salvage charges `min(limit, assessed) - salvage_cents`, that amount is durable and visible, and a successful payout preserves exactly one provider effect.

C5. Salvage and deny-clock records respect the saved-payout crash boundaries: after a saved-attempt crash or dropped reply, the same payout id and amount are recovered by lookup/retry, salvage cannot erase them (`salvage_closed`), and no second provider effect is created.
