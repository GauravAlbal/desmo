from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import signal
import sys
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Optional

from invariant_kernel import (
    Aggregate,
    HistoricalResult,
    Kernel,
    KernelError,
    StoreNotFoundError,
    classify,
)

ROOT = os.path.dirname(os.path.abspath(__file__))
MACHINE_V2 = os.path.join(ROOT, "machines", "claim_desk.ik.toml")
MACHINE_V1 = os.path.join(ROOT, "machines", "claim_desk_v1.ik.toml")
STORE_NAME = "kernel.sqlite"
OVERLAY_NAME = "claim_v1_overlay.json"
AGGREGATE_ID = "claim"
ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
POS_RE = re.compile(r"^[1-9][0-9]*$")
NONNEG_RE = re.compile(r"^(0|[1-9][0-9]*)$")


class AppError(Exception):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


def emit(obj: dict, code: int = 0) -> None:
    sys.stdout.write(json.dumps(obj, separators=(",", ":"), sort_keys=False) + "\n")
    raise SystemExit(code)


def fail(code: str) -> None:
    emit({"error": code}, 1)


def crash_if(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


def require_env() -> tuple[str, str, int]:
    state_dir = os.environ.get("STATE_DIR")
    if not state_dir:
        raise AppError("bad_args")
    service = os.environ.get("SERVICE_URL")
    if service is None or service == "":
        raise AppError("bad_args")
    now_raw = os.environ.get("NOW_MS")
    if now_raw is None or now_raw == "":
        raise AppError("bad_time")
    if not NONNEG_RE.match(now_raw):
        raise AppError("bad_time")
    return state_dir, service.rstrip("/"), int(now_raw)


def store_path(state_dir: str) -> str:
    return os.path.join(state_dir, STORE_NAME)


def parse_id(value: str) -> str:
    if not ID_RE.match(value):
        raise AppError("bad_args")
    return value


def parse_pos(value: str) -> str:
    if not POS_RE.match(value):
        raise AppError("bad_amount")
    return value


def parse_nonneg(value: str) -> str:
    if not NONNEG_RE.match(value):
        raise AppError("bad_amount")
    return value


def as_int(fact: Optional[str]) -> Optional[int]:
    if fact is None:
        return None
    return int(fact, 10)


def kernel_for(state_dir: str) -> Kernel:
    binary = os.environ.get("IK_BINARY") or os.path.join(ROOT, "KIT", "bin", "ik")
    return Kernel(store_path(state_dir), binary=binary, session=True)


def map_kernel(err: Exception) -> AppError:
    klass = classify(err)
    if klass == "corrupt":
        return AppError("corrupt_state")
    if klass == "not_found":
        return AppError("bad_status")
    if isinstance(err, StoreNotFoundError):
        return AppError("bad_status")
    if isinstance(err, KernelError):
        return AppError("bad_status")
    return AppError("bad_status")


def overlay_path(state_dir: str) -> str:
    return os.path.join(state_dir, OVERLAY_NAME)


def read_overlay(state_dir: str) -> dict:
    path = overlay_path(state_dir)
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            obj = json.load(handle)
    except Exception:
        raise AppError("corrupt_state")
    if not isinstance(obj, dict):
        raise AppError("corrupt_state")
    return obj


def write_overlay(state_dir: str, data: dict) -> None:
    path = overlay_path(state_dir)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(data, handle, separators=(",", ":"))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def is_v2(agg: Optional[Aggregate]) -> bool:
    if agg is None:
        return True
    owner = agg.owner
    return int(owner.version) == 2


def load_agg(state_dir: str) -> Optional[Aggregate]:
    path = store_path(state_dir)
    if not os.path.exists(path):
        return None
    kernel = kernel_for(state_dir)
    try:
        v2 = kernel.machine(MACHINE_V2)
        shown = v2.show(AGGREGATE_ID)
    except Exception as err:
        klass = classify(err)
        if klass == "corrupt":
            raise AppError("corrupt_state")
        if klass == "not_found":
            return None
        if isinstance(err, StoreNotFoundError):
            return None
        shown = None
        show_err = err
    else:
        show_err = None
    if shown is None and show_err is not None:
        try:
            v1 = kernel.machine(MACHINE_V1)
            shown = v1.show(AGGREGATE_ID)
        except Exception as err:
            raise map_kernel(err)
    if shown is None:
        return None
    owner = shown.owner
    try:
        if int(owner.version) == 2:
            machine = kernel.machine(MACHINE_V2)
        else:
            machine = kernel.machine(MACHINE_V1)
        if machine.identity != owner:
            raise AppError("corrupt_state")
        return machine.show(AGGREGATE_ID)
    except AppError:
        raise
    except Exception as err:
        raise map_kernel(err)


def payment_of(agg: Optional[Aggregate]) -> str:
    if agg is None:
        return "none"
    if agg.state == "paid":
        return "paid"
    if agg.state == "paying":
        return "attempt_saved"
    return "none"


def public_status(agg: Optional[Aggregate]) -> str:
    if agg is None:
        return "none"
    if agg.state == "paying":
        return "approved"
    return agg.state if agg.state != "empty" else "none"


def fact(agg: Optional[Aggregate], name: str) -> Optional[str]:
    if agg is None:
        return None
    value = agg.facts.get(name)
    if value is None or value == "":
        return None
    return str(value)


def salvage_value(agg: Optional[Aggregate], state_dir: Optional[str] = None) -> int:
    raw = fact(agg, "salvage_cents")
    if raw is not None:
        return int(raw, 10)
    if agg is not None and not is_v2(agg) and state_dir:
        overlay = read_overlay(state_dir)
        if "salvage_cents" in overlay:
            return int(overlay["salvage_cents"])
    return 0


def salvage_is_set(agg: Optional[Aggregate], state_dir: Optional[str] = None) -> bool:
    if fact(agg, "salvage_cents") is not None:
        return True
    if agg is not None and not is_v2(agg) and state_dir:
        return "salvage_cents" in read_overlay(state_dir)
    return False


def denied_clock(agg: Optional[Aggregate], state_dir: Optional[str] = None) -> Optional[int]:
    raw = fact(agg, "denied_ms")
    if raw is not None:
        return int(raw, 10)
    if agg is not None and not is_v2(agg) and state_dir:
        overlay = read_overlay(state_dir)
        if "denied_ms" in overlay and overlay["denied_ms"] is not None:
            return int(overlay["denied_ms"])
    return None


def status_obj(agg: Optional[Aggregate], state_dir: Optional[str] = None) -> dict:
    appeal_used = as_int(fact(agg, "appeal_used"))
    if appeal_used is None:
        appeal_used = 0
    amount = as_int(fact(agg, "amount_cents"))
    if agg is not None and not is_v2(agg) and state_dir:
        overlay = read_overlay(state_dir)
        if overlay.get("payout_amount") is not None:
            amount = int(overlay["payout_amount"])
    return {
        "claim_id": fact(agg, "claim_id"),
        "policy_id": fact(agg, "policy_id"),
        "limit_cents": as_int(fact(agg, "limit_cents")),
        "appeal_window_ms": as_int(fact(agg, "appeal_window_ms")),
        "filed_ms": as_int(fact(agg, "filed_ms")),
        "assessed_cents": as_int(fact(agg, "assessed_cents")),
        "salvage_cents": salvage_value(agg, state_dir),
        "denied_ms": denied_clock(agg, state_dir),
        "appeal_used": appeal_used,
        "status": public_status(agg),
        "payment": payment_of(agg),
        "payout_id": fact(agg, "payout_id"),
        "amount_cents": amount,
    }


def payable_cents(agg: Aggregate) -> int:
    limit = as_int(fact(agg, "limit_cents"))
    assessed = as_int(fact(agg, "assessed_cents"))
    if limit is None or assessed is None:
        raise AppError("bad_status")
    return min(limit, assessed)


def amount_snapshot(agg: Aggregate, state_dir: str) -> int:
    return payable_cents(agg) - salvage_value(agg, state_dir)


def apply_cmd(agg: Aggregate, name: str, **args: Any) -> Aggregate:
    try:
        result = agg.command(name, **args)
    except Exception as err:
        raise map_kernel(err)
    if isinstance(result, HistoricalResult):
        shown = load_agg(os.environ["STATE_DIR"])
        if shown is None:
            raise AppError("bad_status")
        return shown
    return result


def payload_digest(payout_id: str, claim_id: str, amount_cents: int) -> str:
    body = json.dumps(
        {"amount_cents": amount_cents, "claim_id": claim_id, "payout_id": payout_id},
        separators=(",", ":"),
        sort_keys=True,
    )
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


def outcome_digest(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def http_json(method: str, url: str, payload: Optional[dict] = None) -> tuple[int, Optional[dict], Optional[bytes]]:
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["content-type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            raw = resp.read()
            status = resp.getcode()
    except urllib.error.HTTPError as err:
        raw = err.read() if err.fp is not None else b""
        return err.code, _decode_json(raw), raw
    except Exception:
        raise AppError("service_unavailable")
    parsed = _decode_json(raw)
    if parsed is None and method == "GET":
        raise AppError("service_unavailable")
    if parsed is None and status == 200:
        raise AppError("service_unavailable")
    return status, parsed, raw


def _decode_json(raw: bytes) -> Optional[dict]:
    if not raw:
        return None
    try:
        obj = json.loads(raw.decode("utf-8"))
    except Exception:
        return None
    if not isinstance(obj, dict):
        return None
    return obj


def payout_matches(body: dict, payout_id: str, claim_id: str, amount_cents: int) -> bool:
    try:
        amount = body.get("amount_cents")
        if isinstance(amount, str) and POS_RE.match(amount):
            amount = int(amount, 10)
        return (
            body.get("payout_id") == payout_id
            and body.get("claim_id") == claim_id
            and amount == amount_cents
        )
    except Exception:
        return False


def commit_paid(agg: Aggregate, raw: bytes) -> Aggregate:
    crash_if("after-accept-before-record")
    intent = agg.pending_intent
    if intent is not None:
        try:
            recorded = agg.record_effect_outcome(outcome_digest(raw), intent=intent)
        except Exception as err:
            raise map_kernel(err)
        if isinstance(recorded, HistoricalResult):
            shown = load_agg(os.environ["STATE_DIR"])
            if shown is None:
                raise AppError("bad_status")
            agg = shown
        else:
            agg = recorded
    if agg.state == "paying":
        agg = apply_cmd(agg, "complete_payout")
    crash_if("after-record-before-exit")
    return agg


def paid_obj(agg: Aggregate, extra: Optional[dict] = None) -> dict:
    amount = as_int(fact(agg, "amount_cents"))
    if not is_v2(agg):
        overlay = read_overlay(os.environ["STATE_DIR"])
        if overlay.get("payout_amount") is not None:
            amount = int(overlay["payout_amount"])
    body = {
        "claim_id": fact(agg, "claim_id"),
        "payout_id": fact(agg, "payout_id"),
        "amount_cents": amount,
        "status": "paid",
        "payment": "paid",
    }
    if extra:
        body.update(extra)
    return body


def do_file(args: list[str], now_ms: int, state_dir: str) -> dict:
    if len(args) != 4:
        raise AppError("bad_args")
    claim_id, policy_id, limit_cents, appeal_window_ms = args
    parse_id(claim_id)
    parse_id(policy_id)
    parse_pos(limit_cents)
    parse_nonneg(appeal_window_ms)
    existing = load_agg(state_dir)
    if existing is not None:
        raise AppError("already_open")
    try:
        machine = kernel_for(state_dir).machine(MACHINE_V2)
        result = machine.create_with(
            AGGREGATE_ID,
            {
                "name": "file",
                "args": {
                    "claim_id": claim_id,
                    "policy_id": policy_id,
                    "limit_cents": limit_cents,
                    "appeal_window_ms": appeal_window_ms,
                    "filed_ms": str(now_ms),
                    "appeal_used": "0",
                },
            },
        )
    except Exception as err:
        raise map_kernel(err)
    if isinstance(result, HistoricalResult):
        raise AppError("already_open")
    return {
        "claim_id": claim_id,
        "policy_id": policy_id,
        "limit_cents": int(limit_cents, 10),
        "appeal_window_ms": int(appeal_window_ms, 10),
        "filed_ms": now_ms,
        "status": "filed",
        "payment": "none",
        "payout_id": None,
    }


def do_assess(args: list[str], state_dir: str) -> dict:
    if len(args) != 1:
        raise AppError("bad_args")
    amount = parse_pos(args[0])
    agg = load_agg(state_dir)
    if agg is None or public_status(agg) != "filed" or payment_of(agg) != "none":
        raise AppError("bad_status")
    agg = apply_cmd(agg, "assess", assessed_cents=amount)
    return {
        "claim_id": fact(agg, "claim_id"),
        "assessed_cents": int(amount, 10),
        "status": "assessed",
        "payment": "none",
    }


def do_approve(args: list[str], state_dir: str) -> dict:
    if args:
        raise AppError("bad_args")
    agg = load_agg(state_dir)
    if agg is None or public_status(agg) != "assessed" or payment_of(agg) != "none":
        raise AppError("bad_status")
    amount = payable_cents(agg)
    agg = apply_cmd(agg, "approve", amount_cents=str(amount))
    return {
        "claim_id": fact(agg, "claim_id"),
        "status": "approved",
        "payment": "none",
        "amount_cents": amount,
    }


def do_deny(args: list[str], now_ms: int, state_dir: str) -> dict:
    if args:
        raise AppError("bad_args")
    agg = load_agg(state_dir)
    if agg is None or public_status(agg) != "assessed" or payment_of(agg) != "none":
        raise AppError("bad_status")
    if is_v2(agg):
        agg = apply_cmd(agg, "deny", denied_ms=str(now_ms))
    else:
        agg = apply_cmd(agg, "deny")
        overlay = read_overlay(state_dir)
        overlay["denied_ms"] = now_ms
        write_overlay(state_dir, overlay)
    return {"claim_id": fact(agg, "claim_id"), "status": "denied", "payment": "none"}


def do_appeal(args: list[str], now_ms: int, state_dir: str) -> dict:
    if args:
        raise AppError("bad_args")
    agg = load_agg(state_dir)
    if agg is None or public_status(agg) != "denied":
        raise AppError("bad_status")
    filed_ms = as_int(fact(agg, "filed_ms"))
    window = as_int(fact(agg, "appeal_window_ms"))
    if filed_ms is None or window is None:
        raise AppError("bad_status")
    denied_ms = denied_clock(agg, state_dir)
    if denied_ms is not None:
        deadline = denied_ms + window
    else:
        deadline = filed_ms + window
    if now_ms > deadline:
        raise AppError("appeal_closed")
    if (as_int(fact(agg, "appeal_used")) or 0) != 0:
        raise AppError("appeal_used")
    agg = apply_cmd(agg, "appeal", used="1")
    return {
        "claim_id": fact(agg, "claim_id"),
        "status": "assessed",
        "payment": "none",
        "appeal_used": 1,
    }


def do_payout(args: list[str], service: str, state_dir: str) -> dict:
    if args:
        raise AppError("bad_args")
    agg = load_agg(state_dir)
    if agg is None:
        raise AppError("bad_status")
    if agg.state == "paid":
        return paid_obj(agg)
    if agg.state == "paying":
        return recover_payout(agg, service, state_dir, first_lookup=True)
    if agg.state != "approved":
        raise AppError("bad_status")
    amount = amount_snapshot(agg, state_dir)
    if amount < 1:
        raise AppError("bad_amount")
    claim_id = fact(agg, "claim_id")
    if claim_id is None:
        raise AppError("bad_status")
    payout_id = secrets.token_hex(8)
    digest = payload_digest(payout_id, claim_id, amount)
    kwargs = {
        "payout_id": payout_id,
        "effect_id": payout_id,
        "payload_digest": digest,
        "idempotency_key": payout_id,
    }
    if is_v2(agg):
        kwargs["amount_cents"] = str(amount)
    agg = apply_cmd(agg, "save_payout", **kwargs)
    if not is_v2(agg):
        overlay = read_overlay(state_dir)
        overlay["payout_amount"] = amount
        write_overlay(state_dir, overlay)
    crash_if("after-payout-saved-before-request")
    return post_payout(agg, service, payout_id, claim_id, amount)


def recover_payout(agg: Aggregate, service: str, state_dir: str, first_lookup: bool) -> dict:
    payout_id = fact(agg, "payout_id")
    claim_id = fact(agg, "claim_id")
    amount = as_int(fact(agg, "amount_cents"))
    if not is_v2(agg):
        overlay = read_overlay(os.environ["STATE_DIR"])
        if overlay.get("payout_amount") is not None:
            amount = int(overlay["payout_amount"])
    if payout_id is None or claim_id is None or amount is None:
        raise AppError("bad_status")
    if first_lookup:
        status, body, raw = http_json("GET", service + "/v1/payouts/" + urllib.parse.quote(payout_id, safe=""))
        if status == 200:
            if body is None or not payout_matches(body, payout_id, claim_id, amount):
                raise AppError("lookup_conflict")
            agg = commit_paid(agg, raw or b"")
            return paid_obj(agg)
        if status == 404:
            return post_payout(agg, service, payout_id, claim_id, amount)
        if status >= 500:
            raise AppError("service_unavailable")
        raise AppError("service_unavailable")
    return post_payout(agg, service, payout_id, claim_id, amount)


def post_payout(agg: Aggregate, service: str, payout_id: str, claim_id: str, amount: int) -> dict:
    status, body, raw = http_json(
        "POST",
        service + "/v1/payouts",
        {"payout_id": payout_id, "claim_id": claim_id, "amount_cents": amount},
    )
    if status >= 500 or status == 0:
        raise AppError("service_unavailable")
    if status == 409:
        raise AppError("lookup_conflict")
    if status != 200 or body is None or not payout_matches(body, payout_id, claim_id, amount):
        if status == 200:
            raise AppError("lookup_conflict")
        raise AppError("service_unavailable")
    agg = commit_paid(agg, raw or b"")
    return paid_obj(agg)


def do_reconcile(args: list[str], service: str, state_dir: str) -> dict:
    if len(args) != 1:
        raise AppError("bad_args")
    wanted = parse_id(args[0])
    agg = load_agg(state_dir)
    if agg is None or fact(agg, "payout_id") is None:
        raise AppError("no_payout")
    payout_id = fact(agg, "payout_id")
    if payout_id != wanted:
        raise AppError("payout_mismatch")
    if agg.state == "paid":
        return paid_obj(agg, {"lookup": "paid"})
    claim_id = fact(agg, "claim_id")
    amount = as_int(fact(agg, "amount_cents"))
    if not is_v2(agg):
        overlay = read_overlay(state_dir)
        if overlay.get("payout_amount") is not None:
            amount = int(overlay["payout_amount"])
    if claim_id is None or amount is None:
        raise AppError("bad_status")
    status, body, raw = http_json("GET", service + "/v1/payouts/" + urllib.parse.quote(payout_id, safe=""))
    if status == 404:
        return {
            "lookup": "not_sent",
            "claim_id": claim_id,
            "payout_id": payout_id,
            "payment": "attempt_saved",
            "status": "approved",
        }
    if status == 200:
        if body is None or not payout_matches(body, payout_id, claim_id, amount):
            raise AppError("lookup_conflict")
        agg = commit_paid(agg, raw or b"")
        return paid_obj(agg, {"lookup": "paid"})
    raise AppError("service_unavailable")


def do_salvage(args: list[str], state_dir: str) -> dict:
    if len(args) != 1:
        raise AppError("bad_args")
    amount_raw = parse_nonneg(args[0])
    amount = int(amount_raw, 10)
    agg = load_agg(state_dir)
    if agg is None:
        raise AppError("bad_status")
    payment = payment_of(agg)
    status = public_status(agg)
    if payment == "paid" or payment == "attempt_saved":
        raise AppError("salvage_closed")
    if status == "denied":
        raise AppError("salvage_closed")
    if status not in ("assessed", "approved") or payment != "none":
        raise AppError("bad_status")
    payable = payable_cents(agg)
    if amount >= payable:
        raise AppError("bad_amount")
    if salvage_is_set(agg, state_dir):
        current = salvage_value(agg, state_dir)
        if current != amount:
            raise AppError("salvage_locked")
        return {
            "claim_id": fact(agg, "claim_id"),
            "status": status,
            "payment": "none",
            "salvage_cents": current,
        }
    if is_v2(agg):
        name = "salvage_approved" if status == "approved" else "salvage"
        agg = apply_cmd(agg, name, salvage_cents=amount_raw)
    else:
        overlay = read_overlay(state_dir)
        overlay["salvage_cents"] = amount
        write_overlay(state_dir, overlay)
    return {
        "claim_id": fact(agg, "claim_id"),
        "status": status,
        "payment": "none",
        "salvage_cents": amount,
    }


def do_callback(args: list[str], state_dir: str) -> dict:
    if len(args) != 1:
        raise AppError("bad_args")
    path = args[0]
    try:
        with open(path, "r", encoding="utf-8") as handle:
            raw = handle.read()
        obj = json.loads(raw)
    except Exception:
        raise AppError("bad_callback")
    if not isinstance(obj, dict):
        raise AppError("bad_callback")
    agg = load_agg(state_dir)
    return {"ignored": True, "status": public_status(agg), "payment": payment_of(agg)}


def main(argv: list[str]) -> None:
    if not argv:
        fail("bad_args")
    try:
        state_dir, service, now_ms = require_env()
        cmd = argv[0]
        rest = argv[1:]
        if cmd == "file":
            emit(do_file(rest, now_ms, state_dir))
        elif cmd == "assess":
            emit(do_assess(rest, state_dir))
        elif cmd == "approve":
            emit(do_approve(rest, state_dir))
        elif cmd == "deny":
            emit(do_deny(rest, now_ms, state_dir))
        elif cmd == "salvage":
            emit(do_salvage(rest, state_dir))
        elif cmd == "appeal":
            emit(do_appeal(rest, now_ms, state_dir))
        elif cmd == "payout":
            emit(do_payout(rest, service, state_dir))
        elif cmd == "reconcile":
            emit(do_reconcile(rest, service, state_dir))
        elif cmd == "status":
            emit(status_obj(load_agg(state_dir), state_dir))
        elif cmd == "callback":
            emit(do_callback(rest, state_dir))
        else:
            raise AppError("bad_args")
    except AppError as err:
        fail(err.code)


if __name__ == "__main__":
    main(sys.argv[1:])
