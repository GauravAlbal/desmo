import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdirSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const RUN = join(ROOT, "run");
const STUB = join(ROOT, "stub", "server.mjs");
const NODE = process.execPath;

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [STUB], { cwd: ROOT, stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    const onData = (d) => {
      buf += d.toString();
      const line = buf.split("\n").find((l) => l.trim().startsWith("{"));
      if (!line) return;
      child.stdout.off("data", onData);
      resolve({ child, ...JSON.parse(line) });
    };
    child.stdout.on("data", onData);
    child.on("error", reject);
  });
}

function runDesk(env, args) {
  return new Promise((resolve) => {
    const child = spawn(NODE, [RUN, ...args], {
      cwd: ROOT,
      env: { ...process.env, ...env },
      stdio: ["ignore", "pipe", "pipe"],
    });
    let out = "";
    let err = "";
    child.stdout.on("data", (d) => {
      out += d.toString();
    });
    child.stderr.on("data", (d) => {
      err += d.toString();
    });
    child.on("close", (code, signal) => {
      let json = null;
      const t = out.trim();
      if (t) {
        try {
          json = JSON.parse(t);
        } catch {
          json = { parse_error: t };
        }
      }
      resolve({ code, signal, json, out, err });
    });
  });
}

async function fault(control, body) {
  await fetch(`${control}/fault`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function effects(control) {
  const r = await fetch(`${control}/effects`);
  return r.json();
}

function envFor(stateDir, service) {
  return { STATE_DIR: stateDir, SERVICE_URL: service, NOW_MS: "0" };
}

test("happy path stock reserve start complete and restart", async () => {
  const stub = await startStub();
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  const env = envFor(dir, stub.service_url);
  writeFileSync(join(dir, "unrelated.txt"), "keep-me");
  const set = await runDesk(env, ["stock-set", "PAD", "4"]);
  assert.equal(set.code, 0);
  assert.equal(set.json.qty, 4);
  const open = await runDesk(env, ["open", "WO1", "VIN1"]);
  assert.equal(open.code, 0);
  assert.equal(open.json.status, "opened");
  const again = await runDesk(env, ["open", "WO2", "VIN2"]);
  assert.equal(again.json.error, "already_open");
  const restock = await runDesk(env, ["stock-set", "PAD", "9"]);
  assert.equal(restock.json.error, "already_stocked");
  const short = await runDesk(env, ["reserve", "PAD", "9"]);
  assert.equal(short.json.error, "insufficient_stock");
  const res = await runDesk(env, ["reserve", "PAD", "2"]);
  assert.equal(res.code, 0);
  assert.equal(res.json.on_hand, 2);
  const start = await runDesk(env, ["start"]);
  assert.equal(start.json.status, "started");
  const unmarked = await runDesk(env, ["complete"]);
  assert.equal(unmarked.json.error, "usage_unmarked");
  const tooMuch = await runDesk(env, ["mark-used", "9"]);
  assert.equal(tooMuch.json.error, "used_qty_invalid");
  const mark = await runDesk(env, ["mark-used", "2"]);
  assert.equal(mark.code, 0);
  assert.equal(mark.json.used_qty, 2);
  assert.equal(mark.json.used_marked, 1);
  const sameMark = await runDesk(env, ["mark-used", "2"]);
  assert.equal(sameMark.code, 0);
  const other = await runDesk(env, ["mark-used", "1"]);
  assert.equal(other.json.error, "already_marked");
  const done = await runDesk(env, ["complete"]);
  assert.equal(done.json.status, "completed");
  assert.equal(done.json.used_qty, 2);
  assert.equal(done.json.restocked_qty, 0);
  assert.equal(done.json.shelf.PAD, 2);
  const st = await runDesk(env, ["status"]);
  assert.equal(st.json.status, "completed");
  assert.equal(st.json.used_marked, 1);
  assert.equal(st.json.used_qty, 2);
  assert.equal(st.json.wo_id, "WO1");
  assert.equal(readFileSync(join(dir, "unrelated.txt"), "utf8"), "keep-me");
  stub.child.kill("SIGKILL");
});

test("cancel restocks reserved line; empty status shape", async () => {
  const stub = await startStub();
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  const env = envFor(dir, stub.service_url);
  const empty = await runDesk(env, ["status"]);
  assert.equal(empty.code, 0);
  assert.equal(empty.json.status, "none");
  assert.equal(empty.json.wo_id, null);
  assert.deepEqual(empty.json.shelf, {});
  await runDesk(env, ["stock-set", "OIL", "3"]);
  await runDesk(env, ["open", "WO9", "VIN9"]);
  await runDesk(env, ["reserve", "OIL", "1"]);
  const c = await runDesk(env, ["cancel"]);
  assert.equal(c.json.status, "cancelled");
  assert.equal(c.json.shelf.OIL, 3);
  const bad = await runDesk(env, ["start"]);
  assert.equal(bad.json.error, "bad_status");
  stub.child.kill("SIGKILL");
});

test("order-part received once; repeat is no-op", async () => {
  const stub = await startStub();
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  const env = envFor(dir, stub.service_url);
  await runDesk(env, ["open", "WO1", "VIN1"]);
  const first = await runDesk(env, ["order-part", "BOLT", "5"]);
  assert.equal(first.code, 0);
  assert.equal(first.json.payment, "received");
  assert.equal(first.json.on_hand, 5);
  const e1 = await effects(stub.control_url);
  assert.equal(e1.count, 1);
  const second = await runDesk(env, ["order-part", "BOLT", "5"]);
  assert.equal(second.code, 0);
  assert.equal(second.json.payment, "received");
  const e2 = await effects(stub.control_url);
  assert.equal(e2.count, 1);
  stub.child.kill("SIGKILL");
});

test("crash after-purchase-saved-before-request then recover same id", async () => {
  const stub = await startStub();
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  const env = envFor(dir, stub.service_url);
  await runDesk(env, ["open", "WO1", "VIN1"]);
  const crashed = await runDesk(
    { ...env, CRASH_AT: "after-purchase-saved-before-request" },
    ["order-part", "NUT", "2"],
  );
  assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
  const st = await runDesk(env, ["status"]);
  assert.equal(st.json.payment, "attempt_saved");
  assert.ok(st.json.purchase_id);
  const e0 = await effects(stub.control_url);
  assert.equal(e0.count, 0);
  const retry = await runDesk(env, ["order-part", "NUT", "2"]);
  assert.equal(retry.code, 0);
  assert.equal(retry.json.payment, "received");
  assert.equal(retry.json.purchase_id, st.json.purchase_id);
  const e1 = await effects(stub.control_url);
  assert.equal(e1.count, 1);
  stub.child.kill("SIGKILL");
});

test("crash after-accept-before-record adopts by lookup", async () => {
  const stub = await startStub();
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  const env = envFor(dir, stub.service_url);
  await runDesk(env, ["open", "WO1", "VIN1"]);
  const crashed = await runDesk(
    { ...env, CRASH_AT: "after-accept-before-record" },
    ["order-part", "WASHER", "3"],
  );
  assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
  const st = await runDesk(env, ["status"]);
  assert.equal(st.json.payment, "attempt_saved");
  const e1 = await effects(stub.control_url);
  assert.equal(e1.count, 1);
  const retry = await runDesk(env, ["order-part", "WASHER", "3"]);
  assert.equal(retry.json.payment, "received");
  const e2 = await effects(stub.control_url);
  assert.equal(e2.count, 1);
  stub.child.kill("SIGKILL");
});

test("crash after-record-before-exit leaves received; later order-part no-op", async () => {
  const stub = await startStub();
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  const env = envFor(dir, stub.service_url);
  await runDesk(env, ["open", "WO1", "VIN1"]);
  const crashed = await runDesk(
    { ...env, CRASH_AT: "after-record-before-exit" },
    ["order-part", "CLIP", "1"],
  );
  assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
  const st = await runDesk(env, ["status"]);
  assert.equal(st.json.payment, "received");
  const e1 = await effects(stub.control_url);
  const retry = await runDesk(env, ["order-part", "CLIP", "1"]);
  assert.equal(retry.json.payment, "received");
  const e2 = await effects(stub.control_url);
  assert.equal(e2.count, e1.count);
  stub.child.kill("SIGKILL");
});

test("dropped reply then reconcile adopts received without POST", async () => {
  const stub = await startStub();
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  const env = envFor(dir, stub.service_url);
  await runDesk(env, ["open", "WO1", "VIN1"]);
  await fault(stub.control_url, { drop_reply: true });
  const dropped = await runDesk(env, ["order-part", "HOSE", "4"]);
  assert.equal(dropped.json.error, "service_unavailable");
  await fault(stub.control_url, { drop_reply: false });
  const st = await runDesk(env, ["status"]);
  assert.equal(st.json.payment, "attempt_saved");
  const rec = await runDesk(env, ["reconcile", st.json.purchase_id]);
  assert.equal(rec.code, 0);
  assert.equal(rec.json.lookup, "received");
  assert.equal(rec.json.payment, "received");
  const e1 = await effects(stub.control_url);
  assert.equal(e1.count, 1);
  stub.child.kill("SIGKILL");
});

test("reconcile not_sent and mismatch; 5xx stays attempt_saved", async () => {
  const stub = await startStub();
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  const env = envFor(dir, stub.service_url);
  await runDesk(env, ["open", "WO1", "VIN1"]);
  const none = await runDesk(env, ["reconcile", "p-none"]);
  assert.equal(none.json.error, "no_purchase");
  await fault(stub.control_url, { error_status: 503 });
  const fail = await runDesk(env, ["order-part", "SEAL", "1"]);
  assert.equal(fail.json.error, "service_unavailable");
  await fault(stub.control_url, { error_status: 0 });
  const st = await runDesk(env, ["status"]);
  assert.equal(st.json.payment, "attempt_saved");
  const e0 = await effects(stub.control_url);
  assert.equal(e0.count, 0);
  const wrong = await runDesk(env, ["reconcile", "other-id"]);
  assert.equal(wrong.json.error, "purchase_mismatch");
  const ns = await runDesk(env, ["reconcile", st.json.purchase_id]);
  assert.equal(ns.json.lookup, "not_sent");
  assert.equal(ns.json.payment, "attempt_saved");
  stub.child.kill("SIGKILL");
});

test("callback ignored; refusals do not rewrite unrelated bytes", async () => {
  const stub = await startStub();
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  const env = envFor(dir, stub.service_url);
  writeFileSync(join(dir, "side.bin"), Buffer.from([1, 2, 3, 4]));
  await runDesk(env, ["open", "WO1", "VIN1"]);
  const cbPath = join(dir, "cb.json");
  writeFileSync(cbPath, JSON.stringify({ wo_id: "WO9", status: "completed" }));
  const cb = await runDesk(env, ["callback", cbPath]);
  assert.equal(cb.code, 0);
  const st = await runDesk(env, ["status"]);
  assert.equal(st.json.status, "opened");
  const bad = await runDesk(env, ["callback", join(dir, "missing.json")]);
  assert.equal(bad.json.error, "bad_callback");
  assert.deepEqual(readFileSync(join(dir, "side.bin")), Buffer.from([1, 2, 3, 4]));
  stub.child.kill("SIGKILL");
});

test("mark-used leftover restock and not_started", async () => {
  const stub = await startStub();
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  const env = envFor(dir, stub.service_url);
  const none = await runDesk(env, ["mark-used", "0"]);
  assert.equal(none.json.error, "not_started");
  await runDesk(env, ["stock-set", "PAD", "5"]);
  await runDesk(env, ["open", "WO1", "VIN1"]);
  const opened = await runDesk(env, ["mark-used", "1"]);
  assert.equal(opened.json.error, "not_started");
  await runDesk(env, ["reserve", "PAD", "3"]);
  const reserved = await runDesk(env, ["mark-used", "1"]);
  assert.equal(reserved.json.error, "not_started");
  await runDesk(env, ["start"]);
  const mark = await runDesk(env, ["mark-used", "1"]);
  assert.equal(mark.code, 0);
  assert.equal(mark.json.used_qty, 1);
  const st = await runDesk(env, ["status"]);
  assert.equal(st.json.used_marked, 1);
  assert.equal(st.json.used_qty, 1);
  const done = await runDesk(env, ["complete"]);
  assert.equal(done.json.restocked_qty, 2);
  assert.equal(done.json.used_qty, 1);
  assert.equal(done.json.shelf.PAD, 4);
  const second = await runDesk(env, ["complete"]);
  assert.equal(second.json.error, "bad_status");
  const doneMark = await runDesk(env, ["mark-used", "1"]);
  assert.equal(doneMark.json.error, "already_completed");
  stub.child.kill("SIGKILL");
});

test("missing env and bad identifiers", async () => {
  const stub = await startStub();
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  const noUrl = await runDesk({ STATE_DIR: dir, NOW_MS: "0" }, ["status"]);
  assert.equal(noUrl.json.error, "bad_args");
  const noNow = await runDesk({ STATE_DIR: dir, SERVICE_URL: stub.service_url }, ["status"]);
  assert.equal(noNow.json.error, "bad_args");
  const env = envFor(dir, stub.service_url);
  const id = await runDesk(env, ["open", "bad id", "VIN"]);
  assert.equal(id.json.error, "bad_args");
  const qty = await runDesk(env, ["stock-set", "SKU", "01"]);
  assert.equal(qty.json.error, "bad_qty");
  stub.child.kill("SIGKILL");
});
