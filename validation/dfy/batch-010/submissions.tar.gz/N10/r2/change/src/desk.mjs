import { createHash, randomBytes } from "node:crypto";
import { closeSync, existsSync, fsyncSync, openSync, readFileSync, unlinkSync, writeSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Kernel,
  StoreNotFoundError,
  classify,
} from "@ikaros/runtime";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const MACHINE_V1 = join(ROOT, "machines", "shop_v1.ik.toml");
const MACHINE_V2 = join(ROOT, "machines", "shop.ik.toml");
const AGG = "shop";
const USED_FILE = "shop.used.json";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const STATUS_MAP = { idle: "none" };

function fail(code) {
  process.stdout.write(JSON.stringify({ error: code }) + "\n");
  process.exit(1);
}

function ok(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(0);
}

function crash(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

function parseNow(raw) {
  if (raw === undefined || raw === "") fail("bad_args");
  if (!/^(0|[1-9][0-9]*)$/.test(raw)) fail("bad_args");
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0) fail("bad_args");
  return n;
}

function parseId(s) {
  if (typeof s !== "string" || !ID_RE.test(s)) fail("bad_args");
  return s;
}

function parseQty(s, min, max) {
  if (typeof s !== "string" || !/^(0|[1-9][0-9]*)$/.test(s)) fail("bad_qty");
  const n = Number(s);
  if (!Number.isSafeInteger(n) || n < min || n > max) fail("bad_qty");
  return n;
}

function parseShelf(raw) {
  let v;
  try {
    v = JSON.parse(raw);
  } catch {
    fail("corrupt_state");
  }
  if (v === null || typeof v !== "object" || Array.isArray(v)) fail("corrupt_state");
  const out = {};
  for (const [k, q] of Object.entries(v)) {
    if (!ID_RE.test(k) || !Number.isInteger(q) || q < 0 || q > 1_000_000) fail("corrupt_state");
    out[k] = q;
  }
  return out;
}

function shelfJson(shelf) {
  const keys = Object.keys(shelf).sort();
  const o = {};
  for (const k of keys) o[k] = shelf[k];
  return JSON.stringify(o);
}

function facts(a) {
  const s = a.state && typeof a.state === "object" ? a.state : {};
  return s;
}

function pubStatus(state) {
  return STATUS_MAP[state] || state;
}

function onHandOf(shelf, sku) {
  if (!sku || !(sku in shelf)) return null;
  return shelf[sku];
}

function usedOverlayPath() {
  return join(process.env.STATE_DIR, USED_FILE);
}

function readUsedOverlay() {
  const p = usedOverlayPath();
  if (!existsSync(p)) return null;
  try {
    const v = JSON.parse(readFileSync(p, "utf8"));
    if (!v || typeof v !== "object") return null;
    if (!Number.isInteger(v.used_qty) || (v.used_marked !== 0 && v.used_marked !== 1)) return null;
    return { used_qty: v.used_qty, used_marked: v.used_marked };
  } catch {
    fail("corrupt_state");
  }
}

function writeUsedOverlay(used_qty, used_marked) {
  const p = usedOverlayPath();
  const tmp = p + ".tmp";
  const buf = Buffer.from(JSON.stringify({ used_qty, used_marked }) + "\n");
  const fd = openSync(tmp, "w");
  try {
    writeSync(fd, buf);
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
  const dest = openSync(p, "w");
  try {
    writeSync(dest, buf);
    fsyncSync(dest);
  } finally {
    closeSync(dest);
  }
}

function clearUsedOverlay() {
  const p = usedOverlayPath();
  if (existsSync(p)) unlinkSync(p);
}

function markView(a) {
  const f = facts(a);
  const st = a.namedState();
  if (st === "completed") {
    const reserved = f.reserved_qty ?? 0;
    let used = f.used_qty ?? 0;
    if ((f.used_marked ?? 0) !== 1 && used === 0) used = reserved;
    return { used_qty: used, used_marked: 1 };
  }
  if ((f.used_marked ?? 0) === 1) {
    return { used_qty: f.used_qty ?? 0, used_marked: 1 };
  }
  const ov = readUsedOverlay();
  if (ov && st === "started") return ov;
  return { used_qty: f.used_qty ?? 0, used_marked: f.used_marked ?? 0 };
}

function statusBody(a) {
  if (!a) {
    return {
      wo_id: null,
      vin: null,
      sku: null,
      reserved_qty: 0,
      used_qty: 0,
      used_marked: 0,
      status: "none",
      payment: "none",
      purchase_id: null,
      purchase_sku: null,
      purchase_qty: 0,
      shelf: {},
      on_hand: null,
    };
  }
  const f = facts(a);
  const st = pubStatus(a.namedState());
  const shelf = parseShelf(f.shelf_json ?? "{}");
  const sku = f.sku ?? null;
  const mark = markView(a);
  return {
    wo_id: f.wo_id ?? null,
    vin: f.vin ?? null,
    sku,
    reserved_qty: f.reserved_qty ?? 0,
    used_qty: mark.used_qty,
    used_marked: mark.used_marked,
    status: st,
    payment: f.payment ?? "none",
    purchase_id: f.purchase_id ?? null,
    purchase_sku: f.purchase_sku ?? null,
    purchase_qty: f.purchase_qty ?? 0,
    shelf,
    on_hand: sku && (st === "reserved" || st === "started" || st === "completed" || st === "cancelled")
      ? onHandOf(shelf, sku)
      : sku
        ? onHandOf(shelf, sku)
        : null,
  };
}

function kernelError(e) {
  if (e instanceof StoreNotFoundError) return "corrupt_state";
  try {
    const c = classify(e);
    if (c === "corrupt") return "corrupt_state";
  } catch {
    /* ignore */
  }
  if (e && (e.code === "IK_STORE_CORRUPT" || e.rule === "store.corrupt")) return "corrupt_state";
  return null;
}

async function openKernel() {
  const stateDir = process.env.STATE_DIR;
  if (!stateDir) fail("bad_args");
  const store = join(stateDir, "shop.ik.sqlite");
  const kernel = new Kernel(store);
  try {
    const v1 = await kernel.machine(MACHINE_V1);
    const v2 = await kernel.machine(MACHINE_V2);
    return { kernel, v1, v2, machine: v2, store };
  } catch (e) {
    const mapped = kernelError(e);
    if (mapped) fail(mapped);
    throw e;
  }
}

function ownerMachine(ctx, agg) {
  if (!agg) return ctx.v2;
  const own = agg.owner;
  if (own && own.equals(ctx.v1.identity)) return ctx.v1;
  if (own && own.equals(ctx.v2.identity)) return ctx.v2;
  if (own && Number(own.version) === 1) return ctx.v1;
  return ctx.v2;
}

async function showShop(machine) {
  try {
    return await machine.show(AGG);
  } catch (e) {
    if (e instanceof StoreNotFoundError) return null;
    try {
      const c = classify(e);
      if (c === "not_found") return null;
      if (c === "corrupt") fail("corrupt_state");
    } catch {
      /* ignore */
    }
    if (e && e.code === "IK_STORE_CORRUPT") fail("corrupt_state");
    throw e;
  }
}

async function loadShop(ctx) {
  const via = await showShop(ctx.v2);
  if (!via) return { agg: null, machine: ctx.v2 };
  const machine = ownerMachine(ctx, via);
  if (machine === ctx.v2) return { agg: via, machine };
  const agg = await showShop(machine);
  return { agg: agg ?? via, machine };
}

async function ensureShop(ctx, loaded) {
  if (loaded.agg) return loaded;
  const agg = await ctx.v2.create(AGG);
  return { agg, machine: ctx.v2 };
}

function digestPayload(obj) {
  return createHash("sha256").update(JSON.stringify(obj)).digest("hex");
}

function newPurchaseId() {
  return randomBytes(16).toString("hex");
}

function serviceBase() {
  const u = process.env.SERVICE_URL;
  if (!u) fail("bad_args");
  return u.replace(/\/+$/, "");
}

async function httpJson(method, url, body) {
  try {
    const res = await fetch(url, {
      method,
      headers: body ? { "content-type": "application/json", connection: "close" } : { connection: "close" },
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    if (text === undefined || text === "") {
      const err = new Error("incomplete");
      err.incomplete = true;
      throw err;
    }
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      const err = new Error("incomplete");
      err.incomplete = true;
      throw err;
    }
    return { status: res.status, json, text };
  } catch (e) {
    if (e && e.incomplete) throw e;
    const err = new Error("transport");
    err.transport = true;
    throw err;
  }
}

function matchPurchase(body, snap) {
  return (
    body &&
    body.purchase_id === snap.purchase_id &&
    body.wo_id === snap.wo_id &&
    body.sku === snap.sku &&
    body.qty === snap.qty
  );
}

function snapOf(f) {
  return {
    purchase_id: f.purchase_id,
    wo_id: f.wo_id,
    sku: f.purchase_sku,
    qty: f.purchase_qty,
  };
}

function receivedObject(f, shelf) {
  const sku = f.purchase_sku;
  return {
    wo_id: f.wo_id,
    purchase_id: f.purchase_id,
    sku,
    qty: f.purchase_qty,
    payment: "received",
    on_hand: shelf[sku] ?? 0,
    status: "opened",
  };
}

async function maybeRecord(agg, outcomeText) {
  if (!agg.pendingIntent) return agg;
  try {
    const digest = createHash("sha256").update(outcomeText).digest("hex");
    const next = await agg.recordEffectOutcome(digest, { intent: agg.pendingIntent });
    return next && typeof next.namedState === "function" ? next : agg;
  } catch {
    return agg;
  }
}

async function applyReceive(machine, agg, qty, sku) {
  const f = facts(agg);
  const shelf = parseShelf(f.shelf_json ?? "{}");
  shelf[sku] = (shelf[sku] ?? 0) + qty;
  const next = await agg.command("receive_stock", {
    shelf_json: shelfJson(shelf),
    payment: "received",
  });
  return next;
}

async function adoptLookup(machine, agg, json, text) {
  const f = facts(agg);
  const snap = snapOf(f);
  if (!matchPurchase(json, snap)) fail("lookup_conflict");
  let cur = await maybeRecord(agg, text);
  if (facts(cur).payment === "received") {
    return { agg: cur, shelf: parseShelf(facts(cur).shelf_json ?? "{}") };
  }
  cur = await applyReceive(machine, cur, snap.qty, snap.sku);
  return { agg: cur, shelf: parseShelf(facts(cur).shelf_json ?? "{}") };
}

async function lookupThen(machine, agg, { postOn404 }) {
  const f = facts(agg);
  const id = f.purchase_id;
  const base = serviceBase();
  let got;
  try {
    got = await httpJson("GET", `${base}/v1/purchases/${encodeURIComponent(id)}`);
  } catch {
    fail("service_unavailable");
  }
  if (got.status === 200) {
    return adoptLookup(machine, agg, got.json, got.text);
  }
  if (got.status === 404) {
    if (!postOn404) return { not_sent: true, agg };
    return postSaved(machine, agg);
  }
  fail("service_unavailable");
}

async function postSaved(machine, agg) {
  const f = facts(agg);
  const snap = snapOf(f);
  const base = serviceBase();
  let posted;
  try {
    posted = await httpJson("POST", `${base}/v1/purchases`, snap);
  } catch {
    fail("service_unavailable");
  }
  if (posted.status >= 500) fail("service_unavailable");
  if (posted.status === 409) fail("lookup_conflict");
  if (posted.status !== 200) fail("service_unavailable");
  if (!matchPurchase(posted.json, snap)) fail("lookup_conflict");
  crash("after-accept-before-record");
  let cur = await maybeRecord(agg, posted.text);
  cur = await applyReceive(machine, cur, snap.qty, snap.sku);
  return { agg: cur, shelf: parseShelf(facts(cur).shelf_json ?? "{}") };
}

async function main() {
  parseNow(process.env.NOW_MS);
  if (!process.env.SERVICE_URL) fail("bad_args");
  if (!process.env.STATE_DIR) fail("bad_args");

  const [cmd, ...args] = process.argv.slice(2);
  if (!cmd) fail("bad_args");

  const ctx = await openKernel();

  if (cmd === "status") {
    if (args.length) fail("bad_args");
    const { agg } = await loadShop(ctx);
    ok(statusBody(agg));
  }

  if (cmd === "stock-set") {
    if (args.length !== 2) fail("bad_args");
    const sku = parseId(args[0]);
    const qty = parseQty(args[1], 0, 1_000_000);
    let loaded = await loadShop(ctx);
    const st = loaded.agg ? loaded.agg.namedState() : "idle";
    if (!["idle", "opened", "reserved", "started"].includes(st)) fail("bad_status");
    loaded = await ensureShop(ctx, loaded);
    const agg = loaded.agg;
    const shelf = parseShelf(facts(agg).shelf_json ?? "{}");
    if (Object.prototype.hasOwnProperty.call(shelf, sku)) fail("already_stocked");
    shelf[sku] = qty;
    const next = await agg.command("stock_set", { shelf_json: shelfJson(shelf) });
    ok({ sku, qty, shelf: parseShelf(facts(next).shelf_json) });
  }

  if (cmd === "open") {
    if (args.length !== 2) fail("bad_args");
    const wo_id = parseId(args[0]);
    const vin = parseId(args[1]);
    let loaded = await loadShop(ctx);
    if (loaded.agg && loaded.agg.namedState() !== "idle") fail("already_open");
    loaded = await ensureShop(ctx, loaded);
    const next = await loaded.agg.command("open", { wo_id, vin });
    ok({
      wo_id,
      vin,
      status: "opened",
      payment: "none",
      purchase_id: null,
    });
    void next;
  }

  if (cmd === "reserve") {
    if (args.length !== 2) fail("bad_args");
    const sku = parseId(args[0]);
    const qty = parseQty(args[1], 1, 100);
    const { agg } = await loadShop(ctx);
    if (!agg) fail("bad_status");
    const st = agg.namedState();
    const f = facts(agg);
    if (st !== "opened") fail("bad_status");
    if (f.payment === "attempt_saved") fail("order_pending");
    if (f.sku) fail("already_reserved");
    const shelf = parseShelf(f.shelf_json ?? "{}");
    if (!Object.prototype.hasOwnProperty.call(shelf, sku) || shelf[sku] < qty) fail("insufficient_stock");
    shelf[sku] -= qty;
    const next = await agg.command("reserve", { sku, qty, shelf_json: shelfJson(shelf) });
    const nf = facts(next);
    const ns = parseShelf(nf.shelf_json);
    ok({
      wo_id: nf.wo_id,
      sku,
      reserved_qty: qty,
      on_hand: ns[sku] ?? 0,
      status: "reserved",
    });
  }

  if (cmd === "start") {
    if (args.length) fail("bad_args");
    const { agg } = await loadShop(ctx);
    if (!agg || agg.namedState() !== "reserved") fail("bad_status");
    const next = await agg.command("start");
    ok({ wo_id: facts(next).wo_id, status: "started" });
  }

  if (cmd === "mark-used") {
    if (args.length !== 1) fail("bad_args");
    const qty = parseQty(args[0], 0, 1_000_000);
    const { agg, machine } = await loadShop(ctx);
    if (!agg || agg.namedState() === "idle") fail("not_started");
    const st = agg.namedState();
    if (st === "completed") fail("already_completed");
    if (st !== "started") fail("not_started");
    const f = facts(agg);
    const reserved = f.reserved_qty ?? 0;
    if (qty > reserved) fail("used_qty_invalid");
    const mark = markView(agg);
    if (mark.used_marked === 1) {
      if (qty === mark.used_qty) {
        ok({
          wo_id: f.wo_id,
          sku: f.sku,
          reserved_qty: reserved,
          used_qty: qty,
          used_marked: 1,
          status: "started",
        });
      }
      fail("already_marked");
    }
    if (machine === ctx.v2) {
      await agg.command("mark_used", { used_qty: qty, used_marked: 1 });
    } else {
      writeUsedOverlay(qty, 1);
    }
    ok({
      wo_id: f.wo_id,
      sku: f.sku,
      reserved_qty: reserved,
      used_qty: qty,
      used_marked: 1,
      status: "started",
    });
  }

  if (cmd === "complete") {
    if (args.length) fail("bad_args");
    const loaded = await loadShop(ctx);
    const agg = loaded.agg;
    if (!agg || agg.namedState() !== "started") fail("bad_status");
    const f = facts(agg);
    const mark = markView(agg);
    if (mark.used_marked !== 1) fail("usage_unmarked");
    const reserved = f.reserved_qty ?? 0;
    const used = mark.used_qty;
    const restocked_qty = reserved - used;
    const shelf = parseShelf(f.shelf_json ?? "{}");
    const sku = f.sku;
    shelf[sku] = (shelf[sku] ?? 0) + restocked_qty;
    const sj = shelfJson(shelf);
    let next;
    if (loaded.machine === ctx.v2) {
      next = await agg.command("complete", { shelf_json: sj });
    } else {
      const tx = await agg.transaction([
        { name: "stock_set", args: { shelf_json: sj } },
        { name: "complete", args: { used_qty: used } },
      ]);
      next = tx && typeof tx.namedState === "function" ? tx : await loaded.machine.show(AGG);
    }
    clearUsedOverlay();
    const nf = facts(next);
    ok({
      wo_id: nf.wo_id,
      status: "completed",
      sku: nf.sku,
      reserved_qty: nf.reserved_qty,
      used_qty: used,
      restocked_qty,
      shelf: parseShelf(nf.shelf_json),
    });
  }

  if (cmd === "cancel") {
    if (args.length) fail("bad_args");
    const { agg } = await loadShop(ctx);
    if (!agg) fail("bad_status");
    const st = agg.namedState();
    const f = facts(agg);
    if (st === "completed" || st === "cancelled" || st === "idle") fail("bad_status");
    if (f.payment === "attempt_saved") fail("order_started");
    let next;
    if (st === "opened") {
      next = await agg.command("cancel_open");
    } else if (st === "reserved" || st === "started") {
      const shelf = parseShelf(f.shelf_json ?? "{}");
      const sku = f.sku;
      shelf[sku] = (shelf[sku] ?? 0) + f.reserved_qty;
      const name = st === "reserved" ? "cancel_reserved" : "cancel_started";
      next = await agg.command(name, { shelf_json: shelfJson(shelf) });
    } else {
      fail("bad_status");
    }
    clearUsedOverlay();
    const nf = facts(next);
    ok({ wo_id: nf.wo_id, status: "cancelled", shelf: parseShelf(nf.shelf_json) });
  }

  if (cmd === "order-part") {
    if (args.length !== 2) fail("bad_args");
    const sku = parseId(args[0]);
    const qty = parseQty(args[1], 0, 1_000_000);
    const loaded = await loadShop(ctx);
    const agg = loaded.agg;
    if (!agg) fail("bad_status");
    const st = agg.namedState();
    if (st !== "opened") fail("bad_status");
    const f = facts(agg);
    if (f.payment === "received") {
      const shelf = parseShelf(f.shelf_json ?? "{}");
      ok(receivedObject(f, shelf));
    }
    if (f.payment === "attempt_saved") {
      const result = await lookupThen(loaded.machine, agg, { postOn404: true });
      crash("after-record-before-exit");
      ok(receivedObject(facts(result.agg), result.shelf));
    }
    const purchase_id = newPurchaseId();
    const payload = {
      purchase_id,
      wo_id: f.wo_id,
      sku,
      qty,
    };
    const payload_digest = digestPayload(payload);
    const saved = await agg.command("save_purchase", {
      effect_id: purchase_id,
      payload_digest,
      idempotency_key: purchase_id,
      purchase_id,
      sku,
      qty,
      payment: "attempt_saved",
    });
    crash("after-purchase-saved-before-request");
    const result = await postSaved(loaded.machine, saved);
    crash("after-record-before-exit");
    ok(receivedObject(facts(result.agg), result.shelf));
  }

  if (cmd === "reconcile") {
    if (args.length !== 1) fail("bad_args");
    const purchase_id = parseId(args[0]);
    const loaded = await loadShop(ctx);
    const agg = loaded.agg;
    if (!agg) fail("no_purchase");
    const f = facts(agg);
    if (!f.purchase_id) fail("no_purchase");
    if (f.purchase_id !== purchase_id) fail("purchase_mismatch");
    if (f.payment === "received") {
      const shelf = parseShelf(f.shelf_json ?? "{}");
      ok({ ...receivedObject(f, shelf), lookup: "received" });
    }
    const result = await lookupThen(loaded.machine, agg, { postOn404: false });
    if (result.not_sent) {
      ok({
        lookup: "not_sent",
        wo_id: f.wo_id,
        purchase_id: f.purchase_id,
        payment: "attempt_saved",
        status: "opened",
      });
    }
    crash("after-record-before-exit");
    ok({ ...receivedObject(facts(result.agg), result.shelf), lookup: "received" });
  }

  if (cmd === "callback") {
    if (args.length !== 1) fail("bad_args");
    const path = args[0];
    let raw;
    try {
      raw = readFileSync(path, "utf8");
    } catch {
      fail("bad_callback");
    }
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      fail("bad_callback");
    }
    if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) fail("bad_callback");
    await loadShop(ctx);
    ok({ ignored: true });
  }

  fail("bad_args");
}

main().catch((e) => {
  const mapped = kernelError(e);
  if (mapped) fail(mapped);
  fail("corrupt_state");
});
