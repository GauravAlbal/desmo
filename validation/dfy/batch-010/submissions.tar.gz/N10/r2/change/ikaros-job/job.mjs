import { Kernel } from "@ikaros/runtime";

const kernel = new Kernel(".state/kernel.db");
const jobs = await kernel.machine("job.ik.toml");
const job = await jobs.create("job-1");
const running = await job.command("start");
console.log(running.namedState());
