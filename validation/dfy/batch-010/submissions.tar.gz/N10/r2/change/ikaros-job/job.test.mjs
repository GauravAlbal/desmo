import assert from "node:assert/strict";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import { Kernel, StaleCapabilityError } from "@ikaros/runtime";

test("start commits", async () => {
  const dir = mkdtempSync(join(tmpdir(), "ikaros-job-"));
  const jobs = await new Kernel(join(dir, "store.db")).machine("job.ik.toml");
  const job = await jobs.create("job-1");
  const running = await job.command("start");
  assert.equal(running.namedState(), "running");
});

test("cancel then submit is refused; fresh read stays cancelled", async () => {
  const dir = mkdtempSync(join(tmpdir(), "ikaros-job-"));
  const jobs = await new Kernel(join(dir, "store.db")).machine("job.ik.toml");
  const job = await jobs.create("job-1");
  const running = await job.command("start");
  await running.command("cancel");
  await assert.rejects(() => running.command("submit", {
    artifact_digest: "a",
    baseline_digest: "b",
  }), StaleCapabilityError);
  const fresh = await jobs.show("job-1");
  assert.equal(fresh.namedState(), "cancelled");
});
