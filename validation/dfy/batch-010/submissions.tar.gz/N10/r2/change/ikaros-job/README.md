# Ikaros job template

One machine definition in `job.ik.toml`. Runtime remains authoritative.

    npm test
    npm start

## Authority and executor

`job.ik.toml` is the lifecycle definition. The `ik` runtime is the authority:
it commits or refuses each command. A refused command is not a committed state,
and a read is not a mutation. `job.mjs` is a client. It may propose commands.
It does not decide that a stale handle is current.

Scenarios record synthetic outcomes only. They do not send mail, publish an
artifact, or call an external executor. `ik check` does not authorize a
production commit. A missing witness is not proof of unreachability unless the
search completed.

`ik check` without `--corpus` loads `job.ik.cases.json` beside the machine.
That file is input coverage for the goals, not a second definition.

    ik check job.ik.toml --profile .ik/checks.toml
    ik scenario run job.ik.toml scenarios/normal.json --out .ik/runs/normal

The adverse schedule is `scenarios/stale-handle.json`. Its last step expects
`refused:IK_CAPABILITY_STALE`. Meeting that expectation means the runtime
refused the stale handle and committed nothing.
