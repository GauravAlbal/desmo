# Vehicle service work-order desk

Durable shop desk: one shelf and at most one work order, with supplier purchases recovered by saved id.

## Setup

Node 22 is required (`<home>/.nvm/versions/node/v22.17.1/bin/node` on this workstation).

```bash
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x run
```

Start the fake supplier (prints `{service_url, control_url}`):

```bash
node stub/server.mjs
```

## Run

Every command needs `STATE_DIR`, `SERVICE_URL`, and `NOW_MS` (epoch milliseconds, integer). Optional `CRASH_AT` for crash-label tests.

```bash
export STATE_DIR=/tmp/shop-state
export SERVICE_URL='http://127.0.0.1:<port>'
export NOW_MS=0
./run stock-set BRAKE_PAD 4
./run open WO-1 VIN123
./run reserve BRAKE_PAD 2
./run start
./run complete
./run status
```

Other commands: `order-part <sku> <qty>`, `reconcile <purchase_id>`, `cancel`, `callback <path>`.

Output is one JSON object. Exit 0 is success; refusals are nonzero `{ "error": "<code>" }`.

## Tests

```bash
npm test
```
