import { createHash, randomBytes } from "node:crypto";
import { existsSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Kernel,
  HistoricalResult,
  classify,
  StoreNotFoundError,
} from "@ikaros/runtime";

const ROOT_DIR = join(dirname(fileURLToPath(import.meta.url)), "..");
const MACHINE_V2_PATH = join(ROOT_DIR, "desk.ik.toml");
const MACHINE_V1_PATH = join(ROOT_DIR, "desk_v1.ik.toml");
const AGGREGATE_ID = "shop";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const MAX_QTY = 1_000_000;
const PAYMENT_NONE = 0;
const PAYMENT_SAVED = 1;
const PAYMENT_RECEIVED = 2;

export class AppError extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
}

function fail(code) {
  throw new AppError(code);
}

function num(v) {
  if (typeof v === "bigint") return Number(v);
  if (v == null) return 0;
  return Number(v);
}

function isCanonicalInt(s) {
  return typeof s === "string" && /^(0|[1-9][0-9]*)$/.test(s);
}

function parseQty(raw, min, max) {
  if (!isCanonicalInt(raw)) fail("bad_qty");
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < min || n > max) fail("bad_qty");
  return n;
}

function parseId(raw) {
  if (typeof raw !== "string" || !ID_RE.test(raw)) fail("bad_args");
  return raw;
}

function parseNow(raw) {
  if (raw == null || raw === "") fail("bad_args");
  if (!isCanonicalInt(raw)) fail("bad_args");
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0) fail("bad_args");
  return n;
}

function canonicalShelf(obj) {
  const keys = Object.keys(obj).sort();
  const out = {};
  for (const k of keys) out[k] = obj[k];
  return JSON.stringify(out);
}

function parseShelf(raw) {
  if (raw == null || raw === "") return {};
  let v;
  try {
    v = JSON.parse(raw);
  } catch {
    fail("corrupt_state");
  }
  if (v == null || typeof v !== "object" || Array.isArray(v)) fail("corrupt_state");
  const out = {};
  for (const [k, q] of Object.entries(v)) {
    if (!ID_RE.test(k)) fail("corrupt_state");
    const n = num(q);
    if (!Number.isSafeInteger(n) || n < 0 || n > MAX_QTY) fail("corrupt_state");
    out[k] = n;
  }
  return out;
}

function paymentName(p) {
  if (p === PAYMENT_SAVED) return "attempt_saved";
  if (p === PAYMENT_RECEIVED) return "received";
  return "none";
}

function statusName(state) {
  if (state === "idle" || !state) return "none";
  return state;
}

function digestOf(parts) {
  return createHash("sha256").update(JSON.stringify(parts)).digest("hex");
}

function newPurchaseId() {
  return `p${randomBytes(16).toString("hex")}`.slice(0, 64);
}

function crash(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

function factsOf(agg) {
  const s = agg.state && typeof agg.state === "object" ? agg.state : {};
  const shelf = parseShelf(s.shelf_json ?? "{}");
  const reservedSku = s.sku == null || s.sku === "" ? null : s.sku;
  return {
    wo_id: s.wo_id ?? null,
    vin: s.vin ?? null,
    sku: reservedSku,
    reserved_qty: num(s.reserved_qty),
    used_qty: num(s.used_qty),
    used_marked: num(s.used_marked),
    status: statusName(s.state ?? agg.namedState()),
    payment: paymentName(num(s.payment)),
    paymentN: num(s.payment),
    purchase_id: s.purchase_id ?? null,
    purchase_sku: s.purchase_sku ?? null,
    purchase_qty: num(s.purchase_qty),
    shelf,
    on_hand: reservedSku == null ? null : (shelf[reservedSku] ?? 0),
    named: agg.namedState(),
  };
}

function applyUsageView(f, stateDir, agg, machine) {
  const side = stateDir ? readUsageSidecar(stateDir) : null;
  if (side && side.used_marked === 1) {
    f.used_qty = side.used_qty;
    f.used_marked = 1;
  } else if (f.status === "completed" && f.used_marked === 0) {
    f.used_qty = f.reserved_qty;
    f.used_marked = 1;
  }
  return f;
}

function statusPayload(f) {
  return {
    wo_id: f.wo_id,
    vin: f.vin,
    sku: f.sku,
    reserved_qty: f.reserved_qty,
    used_qty: f.used_qty,
    used_marked: f.used_marked,
    status: f.status,
    payment: f.payment,
    purchase_id: f.purchase_id,
    purchase_sku: f.purchase_sku,
    purchase_qty: f.purchase_qty,
    shelf: f.shelf,
    on_hand: f.on_hand,
  };
}

function emptyStatus() {
  return {
    wo_id: null,
    vin: null,
    sku: null,
    reserved_qty: 0,
    used_qty: 0,
    used_marked: 0,
    status: "none",
    payment: "none",
    purchase_id: null,
    purchase_sku: null,
    purchase_qty: 0,
    shelf: {},
    on_hand: null,
  };
}

function storePath(stateDir) {
  return join(stateDir, "desk.sqlite");
}

function usagePath(stateDir) {
  return join(stateDir, "desk.usage.json");
}

function readUsageSidecar(stateDir) {
  const p = usagePath(stateDir);
  if (!existsSync(p)) return null;
  try {
    const v = JSON.parse(readFileSync(p, "utf8"));
    if (v == null || typeof v !== "object") return null;
    return { used_qty: num(v.used_qty), used_marked: num(v.used_marked) };
  } catch {
    fail("corrupt_state");
  }
}

function writeUsageSidecar(stateDir, used_qty) {
  writeFileSync(usagePath(stateDir), JSON.stringify({ used_qty, used_marked: 1 }) + "\n");
}

function isV1(agg, machine) {
  const ver = agg.owner?.version ?? machine.identity.version;
  return Number(ver) === 1;
}

function mapKernel(e) {
  if (e instanceof AppError) throw e;
  if (e instanceof HistoricalResult) fail("corrupt_state");
  if (e instanceof StoreNotFoundError) return null;
  if (e && typeof e === "object" && e.code) {
    const c = classify(e);
    if (c === "corrupt") fail("corrupt_state");
    if (c === "not_found") return null;
    if (e.code === "IK_STORE_CORRUPT") fail("corrupt_state");
  }
  throw e;
}

async function loadMachines(kernel) {
  const v2 = await kernel.machine(MACHINE_V2_PATH);
  const v1 = await kernel.machine(MACHINE_V1_PATH);
  return { v1, v2 };
}

function routeMachine(machines, agg) {
  if (!agg) return machines.v2;
  if (machines.v1.identity.equals(agg.owner)) return machines.v1;
  if (machines.v2.identity.equals(agg.owner)) return machines.v2;
  if (Number(agg.owner.version) === 1) return machines.v1;
  return machines.v2;
}

async function openKernel(stateDir, { mustExist }) {
  const path = storePath(stateDir);
  if (!existsSync(path)) {
    if (mustExist) return { empty: true, stateDir };
    const kernel = new Kernel(path);
    const machines = await loadMachines(kernel);
    return { kernel, machine: machines.v2, machines, agg: null, empty: false, stateDir };
  }
  try {
    if (statSync(path).size === 0) fail("corrupt_state");
    const kernel = new Kernel(path);
    const machines = await loadMachines(kernel);
    try {
      const probe = await machines.v2.show(AGGREGATE_ID);
      const machine = routeMachine(machines, probe);
      const agg = machine === machines.v2 ? probe : await machine.show(AGGREGATE_ID);
      return { kernel, machine, machines, agg, empty: false, stateDir };
    } catch (e) {
      const mapped = mapKernel(e);
      if (mapped === null) return { kernel, machine: machines.v2, machines, agg: null, empty: false, stateDir };
      throw e;
    }
  } catch (e) {
    if (e instanceof AppError) throw e;
    const mapped = mapKernel(e);
    if (mapped === null) fail("corrupt_state");
    fail("corrupt_state");
  }
}

async function apply(agg, name, args) {
  const next = await agg.command(name, args);
  if (next instanceof HistoricalResult) fail("corrupt_state");
  return next;
}

async function ensureAgg(ctx) {
  if (ctx.agg) return ctx.agg;
  ctx.agg = await ctx.machine.create(AGGREGATE_ID);
  return ctx.agg;
}

function requireOpened(f, extra = {}) {
  if (f.status !== "opened") fail("bad_status");
  return extra;
}

async function httpJson(method, url, body) {
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: { "content-type": "application/json", connection: "close" },
      body: body == null ? undefined : JSON.stringify(body),
    });
  } catch {
    fail("service_unavailable");
  }
  let text;
  try {
    text = await res.text();
  } catch {
    fail("service_unavailable");
  }
  if (text === "" && (res.status < 200 || res.status >= 300)) {
    if (res.status >= 500) fail("service_unavailable");
    fail("service_unavailable");
  }
  let json = null;
  if (text !== "") {
    try {
      json = JSON.parse(text);
    } catch {
      fail("service_unavailable");
    }
  }
  return { status: res.status, json, text };
}

function purchaseMatch(body, snap) {
  if (!body || typeof body !== "object") return false;
  return (
    body.purchase_id === snap.purchase_id &&
    body.wo_id === snap.wo_id &&
    body.sku === snap.sku &&
    num(body.qty) === snap.qty
  );
}

async function recordPending(agg, outcomeDigest) {
  if (!agg.pendingIntent) return agg;
  const rec = await agg.recordEffectOutcome(outcomeDigest, { intent: agg.pendingIntent });
  if (rec instanceof HistoricalResult) {
    return agg.machine.show(AGGREGATE_ID);
  }
  return rec;
}

async function adoptReceived(agg, snap, outcomeDigest) {
  let cur = agg;
  if (cur.pendingIntent) {
    cur = await recordPending(cur, outcomeDigest);
  }
  const f = factsOf(cur);
  if (f.paymentN === PAYMENT_RECEIVED) return cur;
  const shelf = { ...f.shelf };
  shelf[snap.sku] = (shelf[snap.sku] ?? 0) + snap.qty;
  cur = await apply(cur, "receive_stock", {
    sku: snap.sku,
    qty: snap.qty,
    shelf_json: canonicalShelf(shelf),
    payment_next: PAYMENT_RECEIVED,
  });
  return cur;
}

function receivedSuccess(f, snap) {
  return {
    wo_id: f.wo_id,
    purchase_id: snap.purchase_id,
    sku: snap.sku,
    qty: snap.qty,
    payment: "received",
    on_hand: f.shelf[snap.sku] ?? 0,
    status: "opened",
  };
}

async function lookupPurchase(serviceUrl, purchaseId) {
  const url = `${serviceUrl.replace(/\/$/, "")}/v1/purchases/${encodeURIComponent(purchaseId)}`;
  return httpJson("GET", url, null);
}

async function postPurchase(serviceUrl, snap) {
  const url = `${serviceUrl.replace(/\/$/, "")}/v1/purchases`;
  return httpJson("POST", url, {
    purchase_id: snap.purchase_id,
    wo_id: snap.wo_id,
    sku: snap.sku,
    qty: snap.qty,
  });
}

function handlePostResult(status, json, snap) {
  if (status >= 500) fail("service_unavailable");
  if (status === 409) fail("lookup_conflict");
  if (status === 200 && purchaseMatch(json, snap)) {
    return { json, digest: digestOf(json) };
  }
  if (status === 200) fail("lookup_conflict");
  fail("service_unavailable");
}

export async function runCommand(env, argv) {
  const stateDir = env.STATE_DIR;
  const serviceUrl = env.SERVICE_URL;
  if (!stateDir || stateDir === "") fail("bad_args");
  if (serviceUrl == null || serviceUrl === "") fail("bad_args");
  parseNow(env.NOW_MS);

  const cmd = argv[0];
  if (!cmd) fail("bad_args");

  if (cmd === "status") {
    const ctx = await openKernel(stateDir, { mustExist: true });
    if (ctx.empty || !ctx.agg) return emptyStatus();
    return statusPayload(applyUsageView(factsOf(ctx.agg), stateDir, ctx.agg, ctx.machine));
  }

  if (cmd === "callback") {
    const path = argv[1];
    if (!path) fail("bad_args");
    let raw;
    try {
      raw = readFileSync(path, "utf8");
    } catch {
      fail("bad_callback");
    }
    try {
      const v = JSON.parse(raw);
      if (v == null || typeof v !== "object" || Array.isArray(v)) fail("bad_callback");
    } catch (e) {
      if (e instanceof AppError) throw e;
      fail("bad_callback");
    }
    return { ignored: true };
  }

  if (cmd === "stock-set") {
    const sku = parseId(argv[1]);
    const qty = parseQty(argv[2], 0, MAX_QTY);
    const ctx = await openKernel(stateDir, { mustExist: false });
    if (ctx.empty) {
      /* unreachable */
    }
    let agg = ctx.agg;
    if (agg) {
      const f = factsOf(agg);
      if (["completed", "cancelled"].includes(f.status)) fail("bad_status");
      if (Object.prototype.hasOwnProperty.call(f.shelf, sku)) fail("already_stocked");
      const shelf = { ...f.shelf, [sku]: qty };
      agg = await apply(agg, "stock_set", { sku, qty, shelf_json: canonicalShelf(shelf) });
      const nf = factsOf(agg);
      return { sku, qty, shelf: nf.shelf };
    }
    agg = await ensureAgg(ctx);
    const shelf = { [sku]: qty };
    agg = await apply(agg, "stock_set", { sku, qty, shelf_json: canonicalShelf(shelf) });
    return { sku, qty, shelf: factsOf(agg).shelf };
  }

  if (cmd === "open") {
    const wo_id = parseId(argv[1]);
    const vin = parseId(argv[2]);
    const ctx = await openKernel(stateDir, { mustExist: false });
    let agg = ctx.agg;
    if (agg) {
      const f = factsOf(agg);
      if (f.status !== "none") fail("already_open");
      agg = await apply(agg, "open", { wo_id, vin });
    } else {
      agg = await ensureAgg(ctx);
      agg = await apply(agg, "open", { wo_id, vin });
    }
    return { wo_id, vin, status: "opened", payment: "none", purchase_id: null };
  }

  if (cmd === "reserve") {
    const sku = parseId(argv[1]);
    const qty = parseQty(argv[2], 1, 100);
    const ctx = await openKernel(stateDir, { mustExist: true });
    if (ctx.empty || !ctx.agg) fail("bad_status");
    const f = factsOf(ctx.agg);
    if (f.status === "reserved") fail("already_reserved");
    if (f.status !== "opened") fail("bad_status");
    if (f.payment === "attempt_saved") fail("order_pending");
    if (!Object.prototype.hasOwnProperty.call(f.shelf, sku) || f.shelf[sku] < qty) {
      fail("insufficient_stock");
    }
    const shelf = { ...f.shelf, [sku]: f.shelf[sku] - qty };
    const agg = await apply(ctx.agg, "reserve", { sku, qty, shelf_json: canonicalShelf(shelf) });
    const nf = factsOf(agg);
    return {
      wo_id: nf.wo_id,
      sku,
      reserved_qty: qty,
      on_hand: nf.shelf[sku] ?? 0,
      status: "reserved",
    };
  }

  if (cmd === "start") {
    const ctx = await openKernel(stateDir, { mustExist: true });
    if (ctx.empty || !ctx.agg) fail("bad_status");
    const f = factsOf(ctx.agg);
    if (f.status !== "reserved") fail("bad_status");
    const agg = await apply(ctx.agg, "start", {});
    return { wo_id: factsOf(agg).wo_id, status: "started" };
  }

  if (cmd === "mark-used") {
    const rawQty = argv[1];
    const ctx = await openKernel(stateDir, { mustExist: true });
    if (ctx.empty || !ctx.agg) fail("not_started");
    const f = applyUsageView(factsOf(ctx.agg), stateDir, ctx.agg, ctx.machine);
    if (f.status === "completed") fail("already_completed");
    if (f.status !== "started") fail("not_started");
    if (!isCanonicalInt(rawQty)) fail("bad_qty");
    const qty = Number(rawQty);
    if (!Number.isSafeInteger(qty) || qty < 0) fail("bad_qty");
    if (qty > f.reserved_qty) fail("used_qty_invalid");
    if (f.used_marked === 1) {
      if (qty === f.used_qty) {
        return {
          wo_id: f.wo_id,
          sku: f.sku,
          reserved_qty: f.reserved_qty,
          used_qty: f.used_qty,
          used_marked: 1,
          status: "started",
        };
      }
      fail("already_marked");
    }
    let agg = ctx.agg;
    if (isV1(ctx.agg, ctx.machine)) {
      writeUsageSidecar(stateDir, qty);
    } else {
      agg = await apply(ctx.agg, "mark_used", { qty });
    }
    const nf = applyUsageView(factsOf(agg), stateDir, agg, ctx.machine);
    return {
      wo_id: nf.wo_id,
      sku: nf.sku,
      reserved_qty: nf.reserved_qty,
      used_qty: nf.used_qty,
      used_marked: 1,
      status: "started",
    };
  }

  if (cmd === "complete") {
    const ctx = await openKernel(stateDir, { mustExist: true });
    if (ctx.empty || !ctx.agg) fail("bad_status");
    const f = applyUsageView(factsOf(ctx.agg), stateDir, ctx.agg, ctx.machine);
    if (f.status !== "started") fail("bad_status");
    if (f.used_marked !== 1) fail("usage_unmarked");
    const restocked_qty = f.reserved_qty - f.used_qty;
    const shelf = { ...f.shelf };
    if (restocked_qty > 0 && f.sku) {
      shelf[f.sku] = (shelf[f.sku] ?? 0) + restocked_qty;
    }
    const shelf_json = canonicalShelf(shelf);
    let agg = ctx.agg;
    if (isV1(ctx.agg, ctx.machine)) {
      if (restocked_qty > 0) {
        agg = await apply(agg, "stock_set", { sku: f.sku, qty: restocked_qty, shelf_json });
      }
      agg = await apply(agg, "complete", { used_qty: f.reserved_qty });
    } else {
      agg = await apply(agg, "complete", { shelf_json });
    }
    const nf = applyUsageView(factsOf(agg), stateDir, agg, ctx.machine);
    return {
      wo_id: nf.wo_id,
      status: "completed",
      sku: nf.sku,
      reserved_qty: nf.reserved_qty,
      used_qty: f.used_qty,
      restocked_qty,
      shelf: nf.shelf,
    };
  }

  if (cmd === "cancel") {
    const ctx = await openKernel(stateDir, { mustExist: true });
    if (ctx.empty || !ctx.agg) fail("bad_status");
    const f = factsOf(ctx.agg);
    if (!["opened", "reserved", "started"].includes(f.status)) fail("bad_status");
    if (f.payment === "attempt_saved") fail("order_started");
    const shelf = { ...f.shelf };
    if ((f.status === "reserved" || f.status === "started") && f.sku) {
      shelf[f.sku] = (shelf[f.sku] ?? 0) + f.reserved_qty;
    }
    const agg = await apply(ctx.agg, "cancel", { shelf_json: canonicalShelf(shelf) });
    const nf = factsOf(agg);
    return { wo_id: nf.wo_id, status: "cancelled", shelf: nf.shelf };
  }

  if (cmd === "order-part") {
    const sku = parseId(argv[1]);
    const qty = parseQty(argv[2], 0, MAX_QTY);
    const ctx = await openKernel(stateDir, { mustExist: true });
    if (ctx.empty || !ctx.agg) fail("bad_status");
    let agg = ctx.agg;
    let f = factsOf(agg);
    if (f.status !== "opened") fail("bad_status");

    if (f.payment === "received") {
      const snap = {
        purchase_id: f.purchase_id,
        wo_id: f.wo_id,
        sku: f.purchase_sku,
        qty: f.purchase_qty,
      };
      return receivedSuccess(f, snap);
    }

    if (f.payment === "attempt_saved") {
      const snap = {
        purchase_id: f.purchase_id,
        wo_id: f.wo_id,
        sku: f.purchase_sku,
        qty: f.purchase_qty,
      };
      const looked = await lookupPurchase(serviceUrl, snap.purchase_id);
      if (looked.status === 200) {
        if (!purchaseMatch(looked.json, snap)) fail("lookup_conflict");
        const digest = digestOf(looked.json);
        agg = await adoptReceived(agg, snap, digest);
        crash("after-record-before-exit");
        return receivedSuccess(factsOf(agg), snap);
      }
      if (looked.status !== 404) {
        if (looked.status >= 500) fail("service_unavailable");
        fail("service_unavailable");
      }
      crash("after-purchase-saved-before-request");
      const posted = await postPurchase(serviceUrl, snap);
      const ok = handlePostResult(posted.status, posted.json, snap);
      crash("after-accept-before-record");
      agg = await adoptReceived(agg, snap, ok.digest);
      crash("after-record-before-exit");
      return receivedSuccess(factsOf(agg), snap);
    }

    requireOpened(f);
    const purchase_id = newPurchaseId();
    const snap = { purchase_id, wo_id: f.wo_id, sku, qty };
    const payload_digest = digestOf(snap);
    agg = await apply(agg, "save_purchase", {
      purchase_id,
      purchase_sku: sku,
      purchase_qty: qty,
      payment_next: PAYMENT_SAVED,
      effect_id: purchase_id,
      payload_digest,
      idempotency_key: purchase_id,
    });
    crash("after-purchase-saved-before-request");
    const posted = await postPurchase(serviceUrl, snap);
    const ok = handlePostResult(posted.status, posted.json, snap);
    crash("after-accept-before-record");
    agg = await adoptReceived(agg, snap, ok.digest);
    crash("after-record-before-exit");
    return receivedSuccess(factsOf(agg), snap);
  }

  if (cmd === "reconcile") {
    const purchase_id = parseId(argv[1]);
    const ctx = await openKernel(stateDir, { mustExist: true });
    if (ctx.empty || !ctx.agg) fail("no_purchase");
    let agg = ctx.agg;
    const f = factsOf(agg);
    if (!f.purchase_id) fail("no_purchase");
    if (f.purchase_id !== purchase_id) fail("purchase_mismatch");
    if (f.payment === "received") {
      const snap = {
        purchase_id: f.purchase_id,
        wo_id: f.wo_id,
        sku: f.purchase_sku,
        qty: f.purchase_qty,
      };
      return { ...receivedSuccess(f, snap), lookup: "received" };
    }
    const snap = {
      purchase_id: f.purchase_id,
      wo_id: f.wo_id,
      sku: f.purchase_sku,
      qty: f.purchase_qty,
    };
    const looked = await lookupPurchase(serviceUrl, purchase_id);
    if (looked.status === 404) {
      return {
        lookup: "not_sent",
        wo_id: f.wo_id,
        purchase_id,
        payment: "attempt_saved",
        status: "opened",
      };
    }
    if (looked.status === 200) {
      if (!purchaseMatch(looked.json, snap)) fail("lookup_conflict");
      const digest = digestOf(looked.json);
      agg = await adoptReceived(agg, snap, digest);
      crash("after-record-before-exit");
      return { ...receivedSuccess(factsOf(agg), snap), lookup: "received" };
    }
    if (looked.status >= 500) fail("service_unavailable");
    fail("service_unavailable");
  }

  fail("bad_args");
}

export async function main(env, argv) {
  try {
    const result = await runCommand(env, argv);
    process.stdout.write(JSON.stringify(result) + "\n");
    process.exitCode = 0;
  } catch (e) {
    if (e instanceof AppError) {
      process.stdout.write(JSON.stringify({ error: e.code }) + "\n");
      process.exitCode = 1;
      return;
    }
    if (e && typeof e === "object" && e.code) {
      try {
        const c = classify(e);
        if (c === "corrupt") {
          process.stdout.write(JSON.stringify({ error: "corrupt_state" }) + "\n");
          process.exitCode = 1;
          return;
        }
        if (c === "refused") {
          process.stdout.write(JSON.stringify({ error: "bad_status" }) + "\n");
          process.exitCode = 1;
          return;
        }
      } catch {
        /* fall through */
      }
    }
    process.stdout.write(JSON.stringify({ error: "corrupt_state" }) + "\n");
    process.exitCode = 1;
  }
}
