import { main } from "./desk.mjs";
await main(process.env, process.argv.slice(2));
