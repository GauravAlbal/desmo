# Vehicle service work-order desk

The program behind `./run` is a durable local desk for one shop: a parts shelf (on-hand quantity per SKU) and one work order. Parts are reserved from the shelf before a job starts. Missing parts are ordered from one supplier. A supplier purchase has an application-created id saved before the request; recovery looks up that id before any retry.

## Scope and invocation

One machine and one process at a time. One shop and at most one work order are bound to a state directory. An unrelated writer may create or modify other files in `STATE_DIR`; those files must survive byte-for-byte. The tool may keep its durable files in `STATE_DIR` under any names. It must use `STATE_DIR`, `SERVICE_URL`, `NOW_MS`, and optional `CRASH_AT`. `SERVICE_URL` is required for every command, including status (status never contacts it). `NOW_MS` is a required non-negative integer epoch-millisecond clock for every command; this initial contract does not compare it to a due date.

`./run <command> [args]` prints exactly one JSON object and nothing else (one trailing newline is allowed). Exit 0 is success. Refusals are nonzero and print `{ "error": "<code>" }`. Identifiers (`wo_id`, SKU, purchase id, VIN) are 1–64 characters matching `A-Za-z0-9._-`. Quantities are canonical non-negative decimal integers in the closed range 0 through 1000000. `stock-set` and `order-part` quantities may be 0 through 1000000; `reserve` quantities must be 1 through 100. `CRASH_AT` labels are:

* `after-purchase-saved-before-request`: after saving a purchase id and purchase snapshot, before sending a request;
* `after-accept-before-record`: after reading a complete successful provider response, before saving the received-stock record;
* `after-record-before-exit`: after saving the received-stock record, before success JSON is written.

A process must kill itself with SIGKILL at a reached label. Durable commits are flushed before the command treats them as committed. A malformed owned state file is `corrupt_state` and is not rewritten. Refusals do not modify state except that a due path named below may durably record a saved purchase attempt.

## Commands

`stock-set <sku> <qty>` creates that SKU on the shelf with on-hand `qty` when the SKU is absent. It returns `{sku,qty,shelf}` where `shelf` is an object mapping every known SKU to its integer on-hand quantity. A second `stock-set` for an already-known SKU is `already_stocked` and does not change quantities. Malformed identifiers are `bad_args`; malformed quantities are `bad_qty`. It never contacts the provider. It is allowed in statuses `none`, `opened`, `reserved`, and `started`.

`open <wo_id> <vin>` binds the empty-or-idle shop to one work order and returns `{wo_id,vin,status:"opened",payment:"none",purchase_id:null}`. A second open is `already_open`. Malformed identifiers are `bad_args`. It never contacts the provider.

`reserve <sku> <qty>` is valid only for an `opened` work order with `payment` not equal to `attempt_saved`. It requires on-hand of `sku` to be at least `qty`, decrements that on-hand by `qty`, records the single reserved line, and returns `{wo_id,sku,reserved_qty,on_hand,status:"reserved"}`. Missing SKU or short stock is `insufficient_stock`. A second reserve is `already_reserved`. An in-flight purchase is `order_pending`. A work order that is not `opened` is `bad_status`. It never contacts the provider.

`start` is valid only for `reserved` and returns `{wo_id,status:"started"}`. Any other status is `bad_status`. It never contacts the provider.

`complete` is valid only for `started`. In this initial contract it consumes the entire reserved quantity (the reserved SKU is not returned to the shelf) and returns `{wo_id,status:"completed",sku,reserved_qty,restocked_qty:0,shelf}`. Any other status is `bad_status`. It never contacts the provider.

`cancel` is allowed for `opened`, `reserved`, or `started` when `payment` is not `attempt_saved`. If a line is reserved or the job has started, the reserved quantity is added back to that SKU’s on-hand. It returns `{wo_id,status:"cancelled",shelf}` and never contacts the provider. An in-flight purchase is `order_started` and preserves the purchase id and snapshot. A completed or cancelled work order cannot reserve, start, complete, or order.

`order-part <sku> <qty>` is valid only for an `opened` work order. Before a saved purchase, it increments nothing locally except a generated purchase id and its exact snapshot (`sku`, `qty`, `wo_id`), then posts once. A matching successful response adds `qty` to that SKU’s on-hand (creating the SKU if needed), sets `payment:"received"`, and returns `{wo_id,purchase_id,sku,qty,payment:"received",on_hand,status:"opened"}`. Repeating `order-part` after `payment:"received"` is a success no-op without a provider call. An attempt whose connection fails, has an incomplete response, or receives HTTP 5xx remains `payment:"attempt_saved"` and returns `service_unavailable`; it does not lookup in that invocation. A reserved, started, completed, or cancelled work order is `bad_status` without contacting the provider.

If a saved attempt exists, `order-part` first `GET /v1/purchases/<purchase_id>`: a matching 200 is adopted without POST; a 404 causes one POST with the saved id only. Never allocate a replacement id. A mismatching success is `lookup_conflict` and changes nothing.

`reconcile <purchase_id>` never POSTs or allocates. No saved purchase is `no_purchase`; another id is `purchase_mismatch`. Lookup 200 with matching ids, sku, qty, and work order commits the received-stock state and returns the success object plus `lookup:"received"`; 404 returns exit 0 `{lookup:"not_sent",wo_id,purchase_id,payment:"attempt_saved",status:"opened"}`; a mismatch is `lookup_conflict`; transport failure is `service_unavailable`.

`status` never contacts the provider and returns `{wo_id,vin,sku,reserved_qty,used_qty,used_marked,status,payment,purchase_id,purchase_sku,purchase_qty,shelf,on_hand}`. Empty fields are null, with `reserved_qty:0`, `used_qty:0`, `used_marked:0`, `purchase_qty:0`, `status:"none"`, `payment:"none"`, and `shelf:{}`. `on_hand` is the on-hand of the reserved SKU, or null when none is reserved. `used_marked` is 0 in this initial contract.

`callback <path>` reads one JSON callback. It must not POST or allocate. A malformed callback is `bad_callback`; a well-formed callback may be ignored. It must never overwrite opened, reserved, started, completed, or cancelled state, and must never change the shelf or a saved purchase.

## Provider

The supplied service has `POST /v1/purchases` and `GET /v1/purchases/<purchase_id>`. A first valid purchase id records one effect and returns the body with `outcome:"purchased"`; repeating the same id and identical fields returns the same object without another effect; any differing field is HTTP 409. Unknown lookup is 404. The provider may drop a reply after accepting, hold a reply, or return 5xx without storing. Control endpoints are not part of this contract.

## Requirements

R1. Open, stock-set, and every later committed record survive new processes, including a purchase attempt killed at `after-purchase-saved-before-request`.

R2. `stock-set` and `open` validate identifiers and quantities, bind at most one work order, and do not contact the provider.

R3. A healthy shelf permits reserve/start/complete: reserve decrements on-hand by the reserved quantity, complete leaves that quantity off the shelf, and a short shelf is `insufficient_stock` without mutation.

R4. Cancellation is terminal, durable, and provider-free. Cancelling a reserved or started job restocks the reserved quantity. Completion (this initial contract) is terminal, durable, provider-free, and does not restock.

R5. A healthy provider permits `order-part` and exactly one external purchase effect; repeating `order-part` after received is a no-op and does not add an effect.

R6. Callback files never overwrite local outcomes, never change the shelf, and never cause provider effects.

R7. Reserve/start/complete/order in the wrong status, a second open, a second stock-set for a known SKU, and `order-part` after the work order leaves `opened` are refused without contacting the provider.

R8. A crash before POST leaves one saved purchase id and zero effects; a later `order-part` POSTs that same id and ends `received` exactly once.

R9. A crash after provider acceptance leaves `attempt_saved` locally and one provider effect; later `order-part` adopts by lookup without a second effect.

R10. A crash after the durable received record leaves `payment:"received"` and later `order-part` is a no-op; reconcile can likewise survive its record-before-exit crash.

R11. A dropped purchase reply yields `service_unavailable` and `attempt_saved`; following reconcile adopts `received` by lookup, never reports `not_sent`, and never posts again.

R12. Reconcile never POSTs: a saved-but-unaccepted id returns `not_sent` with `attempt_saved`; a wrong id is `purchase_mismatch` and leaves state unchanged.

R13. Unrelated files in STATE_DIR retain identical bytes through commits and refusals.

R14. Every invocation emits one JSON object; status on empty is the null shape; missing SERVICE_URL or NOW_MS is a refusal; the first open binds the only work order and no command can operate another `wo_id`.
