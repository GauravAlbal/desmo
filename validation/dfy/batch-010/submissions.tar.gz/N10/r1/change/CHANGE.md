# Change: mark-used leftover restock

R1–R14 remain in force except where this file supersedes R4’s complete-does-not-restock rule and the `complete` / `status` field meanings below. `status` additionally reports `used_qty` as the marked used quantity and `used_marked` as `0` or `1`. This change adds a usage-mark command and changes how `complete` treats leftover reserved parts.

The new command is:

`mark-used <qty>`

It is valid only for a `started` work order. `qty` is a canonical integer in `0` through the reserved quantity inclusive. The command records `used_qty` as that value, sets `used_marked` to `1`, and returns `{wo_id,sku,reserved_qty,used_qty,used_marked:1,status:"started"}`. Repeating `mark-used` with the same `qty` is a success no-op without another mutation. A different `qty` after a mark is `already_marked`. A quantity above reserved is `used_qty_invalid`. `opened`, `reserved`, `completed`, `cancelled`, or `none` is `not_started` (completed is `already_completed`). `mark-used` never contacts the provider.

`complete` is revised only for work orders that are still `started` when the changed program runs. It requires `used_marked:1`; otherwise it returns `usage_unmarked` and changes nothing. On success it restocks `reserved_qty - used_qty` onto the reserved SKU, leaves `used_qty` consumed (not on the shelf), and returns `{wo_id,status:"completed",sku,reserved_qty,used_qty,restocked_qty,shelf}` with `restocked_qty = reserved_qty - used_qty`. A successful complete still never contacts the provider.

## Old-instance policy

* Work orders already `completed` under the original program: they consumed the entire reserved quantity at complete time. The changed program must not restock them, must not require `mark-used`, and must refuse `mark-used` with `already_completed`. `status` reports `status:"completed"`, `used_qty` equal to `reserved_qty`, `used_marked:1`, and the shelf as persisted (no leftover return). `complete` on them remains `bad_status`.
* Work orders already `cancelled`: `mark-used` is `not_started`; shelf remains as persisted (cancel already restocked under R4).
* Work orders still `opened` or `reserved`: they follow the new `complete` / `mark-used` rules once they reach `started`. Existing reserved quantities and shelf quantities remain as stored. `mark-used` before `started` is `not_started`.
* Work orders still `started` with no mark (`used_marked` 0 / absent): `complete` is `usage_unmarked` until `mark-used` succeeds. They are not auto-migrated to “fully used”.
* Saved purchase attempts (`payment:"attempt_saved"` or `"received"`) keep the same purchase id, snapshot, and recovery rules (R8–R12). `mark-used` does not allocate or POST. Cancel while a purchase is `attempt_saved` remains `order_started`.
* SKUs already on the shelf keep their on-hand integers. `stock-set` of a known SKU remains `already_stocked`.

## C1–C5

C1. `mark-used` accepts only a quantity in range, persists `used_qty` and `used_marked:1` on a started job, and creates no provider effect.

C2. Mark-used state survives a new process. Repeating the same quantity is idempotent; a different quantity is `already_marked` without mutation; a completed old instance is `already_completed` without mutation.

C3. `complete` after a mark restocks exactly `reserved_qty - used_qty` and consumes `used_qty`; without a mark it is `usage_unmarked` and does not change the shelf.

C4. Restock from complete is applied once, visible on `status.shelf` / `restocked_qty`, and a second complete is `bad_status`; provider effect count is unchanged by mark-used and complete.

C5. After mark-used (or on a started job awaiting it), a saved-purchase crash or dropped reply still recovers the same purchase id by lookup/retry, cancellation cannot erase a saved attempt, and no second provider effect is created. Pre-change completed jobs are not restocked by later commands.
