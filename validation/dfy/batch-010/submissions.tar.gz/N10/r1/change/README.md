# Vehicle service work-order desk

Durable local desk for one shop: a parts shelf and at most one work order.
Lifecycle authority is an Ikaros machine (`desk.ik.toml`). The Node host owns
the CLI, HTTP to the supplier stub, and crash labels.

## Setup

Node 22 is required. npm registry access is not required after the tarballs
are present under `KIT/npm/`.

```bash
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x ./run
```

On linux, install the matching `@ikaros/<platform>` tarball instead of
`ikaros-darwin-arm64`.

## Run

Start the supplied stub (prints `service_url`):

```bash
node stub/server.mjs
```

```bash
export STATE_DIR=/tmp/desk-state
export SERVICE_URL=http://127.0.0.1:<port>
export NOW_MS=0
mkdir -p "$STATE_DIR"
./run stock-set BRK 10
./run open WO1 VIN1
./run reserve BRK 2
./run start
./run complete
./run status
```

Optional `CRASH_AT` values: `after-purchase-saved-before-request`,
`after-accept-before-record`, `after-record-before-exit`.

`./run` prints one JSON object. Exit 0 is success; refusals are nonzero with
`{"error":"<code>"}`.

## Tests

```bash
node --test tests/desk.test.mjs
```
