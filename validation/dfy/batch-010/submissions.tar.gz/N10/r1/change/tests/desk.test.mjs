import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const RUN = join(ROOT, "run");
const NODE = process.execPath;
const STUB = join(ROOT, "stub", "server.mjs");

function tmp() {
  return mkdtempSync(join(tmpdir(), "desk-test-"));
}

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [STUB], { cwd: ROOT, stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    const onData = (c) => {
      buf += c.toString();
      const nl = buf.indexOf("\n");
      if (nl === -1) return;
      child.stdout.off("data", onData);
      try {
        resolve({ child, ...JSON.parse(buf.slice(0, nl)) });
      } catch (e) {
        reject(e);
      }
    };
    child.stdout.on("data", onData);
    child.on("error", reject);
  });
}

async function fault(control, body) {
  const r = await fetch(`${control}/fault`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  assert.equal(r.status, 200);
}

async function effects(control) {
  const r = await fetch(`${control}/effects`);
  return r.json();
}

function invoke(stateDir, serviceUrl, args, extraEnv = {}) {
  const r = spawnSync(RUN, args, {
    cwd: ROOT,
    env: {
      ...process.env,
      STATE_DIR: stateDir,
      SERVICE_URL: serviceUrl,
      NOW_MS: extraEnv.NOW_MS ?? "1000",
      ...extraEnv,
    },
    encoding: "utf8",
  });
  const text = r.stdout.trim();
  let json = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    json = { parse_error: text, stderr: r.stderr };
  }
  return { status: r.status, signal: r.signal, json, stdout: r.stdout, stderr: r.stderr };
}

function ok(r) {
  assert.equal(r.status, 0, JSON.stringify(r));
  assert.equal(r.stdout.split("\n").filter((l) => l !== "").length, 1);
  return r.json;
}

function err(r, code) {
  assert.notEqual(r.status, 0, JSON.stringify(r));
  assert.equal(r.json.error, code, JSON.stringify(r));
}

test("status empty, missing env, stock-set and open persist across processes", async () => {
  const { child, service_url } = await startStub();
  try {
    const dir = tmp();
    err(invoke(dir, service_url, ["status"], { SERVICE_URL: "" }), "bad_args");
    err(invoke(dir, service_url, ["status"], { NOW_MS: "" }), "bad_args");
    const empty = ok(invoke(dir, service_url, ["status"]));
    assert.equal(empty.status, "none");
    assert.equal(empty.wo_id, null);
    assert.deepEqual(empty.shelf, {});
    assert.equal(empty.reserved_qty, 0);
    err(invoke(dir, service_url, ["stock-set", "bad sku", "1"]), "bad_args");
    err(invoke(dir, service_url, ["stock-set", "SKU1", "01"]), "bad_qty");
    ok(invoke(dir, service_url, ["stock-set", "SKU1", "10"]));
    err(invoke(dir, service_url, ["stock-set", "SKU1", "3"]), "already_stocked");
    const opened = ok(invoke(dir, service_url, ["open", "WO1", "VIN99"]));
    assert.equal(opened.status, "opened");
    err(invoke(dir, service_url, ["open", "WO2", "VIN2"]), "already_open");
    const marker = join(dir, "unrelated.bin");
    writeFileSync(marker, Buffer.from([1, 2, 3, 4]));
    const st = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st.wo_id, "WO1");
    assert.equal(st.shelf.SKU1, 10);
    assert.deepEqual([...readFileSync(marker)], [1, 2, 3, 4]);
  } finally {
    child.kill("SIGKILL");
  }
});

test("reserve start complete cancel and refusals", async () => {
  const { child, service_url } = await startStub();
  try {
    const dir = tmp();
    ok(invoke(dir, service_url, ["stock-set", "BRK", "5"]));
    ok(invoke(dir, service_url, ["open", "WO1", "VIN1"]));
    err(invoke(dir, service_url, ["reserve", "BRK", "9"]), "insufficient_stock");
    err(invoke(dir, service_url, ["reserve", "NOPE", "1"]), "insufficient_stock");
    err(invoke(dir, service_url, ["start"]), "bad_status");
    const rsv = ok(invoke(dir, service_url, ["reserve", "BRK", "2"]));
    assert.equal(rsv.on_hand, 3);
    assert.equal(rsv.status, "reserved");
    err(invoke(dir, service_url, ["reserve", "BRK", "1"]), "already_reserved");
    err(invoke(dir, service_url, ["order-part", "BRK", "1"]), "bad_status");
    ok(invoke(dir, service_url, ["start"]));
    err(invoke(dir, service_url, ["complete"]), "usage_unmarked");
    err(invoke(dir, service_url, ["mark-used", "9"]), "used_qty_invalid");
    err(invoke(dir, service_url, ["mark-used", "01"]), "bad_qty");
    const marked = ok(invoke(dir, service_url, ["mark-used", "2"]));
    assert.equal(marked.used_qty, 2);
    assert.equal(marked.used_marked, 1);
    const again = ok(invoke(dir, service_url, ["mark-used", "2"]));
    assert.equal(again.used_qty, 2);
    err(invoke(dir, service_url, ["mark-used", "1"]), "already_marked");
    const done = ok(invoke(dir, service_url, ["complete"]));
    assert.equal(done.status, "completed");
    assert.equal(done.used_qty, 2);
    assert.equal(done.restocked_qty, 0);
    assert.equal(done.shelf.BRK, 3);
    err(invoke(dir, service_url, ["complete"]), "bad_status");
    err(invoke(dir, service_url, ["mark-used", "2"]), "already_completed");
    err(invoke(dir, service_url, ["cancel"]), "bad_status");

    const dir2 = tmp();
    ok(invoke(dir2, service_url, ["stock-set", "BRK", "5"]));
    ok(invoke(dir2, service_url, ["open", "WO9", "VIN9"]));
    ok(invoke(dir2, service_url, ["reserve", "BRK", "2"]));
    const c = ok(invoke(dir2, service_url, ["cancel"]));
    assert.equal(c.status, "cancelled");
    assert.equal(c.shelf.BRK, 5);
  } finally {
    child.kill("SIGKILL");
  }
});

test("mark-used leftover restock and refusals by status", async () => {
  const { child, service_url } = await startStub();
  try {
    const dir = tmp();
    ok(invoke(dir, service_url, ["stock-set", "BRK", "5"]));
    err(invoke(dir, service_url, ["mark-used", "1"]), "not_started");
    ok(invoke(dir, service_url, ["open", "WO1", "VIN1"]));
    err(invoke(dir, service_url, ["mark-used", "1"]), "not_started");
    ok(invoke(dir, service_url, ["reserve", "BRK", "2"]));
    err(invoke(dir, service_url, ["mark-used", "1"]), "not_started");
    ok(invoke(dir, service_url, ["start"]));
    ok(invoke(dir, service_url, ["mark-used", "1"]));
    const st = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st.used_qty, 1);
    assert.equal(st.used_marked, 1);
    const done = ok(invoke(dir, service_url, ["complete"]));
    assert.equal(done.used_qty, 1);
    assert.equal(done.restocked_qty, 1);
    assert.equal(done.shelf.BRK, 4);
    const st2 = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st2.shelf.BRK, 4);
    assert.equal(st2.used_qty, 1);
    assert.equal(st2.used_marked, 1);
    assert.equal(st2.status, "completed");

    const dirC = tmp();
    ok(invoke(dirC, service_url, ["stock-set", "BRK", "5"]));
    ok(invoke(dirC, service_url, ["open", "WO9", "VIN9"]));
    ok(invoke(dirC, service_url, ["reserve", "BRK", "2"]));
    ok(invoke(dirC, service_url, ["cancel"]));
    err(invoke(dirC, service_url, ["mark-used", "1"]), "not_started");
  } finally {
    child.kill("SIGKILL");
  }
});

test("healthy order-part is one effect; repeat is no-op", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const dir = tmp();
    ok(invoke(dir, service_url, ["open", "WO1", "VIN1"]));
    const rec = ok(invoke(dir, service_url, ["order-part", "OIL", "4"]));
    assert.equal(rec.payment, "received");
    assert.equal(rec.on_hand, 4);
    assert.equal(rec.qty, 4);
    const e1 = await effects(control_url);
    assert.equal(e1.count, 1);
    const again = ok(invoke(dir, service_url, ["order-part", "OIL", "99"]));
    assert.equal(again.payment, "received");
    assert.equal(again.qty, 4);
    const e2 = await effects(control_url);
    assert.equal(e2.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash after-purchase-saved-before-request then recover same id", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const dir = tmp();
    ok(invoke(dir, service_url, ["open", "WO1", "VIN1"]));
    const crashed = invoke(dir, service_url, ["order-part", "PAD", "2"], {
      CRASH_AT: "after-purchase-saved-before-request",
    });
    assert.equal(crashed.signal, "SIGKILL");
    const st = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st.payment, "attempt_saved");
    assert.ok(st.purchase_id);
    err(invoke(dir, service_url, ["reserve", "PAD", "1"]), "order_pending");
    err(invoke(dir, service_url, ["cancel"]), "order_started");
    const e0 = await effects(control_url);
    assert.equal(e0.count, 0);
    const rec = ok(invoke(dir, service_url, ["order-part", "PAD", "2"]));
    assert.equal(rec.payment, "received");
    assert.equal(rec.purchase_id, st.purchase_id);
    const e1 = await effects(control_url);
    assert.equal(e1.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash after-accept-before-record adopts by lookup without second effect", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const dir = tmp();
    ok(invoke(dir, service_url, ["open", "WO1", "VIN1"]));
    const crashed = invoke(dir, service_url, ["order-part", "FLT", "1"], {
      CRASH_AT: "after-accept-before-record",
    });
    assert.equal(crashed.signal, "SIGKILL");
    const st = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st.payment, "attempt_saved");
    const e1 = await effects(control_url);
    assert.equal(e1.count, 1);
    const rec = ok(invoke(dir, service_url, ["order-part", "FLT", "1"]));
    assert.equal(rec.payment, "received");
    const e2 = await effects(control_url);
    assert.equal(e2.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash after-record-before-exit leaves received; later order-part no-op", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const dir = tmp();
    ok(invoke(dir, service_url, ["open", "WO1", "VIN1"]));
    const crashed = invoke(dir, service_url, ["order-part", "BLT", "3"], {
      CRASH_AT: "after-record-before-exit",
    });
    assert.equal(crashed.signal, "SIGKILL");
    const st = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st.payment, "received");
    const rec = ok(invoke(dir, service_url, ["order-part", "BLT", "3"]));
    assert.equal(rec.payment, "received");
    const e = await effects(control_url);
    assert.equal(e.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("dropped reply then reconcile adopts received and never posts again", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const dir = tmp();
    ok(invoke(dir, service_url, ["open", "WO1", "VIN1"]));
    await fault(control_url, { drop_reply: true });
    err(invoke(dir, service_url, ["order-part", "GASK", "1"]), "service_unavailable");
    await fault(control_url, { drop_reply: false });
    const st = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st.payment, "attempt_saved");
    const rec = ok(invoke(dir, service_url, ["reconcile", st.purchase_id]));
    assert.equal(rec.lookup, "received");
    assert.equal(rec.payment, "received");
    const posts = await (await fetch(`${control_url}/posts`)).json();
    const postCount = posts.count;
    ok(invoke(dir, service_url, ["order-part", "GASK", "1"]));
    const posts2 = await (await fetch(`${control_url}/posts`)).json();
    assert.equal(posts2.count, postCount);
  } finally {
    child.kill("SIGKILL");
  }
});

test("reconcile not_sent, mismatch, no_purchase; 5xx leaves attempt_saved", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const dir = tmp();
    err(invoke(dir, service_url, ["reconcile", "p1"]), "no_purchase");
    ok(invoke(dir, service_url, ["open", "WO1", "VIN1"]));
    err(invoke(dir, service_url, ["reconcile", "p1"]), "no_purchase");
    await fault(control_url, { error_status: 503 });
    err(invoke(dir, service_url, ["order-part", "X", "1"]), "service_unavailable");
    await fault(control_url, { error_status: 0 });
    const st = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st.payment, "attempt_saved");
    err(invoke(dir, service_url, ["reconcile", "other-id"]), "purchase_mismatch");
    const ns = ok(invoke(dir, service_url, ["reconcile", st.purchase_id]));
    assert.equal(ns.lookup, "not_sent");
    assert.equal(ns.payment, "attempt_saved");
    const e = await effects(control_url);
    assert.equal(e.count, 0);
  } finally {
    child.kill("SIGKILL");
  }
});

test("callback never mutates; unrelated bytes survive refusals", async () => {
  const { child, service_url } = await startStub();
  try {
    const dir = tmp();
    const marker = join(dir, "keep.dat");
    writeFileSync(marker, "hello-bytes");
    ok(invoke(dir, service_url, ["open", "WO1", "VIN1"]));
    const cb = join(dir, "cb.json");
    writeFileSync(cb, JSON.stringify({ event: "purchased", purchase_id: "x" }));
    const out = ok(invoke(dir, service_url, ["callback", cb]));
    assert.equal(out.ignored, true);
    const st = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st.status, "opened");
    assert.equal(st.payment, "none");
    writeFileSync(cb, "not-json");
    err(invoke(dir, service_url, ["callback", cb]), "bad_callback");
    assert.equal(readFileSync(marker, "utf8"), "hello-bytes");
  } finally {
    child.kill("SIGKILL");
  }
});

test("pre-change completed instance is not restocked and mark-used is already_completed", async () => {
  const { child, service_url } = await startStub();
  try {
    const dir = tmp();
    const OLD_RUN = "/tmp/desk-pre-change-N10r1/run";
    function oldInvoke(args) {
      return spawnSync(OLD_RUN, args, {
        cwd: "/tmp/desk-pre-change-N10r1",
        env: {
          ...process.env,
          STATE_DIR: dir,
          SERVICE_URL: service_url,
          NOW_MS: "1000",
        },
        encoding: "utf8",
      });
    }
    assert.equal(oldInvoke(["stock-set", "BRK", "5"]).status, 0);
    assert.equal(oldInvoke(["open", "WO1", "VIN1"]).status, 0);
    assert.equal(oldInvoke(["reserve", "BRK", "2"]).status, 0);
    assert.equal(oldInvoke(["start"]).status, 0);
    const oldDone = oldInvoke(["complete"]);
    assert.equal(oldDone.status, 0, oldDone.stdout + oldDone.stderr);
    const st = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st.status, "completed");
    assert.equal(st.used_qty, 2);
    assert.equal(st.used_marked, 1);
    assert.equal(st.shelf.BRK, 3);
    err(invoke(dir, service_url, ["mark-used", "2"]), "already_completed");
    err(invoke(dir, service_url, ["complete"]), "bad_status");
    const st2 = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st2.shelf.BRK, 3);
  } finally {
    child.kill("SIGKILL");
  }
});

test("pre-change started instance requires mark-used then restocks leftover", async () => {
  const { child, service_url } = await startStub();
  try {
    const dir = tmp();
    const OLD_RUN = "/tmp/desk-pre-change-N10r1/run";
    function oldInvoke(args) {
      return spawnSync(OLD_RUN, args, {
        cwd: "/tmp/desk-pre-change-N10r1",
        env: {
          ...process.env,
          STATE_DIR: dir,
          SERVICE_URL: service_url,
          NOW_MS: "1000",
        },
        encoding: "utf8",
      });
    }
    assert.equal(oldInvoke(["stock-set", "BRK", "5"]).status, 0);
    assert.equal(oldInvoke(["open", "WO1", "VIN1"]).status, 0);
    assert.equal(oldInvoke(["reserve", "BRK", "2"]).status, 0);
    assert.equal(oldInvoke(["start"]).status, 0);
    err(invoke(dir, service_url, ["complete"]), "usage_unmarked");
    const marked = ok(invoke(dir, service_url, ["mark-used", "0"]));
    assert.equal(marked.used_qty, 0);
    const done = ok(invoke(dir, service_url, ["complete"]));
    assert.equal(done.restocked_qty, 2);
    assert.equal(done.shelf.BRK, 5);
  } finally {
    child.kill("SIGKILL");
  }
});

test("corrupt owned store is corrupt_state and not rewritten", async () => {
  const { child, service_url } = await startStub();
  try {
    const dir = tmp();
    ok(invoke(dir, service_url, ["open", "WO1", "VIN1"]));
    const store = join(dir, "desk.sqlite");
    const before = readFileSync(store);
    writeFileSync(store, "this is not a sqlite database");
    err(invoke(dir, service_url, ["status"]), "corrupt_state");
    assert.equal(readFileSync(store).toString(), "this is not a sqlite database");
    writeFileSync(store, before);
    const st = ok(invoke(dir, service_url, ["status"]));
    assert.equal(st.wo_id, "WO1");
  } finally {
    child.kill("SIGKILL");
  }
});
