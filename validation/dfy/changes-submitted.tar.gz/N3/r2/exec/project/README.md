# Equipment loan desk

Local desk for registering equipment, holding a reservation until a collection
deadline, joining a waitlist, checking equipment out (one confirmation through
the mail service), and returning it. Lifecycle transitions and their durable
record are committed by the Ikaros runtime. The host only parses the command
line, talks to the mail service, and prints JSON.

## Setup

From this directory, with the shipped wheel (no network registry):

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index --no-deps KIT/python/*.whl
chmod +x run
```

`./run` locates `.venv/bin/python` and `KIT/bin/ik` itself. The evaluator does
not need `IK_BINARY` or a virtualenv activation.

## Run

```sh
STATE_DIR=/tmp/desk SERVICE_URL=http://127.0.0.1:9 ./run add-item camera-1
```

Environment:

- `STATE_DIR` — durable store directory. The desk writes only under
  `$STATE_DIR/ik/` (`desk.sqlite` and SQLite sidecars). Other files in
  `STATE_DIR` are left untouched.
- `SERVICE_URL` — mail service base URL, no trailing slash.
- `CRASH_AT` — optional crash label from the brief. The process sends itself
  `SIGKILL` only when that boundary is reached.

`wait <item_id> <wait_id> <borrower_id> <address> <hold_seconds> <now>` joins
the ordered waitlist for a reserved or checked-out item. When an expired
reservation or returned loan frees an item, the head is promoted into a new
reservation and receives one `waitlist_ready` message using the wait id as its
request id. `reconcile <wait_id>` resolves an uncertain promotion without
submitting another message.

The mail stub is `stub/server.mjs` (`node stub/server.mjs`). It binds an
ephemeral port and prints `service_url`. This desk does not open a listen port.

## Tests

```sh
.venv/bin/python tests/test_desk.py
```

## Lifecycle authority

Critical rules (namespace, reserve, expiry, waitlist promotion, attempt,
checkout confirmation, return) are an Ikaros external reducer,
`desk.reducer:LoanDeskReducer`. One desk aggregate holds every item so an id
claim and the item transition commit together. The kernel's single
pending-effect slot is not used: more than one item may have a saved attempt
at the same time, and a second planned effect on the same aggregate is refused
by the runtime. Checkout confirmation identity is the loan id; promotion
identity is the wait id. Each is stored on its attempt and reused for every
lookup and POST.
