"""Equipment loan desk."""
