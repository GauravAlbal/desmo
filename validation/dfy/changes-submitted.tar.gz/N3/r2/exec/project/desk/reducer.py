"""Loan-desk lifecycle. Rust commits; this reducer only decides transitions."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Mapping, Optional

from invariant_kernel import ApplyOutcome, Decision, DomainEvent, ReducerDiagnostic, ReducerIdentity

_SOURCE = Path(__file__).read_bytes()
_CODE_DIGEST = hashlib.sha256(_SOURCE).hexdigest()
_COMMAND_SCHEMA = hashlib.sha256(b"loan-desk-commands-v2-waitlist").hexdigest()
_STATE_SCHEMA = hashlib.sha256(b"loan-desk-state-v2-waitlist").hexdigest()


def _blank_item() -> dict[str, Any]:
    return {
        "availability": "available",
        "reservation_id": None,
        "borrower_id": None,
        "address": None,
        "collect_by": None,
        "reservation_state": "none",
        "loan_id": None,
        "loan_state": "none",
        "notify": "none",
        "attempt_reservation_id": None,
        "attempt_borrower_id": None,
        "attempt_address": None,
        "waitlist": [],
        "expired_reservations": [],
        "promotion_request_id": None,
        "promotion_wait_id": None,
        "promotion_borrower_id": None,
        "promotion_address": None,
        "promotion_notify": "none",
    }


def _clone(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {key: _clone(child) for key, child in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clone(child) for child in value]
    return value


def _copy_state(state: Mapping[str, Any]) -> dict[str, Any]:
    nxt = _clone(state)
    nxt.setdefault("items", {})
    nxt.setdefault("ids", {})
    nxt.setdefault("loans", {})
    nxt.setdefault("promotions", {})
    for item in nxt["items"].values():
        for key, value in _blank_item().items():
            item.setdefault(key, _clone(value))
    return nxt


def _refuse(code: str, message: str) -> ReducerDiagnostic:
    return ReducerDiagnostic(code, message, code)


def _args(command: Mapping[str, Any]) -> Mapping[str, Any]:
    args = command.get("args") or {}
    return args if isinstance(args, Mapping) else {}


def _due(item: Mapping[str, Any], now: int) -> bool:
    return (
        item.get("availability") == "reserved"
        and item.get("reservation_state") == "active"
        and item.get("collect_by") is not None
        and now >= int(item["collect_by"])
    )


def _promotion_event(
    item_id: str,
    item: Mapping[str, Any],
    now: int,
    *,
    source: str,
) -> DomainEvent:
    waiter = item["waitlist"][0]
    return DomainEvent(
        "promotion_started",
        1,
        {
            "item_id": item_id,
            "previous_reservation_id": item.get("reservation_id"),
            "wait_id": waiter["wait_id"],
            "borrower_id": waiter["borrower_id"],
            "address": waiter["address"],
            "hold_seconds": waiter["hold_seconds"],
            "collect_by": now + waiter["hold_seconds"],
            "source": source,
            "loan_id": item.get("loan_id"),
        },
    )


class LoanDeskReducer:
    identity = ReducerIdentity(
        reducer_name="loan_desk",
        reducer_version=2,
        code_digest=_CODE_DIGEST,
        command_schema_digest=_COMMAND_SCHEMA,
        state_schema_digest=_STATE_SCHEMA,
    )

    def initial_state(self) -> dict[str, Any]:
        return {"items": {}, "ids": {}, "loans": {}, "promotions": {}}

    def decide(
        self,
        state: Any,
        observation: Optional[Any],
        effect: Any,
        command: Any,
    ) -> Decision | ReducerDiagnostic:
        del effect
        name = command.get("name") if isinstance(command, Mapping) else None
        args = _args(command) if isinstance(command, Mapping) else {}
        if name == "add_item":
            return self._add_item(state, args)
        if name == "reserve":
            return self._reserve(state, args)
        if name == "wait":
            return self._wait(state, args)
        if name == "expire":
            return self._expire(state, args)
        if name == "begin_checkout":
            return self._begin_checkout(state, args)
        if name == "commit_sent":
            return self._commit_sent(state, args, observation)
        if name == "return_item":
            return self._return_item(state, args)
        return _refuse("bad_args", "unknown command")

    def apply(self, state: Any, event: DomainEvent) -> ApplyOutcome | ReducerDiagnostic:
        nxt = _copy_state(state)
        payload = dict(event.payload)
        kind = event.event_type
        if kind == "item_added":
            item_id = payload["item_id"]
            nxt["items"][item_id] = _blank_item()
            nxt["ids"][item_id] = "item"
        elif kind == "wait_added":
            nxt["items"][payload["item_id"]]["waitlist"].append(
                {
                    "wait_id": payload["wait_id"],
                    "borrower_id": payload["borrower_id"],
                    "address": payload["address"],
                    "hold_seconds": payload["hold_seconds"],
                }
            )
            nxt["ids"][payload["wait_id"]] = "wait"
        elif kind == "reserved":
            item = nxt["items"][payload["item_id"]]
            if payload.get("expire_first") and item.get("reservation_id"):
                item["expired_reservations"].append(item["reservation_id"])
                item["reservation_state"] = "expired"
                item["availability"] = "available"
            item["availability"] = "reserved"
            item["reservation_id"] = payload["reservation_id"]
            item["borrower_id"] = payload["borrower_id"]
            item["address"] = payload["address"]
            item["collect_by"] = payload["collect_by"]
            item["reservation_state"] = "active"
            nxt["ids"][payload["reservation_id"]] = "reservation"
        elif kind == "expired":
            item = nxt["items"][payload["item_id"]]
            if item.get("reservation_id"):
                item["expired_reservations"].append(item["reservation_id"])
            item["availability"] = "available"
            item["reservation_state"] = "expired"
        elif kind == "promotion_started":
            item = nxt["items"][payload["item_id"]]
            previous = payload.get("previous_reservation_id")
            if previous:
                item["expired_reservations"].append(previous)
            item["waitlist"] = item["waitlist"][1:]
            item["availability"] = "reserved"
            item["reservation_id"] = payload["wait_id"]
            item["borrower_id"] = payload["borrower_id"]
            item["address"] = payload["address"]
            item["collect_by"] = payload["collect_by"]
            item["reservation_state"] = "active"
            item["promotion_request_id"] = payload["wait_id"]
            item["promotion_wait_id"] = payload["wait_id"]
            item["promotion_borrower_id"] = payload["borrower_id"]
            item["promotion_address"] = payload["address"]
            item["promotion_notify"] = "attempt_saved"
            nxt["promotions"][payload["wait_id"]] = payload["item_id"]
        elif kind == "attempt_saved":
            item = nxt["items"][payload["item_id"]]
            item["loan_id"] = payload["loan_id"]
            item["loan_state"] = "attempt_saved"
            item["notify"] = "attempt_saved"
            item["attempt_reservation_id"] = payload["reservation_id"]
            item["attempt_borrower_id"] = payload["borrower_id"]
            item["attempt_address"] = payload["address"]
            nxt["ids"][payload["loan_id"]] = "loan"
            nxt["loans"][payload["loan_id"]] = payload["item_id"]
        elif kind == "checked_out":
            item = nxt["items"][payload["item_id"]]
            item["availability"] = "checked_out"
            item["reservation_state"] = "collected"
            item["loan_state"] = "checked_out"
            item["notify"] = "sent"
            item["loan_id"] = payload["loan_id"]
        elif kind == "returned":
            item = nxt["items"][payload["item_id"]]
            item["availability"] = "available"
            item["loan_state"] = "returned"
            item["notify"] = "sent"
        elif kind == "returned_promoted":
            item = nxt["items"][payload["item_id"]]
            item["availability"] = "reserved"
            item["loan_state"] = "returned"
            item["notify"] = "sent"
            self._apply_promotion(item, nxt, payload)
        elif kind == "promotion_sent":
            item = nxt["items"][payload["item_id"]]
            item["promotion_notify"] = "sent"
        else:
            return _refuse("bad_args", "unknown event")
        return ApplyOutcome.new(nxt)

    @staticmethod
    def _apply_promotion(item: dict[str, Any], state: dict[str, Any], payload: Mapping[str, Any]) -> None:
        previous = payload.get("previous_reservation_id")
        if previous:
            item["expired_reservations"].append(previous)
        item["waitlist"] = item["waitlist"][1:]
        item["reservation_id"] = payload["wait_id"]
        item["borrower_id"] = payload["borrower_id"]
        item["address"] = payload["address"]
        item["collect_by"] = payload["collect_by"]
        item["reservation_state"] = "active"
        item["promotion_request_id"] = payload["wait_id"]
        item["promotion_wait_id"] = payload["wait_id"]
        item["promotion_borrower_id"] = payload["borrower_id"]
        item["promotion_address"] = payload["address"]
        item["promotion_notify"] = "attempt_saved"
        state["promotions"][payload["wait_id"]] = payload["item_id"]

    def _add_item(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        if not isinstance(item_id, str):
            return _refuse("bad_args", "item id required")
        if item_id in state["ids"]:
            return _refuse("id_in_use", "id already in the desk namespace")
        return Decision.emit(DomainEvent("item_added", 1, {"item_id": item_id}))

    def _reserve(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        reservation_id = args.get("reservation_id")
        borrower_id = args.get("borrower_id")
        address = args.get("address")
        collect_by = args.get("collect_by")
        now = args.get("now")
        if (
            not isinstance(item_id, str)
            or not isinstance(reservation_id, str)
            or not isinstance(borrower_id, str)
            or not isinstance(address, str)
            or type(collect_by) is not int
            or type(now) is not int
            or collect_by <= now
        ):
            return _refuse("bad_args", "reserve arguments are not usable")
        item = state["items"].get(item_id)
        if item is None:
            return _refuse("unknown_item", "item is not registered")
        if item.get("promotion_notify") == "attempt_saved":
            return Decision.noop()
        if _due(item, now):
            if item.get("waitlist"):
                return Decision.emit(_promotion_event(item_id, item, now, source="expiry"))
            expire_first = True
        else:
            expire_first = False
        if not expire_first and (
            item["availability"] == "checked_out"
            or (item["availability"] == "reserved" and item["reservation_state"] == "active")
        ):
            return _refuse("not_available", "item is not available")
        if reservation_id in state["ids"]:
            return _refuse("id_in_use", "reservation id is already in the namespace")
        return Decision.emit(
            DomainEvent(
                "reserved",
                1,
                {
                    "item_id": item_id,
                    "reservation_id": reservation_id,
                    "borrower_id": borrower_id,
                    "address": address,
                    "collect_by": collect_by,
                    "expire_first": expire_first,
                },
            )
        )

    def _wait(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        wait_id = args.get("wait_id")
        borrower_id = args.get("borrower_id")
        address = args.get("address")
        hold_seconds = args.get("hold_seconds")
        if (
            not isinstance(item_id, str)
            or not isinstance(wait_id, str)
            or not isinstance(borrower_id, str)
            or not isinstance(address, str)
            or type(hold_seconds) is not int
        ):
            return _refuse("bad_args", "wait arguments are not usable")
        item = state["items"].get(item_id)
        if item is None:
            return _refuse("unknown_item", "item is not registered")
        if item["availability"] == "available":
            return _refuse("not_needed", "item is available")
        if wait_id in state["ids"]:
            return _refuse("id_in_use", "wait id is already in the namespace")
        if borrower_id == item.get("borrower_id") or any(
            row["borrower_id"] == borrower_id for row in item.get("waitlist", [])
        ):
            return _refuse("already_waiting", "borrower is already waiting")
        return Decision.emit(
            DomainEvent(
                "wait_added",
                1,
                {
                    "item_id": item_id,
                    "wait_id": wait_id,
                    "borrower_id": borrower_id,
                    "address": address,
                    "hold_seconds": hold_seconds,
                },
            )
        )

    def _expire(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        now = args.get("now")
        if not isinstance(item_id, str) or type(now) is not int:
            return _refuse("bad_args", "expire arguments are not usable")
        item = state["items"].get(item_id)
        if item is None:
            return _refuse("unknown_item", "item is not registered")
        if item.get("promotion_notify") == "attempt_saved":
            return Decision.noop()
        if _due(item, now):
            if item.get("waitlist"):
                return Decision.emit(_promotion_event(item_id, item, now, source="expiry"))
            return Decision.emit(DomainEvent("expired", 1, {"item_id": item_id}))
        return Decision.noop()

    def _begin_checkout(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        reservation_id = args.get("reservation_id")
        loan_id = args.get("loan_id")
        now = args.get("now")
        if (
            not isinstance(item_id, str)
            or not isinstance(reservation_id, str)
            or not isinstance(loan_id, str)
            or type(now) is not int
        ):
            return _refuse("bad_args", "checkout arguments are not usable")
        item = state["items"].get(item_id)
        if item is None:
            return _refuse("unknown_item", "item is not registered")
        if reservation_id in item.get("expired_reservations", []) and item.get("promotion_notify") == "attempt_saved":
            return Decision.noop()
        if _due(item, now):
            if item.get("waitlist"):
                return Decision.emit(_promotion_event(item_id, item, now, source="expiry"))
            return Decision.emit(
                DomainEvent("expired", 1, {"item_id": item_id, "named_reservation_id": reservation_id})
            )
        if reservation_id in item.get("expired_reservations", []):
            if item.get("promotion_notify") == "attempt_saved":
                return Decision.noop()
            return _refuse("expired", "reservation is expired")
        if item["availability"] == "checked_out" or item["loan_state"] == "checked_out":
            return _refuse("already_checked_out", "item is already checked out")
        if item["reservation_state"] == "expired" and item["reservation_id"] == reservation_id:
            return _refuse("expired", "reservation is already expired")
        if item["reservation_state"] != "active":
            return _refuse("not_reserved", "item has no active reservation")
        if item["reservation_id"] != reservation_id:
            return _refuse("reservation_mismatch", "reservation does not match")
        if item["loan_state"] == "attempt_saved":
            if item["loan_id"] != loan_id:
                return _refuse("checkout_in_progress", "a different loan attempt is saved")
            if item["attempt_reservation_id"] != reservation_id:
                return _refuse("reservation_mismatch", "saved attempt is for another reservation")
            return Decision.noop()
        if loan_id in state["ids"]:
            return _refuse("id_in_use", "loan id is already in the namespace")
        return Decision.emit(
            DomainEvent(
                "attempt_saved",
                1,
                {
                    "item_id": item_id,
                    "loan_id": loan_id,
                    "reservation_id": reservation_id,
                    "borrower_id": item["borrower_id"],
                    "address": item["address"],
                },
            )
        )

    def _commit_sent(
        self,
        state: Mapping[str, Any],
        args: Mapping[str, Any],
        observation: Optional[Any],
    ) -> Decision | ReducerDiagnostic:
        request_id = args.get("request_id") or args.get("loan_id")
        if not isinstance(request_id, str) or not isinstance(observation, Mapping):
            return _refuse("bad_args", "request and observation required")
        promotion_item_id = state.get("promotions", {}).get(request_id)
        if promotion_item_id is not None:
            item = state["items"][promotion_item_id]
            if item["promotion_notify"] == "sent":
                return Decision.noop()
            if not self._matches_promotion(observation, promotion_item_id, item, request_id):
                return _refuse("conflict", "service observation does not match promotion")
            return Decision.emit(
                DomainEvent("promotion_sent", 1, {"item_id": promotion_item_id, "request_id": request_id})
            )
        item_id = state["loans"].get(request_id)
        if item_id is None:
            return _refuse("unknown_item", "no attempt for that request")
        item = state["items"][item_id]
        if item["notify"] == "sent" and item["loan_state"] in {"checked_out", "returned"}:
            return Decision.noop()
        if item["loan_state"] != "attempt_saved" or item["notify"] != "attempt_saved":
            return _refuse("not_reserved", "no saved attempt to confirm")
        if not self._matches_checkout(observation, item_id, item, request_id):
            return _refuse("conflict", "service observation does not match the attempt")
        return Decision.emit(DomainEvent("checked_out", 1, {"item_id": item_id, "loan_id": request_id}))

    @staticmethod
    def _matches_checkout(body: Mapping[str, Any], item_id: str, item: Mapping[str, Any], request_id: str) -> bool:
        return (
            body.get("request_id") == request_id
            and body.get("item_id") == item_id
            and body.get("borrower_id") == item.get("attempt_borrower_id")
            and body.get("address") == item.get("attempt_address")
            and body.get("kind") == "checkout"
            and body.get("outcome") == "accepted"
        )

    @staticmethod
    def _matches_promotion(body: Mapping[str, Any], item_id: str, item: Mapping[str, Any], request_id: str) -> bool:
        return (
            body.get("request_id") == request_id
            and body.get("item_id") == item_id
            and body.get("borrower_id") == item.get("promotion_borrower_id")
            and body.get("address") == item.get("promotion_address")
            and body.get("kind") == "waitlist_ready"
            and body.get("outcome") == "accepted"
        )

    def _return_item(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        loan_id = args.get("loan_id")
        now = args.get("now")
        if not isinstance(item_id, str) or not isinstance(loan_id, str) or type(now) is not int:
            return _refuse("bad_args", "return arguments are not usable")
        item = state["items"].get(item_id)
        if item is None:
            return _refuse("unknown_item", "item is not registered")
        if item["loan_state"] == "returned" and item["loan_id"] == loan_id and item.get("promotion_notify") == "attempt_saved":
            return Decision.noop()
        if item["availability"] != "checked_out":
            return _refuse("not_checked_out", "item is not checked out")
        if item["loan_id"] != loan_id:
            return _refuse("loan_mismatch", "loan id does not match the active loan")
        if item.get("waitlist"):
            promotion = _promotion_event(item_id, item, now, source="return")
            return Decision.emit(DomainEvent("returned_promoted", 1, dict(promotion.payload)))
        return Decision.emit(DomainEvent("returned", 1, {"item_id": item_id, "loan_id": loan_id}))
