#!/usr/bin/env python3
"""Process-level checks for the loan desk, including restart, crash, and lost reply."""

from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "run"
NODE = os.environ.get("NODE", "/Users/galbal/.nvm/versions/node/v22.17.1/bin/node")


class Failure(Exception):
    pass


def check(cond: bool, message: str) -> None:
    if not cond:
        raise Failure(message)


def invoke(state: Path, service: str, args: list[str], crash: str | None = None) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["STATE_DIR"] = str(state)
    env["SERVICE_URL"] = service
    if crash is None:
        env.pop("CRASH_AT", None)
    else:
        env["CRASH_AT"] = crash
    return subprocess.run(
        [str(RUN), *args],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
    )


def ok(state: Path, service: str, args: list[str], crash: str | None = None) -> dict:
    proc = invoke(state, service, args, crash)
    check(proc.returncode == 0, f"{args} exit {proc.returncode} stdout={proc.stdout!r} stderr={proc.stderr!r}")
    check(proc.stdout.count("\n") == 1, f"stdout not one line: {proc.stdout!r}")
    return json.loads(proc.stdout)


def refused(state: Path, service: str, args: list[str], code: str) -> dict:
    proc = invoke(state, service, args)
    check(proc.returncode != 0, f"{args} should refuse, stdout={proc.stdout!r}")
    check(proc.stdout.count("\n") == 1, f"stdout not one line: {proc.stdout!r}")
    body = json.loads(proc.stdout)
    check(body.get("error") == code, f"{args} error {body} != {code}")
    return body


def start_stub() -> tuple[subprocess.Popen[str], str, str]:
    proc = subprocess.Popen(
        [NODE, str(ROOT / "stub" / "server.mjs")],
        cwd=ROOT / "stub",
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    assert proc.stdout is not None
    line = proc.stdout.readline()
    info = json.loads(line)
    return proc, info["service_url"], info["control_url"]


def control(control_url: str, method: str, path: str, payload: dict | None = None) -> dict:
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(control_url + path, data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=5) as resp:
        return json.loads(resp.read().decode())


def effects(control_url: str) -> dict:
    return control(control_url, "GET", "/effects")


def past_deadline_checkout(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-due-"))
    try:
        ok(state, service, ["add-item", "box"])
        ok(state, service, ["reserve", "box", "res-b", "ada", "ada@lab.example", "10", "1"])
        before = effects(control_url)["count"]
        refused(state, service, ["checkout", "box", "res-b", "loan-b", "10"], "expired")
        check(effects(control_url)["count"] == before, "due checkout contacted the service")
        status = ok(state, service, ["status", "box", "10"])
        check(status["availability"] == "available" and status["reservation_state"] == "expired", status)
        check(status["past_deadline"] is True, status)
        reserved = ok(state, service, ["reserve", "box", "res-b2", "ada", "ada@lab.example", "20", "10"])
        check(reserved["availability"] == "reserved", reserved)
        killed = invoke(state, service, ["checkout", "box", "res-b2", "loan-b2", "11"], "after-attempt-saved-before-request")
        check(abs(killed.returncode) == signal.SIGKILL, killed.returncode)
        rec = ok(state, service, ["reconcile", "loan-b2"])
        check(rec["notify"] == "not_sent" and rec["kind"] == "checkout" and rec["item_id"] == "box", rec)
        check(ok(state, service, ["status", "box", "11"])["loan_state"] == "attempt_saved", "not_sent cleared the attempt")
        refused(state, service, ["reserve", "box", "res-b3", "ada", "ada@lab.example", "03", "1"], "bad_args")
        print("due-and-not-sent ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


def main() -> None:
    stub, service, control_url = start_stub()
    try:
        healthy(service, control_url)
        crash_and_lost(service, control_url)
        unrelated_writer(service)
        callback_and_return(service, control_url)
        past_deadline_checkout(service, control_url)
        waitlist_promotions(service, control_url)
    finally:
        stub.send_signal(signal.SIGTERM)
        stub.wait(timeout=5)


def healthy(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-healthy-"))
    try:
        added = ok(state, service, ["add-item", "cam-1"])
        check(added["availability"] == "available", added)
        ok(state, service, ["add-item", "cam-2"])
        refused(state, service, ["add-item", "cam-1"], "id_in_use")
        refused(state, service, ["add-item", "bad id"], "bad_args")
        refused(state, service, ["checkout", "missing", "r", "l", "1"], "unknown_item")
        reserved = ok(
            state,
            service,
            ["reserve", "cam-1", "res-1", "ada", "ada@lab.example", "50", "10"],
        )
        check(reserved["availability"] == "reserved" and reserved["collect_by"] == 50, reserved)
        status = ok(state, service, ["status", "cam-1", "10"])
        check(status["borrower_id"] == "ada" and status["address"] == "ada@lab.example", status)
        check(status["reservation_state"] == "active" and status["past_deadline"] is False, status)
        other = ok(state, service, ["status", "cam-2", "10"])
        check(other["availability"] == "available" and other["loan_id"] is None, other)
        stayed = ok(state, service, ["expire", "cam-1", "49"])
        check(stayed["expired"] is False and stayed["availability"] == "reserved", stayed)
        check(effects(control_url)["count"] == 0, "expire contacted the service")
        checked = ok(state, service, ["checkout", "cam-1", "res-1", "loan-1", "20"])
        check(checked["notify"] == "sent" and checked["request_id"] == "loan-1", checked)
        check(effects(control_url)["count"] == 1, effects(control_url))
        after = ok(state, service, ["status", "cam-1", "20"])
        check(after["availability"] == "checked_out" and after["loan_state"] == "checked_out", after)
        check(after["notify"] == "sent" and after["borrower_id"] == "ada", after)
        check(ok(state, service, ["status", "cam-2", "20"])["availability"] == "available", "second item moved")
        refused(state, service, ["checkout", "cam-1", "res-1", "loan-1", "21"], "already_checked_out")
        refused(state, service, ["checkout", "cam-1", "res-1", "loan-2", "21"], "already_checked_out")
        check(effects(control_url)["count"] == 1, "double checkout added an effect")
        refused(state, service, ["return", "cam-2", "loan-x", "22"], "not_checked_out")
        refused(state, service, ["return", "cam-1", "loan-x", "22"], "loan_mismatch")
        returned = ok(state, service, ["return", "cam-1", "loan-1", "22"])
        check(returned["availability"] == "available" and returned["loan_state"] == "returned", returned)
        refused(state, service, ["return", "cam-1", "loan-1", "23"], "not_checked_out")
        print("healthy ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


def crash_and_lost(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-crash-"))
    try:
        ok(state, service, ["add-item", "tripod"])
        ok(state, service, ["reserve", "tripod", "res-t", "bea", "bea@lab.example", "80", "5"])
        before = effects(control_url)["count"]
        killed = invoke(state, service, ["checkout", "tripod", "res-t", "loan-t", "6"], "after-attempt-saved-before-request")
        check(killed.returncode < 0 and abs(killed.returncode) == signal.SIGKILL, f"crash before request rc={killed.returncode} out={killed.stdout!r} err={killed.stderr!r}")
        check(effects(control_url)["count"] == before, "request was sent before the crash boundary")
        status = ok(state, service, ["status", "tripod", "6"])
        check(status["loan_state"] == "attempt_saved" and status["loan_id"] == "loan-t", status)
        refused(state, service, ["checkout", "tripod", "res-t", "loan-other", "6"], "checkout_in_progress")
        check(effects(control_url)["count"] == before, "progress refusal added an effect")
        done = ok(state, service, ["checkout", "tripod", "res-t", "loan-t", "7"])
        check(done["notify"] == "sent", done)
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        print("crash-before-request ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)

    state = Path(tempfile.mkdtemp(prefix="desk-accept-"))
    try:
        ok(state, service, ["add-item", "lamp"])
        ok(state, service, ["reserve", "lamp", "res-l", "cy", "cy@lab.example", "90", "1"])
        before = effects(control_url)["count"]
        killed = invoke(state, service, ["checkout", "lamp", "res-l", "loan-l", "2"], "after-accept-before-record")
        check(killed.returncode < 0 and abs(killed.returncode) == signal.SIGKILL, f"accept crash rc={killed.returncode} out={killed.stdout!r} err={killed.stderr!r}")
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        status = ok(state, service, ["status", "lamp", "2"])
        check(status["loan_state"] == "attempt_saved" and status["notify"] == "attempt_saved", status)
        resumed = ok(state, service, ["checkout", "lamp", "res-l", "loan-l", "3"])
        check(resumed["notify"] == "sent" and resumed["request_id"] == "loan-l", resumed)
        check(effects(control_url)["count"] == before + 1, "resume counted a second effect")
        after = ok(state, service, ["status", "lamp", "3"])
        check(after["availability"] == "checked_out" and after["notify"] == "sent", after)
        print("crash-after-accept ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)

    state = Path(tempfile.mkdtemp(prefix="desk-record-"))
    try:
        ok(state, service, ["add-item", "mic"])
        ok(state, service, ["reserve", "mic", "res-m", "dee", "dee@lab.example", "40", "4"])
        before = effects(control_url)["count"]
        killed = invoke(state, service, ["checkout", "mic", "res-m", "loan-m", "5"], "after-record-before-exit")
        check(killed.returncode < 0 and abs(killed.returncode) == signal.SIGKILL, f"record crash rc={killed.returncode} out={killed.stdout!r}")
        status = ok(state, service, ["status", "mic", "5"])
        check(status["availability"] == "checked_out" and status["notify"] == "sent", status)
        refused(state, service, ["checkout", "mic", "res-m", "loan-m", "6"], "already_checked_out")
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        print("crash-after-record ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)

    state = Path(tempfile.mkdtemp(prefix="desk-lost-"))
    try:
        ok(state, service, ["add-item", "stand"])
        ok(state, service, ["reserve", "stand", "res-s", "ed", "ed@lab.example", "70", "8"])
        before = effects(control_url)["count"]
        control(control_url, "POST", "/fault", {"drop_reply": True})
        lost = invoke(state, service, ["checkout", "stand", "res-s", "loan-s", "9"])
        check(lost.returncode != 0, f"lost reply should not look like success: {lost.stdout!r}")
        body = json.loads(lost.stdout)
        check(body.get("error") == "service_unavailable", body)
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        status = ok(state, service, ["status", "stand", "9"])
        check(status["loan_state"] == "attempt_saved", status)
        control(control_url, "POST", "/fault", {"drop_reply": False})
        reconciled = ok(state, service, ["reconcile", "loan-s"])
        check(reconciled["notify"] == "sent" and reconciled["availability"] == "checked_out", reconciled)
        check(reconciled.get("notify") != "not_sent", reconciled)
        check(effects(control_url)["count"] == before + 1, "reconcile added an effect")
        posts = effects(control_url)["posts"]
        loan_posts = [row for row in posts if row.get("request_id") == "loan-s"]
        check(len(loan_posts) == 1, loan_posts)
        print("lost-reply ok")
    finally:
        control(control_url, "POST", "/fault", {"drop_reply": False})
        shutil.rmtree(state, ignore_errors=True)


def unrelated_writer(service: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-writer-"))
    try:
        note = state / "other.txt"
        note.write_bytes(b"keep-me\n")
        ok(state, service, ["add-item", "case"])
        refused(state, service, ["reserve", "missing", "res-z", "ada", "ada@lab.example", "3", "1"], "unknown_item")
        check(note.read_bytes() == b"keep-me\n", "unrelated file changed")
        print("unrelated-writer ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


def callback_and_return(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-cb-"))
    try:
        ok(state, service, ["add-item", "drone"])
        ok(state, service, ["reserve", "drone", "res-d", "fay", "fay@lab.example", "30", "1"])
        early = ok(state, service, ["expire", "drone", "1"])
        check(early["expired"] is False, early)
        ok(state, service, ["expire", "drone", "30"])
        status = ok(state, service, ["status", "drone", "30"])
        check(status["availability"] == "available" and status["reservation_state"] == "expired", status)
        refused(state, service, ["checkout", "drone", "res-d", "loan-d", "31"], "expired")
        check(effects(control_url)["count"] == effects(control_url)["count"], "placeholder")
        before = effects(control_url)["count"]
        refused(state, service, ["checkout", "drone", "res-d", "loan-d", "31"], "expired")
        check(effects(control_url)["count"] == before, "expired checkout contacted service")
        ok(state, service, ["reserve", "drone", "res-d2", "fay", "fay@lab.example", "100", "31"])
        killed = invoke(state, service, ["checkout", "drone", "res-d2", "loan-d2", "32"], "after-record-before-exit")
        check(abs(killed.returncode) == signal.SIGKILL, killed.returncode)
        cb = state / "cb.json"
        cb.write_text(json.dumps({
            "callback_id": "cb-loan-d2",
            "request_id": "loan-d2",
            "item_id": "drone",
            "borrower_id": "fay",
            "address": "other@lab.example",
            "kind": "checkout",
            "outcome": "accepted",
        }))
        before = effects(control_url)["count"]
        first = ok(state, service, ["callback", str(cb)])
        second = ok(state, service, ["callback", str(cb)])
        check(first == {"ok": True} and second == {"ok": True}, (first, second))
        status = ok(state, service, ["status", "drone", "32"])
        check(status["availability"] == "checked_out" and status["address"] == "fay@lab.example", status)
        check(status["loan_id"] == "loan-d2" and status["notify"] == "sent", status)
        check(effects(control_url)["count"] == before, "callback added an effect")
        bad = state / "bad.json"
        bad.write_text("{")
        refused(state, service, ["callback", str(bad)], "bad_args")
        check((state / "other-absent").exists() is False, "callback created junk")
        none = ok(state, service, ["reconcile", "never-loan"])
        check(none["notify"] == "none" and none["loan_id"] is None and none["kind"] is None, none)
        print("expiry-callback ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


def waitlist_promotions(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-wait-"))
    try:
        ok(state, service, ["add-item", "wait-box"])
        ok(state, service, ["reserve", "wait-box", "res-0", "ada", "ada@lab.example", "10", "1"])
        first = ok(state, service, ["checkout", "wait-box", "res-0", "wait-loan-0", "2"])
        check(first["notify"] == "sent", first)
        ok(state, service, ["wait", "wait-box", "wait-1", "bea", "bea@lab.example", "5", "3"])
        ok(state, service, ["wait", "wait-box", "wait-2", "cy", "cy@lab.example", "7", "4"])
        refused(state, service, ["wait", "wait-box", "wait-3", "bea", "other@lab.example", "2", "5"], "already_waiting")
        promoted = ok(state, service, ["return", "wait-box", "wait-loan-0", "20"])
        check(promoted["availability"] == "reserved" and promoted["promoted_wait_id"] == "wait-1", promoted)
        status = ok(state, service, ["status", "wait-box", "20"])
        check(status["reservation_id"] == "wait-1" and [x["wait_id"] for x in status["waitlist"]] == ["wait-2"], status)
        check(status["promotion"]["notify"] == "sent", status)
        before = effects(control_url)["count"]
        refused(state, service, ["return", "wait-box", "wait-loan-0", "21"], "not_checked_out")
        check(effects(control_url)["count"] == before, "second return sent mail")
        refused(state, service, ["checkout", "wait-box", "res-0", "loan-old", "21"], "expired")
        checked = ok(state, service, ["checkout", "wait-box", "wait-1", "wait-loan-1", "6"])
        check(checked["notify"] == "sent", checked)
        returned = ok(state, service, ["return", "wait-box", "wait-loan-1", "30"])
        check(returned["promoted_wait_id"] == "wait-2", returned)
        effects_now = effects(control_url)
        kinds = [e["kind"] for e in effects_now["effects"] if e["request_id"] in {"wait-loan-0", "wait-1", "wait-loan-1", "wait-2"}]
        check(kinds == ["checkout", "waitlist_ready", "checkout", "waitlist_ready"], kinds)
        ok(state, service, ["add-item", "expire-box"])
        ok(state, service, ["reserve", "expire-box", "expire-res-0", "dee", "dee@lab.example", "10", "1"])
        ok(state, service, ["wait", "expire-box", "expire-wait-1", "fay", "fay@lab.example", "4", "2"])
        ok(state, service, ["wait", "expire-box", "expire-wait-2", "gus", "gus@lab.example", "5", "3"])
        first_expiry = ok(state, service, ["expire", "expire-box", "10"])
        check(first_expiry["promoted_wait_id"] == "expire-wait-1" and first_expiry["notify"] == "sent", first_expiry)
        before_chain = effects(control_url)["count"]
        ok(state, service, ["expire", "expire-box", "13"])
        check(effects(control_url)["count"] == before_chain, "early chained expiry sent mail")
        second_expiry = ok(state, service, ["expire", "expire-box", "14"])
        check(second_expiry["promoted_wait_id"] == "expire-wait-2" and effects(control_url)["count"] == before_chain + 1, second_expiry)
        refused(state, service, ["checkout", "expire-box", "expire-res-0", "expire-loan", "15"], "expired")
        ok(state, service, ["add-item", "uncertain-box"])
        ok(state, service, ["reserve", "uncertain-box", "uncertain-res", "hal", "hal@lab.example", "50", "1"])
        ok(state, service, ["checkout", "uncertain-box", "uncertain-res", "uncertain-loan", "2"])
        ok(state, service, ["wait", "uncertain-box", "uncertain-wait", "ivy", "ivy@lab.example", "5", "3"])
        control(control_url, "POST", "/fault", {"drop_reply": True})
        uncertain = invoke(state, service, ["return", "uncertain-box", "uncertain-loan", "10"])
        check(uncertain.returncode != 0 and json.loads(uncertain.stdout)["error"] == "service_unavailable", uncertain.stdout)
        control(control_url, "POST", "/fault", {"drop_reply": False})
        reconciled = ok(state, service, ["reconcile", "uncertain-wait"])
        check(reconciled["notify"] == "sent" and reconciled["kind"] == "waitlist_ready", reconciled)
        posts = [row for row in effects(control_url)["posts"] if row["request_id"] == "uncertain-wait" and row["stored"]]
        check(len(posts) == 1, posts)
        ok(state, service, ["add-item", "crash-box"])
        ok(state, service, ["reserve", "crash-box", "crash-res", "jan", "jan@lab.example", "70", "1"])
        ok(state, service, ["checkout", "crash-box", "crash-res", "crash-loan", "2"])
        ok(state, service, ["wait", "crash-box", "crash-wait", "kai", "kai@lab.example", "5", "3"])
        killed = invoke(state, service, ["return", "crash-box", "crash-loan", "10"], "after-attempt-saved-before-request")
        check(killed.returncode < 0 and abs(killed.returncode) == signal.SIGKILL, killed.returncode)
        pending = ok(state, service, ["status", "crash-box", "10"])
        check(pending["promotion"]["notify"] == "attempt_saved" and pending["reservation_id"] == "crash-wait", pending)
        ok(state, service, ["return", "crash-box", "crash-loan", "11"])
        check(len([row for row in effects(control_url)["effects"] if row["request_id"] == "crash-wait"]) == 1, "crash promotion duplicated")
        print("waitlist-promotions ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


if __name__ == "__main__":
    try:
        main()
    except Failure as exc:
        print(f"FAIL {exc}")
        raise SystemExit(1)
