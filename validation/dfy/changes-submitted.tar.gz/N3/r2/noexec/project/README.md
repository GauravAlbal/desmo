# Equipment loan desk

Local desk for registering equipment, holding a reservation until a collection
deadline, checking it out (one confirmation through the mail service), and
returning it. A `wait` list may form while an item is reserved or checked
out: when the active reservation expires or the loan is returned, the desk
promotes the waitlist head into a fresh reservation and sends it one
`waitlist_ready` notice, exactly once. Lifecycle transitions and their
durable record are committed by the Ikaros runtime. The host only parses the
command line, talks to the mail service, and prints JSON.

## Setup

From this directory, with the shipped wheel (no network registry):

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index --no-deps KIT/python/*.whl
chmod +x run
```

`./run` locates `.venv/bin/python` and `KIT/bin/ik` itself. The evaluator does
not need `IK_BINARY` or a virtualenv activation.

## Run

```sh
STATE_DIR=/tmp/desk SERVICE_URL=http://127.0.0.1:9 ./run add-item camera-1
```

Environment:

- `STATE_DIR` — durable store directory. The desk writes only under
  `$STATE_DIR/ik/` (`desk.sqlite` and SQLite sidecars). Other files in
  `STATE_DIR` are left untouched.
- `SERVICE_URL` — mail service base URL, no trailing slash.
- `CRASH_AT` — optional crash label from the brief. The process sends itself
  `SIGKILL` only when that boundary is reached. The three labels now also
  apply to a promotion send inside `return`, `expire`, and the expiry path
  of `checkout`.

The mail stub is `stub/server.mjs` (`node stub/server.mjs`). It binds an
ephemeral port and prints `service_url`. This desk does not open a listen port.

## Commands

`add-item`, `reserve`, `expire`, `checkout`, `return`, `status`, `reconcile`,
and `callback` are as specified in `BRIEF.md`. `wait` (added by `CHANGE.md`)
appends a borrower to an item's waitlist:

```sh
./run wait <item_id> <wait_id> <borrower_id> <address> <hold_seconds> <now>
```

`status` now also reports `waitlist` (join order) and `promotion` (the
item's current promotion-notice state) on every item. `reconcile <id>`
accepts either a loan id or a promotion request id (the wait id).

## Tests

```sh
.venv/bin/python tests/test_desk.py
```

## Lifecycle authority

Critical rules (namespace, reserve, expiry, attempt, checkout confirmation,
return, waitlist join, and promotion) are an Ikaros external reducer,
`desk.reducer:LoanDeskReducer` (`reducer_version=2`; the state and command
schema digests changed with this revision). One desk aggregate holds every
item so an id claim and the item transition commit together. The kernel's
single pending-effect slot is not used: more than one item may have a saved
attempt at the same time, and a second planned effect on the same aggregate
is refused by the runtime. Confirmation identity is the loan id for a
checkout confirmation, or the wait id for a promotion notice; both are
stored on the matching attempt and reused for every lookup and POST.

Because the reducer's identity (`reducer_version`, code digest, and state
schema digest) changed, a store created by the previous revision of this
desk is a different bound machine identity. The runtime does not migrate it
in place; a process started against such a store with this code will see a
capability/identity mismatch rather than silently reinterpreting old rows
under the new shape. Start a fresh `STATE_DIR` for this revision.
