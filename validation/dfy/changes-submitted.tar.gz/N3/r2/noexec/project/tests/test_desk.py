#!/usr/bin/env python3
"""Process-level checks for the loan desk, including restart, crash, and lost reply."""

from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import tempfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "run"
NODE = os.environ.get("NODE", "/Users/galbal/.nvm/versions/node/v22.17.1/bin/node")


class Failure(Exception):
    pass


def check(cond: bool, message: str) -> None:
    if not cond:
        raise Failure(message)


def invoke(state: Path, service: str, args: list[str], crash: str | None = None) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["STATE_DIR"] = str(state)
    env["SERVICE_URL"] = service
    if crash is None:
        env.pop("CRASH_AT", None)
    else:
        env["CRASH_AT"] = crash
    return subprocess.run(
        [str(RUN), *args],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
    )


def ok(state: Path, service: str, args: list[str], crash: str | None = None) -> dict:
    proc = invoke(state, service, args, crash)
    check(proc.returncode == 0, f"{args} exit {proc.returncode} stdout={proc.stdout!r} stderr={proc.stderr!r}")
    check(proc.stdout.count("\n") == 1, f"stdout not one line: {proc.stdout!r}")
    return json.loads(proc.stdout)


def refused(state: Path, service: str, args: list[str], code: str) -> dict:
    proc = invoke(state, service, args)
    check(proc.returncode != 0, f"{args} should refuse, stdout={proc.stdout!r}")
    check(proc.stdout.count("\n") == 1, f"stdout not one line: {proc.stdout!r}")
    body = json.loads(proc.stdout)
    check(body.get("error") == code, f"{args} error {body} != {code}")
    return body


def start_stub() -> tuple[subprocess.Popen[str], str, str]:
    proc = subprocess.Popen(
        [NODE, str(ROOT / "stub" / "server.mjs")],
        cwd=ROOT / "stub",
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    assert proc.stdout is not None
    line = proc.stdout.readline()
    info = json.loads(line)
    return proc, info["service_url"], info["control_url"]


def control(control_url: str, method: str, path: str, payload: dict | None = None) -> dict:
    data = None if payload is None else json.dumps(payload).encode()
    req = urllib.request.Request(control_url + path, data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req, timeout=5) as resp:
        return json.loads(resp.read().decode())


def effects(control_url: str) -> dict:
    return control(control_url, "GET", "/effects")


def past_deadline_checkout(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-due-"))
    try:
        ok(state, service, ["add-item", "box"])
        ok(state, service, ["reserve", "box", "res-b", "ada", "ada@lab.example", "10", "1"])
        before = effects(control_url)["count"]
        refused(state, service, ["checkout", "box", "res-b", "loan-b", "10"], "expired")
        check(effects(control_url)["count"] == before, "due checkout contacted the service")
        status = ok(state, service, ["status", "box", "10"])
        check(status["availability"] == "available" and status["reservation_state"] == "expired", status)
        check(status["past_deadline"] is True, status)
        reserved = ok(state, service, ["reserve", "box", "res-b2", "ada", "ada@lab.example", "20", "10"])
        check(reserved["availability"] == "reserved", reserved)
        killed = invoke(state, service, ["checkout", "box", "res-b2", "loan-b2", "11"], "after-attempt-saved-before-request")
        check(abs(killed.returncode) == signal.SIGKILL, killed.returncode)
        rec = ok(state, service, ["reconcile", "loan-b2"])
        check(rec["notify"] == "not_sent" and rec["kind"] == "checkout" and rec["item_id"] == "box", rec)
        check(ok(state, service, ["status", "box", "11"])["loan_state"] == "attempt_saved", "not_sent cleared the attempt")
        refused(state, service, ["reserve", "box", "res-b3", "ada", "ada@lab.example", "03", "1"], "bad_args")
        print("due-and-not-sent ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


def waitlist_join_order(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-wait-"))
    try:
        ok(state, service, ["add-item", "drum"])
        refused(state, service, ["wait", "drum", "w1", "amy", "amy@lab.example", "100", "1"], "not_needed")
        ok(state, service, ["reserve", "drum", "res-w", "amy", "amy@lab.example", "50", "1"])
        before = effects(control_url)["count"]
        first = ok(state, service, ["wait", "drum", "w1", "bo", "bo@lab.example", "100", "2"])
        check(first["position"] == 1 and first["availability"] == "reserved", first)
        second = ok(state, service, ["wait", "drum", "w2", "cy", "cy@lab.example", "200", "3"])
        check(second["position"] == 2, second)
        refused(state, service, ["wait", "drum", "w3", "bo", "bo@lab.example", "100", "4"], "already_waiting")
        refused(state, service, ["wait", "drum", "w1", "dee", "dee@lab.example", "100", "4"], "id_in_use")
        refused(state, service, ["wait", "drum", "w4", "amy", "amy@lab.example", "100", "4"], "already_waiting")
        check(effects(control_url)["count"] == before, "joining the waitlist contacted the service")
        status = ok(state, service, ["status", "drum", "4"])
        check([w["wait_id"] for w in status["waitlist"]] == ["w1", "w2"], status)
        check(status["promotion"] == {"request_id": None, "notify": "none", "wait_id": None}, status)
        print("waitlist-join-order ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


def return_promotes_once(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-return-promote-"))
    try:
        ok(state, service, ["add-item", "scope"])
        ok(state, service, ["reserve", "scope", "res-r", "amy", "amy@lab.example", "50", "1"])
        checked = ok(state, service, ["checkout", "scope", "res-r", "loan-r", "2"])
        check(checked["notify"] == "sent", checked)
        before = effects(control_url)["count"]
        ok(state, service, ["wait", "scope", "w1", "bo", "bo@lab.example", "300", "3"])
        ok(state, service, ["wait", "scope", "w2", "cy", "cy@lab.example", "400", "3"])
        returned = ok(state, service, ["return", "scope", "loan-r", "5"])
        check(returned["availability"] == "reserved" and returned["promoted_wait_id"] == "w1", returned)
        check(returned["notify"] == "sent" and returned["loan_state"] == "returned", returned)
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        status = ok(state, service, ["status", "scope", "5"])
        check(status["reservation_id"] == "w1" and status["borrower_id"] == "bo", status)
        check(status["collect_by"] == 5 + 300, status)
        check([w["wait_id"] for w in status["waitlist"]] == ["w2"], status)
        refused(state, service, ["return", "scope", "loan-r", "6"], "not_checked_out")
        check(effects(control_url)["count"] == before + 1, "second return added an effect")
        print("return-promotes-once ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


def return_empty_waitlist_unaffected(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-return-empty-"))
    try:
        ok(state, service, ["add-item", "mug"])
        ok(state, service, ["reserve", "mug", "res-mg", "amy", "amy@lab.example", "50", "1"])
        ok(state, service, ["checkout", "mug", "res-mg", "loan-mg", "2"])
        before = effects(control_url)["count"]
        returned = ok(state, service, ["return", "mug", "loan-mg", "5"])
        check(returned["availability"] == "available" and returned["promoted_wait_id"] is None, returned)
        check(returned["notify"] == "none", returned)
        check(effects(control_url)["count"] == before, "return with an empty waitlist added an effect")
        print("return-empty-waitlist ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


def expire_promotes_and_chains(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-expire-promote-"))
    try:
        ok(state, service, ["add-item", "ladder"])
        ok(state, service, ["reserve", "ladder", "res-e", "amy", "amy@lab.example", "10", "1"])
        ok(state, service, ["wait", "ladder", "w1", "bo", "bo@lab.example", "50", "2"])
        ok(state, service, ["wait", "ladder", "w2", "cy", "cy@lab.example", "60", "2"])
        before = effects(control_url)["count"]
        refused(state, service, ["reserve", "ladder", "res-e2", "dee", "dee@lab.example", "999", "10"], "not_available")
        check(effects(control_url)["count"] == before + 1, "due reserve did not promote exactly once")
        status = ok(state, service, ["status", "ladder", "10"])
        check(status["availability"] == "reserved" and status["reservation_id"] == "w1", status)
        check(status["collect_by"] == 10 + 50, status)
        check(status["promotion"]["notify"] == "sent" and status["promotion"]["wait_id"] == "w1", status)
        refused(state, service, ["checkout", "ladder", "res-e", "loan-e", "11"], "expired")
        check(effects(control_url)["count"] == before + 1, "checkout of the original id added an effect")
        before2 = effects(control_url)["count"]
        stayed = ok(state, service, ["expire", "ladder", "20"])
        check(stayed["expired"] is False, stayed)
        check(effects(control_url)["count"] == before2, "expire before the new deadline added an effect")
        expired2 = ok(state, service, ["expire", "ladder", "60"])
        check(expired2["expired"] is True and expired2["promoted_wait_id"] == "w2", expired2)
        check(expired2["notify"] == "sent", expired2)
        check(effects(control_url)["count"] == before2 + 1, effects(control_url))
        status2 = ok(state, service, ["status", "ladder", "60"])
        check(status2["reservation_id"] == "w2" and status2["waitlist"] == [], status2)
        refused(state, service, ["checkout", "ladder", "w1", "loan-w1", "61"], "expired")
        check(effects(control_url)["count"] == before2 + 1, "checkout of the first promoted id added an effect")
        print("expire-promotes-and-chains ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


def return_crash_and_lost_reply(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-return-lost-"))
    try:
        ok(state, service, ["add-item", "kite"])
        ok(state, service, ["reserve", "kite", "res-k", "amy", "amy@lab.example", "50", "1"])
        ok(state, service, ["checkout", "kite", "res-k", "loan-k", "2"])
        ok(state, service, ["wait", "kite", "wk", "bo", "bo@lab.example", "300", "3"])
        before = effects(control_url)["count"]
        control(control_url, "POST", "/fault", {"drop_reply": True})
        lost = invoke(state, service, ["return", "kite", "loan-k", "5"])
        check(lost.returncode != 0, f"lost reply should not look like success: {lost.stdout!r}")
        body = json.loads(lost.stdout)
        check(body.get("error") == "service_unavailable", body)
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        status_during = ok(state, service, ["status", "kite", "5"])
        check(status_during["loan_state"] == "returned" and status_during["availability"] == "reserved", status_during)
        control(control_url, "POST", "/fault", {"drop_reply": False})
        reconciled = ok(state, service, ["reconcile", "wk"])
        check(reconciled["notify"] == "sent" and reconciled["availability"] == "reserved", reconciled)
        check(reconciled.get("notify") != "not_sent", reconciled)
        check(effects(control_url)["count"] == before + 1, "reconcile added an effect")
        print("return-lost-reply ok")
    finally:
        control(control_url, "POST", "/fault", {"drop_reply": False})
        shutil.rmtree(state, ignore_errors=True)

    state2 = Path(tempfile.mkdtemp(prefix="desk-return-crash-"))
    try:
        ok(state2, service, ["add-item", "flag"])
        ok(state2, service, ["reserve", "flag", "res-f", "amy", "amy@lab.example", "50", "1"])
        ok(state2, service, ["checkout", "flag", "res-f", "loan-f", "2"])
        ok(state2, service, ["wait", "flag", "wf", "bo", "bo@lab.example", "300", "3"])
        before = effects(control_url)["count"]
        killed = invoke(state2, service, ["return", "flag", "loan-f", "5"], "after-attempt-saved-before-request")
        check(abs(killed.returncode) == signal.SIGKILL, killed.returncode)
        check(effects(control_url)["count"] == before, "promotion request was sent before the crash boundary")
        status = ok(state2, service, ["status", "flag", "5"])
        check(status["availability"] == "reserved" and status["promotion"]["notify"] == "attempt_saved", status)
        resumed = ok(state2, service, ["return", "flag", "loan-f", "6"])
        check(resumed["notify"] == "sent" and resumed["promoted_wait_id"] == "wf", resumed)
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        print("return-crash-before-request ok")
    finally:
        shutil.rmtree(state2, ignore_errors=True)


def checkout_meets_expiry(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-checkout-expiry-"))
    try:
        ok(state, service, ["add-item", "ring"])
        ok(state, service, ["reserve", "ring", "res-c", "amy", "amy@lab.example", "10", "1"])
        ok(state, service, ["wait", "ring", "wc", "bo", "bo@lab.example", "90", "2"])
        before = effects(control_url)["count"]
        refused(state, service, ["checkout", "ring", "res-c", "loan-c", "10"], "expired")
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        status = ok(state, service, ["status", "ring", "10"])
        check(status["availability"] == "reserved" and status["reservation_id"] == "wc", status)
        check(status["promotion"]["notify"] == "sent", status)
        refused(state, service, ["checkout", "ring", "res-c", "loan-c2", "11"], "expired")
        check(effects(control_url)["count"] == before + 1, "second checkout of the expired id added an effect")
        print("checkout-meets-expiry ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)

    state2 = Path(tempfile.mkdtemp(prefix="desk-checkout-expiry-lost-"))
    try:
        ok(state2, service, ["add-item", "sled"])
        ok(state2, service, ["reserve", "sled", "res-s2", "amy", "amy@lab.example", "10", "1"])
        ok(state2, service, ["wait", "sled", "ws", "bo", "bo@lab.example", "90", "2"])
        before = effects(control_url)["count"]
        control(control_url, "POST", "/fault", {"drop_reply": True})
        lost = invoke(state2, service, ["checkout", "sled", "res-s2", "loan-s2", "10"])
        check(lost.returncode != 0, f"lost reply should not look like success: {lost.stdout!r}")
        body = json.loads(lost.stdout)
        check(body.get("error") == "service_unavailable", body)
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        control(control_url, "POST", "/fault", {"drop_reply": False})
        reconciled = ok(state2, service, ["reconcile", "ws"])
        check(reconciled["notify"] == "sent", reconciled)
        check(effects(control_url)["count"] == before + 1, "reconcile added an effect")
        print("checkout-meets-expiry-lost-reply ok")
    finally:
        control(control_url, "POST", "/fault", {"drop_reply": False})
        shutil.rmtree(state2, ignore_errors=True)


def main() -> None:
    stub, service, control_url = start_stub()
    try:
        healthy(service, control_url)
        crash_and_lost(service, control_url)
        unrelated_writer(service)
        callback_and_return(service, control_url)
        past_deadline_checkout(service, control_url)
        waitlist_join_order(service, control_url)
        return_promotes_once(service, control_url)
        return_empty_waitlist_unaffected(service, control_url)
        expire_promotes_and_chains(service, control_url)
        return_crash_and_lost_reply(service, control_url)
        checkout_meets_expiry(service, control_url)
    finally:
        stub.send_signal(signal.SIGTERM)
        stub.wait(timeout=5)


def healthy(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-healthy-"))
    try:
        added = ok(state, service, ["add-item", "cam-1"])
        check(added["availability"] == "available", added)
        ok(state, service, ["add-item", "cam-2"])
        refused(state, service, ["add-item", "cam-1"], "id_in_use")
        refused(state, service, ["add-item", "bad id"], "bad_args")
        refused(state, service, ["checkout", "missing", "r", "l", "1"], "unknown_item")
        reserved = ok(
            state,
            service,
            ["reserve", "cam-1", "res-1", "ada", "ada@lab.example", "50", "10"],
        )
        check(reserved["availability"] == "reserved" and reserved["collect_by"] == 50, reserved)
        status = ok(state, service, ["status", "cam-1", "10"])
        check(status["borrower_id"] == "ada" and status["address"] == "ada@lab.example", status)
        check(status["reservation_state"] == "active" and status["past_deadline"] is False, status)
        other = ok(state, service, ["status", "cam-2", "10"])
        check(other["availability"] == "available" and other["loan_id"] is None, other)
        stayed = ok(state, service, ["expire", "cam-1", "49"])
        check(stayed["expired"] is False and stayed["availability"] == "reserved", stayed)
        check(effects(control_url)["count"] == 0, "expire contacted the service")
        checked = ok(state, service, ["checkout", "cam-1", "res-1", "loan-1", "20"])
        check(checked["notify"] == "sent" and checked["request_id"] == "loan-1", checked)
        check(effects(control_url)["count"] == 1, effects(control_url))
        after = ok(state, service, ["status", "cam-1", "20"])
        check(after["availability"] == "checked_out" and after["loan_state"] == "checked_out", after)
        check(after["notify"] == "sent" and after["borrower_id"] == "ada", after)
        check(ok(state, service, ["status", "cam-2", "20"])["availability"] == "available", "second item moved")
        refused(state, service, ["checkout", "cam-1", "res-1", "loan-1", "21"], "already_checked_out")
        refused(state, service, ["checkout", "cam-1", "res-1", "loan-2", "21"], "already_checked_out")
        check(effects(control_url)["count"] == 1, "double checkout added an effect")
        refused(state, service, ["return", "cam-2", "loan-x", "22"], "not_checked_out")
        refused(state, service, ["return", "cam-1", "loan-x", "22"], "loan_mismatch")
        returned = ok(state, service, ["return", "cam-1", "loan-1", "22"])
        check(returned["availability"] == "available" and returned["loan_state"] == "returned", returned)
        refused(state, service, ["return", "cam-1", "loan-1", "23"], "not_checked_out")
        print("healthy ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


def crash_and_lost(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-crash-"))
    try:
        ok(state, service, ["add-item", "tripod"])
        ok(state, service, ["reserve", "tripod", "res-t", "bea", "bea@lab.example", "80", "5"])
        before = effects(control_url)["count"]
        killed = invoke(state, service, ["checkout", "tripod", "res-t", "loan-t", "6"], "after-attempt-saved-before-request")
        check(killed.returncode < 0 and abs(killed.returncode) == signal.SIGKILL, f"crash before request rc={killed.returncode} out={killed.stdout!r} err={killed.stderr!r}")
        check(effects(control_url)["count"] == before, "request was sent before the crash boundary")
        status = ok(state, service, ["status", "tripod", "6"])
        check(status["loan_state"] == "attempt_saved" and status["loan_id"] == "loan-t", status)
        refused(state, service, ["checkout", "tripod", "res-t", "loan-other", "6"], "checkout_in_progress")
        check(effects(control_url)["count"] == before, "progress refusal added an effect")
        done = ok(state, service, ["checkout", "tripod", "res-t", "loan-t", "7"])
        check(done["notify"] == "sent", done)
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        print("crash-before-request ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)

    state = Path(tempfile.mkdtemp(prefix="desk-accept-"))
    try:
        ok(state, service, ["add-item", "lamp"])
        ok(state, service, ["reserve", "lamp", "res-l", "cy", "cy@lab.example", "90", "1"])
        before = effects(control_url)["count"]
        killed = invoke(state, service, ["checkout", "lamp", "res-l", "loan-l", "2"], "after-accept-before-record")
        check(killed.returncode < 0 and abs(killed.returncode) == signal.SIGKILL, f"accept crash rc={killed.returncode} out={killed.stdout!r} err={killed.stderr!r}")
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        status = ok(state, service, ["status", "lamp", "2"])
        check(status["loan_state"] == "attempt_saved" and status["notify"] == "attempt_saved", status)
        resumed = ok(state, service, ["checkout", "lamp", "res-l", "loan-l", "3"])
        check(resumed["notify"] == "sent" and resumed["request_id"] == "loan-l", resumed)
        check(effects(control_url)["count"] == before + 1, "resume counted a second effect")
        after = ok(state, service, ["status", "lamp", "3"])
        check(after["availability"] == "checked_out" and after["notify"] == "sent", after)
        print("crash-after-accept ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)

    state = Path(tempfile.mkdtemp(prefix="desk-record-"))
    try:
        ok(state, service, ["add-item", "mic"])
        ok(state, service, ["reserve", "mic", "res-m", "dee", "dee@lab.example", "40", "4"])
        before = effects(control_url)["count"]
        killed = invoke(state, service, ["checkout", "mic", "res-m", "loan-m", "5"], "after-record-before-exit")
        check(killed.returncode < 0 and abs(killed.returncode) == signal.SIGKILL, f"record crash rc={killed.returncode} out={killed.stdout!r}")
        status = ok(state, service, ["status", "mic", "5"])
        check(status["availability"] == "checked_out" and status["notify"] == "sent", status)
        refused(state, service, ["checkout", "mic", "res-m", "loan-m", "6"], "already_checked_out")
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        print("crash-after-record ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)

    state = Path(tempfile.mkdtemp(prefix="desk-lost-"))
    try:
        ok(state, service, ["add-item", "stand"])
        ok(state, service, ["reserve", "stand", "res-s", "ed", "ed@lab.example", "70", "8"])
        before = effects(control_url)["count"]
        control(control_url, "POST", "/fault", {"drop_reply": True})
        lost = invoke(state, service, ["checkout", "stand", "res-s", "loan-s", "9"])
        check(lost.returncode != 0, f"lost reply should not look like success: {lost.stdout!r}")
        body = json.loads(lost.stdout)
        check(body.get("error") == "service_unavailable", body)
        check(effects(control_url)["count"] == before + 1, effects(control_url))
        status = ok(state, service, ["status", "stand", "9"])
        check(status["loan_state"] == "attempt_saved", status)
        control(control_url, "POST", "/fault", {"drop_reply": False})
        reconciled = ok(state, service, ["reconcile", "loan-s"])
        check(reconciled["notify"] == "sent" and reconciled["availability"] == "checked_out", reconciled)
        check(reconciled.get("notify") != "not_sent", reconciled)
        check(effects(control_url)["count"] == before + 1, "reconcile added an effect")
        posts = effects(control_url)["posts"]
        loan_posts = [row for row in posts if row.get("request_id") == "loan-s"]
        check(len(loan_posts) == 1, loan_posts)
        print("lost-reply ok")
    finally:
        control(control_url, "POST", "/fault", {"drop_reply": False})
        shutil.rmtree(state, ignore_errors=True)


def unrelated_writer(service: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-writer-"))
    try:
        note = state / "other.txt"
        note.write_bytes(b"keep-me\n")
        ok(state, service, ["add-item", "case"])
        refused(state, service, ["reserve", "missing", "res-z", "ada", "ada@lab.example", "3", "1"], "unknown_item")
        check(note.read_bytes() == b"keep-me\n", "unrelated file changed")
        print("unrelated-writer ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


def callback_and_return(service: str, control_url: str) -> None:
    state = Path(tempfile.mkdtemp(prefix="desk-cb-"))
    try:
        ok(state, service, ["add-item", "drone"])
        ok(state, service, ["reserve", "drone", "res-d", "fay", "fay@lab.example", "30", "1"])
        early = ok(state, service, ["expire", "drone", "1"])
        check(early["expired"] is False, early)
        ok(state, service, ["expire", "drone", "30"])
        status = ok(state, service, ["status", "drone", "30"])
        check(status["availability"] == "available" and status["reservation_state"] == "expired", status)
        refused(state, service, ["checkout", "drone", "res-d", "loan-d", "31"], "expired")
        check(effects(control_url)["count"] == effects(control_url)["count"], "placeholder")
        before = effects(control_url)["count"]
        refused(state, service, ["checkout", "drone", "res-d", "loan-d", "31"], "expired")
        check(effects(control_url)["count"] == before, "expired checkout contacted service")
        ok(state, service, ["reserve", "drone", "res-d2", "fay", "fay@lab.example", "100", "31"])
        killed = invoke(state, service, ["checkout", "drone", "res-d2", "loan-d2", "32"], "after-record-before-exit")
        check(abs(killed.returncode) == signal.SIGKILL, killed.returncode)
        cb = state / "cb.json"
        cb.write_text(json.dumps({
            "callback_id": "cb-loan-d2",
            "request_id": "loan-d2",
            "item_id": "drone",
            "borrower_id": "fay",
            "address": "other@lab.example",
            "kind": "checkout",
            "outcome": "accepted",
        }))
        before = effects(control_url)["count"]
        first = ok(state, service, ["callback", str(cb)])
        second = ok(state, service, ["callback", str(cb)])
        check(first == {"ok": True} and second == {"ok": True}, (first, second))
        status = ok(state, service, ["status", "drone", "32"])
        check(status["availability"] == "checked_out" and status["address"] == "fay@lab.example", status)
        check(status["loan_id"] == "loan-d2" and status["notify"] == "sent", status)
        check(effects(control_url)["count"] == before, "callback added an effect")
        bad = state / "bad.json"
        bad.write_text("{")
        refused(state, service, ["callback", str(bad)], "bad_args")
        check((state / "other-absent").exists() is False, "callback created junk")
        none = ok(state, service, ["reconcile", "never-loan"])
        check(none["notify"] == "none" and none["loan_id"] is None and none["kind"] is None, none)
        print("expiry-callback ok")
    finally:
        shutil.rmtree(state, ignore_errors=True)


if __name__ == "__main__":
    try:
        main()
    except Failure as exc:
        print(f"FAIL {exc}")
        raise SystemExit(1)
