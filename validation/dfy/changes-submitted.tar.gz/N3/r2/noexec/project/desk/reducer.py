"""Loan-desk lifecycle. Rust commits; this reducer only decides transitions."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any, Mapping, Optional

from invariant_kernel import (
    ApplyOutcome,
    Decision,
    DomainEvent,
    ReducerDiagnostic,
    ReducerIdentity,
)

_SOURCE = Path(__file__).read_bytes()
_CODE_DIGEST = hashlib.sha256(_SOURCE).hexdigest()
_COMMAND_SCHEMA = hashlib.sha256(b"loan-desk-commands-v2").hexdigest()
_STATE_SCHEMA = hashlib.sha256(b"loan-desk-state-v2").hexdigest()


def _blank_item() -> dict[str, Any]:
    return {
        "availability": "available",
        "reservation_id": None,
        "borrower_id": None,
        "address": None,
        "collect_by": None,
        "reservation_state": "none",
        "loan_id": None,
        "loan_state": "none",
        "notify": "none",
        "attempt_reservation_id": None,
        "attempt_borrower_id": None,
        "attempt_address": None,
        "waitlist": [],
        "promotion_notify": "none",
        "promotion_request_id": None,
        "promotion_attempt_borrower_id": None,
        "promotion_attempt_address": None,
        "promotion_source_loan_id": None,
        # Reservation ids that expired into the promotion chain leading to the
        # item's *current* reservation. Reset whenever an ordinary `reserve`
        # starts a fresh, unrelated reservation. This is deliberately NOT a
        # global store of every reservation that ever expired: a plain
        # (non-waitlist) expiry that is later superseded by an unrelated
        # `reserve` must keep reporting `reservation_mismatch`, not `expired`,
        # for the original brief (R3) to keep holding unchanged.
        "promoted_away_ids": [],
    }


def _copy_state(state: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "items": {key: dict(value) for key, value in state["items"].items()},
        "ids": dict(state["ids"]),
        "loans": dict(state["loans"]),
        "promotions": dict(state.get("promotions", {})),
    }


def _refuse(code: str, message: str) -> ReducerDiagnostic:
    return ReducerDiagnostic(code, message, code)


def _args(command: Mapping[str, Any]) -> Mapping[str, Any]:
    args = command.get("args") or {}
    if not isinstance(args, Mapping):
        return {}
    return args


def _due(item: Mapping[str, Any], now: int) -> bool:
    return (
        item["availability"] == "reserved"
        and item["reservation_state"] == "active"
        and item["collect_by"] is not None
        and now >= int(item["collect_by"])
    )


def _promotion_payload(item_id: str, item: Mapping[str, Any], now: int) -> dict[str, Any]:
    head = item["waitlist"][0]
    return {
        "item_id": item_id,
        "old_reservation_id": item["reservation_id"],
        "wait_id": head["wait_id"],
        "borrower_id": head["borrower_id"],
        "address": head["address"],
        "hold_seconds": head["hold_seconds"],
        "now": now,
    }


def _already_expired(item: Mapping[str, Any], reservation_id: str) -> bool:
    if item["reservation_state"] == "expired" and item["reservation_id"] == reservation_id:
        return True
    return reservation_id in item["promoted_away_ids"]


class LoanDeskReducer:
    identity = ReducerIdentity(
        reducer_name="loan_desk",
        reducer_version=2,
        code_digest=_CODE_DIGEST,
        command_schema_digest=_COMMAND_SCHEMA,
        state_schema_digest=_STATE_SCHEMA,
    )

    def initial_state(self) -> dict[str, Any]:
        return {"items": {}, "ids": {}, "loans": {}, "promotions": {}}

    def decide(
        self,
        state: Any,
        observation: Optional[Any],
        effect: Any,
        command: Any,
    ) -> Decision | ReducerDiagnostic:
        del effect
        name = command.get("name") if isinstance(command, Mapping) else None
        args = _args(command) if isinstance(command, Mapping) else {}
        if name == "add_item":
            return self._add_item(state, args)
        if name == "reserve":
            return self._reserve(state, args)
        if name == "expire":
            return self._expire(state, args)
        if name == "begin_checkout":
            return self._begin_checkout(state, args)
        if name == "commit_sent":
            return self._commit_sent(state, args, observation)
        if name == "return_item":
            return self._return_item(state, args)
        if name == "join_wait":
            return self._join_wait(state, args)
        if name == "commit_promotion_sent":
            return self._commit_promotion_sent(state, args, observation)
        return _refuse("bad_args", "unknown command")

    def apply(self, state: Any, event: DomainEvent) -> ApplyOutcome | ReducerDiagnostic:
        nxt = _copy_state(state)
        payload = dict(event.payload)
        kind = event.event_type
        if kind == "item_added":
            item_id = payload["item_id"]
            nxt["items"][item_id] = _blank_item()
            nxt["ids"][item_id] = "item"
        elif kind == "reserved":
            item = nxt["items"][payload["item_id"]]
            if payload.get("expire_first"):
                item["availability"] = "available"
                item["reservation_state"] = "expired"
            item["availability"] = "reserved"
            item["reservation_id"] = payload["reservation_id"]
            item["borrower_id"] = payload["borrower_id"]
            item["address"] = payload["address"]
            item["collect_by"] = payload["collect_by"]
            item["reservation_state"] = "active"
            item["promoted_away_ids"] = []
            nxt["ids"][payload["reservation_id"]] = "reservation"
        elif kind == "expired":
            item = nxt["items"][payload["item_id"]]
            item["availability"] = "available"
            item["reservation_state"] = "expired"
        elif kind == "expired_promoted":
            item = nxt["items"][payload["item_id"]]
            wait_id = payload["wait_id"]
            item["promoted_away_ids"] = list(item["promoted_away_ids"]) + [payload["old_reservation_id"]]
            item["waitlist"] = [w for w in item["waitlist"] if w["wait_id"] != wait_id]
            item["availability"] = "reserved"
            item["reservation_id"] = wait_id
            item["borrower_id"] = payload["borrower_id"]
            item["address"] = payload["address"]
            item["collect_by"] = payload["now"] + payload["hold_seconds"]
            item["reservation_state"] = "active"
            nxt["ids"][wait_id] = "reservation"
            nxt["promotions"][wait_id] = payload["item_id"]
            item["promotion_notify"] = "attempt_saved"
            item["promotion_request_id"] = wait_id
            item["promotion_attempt_borrower_id"] = payload["borrower_id"]
            item["promotion_attempt_address"] = payload["address"]
            item["promotion_source_loan_id"] = None
        elif kind == "attempt_saved":
            item = nxt["items"][payload["item_id"]]
            item["loan_id"] = payload["loan_id"]
            item["loan_state"] = "attempt_saved"
            item["notify"] = "attempt_saved"
            item["attempt_reservation_id"] = payload["reservation_id"]
            item["attempt_borrower_id"] = payload["borrower_id"]
            item["attempt_address"] = payload["address"]
            nxt["ids"][payload["loan_id"]] = "loan"
            nxt["loans"][payload["loan_id"]] = payload["item_id"]
        elif kind == "checked_out":
            item = nxt["items"][payload["item_id"]]
            item["availability"] = "checked_out"
            item["reservation_state"] = "collected"
            item["loan_state"] = "checked_out"
            item["notify"] = "sent"
            item["loan_id"] = payload["loan_id"]
        elif kind == "returned":
            item = nxt["items"][payload["item_id"]]
            item["availability"] = "available"
            item["loan_state"] = "returned"
            item["notify"] = "sent"
        elif kind == "returned_promoted":
            item = nxt["items"][payload["item_id"]]
            item["loan_state"] = "returned"
            item["notify"] = "sent"
            wait_id = payload["wait_id"]
            item["waitlist"] = [w for w in item["waitlist"] if w["wait_id"] != wait_id]
            item["availability"] = "reserved"
            item["reservation_id"] = wait_id
            item["borrower_id"] = payload["borrower_id"]
            item["address"] = payload["address"]
            item["collect_by"] = payload["now"] + payload["hold_seconds"]
            item["reservation_state"] = "active"
            item["promoted_away_ids"] = []
            nxt["ids"][wait_id] = "reservation"
            nxt["promotions"][wait_id] = payload["item_id"]
            item["promotion_notify"] = "attempt_saved"
            item["promotion_request_id"] = wait_id
            item["promotion_attempt_borrower_id"] = payload["borrower_id"]
            item["promotion_attempt_address"] = payload["address"]
            item["promotion_source_loan_id"] = payload["loan_id"]
        elif kind == "promotion_sent":
            item = nxt["items"][payload["item_id"]]
            item["promotion_notify"] = "sent"
        elif kind == "waiter_joined":
            item = nxt["items"][payload["item_id"]]
            item["waitlist"] = list(item["waitlist"]) + [
                {
                    "wait_id": payload["wait_id"],
                    "borrower_id": payload["borrower_id"],
                    "address": payload["address"],
                    "hold_seconds": payload["hold_seconds"],
                }
            ]
            nxt["ids"][payload["wait_id"]] = "wait"
        else:
            return _refuse("bad_args", "unknown event")
        return ApplyOutcome.new(nxt)

    def _add_item(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        if not isinstance(item_id, str):
            return _refuse("bad_args", "item id required")
        if item_id in state["ids"]:
            return _refuse("id_in_use", "id already in the desk namespace")
        return Decision.emit(DomainEvent("item_added", 1, {"item_id": item_id}))

    def _reserve(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        reservation_id = args.get("reservation_id")
        borrower_id = args.get("borrower_id")
        address = args.get("address")
        collect_by = args.get("collect_by")
        now = args.get("now")
        if (
            not isinstance(item_id, str)
            or not isinstance(reservation_id, str)
            or not isinstance(borrower_id, str)
            or not isinstance(address, str)
            or type(collect_by) is not int
            or type(now) is not int
            or collect_by <= now
        ):
            return _refuse("bad_args", "reserve arguments are not usable")
        item = state["items"].get(item_id)
        if item is None:
            return _refuse("unknown_item", "item is not registered")
        due = _due(item, now)
        if due and item["waitlist"]:
            return Decision.emit(DomainEvent("expired_promoted", 1, _promotion_payload(item_id, item, now)))
        expire_first = due
        if not expire_first and (
            item["availability"] == "checked_out"
            or (item["availability"] == "reserved" and item["reservation_state"] == "active")
        ):
            return _refuse("not_available", "item is not available")
        if reservation_id in state["ids"]:
            return _refuse("id_in_use", "reservation id is already in the namespace")
        return Decision.emit(
            DomainEvent(
                "reserved",
                1,
                {
                    "item_id": item_id,
                    "reservation_id": reservation_id,
                    "borrower_id": borrower_id,
                    "address": address,
                    "collect_by": collect_by,
                    "expire_first": expire_first,
                },
            )
        )

    def _due_expiry_event(self, item_id: str, item: Mapping[str, Any], now: int) -> DomainEvent:
        if item["waitlist"]:
            return DomainEvent("expired_promoted", 1, _promotion_payload(item_id, item, now))
        return DomainEvent("expired", 1, {"item_id": item_id})

    def _expire(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        now = args.get("now")
        if not isinstance(item_id, str) or type(now) is not int:
            return _refuse("bad_args", "expire arguments are not usable")
        item = state["items"].get(item_id)
        if item is None:
            return _refuse("unknown_item", "item is not registered")
        if _due(item, now):
            return Decision.emit(self._due_expiry_event(item_id, item, now))
        return Decision.noop()

    def _begin_checkout(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        reservation_id = args.get("reservation_id")
        loan_id = args.get("loan_id")
        now = args.get("now")
        if (
            not isinstance(item_id, str)
            or not isinstance(reservation_id, str)
            or not isinstance(loan_id, str)
            or type(now) is not int
        ):
            return _refuse("bad_args", "checkout arguments are not usable")
        item = state["items"].get(item_id)
        if item is None:
            return _refuse("unknown_item", "item is not registered")
        if _due(item, now):
            return Decision.emit(self._due_expiry_event(item_id, item, now))
        if item["availability"] == "checked_out" or item["loan_state"] == "checked_out":
            return _refuse("already_checked_out", "item is already checked out")
        if _already_expired(item, reservation_id):
            return _refuse("expired", "reservation is already expired")
        if item["reservation_state"] != "active":
            return _refuse("not_reserved", "item has no active reservation")
        if item["reservation_id"] != reservation_id:
            return _refuse("reservation_mismatch", "reservation does not match")
        if item["loan_state"] == "attempt_saved":
            if item["loan_id"] != loan_id:
                return _refuse("checkout_in_progress", "a different loan attempt is saved")
            if item["attempt_reservation_id"] != reservation_id:
                return _refuse("reservation_mismatch", "saved attempt is for another reservation")
            return Decision.noop()
        existing = state["ids"].get(loan_id)
        if existing is not None:
            return _refuse("id_in_use", "loan id is already in the namespace")
        return Decision.emit(
            DomainEvent(
                "attempt_saved",
                1,
                {
                    "item_id": item_id,
                    "loan_id": loan_id,
                    "reservation_id": reservation_id,
                    "borrower_id": item["borrower_id"],
                    "address": item["address"],
                },
            )
        )

    def _commit_sent(
        self,
        state: Mapping[str, Any],
        args: Mapping[str, Any],
        observation: Optional[Any],
    ) -> Decision | ReducerDiagnostic:
        loan_id = args.get("loan_id")
        if not isinstance(loan_id, str):
            return _refuse("bad_args", "loan id required")
        item_id = state["loans"].get(loan_id)
        if item_id is None:
            return _refuse("unknown_item", "no attempt for that loan")
        item = state["items"][item_id]
        if item["notify"] == "sent" and item["loan_state"] in {"checked_out", "returned"}:
            return Decision.noop()
        if item["loan_state"] != "attempt_saved" or item["notify"] != "attempt_saved":
            return _refuse("not_reserved", "no saved attempt to confirm")
        if not isinstance(observation, Mapping):
            return _refuse("conflict", "service observation does not match the attempt")
        if (
            observation.get("request_id") != loan_id
            or observation.get("item_id") != item_id
            or observation.get("borrower_id") != item["attempt_borrower_id"]
            or observation.get("address") != item["attempt_address"]
            or observation.get("kind") != "checkout"
            or observation.get("outcome") != "accepted"
        ):
            return _refuse("conflict", "service observation does not match the attempt")
        return Decision.emit(
            DomainEvent("checked_out", 1, {"item_id": item_id, "loan_id": loan_id})
        )

    def _return_item(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        loan_id = args.get("loan_id")
        now = args.get("now")
        if not isinstance(item_id, str) or not isinstance(loan_id, str) or type(now) is not int:
            return _refuse("bad_args", "return arguments are not usable")
        item = state["items"].get(item_id)
        if item is None:
            return _refuse("unknown_item", "item is not registered")
        if item["availability"] != "checked_out":
            return _refuse("not_checked_out", "item is not checked out")
        if item["loan_id"] != loan_id:
            return _refuse("loan_mismatch", "loan id does not match the active loan")
        if item["waitlist"]:
            payload = _promotion_payload(item_id, item, now)
            payload["loan_id"] = loan_id
            return Decision.emit(DomainEvent("returned_promoted", 1, payload))
        return Decision.emit(DomainEvent("returned", 1, {"item_id": item_id, "loan_id": loan_id}))

    def _join_wait(self, state: Mapping[str, Any], args: Mapping[str, Any]) -> Decision | ReducerDiagnostic:
        item_id = args.get("item_id")
        wait_id = args.get("wait_id")
        borrower_id = args.get("borrower_id")
        address = args.get("address")
        hold_seconds = args.get("hold_seconds")
        if (
            not isinstance(item_id, str)
            or not isinstance(wait_id, str)
            or not isinstance(borrower_id, str)
            or not isinstance(address, str)
            or type(hold_seconds) is not int
        ):
            return _refuse("bad_args", "wait arguments are not usable")
        item = state["items"].get(item_id)
        if item is None:
            return _refuse("unknown_item", "item is not registered")
        if item["availability"] == "available":
            return _refuse("not_needed", "item is available")
        if item["borrower_id"] == borrower_id or any(w["borrower_id"] == borrower_id for w in item["waitlist"]):
            return _refuse("already_waiting", "borrower already has a stake in this item")
        if wait_id in state["ids"]:
            return _refuse("id_in_use", "wait id is already in the namespace")
        return Decision.emit(
            DomainEvent(
                "waiter_joined",
                1,
                {
                    "item_id": item_id,
                    "wait_id": wait_id,
                    "borrower_id": borrower_id,
                    "address": address,
                    "hold_seconds": hold_seconds,
                },
            )
        )

    def _commit_promotion_sent(
        self,
        state: Mapping[str, Any],
        args: Mapping[str, Any],
        observation: Optional[Any],
    ) -> Decision | ReducerDiagnostic:
        request_id = args.get("request_id")
        if not isinstance(request_id, str):
            return _refuse("bad_args", "request id required")
        item_id = state["promotions"].get(request_id)
        if item_id is None:
            return _refuse("unknown_item", "no promotion attempt for that id")
        item = state["items"][item_id]
        if item["promotion_notify"] == "sent":
            return Decision.noop()
        if item["promotion_notify"] != "attempt_saved" or item["promotion_request_id"] != request_id:
            return _refuse("conflict", "no saved promotion attempt to confirm")
        if not isinstance(observation, Mapping):
            return _refuse("conflict", "service observation does not match the promotion attempt")
        if (
            observation.get("request_id") != request_id
            or observation.get("item_id") != item_id
            or observation.get("borrower_id") != item["promotion_attempt_borrower_id"]
            or observation.get("address") != item["promotion_attempt_address"]
            or observation.get("kind") != "waitlist_ready"
            or observation.get("outcome") != "accepted"
        ):
            return _refuse("conflict", "service observation does not match the promotion attempt")
        return Decision.emit(DomainEvent("promotion_sent", 1, {"item_id": item_id, "request_id": request_id}))
