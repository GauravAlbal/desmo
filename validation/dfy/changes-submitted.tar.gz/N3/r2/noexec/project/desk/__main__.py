"""CLI for the equipment loan desk. One command per process."""

from __future__ import annotations

import json
import os
import signal
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Mapping, Optional

from invariant_kernel import HistoricalResult, Kernel, KernelError

from desk.reducer import LoanDeskReducer

AGGREGATE = "desk"
ENTRYPOINT = "desk.reducer:LoanDeskReducer"
DOMAIN_ERRORS = {
    "bad_args",
    "unknown_item",
    "id_in_use",
    "not_available",
    "not_reserved",
    "reservation_mismatch",
    "expired",
    "already_checked_out",
    "checkout_in_progress",
    "not_checked_out",
    "loan_mismatch",
    "service_unavailable",
    "conflict",
    "not_needed",
    "already_waiting",
}
ID_RE_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._-")
LOCAL_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._+-")
DOMAIN_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.-")


def emit(payload: Mapping[str, Any], code: int = 0) -> None:
    sys.stdout.write(json.dumps(payload, separators=(",", ":")) + "\n")
    sys.stdout.flush()
    raise SystemExit(code)


def fail(code: str, **extra: Any) -> None:
    body = {"error": code}
    body.update(extra)
    emit(body, 1)


def crash_if(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


class Desk:
    def __init__(self, store: Path, python: str) -> None:
        self.store = store
        self.python = python
        self.kernel: Optional[Kernel] = None
        self.machine = None
        self.aggregate = None

    def close(self) -> None:
        if self.kernel is not None:
            self.kernel.close()
            self.kernel = None

    def _open(self, create_dirs: bool) -> None:
        if self.kernel is not None:
            return
        if create_dirs:
            self.store.parent.mkdir(parents=True, exist_ok=True)
        binary = os.environ.get("IK_BINARY")
        self.kernel = Kernel(store=str(self.store), binary=binary, session=True)
        self.machine = self.kernel.reducer(ENTRYPOINT, python=self.python)

    def load(self, *, create: bool) -> Optional[Any]:
        if not self.store.exists():
            if not create:
                return None
            self._open(True)
            return None
        self._open(False)
        try:
            self.aggregate = self.machine.show(AGGREGATE)
            return self.aggregate
        except KernelError as exc:
            if getattr(exc, "rule", None) == "aggregate.not_found":
                return None
            raise

    def call(self, name: str, args: Mapping[str, Any], observation: Optional[Mapping[str, Any]] = None) -> Any:
        command = {"name": name, "args": dict(args)}
        if self.aggregate is None:
            self._open(True)
            self.aggregate = self.machine.create_with(AGGREGATE, command, observation=observation)
            return self.aggregate
        self.aggregate = self.aggregate.execute(command, observation)
        return self.aggregate


def valid_id(value: str) -> bool:
    return 1 <= len(value) <= 64 and all(ch in ID_RE_CHARS for ch in value)


def valid_address(value: str) -> bool:
    if value.count("@") != 1:
        return False
    local, domain = value.split("@")
    return (
        1 <= len(local) <= 64
        and 1 <= len(domain) <= 63
        and all(ch in LOCAL_CHARS for ch in local)
        and all(ch in DOMAIN_CHARS for ch in domain)
    )


def parse_time(value: str, *, bounded: bool) -> Optional[int]:
    if value == "0" or (len(value) > 0 and value[0] in "123456789" and value.isdigit()):
        number = int(value)
        if bounded and number > 9999999999:
            return None
        return number
    return None


def parse_hold_seconds(value: str) -> Optional[int]:
    if len(value) > 0 and value[0] in "123456789" and value.isdigit():
        number = int(value)
        if 1 <= number <= 2592000:
            return number
    return None


def item_of(state: Mapping[str, Any], item_id: str) -> Optional[Mapping[str, Any]]:
    found = state["items"].get(item_id)
    return found


def loan_item(state: Mapping[str, Any], loan_id: str) -> tuple[Optional[str], Optional[Mapping[str, Any]]]:
    item_id = state["loans"].get(loan_id)
    if item_id is None:
        return None, None
    return item_id, state["items"][item_id]


def promotion_item(state: Mapping[str, Any], request_id: str) -> tuple[Optional[str], Optional[Mapping[str, Any]]]:
    item_id = state.get("promotions", {}).get(request_id)
    if item_id is None:
        return None, None
    return item_id, state["items"][item_id]


def status_body(item_id: str, item: Mapping[str, Any], now: int) -> dict[str, Any]:
    reservation_state = item["reservation_state"]
    past = reservation_state == "expired" or (
        reservation_state == "active" and item["collect_by"] is not None and now >= int(item["collect_by"])
    )
    has_reservation = reservation_state != "none"
    has_loan = item["loan_state"] != "none"
    borrower = item["attempt_borrower_id"] if has_loan and item["attempt_borrower_id"] else item["borrower_id"]
    address = item["attempt_address"] if has_loan and item["attempt_address"] else item["address"]
    if not has_reservation and not has_loan:
        borrower = None
        address = None
    return {
        "item_id": item_id,
        "availability": item["availability"],
        "reservation_id": item["reservation_id"] if has_reservation else None,
        "borrower_id": borrower if has_reservation or has_loan else None,
        "address": address if has_reservation or has_loan else None,
        "collect_by": item["collect_by"] if has_reservation else None,
        "reservation_state": reservation_state,
        "past_deadline": past,
        "loan_id": item["loan_id"] if has_loan else None,
        "loan_state": item["loan_state"],
        "notify": item["notify"],
        "now": now,
        "waitlist": [
            {
                "wait_id": w["wait_id"],
                "borrower_id": w["borrower_id"],
                "address": w["address"],
                "hold_seconds": w["hold_seconds"],
            }
            for w in item["waitlist"]
        ],
        "promotion": {
            "request_id": item["promotion_request_id"],
            "notify": item["promotion_notify"],
            "wait_id": item["promotion_request_id"],
        },
    }


def current_promotion_fields(item: Mapping[str, Any]) -> tuple[Optional[str], str]:
    if (
        item["promotion_request_id"] is not None
        and item["availability"] == "reserved"
        and item["reservation_id"] == item["promotion_request_id"]
    ):
        return item["promotion_request_id"], item["promotion_notify"]
    return None, "none"


def domain_code(exc: BaseException) -> Optional[str]:
    rule = getattr(exc, "rule", None)
    code = getattr(exc, "code", None)
    if rule in DOMAIN_ERRORS:
        return rule
    if code in DOMAIN_ERRORS:
        return code
    return None


def http_json(method: str, url: str, payload: Optional[Mapping[str, Any]] = None) -> tuple[Optional[int], Optional[dict[str, Any]], Optional[str]]:
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            raw = response.read()
            status = response.status
    except urllib.error.HTTPError as exc:
        try:
            raw = exc.read()
        except Exception:
            return None, None, "incomplete"
        status = exc.code
    except Exception:
        return None, None, "unavailable"
    try:
        body = json.loads(raw.decode("utf-8")) if raw else None
    except Exception:
        return status, None, "incomplete"
    if not isinstance(body, dict):
        return status, None, "incomplete"
    return status, body, None


def service_base() -> str:
    return os.environ.get("SERVICE_URL", "").rstrip("/")


def lookup_request(request_id: str) -> tuple[Optional[int], Optional[dict[str, Any]], Optional[str]]:
    base = service_base()
    if not base:
        return None, None, "unavailable"
    return http_json("GET", base + "/v1/requests/" + request_id)


def post_checkout(item_id: str, item: Mapping[str, Any], loan_id: str) -> tuple[Optional[int], Optional[dict[str, Any]], Optional[str]]:
    base = service_base()
    if not base:
        return None, None, "unavailable"
    payload = {
        "request_id": loan_id,
        "item_id": item_id,
        "borrower_id": item["attempt_borrower_id"],
        "address": item["attempt_address"],
        "kind": "checkout",
    }
    return http_json("POST", base + "/v1/messages", payload)


def matches_attempt(body: Mapping[str, Any], item_id: str, item: Mapping[str, Any], loan_id: str) -> bool:
    return (
        body.get("request_id") == loan_id
        and body.get("item_id") == item_id
        and body.get("borrower_id") == item["attempt_borrower_id"]
        and body.get("address") == item["attempt_address"]
        and body.get("kind") == "checkout"
        and body.get("outcome") == "accepted"
    )


def post_promotion(item_id: str, item: Mapping[str, Any], request_id: str) -> tuple[Optional[int], Optional[dict[str, Any]], Optional[str]]:
    base = service_base()
    if not base:
        return None, None, "unavailable"
    payload = {
        "request_id": request_id,
        "item_id": item_id,
        "borrower_id": item["promotion_attempt_borrower_id"],
        "address": item["promotion_attempt_address"],
        "kind": "waitlist_ready",
    }
    return http_json("POST", base + "/v1/messages", payload)


def matches_promotion(body: Mapping[str, Any], item_id: str, item: Mapping[str, Any], request_id: str) -> bool:
    return (
        body.get("request_id") == request_id
        and body.get("item_id") == item_id
        and body.get("borrower_id") == item["promotion_attempt_borrower_id"]
        and body.get("address") == item["promotion_attempt_address"]
        and body.get("kind") == "waitlist_ready"
        and body.get("outcome") == "accepted"
    )


def commit_promotion(desk: Desk, item_id: str, request_id: str, body: Mapping[str, Any], *, from_post: bool) -> Mapping[str, Any]:
    if from_post:
        desk.close()
        crash_if("after-accept-before-record")
        desk.load(create=False)
    result = desk.call("commit_promotion_sent", {"request_id": request_id}, observation=body)
    committed = bool(result.mutation) and not isinstance(result, HistoricalResult)
    fresh = result.state["items"][item_id]
    if committed:
        crash_if("after-record-before-exit")
    return fresh


def continue_promotion(desk: Desk, item_id: str, item: Mapping[str, Any]) -> Mapping[str, Any]:
    """Resolve a saved promotion attempt by lookup-or-post. Never re-saves the attempt."""
    if item["promotion_notify"] != "attempt_saved":
        return item
    request_id = item["promotion_request_id"]
    status, body, err = lookup_request(request_id)
    if err or status is None:
        desk.close()
        fail("service_unavailable")
    if status == 200:
        if body is None or not matches_promotion(body, item_id, item, request_id):
            desk.close()
            fail("conflict")
        return commit_promotion(desk, item_id, request_id, body, from_post=False)
    if status != 404:
        desk.close()
        fail("service_unavailable")
    status, body, err = post_promotion(item_id, item, request_id)
    if err or status is None:
        desk.close()
        fail("service_unavailable")
    if status == 409:
        desk.close()
        fail("conflict")
    if status != 200 or body is None:
        desk.close()
        fail("service_unavailable")
    return commit_promotion(desk, item_id, request_id, body, from_post=True)


def require_env_dir() -> Path:
    raw = os.environ.get("STATE_DIR")
    if not raw:
        fail("bad_args")
    return Path(raw)


def python_bin() -> str:
    return os.environ.get("DESK_PYTHON") or sys.executable


def run_command(argv: list[str]) -> None:
    if not argv:
        fail("bad_args")
    command, args = argv[0], argv[1:]
    state_dir = require_env_dir()
    store = state_dir / "ik" / "desk.sqlite"
    desk = Desk(store, python_bin())
    try:
        if command == "add-item":
            cmd_add_item(desk, args)
        elif command == "reserve":
            cmd_reserve(desk, args)
        elif command == "expire":
            cmd_expire(desk, args)
        elif command == "checkout":
            cmd_checkout(desk, args)
        elif command == "return":
            cmd_return(desk, args)
        elif command == "status":
            cmd_status(desk, args)
        elif command == "reconcile":
            cmd_reconcile(desk, args)
        elif command == "callback":
            cmd_callback(desk, args)
        elif command == "wait":
            cmd_wait(desk, args)
        else:
            fail("bad_args")
    except SystemExit:
        raise
    except KernelError as exc:
        code = domain_code(exc)
        desk.close()
        if code:
            fail(code)
        fail("service_unavailable", detail=f"{getattr(exc, 'code', '')} {exc}")
    finally:
        desk.close()


def cmd_add_item(desk: Desk, args: list[str]) -> None:
    if len(args) != 1 or not valid_id(args[0]):
        fail("bad_args")
    desk.load(create=True)
    desk.call("add_item", {"item_id": args[0]})
    desk.close()
    emit(
        {
            "item_id": args[0],
            "availability": "available",
            "reservation_id": None,
            "loan_id": None,
        }
    )


def cmd_reserve(desk: Desk, args: list[str]) -> None:
    if len(args) != 6:
        fail("bad_args")
    item_id, reservation_id, borrower_id, address, collect_raw, now_raw = args
    collect_by = parse_time(collect_raw, bounded=True)
    now = parse_time(now_raw, bounded=True)
    if (
        not valid_id(item_id)
        or not valid_id(reservation_id)
        or not valid_id(borrower_id)
        or not valid_address(address)
        or collect_by is None
        or now is None
        or collect_by <= now
    ):
        fail("bad_args")
    loaded = desk.load(create=False)
    if loaded is None:
        fail("unknown_item")
    result = desk.call(
        "reserve",
        {
            "item_id": item_id,
            "reservation_id": reservation_id,
            "borrower_id": borrower_id,
            "address": address,
            "collect_by": collect_by,
            "now": now,
        },
    )
    item = result.state["items"][item_id]
    mutated = bool(result.mutation) and not isinstance(result, HistoricalResult)
    if mutated and item["reservation_id"] != reservation_id:
        # The due reservation promoted the waitlist head instead of storing ours.
        desk.close()
        crash_if("after-attempt-saved-before-request")
        desk.load(create=False)
        item = desk.aggregate.state["items"][item_id]
        continue_promotion(desk, item_id, item)
        desk.close()
        fail("not_available")
    desk.close()
    emit(
        {
            "item_id": item_id,
            "reservation_id": reservation_id,
            "borrower_id": borrower_id,
            "address": address,
            "collect_by": collect_by,
            "availability": "reserved",
            "now": now,
        }
    )


def cmd_expire(desk: Desk, args: list[str]) -> None:
    if len(args) != 2:
        fail("bad_args")
    item_id, now_raw = args
    now = parse_time(now_raw, bounded=True)
    if not valid_id(item_id) or now is None:
        fail("bad_args")
    loaded = desk.load(create=False)
    if loaded is None:
        fail("unknown_item")
    item = loaded.state["items"].get(item_id)
    if item is not None:
        item = continue_promotion(desk, item_id, item)
    result = desk.call("expire", {"item_id": item_id, "now": now})
    item = result.state["items"][item_id]
    expired = bool(result.mutation) and not isinstance(result, HistoricalResult)
    if expired and item["promotion_notify"] == "attempt_saved":
        desk.close()
        crash_if("after-attempt-saved-before-request")
        desk.load(create=False)
        item = desk.aggregate.state["items"][item_id]
        item = continue_promotion(desk, item_id, item)
    promoted_wait_id, promo_notify = current_promotion_fields(item)
    desk.close()
    emit(
        {
            "item_id": item_id,
            "availability": item["availability"],
            "expired": expired,
            "reservation_id": item["reservation_id"],
            "promoted_wait_id": promoted_wait_id,
            "notify": promo_notify,
            "now": now,
        }
    )


def cmd_return(desk: Desk, args: list[str]) -> None:
    if len(args) != 3:
        fail("bad_args")
    item_id, loan_id, now_raw = args
    now = parse_time(now_raw, bounded=True)
    if not valid_id(item_id) or not valid_id(loan_id) or now is None:
        fail("bad_args")
    loaded = desk.load(create=False)
    if loaded is None:
        fail("unknown_item")
    item = loaded.state["items"].get(item_id)
    if (
        item is not None
        and item["promotion_notify"] == "attempt_saved"
        and item["promotion_source_loan_id"] == loan_id
    ):
        # This loan's return already committed and promoted; finish the pending send.
        item = continue_promotion(desk, item_id, item)
        promoted_wait_id, promo_notify = current_promotion_fields(item)
        desk.close()
        emit(
            {
                "item_id": item_id,
                "loan_id": loan_id,
                "availability": item["availability"],
                "loan_state": "returned",
                "promoted_wait_id": promoted_wait_id,
                "notify": promo_notify,
                "now": now,
            }
        )
    result = desk.call("return_item", {"item_id": item_id, "loan_id": loan_id, "now": now})
    item = result.state["items"][item_id]
    promoted_now = (
        bool(result.mutation)
        and not isinstance(result, HistoricalResult)
        and item["promotion_notify"] == "attempt_saved"
        and item["promotion_source_loan_id"] == loan_id
    )
    if promoted_now:
        desk.close()
        crash_if("after-attempt-saved-before-request")
        desk.load(create=False)
        item = desk.aggregate.state["items"][item_id]
        item = continue_promotion(desk, item_id, item)
    promoted_wait_id, promo_notify = current_promotion_fields(item)
    desk.close()
    emit(
        {
            "item_id": item_id,
            "loan_id": loan_id,
            "availability": item["availability"],
            "loan_state": "returned",
            "promoted_wait_id": promoted_wait_id,
            "notify": promo_notify,
            "now": now,
        }
    )


def cmd_status(desk: Desk, args: list[str]) -> None:
    if len(args) != 2:
        fail("bad_args")
    item_id, now_raw = args
    now = parse_time(now_raw, bounded=True)
    if not valid_id(item_id) or now is None:
        fail("bad_args")
    loaded = desk.load(create=False)
    if loaded is None or item_id not in loaded.state["items"]:
        fail("unknown_item")
    desk.close()
    emit(status_body(item_id, loaded.state["items"][item_id], now))


def cmd_wait(desk: Desk, args: list[str]) -> None:
    if len(args) != 6:
        fail("bad_args")
    item_id, wait_id, borrower_id, address, hold_raw, now_raw = args
    hold_seconds = parse_hold_seconds(hold_raw)
    now = parse_time(now_raw, bounded=True)
    if (
        not valid_id(item_id)
        or not valid_id(wait_id)
        or not valid_id(borrower_id)
        or not valid_address(address)
        or hold_seconds is None
        or now is None
    ):
        fail("bad_args")
    loaded = desk.load(create=False)
    if loaded is None:
        fail("unknown_item")
    result = desk.call(
        "join_wait",
        {
            "item_id": item_id,
            "wait_id": wait_id,
            "borrower_id": borrower_id,
            "address": address,
            "hold_seconds": hold_seconds,
        },
    )
    item = result.state["items"][item_id]
    position = len(item["waitlist"])
    desk.close()
    emit(
        {
            "item_id": item_id,
            "wait_id": wait_id,
            "borrower_id": borrower_id,
            "address": address,
            "hold_seconds": hold_seconds,
            "position": position,
            "availability": item["availability"],
            "now": now,
        }
    )


def checkout_success(item_id: str, item: Mapping[str, Any], loan_id: str, now: int) -> dict[str, Any]:
    return {
        "item_id": item_id,
        "reservation_id": item["attempt_reservation_id"],
        "loan_id": loan_id,
        "borrower_id": item["attempt_borrower_id"],
        "address": item["attempt_address"],
        "availability": "checked_out",
        "notify": "sent",
        "request_id": loan_id,
        "now": now,
    }


def commit_confirmation(desk: Desk, item_id: str, item: Mapping[str, Any], loan_id: str, body: Mapping[str, Any], now: int, *, from_post: bool) -> None:
    if from_post:
        desk.close()
        crash_if("after-accept-before-record")
        desk.load(create=False)
    result = desk.call("commit_sent", {"loan_id": loan_id}, observation=body)
    committed = bool(result.mutation) and not isinstance(result, HistoricalResult)
    fresh = result.state["items"][item_id]
    desk.close()
    if committed:
        crash_if("after-record-before-exit")
    emit(checkout_success(item_id, fresh, loan_id, now))


def cmd_checkout(desk: Desk, args: list[str]) -> None:
    if len(args) != 4:
        fail("bad_args")
    item_id, reservation_id, loan_id, now_raw = args
    now = parse_time(now_raw, bounded=True)
    if not valid_id(item_id) or not valid_id(reservation_id) or not valid_id(loan_id) or now is None:
        fail("bad_args")
    loaded = desk.load(create=False)
    if loaded is None:
        fail("unknown_item")
    item = loaded.state["items"].get(item_id)
    if (
        item is not None
        and reservation_id in item["promoted_away_ids"]
        and item["promotion_notify"] == "attempt_saved"
    ):
        # The named reservation expired into a still-pending promotion; finish that send first.
        continue_promotion(desk, item_id, item)
    result = desk.call(
        "begin_checkout",
        {
            "item_id": item_id,
            "reservation_id": reservation_id,
            "loan_id": loan_id,
            "now": now,
        },
    )
    item = result.state["items"][item_id]
    mutated = bool(result.mutation) and not isinstance(result, HistoricalResult)
    saved_now = (
        mutated
        and item["loan_state"] == "attempt_saved"
        and item["reservation_state"] == "active"
        and item["reservation_id"] == reservation_id
    )
    if mutated and item["reservation_state"] == "expired":
        desk.close()
        if item["reservation_id"] == reservation_id:
            fail("expired")
        fail("not_reserved")
    just_promoted = (
        mutated
        and not saved_now
        and item["availability"] == "reserved"
        and item["reservation_id"] != reservation_id
        and item["promotion_notify"] == "attempt_saved"
    )
    if just_promoted:
        desk.close()
        crash_if("after-attempt-saved-before-request")
        desk.load(create=False)
        item = desk.aggregate.state["items"][item_id]
        continue_promotion(desk, item_id, item)
        desk.close()
        if reservation_id in result.state["items"][item_id]["promoted_away_ids"]:
            fail("expired")
        fail("not_reserved")
    if saved_now:
        desk.close()
        crash_if("after-attempt-saved-before-request")
        desk.load(create=False)
        item = desk.aggregate.state["items"][item_id]
    status, body, err = lookup_request(loan_id)
    if err or status is None:
        desk.close()
        fail("service_unavailable")
    if status == 200:
        if body is None or not matches_attempt(body, item_id, item, loan_id):
            desk.close()
            fail("conflict")
        commit_confirmation(desk, item_id, item, loan_id, body, now, from_post=False)
        return
    if status != 404:
        desk.close()
        fail("service_unavailable")
    status, body, err = post_checkout(item_id, item, loan_id)
    if err or status is None:
        desk.close()
        fail("service_unavailable")
    if status == 409:
        desk.close()
        fail("conflict")
    if status != 200 or body is None:
        desk.close()
        fail("service_unavailable")
    commit_confirmation(desk, item_id, item, loan_id, body, now, from_post=True)


def reconcile_body(loan_id: str, item_id: Optional[str], item: Optional[Mapping[str, Any]], notify: str) -> dict[str, Any]:
    if notify == "none":
        return {
            "request_id": loan_id,
            "loan_id": None,
            "item_id": None,
            "kind": None,
            "notify": "none",
            "availability": None,
            "loan_state": "none",
        }
    assert item is not None and item_id is not None
    return {
        "request_id": loan_id,
        "loan_id": loan_id,
        "item_id": item_id,
        "kind": "checkout",
        "notify": notify,
        "availability": item["availability"],
        "loan_state": item["loan_state"],
    }


def reconcile_body_promotion(request_id: str, item_id: Optional[str], item: Optional[Mapping[str, Any]], notify: str) -> dict[str, Any]:
    if notify == "none":
        return {
            "request_id": request_id,
            "loan_id": None,
            "item_id": None,
            "kind": None,
            "notify": "none",
            "availability": None,
            "loan_state": "none",
        }
    assert item is not None and item_id is not None
    return {
        "request_id": request_id,
        "loan_id": item["loan_id"],
        "item_id": item_id,
        "kind": "waitlist_ready",
        "notify": notify,
        "availability": item["availability"],
        "loan_state": item["loan_state"],
    }


def cmd_reconcile(desk: Desk, args: list[str]) -> None:
    if len(args) != 1 or not valid_id(args[0]):
        fail("bad_args")
    the_id = args[0]
    loaded = desk.load(create=False)
    if loaded is None:
        desk.close()
        emit(reconcile_body(the_id, None, None, "none"))
    item_id, item = loan_item(loaded.state, the_id)
    if item_id is not None and item is not None and item["loan_state"] != "none":
        if item["notify"] == "sent":
            desk.close()
            emit(reconcile_body(the_id, item_id, item, "sent"))
        status, body, err = lookup_request(the_id)
        if err or status is None:
            desk.close()
            fail("service_unavailable")
        if status == 404:
            desk.close()
            emit(reconcile_body(the_id, item_id, item, "not_sent"))
        if status != 200 or body is None or not matches_attempt(body, item_id, item, the_id):
            desk.close()
            if status == 200:
                fail("conflict")
            fail("service_unavailable")
        result = desk.call("commit_sent", {"loan_id": the_id}, observation=body)
        committed = bool(result.mutation) and not isinstance(result, HistoricalResult)
        fresh_id, fresh = loan_item(result.state, the_id)
        desk.close()
        if committed:
            crash_if("after-record-before-exit")
        emit(reconcile_body(the_id, fresh_id, fresh, "sent"))

    promo_id, promo_item = promotion_item(loaded.state, the_id)
    if promo_id is None or promo_item is None or promo_item["promotion_request_id"] != the_id:
        desk.close()
        emit(reconcile_body_promotion(the_id, None, None, "none"))
    if promo_item["promotion_notify"] == "sent":
        desk.close()
        emit(reconcile_body_promotion(the_id, promo_id, promo_item, "sent"))
    status, body, err = lookup_request(the_id)
    if err or status is None:
        desk.close()
        fail("service_unavailable")
    if status == 404:
        desk.close()
        emit(reconcile_body_promotion(the_id, promo_id, promo_item, "not_sent"))
    if status != 200 or body is None or not matches_promotion(body, promo_id, promo_item, the_id):
        desk.close()
        if status == 200:
            fail("conflict")
        fail("service_unavailable")
    result = desk.call("commit_promotion_sent", {"request_id": the_id}, observation=body)
    committed = bool(result.mutation) and not isinstance(result, HistoricalResult)
    fresh_promo_id, fresh_promo = promotion_item(result.state, the_id)
    desk.close()
    if committed:
        crash_if("after-record-before-exit")
    emit(reconcile_body_promotion(the_id, fresh_promo_id, fresh_promo, "sent"))


def parse_callback(path: str) -> Mapping[str, Any]:
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError:
        fail("bad_args")
    try:
        decoder = json.JSONDecoder()
        value, end = decoder.raw_decode(text)
    except json.JSONDecodeError:
        fail("bad_args")
    if text[end:].strip():
        fail("bad_args")
    if not isinstance(value, dict):
        fail("bad_args")
    required = ("callback_id", "request_id", "item_id", "borrower_id", "address", "kind", "outcome")
    for field in required:
        if field not in value or not isinstance(value[field], str) or not value[field]:
            fail("bad_args")
    if value["outcome"] not in {"accepted", "rejected"}:
        fail("bad_args")
    if value["kind"] not in {"checkout", "waitlist_ready"}:
        fail("bad_args")
    return value


def cmd_callback(desk: Desk, args: list[str]) -> None:
    if len(args) != 1:
        fail("bad_args")
    payload = parse_callback(args[0])
    loaded = desk.load(create=False)
    if loaded is None:
        emit({"ok": True})
    item_id, item = loan_item(loaded.state, payload["request_id"])
    if item is None or item_id is None:
        desk.close()
        emit({"ok": True})
    if item["notify"] == "sent" or item["loan_state"] in {"checked_out", "returned"}:
        desk.close()
        emit({"ok": True})
    if (
        item["notify"] != "attempt_saved"
        or payload["outcome"] != "accepted"
        or payload["kind"] != "checkout"
    ):
        desk.close()
        emit({"ok": True})
    status, body, err = lookup_request(payload["request_id"])
    if err or status != 200 or body is None or not matches_attempt(body, item_id, item, payload["request_id"]):
        desk.close()
        emit({"ok": True})
    desk.call("commit_sent", {"loan_id": payload["request_id"]}, observation=body)
    desk.close()
    emit({"ok": True})


def main() -> None:
    try:
        run_command(sys.argv[1:])
    except SystemExit:
        raise
    except BrokenPipeError:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
