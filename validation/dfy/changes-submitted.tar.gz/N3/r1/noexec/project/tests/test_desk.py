"""Process-restart, crash-label, and lost-reply checks for the loan desk."""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "run"
NODE = "/Users/galbal/.nvm/versions/node/v22.17.1/bin/node"


class Stub:
    def __init__(self) -> None:
        self.proc = subprocess.Popen(
            [NODE, str(ROOT / "stub" / "server.mjs")],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        line = self.proc.stdout.readline()
        info = json.loads(line)
        self.service = info["service_url"]
        self.control = info["control_url"]

    def close(self) -> None:
        if self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.kill()

    def effects(self) -> dict:
        with urllib.request.urlopen(self.control + "/effects", timeout=5) as response:
            return json.loads(response.read().decode())

    def fault(self, **body) -> None:
        data = json.dumps(body).encode()
        req = urllib.request.Request(
            self.control + "/fault",
            data=data,
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as response:
            response.read()


def invoke(state: str, service: str, args, crash=None):
    env = os.environ.copy()
    env["STATE_DIR"] = state
    env["SERVICE_URL"] = service
    env["IK_BINARY"] = str(ROOT / "KIT" / "bin" / "ik")
    if crash is None:
        env.pop("CRASH_AT", None)
    else:
        env["CRASH_AT"] = crash
    proc = subprocess.run(
        [str(RUN), *args],
        cwd=str(ROOT),
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
    )
    body = None
    if proc.stdout.strip():
        body = json.loads(proc.stdout)
    return proc.returncode, body, proc.stderr


class DeskTests(unittest.TestCase):
    def setUp(self) -> None:
        self.stub = Stub()
        self.tmp = tempfile.TemporaryDirectory()
        self.state = self.tmp.name

    def tearDown(self) -> None:
        self.stub.close()
        self.tmp.cleanup()

    def run_ok(self, *args, crash=None):
        code, body, err = invoke(self.state, self.stub.service, list(args), crash)
        self.assertEqual(code, 0, (body, err))
        self.assertIsInstance(body, dict)
        return body

    def run_err(self, *args, crash=None):
        code, body, err = invoke(self.state, self.stub.service, list(args), crash)
        self.assertNotEqual(code, 0, (body, err))
        self.assertIsInstance(body, dict)
        self.assertIn(body.get("error"), {
            "bad_args", "unknown_item", "id_in_use", "not_available", "not_reserved",
            "reservation_mismatch", "expired", "already_checked_out", "checkout_in_progress",
            "not_checked_out", "loan_mismatch", "service_unavailable", "conflict",
        })
        return body

    def test_restart_reservation_and_second_item(self):
        self.run_ok("add-item", "item-1")
        self.run_ok("add-item", "item-2")
        reserved = self.run_ok("reserve", "item-1", "res-1", "bor-1", "a@b.c", "100", "10")
        self.assertEqual(reserved["availability"], "reserved")
        self.assertEqual(reserved["collect_by"], 100)
        status = self.run_ok("status", "item-1", "10")
        self.assertEqual(status["borrower_id"], "bor-1")
        self.assertEqual(status["address"], "a@b.c")
        self.assertEqual(status["reservation_id"], "res-1")
        other = self.run_ok("status", "item-2", "10")
        self.assertEqual(other["availability"], "available")
        self.assertFalse(other["past_deadline"])

    def test_refusals_do_not_touch_foreign_file(self):
        foreign = Path(self.state) / "other.txt"
        foreign.write_bytes(b"keep-me\n")
        self.run_err("checkout", "missing", "res", "loan", "1")
        self.assertEqual(self.run_err("checkout", "missing", "res", "loan", "1")["error"], "unknown_item")
        self.run_ok("add-item", "item-1")
        self.assertEqual(self.run_err("add-item", "item-1")["error"], "id_in_use")
        self.assertEqual(self.run_err("add-item", "bad id")["error"], "bad_args")
        self.assertEqual(self.run_err("reserve", "nope", "res", "bor", "a@b.c", "5", "1")["error"], "unknown_item")
        self.assertEqual(foreign.read_bytes(), b"keep-me\n")
        self.assertEqual(self.stub.effects()["count"], 0)

    def test_expiry_and_re_reserve_send_no_mail(self):
        self.run_ok("add-item", "rope")
        self.run_ok("reserve", "rope", "res-r", "bor", "a@b.c", "50", "1")
        early = self.run_ok("expire", "rope", "10")
        self.assertFalse(early["expired"])
        self.assertEqual(early["availability"], "reserved")
        due = self.run_ok("expire", "rope", "50")
        self.assertTrue(due["expired"])
        self.assertEqual(due["availability"], "available")
        refused = self.run_err("checkout", "rope", "res-r", "loan-r", "50")
        self.assertEqual(refused["error"], "expired")
        again = self.run_ok("reserve", "rope", "res-r2", "bor", "a@b.c", "90", "50")
        self.assertEqual(again["reservation_id"], "res-r2")
        self.assertEqual(self.stub.effects()["count"], 0)
        self.assertEqual(self.stub.effects()["posts"], [])

    def test_checkout_past_deadline_expires_without_mail(self):
        self.run_ok("add-item", "late")
        self.run_ok("reserve", "late", "res-l", "bor", "a@b.c", "20", "1")
        refused = self.run_err("checkout", "late", "res-l", "loan-l", "20")
        self.assertEqual(refused["error"], "expired")
        status = self.run_ok("status", "late", "20")
        self.assertEqual(status["availability"], "available")
        self.assertEqual(status["reservation_state"], "expired")
        self.assertTrue(status["past_deadline"])
        self.assertEqual(self.stub.effects()["posts"], [])

    def test_healthy_checkout_return_and_double_checkout(self):
        self.run_ok("add-item", "item-1")
        self.run_ok("reserve", "item-1", "res-1", "bor-1", "local@example.com", "100", "10")
        checked = self.run_ok("checkout", "item-1", "res-1", "loan-1", "20")
        self.assertEqual(checked["notify"], "sent")
        self.assertEqual(checked["request_id"], "loan-1")
        status = self.run_ok("status", "item-1", "20")
        self.assertEqual(status["availability"], "checked_out")
        self.assertEqual(status["loan_id"], "loan-1")
        self.assertEqual(status["borrower_id"], "bor-1")
        effects = self.stub.effects()
        self.assertEqual(effects["count"], 1)
        self.assertEqual(effects["effects"][0]["kind"], "checkout")
        self.assertEqual(self.run_err("checkout", "item-1", "res-1", "loan-1", "21")["error"], "already_checked_out")
        self.assertEqual(self.run_err("checkout", "item-1", "res-1", "loan-2", "21")["error"], "already_checked_out")
        self.assertEqual(self.stub.effects()["count"], 1)
        self.assertEqual(self.run_err("return", "item-1", "other", "22")["error"], "loan_mismatch")
        returned = self.run_ok("return", "item-1", "loan-1", "22")
        self.assertEqual(returned["loan_state"], "returned")
        self.assertEqual(returned["availability"], "available")
        self.assertEqual(self.run_err("return", "item-1", "loan-1", "23")["error"], "not_checked_out")
        self.assertEqual(self.stub.effects()["count"], 1)

    def test_crash_before_request_then_resume(self):
        self.run_ok("add-item", "cam")
        self.run_ok("reserve", "cam", "res-c", "bor-c", "a@b.c", "500", "1")
        code, body, _err = invoke(
            self.state, self.stub.service,
            ["checkout", "cam", "res-c", "loan-c", "2"],
            crash="after-attempt-saved-before-request",
        )
        self.assertEqual(code, -9 if code < 0 else 137)
        self.assertFalse(body)
        status = self.run_ok("status", "cam", "2")
        self.assertEqual(status["loan_state"], "attempt_saved")
        self.assertEqual(status["loan_id"], "loan-c")
        self.assertEqual(self.stub.effects()["count"], 0)
        self.assertEqual(self.run_err("checkout", "cam", "res-c", "loan-other", "2")["error"], "checkout_in_progress")
        self.assertEqual(self.stub.effects()["count"], 0)
        done = self.run_ok("checkout", "cam", "res-c", "loan-c", "2")
        self.assertEqual(done["notify"], "sent")
        self.assertEqual(self.stub.effects()["count"], 1)
        self.assertEqual(self.stub.effects()["effects"][0]["request_id"], "loan-c")

    def test_crash_after_accept_does_not_double_send(self):
        self.run_ok("add-item", "axe")
        self.run_ok("reserve", "axe", "res-a", "bor-a", "a@b.c", "500", "1")
        code, _body, _err = invoke(
            self.state, self.stub.service,
            ["checkout", "axe", "res-a", "loan-a", "2"],
            crash="after-accept-before-record",
        )
        self.assertIn(code, (-9, 137))
        status = self.run_ok("status", "axe", "2")
        self.assertEqual(status["notify"], "attempt_saved")
        self.assertEqual(self.stub.effects()["count"], 1)
        done = self.run_ok("checkout", "axe", "res-a", "loan-a", "2")
        self.assertEqual(done["notify"], "sent")
        self.assertEqual(self.stub.effects()["count"], 1)
        self.assertEqual(len(self.stub.effects()["posts"]), 1)

    def test_crash_after_record_is_visible_and_not_repeated(self):
        self.run_ok("add-item", "nail")
        self.run_ok("reserve", "nail", "res-n", "bor-n", "a@b.c", "80", "1")
        code, _body, _err = invoke(
            self.state, self.stub.service,
            ["checkout", "nail", "res-n", "loan-n", "2"],
            crash="after-record-before-exit",
        )
        self.assertIn(code, (-9, 137))
        status = self.run_ok("status", "nail", "2")
        self.assertEqual(status["availability"], "checked_out")
        self.assertEqual(status["notify"], "sent")
        self.assertEqual(self.run_err("checkout", "nail", "res-n", "loan-n", "3")["error"], "already_checked_out")
        self.assertEqual(self.stub.effects()["count"], 1)

    def test_lost_reply_reconcile_does_not_post_again(self):
        self.run_ok("add-item", "saw")
        self.run_ok("reserve", "saw", "res-s", "bor-s", "a@b.c", "500", "1")
        self.stub.fault(drop_reply=True)
        lost = self.run_err("checkout", "saw", "res-s", "loan-s", "2")
        self.assertEqual(lost["error"], "service_unavailable")
        status = self.run_ok("status", "saw", "2")
        self.assertEqual(status["loan_state"], "attempt_saved")
        self.assertEqual(self.stub.effects()["count"], 1)
        posts_before = len(self.stub.effects()["posts"])
        self.stub.fault(drop_reply=False)
        reconciled = self.run_ok("reconcile", "loan-s")
        self.assertEqual(reconciled["notify"], "sent")
        self.assertNotEqual(reconciled["notify"], "not_sent")
        self.assertEqual(self.stub.effects()["count"], 1)
        self.assertEqual(len(self.stub.effects()["posts"]), posts_before)
        self.assertEqual(self.run_ok("status", "saw", "2")["availability"], "checked_out")

    def test_reconcile_absent_and_not_sent(self):
        none = self.run_ok("reconcile", "never")
        self.assertEqual(none["notify"], "none")
        self.assertIsNone(none["loan_id"])
        self.assertIsNone(none["item_id"])
        self.run_ok("add-item", "box")
        self.run_ok("reserve", "box", "res-b", "bor", "a@b.c", "40", "1")
        code, _body, _err = invoke(
            self.state, self.stub.service,
            ["checkout", "box", "res-b", "loan-b", "2"],
            crash="after-attempt-saved-before-request",
        )
        self.assertIn(code, (-9, 137))
        missing = self.run_ok("reconcile", "loan-b")
        self.assertEqual(missing["notify"], "not_sent")
        self.assertEqual(missing["loan_id"], "loan-b")
        self.assertEqual(self.run_ok("status", "box", "2")["loan_state"], "attempt_saved")

    def test_late_callback_does_not_change_sent_loan(self):
        self.run_ok("add-item", "bell")
        self.run_ok("reserve", "bell", "res-b", "bor", "a@b.c", "90", "1")
        self.run_ok("checkout", "bell", "res-b", "loan-b", "2")
        callback = Path(self.state) / "cb.json"
        callback.write_text(json.dumps({
            "callback_id": "cb-loan-b",
            "request_id": "loan-b",
            "item_id": "bell",
            "borrower_id": "other",
            "address": "z@z.z",
            "kind": "checkout",
            "outcome": "accepted",
        }))
        self.assertEqual(self.run_ok("callback", str(callback))["ok"], True)
        callback.write_text(json.dumps({
            "callback_id": "cb-loan-b",
            "request_id": "loan-b",
            "item_id": "bell",
            "borrower_id": "other",
            "address": "other@z.z",
            "kind": "checkout",
            "outcome": "accepted",
        }))
        self.assertEqual(self.run_ok("callback", str(callback))["ok"], True)
        status = self.run_ok("status", "bell", "3")
        self.assertEqual(status["address"], "a@b.c")
        self.assertEqual(status["borrower_id"], "bor")
        self.assertEqual(status["notify"], "sent")
        self.assertEqual(status["loan_id"], "loan-b")
        self.assertEqual(self.stub.effects()["count"], 1)
        self.assertEqual(self.run_err("callback", str(callback) + "-missing")["error"], "bad_args")

    def test_crash_label_is_ignored_when_not_reached(self):
        body = self.run_ok("add-item", "quiet", crash="after-attempt-saved-before-request")
        self.assertEqual(body["item_id"], "quiet")


if __name__ == "__main__":
    unittest.main()
