"""Acceptance coverage for FIFO waitlist promotion and recovery."""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / "run"
NODE = "/Users/galbal/.nvm/versions/node/v22.17.1/bin/node"


class Stub:
    def __init__(self) -> None:
        self.proc = subprocess.Popen(
            [NODE, str(ROOT / "stub" / "server.mjs")],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        info = json.loads(self.proc.stdout.readline())
        self.service = info["service_url"]
        self.control = info["control_url"]

    def close(self) -> None:
        if self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.kill()

    def effects(self) -> dict:
        with urllib.request.urlopen(self.control + "/effects", timeout=5) as response:
            return json.loads(response.read().decode())

    def fault(self, **body) -> None:
        req = urllib.request.Request(
            self.control + "/fault",
            data=json.dumps(body).encode(),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=5) as response:
            response.read()


def invoke(state: str, service: str, *args: str, crash: str | None = None):
    env = os.environ.copy()
    env.update({
        "STATE_DIR": state,
        "SERVICE_URL": service,
        "IK_BINARY": str(ROOT / "KIT" / "bin" / "ik"),
    })
    if crash is None:
        env.pop("CRASH_AT", None)
    else:
        env["CRASH_AT"] = crash
    proc = subprocess.run(
        [str(RUN), *args],
        cwd=str(ROOT),
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
    )
    body = json.loads(proc.stdout) if proc.stdout.strip() else None
    return proc.returncode, body, proc.stderr


class WaitlistTests(unittest.TestCase):
    def setUp(self) -> None:
        self.stub = Stub()
        self.tmp = tempfile.TemporaryDirectory()

    def tearDown(self) -> None:
        self.stub.close()
        self.tmp.cleanup()

    @property
    def state(self) -> str:
        return self.tmp.name

    def ok(self, *args: str, crash: str | None = None) -> dict:
        code, body, stderr = invoke(self.state, self.stub.service, *args, crash=crash)
        self.assertEqual(code, 0, (body, stderr))
        return body

    def err(self, *args: str) -> dict:
        code, body, stderr = invoke(self.state, self.stub.service, *args)
        self.assertNotEqual(code, 0, (body, stderr))
        return body

    def reserve(self, item: str = "item", reservation: str = "res") -> None:
        self.ok("add-item", item)
        self.ok("reserve", item, reservation, "owner", "owner@example.test", "100", "1")

    def test_join_order_and_refusals(self):
        self.reserve()
        self.assertEqual(
            self.ok("wait", "item", "wait-1", "borrower-1", "one@example.test", "20", "2")["position"],
            1,
        )
        self.assertEqual(
            self.ok("wait", "item", "wait-2", "borrower-2", "two@example.test", "30", "3")["position"],
            2,
        )
        status = self.ok("status", "item", "3")
        self.assertEqual([entry["wait_id"] for entry in status["waitlist"]], ["wait-1", "wait-2"])
        self.assertEqual(self.err("wait", "item", "wait-3", "borrower-1", "x@example.test", "5", "3")["error"], "already_waiting")
        self.assertEqual(self.stub.effects()["count"], 0)

        self.ok("add-item", "available")
        self.assertEqual(self.err("wait", "available", "wait-3", "borrower-3", "x@example.test", "5", "3")["error"], "not_needed")

    def test_return_promotes_only_head(self):
        self.reserve()
        self.ok("checkout", "item", "res", "loan", "2")
        self.ok("wait", "item", "wait-1", "borrower-1", "one@example.test", "20", "3")
        self.ok("wait", "item", "wait-2", "borrower-2", "two@example.test", "30", "4")
        returned = self.ok("return", "item", "loan", "10")
        self.assertEqual(returned["promoted_wait_id"], "wait-1")
        status = self.ok("status", "item", "10")
        self.assertEqual(status["availability"], "reserved")
        self.assertEqual(status["reservation_id"], "wait-1")
        self.assertEqual(status["collect_by"], 30)
        self.assertEqual([entry["wait_id"] for entry in status["waitlist"]], ["wait-2"])
        self.assertEqual(status["promotion"]["notify"], "sent")
        effects = self.stub.effects()
        self.assertEqual(effects["count"], 2)
        self.assertEqual([entry["kind"] for entry in effects["effects"]], ["checkout", "waitlist_ready"])
        self.assertEqual(self.err("return", "item", "loan", "11")["error"], "not_checked_out")
        self.assertEqual(self.stub.effects()["count"], 2)

    def test_expiry_chains_waiters_without_checkout_mail(self):
        self.reserve()
        self.ok("wait", "item", "wait-1", "borrower-1", "one@example.test", "20", "2")
        self.ok("wait", "item", "wait-2", "borrower-2", "two@example.test", "30", "3")
        first = self.ok("expire", "item", "100")
        self.assertEqual(first["promoted_wait_id"], "wait-1")
        self.assertEqual(self.ok("expire", "item", "119")["expired"], False)
        second = self.ok("expire", "item", "120")
        self.assertEqual(second["promoted_wait_id"], "wait-2")
        effects = self.stub.effects()
        self.assertEqual(effects["count"], 2)
        self.assertEqual([entry["request_id"] for entry in effects["effects"]], ["wait-1", "wait-2"])
        self.assertTrue(all(entry["kind"] == "waitlist_ready" for entry in effects["effects"]))
        self.assertEqual(self.err("checkout", "item", "res", "loan", "121")["error"], "expired")
        self.assertEqual(self.stub.effects()["count"], 2)

    def test_uncertain_and_crashed_promotion_recover_without_second_effect(self):
        self.reserve()
        self.ok("checkout", "item", "res", "loan", "2")
        self.ok("wait", "item", "wait-1", "borrower-1", "one@example.test", "20", "3")
        self.stub.fault(drop_reply=True)
        self.assertEqual(self.err("return", "item", "loan", "10")["error"], "service_unavailable")
        self.stub.fault(drop_reply=False)
        reconciled = self.ok("reconcile", "wait-1")
        self.assertEqual(reconciled["kind"], "waitlist_ready")
        self.assertEqual(reconciled["notify"], "sent")
        self.assertEqual(self.stub.effects()["count"], 2)

        other = tempfile.TemporaryDirectory()
        try:
            state = other.name
            for args in (
                ("add-item", "other"),
                ("reserve", "other", "res-2", "owner-2", "owner2@example.test", "100", "1"),
                ("checkout", "other", "res-2", "loan-2", "2"),
                ("wait", "other", "wait-2", "borrower-2", "two@example.test", "20", "3"),
            ):
                code, body, stderr = invoke(state, self.stub.service, *args)
                self.assertEqual(code, 0, (body, stderr))
            code, body, _ = invoke(
                state,
                self.stub.service,
                "return", "other", "loan-2", "10",
                crash="after-attempt-saved-before-request",
            )
            self.assertIn(code, (-9, 137))
            self.assertIsNone(body)
            status_code, status, _ = invoke(state, self.stub.service, "status", "other", "10")
            self.assertEqual(status_code, 0)
            self.assertEqual(status["reservation_id"], "wait-2")
            self.assertEqual(status["promotion"]["notify"], "attempt_saved")
            done_code, done, stderr = invoke(state, self.stub.service, "return", "other", "loan-2", "10")
            self.assertEqual(done_code, 0, (done, stderr))
            self.assertEqual(done["promoted_wait_id"], "wait-2")
            matching = [effect for effect in self.stub.effects()["effects"] if effect["request_id"] == "wait-2"]
            self.assertEqual(len(matching), 1)
        finally:
            other.cleanup()


if __name__ == "__main__":
    unittest.main()
