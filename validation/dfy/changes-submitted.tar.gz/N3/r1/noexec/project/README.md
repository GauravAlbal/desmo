# Equipment loan desk

Local desk for registering equipment, reserving it until a collection deadline,
checking it out, returning it, and promoting a FIFO waitlist. Checkout sends one
confirmation through the mail service. Returning an item or expiring its active
reservation promotes the first waiter and sends one `waitlist_ready` notice.
Lifecycle transitions and their durable records are committed by the Ikaros
runtime (`invariant_kernel` plus `KIT/bin/ik`). The host parses commands, calls
the mail service, and prints JSON.

## Setup

From this directory, with the shipped wheel (no network registry):

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index --no-deps KIT/python/*.whl
chmod +x run
```

`./run` creates that virtualenv itself if it is missing. Node is only needed to
run the supplied mail stub.

## Run

```sh
export STATE_DIR=/tmp/loan-desk
export SERVICE_URL=http://127.0.0.1:9
./run add-item item-1
./run reserve item-1 res-1 borrower-1 borrower@example.test 100 1
./run wait item-1 wait-1 borrower-2 other@example.test 60 2
```

Each invocation prints one JSON object and exits 0 on success. A refusal exits
nonzero with an `error` field set to a code from the brief.

The mail stub:

```sh
/Users/galbal/.nvm/versions/node/v22.17.1/bin/node stub/server.mjs
```

It prints `service_url` and `control_url`. Point `SERVICE_URL` at `service_url`.
The desk never reads the control port.

Optional `CRASH_AT` is one of `after-attempt-saved-before-request`,
`after-accept-before-record`, or `after-record-before-exit`. The same boundaries
apply to checkout confirmations and promotion notices. The process kills itself
with SIGKILL only if that command reaches the named boundary.

## Tests

```sh
.venv/bin/python -m unittest discover -s tests
```

## Records

The desk writes only `loan-desk.sqlite` (and SQLite journal files for that name)
under `STATE_DIR`. Other files in that directory are left unchanged. The desk
does not read the wall clock; command arguments supply all times. Checkout uses
the loan id as its request id; promotion uses the wait id. Both effects are
looked up before POST, and uncertain outcomes are reconciled without POSTing.

The waitlist change uses reducer identity version 2 and a new state shape. Stores
created by the previous reducer identity are intentionally not migrated; start
with a fresh `STATE_DIR` for this version.
