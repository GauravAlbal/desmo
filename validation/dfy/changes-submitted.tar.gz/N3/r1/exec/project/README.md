# Equipment loan desk

Local desk for registering equipment, reserving it until a collection deadline, checking it out, and returning it. Checkout sends one confirmation through the mail service. Lifecycle transitions and their durable records are committed by the Ikaros runtime (`invariant_kernel` plus `KIT/bin/ik`). The host parses commands, calls the mail service, and prints JSON. It does not decide those transitions itself.

## Setup

From this directory, with the shipped wheel (no network registry):

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index --no-deps KIT/python/*.whl
chmod +x run
```

`./run` creates that virtualenv itself if it is missing. Node is only needed to run the supplied mail stub.

## Run

```sh
export STATE_DIR=/tmp/loan-desk
export SERVICE_URL=http://127.0.0.1:9
./run add-item item-1
./run wait item-1 wait-1 borrower-1 local@example.com 3600 10
```

Each invocation prints one JSON object and exits 0 on success. A refusal exits nonzero with an `error` field set to a code from the brief. `wait` joins the FIFO waitlist for a reserved or checked-out item; return or expiry promotes the head and sends one `waitlist_ready` notice.

The mail stub:

```sh
/Users/galbal/.nvm/versions/node/v22.17.1/bin/node stub/server.mjs
```

It prints `service_url` and `control_url`. Point `SERVICE_URL` at `service_url`. The desk never reads the control port.

Optional `CRASH_AT` is one of `after-attempt-saved-before-request`, `after-accept-before-record`, or `after-record-before-exit`. These boundaries apply to checkout confirmations and waitlist promotion notices, and kill the process only when that command reaches the named boundary.

## Tests

```sh
.venv/bin/python -m unittest tests/test_desk.py
```

## Records

The desk writes only `loan-desk.sqlite` (and SQLite journal files for that name) under `STATE_DIR`. Other files in that directory are left unchanged. The desk does not read the wall clock; `now` and `collect_by` come from command arguments. The checkout confirmation request id is the loan id; the waitlist promotion request id is the wait id.
