"""Operator entry point. One command, one JSON object, Ikaros-backed records."""

from __future__ import annotations

import json
import os
import signal
import sys
from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
_pp = os.environ.get("PYTHONPATH", "")
os.environ["PYTHONPATH"] = str(ROOT) if not _pp else str(ROOT) + ":" + _pp
os.environ.setdefault("IK_BINARY", str(ROOT / "KIT" / "bin" / "ik"))

from invariant_kernel import Kernel, KernelError

from desk.mail import MailClient
from desk.validate import ERROR_CODES, parse_time, valid_address, valid_id

DESK_ID = "desk"
_KERNEL = None


def close_kernel() -> None:
    global _KERNEL
    kernel = _KERNEL
    _KERNEL = None
    if kernel is not None:
        kernel.close()


def crash_if(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        close_kernel()
        os.kill(os.getpid(), signal.SIGKILL)


def emit(payload: dict, code: int = 0) -> None:
    close_kernel()
    sys.stdout.write(json.dumps(payload) + "\n")
    sys.stdout.flush()
    raise SystemExit(code)


def fail(code: str) -> None:
    if code not in ERROR_CODES:
        code = "bad_args"
    emit({"error": code}, 1)


def thaw(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: thaw(item) for key, item in value.items()}
    if isinstance(value, list):
        return [thaw(item) for item in value]
    return value


class Desk:
    def __init__(self, state_dir: str) -> None:
        self.state_dir = state_dir
        self.store_path = os.path.join(state_dir, "loan-desk.sqlite")
        self.kernel = None
        self.machine = None
        self.agg = None

    def _connect(self) -> None:
        global _KERNEL
        if self.kernel is not None:
            return
        os.makedirs(self.state_dir, exist_ok=True)
        self.kernel = Kernel(
            store=self.store_path,
            binary=os.environ["IK_BINARY"],
            session=True,
            timeout=30,
        )
        _KERNEL = self.kernel
        self.machine = self.kernel.reducer(
            "desk.reducer:LoanDeskReducer",
            python=sys.executable,
        )

    def load(self):
        if not os.path.exists(self.store_path):
            return None
        self._connect()
        try:
            self.agg = self.machine.show(DESK_ID)
        except KernelError as exc:
            if getattr(exc, "rule", None) == "aggregate.not_found":
                return None
            raise
        return thaw(self.agg.state)

    def apply(self, command: dict, observation=None):
        self._connect()
        if self.agg is None and os.path.exists(self.store_path):
            try:
                self.agg = self.machine.show(DESK_ID)
            except KernelError as exc:
                if getattr(exc, "rule", None) != "aggregate.not_found":
                    raise
        try:
            if self.agg is None:
                result = self.machine.create_with(DESK_ID, command)
            else:
                result = self.agg.execute(command, observation)
        except KernelError as exc:
            rule = getattr(exc, "rule", None)
            if rule in ERROR_CODES:
                fail(rule)
            raise
        self.agg = result
        return thaw(result.state), bool(result.mutation)


def item_of(state, item_id: str):
    if state is None:
        return None
    return state["items"].get(item_id)


def status_payload(item_id: str, item: dict, now: int) -> dict:
    reservation_state = item["reservation_state"]
    past = reservation_state == "expired" or (
        reservation_state == "active" and now >= item["collect_by"]
    )
    return {
        "item_id": item_id,
        "availability": item["availability"],
        "reservation_id": item["reservation_id"],
        "borrower_id": item["borrower_id"],
        "address": item["address"],
        "collect_by": item["collect_by"],
        "reservation_state": reservation_state,
        "past_deadline": past,
        "loan_id": item["loan_id"],
        "loan_state": item["loan_state"],
        "notify": item["notify"],
        "waitlist": list(item.get("waitlist", [])),
        "promotion": dict(item.get("promotion", {
            "request_id": None,
            "notify": "none",
            "wait_id": None,
        })),
        "now": now,
    }


def require_env():
    state_dir = os.environ.get("STATE_DIR")
    service_url = os.environ.get("SERVICE_URL")
    if not state_dir or not service_url:
        fail("bad_args")
    return state_dir, service_url


def command_add(desk: Desk, args: list) -> None:
    if len(args) != 1 or not valid_id(args[0]):
        fail("bad_args")
    state, _ = desk.apply({"name": "add_item", "item_id": args[0]})
    item = state["items"][args[0]]
    emit({
        "item_id": args[0],
        "availability": item["availability"],
        "reservation_id": item["reservation_id"],
        "loan_id": item["loan_id"],
    })


def command_reserve(desk: Desk, mail: MailClient, args: list) -> None:
    if len(args) != 6:
        fail("bad_args")
    item_id, reservation_id, borrower_id, address, collect_text, now_text = args
    collect_by = parse_time(collect_text, bound_now=False)
    now = parse_time(now_text, bound_now=True)
    if (
        not valid_id(item_id)
        or not valid_id(reservation_id)
        or not valid_id(borrower_id)
        or not valid_address(address)
        or collect_by is None
        or now is None
        or collect_by <= now
    ):
        fail("bad_args")
    state = desk.load()
    if item_of(state, item_id) is None:
        fail("unknown_item")
    if reservation_id in state["ids"]:
        fail("id_in_use")
    state, expired_mutated = desk.apply({"name": "expire_if_due", "item_id": item_id, "now": now})
    item = state["items"][item_id]
    if item.get("promotion", {}).get("notify") == "attempt_saved":
        if expired_mutated:
            crash_if("after-attempt-saved-before-request")
        _finish_promotion(desk, mail, item_id)
        state = desk.load()
    state, _ = desk.apply({
        "name": "reserve",
        "item_id": item_id,
        "reservation_id": reservation_id,
        "borrower_id": borrower_id,
        "address": address,
        "collect_by": collect_by,
        "now": now,
    })
    item = state["items"][item_id]
    emit({
        "item_id": item_id,
        "reservation_id": item["reservation_id"],
        "borrower_id": item["borrower_id"],
        "address": item["address"],
        "collect_by": item["collect_by"],
        "availability": item["availability"],
        "now": now,
    })
def command_wait(desk: Desk, args: list) -> None:
    if len(args) != 6:
        fail("bad_args")
    item_id, wait_id, borrower_id, address, hold_text, now_text = args
    hold_seconds = parse_time(hold_text, bound_now=False)
    now = parse_time(now_text, bound_now=True)
    if (
        not valid_id(item_id)
        or not valid_id(wait_id)
        or not valid_id(borrower_id)
        or not valid_address(address)
        or hold_seconds is None
        or hold_seconds < 1
        or hold_seconds > 2592000
        or now is None
    ):
        fail("bad_args")
    state = desk.load()
    if item_of(state, item_id) is None:
        fail("unknown_item")
    state, _ = desk.apply({
        "name": "wait",
        "item_id": item_id,
        "wait_id": wait_id,
        "borrower_id": borrower_id,
        "address": address,
        "hold_seconds": hold_seconds,
    })
    item = state["items"][item_id]
    emit({
        "item_id": item_id,
        "wait_id": wait_id,
        "borrower_id": borrower_id,
        "address": address,
        "hold_seconds": hold_seconds,
        "position": len(item["waitlist"]),
        "availability": item["availability"],
        "now": now,
    })


def command_expire(desk: Desk, mail: MailClient, args: list) -> None:
    if len(args) != 2:
        fail("bad_args")
    item_id, now_text = args
    now = parse_time(now_text, bound_now=True)
    if not valid_id(item_id) or now is None:
        fail("bad_args")
    if item_of(desk.load(), item_id) is None:
        fail("unknown_item")
    before_reservation_id = desk.load()["items"][item_id]["reservation_id"]
    state, mutated = desk.apply({"name": "expire_if_due", "item_id": item_id, "now": now})
    item = state["items"][item_id]
    if item.get("promotion", {}).get("notify") == "attempt_saved":
        if mutated and item["reservation_id"] != before_reservation_id:
            crash_if("after-attempt-saved-before-request")
        _finish_promotion(desk, mail, item_id)
        state = desk.load()
        item = state["items"][item_id]
    promotion = item.get("promotion", {})
    promoted_wait_id = (
        item["reservation_id"]
        if mutated and item["reservation_id"] != before_reservation_id
        else None
    )
    emit({
        "item_id": item_id,
        "availability": item["availability"],
        "expired": mutated,
        "reservation_id": item["reservation_id"],
        "promoted_wait_id": promoted_wait_id,
        "notify": promotion.get("notify", "none") if promoted_wait_id else "none",
        "now": now,
    })


def command_checkout(desk: Desk, mail: MailClient, args: list) -> None:
    if len(args) != 4:
        fail("bad_args")
    item_id, reservation_id, loan_id, now_text = args
    now = parse_time(now_text, bound_now=True)
    if not valid_id(item_id) or not valid_id(reservation_id) or not valid_id(loan_id) or now is None:
        fail("bad_args")
    if item_of(desk.load(), item_id) is None:
        fail("unknown_item")
    state, expired_mutated = desk.apply({"name": "expire_if_due", "item_id": item_id, "now": now})
    item = state["items"][item_id]
    if item.get("promotion", {}).get("notify") == "attempt_saved":
        if expired_mutated:
            crash_if("after-attempt-saved-before-request")
        _finish_promotion(desk, mail, item_id)
        state = desk.load()
        item = state["items"][item_id]
    if state.get("reservations", {}).get(reservation_id, {}).get("state") == "expired":
        fail("expired")
    if item["reservation_state"] == "expired" and item["reservation_id"] == reservation_id:
        fail("expired")
    state, saved_now = desk.apply({
        "name": "save_attempt",
        "item_id": item_id,
        "reservation_id": reservation_id,
        "loan_id": loan_id,
        "now": now,
    })
    loan = state["loans"][loan_id]
    if saved_now:
        crash_if("after-attempt-saved-before-request")
    outcome = _confirm(mail, loan_id, loan)
    if outcome is None:
        fail("service_unavailable")
    state, recorded = desk.apply({"name": "mark_sent", "loan_id": loan_id}, outcome)
    if recorded:
        crash_if("after-record-before-exit")
    item = state["items"][item_id]
    emit({
        "item_id": item_id,
        "reservation_id": item["reservation_id"],
        "loan_id": loan_id,
        "borrower_id": item["borrower_id"],
        "address": item["address"],
        "availability": item["availability"],
        "notify": item["notify"],
        "request_id": loan_id,
        "now": now,
    })


def _confirm(mail: MailClient, loan_id: str, loan: dict):
    status, body = mail.lookup(loan_id)
    if status == "unavailable":
        return None
    if status == "ok":
        if _matches(body, loan, loan_id):
            return body
        fail("conflict")
    if status != "not_found":
        return None
    payload = {
        "request_id": loan_id,
        "item_id": loan["item_id"],
        "borrower_id": loan["borrower_id"],
        "address": loan["address"],
        "kind": "checkout",
    }
    posted, body = mail.confirm(payload)
    if posted == "conflict":
        fail("conflict")
    if posted != "ok" or not _matches(body, loan, loan_id):
        return None
    crash_if("after-accept-before-record")
    return body


def _matches(body, loan: dict, loan_id: str) -> bool:
    return isinstance(body, dict) and (
        body.get("request_id") == loan_id
        and body.get("item_id") == loan["item_id"]
        and body.get("borrower_id") == loan["borrower_id"]
        and body.get("address") == loan["address"]
        and body.get("kind") == "checkout"
        and body.get("outcome") == "accepted"
    )
def _promotion_matches(body, promotion: dict, wait_id: str) -> bool:
    return isinstance(body, dict) and (
        body.get("request_id") == wait_id
        and body.get("item_id") == promotion["item_id"]
        and body.get("borrower_id") == promotion["borrower_id"]
        and body.get("address") == promotion["address"]
        and body.get("kind") == "waitlist_ready"
        and body.get("outcome") == "accepted"
    )


def _finish_promotion(desk: Desk, mail: MailClient, item_id: str):
    state = desk.load()
    item = state["items"][item_id]
    pointer = item.get("promotion", {})
    wait_id = pointer.get("wait_id")
    if pointer.get("notify") != "attempt_saved" or not wait_id:
        return state, False
    promotion = state.get("promotions", {}).get(wait_id)
    if promotion is None:
        fail("conflict")
    status, body = mail.lookup(wait_id)
    if status == "unavailable":
        fail("service_unavailable")
    if status == "ok":
        if not _promotion_matches(body, promotion, wait_id):
            fail("conflict")
    elif status == "not_found":
        payload = {
            "request_id": wait_id,
            "item_id": promotion["item_id"],
            "borrower_id": promotion["borrower_id"],
            "address": promotion["address"],
            "kind": "waitlist_ready",
        }
        posted, body = mail.confirm(payload)
        if posted == "conflict":
            fail("conflict")
        if posted != "ok" or not _promotion_matches(body, promotion, wait_id):
            fail("service_unavailable")
        crash_if("after-accept-before-record")
    else:
        fail("service_unavailable")
    state, recorded = desk.apply({"name": "mark_promotion_sent", "wait_id": wait_id}, body)
    if recorded:
        crash_if("after-record-before-exit")
    return state, recorded


def command_return(desk: Desk, mail: MailClient, args: list) -> None:
    if len(args) != 3:
        fail("bad_args")
    item_id, loan_id, now_text = args
    now = parse_time(now_text, bound_now=True)
    if not valid_id(item_id) or not valid_id(loan_id) or now is None:
        fail("bad_args")
    if item_of(desk.load(), item_id) is None:
        fail("unknown_item")
    state, return_mutated = desk.apply({
        "name": "return_item",
        "item_id": item_id,
        "loan_id": loan_id,
        "now": now,
    })
    item = state["items"][item_id]
    if item.get("promotion", {}).get("notify") == "attempt_saved":
        if return_mutated:
            crash_if("after-attempt-saved-before-request")
        _finish_promotion(desk, mail, item_id)
        state = desk.load()
        item = state["items"][item_id]
    promotion = item.get("promotion", {})
    promoted = promotion.get("source_loan_id") == loan_id and promotion.get("wait_id")
    emit({
        "item_id": item_id,
        "loan_id": loan_id,
        "availability": item["availability"],
        "loan_state": item["loan_state"],
        "promoted_wait_id": promotion.get("wait_id") if promoted else None,
        "notify": promotion.get("notify", "none") if promoted else "none",
        "now": now,
    })


def command_status(desk: Desk, args: list) -> None:
    if len(args) != 2:
        fail("bad_args")
    item_id, now_text = args
    now = parse_time(now_text, bound_now=True)
    if not valid_id(item_id) or now is None:
        fail("bad_args")
    item = item_of(desk.load(), item_id)
    if item is None:
        fail("unknown_item")
    emit(status_payload(item_id, item, now))


def command_reconcile(desk: Desk, mail: MailClient, args: list) -> None:
    if len(args) != 1 or not valid_id(args[0]):
        fail("bad_args")
    request_id = args[0]
    state = desk.load()
    promotion = None if state is None else state.get("promotions", {}).get(request_id)
    if promotion is not None:
        item = state["items"][promotion["item_id"]]
        if promotion["notify"] == "sent":
            emit({
                "request_id": request_id,
                "loan_id": promotion.get("source_loan_id"),
                "item_id": promotion["item_id"],
                "kind": "waitlist_ready",
                "notify": "sent",
                "availability": item["availability"],
                "loan_state": item["loan_state"],
            })
        status, body = mail.lookup(request_id)
        if status == "not_found":
            emit({
                "request_id": request_id,
                "loan_id": promotion.get("source_loan_id"),
                "item_id": promotion["item_id"],
                "kind": "waitlist_ready",
                "notify": "not_sent",
                "availability": item["availability"],
                "loan_state": item["loan_state"],
            })
        if status != "ok":
            fail("service_unavailable")
        if not _promotion_matches(body, promotion, request_id):
            fail("conflict")
        state, recorded = desk.apply({"name": "mark_promotion_sent", "wait_id": request_id}, body)
        if recorded:
            crash_if("after-record-before-exit")
        item = state["items"][promotion["item_id"]]
        emit({
            "request_id": request_id,
            "loan_id": promotion.get("source_loan_id"),
            "item_id": promotion["item_id"],
            "kind": "waitlist_ready",
            "notify": "sent",
            "availability": item["availability"],
            "loan_state": item["loan_state"],
        })
    loan = None if state is None else state["loans"].get(request_id)
    if loan is None:
        emit({
            "request_id": request_id,
            "loan_id": None,
            "item_id": None,
            "kind": None,
            "notify": "none",
            "availability": None,
            "loan_state": "none",
        })
    if loan["notify"] == "sent":
        item = state["items"][loan["item_id"]]
        loan_state = item["loan_state"] if item.get("loan_id") == request_id else loan["loan_state"]
        emit({
            "request_id": request_id,
            "loan_id": request_id,
            "item_id": loan["item_id"],
            "kind": "checkout",
            "notify": "sent",
            "availability": item["availability"],
            "loan_state": loan_state,
        })
    status, body = mail.lookup(request_id)
    if status == "not_found":
        item = state["items"][loan["item_id"]]
        emit({
            "request_id": request_id,
            "loan_id": request_id,
            "item_id": loan["item_id"],
            "kind": "checkout",
            "notify": "not_sent",
            "availability": item["availability"],
            "loan_state": loan["loan_state"],
        })
    if status != "ok":
        fail("service_unavailable")
    if not _matches(body, loan, request_id):
        fail("conflict")
    state, recorded = desk.apply({"name": "mark_sent", "loan_id": request_id}, body)
    if recorded:
        crash_if("after-record-before-exit")
    item = state["items"][loan["item_id"]]
    emit({
        "request_id": request_id,
        "loan_id": request_id,
        "item_id": loan["item_id"],
        "kind": "checkout",
        "notify": "sent",
        "availability": item["availability"],
        "loan_state": item["loan_state"],
    })


def command_callback(desk: Desk, mail: MailClient, args: list) -> None:
    if len(args) != 1:
        fail("bad_args")
    try:
        parsed = json.loads(Path(args[0]).read_text(encoding="utf-8"))
    except Exception:
        fail("bad_args")
    if not _callback_ok(parsed):
        fail("bad_args")
    state = desk.load()
    request_id = parsed["request_id"]
    promotion = None if state is None else state.get("promotions", {}).get(request_id)
    if promotion is not None:
        if promotion["notify"] == "sent" or parsed["outcome"] != "accepted":
            emit({"ok": True})
        status, body = mail.lookup(request_id)
        if status == "ok" and _promotion_matches(body, promotion, request_id):
            desk.apply({"name": "mark_promotion_sent", "wait_id": request_id}, body)
        emit({"ok": True})
    loan = None if state is None else state["loans"].get(request_id)
    if loan is None or loan["notify"] == "sent" or loan["loan_state"] in {"checked_out", "returned"}:
        emit({"ok": True})
    if parsed["outcome"] != "accepted" or loan["notify"] != "attempt_saved":
        emit({"ok": True})
    status, body = mail.lookup(request_id)
    if status == "ok" and _matches(body, loan, request_id):
        desk.apply({"name": "mark_sent", "loan_id": request_id}, body)
    emit({"ok": True})


def _callback_ok(parsed: Any) -> bool:
    if not isinstance(parsed, dict):
        return False
    required = ("callback_id", "request_id", "item_id", "borrower_id", "address", "kind", "outcome")
    if any(not isinstance(parsed.get(key), str) or parsed.get(key) == "" for key in required):
        return False
    if parsed["kind"] not in {"checkout", "waitlist_ready"}:
        return False
    if parsed["outcome"] not in {"accepted", "rejected"}:
        return False
    return True


def main(argv: list) -> None:
    if not argv:
        fail("bad_args")
    state_dir, service_url = require_env()
    name, args = argv[0], argv[1:]
    desk = Desk(state_dir)
    mail = MailClient(service_url)
    commands = {
        "add-item": lambda: command_add(desk, args),
        "reserve": lambda: command_reserve(desk, mail, args),
        "wait": lambda: command_wait(desk, args),
        "expire": lambda: command_expire(desk, mail, args),
        "checkout": lambda: command_checkout(desk, mail, args),
        "return": lambda: command_return(desk, mail, args),
        "status": lambda: command_status(desk, args),
        "reconcile": lambda: command_reconcile(desk, mail, args),
        "callback": lambda: command_callback(desk, mail, args),
    }
    handler = commands.get(name)
    if handler is None:
        fail("bad_args")
    try:
        handler()
    except SystemExit:
        raise
    except Exception as exc:
        emit({"error": "service_unavailable", "detail": type(exc).__name__ + ": " + str(exc)}, 1)
    fail("bad_args")


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    finally:
        close_kernel()
