"""Mail-service client. Lookup and one confirmation POST. No second request id."""

from __future__ import annotations

import json
from typing import Any, Optional
from urllib import error, request


class MailClient:
    def __init__(self, base_url: str, timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def lookup(self, loan_id: str):
        return self._exchange("GET", "/v1/requests/" + loan_id, None)

    def confirm(self, payload: dict):
        return self._exchange("POST", "/v1/messages", payload)

    def _exchange(self, method: str, path: str, payload):
        data = None
        headers = {}
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        req = request.Request(self.base_url + path, data=data, headers=headers, method=method)
        try:
            with request.urlopen(req, timeout=self.timeout) as response:
                body = _read_complete(response)
                status = response.status
        except error.HTTPError as exc:
            try:
                raw = exc.read()
            except Exception:
                return "unavailable", None
            status = exc.code
            if status == 404 and method == "GET":
                return "not_found", None
            if status == 409:
                return "conflict", _parse_object(raw)
            return "unavailable", None
        except Exception:
            return "unavailable", None
        if status != 200:
            return "unavailable", None
        parsed = _parse_object(body)
        if parsed is None:
            return "unavailable", None
        return "ok", parsed


def _read_complete(response: Any) -> bytes:
    body = response.read()
    declared = response.headers.get("Content-Length")
    if declared is not None and declared.isdigit() and int(declared) != len(body):
        raise OSError("incomplete response body")
    return body


def _parse_object(raw: bytes):
    try:
        parsed = json.loads(raw.decode("utf-8"))
    except Exception:
        return None
    if not isinstance(parsed, dict):
        return None
    return parsed
