"""Equipment-loan lifecycle decisions.

Rust commits these decisions and is the only persistence authority. The host
may not mark a loan sent, expire a reservation, or claim an id except by
submitting one of these commands.
"""

from __future__ import annotations

import hashlib
from typing import Any, Mapping, Optional

from invariant_kernel import (
    ApplyOutcome,
    Decision,
    DomainEvent,
    ReducerDiagnostic,
    ReducerIdentity,
)

from desk.validate import valid_address, valid_id


def _digest(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): thaw(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [thaw(item) for item in value]
    return value


def refuse(code: str) -> ReducerDiagnostic:
    return ReducerDiagnostic(code, code, rule=code)


def blank_item() -> dict:
    return {
        "availability": "available",
        "reservation_id": None,
        "borrower_id": None,
        "address": None,
        "collect_by": None,
        "reservation_state": "none",
        "loan_id": None,
        "loan_state": "none",
        "notify": "none",
        "waitlist": [],
        "promotion": {
            "request_id": None,
            "notify": "none",
            "wait_id": None,
            "source_loan_id": None,
        },
    }


def _normalize_item(item: Mapping[str, Any]) -> dict:
    result = dict(item)
    result.setdefault("waitlist", [])
    result.setdefault("promotion", {
        "request_id": None,
        "notify": "none",
        "wait_id": None,
        "source_loan_id": None,
    })
    result["waitlist"] = [dict(waiter) for waiter in result["waitlist"]]
    result["promotion"] = dict(result["promotion"])
    return result


def copy_state(state: Mapping[str, Any]) -> dict:
    return {
        "items": {key: _normalize_item(item) for key, item in state["items"].items()},
        "ids": dict(state["ids"]),
        "loans": {key: dict(loan) for key, loan in state["loans"].items()},
        "reservations": {
            key: dict(value) for key, value in state.get("reservations", {}).items()
        },
        "promotions": {
            key: dict(value) for key, value in state.get("promotions", {}).items()
        },
    }


def _is_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def _service_matches(observation: Mapping[str, Any], loan: Mapping[str, Any], loan_id: str) -> bool:
    return (
        observation.get("request_id") == loan_id
        and observation.get("item_id") == loan["item_id"]
        and observation.get("borrower_id") == loan["borrower_id"]
        and observation.get("address") == loan["address"]
        and observation.get("kind") == "checkout"
        and observation.get("outcome") == "accepted"
    )
def _promotion_matches(observation: Mapping[str, Any], promotion: Mapping[str, Any]) -> bool:
    return (
        observation.get("request_id") == promotion["request_id"]
        and observation.get("item_id") == promotion["item_id"]
        and observation.get("borrower_id") == promotion["borrower_id"]
        and observation.get("address") == promotion["address"]
        and observation.get("kind") == "waitlist_ready"
        and observation.get("outcome") == "accepted"
    )


class LoanDeskReducer:
    identity = ReducerIdentity(
        reducer_name="loan_desk",
        reducer_version=1,
        code_digest=_digest("loan_desk.reducer.v1"),
        command_schema_digest=_digest("loan_desk.commands.v1"),
        state_schema_digest=_digest("loan_desk.state.v1"),
    )

    def initial_state(self) -> dict:
        return {"items": {}, "ids": {}, "loans": {}, "reservations": {}, "promotions": {}}

    def decide(self, state: Any, observation: Optional[Any], effect: Any, command: Any):
        del effect
        state = thaw(state)
        command = thaw(command)
        observation = None if observation is None else thaw(observation)
        if not isinstance(command, dict):
            return refuse("bad_args")
        name = command.get("name")
        handler = {
            "add_item": self._add_item,
            "expire_if_due": self._expire_if_due,
            "reserve": self._reserve,
            "wait": self._wait,
            "save_attempt": self._save_attempt,
            "mark_sent": self._mark_sent,
            "mark_promotion_sent": self._mark_promotion_sent,
            "return_item": self._return_item,
        }.get(name)
        if handler is None:
            return refuse("bad_args")
        result = handler(state, command, observation)
        if isinstance(result, ReducerDiagnostic):
            return result
        if result is None:
            return Decision.noop()
        return Decision.emit(DomainEvent(str(name), 1, result))

    def apply(self, state: Any, event: Any):
        del state
        nxt = thaw(event.payload)
        problem = invariant_problem(nxt)
        if problem:
            raise RuntimeError(problem)
        return ApplyOutcome.new(nxt)

    def _add_item(self, state, command, observation):
        del observation
        item_id = command.get("item_id")
        if not valid_id(item_id):
            return refuse("bad_args")
        if item_id in state["ids"]:
            return refuse("id_in_use")
        nxt = copy_state(state)
        nxt["ids"][item_id] = "item"
        nxt["items"][item_id] = blank_item()
        return nxt

    def _make_promotion(self, state, item_id, now, source_loan_id=None):
        nxt = copy_state(state)
        item = nxt["items"][item_id]
        old_id = item["reservation_id"]
        if old_id is not None:
            nxt["reservations"].setdefault(old_id, {"item_id": item_id, "state": "active"})
            nxt["reservations"][old_id]["state"] = "expired"
        waiter = item["waitlist"].pop(0)
        wait_id = waiter["wait_id"]
        nxt["ids"][wait_id] = "reservation"
        nxt["reservations"][wait_id] = {"item_id": item_id, "state": "active"}
        item["availability"] = "reserved"
        item["reservation_id"] = wait_id
        item["borrower_id"] = waiter["borrower_id"]
        item["address"] = waiter["address"]
        item["collect_by"] = now + waiter["hold_seconds"]
        item["reservation_state"] = "active"
        promotion = {
            "item_id": item_id,
            "wait_id": wait_id,
            "request_id": wait_id,
            "borrower_id": waiter["borrower_id"],
            "address": waiter["address"],
            "kind": "waitlist_ready",
            "notify": "attempt_saved",
            "source_loan_id": source_loan_id,
        }
        nxt["promotions"][wait_id] = promotion
        item["promotion"] = {
            "request_id": wait_id,
            "notify": "attempt_saved",
            "wait_id": wait_id,
            "source_loan_id": source_loan_id,
        }
        return nxt

    def _expire_if_due(self, state, command, observation):
        del observation
        item_id = command.get("item_id")
        now = command.get("now")
        if not valid_id(item_id) or not _is_int(now) or now < 0:
            return refuse("bad_args")
        item = state["items"].get(item_id)
        if item is None:
            return refuse("unknown_item")
        if item.get("promotion", {}).get("notify") == "attempt_saved":
            return None
        if (
            item["availability"] == "reserved"
            and item["reservation_state"] == "active"
            and now >= item["collect_by"]
        ):
            if item.get("waitlist"):
                return self._make_promotion(state, item_id, now)
            nxt = copy_state(state)
            expired = nxt["items"][item_id]
            old_id = expired["reservation_id"]
            if old_id is not None:
                nxt["reservations"].setdefault(old_id, {"item_id": item_id, "state": "active"})
                nxt["reservations"][old_id]["state"] = "expired"
            expired["availability"] = "available"
            expired["reservation_state"] = "expired"
            return nxt
        return None

    def _reserve(self, state, command, observation):
        del observation
        item_id = command.get("item_id")
        reservation_id = command.get("reservation_id")
        borrower_id = command.get("borrower_id")
        address = command.get("address")
        collect_by = command.get("collect_by")
        now = command.get("now")
        if (
            not valid_id(item_id)
            or not valid_id(reservation_id)
            or not valid_id(borrower_id)
            or not valid_address(address)
            or not _is_int(collect_by)
            or not _is_int(now)
            or collect_by <= now
            or now < 0
            or now > 9999999999
        ):
            return refuse("bad_args")
        item = state["items"].get(item_id)
        if item is None:
            return refuse("unknown_item")
        if reservation_id in state["ids"]:
            return refuse("id_in_use")
        if item["availability"] != "available":
            return refuse("not_available")
        nxt = copy_state(state)
        nxt["ids"][reservation_id] = "reservation"
        nxt["reservations"][reservation_id] = {"item_id": item_id, "state": "active"}
        reserved = nxt["items"][item_id]
        reserved["availability"] = "reserved"
        reserved["reservation_id"] = reservation_id
        reserved["borrower_id"] = borrower_id
        reserved["address"] = address
        reserved["collect_by"] = collect_by
        reserved["reservation_state"] = "active"
        return nxt

    def _wait(self, state, command, observation):
        del observation
        item_id = command.get("item_id")
        wait_id = command.get("wait_id")
        borrower_id = command.get("borrower_id")
        address = command.get("address")
        hold_seconds = command.get("hold_seconds")
        if (
            not valid_id(item_id)
            or not valid_id(wait_id)
            or not valid_id(borrower_id)
            or not valid_address(address)
            or not _is_int(hold_seconds)
            or hold_seconds < 1
            or hold_seconds > 2592000
        ):
            return refuse("bad_args")
        item = state["items"].get(item_id)
        if item is None:
            return refuse("unknown_item")
        if wait_id in state["ids"]:
            return refuse("id_in_use")
        if item["availability"] == "available":
            return refuse("not_needed")
        if item["borrower_id"] == borrower_id or any(
            waiter["borrower_id"] == borrower_id for waiter in item.get("waitlist", [])
        ):
            return refuse("already_waiting")
        nxt = copy_state(state)
        nxt["ids"][wait_id] = "wait"
        nxt["items"][item_id]["waitlist"].append({
            "wait_id": wait_id,
            "borrower_id": borrower_id,
            "address": address,
            "hold_seconds": hold_seconds,
        })
        return nxt

    def _save_attempt(self, state, command, observation):
        del observation
        item_id = command.get("item_id")
        reservation_id = command.get("reservation_id")
        loan_id = command.get("loan_id")
        now = command.get("now")
        if (
            not valid_id(item_id)
            or not valid_id(reservation_id)
            or not valid_id(loan_id)
            or not _is_int(now)
            or now < 0
            or now > 9999999999
        ):
            return refuse("bad_args")
        item = state["items"].get(item_id)
        if item is None:
            return refuse("unknown_item")
        if item["availability"] == "checked_out" or item["loan_state"] == "checked_out":
            return refuse("already_checked_out")
        reservation_record = state.get("reservations", {}).get(reservation_id)
        if reservation_record is not None and reservation_record.get("state") == "expired":
            return refuse("expired")
        if item["reservation_state"] == "expired" and item["reservation_id"] == reservation_id:
            return refuse("expired")
        if item["availability"] != "reserved" or item["reservation_state"] != "active":
            return refuse("not_reserved")
        if item["reservation_id"] != reservation_id:
            return refuse("reservation_mismatch")
        if now >= item["collect_by"]:
            return refuse("expired")
        if item["loan_state"] == "attempt_saved" and item["loan_id"] != loan_id:
            return refuse("checkout_in_progress")
        if loan_id in state["ids"] and not (
            item["loan_state"] == "attempt_saved" and item["loan_id"] == loan_id
        ):
            return refuse("id_in_use")
        if (
            item["loan_state"] == "attempt_saved"
            and item["loan_id"] == loan_id
            and item["reservation_id"] == reservation_id
        ):
            return None
        nxt = copy_state(state)
        nxt["ids"][loan_id] = "loan"
        current = nxt["items"][item_id]
        current["loan_id"] = loan_id
        current["loan_state"] = "attempt_saved"
        current["notify"] = "attempt_saved"
        nxt["loans"][loan_id] = {
            "item_id": item_id,
            "reservation_id": reservation_id,
            "borrower_id": current["borrower_id"],
            "address": current["address"],
            "loan_state": "attempt_saved",
            "notify": "attempt_saved",
        }
        return nxt

    def _mark_sent(self, state, command, observation):
        loan_id = command.get("loan_id")
        if not valid_id(loan_id):
            return refuse("bad_args")
        loan = state["loans"].get(loan_id)
        if loan is None:
            return refuse("unknown_item")
        if loan["notify"] == "sent":
            return None
        if loan["loan_state"] != "attempt_saved" or loan["notify"] != "attempt_saved":
            return refuse("conflict")
        if not isinstance(observation, dict) or not _service_matches(observation, loan, loan_id):
            return refuse("conflict")
        nxt = copy_state(state)
        recorded = nxt["loans"][loan_id]
        recorded["loan_state"] = "checked_out"
        recorded["notify"] = "sent"
        item = nxt["items"][recorded["item_id"]]
        if item.get("loan_id") != loan_id:
            raise RuntimeError("attempt is not the item's current loan")
        item["loan_state"] = "checked_out"
        item["notify"] = "sent"
        item["availability"] = "checked_out"
        item["reservation_state"] = "collected"
        return nxt
    def _mark_promotion_sent(self, state, command, observation):
        wait_id = command.get("wait_id")
        if not valid_id(wait_id):
            return refuse("bad_args")
        promotion = state.get("promotions", {}).get(wait_id)
        if promotion is None:
            return refuse("unknown_item")
        if promotion["notify"] == "sent":
            return None
        if promotion["notify"] != "attempt_saved":
            return refuse("conflict")
        if not isinstance(observation, dict) or not _promotion_matches(observation, promotion):
            return refuse("conflict")
        nxt = copy_state(state)
        nxt["promotions"][wait_id]["notify"] = "sent"
        item = nxt["items"][promotion["item_id"]]
        if item["promotion"].get("wait_id") == wait_id:
            item["promotion"]["notify"] = "sent"
        return nxt


    def _return_item(self, state, command, observation):
        del observation
        item_id = command.get("item_id")
        loan_id = command.get("loan_id")
        now = command.get("now")
        if (
            not valid_id(item_id)
            or not valid_id(loan_id)
            or not _is_int(now)
            or now < 0
            or now > 9999999999
        ):
            return refuse("bad_args")
        item = state["items"].get(item_id)
        if item is None:
            return refuse("unknown_item")
        promotion = item.get("promotion", {})
        if (
            item["loan_state"] == "returned"
            and promotion.get("source_loan_id") == loan_id
            and promotion.get("notify") == "attempt_saved"
        ):
            return None
        if item["availability"] != "checked_out":
            return refuse("not_checked_out")
        if item["loan_id"] != loan_id:
            return refuse("loan_mismatch")
        nxt = copy_state(state)
        returned = nxt["items"][item_id]
        returned["availability"] = "available"
        returned["loan_state"] = "returned"
        recorded = nxt["loans"][loan_id]
        recorded["loan_state"] = "returned"
        recorded["notify"] = "sent"
        if returned["waitlist"]:
            return self._make_promotion(nxt, item_id, now, source_loan_id=loan_id)
        return nxt


def invariant_problem(state: Mapping[str, Any]) -> Optional[str]:
    keys = set(state)
    if keys not in (
        {"items", "ids", "loans"},
        {"items", "ids", "loans", "reservations", "promotions"},
    ):
        return "state keys"
    ids = state["ids"]
    items = state["items"]
    loans = state["loans"]
    reservations = state.get("reservations", {})
    promotions = state.get("promotions", {})
    if not all(isinstance(value, dict) for value in (ids, items, loans, reservations, promotions)):
        return "state types"
    for item_id, raw_item in items.items():
        item = _normalize_item(raw_item)
        if ids.get(item_id) != "item":
            return "item id missing from namespace"
        if item["availability"] not in {"available", "reserved", "checked_out"}:
            return "availability"
        if item["reservation_state"] not in {"none", "active", "expired", "collected"}:
            return "reservation_state"
        if item["loan_state"] not in {"none", "attempt_saved", "checked_out", "returned"}:
            return "loan_state"
        if item["notify"] not in {"none", "attempt_saved", "sent"}:
            return "notify"
        if item["availability"] == "reserved" and item["reservation_state"] != "active":
            return "reserved without active reservation"
        if item["reservation_state"] == "active" and item["availability"] != "reserved":
            return "active reservation not reserved"
        if item["availability"] == "checked_out" and not (
            item["loan_state"] == "checked_out"
            and item["notify"] == "sent"
            and item["reservation_state"] == "collected"
        ):
            return "checked_out shape"
        if item["loan_state"] == "none" and (item["loan_id"] is not None or item["notify"] != "none"):
            return "empty loan"
        if item["loan_id"] is None and item["loan_state"] != "none":
            return "loan id missing"
        if item["reservation_state"] == "none" and item["reservation_id"] is not None:
            return "reservation id"
        if item["reservation_id"] is not None and ids.get(item["reservation_id"]) != "reservation":
            return "reservation namespace"
        if item["loan_id"] is not None:
            if ids.get(item["loan_id"]) != "loan":
                return "loan namespace"
            loan = loans.get(item["loan_id"])
            if loan is None or loan["item_id"] != item_id:
                return "loan index"
            if loan["loan_state"] != item["loan_state"] or loan["notify"] != item["notify"]:
                return "loan mirror"
            if (
                loan["loan_state"] != "returned"
                and (
                    loan["borrower_id"] != item["borrower_id"]
                    or loan["address"] != item["address"]
                )
            ):
                return "loan identity"
        if item["loan_state"] == "attempt_saved" and item["notify"] != "attempt_saved":
            return "attempt notify"
        if item["loan_state"] in {"checked_out", "returned"} and item["notify"] != "sent":
            return "sent notify"
        if item["loan_state"] == "returned" and item["availability"] == "checked_out":
            return "returned still out"
        if item["promotion"].get("notify") not in {"none", "attempt_saved", "sent"}:
            return "promotion notify"
        for waiter in item["waitlist"]:
            if ids.get(waiter.get("wait_id")) != "wait":
                return "wait namespace"
    for reservation_id, reservation in reservations.items():
        if ids.get(reservation_id) != "reservation":
            return "reservation index"
        if reservation.get("state") not in {"active", "expired"}:
            return "reservation state"
    for loan_id, loan in loans.items():
        if ids.get(loan_id) != "loan":
            return "orphan loan id"
        if loan["item_id"] not in items:
            return "loan item"
    for wait_id, promotion in promotions.items():
        if promotion.get("wait_id") != wait_id or promotion.get("kind") != "waitlist_ready":
            return "promotion index"
        if promotion.get("notify") not in {"attempt_saved", "sent"}:
            return "promotion state"
    return None
