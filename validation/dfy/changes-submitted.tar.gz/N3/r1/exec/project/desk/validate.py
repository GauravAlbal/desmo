"""Argument shapes from the desk brief. Not a lifecycle authority."""

from __future__ import annotations

import re

ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
ADDR_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$")
TIME_RE = re.compile(r"^(0|[1-9][0-9]*)$")
NOW_MAX = 9999999999
INT_MAX = 2**63 - 1

ERROR_CODES = frozenset({
    "bad_args",
    "unknown_item",
    "id_in_use",
    "not_available",
    "not_reserved",
    "reservation_mismatch",
    "expired",
    "already_checked_out",
    "checkout_in_progress",
    "not_checked_out",
    "loan_mismatch",
    "service_unavailable",
    "conflict",
    "not_needed",
    "already_waiting",
})


def valid_id(value) -> bool:
    return isinstance(value, str) and ID_RE.fullmatch(value) is not None


def valid_address(value) -> bool:
    return isinstance(value, str) and ADDR_RE.fullmatch(value) is not None


def parse_time(text: str, *, bound_now: bool) -> int | None:
    if not isinstance(text, str) or TIME_RE.fullmatch(text) is None:
        return None
    value = int(text)
    if value > INT_MAX:
        return None
    if bound_now and value > NOW_MAX:
        return None
    return value
