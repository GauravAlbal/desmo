import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const node = process.env.NODE || process.execPath;
const provider = { service_url: "", control_url: "" };

function run(args, env, { allowSignal = false } = {}) {
  const { promise, resolve, reject } = Promise.withResolvers();
  const child = spawn(path.join(root, "run"), args, {
    cwd: root,
    env: { ...process.env, NODE: node, ...env },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const out = [];
  const err = [];
  child.stdout.on("data", (chunk) => out.push(chunk));
  child.stderr.on("data", (chunk) => err.push(chunk));
  child.on("error", reject);
  child.on("close", (code, signal) => {
    const stdout = Buffer.concat(out).toString("utf8");
    const stderr = Buffer.concat(err).toString("utf8");
    if (signal) {
      if (!allowSignal) return reject(new Error(`signal ${signal}\n${stderr}\n${stdout}`));
      return resolve({ code, signal, stdout, stderr, json: null });
    }
    const lines = stdout.split("\n").filter(Boolean);
    let json = null;
    if (lines.length === 1) {
      try { json = JSON.parse(lines[0]); } catch { /* asserted by callers */ }
    }
    resolve({ code, signal, stdout, stderr, json, lines });
  });
  return promise;
}

async function control(pathname, body) {
  const response = await fetch(provider.control_url + pathname, body
    ? { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }
    : undefined);
  return response.json();
}

function deskEnv(extra = {}) {
  const stateDir = mkdtempSync(path.join(tmpdir(), "line-desk-"));
  return { STATE_DIR: stateDir, SERVICE_URL: provider.service_url, ...extra };
}

function linesFile(env, name, value) {
  const file = path.join(env.STATE_DIR, name + ".json");
  writeFileSync(file, JSON.stringify(value));
  return file;
}

async function recordAndAttach(env, orderId, capCents, lines) {
  const amount = lines.reduce((sum, line) => sum + line.price_cents, 0);
  assert.equal((await run(["record", orderId, String(amount)], env)).code, 0);
  const file = linesFile(env, orderId, { cap_cents: capCents, lines });
  const attached = await run(["attach", orderId, file], env);
  assert.equal(attached.code, 0, attached.stderr);
  return file;
}

test.before(async () => {
  const child = spawn(node, [path.join(root, "tests/provider.mjs")], {
    env: { ...process.env, PORT: "46502", CONTROL_PORT: "46503" },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const { promise, resolve, reject } = Promise.withResolvers();
  let output = "";
  const timer = setTimeout(() => reject(new Error("provider did not start")), 5000);
  child.stdout.on("data", (chunk) => {
    output += chunk.toString("utf8");
    const newline = output.indexOf("\n");
    if (newline >= 0) {
      clearTimeout(timer);
      resolve(output.slice(0, newline));
    }
  });
  child.on("exit", (code) => reject(new Error("provider exited " + code)));
  Object.assign(provider, JSON.parse(await promise));
  provider.child = child;
});

test.after(() => {
  provider.child?.kill("SIGTERM");
});

test("attach persists an immutable validated line snapshot", async () => {
  const env = deskEnv();
  await run(["record", "attach-1", "8000"], env);
  const original = {
    cap_cents: 4000,
    lines: [
      { line_id: "sku-a", price_cents: 3000 },
      { line_id: "sku-b", price_cents: 5000 },
    ],
  };
  const file = linesFile(env, "original", original);
  const before = await control("/traffic");
  const attached = await run(["attach", "attach-1", file], env);
  assert.equal(attached.code, 0, attached.stderr);
  assert.deepEqual(attached.json, {
    order_id: "attach-1",
    cap_cents: 4000,
    lines: [
      { line_id: "sku-a", price_cents: 3000, refund: "none" },
      { line_id: "sku-b", price_cents: 5000, refund: "none" },
    ],
  });
  writeFileSync(file, JSON.stringify({ cap_cents: 1, lines: [] }));
  const status = await run(["status", "attach-1"], env);
  assert.equal(status.json.cap_cents, 4000);
  assert.deepEqual(status.json.lines, attached.json.lines);
  const same = linesFile(env, "same-reordered", {
    cap_cents: 4000,
    lines: [original.lines[1], original.lines[0]],
  });
  assert.equal((await run(["attach", "attach-1", same], env)).code, 0);
  const different = linesFile(env, "different", { ...original, cap_cents: 3999 });
  assert.equal((await run(["attach", "attach-1", different], env)).json.error, "conflict");
  const after = await control("/traffic");
  assert.equal(after.requests.length, before.requests.length);
});

test("line refund enforces cap and an adopted line cannot be refunded twice", async () => {
  const env = deskEnv();
  await recordAndAttach(env, "cap-1", 4000, [
    { line_id: "fits", price_cents: 3000 },
    { line_id: "too-big", price_cents: 5000 },
  ]);
  const before = await control("/effects");
  assert.equal((await run(["refund", "cap-1", "too-big"], env)).json.error, "over_cap");
  assert.equal((await control("/effects")).count, before.count);
  const refunded = await run(["refund", "cap-1", "fits"], env);
  assert.equal(refunded.code, 0, refunded.stderr);
  assert.equal(refunded.json.refunded_cents, 3000);
  const status = await run(["status", "cap-1"], env);
  assert.equal(status.json.lines[0].refund, "refunded");
  const effects = await control("/effects");
  assert.equal(effects.count, before.count + 1);
  assert.equal(effects.effects.at(-1).amount_cents, 3000);
  assert.equal((await run(["refund", "cap-1", "fits"], env)).json.error, "already_refunded");
  assert.equal((await control("/effects")).count, effects.count);
});

test("an open line attempt blocks another selection and is reused", async () => {
  const env = deskEnv({ CRASH_AT: "after-attempt-saved-before-request" });
  await recordAndAttach(env, "open-1", 500, [
    { line_id: "a", price_cents: 200 },
    { line_id: "b", price_cents: 300 },
  ]);
  const before = await control("/effects");
  const killed = await run(["refund", "open-1", "a"], env, { allowSignal: true });
  assert.equal(killed.signal, "SIGKILL");
  const status = await run(["status", "open-1"], { ...env, CRASH_AT: "" });
  assert.equal(status.json.refund, "attempt_saved");
  assert.equal(status.json.lines[0].refund, "pending");
  const blocked = await run(["refund", "open-1", "b"], { ...env, CRASH_AT: "" });
  assert.equal(blocked.json.error, "refund_open");
  assert.equal((await control("/effects")).count, before.count);
  const completed = await run(["refund", "open-1", "a"], { ...env, CRASH_AT: "" });
  assert.equal(completed.code, 0, completed.stderr);
  assert.equal(completed.json.refund_id, status.json.refund_id);
  assert.equal((await control("/effects")).count, before.count + 1);
});

test("a lost line-refund reply is reconciled before cap is reused", async () => {
  const env = deskEnv();
  await recordAndAttach(env, "lost-line", 400, [
    { line_id: "a", price_cents: 300 },
    { line_id: "b", price_cents: 200 },
  ]);
  await control("/fault", { drop_reply: true, status_5xx: false });
  const before = await control("/effects");
  assert.equal((await run(["refund", "lost-line", "a"], env)).json.error, "unavailable");
  assert.equal((await run(["refund", "lost-line", "b"], env)).json.error, "refund_open");
  const accepted = await control("/effects");
  assert.equal(accepted.count, before.count + 1);
  await control("/fault", { drop_reply: false });
  const reconciled = await run(["reconcile", "lost-line"], env);
  assert.equal(reconciled.code, 0, reconciled.stderr);
  assert.equal(reconciled.json.refunded_cents, 300);
  assert.equal((await run(["refund", "lost-line", "b"], env)).json.error, "over_cap");
  assert.equal((await control("/effects")).count, accepted.count);
});

test("shipment blocks line refunds and any adopted line blocks shipment", async () => {
  const shippedEnv = deskEnv();
  await recordAndAttach(shippedEnv, "shipped-line", 500, [{ line_id: "a", price_cents: 500 }]);
  assert.equal((await run(["ship", "shipped-line"], shippedEnv)).code, 0);
  const before = await control("/effects");
  assert.equal((await run(["refund", "shipped-line", "a"], shippedEnv)).json.error, "shipped");
  assert.equal((await control("/effects")).count, before.count);

  const refundedEnv = deskEnv();
  await recordAndAttach(refundedEnv, "refunded-line", 500, [{ line_id: "a", price_cents: 500 }]);
  assert.equal((await run(["refund", "refunded-line", "a"], refundedEnv)).code, 0);
  const ship = await run(["ship", "refunded-line"], refundedEnv);
  assert.equal(ship.json.error, "refund_open");
  assert.equal((await run(["status", "refunded-line"], refundedEnv)).json.shipment, "open");
});

test("cancel refunds exactly the fitting remainder or refuses the whole remainder", async () => {
  const fitting = deskEnv();
  await recordAndAttach(fitting, "remainder-fit", 1000, [
    { line_id: "a", price_cents: 400 },
    { line_id: "b", price_cents: 600 },
  ]);
  const before = await control("/effects");
  assert.equal((await run(["refund", "remainder-fit", "a"], fitting)).code, 0);
  const cancelled = await run(["cancel", "remainder-fit"], fitting);
  assert.equal(cancelled.code, 0, cancelled.stderr);
  assert.equal(cancelled.json.refunded_cents, 1000);
  const effects = await control("/effects");
  assert.deepEqual(effects.effects.slice(-2).map((effect) => effect.amount_cents), [400, 600]);
  assert.equal((await run(["cancel", "remainder-fit"], fitting)).code, 0);
  assert.equal((await control("/effects")).count, effects.count);

  const capped = deskEnv();
  await recordAndAttach(capped, "remainder-cap", 700, [
    { line_id: "a", price_cents: 400 },
    { line_id: "b", price_cents: 600 },
  ]);
  assert.equal((await run(["refund", "remainder-cap", "a"], capped)).code, 0);
  const capBefore = await control("/effects");
  assert.equal((await run(["cancel", "remainder-cap"], capped)).json.error, "over_cap");
  const status = await run(["status", "remainder-cap"], capped);
  assert.equal(status.json.lines[1].refund, "none");
  assert.equal((await control("/effects")).count, capBefore.count);
  assert.ok(effects.count >= before.count + 2);
});
