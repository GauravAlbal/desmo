import { createHash, randomBytes } from "node:crypto";
import { closeSync, existsSync, fsyncSync, mkdirSync, openSync, readFileSync, writeSync } from "node:fs";
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  Aggregate, Capability, HistoricalResult, Kernel, KernelError, Machine,
  StoreNotFoundError, classify,
  type EffectIntent, type Json,
} from "@ikaros/runtime";

const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const LINE_ID_RE = /^[A-Za-z0-9._-]{1,32}$/;
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const MACHINE_PATH = path.join(ROOT, "machines", "paid_order.ik.toml");

type RefundState = "none" | "attempt_saved" | "refunded";
type Shipment = "open" | "shipped";
type LineRefundState = "none" | "pending" | "refunded";
interface LineView { line_id: string; price_cents: number; refund: LineRefundState }
interface OrderView {
  order_id: string; amount_cents: number; currency: "USD"; shipment: Shipment;
  refund: RefundState; refund_id: string | null; refunded_cents: number;
  cap_cents: number; lines: LineView[];
}
interface OrderData extends OrderView { attempt_cents: number; attempt_line_ids: string[] }
interface OriginalOrderView {
  order_id: string; amount_cents: number; currency: "USD"; shipment: Shipment;
  refund: RefundState; refund_id: string | null; refunded_cents: number;
}
interface LinesAttachment { cap_cents: number; lines: Array<{ line_id: string; price_cents: number }> }
interface Acceptance {
  refund_id: string; order_id: string; amount_cents: number; currency: "USD"; outcome: "refunded";
}
type HttpResult = { kind: "ok"; status: number; text: string } | { kind: "down" };

function finish(code: number, body: unknown): never {
  writeSync(1, JSON.stringify(body) + "\n");
  process.exit(code);
}
function ok(body: unknown): never { finish(0, body); }
function refuse(code: string): never { finish(1, { error: code }); }
function validId(value: string | undefined): value is string {
  return typeof value === "string" && ID_RE.test(value);
}
function validAmount(value: string | undefined): number | null {
  if (typeof value !== "string" || !/^[1-9][0-9]*$/.test(value) || value.length > 9) return null;
  const amount = Number(value);
  return Number.isSafeInteger(amount) && amount >= 1 && amount <= 100000000 ? amount : null;
}
function requireStateDir(): string {
  const dir = process.env.STATE_DIR;
  if (!dir) refuse("bad_args");
  return dir;
}
function serviceBase(): string {
  const raw = process.env.SERVICE_URL;
  if (!raw || !/^https?:\/\//.test(raw)) refuse("unavailable");
  return raw.replace(/\/$/, "");
}
function storePath(stateDir: string): string { return path.join(stateDir, "paid-order.sqlite"); }
function flushStore(stateDir: string): void {
  const base = storePath(stateDir);
  for (const suffix of ["", "-wal", "-shm"]) {
    const file = base + suffix;
    if (!existsSync(file)) continue;
    const fd = openSync(file, "r+");
    try { fsyncSync(fd); } finally { closeSync(fd); }
  }
}
function crashIf(boundary: string, stateDir: string): void {
  if (process.env.CRASH_AT !== boundary) return;
  flushStore(stateDir);
  process.kill(process.pid, "SIGKILL");
}
function digestOf(value: Record<string, Json>): string {
  const sorted: Record<string, Json> = {};
  for (const key of Object.keys(value).sort()) sorted[key] = value[key];
  return createHash("sha256").update(JSON.stringify(sorted)).digest("hex");
}
function newRefundId(): string { return "rf." + randomBytes(16).toString("hex"); }
function asRecord(value: Json | undefined): Record<string, Json> | null {
  return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}
function parseStoredLines(value: Json | undefined): LineView[] {
  if (value === undefined) return [];
  if (typeof value !== "string") refuse("unavailable");
  let parsed: unknown;
  try { parsed = JSON.parse(value); } catch { refuse("unavailable"); }
  if (!Array.isArray(parsed)) refuse("unavailable");
  const lines: LineView[] = [];
  for (const item of parsed) {
    if (!item || typeof item !== "object" || Array.isArray(item)) refuse("unavailable");
    const row = item as Record<string, unknown>;
    const lineId = typeof row.line_id === "string" ? row.line_id : "";
    if (!LINE_ID_RE.test(lineId) || !Number.isInteger(row.price_cents)) refuse("unavailable");
    if (row.refund !== "none" && row.refund !== "pending" && row.refund !== "refunded") refuse("unavailable");
    lines.push({ line_id: lineId, price_cents: Number(row.price_cents), refund: row.refund });
  }
  return lines;
}
function parseStoredSelection(value: Json | undefined): string[] {
  if (value === undefined) return [];
  if (typeof value !== "string") refuse("unavailable");
  let parsed: unknown;
  try { parsed = JSON.parse(value); } catch { refuse("unavailable"); }
  if (!Array.isArray(parsed) || parsed.some((item) => typeof item !== "string" || !LINE_ID_RE.test(item))) refuse("unavailable");
  return parsed as string[];
}
function viewOf(orderId: string, state: Json): OrderData {
  const record = asRecord(state);
  if (!record) refuse("unavailable");
  const named = String(record.state);
  const amount = Number(record.amount_cents);
  const refunded = Number(record.refunded_cents ?? 0);
  const cap = record.cap_cents === undefined ? amount : Number(record.cap_cents);
  const attemptCents = Number(record.attempt_cents ?? (named === "refund_planned" ? amount : 0));
  if (![amount, refunded, cap, attemptCents].every(Number.isInteger)) refuse("unavailable");
  let shipment: Shipment = "open";
  let refund: RefundState = "none";
  if (named === "shipped") shipment = "shipped";
  else if (named === "refund_planned") refund = "attempt_saved";
  else if (named === "refunded") refund = "refunded";
  else if (named !== "open") refuse("unavailable");
  const rawRefundId = typeof record.refund_id === "string" ? record.refund_id : null;
  return {
    order_id: orderId, amount_cents: amount, currency: "USD", shipment, refund,
    refund_id: refund === "none" ? null : rawRefundId, refunded_cents: refunded,
    cap_cents: cap, lines: parseStoredLines(record.lines_json), attempt_cents: attemptCents,
    attempt_line_ids: parseStoredSelection(record.attempt_lines_json),
  };
}
function publicView(data: OrderData): OrderView {
  return {
    order_id: data.order_id, amount_cents: data.amount_cents, currency: data.currency,
    shipment: data.shipment, refund: data.refund, refund_id: data.refund_id,
    refunded_cents: data.refunded_cents, cap_cents: data.cap_cents, lines: data.lines,
  };
}
function originalView(data: OrderData): OriginalOrderView {
  return {
    order_id: data.order_id, amount_cents: data.amount_cents, currency: data.currency,
    shipment: data.shipment, refund: data.refund, refund_id: data.refund_id,
    refunded_cents: data.refunded_cents,
  };
}
function missingAggregate(err: unknown): boolean {
  if (err instanceof StoreNotFoundError) return true;
  return err instanceof KernelError &&
    (err.rule === "aggregate.not_found" || err.rule === "store.missing" || classify(err) === "not_found");
}
async function openMachine(stateDir: string): Promise<{ kernel: Kernel; machine: Machine }> {
  mkdirSync(stateDir, { recursive: true });
  const kernel = new Kernel(storePath(stateDir));
  return { kernel, machine: await kernel.machine(MACHINE_PATH) };
}
async function load(machine: Machine, orderId: string): Promise<Aggregate | null> {
  try { return await machine.show(orderId); }
  catch (err) { if (missingAggregate(err)) return null; throw err; }
}
function commandBody(name: string, args?: Record<string, Json>): Record<string, Json> {
  return args && Object.keys(args).length > 0 ? { name, args } : { name };
}
async function applyCommand(agg: Aggregate, name: string, args?: Record<string, Json>): Promise<Aggregate> {
  const operationId = agg.machine.kernel.newOperationId();
  const wire = agg.capability.toWire();
  const command = commandBody(name, args);
  try {
    const settled = await agg.execute(command, { operationId });
    return settled instanceof HistoricalResult ? await agg.machine.show(agg.id) : settled;
  } catch (err) {
    if (!(err instanceof KernelError) || err.outcome !== "submission-unknown") throw err;
    const found = await agg.machine.lookupOperation(agg.id, Capability.fromWire(wire), operationId, { command });
    if (found.outcome === "committed_exact") return agg.machine.show(agg.id);
    throw err;
  }
}
function effectBody(intent: EffectIntent, outcomeDigest: string): Record<string, Json> {
  return {
    effect_id: intent.effectId, aggregate_id: intent.aggregateId,
    planned_generation: typeof intent.generation === "bigint" ? Number(intent.generation) : intent.generation,
    payload_digest: intent.payloadDigest, idempotency_key: intent.idempotencyKey, outcome_digest: outcomeDigest,
  };
}
async function bindOutcome(agg: Aggregate, outcomeDigest: string): Promise<Aggregate> {
  const intent = agg.pendingIntent;
  if (!intent) return agg;
  const operationId = agg.machine.kernel.newOperationId();
  const wire = agg.capability.toWire();
  const effect = effectBody(intent, outcomeDigest);
  try {
    const settled = await agg.recordEffectOutcome(outcomeDigest, { operationId, intent });
    return settled instanceof HistoricalResult ? await agg.machine.show(agg.id) : settled;
  } catch (err) {
    const shown = await agg.machine.show(agg.id);
    if (shown.effect.status === "recorded") return shown;
    if (err instanceof KernelError && err.outcome === "submission-unknown") {
      const found = await agg.machine.lookupOperation(agg.id, Capability.fromWire(wire), operationId, { effect });
      if (found.outcome === "committed_exact") return agg.machine.show(agg.id);
    }
    throw err;
  }
}
async function commitRefunded(agg: Aggregate, acceptance: Acceptance, stateDir: string): Promise<{ view: OrderView; committedNow: boolean }> {
  if (agg.namedState() !== "refund_planned") return { view: publicView(viewOf(agg.id, agg.state)), committedNow: false };
  const before = viewOf(agg.id, agg.state);
  const selected = new Set(before.attempt_line_ids);
  const completedLines = before.lines.map((line) => selected.has(line.line_id) ? { ...line, refund: "refunded" as const } : line);
  const outcomeDigest = digestOf({
    amount_cents: acceptance.amount_cents, currency: acceptance.currency, order_id: acceptance.order_id,
    outcome: acceptance.outcome, refund_id: acceptance.refund_id,
  });
  let current = agg;
  if (current.effect.status === "pending") current = await bindOutcome(current, outcomeDigest);
  if (current.namedState() !== "refund_planned") return { view: publicView(viewOf(current.id, current.state)), committedNow: false };
  const noted = await applyCommand(current, "note_refunded", {
    refunded_cents: before.refunded_cents + acceptance.amount_cents,
    lines_json: JSON.stringify(completedLines),
  });
  flushStore(stateDir);
  return { view: publicView(viewOf(noted.id, noted.state)), committedNow: true };
}
function httpCall(method: "GET" | "POST", url: string, body?: string): Promise<HttpResult> {
  const { promise, resolve } = Promise.withResolvers<HttpResult>();
  let settled = false;
  const done = (result: HttpResult): void => { if (!settled) { settled = true; resolve(result); } };
  let req: http.ClientRequest;
  try {
    const parsed = new URL(url);
    req = http.request({
      protocol: parsed.protocol, hostname: parsed.hostname, port: parsed.port,
      path: parsed.pathname + parsed.search, method,
      headers: body ? { "content-type": "application/json", "content-length": Buffer.byteLength(body) } : { accept: "application/json" },
    }, (res) => {
      const chunks: Buffer[] = [];
      res.on("data", (chunk: Buffer) => chunks.push(chunk));
      res.on("end", () => done({ kind: "ok", status: res.statusCode ?? 0, text: Buffer.concat(chunks).toString("utf8") }));
      res.on("error", () => done({ kind: "down" }));
      res.on("aborted", () => done({ kind: "down" }));
    });
  } catch { done({ kind: "down" }); return promise; }
  req.on("error", () => done({ kind: "down" }));
  req.on("aborted", () => done({ kind: "down" }));
  if (body) req.write(body);
  req.end();
  return promise;
}
function readAcceptance(saved: { refund_id: string; order_id: string; amount_cents: number }, text: string): Acceptance | "mismatch" | "bad" {
  let parsed: unknown;
  try { parsed = JSON.parse(text); } catch { return "bad"; }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return "bad";
  const body = parsed as Record<string, unknown>;
  if (body.outcome !== "refunded" || body.currency !== "USD") return "mismatch";
  if (body.refund_id !== saved.refund_id || body.order_id !== saved.order_id || body.amount_cents !== saved.amount_cents) return "mismatch";
  return { ...saved, currency: "USD", outcome: "refunded" };
}
async function lookupRefund(saved: { refund_id: string; order_id: string; amount_cents: number }): Promise<"missing" | "mismatch" | "unavailable" | Acceptance> {
  const result = await httpCall("GET", serviceBase() + "/v1/refunds/" + saved.refund_id);
  if (result.kind === "down") return "unavailable";
  if (result.status === 404) return "missing";
  if (result.status !== 200) return "unavailable";
  const acceptance = readAcceptance(saved, result.text);
  return acceptance === "bad" ? "unavailable" : acceptance;
}
async function postRefund(saved: { refund_id: string; order_id: string; amount_cents: number }): Promise<Acceptance | "conflict" | "unavailable"> {
  const result = await httpCall("POST", serviceBase() + "/v1/refunds", JSON.stringify({ ...saved, currency: "USD" }));
  if (result.kind === "down" || result.status !== 200 && result.status !== 409) return "unavailable";
  if (result.status === 409) return "conflict";
  const acceptance = readAcceptance(saved, result.text);
  if (acceptance === "bad") return "unavailable";
  return acceptance === "mismatch" ? "conflict" : acceptance;
}
function parseAttachment(file: string, orderAmount: number): LinesAttachment | null {
  let value: unknown;
  try { value = JSON.parse(readFileSync(file, "utf8")); } catch { return null; }
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const body = value as Record<string, unknown>;
  const cap = Number(body.cap_cents);
  if (!Number.isInteger(body.cap_cents) || cap < 1 || cap > orderAmount || !Array.isArray(body.lines) || body.lines.length < 1 || body.lines.length > 20) return null;
  const ids = new Set<string>();
  const lines: LinesAttachment["lines"] = [];
  let total = 0;
  for (const item of body.lines) {
    if (!item || typeof item !== "object" || Array.isArray(item)) return null;
    const line = item as Record<string, unknown>;
    if (typeof line.line_id !== "string" || !LINE_ID_RE.test(line.line_id) || ids.has(line.line_id)) return null;
    const price = Number(line.price_cents);
    if (!Number.isInteger(line.price_cents) || price < 1 || price > 100000000) return null;
    ids.add(line.line_id); total += price;
    if (!Number.isSafeInteger(total)) return null;
    lines.push({ line_id: line.line_id, price_cents: price });
  }
  return total === orderAmount ? { cap_cents: cap, lines } : null;
}
function sameAttachment(current: OrderData, attachment: LinesAttachment): boolean {
  if (current.cap_cents !== attachment.cap_cents || current.lines.length !== attachment.lines.length) return false;
  const prices = new Map(current.lines.map((line) => [line.line_id, line.price_cents]));
  return attachment.lines.every((line) => prices.get(line.line_id) === line.price_cents);
}
function sameSet(left: string[], right: string[]): boolean {
  if (left.length !== right.length) return false;
  const values = new Set(left);
  return values.size === right.length && right.every((value) => values.has(value));
}
async function record(orderId: string, amount: number): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (existing) {
    const view = viewOf(orderId, existing.state);
    if (view.amount_cents !== amount) refuse("conflict");
    ok(originalView(view));
  }
  let created: Aggregate;
  try {
    const settled = await machine.createWith({ aggregateId: orderId, command: { name: "admit", args: { amount_cents: amount } } });
    if (settled instanceof HistoricalResult) {
      const shown = await load(machine, orderId);
      if (!shown) refuse("unavailable");
      created = shown;
    } else created = settled;
  } catch (err) {
    const again = await load(machine, orderId);
    if (again) {
      const view = viewOf(orderId, again.state);
      if (view.amount_cents !== amount) refuse("conflict");
      ok(originalView(view));
    }
    throw err;
  }
  flushStore(stateDir);
  ok(originalView(viewOf(orderId, created.state)));
}
async function attach(orderId: string, linesPath: string): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  const current = viewOf(orderId, existing.state);
  if (current.shipment === "shipped") refuse("shipped");
  if (current.refund !== "none" || current.refunded_cents > 0) refuse("refund_open");
  const attachment = parseAttachment(linesPath, current.amount_cents);
  if (!attachment) refuse("bad_lines");
  if (current.lines.length > 0) {
    if (!sameAttachment(current, attachment)) refuse("conflict");
    ok({ order_id: orderId, cap_cents: current.cap_cents, lines: current.lines });
  }
  const lines: LineView[] = attachment.lines.map((line) => ({ ...line, refund: "none" }));
  const attached = await applyCommand(existing, "attach_lines", { cap_cents: attachment.cap_cents, lines_json: JSON.stringify(lines) });
  flushStore(stateDir);
  const view = viewOf(orderId, attached.state);
  ok({ order_id: orderId, cap_cents: view.cap_cents, lines: view.lines });
}
async function ship(orderId: string): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  const view = viewOf(orderId, existing.state);
  if (view.refund !== "none" || view.refunded_cents > 0) refuse("refund_open");
  if (view.shipment === "shipped") ok(publicView(view));
  let shipped: Aggregate;
  try { shipped = await applyCommand(existing, "ship"); }
  catch (err) { if (err instanceof KernelError && err.code === "IK_ILLEGAL_STATE") refuse("refund_open"); throw err; }
  flushStore(stateDir);
  ok(publicView(viewOf(orderId, shipped.state)));
}
async function status(orderId: string): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  ok(publicView(viewOf(orderId, existing.state)));
}
async function ensureAttempt(agg: Aggregate, stateDir: string, amountCents: number, lineIds: string[]): Promise<{ agg: Aggregate; savedNow: boolean }> {
  if (agg.namedState() === "refund_planned") return { agg, savedNow: false };
  const view = viewOf(agg.id, agg.state);
  const refundId = newRefundId();
  const selected = new Set(lineIds);
  const lines = view.lines.map((line) => selected.has(line.line_id) ? { ...line, refund: "pending" as const } : line);
  const payloadDigest = digestOf({ amount_cents: amountCents, currency: "USD", line_ids: lineIds, order_id: view.order_id, refund_id: refundId });
  const planned = await applyCommand(agg, "begin_refund", {
    refund_id: refundId, effect_id: refundId, payload_digest: payloadDigest, idempotency_key: refundId,
    attempt_cents: amountCents, attempt_lines_json: JSON.stringify(lineIds), lines_json: JSON.stringify(lines),
  });
  flushStore(stateDir);
  return { agg: planned, savedNow: true };
}
async function finishAttempt(attempt: { agg: Aggregate; savedNow: boolean }, stateDir: string): Promise<never> {
  if (attempt.savedNow) crashIf("after-attempt-saved-before-request", stateDir);
  const saved = viewOf(attempt.agg.id, attempt.agg.state);
  if (!saved.refund_id || saved.attempt_cents < 1) refuse("unavailable");
  const target = { refund_id: saved.refund_id, order_id: saved.order_id, amount_cents: saved.attempt_cents };
  let acceptance: Acceptance | null = null;
  let acceptedByPost = false;
  if (!attempt.savedNow) {
    const looked = await lookupRefund(target);
    if (looked === "unavailable") refuse("unavailable");
    if (looked === "mismatch") refuse("conflict");
    if (looked !== "missing") acceptance = looked;
  }
  if (!acceptance) {
    const posted = await postRefund(target);
    if (posted === "unavailable") refuse("unavailable");
    if (posted === "conflict") refuse("conflict");
    acceptance = posted; acceptedByPost = true;
  }
  if (acceptedByPost) crashIf("after-accept-before-record", stateDir);
  const committed = await commitRefunded(attempt.agg, acceptance, stateDir);
  if (committed.committedNow) crashIf("after-record-before-exit", stateDir);
  ok(committed.view);
}
async function refund(orderId: string, lineIds: string[]): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  const current = viewOf(orderId, existing.state);
  if (current.lines.length === 0) refuse("not_attached");
  const seen = new Set<string>();
  const byId = new Map(current.lines.map((line) => [line.line_id, line]));
  const selected: LineView[] = [];
  for (const lineId of lineIds) {
    const line = byId.get(lineId);
    if (!LINE_ID_RE.test(lineId) || !line || seen.has(lineId)) refuse("unknown_line");
    seen.add(lineId); selected.push(line);
  }
  if (selected.some((line) => line.refund === "refunded")) refuse("already_refunded");
  if (current.refund === "attempt_saved") {
    if (!sameSet(current.attempt_line_ids, lineIds)) refuse("refund_open");
    await finishAttempt({ agg: existing, savedNow: false }, stateDir);
  }
  if (current.shipment === "shipped") refuse("shipped");
  const amount = selected.reduce((sum, line) => sum + line.price_cents, 0);
  if (current.refunded_cents + amount > current.cap_cents) refuse("over_cap");
  serviceBase();
  await finishAttempt(await ensureAttempt(existing, stateDir, amount, lineIds), stateDir);
}
async function cancel(orderId: string): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  const current = viewOf(orderId, existing.state);
  if (current.refund === "attempt_saved") await finishAttempt({ agg: existing, savedNow: false }, stateDir);
  if (current.lines.length === 0) {
    if (current.refund === "refunded") ok(publicView(current));
    if (current.shipment === "shipped") refuse("shipped");
    serviceBase();
    await finishAttempt(await ensureAttempt(existing, stateDir, current.amount_cents, []), stateDir);
  }
  const remaining = current.lines.filter((line) => line.refund !== "refunded");
  if (remaining.length === 0) ok(publicView(current));
  if (current.shipment === "shipped") refuse("shipped");
  const amount = remaining.reduce((sum, line) => sum + line.price_cents, 0);
  if (current.refunded_cents + amount > current.cap_cents) refuse("over_cap");
  serviceBase();
  await finishAttempt(await ensureAttempt(existing, stateDir, amount, remaining.map((line) => line.line_id)), stateDir);
}
async function reconcile(orderId: string): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  const view = viewOf(orderId, existing.state);
  if (view.refund === "none") ok({ order_id: orderId, refund: "none", refund_id: null, outcome: "not_applicable", amount_cents: view.amount_cents, refunded_cents: view.refunded_cents });
  if (view.refund === "refunded") ok({ order_id: orderId, refund: "refunded", refund_id: view.refund_id, outcome: "refunded", amount_cents: view.amount_cents, refunded_cents: view.refunded_cents });
  if (!view.refund_id || view.attempt_cents < 1) refuse("unavailable");
  const looked = await lookupRefund({ refund_id: view.refund_id, order_id: orderId, amount_cents: view.attempt_cents });
  if (looked === "unavailable") refuse("unavailable");
  if (looked === "mismatch") refuse("conflict");
  if (looked === "missing") ok({ order_id: orderId, refund: "attempt_saved", refund_id: view.refund_id, outcome: "not_sent", amount_cents: view.amount_cents, refunded_cents: view.refunded_cents });
  const committed = await commitRefunded(existing, looked, stateDir);
  if (committed.committedNow) crashIf("after-record-before-exit", stateDir);
  ok({ order_id: orderId, refund: "refunded", refund_id: committed.view.refund_id, outcome: "refunded", amount_cents: committed.view.amount_cents, refunded_cents: committed.view.refunded_cents });
}

type ParsedArgs =
  | { command: "record"; orderId: string; amount: number }
  | { command: "attach"; orderId: string; linesPath: string }
  | { command: "refund"; orderId: string; lineIds: string[] }
  | { command: "ship" | "cancel" | "status" | "reconcile"; orderId: string };
function parseArgs(argv: string[]): ParsedArgs {
  const [command, ...rest] = argv;
  if (!command) refuse("bad_args");
  if (command === "record") {
    if (rest.length !== 2) refuse("bad_args");
    if (!validId(rest[0])) refuse("bad_id");
    const amount = validAmount(rest[1]);
    if (amount === null) refuse("bad_amount");
    return { command, orderId: rest[0], amount };
  }
  if (command === "attach") {
    if (rest.length !== 2) refuse("bad_args");
    if (!validId(rest[0])) refuse("bad_id");
    return { command, orderId: rest[0], linesPath: rest[1] };
  }
  if (command === "refund") {
    if (rest.length < 2) refuse("bad_args");
    if (!validId(rest[0])) refuse("bad_id");
    return { command, orderId: rest[0], lineIds: rest.slice(1) };
  }
  if (command === "ship" || command === "cancel" || command === "status" || command === "reconcile") {
    if (rest.length !== 1) refuse("bad_args");
    if (!validId(rest[0])) refuse("bad_id");
    return { command, orderId: rest[0] };
  }
  refuse("bad_args");
}
async function main(): Promise<void> {
  const parsed = parseArgs(process.argv.slice(2));
  if (parsed.command === "record") await record(parsed.orderId, parsed.amount);
  else if (parsed.command === "attach") await attach(parsed.orderId, parsed.linesPath);
  else if (parsed.command === "refund") await refund(parsed.orderId, parsed.lineIds);
  else if (parsed.command === "ship") await ship(parsed.orderId);
  else if (parsed.command === "status") await status(parsed.orderId);
  else if (parsed.command === "cancel") await cancel(parsed.orderId);
  else await reconcile(parsed.orderId);
}
main().catch((err: unknown) => {
  process.stderr.write((err instanceof Error ? err.stack ?? err.message : String(err)) + "\n");
  finish(1, { error: "unavailable" });
});
