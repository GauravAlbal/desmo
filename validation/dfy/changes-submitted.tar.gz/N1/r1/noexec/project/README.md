# Paid-order refund desk

Local desk that records paid orders and submits durable, exactly identified refunds through the payment provider. Shipment, attachment admission, the single open refund attempt, cumulative refunded amount, and per-order cap are owned by the Ikaros machine in `machines/paid_order.ik.toml`; the process owns CLI/file validation and HTTP.

## Setup

Node 22 or newer. No network registry is required.

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

## Run

Each invocation is one process and prints one JSON object on stdout.

```sh
export STATE_DIR=/tmp/desk-state
export SERVICE_URL=http://127.0.0.1:46500
./run record ORDER-1 8000
cat > /tmp/order-lines.json <<'JSON'
{"cap_cents":4000,"lines":[{"line_id":"sku-a","price_cents":3000},{"line_id":"sku-b","price_cents":5000}]}
JSON
./run attach ORDER-1 /tmp/order-lines.json
./run refund ORDER-1 sku-a
./run status ORDER-1
./run reconcile ORDER-1
```

Orders without an attachment retain the original full-refund behavior through `./run cancel ORDER-1`. For attached orders, `cancel` continues an open attempt or refunds all remaining lines only when their total stays within the cap.

`CRASH_AT` may be `after-attempt-saved-before-request`, `after-accept-before-record`, or `after-record-before-exit`. It applies to both `cancel` and `refund`; the process kills itself with `SIGKILL` only if that invocation reaches the named boundary.

The provider is the supplied stub, or any service that implements `stub/CONTRACT.md`.

## Tests

```sh
node --test --test-concurrency=1 tests/desk.test.mjs tests/lines.test.mjs
```

The lifecycle scenarios are:

```sh
node_modules/@ikaros/darwin-arm64/bin/ik scenario run \
  machines/paid_order.ik.toml scenarios/refund-once.json \
  --out /tmp/paid-order-full
node_modules/@ikaros/darwin-arm64/bin/ik scenario run \
  machines/paid_order.ik.toml scenarios/partial-refund.json \
  --out /tmp/paid-order-partial
```
