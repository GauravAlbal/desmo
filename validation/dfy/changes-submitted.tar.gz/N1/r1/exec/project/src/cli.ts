import { createHash, randomBytes } from "node:crypto";
import {
  closeSync,
  existsSync,
  fsyncSync,
  mkdirSync,
  openSync,
  readFileSync,
  writeSync,
} from "node:fs";
import http from "node:http";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  Aggregate,
  Capability,
  HistoricalResult,
  Kernel,
  KernelError,
  StoreNotFoundError,
  classify,
  type EffectIntent,
  type Json,
} from "@ikaros/runtime";

const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const LINE_ID_RE = /^[A-Za-z0-9._-]{1,32}$/;
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const MACHINE = path.join(ROOT, "machines", "paid_order.ik.toml");

type RefundState = "none" | "attempt_saved" | "refunded";
type Shipment = "open" | "shipped";
type LineRefund = "none" | "pending" | "refunded";

type Line = {
  line_id: string;
  price_cents: number;
  refund: LineRefund;
};

type StoredLine = { line_id: string; price_cents: number };

interface OrderView {
  order_id: string;
  amount_cents: number;
  currency: "USD";
  shipment: Shipment;
  refund: RefundState;
  refund_id: string | null;
  refunded_cents: number;
  cap_cents: number;
  lines: Line[];
}

interface Acceptance {
  refund_id: string;
  order_id: string;
  amount_cents: number;
  currency: "USD";
  outcome: "refunded";
}

type HttpResult =
  | { kind: "ok"; status: number; text: string }
  | { kind: "down" };

type ParsedArgs = {
  command: string;
  orderId?: string;
  amount?: number;
  linesPath?: string;
  lineIds?: string[];
};

function finish(code: number, body: unknown): never {
  writeSync(1, JSON.stringify(body) + "\n");
  process.exit(code);
}

function ok(body: unknown): never {
  finish(0, body);
}

function refuse(code: string): never {
  finish(1, { error: code });
}

function validId(value: string | undefined): value is string {
  return typeof value === "string" && ID_RE.test(value);
}

function validLineId(value: string | undefined): value is string {
  return typeof value === "string" && LINE_ID_RE.test(value);
}

function validAmount(value: string | undefined): number | null {
  if (typeof value !== "string" || !/^[1-9][0-9]*$/.test(value)) return null;
  if (value.length > 9) return null;
  const amount = Number(value);
  if (!Number.isSafeInteger(amount) || amount < 1 || amount > 100000000) return null;
  return amount;
}

function requireStateDir(): string {
  const dir = process.env.STATE_DIR;
  if (!dir) refuse("bad_args");
  return dir;
}

function serviceBase(): string {
  const raw = process.env.SERVICE_URL;
  if (!raw || !/^https?:\/\//.test(raw)) refuse("unavailable");
  return raw.replace(/\/$/, "");
}

function storePath(stateDir: string): string {
  return path.join(stateDir, "paid-order.sqlite");
}

function flushStore(stateDir: string): void {
  const base = storePath(stateDir);
  for (const suffix of ["", "-wal", "-shm"]) {
    const file = base + suffix;
    if (!existsSync(file)) continue;
    const fd = openSync(file, "r+");
    try {
      fsyncSync(fd);
    } finally {
      closeSync(fd);
    }
  }
}

function crashIf(boundary: string, stateDir: string): void {
  if (process.env.CRASH_AT !== boundary) return;
  flushStore(stateDir);
  process.kill(process.pid, "SIGKILL");
}

function canonical(value: Record<string, Json>): string {
  const keys = Object.keys(value).sort();
  const sorted: Record<string, Json> = {};
  for (const key of keys) sorted[key] = value[key];
  return JSON.stringify(sorted);
}

function digestOf(value: Record<string, Json>): string {
  return createHash("sha256").update(canonical(value)).digest("hex");
}

function newRefundId(): string {
  return "rf." + randomBytes(16).toString("hex");
}

function asRecord(value: Json | undefined): Record<string, Json> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value;
}

function jsonString(value: Json | undefined, fallback: string): string {
  return typeof value === "string" ? value : fallback;
}

function storedLines(value: Json | undefined): StoredLine[] {
  const raw = jsonString(value, "[]");
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((line): line is StoredLine => {
      if (!line || typeof line !== "object" || Array.isArray(line)) return false;
      const row = line as Record<string, unknown>;
      return validLineId(row.line_id as string | undefined) &&
        Number.isInteger(row.price_cents) &&
        (row.price_cents as number) >= 1;
    });
  } catch {
    return [];
  }
}

function attemptLineIds(value: Json | undefined): string[] {
  const raw = jsonString(value, "[]");
  try {
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.every((id) => typeof id === "string")
      ? parsed as string[]
      : [];
  } catch {
    return [];
  }
}

function viewOf(orderId: string, state: Json): OrderView {
  const record = asRecord(state);
  if (!record) refuse("unavailable");
  const named = String(record.state);
  const amount = Number(record.amount_cents);
  const refunded = Number(record.refunded_cents ?? 0);
  const cap = Number(record.cap_cents ?? amount);
  const refundId = typeof record.refund_id === "string" ? record.refund_id : null;
  let shipment: Shipment = "open";
  let refund: RefundState = "none";
  if (named === "shipped") {
    shipment = "shipped";
  } else if (named === "attempt_saved") {
    refund = "attempt_saved";
  } else if (named === "refunded") {
    refund = "refunded";
  } else if (named !== "open") {
    refuse("unavailable");
  }
  const lines: Line[] = storedLines(record.lines_json).map((line) => ({
    ...line,
    refund: "none",
  }));
  return {
    order_id: orderId,
    amount_cents: amount,
    currency: "USD",
    shipment,
    refund,
    refund_id: refund === "none" ? null : refundId,
    refunded_cents: refunded,
    cap_cents: cap,
    lines,
  };
}

function lineStatusFromStored(value: Json | undefined): Line[] {
  const raw = jsonString(value, "[]");
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((line): line is Line => {
      if (!line || typeof line !== "object" || Array.isArray(line)) return false;
      const row = line as Record<string, unknown>;
      return validLineId(row.line_id as string | undefined) &&
        Number.isInteger(row.price_cents) &&
        (row.price_cents as number) >= 1 &&
        (row.refund === "none" || row.refund === "refunded");
    });
  } catch {
    return [];
  }
}

function viewWithLineState(orderId: string, state: Json): OrderView {
  const view = viewOf(orderId, state);
  const record = asRecord(state);
  if (!record) return view;
  const committed = lineStatusFromStored(record.lines_json);
  const pending = new Set(attemptLineIds(record.attempt_lines_json));
  view.lines = committed.map((line) => ({
    line_id: line.line_id,
    price_cents: line.price_cents,
    refund: view.refund === "attempt_saved" && pending.has(line.line_id)
      ? "pending"
      : line.refund,
  }));
  return view;
}

function missingAggregate(err: unknown): boolean {
  if (err instanceof StoreNotFoundError) return true;
  if (!(err instanceof KernelError)) return false;
  return err.rule === "aggregate.not_found" || err.rule === "store.missing" || classify(err) === "not_found";
}

async function openMachine(stateDir: string): Promise<{ kernel: Kernel; machine: Awaited<ReturnType<Kernel["machine"]>> }> {
  mkdirSync(stateDir, { recursive: true });
  const kernel = new Kernel(storePath(stateDir));
  const machine = await kernel.machine(MACHINE);
  return { kernel, machine };
}

async function load(machine: Awaited<ReturnType<Kernel["machine"]>>, orderId: string): Promise<Aggregate | null> {
  try {
    return await machine.show(orderId);
  } catch (err) {
    if (missingAggregate(err)) return null;
    throw err;
  }
}

function commandBody(name: string, args?: Record<string, Json>): Record<string, Json> {
  if (args && Object.keys(args).length > 0) return { name, args };
  return { name };
}

async function applyCommand(agg: Aggregate, name: string, args?: Record<string, Json>): Promise<Aggregate> {
  const operationId = agg.machine.kernel.newOperationId();
  const wire = agg.capability.toWire();
  const command = commandBody(name, args);
  try {
    const settled = await agg.execute(command, { operationId });
    if (settled instanceof HistoricalResult) return await agg.machine.show(agg.id);
    return settled;
  } catch (err) {
    if (!(err instanceof KernelError) || err.outcome !== "submission-unknown") throw err;
    const found = await agg.machine.lookupOperation(agg.id, Capability.fromWire(wire), operationId, { command });
    if (found.outcome === "committed_exact") return await agg.machine.show(agg.id);
    throw err;
  }
}

function effectBody(intent: EffectIntent, outcomeDigest: string): Record<string, Json> {
  return {
    effect_id: intent.effectId,
    aggregate_id: intent.aggregateId,
    planned_generation: typeof intent.generation === "bigint" ? Number(intent.generation) : intent.generation,
    payload_digest: intent.payloadDigest,
    idempotency_key: intent.idempotencyKey,
    outcome_digest: outcomeDigest,
  };
}

async function bindOutcome(agg: Aggregate, outcomeDigest: string): Promise<Aggregate> {
  const intent = agg.pendingIntent;
  if (!intent) return agg.effect.status === "recorded" ? agg : agg;
  const operationId = agg.machine.kernel.newOperationId();
  const wire = agg.capability.toWire();
  const effect = effectBody(intent, outcomeDigest);
  try {
    const settled = await agg.recordEffectOutcome(outcomeDigest, { operationId, intent });
    if (settled instanceof HistoricalResult) return await agg.machine.show(agg.id);
    return settled;
  } catch (err) {
    const shown = await agg.machine.show(agg.id);
    if (shown.effect.status === "recorded") return shown;
    if (err instanceof KernelError && err.outcome === "submission-unknown") {
      const found = await agg.machine.lookupOperation(agg.id, Capability.fromWire(wire), operationId, { effect });
      if (found.outcome === "committed_exact") return await agg.machine.show(agg.id);
    }
    throw err;
  }
}

function storedLineJson(lines: Line[]): string {
  return JSON.stringify(lines.map(({ line_id, price_cents, refund }) => ({ line_id, price_cents, refund })));
}

async function commitRefunded(agg: Aggregate, acceptance: Acceptance, stateDir: string): Promise<{ view: OrderView; committedNow: boolean }> {
  const before = viewWithLineState(agg.id, agg.state);
  if (agg.namedState() === "refunded" && before.refunded_cents >= acceptance.amount_cents) {
    return { view: before, committedNow: false };
  }
  const outcomeDigest = digestOf({
    amount_cents: acceptance.amount_cents,
    currency: acceptance.currency,
    order_id: acceptance.order_id,
    outcome: acceptance.outcome,
    refund_id: acceptance.refund_id,
  });
  let current = agg;
  if (current.effect.status === "pending") current = await bindOutcome(current, outcomeDigest);
  const currentView = viewWithLineState(current.id, current.state);
  const adopted = currentView.lines.map((line) => line.refund === "pending"
    ? { ...line, refund: "refunded" as const }
    : line);
  const nextRefunded = currentView.refunded_cents + acceptance.amount_cents;
  const noted = await applyCommand(current, "adopt_refund", {
    refunded_cents: nextRefunded,
    lines_json: storedLineJson(adopted),
  });
  flushStore(stateDir);
  return { view: viewWithLineState(noted.id, noted.state), committedNow: true };
}

function httpCall(method: "GET" | "POST", url: string, body?: string): Promise<HttpResult> {
  return new Promise((resolve) => {
    let settled = false;
    const done = (result: HttpResult): void => {
      if (settled) return;
      settled = true;
      resolve(result);
    };
    let req: http.ClientRequest;
    try {
      const parsed = new URL(url);
      req = http.request(
        {
          protocol: parsed.protocol,
          hostname: parsed.hostname,
          port: parsed.port,
          path: parsed.pathname + parsed.search,
          method,
          headers: body
            ? { "content-type": "application/json", "content-length": Buffer.byteLength(body) }
            : { accept: "application/json" },
        },
        (res) => {
          const chunks: Buffer[] = [];
          res.on("data", (chunk: Buffer) => chunks.push(chunk));
          res.on("end", () => done({ kind: "ok", status: res.statusCode ?? 0, text: Buffer.concat(chunks).toString("utf8") }));
          res.on("error", () => done({ kind: "down" }));
          res.on("aborted", () => done({ kind: "down" }));
        },
      );
    } catch {
      done({ kind: "down" });
      return;
    }
    req.on("error", () => done({ kind: "down" }));
    req.on("aborted", () => done({ kind: "down" }));
    if (body) req.write(body);
    req.end();
  });
}

function parseJson(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function readAcceptance(saved: { refund_id: string; order_id: string; amount_cents: number }, text: string): Acceptance | "mismatch" | "bad" {
  const parsed = parseJson(text);
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return "bad";
  const body = parsed as Record<string, unknown>;
  if (body.outcome !== "refunded" || body.currency !== "USD") return "mismatch";
  if (body.refund_id !== saved.refund_id || body.order_id !== saved.order_id) return "mismatch";
  if (body.amount_cents !== saved.amount_cents || typeof body.amount_cents !== "number") return "mismatch";
  return { refund_id: saved.refund_id, order_id: saved.order_id, amount_cents: saved.amount_cents, currency: "USD", outcome: "refunded" };
}

async function lookupRefund(saved: { refund_id: string; order_id: string; amount_cents: number }): Promise<"found" | "missing" | "mismatch" | "unavailable" | Acceptance> {
  const result = await httpCall("GET", serviceBase() + "/v1/refunds/" + encodeURIComponent(saved.refund_id));
  if (result.kind === "down") return "unavailable";
  if (result.status === 404) return "missing";
  if (result.status !== 200) return "unavailable";
  const read = readAcceptance(saved, result.text);
  if (read === "bad") return "unavailable";
  if (read === "mismatch") return "mismatch";
  return read;
}

async function postRefund(saved: { refund_id: string; order_id: string; amount_cents: number }): Promise<Acceptance | "conflict" | "unavailable"> {
  const payload = { refund_id: saved.refund_id, order_id: saved.order_id, amount_cents: saved.amount_cents, currency: "USD" };
  const result = await httpCall("POST", serviceBase() + "/v1/refunds", JSON.stringify(payload));
  if (result.kind === "down") return "unavailable";
  if (result.status === 409) return "conflict";
  if (result.status !== 200) return "unavailable";
  const read = readAcceptance(saved, result.text);
  if (read === "bad") return "unavailable";
  if (read === "mismatch") return "conflict";
  return read;
}

async function record(orderId: string, amount: number): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (existing) {
    const view = viewWithLineState(orderId, existing.state);
    if (view.amount_cents !== amount) refuse("conflict");
    ok(view);
  }
  let created: Aggregate;
  try {
    const settled = await machine.createWith({ aggregateId: orderId, command: { name: "admit", args: { amount_cents: amount } } });
    if (settled instanceof HistoricalResult) {
      const shown = await load(machine, orderId);
      if (!shown) refuse("unavailable");
      created = shown;
    } else {
      created = settled;
    }
  } catch (err) {
    const again = await load(machine, orderId);
    if (again) {
      const view = viewWithLineState(orderId, again.state);
      if (view.amount_cents !== amount) refuse("conflict");
      ok(view);
    }
    throw err;
  }
  flushStore(stateDir);
  ok(viewWithLineState(orderId, created.state));
}

async function ship(orderId: string): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  const view = viewWithLineState(orderId, existing.state);
  if (view.refund !== "none") refuse("refund_open");
  if (view.shipment === "shipped") ok(view);
  let shipped: Aggregate;
  try {
    shipped = await applyCommand(existing, "ship");
  } catch (err) {
    if (err instanceof KernelError && err.code === "IK_ILLEGAL_STATE") refuse("refund_open");
    throw err;
  }
  flushStore(stateDir);
  ok(viewWithLineState(orderId, shipped.state));
}

async function status(orderId: string): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  ok(viewWithLineState(orderId, existing.state));
}

function readAttachment(file: string, amount: number): { cap_cents: number; lines: StoredLine[] } | null {
  let parsed: unknown;
  try {
    parsed = JSON.parse(readFileSync(file, "utf8"));
  } catch {
    return null;
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
  const body = parsed as Record<string, unknown>;
  const cap = body.cap_cents;
  if (!Number.isInteger(cap) || (cap as number) < 1 || (cap as number) > amount) return null;
  if (!Array.isArray(body.lines) || body.lines.length < 1 || body.lines.length > 20) return null;
  const ids = new Set<string>();
  const lines: StoredLine[] = [];
  let sum = 0;
  for (const item of body.lines) {
    if (!item || typeof item !== "object" || Array.isArray(item)) return null;
    const row = item as Record<string, unknown>;
    if (!validLineId(row.line_id as string | undefined) || ids.has(row.line_id as string)) return null;
    if (!Number.isInteger(row.price_cents) || (row.price_cents as number) < 1 || (row.price_cents as number) > 100000000) return null;
    ids.add(row.line_id as string);
    lines.push({ line_id: row.line_id as string, price_cents: row.price_cents as number });
    sum += row.price_cents as number;
  }
  return sum === amount ? { cap_cents: cap as number, lines } : null;
}

function attachmentKey(cap: number, lines: Array<{ line_id: string; price_cents: number }>): string {
  const normalized = lines
    .map(({ line_id, price_cents }) => ({ line_id, price_cents }))
    .sort((a, b) => a.line_id.localeCompare(b.line_id));
  return JSON.stringify({ cap_cents: cap, lines: normalized });

}
async function attach(orderId: string, file: string): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  const view = viewWithLineState(orderId, existing.state);
  if (view.shipment === "shipped") refuse("shipped");
  if (view.refund !== "none") refuse("refund_open");
  const attachment = readAttachment(file, view.amount_cents);
  if (!attachment) refuse("bad_lines");
  if (view.lines.length > 0) {
    const current = attachmentKey(view.cap_cents, view.lines);
    const requested = attachmentKey(attachment.cap_cents, attachment.lines);
    if (current === requested) ok(view);
    refuse("conflict");
  }
  const linesJson = JSON.stringify(attachment.lines.map((line) => ({ ...line, refund: "none" })));
  const updated = await applyCommand(existing, "attach", { cap_cents: attachment.cap_cents, lines_json: linesJson });
  flushStore(stateDir);
  ok(viewWithLineState(orderId, updated.state));
}

function attemptFrom(agg: Aggregate): { refundId: string; amount: number; lineIds: string[] } | null {
  const record = asRecord(agg.state);
  if (!record || agg.namedState() !== "attempt_saved") return null;
  if (typeof record.refund_id !== "string") return null;
  const amount = Number(record.attempt_amount_cents);
  if (!Number.isInteger(amount) || amount < 1) return null;
  return { refundId: record.refund_id, amount, lineIds: attemptLineIds(record.attempt_lines_json) };
}

async function ensureAttempt(agg: Aggregate, stateDir: string, amount: number, lineIds: string[]): Promise<{ agg: Aggregate; savedNow: boolean }> {
  if (agg.namedState() === "attempt_saved") return { agg, savedNow: false };
  const view = viewWithLineState(agg.id, agg.state);
  const refundId = newRefundId();
  const payloadDigest = digestOf({ amount_cents: amount, currency: "USD", line_ids: JSON.stringify(lineIds), order_id: view.order_id, refund_id: refundId });
  const planned = await applyCommand(agg, "begin_refund", {
    refund_id: refundId,
    effect_id: refundId,
    payload_digest: payloadDigest,
    idempotency_key: refundId,
    attempt_amount_cents: amount,
    attempt_lines_json: JSON.stringify(lineIds),
  });
  flushStore(stateDir);
  return { agg: planned, savedNow: true };
}

async function finishAttempt(agg: Aggregate, stateDir: string, savedNow: boolean): Promise<OrderView> {
  if (savedNow) crashIf("after-attempt-saved-before-request", stateDir);
  const attempt = attemptFrom(agg);
  if (!attempt) refuse("unavailable");
  const target = { refund_id: attempt.refundId, order_id: agg.id, amount_cents: attempt.amount };
  let acceptance: Acceptance | null = null;
  let acceptedByPost = false;
  if (!savedNow) {
    const looked = await lookupRefund(target);
    if (looked === "unavailable") refuse("unavailable");
    if (looked === "mismatch") refuse("conflict");
    if (looked !== "missing") acceptance = looked;
  }
  if (!acceptance) {
    const posted = await postRefund(target);
    if (posted === "unavailable") refuse("unavailable");
    if (posted === "conflict") refuse("conflict");
    acceptance = posted;
    acceptedByPost = true;
  }
  if (acceptedByPost) crashIf("after-accept-before-record", stateDir);
  const committed = await commitRefunded(agg, acceptance, stateDir);
  if (committed.committedNow) crashIf("after-record-before-exit", stateDir);
  return committed.view;
}

async function cancel(orderId: string): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  const initial = viewWithLineState(orderId, existing.state);
  if (initial.lines.length === 0) {
    if (initial.refund === "refunded") ok(initial);
    if (initial.shipment === "shipped" && initial.refund === "none") refuse("shipped");
    if (initial.refund === "none") serviceBase();
    const attempt = await ensureAttempt(existing, stateDir, initial.amount_cents, []);
    ok(await finishAttempt(attempt.agg, stateDir, attempt.savedNow));
  }
  if (initial.refund === "refunded" && initial.lines.every((line) => line.refund === "refunded")) ok(initial);
  if (initial.refund === "none" && initial.shipment === "shipped") refuse("shipped");
  if (initial.refund === "attempt_saved") ok(await finishAttempt(existing, stateDir, false));
  const remaining = initial.lines.filter((line) => line.refund !== "refunded");
  if (remaining.length === 0) ok(initial);
  const total = remaining.reduce((sum, line) => sum + line.price_cents, 0);
  if (initial.refunded_cents + total > initial.cap_cents) refuse("over_cap");
  const attempt = await ensureAttempt(existing, stateDir, total, remaining.map((line) => line.line_id));
  ok(await finishAttempt(attempt.agg, stateDir, attempt.savedNow));
}

async function refund(orderId: string, lineIds: string[]): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  const initial = viewWithLineState(orderId, existing.state);
  if (initial.lines.length === 0) refuse("not_attached");
  if (lineIds.some((id) => !validLineId(id)) || new Set(lineIds).size !== lineIds.length) refuse("unknown_line");
  const selected = initial.lines.filter((line) => lineIds.includes(line.line_id));
  if (selected.length !== lineIds.length) refuse("unknown_line");
  const openAttempt = attemptFrom(existing);
  if (openAttempt) {
    if (openAttempt.lineIds.length !== lineIds.length || openAttempt.lineIds.some((id) => !lineIds.includes(id))) refuse("refund_open");
    ok(await finishAttempt(existing, stateDir, false));
  }
  if (initial.shipment === "shipped") refuse("shipped");
  if (selected.some((line) => line.refund === "refunded")) refuse("already_refunded");
  const amount = selected.reduce((sum, line) => sum + line.price_cents, 0);
  if (initial.refunded_cents + amount > initial.cap_cents) refuse("over_cap");
  const attempt = await ensureAttempt(existing, stateDir, amount, lineIds);
  ok(await finishAttempt(attempt.agg, stateDir, attempt.savedNow));
}

async function reconcile(orderId: string): Promise<never> {
  const stateDir = requireStateDir();
  const { machine } = await openMachine(stateDir);
  const existing = await load(machine, orderId);
  if (!existing) refuse("unknown_order");
  const view = viewWithLineState(orderId, existing.state);
  const attempt = attemptFrom(existing);
  if (!attempt && view.refund === "none") ok({ order_id: view.order_id, refund: "none", refund_id: null, outcome: "not_applicable", amount_cents: view.amount_cents, refunded_cents: 0 });
  if (!attempt && view.refund === "refunded") ok({ order_id: view.order_id, refund: "refunded", refund_id: view.refund_id, outcome: "refunded", amount_cents: view.amount_cents, refunded_cents: view.refunded_cents });
  if (!attempt) refuse("unavailable");
  const looked = await lookupRefund({ refund_id: attempt.refundId, order_id: orderId, amount_cents: attempt.amount });
  if (looked === "unavailable") refuse("unavailable");
  if (looked === "mismatch") refuse("conflict");
  if (looked === "missing") ok({ order_id: view.order_id, refund: "attempt_saved", refund_id: attempt.refundId, outcome: "not_sent", amount_cents: view.amount_cents, refunded_cents: view.refunded_cents });
  const committed = await commitRefunded(existing, looked, stateDir);
  if (committed.committedNow) crashIf("after-record-before-exit", stateDir);
  ok({ order_id: committed.view.order_id, refund: "refunded", refund_id: committed.view.refund_id, outcome: "refunded", amount_cents: committed.view.amount_cents, refunded_cents: committed.view.refunded_cents });
}

function parseArgs(argv: string[]): ParsedArgs {
  const [command, ...rest] = argv;
  if (!command) refuse("bad_args");
  if (command === "record") {
    if (rest.length !== 2) refuse("bad_args");
    if (!validId(rest[0])) refuse("bad_id");
    const amount = validAmount(rest[1]);
    if (amount === null) refuse("bad_amount");
    return { command, orderId: rest[0], amount };
  }
  if (command === "attach") {
    if (rest.length !== 2) refuse("bad_args");
    if (!validId(rest[0])) refuse("bad_id");
    return { command, orderId: rest[0], linesPath: rest[1] };
  }
  if (command === "refund") {
    if (rest.length < 2) refuse("bad_args");
    if (!validId(rest[0])) refuse("bad_id");
    return { command, orderId: rest[0], lineIds: rest.slice(1) };
  }
  if (command === "ship" || command === "cancel" || command === "status" || command === "reconcile") {
    if (rest.length !== 1) refuse("bad_args");
    if (!validId(rest[0])) refuse("bad_id");
    return { command, orderId: rest[0] };
  }
  refuse("bad_args");
}

async function main(): Promise<void> {
  const parsed = parseArgs(process.argv.slice(2));
  if (!parsed.orderId) refuse("bad_args");
  if (parsed.command === "record") await record(parsed.orderId, parsed.amount as number);
  if (parsed.command === "attach") await attach(parsed.orderId, parsed.linesPath as string);
  if (parsed.command === "refund") await refund(parsed.orderId, parsed.lineIds as string[]);
  if (parsed.command === "ship") await ship(parsed.orderId);
  if (parsed.command === "status") await status(parsed.orderId);
  if (parsed.command === "cancel") await cancel(parsed.orderId);
  if (parsed.command === "reconcile") await reconcile(parsed.orderId);
  refuse("bad_args");
}

main().catch((err: unknown) => {
  const message = err instanceof Error ? err.stack ?? err.message : String(err);
  process.stderr.write(message + "\n");
  finish(1, { error: "unavailable" });
});

