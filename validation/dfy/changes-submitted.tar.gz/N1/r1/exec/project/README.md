# Paid-order cancellation desk

Local desk that records a paid order and refunds it once through the payment provider. Shipment and refund transitions are an Ikaros machine (`machines/paid_order.ik.toml`). The process owns HTTP and the command line only.

## Setup

Node 22 or newer. No network registry is required.

```sh
npm install --offline --no-audit --no-fund
```

That installs `@ikaros/runtime` and the matching `ik` binary from `KIT/npm/`.

## Run

Each invocation is one process and prints one JSON object on stdout.

```sh
export STATE_DIR=/tmp/desk-state
export SERVICE_URL=http://127.0.0.1:46500   # no trailing slash
./run record ORDER-1 1000
./run status ORDER-1
./run ship ORDER-1
./run attach ORDER-1 lines.json
./run refund ORDER-1 sku-a sku-b
./run cancel ORDER-1
./run reconcile ORDER-1

`lines.json` is an attachment such as `{"cap_cents":4000,"lines":[{"line_id":"sku-a","price_cents":3000},{"line_id":"sku-b","price_cents":5000}]}`. The line prices must sum to the recorded order amount; the cap is the maximum cumulative refund.

`CRASH_AT` may be `after-attempt-saved-before-request`, `after-accept-before-record`, or `after-record-before-exit`. The process kills itself with `SIGKILL` only if that invocation reaches the named boundary.

The provider is the supplied stub, or any service that implements `stub/CONTRACT.md`. `stub/server.mjs` binds an ephemeral port; this tree's tests do not start it. They start `tests/provider.mjs` on `127.0.0.1:46500` (control `46501`).

## Tests

```sh
node --test --test-concurrency=1 tests/desk.test.mjs
```

Ports 46500 and 46501 must be free. The kernel scenario is:

```sh
ik scenario run machines/paid_order.ik.toml scenarios/refund-once.json --out /tmp/paid-order-scenario
```

`ik` is `node_modules/@ikaros/darwin-arm64/bin/ik` after install.
