import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtempSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const node = process.env.NODE || process.execPath;
const provider = { service_url: "", control_url: "" };

function run(args, env, { allowSignal = false } = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(path.join(root, "run"), args, {
      cwd: root,
      env: { ...process.env, NODE: node, ...env },
      stdio: ["ignore", "pipe", "pipe"],
    });
    const out = [];
    const err = [];
    child.stdout.on("data", (chunk) => out.push(chunk));
    child.stderr.on("data", (chunk) => err.push(chunk));
    child.on("error", reject);
    child.on("close", (code, signal) => {
      const stdout = Buffer.concat(out).toString("utf8");
      const stderr = Buffer.concat(err).toString("utf8");
      if (signal) {
        if (!allowSignal) {
          reject(new Error(`signal ${signal}\n${stderr}\n${stdout}`));
          return;
        }
        resolve({ code, signal, stdout, stderr, json: null });
        return;
      }
      let json = null;
      const lines = stdout.split("\n").filter((line) => line.length > 0);
      if (lines.length === 1) {
        try {
          json = JSON.parse(lines[0]);
        } catch {
          json = null;
        }
      }
      resolve({ code, signal, stdout, stderr, json, lines });
    });
  });
}

async function control(pathname, body) {
  const response = await fetch(provider.control_url + pathname, body
    ? { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }
    : undefined);
  return response.json();
}

test.before(async () => {
  const child = spawn(node, [path.join(root, "tests/provider.mjs")], {
    env: { ...process.env, PORT: "46500", CONTROL_PORT: "46501" },
  });
  const line = await new Promise((resolve, reject) => {
    let buf = "";
    const timer = setTimeout(() => reject(new Error("provider did not start")), 5000);
    child.stdout.on("data", (chunk) => {
      buf += chunk.toString("utf8");
      const idx = buf.indexOf("\n");
      if (idx >= 0) {
        clearTimeout(timer);
        resolve(buf.slice(0, idx));
      }
    });
    child.on("exit", (code) => reject(new Error("provider exited " + code)));
  });
  Object.assign(provider, JSON.parse(line));
  provider.child = child;
});

test.after(async () => {
  provider.child?.kill("SIGTERM");
});

function deskEnv(extra = {}) {
  const dir = mkdtempSync(path.join(tmpdir(), "desk-"));
  return { STATE_DIR: dir, SERVICE_URL: provider.service_url, ...extra, dir };
}

test("record persists across processes and refuses a different amount", async () => {
  const env = deskEnv();
  const first = await run(["record", "ord-1", "1000"], env);
  assert.equal(first.code, 0);
  assert.deepEqual(first.json, {
    order_id: "ord-1",
    amount_cents: 1000,
    currency: "USD",
    shipment: "open",
    refund: "none",
    refund_id: null,
    refunded_cents: 0,
    cap_cents: 1000,
    lines: [],
  });
  const again = await run(["record", "ord-1", "1000"], env);
  assert.equal(again.code, 0);
  assert.equal(again.json.amount_cents, 1000);
  const clash = await run(["record", "ord-1", "2000"], env);
  assert.equal(clash.code, 1);
  assert.equal(clash.json.error, "conflict");
  const status = await run(["status", "ord-1"], env);
  assert.equal(status.code, 0);
  assert.equal(status.json.amount_cents, 1000);
  assert.equal(status.json.shipment, "open");
});

test("validation refusals do not write orders or contact the provider", async () => {
  const env = deskEnv();
  const before = await control("/traffic");
  const badArgs = await run(["record", "ord-1"], env);
  assert.equal(badArgs.code, 1);
  assert.equal(badArgs.json.error, "bad_args");
  const badId = await run(["status", "bad id"], env);
  assert.equal(badId.code, 1);
  assert.equal(badId.json.error, "bad_id");
  const badAmount = await run(["record", "ord-1", "01"], env);
  assert.equal(badAmount.code, 1);
  assert.equal(badAmount.json.error, "bad_amount");
  const unknown = await run(["cancel", "missing"], env);
  assert.equal(unknown.code, 1);
  assert.equal(unknown.json.error, "unknown_order");
  const after = await control("/traffic");
  assert.equal(after.requests.length, before.requests.length);
  const status = await run(["status", "ord-1"], env);
  assert.equal(status.json.error, "unknown_order");
});

test("ship blocks a new refund and is idempotent", async () => {
  const env = deskEnv();
  await run(["record", "box", "500"], env);
  const shipped = await run(["ship", "box"], env);
  assert.equal(shipped.code, 0);
  assert.equal(shipped.json.shipment, "shipped");
  const again = await run(["ship", "box"], env);
  assert.equal(again.code, 0);
  assert.equal(again.json.shipment, "shipped");
  const before = await control("/effects");
  const cancelled = await run(["cancel", "box"], env);
  assert.equal(cancelled.code, 1);
  assert.equal(cancelled.json.error, "shipped");
  const status = await run(["status", "box"], env);
  assert.equal(status.json.shipment, "shipped");
  assert.equal(status.json.refund, "none");
  const after = await control("/effects");
  assert.equal(after.count, before.count);
});

test("cancel refunds once and a second cancel adds no effect", async () => {
  const env = deskEnv();
  await run(["record", "pay", "2500"], env);
  const before = await control("/effects");
  const cancelled = await run(["cancel", "pay"], env);
  assert.equal(cancelled.code, 0, cancelled.stderr);
  assert.equal(cancelled.json.refund, "refunded");
  assert.equal(cancelled.json.refunded_cents, 2500);
  assert.equal(cancelled.json.shipment, "open");
  assert.ok(cancelled.json.refund_id);
  const effects = await control("/effects");
  assert.equal(effects.count, before.count + 1);
  assert.equal(effects.effects[effects.effects.length - 1].amount_cents, 2500);
  assert.equal(effects.effects[effects.effects.length - 1].refund_id, cancelled.json.refund_id);
  const second = await run(["cancel", "pay"], env);
  assert.equal(second.code, 0);
  assert.equal(second.json.refund_id, cancelled.json.refund_id);
  assert.equal(second.json.refunded_cents, 2500);
  const after = await control("/effects");
  assert.equal(after.count, effects.count);
  const posts = after.posts;
  const third = await run(["cancel", "pay"], env);
  assert.equal(third.code, 0);
  const finalEffects = await control("/effects");
  assert.equal(finalEffects.posts, posts);
});

test("orders are independent", async () => {
  const env = deskEnv();
  await run(["record", "a", "100"], env);
  await run(["record", "b", "200"], env);
  await run(["ship", "a"], env);
  const cancelled = await run(["cancel", "b"], env);
  assert.equal(cancelled.code, 0);
  assert.equal(cancelled.json.amount_cents, 200);
  const a = await run(["status", "a"], env);
  assert.equal(a.json.shipment, "shipped");
  assert.equal(a.json.refund, "none");
  const effects = await control("/effects");
  assert.equal(effects.effects.filter((row) => row.order_id === "a").length, 0);
  assert.equal(effects.effects.filter((row) => row.order_id === "b").length, 1);
});

test("unrelated state-dir file is preserved", async () => {
  const env = deskEnv();
  const note = path.join(env.STATE_DIR, "other.txt");
  writeFileSync(note, "keep-me");
  await run(["record", "keep", "9"], env);
  await run(["ship", "keep"], env);
  assert.equal(readFileSync(note, "utf8"), "keep-me");
});

test("crash before request leaves the attempt and reconcile does not post", async () => {
  const env = deskEnv({ CRASH_AT: "after-attempt-saved-before-request" });
  await run(["record", "crash1", "40"], env);
  const before = await control("/effects");
  const trafficBefore = await control("/traffic");
  const killed = await run(["cancel", "crash1"], env, { allowSignal: true });
  assert.equal(killed.signal, "SIGKILL");
  const status = await run(["status", "crash1"], { ...env, CRASH_AT: "" });
  assert.equal(status.json.refund, "attempt_saved");
  assert.ok(status.json.refund_id);
  const effects = await control("/effects");
  assert.equal(effects.count, before.count);
  const reconciled = await run(["reconcile", "crash1"], { ...env, CRASH_AT: "" });
  assert.equal(reconciled.code, 0, reconciled.stderr);
  assert.equal(reconciled.json.outcome, "not_sent");
  assert.equal(reconciled.json.refund, "attempt_saved");
  assert.equal(reconciled.json.refund_id, status.json.refund_id);
  const traffic = await control("/traffic");
  const added = traffic.requests.slice(trafficBefore.requests.length);
  assert.equal(added.filter((row) => row.method === "POST").length, 0);
  assert.equal((await control("/effects")).count, before.count);
  const later = await run(["cancel", "crash1"], { ...env, CRASH_AT: "" });
  assert.equal(later.code, 0, later.stderr);
  assert.equal(later.json.refund, "refunded");
  assert.equal(later.json.refund_id, status.json.refund_id);
  assert.equal(later.json.refunded_cents, 40);
  const finalEffects = await control("/effects");
  assert.equal(finalEffects.count, before.count + 1);
  assert.equal(finalEffects.effects.at(-1).refund_id, status.json.refund_id);
});

test("crash after accept is resolved by a later cancel without a second effect", async () => {
  const env = deskEnv({ CRASH_AT: "after-accept-before-record" });
  await run(["record", "crash2", "70"], env);
  const before = await control("/effects");
  const killed = await run(["cancel", "crash2"], env, { allowSignal: true });
  assert.equal(killed.signal, "SIGKILL");
  const status = await run(["status", "crash2"], { ...env, CRASH_AT: "" });
  assert.equal(status.json.refund, "attempt_saved");
  const effects = await control("/effects");
  assert.equal(effects.count, before.count + 1);
  const refundId = effects.effects.at(-1).refund_id;
  assert.equal(status.json.refund_id, refundId);
  const later = await run(["cancel", "crash2"], { ...env, CRASH_AT: "" });
  assert.equal(later.code, 0, later.stderr);
  assert.equal(later.json.refund, "refunded");
  assert.equal(later.json.refund_id, refundId);
  assert.equal(later.json.refunded_cents, 70);
  const after = await control("/effects");
  assert.equal(after.count, effects.count);
  assert.equal(after.effects.filter((row) => row.order_id === "crash2").length, 1);
});

test("crash after the durable refund record leaves refunded", async () => {
  const env = deskEnv({ CRASH_AT: "after-record-before-exit" });
  await run(["record", "crash3", "80"], env);
  const killed = await run(["cancel", "crash3"], env, { allowSignal: true });
  assert.equal(killed.signal, "SIGKILL");
  const status = await run(["status", "crash3"], { ...env, CRASH_AT: "" });
  assert.equal(status.json.refund, "refunded");
  assert.equal(status.json.refunded_cents, 80);
  const before = await control("/effects");
  const again = await run(["cancel", "crash3"], { ...env, CRASH_AT: "after-record-before-exit" });
  assert.equal(again.code, 0, again.stderr);
  assert.equal(again.json.refund, "refunded");
  assert.equal(again.json.refund_id, status.json.refund_id);
  const after = await control("/effects");
  assert.equal(after.count, before.count);
});

test("lost reply is resolved by reconcile and does not post a new id", async () => {
  const env = deskEnv();
  await run(["record", "lost", "90"], env);
  await control("/fault", { drop_reply: true, status_5xx: false });
  const before = await control("/effects");
  const cancelled = await run(["cancel", "lost"], env);
  assert.equal(cancelled.code, 1, cancelled.stderr + cancelled.stdout);
  assert.equal(cancelled.json.error, "unavailable");
  const status = await run(["status", "lost"], env);
  assert.equal(status.json.refund, "attempt_saved");
  const effects = await control("/effects");
  assert.equal(effects.count, before.count + 1);
  assert.equal(effects.effects.at(-1).refund_id, status.json.refund_id);
  await control("/fault", { drop_reply: false });
  const reconciled = await run(["reconcile", "lost"], env);
  assert.equal(reconciled.code, 0, reconciled.stderr);
  assert.equal(reconciled.json.outcome, "refunded");
  assert.notEqual(reconciled.json.outcome, "not_sent");
  assert.equal(reconciled.json.refund_id, status.json.refund_id);
  assert.equal(reconciled.json.refunded_cents, 90);
  const after = await control("/effects");
  assert.equal(after.count, effects.count);
});

test("provider 500 leaves the attempt and does not count an effect", async () => {
  const env = deskEnv();
  await run(["record", "down", "15"], env);
  await control("/fault", { status_5xx: true, drop_reply: false });
  const before = await control("/effects");
  const cancelled = await run(["cancel", "down"], env);
  assert.equal(cancelled.json.error, "unavailable");
  const status = await run(["status", "down"], env);
  assert.equal(status.json.refund, "attempt_saved");
  assert.equal((await control("/effects")).count, before.count);
  await control("/fault", { status_5xx: false });
  const later = await run(["cancel", "down"], env);
  assert.equal(later.code, 0, later.stderr);
  assert.equal(later.json.refund_id, status.json.refund_id);
  assert.equal((await control("/effects")).effects.filter((row) => row.order_id === "down").length, 1);
});

test("lookup mismatch is conflict and does not allocate a new refund id", async () => {
  const env = deskEnv({ CRASH_AT: "after-attempt-saved-before-request" });
  await run(["record", "mis", "33"], env);
  await run(["cancel", "mis"], env, { allowSignal: true });
  const status = await run(["status", "mis"], { ...env, CRASH_AT: "" });
  const refundId = status.json.refund_id;
  await fetch(provider.service_url + "/v1/refunds", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      refund_id: refundId,
      order_id: "mis",
      amount_cents: 33,
      currency: "USD",
    }),
  });
  await control("/fault", { lookup_mismatch: true, drop_reply: false, status_5xx: false });
  const before = await control("/effects");
  const cancelled = await run(["cancel", "mis"], { ...env, CRASH_AT: "" });
  assert.equal(cancelled.code, 1);
  assert.equal(cancelled.json.error, "conflict");
  const afterStatus = await run(["status", "mis"], { ...env, CRASH_AT: "" });
  assert.equal(afterStatus.json.refund, "attempt_saved");
  assert.equal(afterStatus.json.refund_id, refundId);
  assert.equal((await control("/effects")).count, before.count);
  await control("/fault", { lookup_mismatch: false });
});

test("reconcile of an open order does not contact the provider", async () => {
  const env = deskEnv();
  await run(["record", "plain", "12"], env);
  const before = await control("/traffic");
  const reconciled = await run(["reconcile", "plain"], env);
  assert.equal(reconciled.code, 0);
  assert.equal(reconciled.json.outcome, "not_applicable");
  assert.equal(reconciled.json.refund, "none");
  const after = await control("/traffic");
  assert.equal(after.requests.length, before.requests.length);
});

test("ship after an attempt is refund_open", async () => {
  const env = deskEnv({ CRASH_AT: "after-attempt-saved-before-request" });
  await run(["record", "late-ship", "18"], env);
  await run(["cancel", "late-ship"], env, { allowSignal: true });
  const shipped = await run(["ship", "late-ship"], { ...env, CRASH_AT: "" });
  assert.equal(shipped.code, 1);
  assert.equal(shipped.json.error, "refund_open");
  const status = await run(["status", "late-ship"], { ...env, CRASH_AT: "" });
  assert.equal(status.json.shipment, "open");
  assert.equal(status.json.refund, "attempt_saved");
});

test("attach persists immutable lines and rejects a different attachment", async () => {
  const env = deskEnv();
  const lines = path.join(env.dir, "lines.json");
  writeFileSync(lines, JSON.stringify({
    cap_cents: 1000,
    lines: [
      { line_id: "sku-a", price_cents: 400 },
      { line_id: "sku-b", price_cents: 600 },
    ],
  }));
  await run(["record", "lines", "1000"], env);
  const attached = await run(["attach", "lines", lines], env);
  assert.equal(attached.code, 0);
  assert.deepEqual(attached.json.lines, [
    { line_id: "sku-a", price_cents: 400, refund: "none" },
    { line_id: "sku-b", price_cents: 600, refund: "none" },
  ]);
  writeFileSync(lines, JSON.stringify({ cap_cents: 1000, lines: [{ line_id: "changed", price_cents: 1000 }] }));
  const stable = await run(["status", "lines"], env);
  assert.deepEqual(stable.json.lines, attached.json.lines);
  const conflict = await run(["attach", "lines", lines], env);
  assert.equal(conflict.code, 1);
  assert.equal(conflict.json.error, "conflict");
});

test("line refunds are capped, idempotent, and cancel refunds the remainder", async () => {
  const env = deskEnv();
  const lines = path.join(env.dir, "lines.json");
  writeFileSync(lines, JSON.stringify({
    cap_cents: 500,
    lines: [
      { line_id: "sku-a", price_cents: 400 },
      { line_id: "sku-b", price_cents: 600 },
    ],
  }));
  await run(["record", "partial", "1000"], env);
  await run(["attach", "partial", lines], env);
  const over = await run(["refund", "partial", "sku-b"], env);
  assert.equal(over.code, 1);
  assert.equal(over.json.error, "over_cap");
  const first = await run(["refund", "partial", "sku-a"], env);
  assert.equal(first.code, 0);
  assert.equal(first.json.refunded_cents, 400);
  const duplicate = await run(["refund", "partial", "sku-a"], env);
  assert.equal(duplicate.code, 1);
  assert.equal(duplicate.json.error, "already_refunded");
  const blocked = await run(["cancel", "partial"], env);
  assert.equal(blocked.code, 1);
  assert.equal(blocked.json.error, "over_cap");
  assert.equal((await control("/effects")).effects.filter((row) => row.order_id === "partial").length, 1);
});

test("line refund keeps shipping blocked in both directions", async () => {
  const env = deskEnv();
  const lines = path.join(env.dir, "lines.json");
  writeFileSync(lines, JSON.stringify({ cap_cents: 1000, lines: [{ line_id: "sku-a", price_cents: 1000 }] }));
  await run(["record", "ship-lines", "1000"], env);
  await run(["attach", "ship-lines", lines], env);
  await run(["ship", "ship-lines"], env);
  const refused = await run(["refund", "ship-lines", "sku-a"], env);
  assert.equal(refused.code, 1);
  assert.equal(refused.json.error, "shipped");
  await run(["record", "refunded-lines", "1000"], env);
  await run(["attach", "refunded-lines", lines], env);
  await run(["refund", "refunded-lines", "sku-a"], env);
  const shipAfterRefund = await run(["ship", "refunded-lines"], env);
  assert.equal(shipAfterRefund.code, 1);
  assert.equal(shipAfterRefund.json.error, "refund_open");
});
