import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const NODE = "/Users/galbal/.nvm/versions/node/v22.17.1/bin/node";
const RUN = join(ROOT, "run");

function fail(message) {
  console.error("FAIL", message);
  process.exit(1);
}

function assert(cond, message) {
  if (!cond) fail(message);
}

function run(args, env, { allowSignal = false } = {}) {
  return new Promise((resolve) => {
    const child = spawn(RUN, args, {
      cwd: ROOT,
      env: { ...process.env, ...env },
      stdio: ["ignore", "pipe", "pipe"],
    });
    const out = [];
    const err = [];
    child.stdout.on("data", (chunk) => out.push(chunk));
    child.stderr.on("data", (chunk) => err.push(chunk));
    child.on("close", (code, signal) => {
      const stdout = Buffer.concat(out).toString("utf8");
      const stderr = Buffer.concat(err).toString("utf8");
      resolve({ code, signal, stdout, stderr, allowSignal });
    });
  });
}

function parseOne(result, label) {
  const text = result.stdout.trim();
  assert(text.length > 0, `${label} produced no stdout (code=${result.code} signal=${result.signal} stderr=${result.stderr})`);
  const lines = text.split("\n").filter((line) => line.length > 0);
  assert(lines.length === 1, `${label} stdout was not one JSON object: ${JSON.stringify(result.stdout)}`);
  let body;
  try {
    body = JSON.parse(lines[0]);
  } catch (err) {
    fail(`${label} stdout was not JSON: ${result.stdout}`);
  }
  return body;
}

async function ok(args, env, label) {
  const result = await run(args, env);
  assert(result.code === 0 && !result.signal, `${label} exit ${result.code} signal ${result.signal} stdout ${result.stdout} stderr ${result.stderr}`);
  return parseOne(result, label);
}

async function refused(args, env, error, label) {
  const result = await run(args, env);
  assert(result.code !== 0 && !result.signal, `${label} expected refusal, code=${result.code} signal=${result.signal} stdout=${result.stdout}`);
  const body = parseOne(result, label);
  assert(body.error === error, `${label} error ${body.error} expected ${error} body ${result.stdout}`);
  return body;
}

async function killed(args, env, label) {
  const result = await run(args, env, { allowSignal: true });
  assert(result.signal === "SIGKILL" || result.code === 137, `${label} expected SIGKILL, code=${result.code} signal=${result.signal} stdout=${result.stdout} stderr=${result.stderr}`);
  assert(!result.stdout.trim(), `${label} wrote stdout before kill: ${result.stdout}`);
  return result;
}

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [join(ROOT, "stub/server.mjs")], {
      cwd: ROOT,
      stdio: ["ignore", "pipe", "pipe"],
    });
    let buf = "";
    const onData = (chunk) => {
      buf += chunk.toString("utf8");
      const nl = buf.indexOf("\n");
      if (nl === -1) return;
      child.stdout.off("data", onData);
      try {
        const info = JSON.parse(buf.slice(0, nl));
        resolve({ child, ...info });
      } catch (err) {
        reject(err);
      }
    };
    child.stdout.on("data", onData);
    child.on("error", reject);
    child.on("exit", (code) => reject(new Error(`stub exited ${code} before ready`)));
  });
}

async function effects(control) {
  const response = await fetch(control + "/effects");
  return response.json();
}

async function traffic(control) {
  const response = await fetch(control + "/traffic");
  return response.json();
}

async function fault(control, body) {
  const response = await fetch(control + "/fault", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  assert(response.status === 200, "fault injection failed");
}

const root = mkdtempSync(join(tmpdir(), "desk-"));
const stub = await startStub();
const baseEnv = { STATE_DIR: join(root, "state"), SERVICE_URL: stub.service_url };
let failures = 0;

try {
  const recorded = await ok(["record", "A._-1", "1000"], baseEnv, "record");
  assert(recorded.shipment === "open" && recorded.refund === "none" && recorded.refund_id === null && recorded.refunded_cents === 0, "record view");
  assert(recorded.amount_cents === 1000 && recorded.currency === "USD" && recorded.order_id === "A._-1", "record fields");

  const again = await ok(["record", "A._-1", "1000"], baseEnv, "record same");
  assert(again.amount_cents === 1000 && again.refund === "none", "idempotent record");
  await refused(["record", "A._-1", "1001"], baseEnv, "conflict", "record conflict");
  const afterConflict = await ok(["status", "A._-1"], baseEnv, "status after conflict");
  assert(afterConflict.amount_cents === 1000, "conflict changed amount");

  await refused(["record", "bad id", "1000"], baseEnv, "bad_id", "bad id");
  await refused(["record", "ok", "01"], baseEnv, "bad_amount", "leading zero");
  await refused(["record", "ok", "0"], baseEnv, "bad_amount", "zero amount");
  await refused(["record", "ok"], baseEnv, "bad_args", "too few");
  await refused(["cancel", "missing"], baseEnv, "unknown_order", "unknown cancel");
  await refused(["nope"], baseEnv, "bad_args", "unknown command");

  const status = await ok(["status", "A._-1"], baseEnv, "status restart");
  assert(status.amount_cents === 1000 && status.shipment === "open", "restart lost record");

  const marker = join(baseEnv.STATE_DIR, "unrelated.txt");
  writeFileSync(marker, "keep-me");
  await ok(["ship", "A._-1"], baseEnv, "ship");
  await ok(["ship", "A._-1"], baseEnv, "ship again");
  const shipped = await ok(["status", "A._-1"], baseEnv, "shipped status");
  assert(shipped.shipment === "shipped" && shipped.refund === "none", "ship view");
  assert(readFileSync(marker, "utf8") === "keep-me", "unrelated file changed");
  const beforeTraffic = await traffic(stub.control_url);
  await refused(["cancel", "A._-1"], baseEnv, "shipped", "cancel shipped");
  const afterTraffic = await traffic(stub.control_url);
  assert(afterTraffic.requests.length === beforeTraffic.requests.length, "shipped cancel contacted provider");
  const stillShipped = await ok(["status", "A._-1"], baseEnv, "still shipped");
  assert(stillShipped.shipment === "shipped" && stillShipped.refund === "none", "shipped cancel mutated refund");

  await ok(["record", "B", "2500"], baseEnv, "record B");
  const cancelled = await ok(["cancel", "B"], baseEnv, "cancel B");
  assert(cancelled.refund === "refunded" && cancelled.refunded_cents === 2500 && cancelled.shipment === "open", "cancel view");
  assert(typeof cancelled.refund_id === "string" && cancelled.refund_id.length > 0, "refund id missing");
  const provider = await effects(stub.control_url);
  assert(provider.count === 1, `expected one effect, got ${provider.count}`);
  assert(provider.effects[0].order_id === "B" && provider.effects[0].amount_cents === 2500 && provider.effects[0].refund_id === cancelled.refund_id, "effect mismatch");
  const second = await ok(["cancel", "B"], baseEnv, "cancel again");
  assert(second.refund_id === cancelled.refund_id && second.refunded_cents === 2500, "second cancel changed refund");
  const provider2 = await effects(stub.control_url);
  assert(provider2.count === 1, "second cancel added an effect");
  const posts = (await traffic(stub.control_url)).requests.filter((row) => row.method === "POST");
  assert(posts.length === 1, `expected one POST, got ${posts.length}`);
  const other = await ok(["status", "A._-1"], baseEnv, "A independent");
  assert(other.shipment === "shipped" && other.refund === "none", "orders were not independent");

  await refused(["ship", "B"], baseEnv, "refund_open", "ship after refund");

  const crashDir = join(root, "crash");
  const crashEnv = { STATE_DIR: crashDir, SERVICE_URL: stub.service_url };
  await ok(["record", "C", "400"], crashEnv, "record C");
  await killed(["cancel", "C"], { ...crashEnv, CRASH_AT: "after-attempt-saved-before-request" }, "crash before request");
  const saved = await ok(["status", "C"], crashEnv, "status after crash before request");
  assert(saved.refund === "attempt_saved" && saved.refund_id, "attempt not saved");
  const countAfterCrash = (await effects(stub.control_url)).count;
  assert(countAfterCrash === 1, "crash before request counted an effect");
  const reconciled = await ok(["reconcile", "C"], crashEnv, "reconcile not sent");
  assert(reconciled.outcome === "not_sent" && reconciled.refund === "attempt_saved" && reconciled.refund_id === saved.refund_id, "reconcile not_sent");
  const postsAfter = (await traffic(stub.control_url)).requests.filter((row) => row.method === "POST").length;
  assert(postsAfter === 1, "reconcile posted");
  assert((await effects(stub.control_url)).count === 1, "reconcile added an effect");
  const resumed = await ok(["cancel", "C"], crashEnv, "resume after crash before request");
  assert(resumed.refund === "refunded" && resumed.refund_id === saved.refund_id && resumed.refunded_cents === 400, "resume refund id");
  assert((await effects(stub.control_url)).count === 2, "resume did not count exactly one new effect");
  const onlyC = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "C");
  assert(onlyC.length === 1 && onlyC[0].refund_id === saved.refund_id, "C effect id changed");

  const acceptDir = join(root, "accept");
  const acceptEnv = { STATE_DIR: acceptDir, SERVICE_URL: stub.service_url };
  await ok(["record", "D", "700"], acceptEnv, "record D");
  await killed(["cancel", "D"], { ...acceptEnv, CRASH_AT: "after-accept-before-record" }, "crash after accept");
  const pending = await ok(["status", "D"], acceptEnv, "status after accept crash");
  assert(pending.refund === "attempt_saved" && pending.refund_id, "accept crash lost attempt");
  const dEffects = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "D");
  assert(dEffects.length === 1 && dEffects[0].refund_id === pending.refund_id, "accept crash effect");
  const recovered = await ok(["cancel", "D"], acceptEnv, "recover accept crash");
  assert(recovered.refund === "refunded" && recovered.refund_id === pending.refund_id && recovered.refunded_cents === 700, "recover refunded");
  const dEffects2 = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "D");
  assert(dEffects2.length === 1, "recover added an effect");

  const doneDir = join(root, "done");
  const doneEnv = { STATE_DIR: doneDir, SERVICE_URL: stub.service_url };
  await ok(["record", "E", "80"], doneEnv, "record E");
  await killed(["cancel", "E"], { ...doneEnv, CRASH_AT: "after-record-before-exit" }, "crash after record");
  const durable = await ok(["status", "E"], doneEnv, "status after record crash");
  assert(durable.refund === "refunded" && durable.refunded_cents === 80 && durable.refund_id, "record crash not durable");
  const beforeE = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "E").length;
  const againE = await ok(["cancel", "E"], doneEnv, "cancel after record crash");
  assert(againE.refund === "refunded" && againE.refund_id === durable.refund_id, "later cancel changed refund");
  const afterE = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "E").length;
  assert(beforeE === 1 && afterE === 1, "later cancel added an effect");

  await fault(stub.control_url, { drop_reply: true });
  const lostDir = join(root, "lost");
  const lostEnv = { STATE_DIR: lostDir, SERVICE_URL: stub.service_url };
  await ok(["record", "F", "55"], lostEnv, "record F");
  await refused(["cancel", "F"], lostEnv, "unavailable", "lost reply");
  const lostStatus = await ok(["status", "F"], lostEnv, "status lost reply");
  assert(lostStatus.refund === "attempt_saved" && lostStatus.refund_id, "lost reply dropped attempt");
  const fCount = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "F");
  assert(fCount.length === 1 && fCount[0].refund_id === lostStatus.refund_id, "lost reply effect");
  await fault(stub.control_url, { drop_reply: false });
  const reconciledLost = await ok(["reconcile", "F"], lostEnv, "reconcile lost reply");
  assert(reconciledLost.outcome === "refunded" && reconciledLost.refund === "refunded" && reconciledLost.refund_id === lostStatus.refund_id, "lost reply reconcile");
  assert(reconciledLost.refunded_cents === 55, "lost reply amount");
  const fCount2 = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "F").length;
  assert(fCount2 === 1, "reconcile lost reply added an effect");

  await fault(stub.control_url, { status_5xx: true });
  const fiveDir = join(root, "five");
  const fiveEnv = { STATE_DIR: fiveDir, SERVICE_URL: stub.service_url };
  await ok(["record", "G", "15"], fiveEnv, "record G");
  await refused(["cancel", "G"], fiveEnv, "unavailable", "http 500");
  const fiveStatus = await ok(["status", "G"], fiveEnv, "status 500");
  assert(fiveStatus.refund === "attempt_saved", "500 cleared attempt");
  assert((await effects(stub.control_url)).effects.filter((row) => row.order_id === "G").length === 0, "500 stored an effect");
  await fault(stub.control_url, { status_5xx: false });
  const fiveDone = await ok(["cancel", "G"], fiveEnv, "retry after 500");
  assert(fiveDone.refund === "refunded" && fiveDone.refund_id === fiveStatus.refund_id, "retry after 500 changed id");

  const na = await ok(["reconcile", "A._-1"], baseEnv, "reconcile shipped");
  assert(na.outcome === "not_applicable" && na.refund === "none" && na.refund_id === null, "not applicable");

  const conflictDir = join(root, "conflict");
  const conflictEnv = { STATE_DIR: conflictDir, SERVICE_URL: stub.service_url };
  await ok(["record", "H", "90"], conflictEnv, "record H");
  await killed(["cancel", "H"], { ...conflictEnv, CRASH_AT: "after-attempt-saved-before-request" }, "crash H");
  const h = await ok(["status", "H"], conflictEnv, "status H");
  const planted = await fetch(stub.service_url + "/v1/refunds", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ refund_id: h.refund_id, order_id: "H", amount_cents: 91, currency: "USD" }),
  });
  assert(planted.status === 200, "plant conflict refund failed");
  await refused(["cancel", "H"], conflictEnv, "conflict", "lookup conflict");
  const h2 = await ok(["status", "H"], conflictEnv, "status after conflict lookup");
  assert(h2.refund === "attempt_saved" && h2.refund_id === h.refund_id, "conflict lookup changed attempt");
  await refused(["reconcile", "H"], conflictEnv, "conflict", "reconcile conflict");

  const deadEnv = { STATE_DIR: join(root, "dead"), SERVICE_URL: "http://127.0.0.1:9" };
  await ok(["record", "I", "10"], deadEnv, "record without provider");
  await refused(["cancel", "I"], deadEnv, "unavailable", "provider down");
  const i = await ok(["status", "I"], deadEnv, "status provider down");
  assert(i.refund === "attempt_saved" && i.refund_id, "provider down lost attempt");
  await refused(["reconcile", "I"], deadEnv, "unavailable", "reconcile down");
  const i2 = await ok(["status", "I"], deadEnv, "status after reconcile down");
  assert(i2.refund === "attempt_saved" && i2.refund_id === i.refund_id, "reconcile down changed attempt");

  const maxId = "Z".repeat(64);
  await ok(["record", maxId, "100000000"], baseEnv, "max record");
  await refused(["record", "Z".repeat(65), "1"], baseEnv, "bad_id", "id too long");

  console.log("ok");
} catch (err) {
  failures += 1;
  console.error(err);
  process.exitCode = 1;
} finally {
  stub.child.kill("SIGTERM");
  rmSync(root, { recursive: true, force: true });
}
if (failures) process.exit(1);
