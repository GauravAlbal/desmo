# Paid-order cancellation desk

Local desk that records a paid order and refunds it once through the payment provider. Lifecycle rules and their durable records live in the Ikaros machine `machines/paid_order.ik.toml`. `./run` is the only operator interface.

## Setup

Node 22 is required. From this directory, with network access to the npm registry unavailable:

```sh
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x ./run
```

`./run` uses `/Users/galbal/.nvm/versions/node/v22.17.1/bin/node` when that binary exists, otherwise `node` on `PATH`.

## Run

```sh
export STATE_DIR=/tmp/desk-state
export SERVICE_URL=http://127.0.0.1:9
./run record ORDER-1 1000
./run status ORDER-1
./run ship ORDER-1
./run cancel ORDER-1
./run reconcile ORDER-1
```

Each invocation prints one JSON object on stdout. Exit 0 is success. A refusal is a nonzero exit and `{"error":"<code>"}`.

The payment provider is `stub/server.mjs`. It prints `service_url` and `control_url` on startup. Point `SERVICE_URL` at `service_url`.

Optional `CRASH_AT` kills the process with `SIGKILL` at one named boundary: `after-attempt-saved-before-request`, `after-accept-before-record`, or `after-record-before-exit`.

## Tests

```sh
node test/desk.test.mjs
```

The test starts the stub itself.
