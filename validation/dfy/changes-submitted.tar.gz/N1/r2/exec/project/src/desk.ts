import { createHash, randomBytes } from "node:crypto";
import { closeSync, existsSync, fsyncSync, mkdirSync, openSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Aggregate,
  HistoricalResult,
  Kernel,
  KernelError,
  StoreNotFoundError,
} from "@ikaros/runtime";

const MACHINE_PATH = fileURLToPath(new URL("../machines/paid_order.ik.toml", import.meta.url));
const STORE_NAME = "paid-order.sqlite";
const MAX_AMOUNT = 100_000_000;

type Json = null | boolean | number | string | Json[] | { [key: string]: Json };
type Line = {
  line_id: string;
  price_cents: number;
  refund: "none" | "pending" | "refunded";
};
type OrderView = {
  order_id: string;
  amount_cents: number;
  currency: "USD";
  shipment: "open" | "shipped";
  refund: "none" | "attempt_saved" | "refunded";
  refund_id: string | null;
  refunded_cents: number;
  cap_cents: number;
  lines: Line[];
};

function finish(status: number, body: Json): never {
  process.stdout.write(JSON.stringify(body) + "\n");
  process.exit(status);
}

function refuse(error: string): never {
  finish(1, { error });
}

function crash(boundary: string): void {
  if (process.env.CRASH_AT === boundary) {
    process.kill(process.pid, "SIGKILL");
  }
}

function validId(value: string): boolean {
  return /^[A-Za-z0-9._-]{1,64}$/.test(value);
}

function parseAmount(raw: string): number | null {
  if (!/^[1-9][0-9]*$/.test(raw)) return null;
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value < 1 || value > MAX_AMOUNT) return null;
  return value;
}

function flushPath(path: string): void {
  if (!existsSync(path)) return;
  const fd = openSync(path, "r+");
  try {
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
}

function flushStore(storePath: string): void {
  flushPath(storePath);
  flushPath(storePath + "-wal");
  const dir = join(storePath, "..");
  if (existsSync(dir)) {
    const fd = openSync(dir, "r");
    try {
      fsyncSync(fd);
    } finally {
      closeSync(fd);
    }
  }
}

function asAggregate(value: Aggregate | HistoricalResult, fallback: Aggregate): Aggregate {
  return value instanceof Aggregate ? value : fallback;
}

function factNumber(state: { [key: string]: Json }, key: string): number {
  const value = state[key];
  return typeof value === "number" ? value : Number(value);
}

function factString(state: { [key: string]: Json }, key: string): string {
  const value = state[key];
  return typeof value === "string" ? value : "";
}

function linesOf(state: { [key: string]: Json }): Line[] {
  const raw = factString(state, "lines_json");
  if (raw === "") return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    return Array.isArray(parsed) ? parsed as Line[] : [];
  } catch {
    return [];
  }
}

function attemptLinesOf(state: { [key: string]: Json }): Set<string> {
  try {
    const parsed = JSON.parse(factString(state, "attempt_lines")) as unknown;
    return Array.isArray(parsed) ? new Set(parsed.filter((v): v is string => typeof v === "string")) : new Set();
  } catch {
    return new Set();
  }
}

function viewOf(orderId: string, aggregate: Aggregate): OrderView {
  const state = aggregate.state as { [key: string]: Json };
  const named = aggregate.namedState();
  const amount = factNumber(state, "amount_cents");
  const attemptRefundId = factString(state, "attempt_refund_id");
  const refundId = attemptRefundId === "" || attemptRefundId === "__none__" ? factString(state, "refund_id") : attemptRefundId;
  const lines = linesOf(state);
  const pending = attemptLinesOf(state);
  for (const line of lines) if (pending.has(line.line_id)) line.refund = "pending";
  return {
    order_id: orderId,
    amount_cents: amount,
    currency: "USD",
    shipment: named === "shipped" ? "shipped" : "open",
    refund: named === "attempting" ? "attempt_saved" : named === "refunded" ? "refunded" : "none",
    refund_id: refundId === "" ? null : refundId,
    refunded_cents: factNumber(state, "refunded_cents"),
    cap_cents: factNumber(state, "cap_cents") || amount,
    lines,
  };
}

function reconcileView(view: OrderView, outcome: "not_sent" | "refunded" | "not_applicable"): Json {
  return {
    order_id: view.order_id,
    refund: view.refund,
    refund_id: view.refund_id,
    outcome,
    amount_cents: view.amount_cents,
    refunded_cents: view.refunded_cents,
  };
}

class Desk {
  private readonly kernel: Kernel;
  private readonly storePath: string;
  private readonly serviceUrl: string;
  private machinePromise: ReturnType<Kernel["machine"]> | null = null;

  constructor(storePath: string, serviceUrl: string) {
    this.storePath = storePath;
    this.serviceUrl = serviceUrl;
    this.kernel = new Kernel(storePath);
  }

  private machine() {
    if (!this.machinePromise) this.machinePromise = this.kernel.machine(MACHINE_PATH);
    return this.machinePromise;
  }

  private async show(orderId: string): Promise<Aggregate | null> {
    const machine = await this.machine();
    try {
      return await machine.show(orderId);
    } catch (err) {
      if (err instanceof StoreNotFoundError) return null;
      if (err instanceof KernelError && err.rule === "aggregate.not_found") return null;
      throw err;
    }
  }

  private async commitRefunded(aggregate: Aggregate, outcomeDigest: string): Promise<Aggregate> {
    const machine = await this.machine();
    let current = aggregate;
    if (current.effect.status === "pending" && current.pendingIntent) {
      const recorded = await current.recordEffectOutcome(outcomeDigest);
      current = asAggregate(recorded, current);
      if (!(recorded instanceof Aggregate)) current = await machine.show(aggregate.id);
      flushStore(this.storePath);
    }
    if (current.namedState() !== "refunded") {
      const state = current.state as { [key: string]: Json };
      const done = await current.command("complete_refund", {
        refund_id: factString(state, "attempt_refund_id"),
        amount_cents: factNumber(state, "amount_cents"),
        clear_refund_id: "",
        clear_amount: 0,
        clear_lines: "",
      });
      current = done;
      flushStore(this.storePath);
    }
    if (current.namedState() !== "refunded") {
      throw new Error("refunded outcome was not committed");
    }
    return current;
  }

  async record(orderId: string, amount: number): Promise<never> {
    const existing = await this.show(orderId);
    if (existing) {
      const stored = factNumber(existing.state as { [key: string]: Json }, "amount_cents");
      if (stored !== amount) refuse("conflict");
      finish(0, viewOf(orderId, existing) as unknown as Json);
    }
    mkdirSync(join(this.storePath, ".."), { recursive: true });
    const machine = await this.machine();
    const created = await machine.createWith({
      aggregateId: orderId,
      command: { name: "admit", args: { amount_cents: amount, currency: "USD" } },
    });
    const aggregate = created instanceof Aggregate ? created : await machine.show(orderId);
    flushStore(this.storePath);
    finish(0, viewOf(orderId, aggregate) as unknown as Json);
  }

  async ship(orderId: string): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    const named = existing.namedState();
    if (named === "attempting" || named === "refunded") {
      try {
        await existing.command("ship");
      } catch (err) {
        if (err instanceof KernelError) refuse("refund_open");
        throw err;
      }
      refuse("refund_open");
    }
    const shipped = await existing.command("ship");
    flushStore(this.storePath);
    finish(0, viewOf(orderId, shipped) as unknown as Json);
  }

  async status(orderId: string): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    finish(0, viewOf(orderId, existing) as unknown as Json);
  }

  async attach(orderId: string, linesPath: string): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    let input: unknown;
    try {
      input = JSON.parse(readFileSync(linesPath, "utf8"));
    } catch {
      refuse("bad_lines");
    }
    if (!input || typeof input !== "object" || Array.isArray(input)) refuse("bad_lines");
    const body = input as { cap_cents?: unknown; lines?: unknown };
    const state = existing.state as { [key: string]: Json };
    const stored = linesOf(state);
    const cap = body.cap_cents;
    const rawLines = body.lines;
    if (!Number.isSafeInteger(cap) || (cap as number) < 1 || (cap as number) > factNumber(state, "amount_cents") ||
      !Array.isArray(rawLines) || rawLines.length < 1 || rawLines.length > 20) refuse("bad_lines");
    const lines: Line[] = [];
    const ids = new Set<string>();
    let total = 0;
    for (const raw of rawLines) {
      if (!raw || typeof raw !== "object" || Array.isArray(raw)) refuse("bad_lines");
      const item = raw as { line_id?: unknown; price_cents?: unknown };
      if (typeof item.line_id !== "string" || !/^[A-Za-z0-9._-]{1,32}$/.test(item.line_id) ||
        ids.has(item.line_id) || !Number.isSafeInteger(item.price_cents) ||
        (item.price_cents as number) < 1 || (item.price_cents as number) > MAX_AMOUNT) refuse("bad_lines");
      ids.add(item.line_id);
      total += item.price_cents as number;
      lines.push({ line_id: item.line_id, price_cents: item.price_cents as number, refund: "none" });
    }
    if (total !== factNumber(state, "amount_cents")) refuse("bad_lines");
    const named = existing.namedState();
    if (named === "shipped") refuse("shipped");
    if (named === "attempting" || named === "refunded") refuse("refund_open");
    if (stored.length > 0) {
      if (factNumber(state, "cap_cents") === cap &&
        JSON.stringify(stored.map(({ line_id, price_cents }) => ({ line_id, price_cents }))) ===
        JSON.stringify(lines.map(({ line_id, price_cents }) => ({ line_id, price_cents })))) {
        finish(0, { order_id: orderId, cap_cents: cap, lines: stored } as unknown as Json);
      }
      refuse("conflict");
    }
    const attached = await existing.command("attach_lines", { cap_cents: cap, lines_json: JSON.stringify(lines) });
    flushStore(this.storePath);
    finish(0, { order_id: orderId, cap_cents: cap, lines } as unknown as Json);
  }

  async refund(orderId: string, selectedIds: string[]): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    const state = existing.state as { [key: string]: Json };
    const lines = linesOf(state);
    if (lines.length === 0) refuse("not_attached");
    const seen = new Set<string>();
    if (selectedIds.some((id) => seen.has(id) || (seen.add(id), false))) refuse("unknown_line");
    const selected = lines.filter((line) => selectedIds.includes(line.line_id));
    if (selected.length !== selectedIds.length) refuse("unknown_line");
    const named = existing.namedState();
    if (named === "shipped" && named !== "attempting") refuse("shipped");
    if (selected.some((line) => line.refund === "refunded")) refuse("already_refunded");
    const attempt = factString(state, "attempt_lines");
    const attemptIds = attempt === "" || attempt === "__none__" || attempt === "__full__" ? [] : JSON.parse(attempt) as string[];
    if (named === "attempting") {
      if (JSON.stringify(attemptIds) !== JSON.stringify(selectedIds)) refuse("refund_open");
      if (!this.serviceUrl) refuse("unavailable");
      return await this.retryLine(existing);
    }
    const amount = selected.reduce((sum, line) => sum + line.price_cents, 0);
    if (factNumber(state, "refunded_cents") + amount > factNumber(state, "cap_cents")) refuse("over_cap");
    if (!this.serviceUrl) refuse("unavailable");
    const refundId = randomBytes(16).toString("hex");
    const current = await existing.command("save_line_attempt", {
      refund_id: refundId, effect_id: refundId, payload_digest: payloadDigest(orderId, amount, refundId),
      idempotency_key: refundId, amount_cents: amount, lines_json: JSON.stringify(selectedIds),
    });
    flushStore(this.storePath);
    crash("after-attempt-saved-before-request");
    await this.postLineAndCommit(current);
  }

  private async retryLine(aggregate: Aggregate): Promise<never> {
    const lookup = await this.lookup(aggregate);
    if (lookup.kind === "accepted") {
      const committed = await this.commitLineRefunded(aggregate, lookup.digest);
      crash("after-record-before-exit");
      finish(0, viewOf(aggregate.id, committed) as unknown as Json);
    }
    if (lookup.kind === "mismatch") refuse("conflict");
    if (lookup.kind === "absent") await this.postLineAndCommit(aggregate);
    refuse("unavailable");
  }

  private async commitLineRefunded(aggregate: Aggregate, outcomeDigest: string): Promise<Aggregate> {
    let current = aggregate;
    if (current.effect.status === "pending" && current.pendingIntent) {
      const recorded = await current.recordEffectOutcome(outcomeDigest);
      current = asAggregate(recorded, current);
      if (!(recorded instanceof Aggregate)) current = await (await this.machine()).show(aggregate.id);
      flushStore(this.storePath);
    }
    if (current.namedState() === "attempting") {
      const state = current.state as { [key: string]: Json };
      const lines = linesOf(state);
      const selected = attemptLinesOf(state);
      const updated = lines.map((line) => selected.has(line.line_id) ? { ...line, refund: "refunded" as const } : line);
      const done = await current.command("complete_line_refund", {
        refund_id: factString(state, "attempt_refund_id"),
        amount_cents: factNumber(state, "attempt_amount"),
        refunded_cents: factNumber(state, "refunded_cents") + factNumber(state, "attempt_amount"),
        lines_json: JSON.stringify(updated),
        clear_refund_id: "",
        clear_amount: 0,
        clear_lines: "",
      });
      current = done;
      flushStore(this.storePath);
    }
    return current;
  }

  async cancel(orderId: string): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    const attachedLines = linesOf(existing.state as { [key: string]: Json });
    if (attachedLines.length > 0) {
      const named = existing.namedState();
      if (named === "attempting") return await this.retryLine(existing);
      if (attachedLines.every((line) => line.refund === "refunded")) {
        finish(0, viewOf(orderId, existing) as unknown as Json);
      }
      if (named === "shipped") refuse("shipped");
      const state = existing.state as { [key: string]: Json };
      const remaining = attachedLines.filter((line) => line.refund !== "refunded");
      const amount = remaining.reduce((sum, line) => sum + line.price_cents, 0);
      if (factNumber(state, "refunded_cents") + amount > factNumber(state, "cap_cents")) refuse("over_cap");
      if (!this.serviceUrl) refuse("unavailable");
      return await this.refund(orderId, remaining.map((line) => line.line_id));
    }
    const named = existing.namedState();
    if (named === "refunded") finish(0, viewOf(orderId, existing) as unknown as Json);
    if (named === "shipped") refuse("shipped");
    if (!this.serviceUrl) refuse("unavailable");

    let current = existing;
    if (named === "open") {
      const refundId = randomBytes(16).toString("hex");
      const state = existing.state as { [key: string]: Json };
      const amount = factNumber(state, "amount_cents");
      const digest = payloadDigest(orderId, amount, refundId);
      current = await existing.command("save_attempt", {
        refund_id: refundId,
        effect_id: refundId,
        payload_digest: digest,
        idempotency_key: refundId,
        amount_cents: amount,
        attempt_lines: "__full__",
      });
      flushStore(this.storePath);
      crash("after-attempt-saved-before-request");
      await this.postAndCommit(current);
    }

    if (current.namedState() !== "attempting") {
      throw new Error("cancel left an unexpected state");
    }
    const lookup = await this.lookup(current);
    if (lookup.kind === "accepted") {
      const committed = await this.commitRefunded(current, lookup.digest);
      crash("after-record-before-exit");
      finish(0, viewOf(orderId, committed) as unknown as Json);
    }
    if (lookup.kind === "mismatch") refuse("conflict");
    if (lookup.kind === "absent") {
      await this.postAndCommit(current);
    }
    refuse("unavailable");
  }

  async reconcile(orderId: string): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    const named = existing.namedState();
    if (named === "refunded") {
      finish(0, reconcileView(viewOf(orderId, existing), "refunded"));
    }
    if (named !== "attempting") {
      finish(0, reconcileView(viewOf(orderId, existing), "not_applicable"));
    }
    if (!this.serviceUrl) refuse("unavailable");
    const lookup = await this.lookup(existing);
    if (lookup.kind === "accepted") {
      const state = existing.state as { [key: string]: Json };
      const committed = factString(state, "attempt_lines") === "__full__"
        ? await this.commitRefunded(existing, lookup.digest)
        : await this.commitLineRefunded(existing, lookup.digest);
      crash("after-record-before-exit");
      finish(0, reconcileView(viewOf(orderId, committed), "refunded"));
    }
    if (lookup.kind === "absent") {
      finish(0, reconcileView(viewOf(orderId, existing), "not_sent"));
    }
    if (lookup.kind === "mismatch") refuse("conflict");
    refuse("unavailable");
  }

  private async postAndCommit(aggregate: Aggregate): Promise<never> {
    const state = aggregate.state as { [key: string]: Json };
    const refundId = factString(state, "attempt_refund_id");
    const amount = factNumber(state, "amount_cents");
    const orderId = aggregate.id;
    const posted = await postRefund(this.serviceUrl, {
      refund_id: refundId, order_id: orderId, amount_cents: amount, currency: "USD",
    });
    if (posted.kind === "unavailable") refuse("unavailable");
    if (posted.kind === "mismatch") refuse("conflict");
    crash("after-accept-before-record");
    const committed = await this.commitRefunded(aggregate, posted.digest);
    crash("after-record-before-exit");
    finish(0, viewOf(orderId, committed) as unknown as Json);
  }

  private async postLineAndCommit(aggregate: Aggregate): Promise<never> {
    const state = aggregate.state as { [key: string]: Json };
    const refundId = factString(state, "attempt_refund_id");
    const amount = factNumber(state, "attempt_amount");
    const posted = await postRefund(this.serviceUrl, {
      refund_id: refundId, order_id: aggregate.id, amount_cents: amount, currency: "USD",
    });
    if (posted.kind === "unavailable") refuse("unavailable");
    if (posted.kind === "mismatch") refuse("conflict");
    crash("after-accept-before-record");
    const committed = await this.commitLineRefunded(aggregate, posted.digest);
    crash("after-record-before-exit");
    finish(0, viewOf(aggregate.id, committed) as unknown as Json);
  }

  private async lookup(aggregate: Aggregate): Promise<Lookup> {
    const state = aggregate.state as { [key: string]: Json };
    const refundId = factString(state, "attempt_refund_id");
    const amount = factString(state, "attempt_lines") === "" ? factNumber(state, "amount_cents") : factNumber(state, "attempt_amount");
    return getRefund(this.serviceUrl, refundId, aggregate.id, amount);
  }
}

type Lookup =
  | { kind: "accepted"; digest: string }
  | { kind: "absent" }
  | { kind: "mismatch" }
  | { kind: "unavailable" };

function payloadDigest(orderId: string, amount: number, refundId: string): string {
  const body = JSON.stringify({
    amount_cents: amount,
    currency: "USD",
    order_id: orderId,
    refund_id: refundId,
  });
  return createHash("sha256").update(body).digest("hex");
}

function digestOf(body: string): string {
  return createHash("sha256").update(body).digest("hex");
}

function matchesAcceptance(
  parsed: Json,
  refundId: string,
  orderId: string,
  amount: number,
): "match" | "mismatch" | "malformed" {
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return "malformed";
  const body = parsed as { [key: string]: Json };
  const sameOrder = body.order_id === orderId;
  const sameAmount = body.amount_cents === amount;
  const sameId = body.refund_id === refundId;
  const sameCurrency = body.currency === "USD";
  const refunded = body.outcome === "refunded";
  if (sameId && sameOrder && sameAmount && sameCurrency && refunded) return "match";
  if (body.order_id !== undefined && !sameOrder) return "mismatch";
  if (body.amount_cents !== undefined && !sameAmount) return "mismatch";
  if (body.refund_id !== undefined && !sameId) return "mismatch";
  if (body.currency !== undefined && !sameCurrency) return "mismatch";
  return "malformed";
}

async function readHttp(response: Response): Promise<{ status: number; text: string } | null> {
  try {
    const text = await response.text();
    return { status: response.status, text };
  } catch {
    return null;
  }
}

async function getRefund(serviceUrl: string, refundId: string, orderId: string, amount: number): Promise<Lookup> {
  let response: Response;
  try {
    response = await fetch(serviceUrl + "/v1/refunds/" + refundId, {
      method: "GET",
      redirect: "error",
    });
  } catch {
    return { kind: "unavailable" };
  }
  const read = await readHttp(response);
  if (!read) return { kind: "unavailable" };
  if (read.status === 404) return { kind: "absent" };
  if (read.status !== 200) return { kind: "unavailable" };
  let parsed: Json;
  try {
    parsed = JSON.parse(read.text) as Json;
  } catch {
    return { kind: "unavailable" };
  }
  const match = matchesAcceptance(parsed, refundId, orderId, amount);
  if (match === "match") return { kind: "accepted", digest: digestOf(read.text) };
  if (match === "mismatch") return { kind: "mismatch" };
  return { kind: "unavailable" };
}

async function postRefund(
  serviceUrl: string,
  body: { refund_id: string; order_id: string; amount_cents: number; currency: "USD" },
): Promise<Lookup> {
  let response: Response;
  try {
    response = await fetch(serviceUrl + "/v1/refunds", {
      method: "POST",
      redirect: "error",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch {
    return { kind: "unavailable" };
  }
  const read = await readHttp(response);
  if (!read) return { kind: "unavailable" };
  if (read.status === 500) return { kind: "unavailable" };
  if (read.status === 409) return { kind: "mismatch" };
  if (read.status !== 200) return { kind: "unavailable" };
  let parsed: Json;
  try {
    parsed = JSON.parse(read.text) as Json;
  } catch {
    return { kind: "unavailable" };
  }
  const match = matchesAcceptance(parsed, body.refund_id, body.order_id, body.amount_cents);
  if (match === "match") return { kind: "accepted", digest: digestOf(read.text) };
  if (match === "mismatch") return { kind: "mismatch" };
  return { kind: "unavailable" };
}

async function main(): Promise<void> {
  const argv = process.argv.slice(2);
  const command = argv[0];
  if (!command) refuse("bad_args");
  const stateDir = process.env.STATE_DIR;
  if (!stateDir) refuse("bad_args");
  const serviceUrl = process.env.SERVICE_URL ?? "";
  const desk = new Desk(join(stateDir, STORE_NAME), serviceUrl);

  if (command === "record") {
    if (argv.length !== 3) refuse("bad_args");
    const orderId = argv[1];
    if (!validId(orderId)) refuse("bad_id");
    const amount = parseAmount(argv[2]);
    if (amount === null) refuse("bad_amount");
    await desk.record(orderId, amount);
  }
  if (command === "attach") {
    if (argv.length !== 3) refuse("bad_args");
    if (!validId(argv[1])) refuse("bad_id");
    await desk.attach(argv[1], argv[2]);
  }
  if (command === "refund") {
    if (argv.length < 3) refuse("bad_args");
    if (!validId(argv[1]) || argv.slice(2).some((id) => !validId(id))) refuse("bad_id");
    await desk.refund(argv[1], argv.slice(2));
  }
  if (command === "ship" || command === "cancel" || command === "status" || command === "reconcile") {
    if (argv.length !== 2) refuse("bad_args");
    const orderId = argv[1];
    if (!validId(orderId)) refuse("bad_id");
    if (command === "ship") await desk.ship(orderId);
    if (command === "cancel") await desk.cancel(orderId);
    if (command === "status") await desk.status(orderId);
    await desk.reconcile(orderId);
  }
  refuse("bad_args");
}

main().catch((err: unknown) => {
  const detail = err instanceof Error ? err.message : String(err);
  finish(1, { error: "internal", detail });
});
