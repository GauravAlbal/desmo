import { createHash, randomBytes } from "node:crypto";
import { closeSync, existsSync, fsyncSync, mkdirSync, openSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Aggregate,
  HistoricalResult,
  Kernel,
  KernelError,
  Machine,
  StoreNotFoundError,
} from "@ikaros/runtime";

const MACHINE_PATH = fileURLToPath(new URL("../machines/paid_order.ik.toml", import.meta.url));
const STORE_NAME = "paid-order.sqlite";
const MAX_AMOUNT = 100_000_000;
const MAX_LINES = 20;

type Json = null | boolean | number | string | Json[] | { [key: string]: Json };

type LineView = {
  line_id: string;
  price_cents: number;
  refund: "none" | "pending" | "refunded";
};

type OrderView = {
  order_id: string;
  amount_cents: number;
  currency: "USD";
  shipment: "open" | "shipped";
  refund: "none" | "attempt_saved" | "refunded";
  refund_id: string | null;
  refunded_cents: number;
  cap_cents: number;
  lines: LineView[];
};

function finish(status: number, body: Json): never {
  process.stdout.write(JSON.stringify(body) + "\n");
  process.exit(status);
}

function refuse(error: string): never {
  finish(1, { error });
}

function crash(boundary: string): void {
  if (process.env.CRASH_AT === boundary) {
    process.kill(process.pid, "SIGKILL");
  }
}

function validId(value: string): boolean {
  return /^[A-Za-z0-9._-]{1,64}$/.test(value);
}

function validLineId(value: unknown): value is string {
  return typeof value === "string" && /^[A-Za-z0-9._-]{1,32}$/.test(value);
}

function parseAmount(raw: string): number | null {
  if (!/^[1-9][0-9]*$/.test(raw)) return null;
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value < 1 || value > MAX_AMOUNT) return null;
  return value;
}

function flushPath(path: string): void {
  if (!existsSync(path)) return;
  const fd = openSync(path, "r+");
  try {
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
}

function flushStore(storePath: string): void {
  flushPath(storePath);
  flushPath(storePath + "-wal");
  const dir = join(storePath, "..");
  if (existsSync(dir)) {
    const fd = openSync(dir, "r");
    try {
      fsyncSync(fd);
    } finally {
      closeSync(fd);
    }
  }
}

function factNumber(state: { [key: string]: Json }, key: string): number {
  const value = state[key];
  return typeof value === "number" ? value : Number(value);
}

function factString(state: { [key: string]: Json }, key: string): string {
  const value = state[key];
  return typeof value === "string" ? value : "";
}

function parseLines(raw: string): LineView[] {
  if (raw === "") return [];
  return JSON.parse(raw) as LineView[];
}

// Marks the selected line ids "pending" inside the stored lines snapshot, for
// the lines mode. Returns "" (no change needed) when this is the no-lines mode.
function markPending(existingLinesRaw: string, selectionIds: string[] | null): string {
  if (selectionIds === null) return "";
  const ids = new Set(selectionIds);
  const lines = parseLines(existingLinesRaw);
  const updated = lines.map((line) => (ids.has(line.line_id) ? { ...line, refund: "pending" as const } : line));
  return JSON.stringify(updated);
}

// Computes the host-side durable snapshot for a completed attempt: the new
// cumulative refunded_cents and the lines array with the attempt's lines
// flipped to "refunded". For the no-lines mode (attemptLinesRaw === ""),
// lines_json stays "" and refunded_cents becomes the full attempt amount.
function computeCompletion(
  existingLinesRaw: string,
  attemptLinesRaw: string,
  attemptAmount: number,
  priorRefundedCents: number,
): { linesJson: string; refundedCents: number } {
  if (attemptLinesRaw === "") {
    return { linesJson: "", refundedCents: priorRefundedCents + attemptAmount };
  }
  const attemptIds = new Set(JSON.parse(attemptLinesRaw) as string[]);
  const lines = parseLines(existingLinesRaw);
  const updated = lines.map((line) =>
    attemptIds.has(line.line_id) ? { ...line, refund: "refunded" as const } : line,
  );
  return { linesJson: JSON.stringify(updated), refundedCents: priorRefundedCents + attemptAmount };
}

type LinesFile = { cap_cents: number; lines: { line_id: string; price_cents: number }[] };

function parseLinesFile(raw: string, orderAmount: number): LinesFile | null {
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch {
    return null;
  }
  if (!data || typeof data !== "object" || Array.isArray(data)) return null;
  const obj = data as { [key: string]: unknown };
  const cap = obj.cap_cents;
  if (typeof cap !== "number" || !Number.isInteger(cap) || cap < 1 || cap > orderAmount) return null;
  const rawLines = obj.lines;
  if (!Array.isArray(rawLines) || rawLines.length < 1 || rawLines.length > MAX_LINES) return null;
  const seen = new Set<string>();
  const lines: { line_id: string; price_cents: number }[] = [];
  let sum = 0;
  for (const entry of rawLines) {
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) return null;
    const row = entry as { [key: string]: unknown };
    const lineId = row.line_id;
    const price = row.price_cents;
    if (!validLineId(lineId) || seen.has(lineId)) return null;
    seen.add(lineId);
    if (typeof price !== "number" || !Number.isInteger(price) || price < 1 || price > MAX_AMOUNT) return null;
    sum += price;
    lines.push({ line_id: lineId, price_cents: price });
  }
  if (sum !== orderAmount) return null;
  return { cap_cents: cap, lines };
}

// Unordered-multiset comparison of {line_id, price_cents} pairs: an attachment
// is "identical" regardless of the order lines appear in the source file.
function sameAttachment(storedLines: LineView[], storedCap: number, parsed: LinesFile): boolean {
  if (storedCap !== parsed.cap_cents) return false;
  if (storedLines.length !== parsed.lines.length) return false;
  const a = storedLines.map((line) => `${line.line_id}:${line.price_cents}`).sort();
  const b = parsed.lines.map((line) => `${line.line_id}:${line.price_cents}`).sort();
  return a.every((value, index) => value === b[index]);
}

function viewOf(orderId: string, aggregate: Aggregate): OrderView {
  const state = aggregate.state as { [key: string]: Json };
  const named = aggregate.namedState();
  const amount = factNumber(state, "amount_cents");
  const refundId = factString(state, "refund_id");
  const shipment = named === "shipped" ? "shipped" : "open";
  const refund: OrderView["refund"] = named === "attempting" ? "attempt_saved" : named === "refunded" ? "refunded" : "none";
  const refundedCents = factNumber(state, "refunded_cents");
  const linesRaw = factString(state, "lines_json");
  const hasLines = linesRaw !== "";
  const capCents = hasLines ? factNumber(state, "cap_cents") : amount;
  const lines = hasLines ? parseLines(linesRaw) : [];
  return {
    order_id: orderId,
    amount_cents: amount,
    currency: "USD",
    shipment,
    refund,
    refund_id: refund === "none" || refundId === "" ? null : refundId,
    refunded_cents: refundedCents,
    cap_cents: capCents,
    lines,
  };
}

function reconcileView(view: OrderView, outcome: "not_sent" | "refunded" | "not_applicable"): Json {
  return {
    order_id: view.order_id,
    refund: view.refund,
    refund_id: view.refund_id,
    outcome,
    amount_cents: view.amount_cents,
    refunded_cents: view.refunded_cents,
  };
}

class Desk {
  private readonly kernel: Kernel;
  private readonly storePath: string;
  private readonly serviceUrl: string;
  private machinePromise: Promise<Machine> | null = null;

  constructor(storePath: string, serviceUrl: string) {
    this.storePath = storePath;
    this.serviceUrl = serviceUrl;
    this.kernel = new Kernel(storePath);
  }

  private machine(): Promise<Machine> {
    if (!this.machinePromise) this.machinePromise = this.kernel.machine(MACHINE_PATH);
    return this.machinePromise;
  }

  private async show(orderId: string): Promise<Aggregate | null> {
    const machine = await this.machine();
    try {
      return await machine.show(orderId);
    } catch (err) {
      if (err instanceof StoreNotFoundError) return null;
      if (err instanceof KernelError && err.rule === "aggregate.not_found") return null;
      throw err;
    }
  }

  // Commits the terminal "refunded" outcome for the attempt currently open on
  // `aggregate`, recording the effect outcome digest first when one is still
  // pending. Idempotent: a repeat call on an already-settled aggregate is a
  // no-op that just returns it.
  private async commitRefunded(aggregate: Aggregate, outcomeDigest: string): Promise<Aggregate> {
    const machine = await this.machine();
    let current = aggregate;
    if (current.effect.status === "pending" && current.pendingIntent) {
      const recorded = await current.recordEffectOutcome(outcomeDigest);
      current = recorded instanceof Aggregate ? recorded : await machine.show(aggregate.id);
      flushStore(this.storePath);
    }
    if (current.namedState() !== "refunded") {
      const state = current.state as { [key: string]: Json };
      const refundId = factString(state, "refund_id");
      const attemptAmount = factNumber(state, "attempt_amount_cents");
      const attemptLinesRaw = factString(state, "attempt_lines_json");
      const priorRefundedCents = factNumber(state, "refunded_cents");
      const existingLinesRaw = factString(state, "lines_json");
      const { linesJson, refundedCents } = computeCompletion(
        existingLinesRaw,
        attemptLinesRaw,
        attemptAmount,
        priorRefundedCents,
      );
      const done = await current.command("complete_refund", {
        refund_id: refundId,
        attempt_amount_cents: attemptAmount,
        refunded_cents: refundedCents,
        lines_json: linesJson,
      });
      current = done;
      flushStore(this.storePath);
    }
    if (current.namedState() !== "refunded") {
      throw new Error("refunded outcome was not committed");
    }
    return current;
  }

  // Opens a new refund attempt for `selectionIds` (the no-lines whole-order
  // refund when `selectionIds` is null) and commits it before honoring the
  // pre-request crash boundary.
  private async startNewAttempt(
    existing: Aggregate,
    orderId: string,
    selectionIds: string[] | null,
    amount: number,
  ): Promise<Aggregate> {
    const refundId = randomBytes(16).toString("hex");
    const digest = payloadDigest(orderId, amount, refundId);
    const existingLinesRaw = factString(existing.state as { [key: string]: Json }, "lines_json");
    const attemptLinesJson = selectionIds === null ? "" : JSON.stringify(selectionIds);
    const newLinesJson = markPending(existingLinesRaw, selectionIds);
    const current = await existing.command("save_attempt", {
      refund_id: refundId,
      effect_id: refundId,
      payload_digest: digest,
      idempotency_key: refundId,
      attempt_amount_cents: amount,
      attempt_lines_json: attemptLinesJson,
      lines_json: newLinesJson,
    });
    flushStore(this.storePath);
    crash("after-attempt-saved-before-request");
    return current;
  }

  // Drives an aggregate that is already in the "attempting" state to its
  // conclusion: lookup the saved refund id, adopt a matching acceptance,
  // refuse on a conflicting one, or POST once when the provider has no
  // record of it yet.
  private async driveAttempt(current: Aggregate, orderId: string): Promise<never> {
    if (current.namedState() !== "attempting") {
      throw new Error("attempt drive left an unexpected state");
    }
    const lookup = await this.lookup(current);
    if (lookup.kind === "accepted") {
      const committed = await this.commitRefunded(current, lookup.digest);
      crash("after-record-before-exit");
      finish(0, viewOf(orderId, committed) as unknown as Json);
    }
    if (lookup.kind === "mismatch") refuse("conflict");
    if (lookup.kind === "absent") {
      await this.postAndCommit(current);
    }
    refuse("unavailable");
  }

  private async continueAttempt(existing: Aggregate, orderId: string): Promise<never> {
    if (!this.serviceUrl) refuse("unavailable");
    await this.driveAttempt(existing, orderId);
  }

  async record(orderId: string, amount: number): Promise<never> {
    const existing = await this.show(orderId);
    if (existing) {
      const stored = factNumber(existing.state as { [key: string]: Json }, "amount_cents");
      if (stored !== amount) refuse("conflict");
      finish(0, viewOf(orderId, existing) as unknown as Json);
    }
    mkdirSync(join(this.storePath, ".."), { recursive: true });
    const machine = await this.machine();
    const created = await machine.createWith({
      aggregateId: orderId,
      command: { name: "admit", args: { amount_cents: amount, currency: "USD" } },
    });
    const aggregate = created instanceof Aggregate ? created : await machine.show(orderId);
    flushStore(this.storePath);
    finish(0, viewOf(orderId, aggregate) as unknown as Json);
  }

  async attach(orderId: string, linesPath: string): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    const named = existing.namedState();
    if (named === "shipped") refuse("shipped");
    if (named === "attempting" || named === "refunded") refuse("refund_open");
    const state = existing.state as { [key: string]: Json };
    const amount = factNumber(state, "amount_cents");

    let raw: string;
    try {
      raw = readFileSync(linesPath, "utf8");
    } catch {
      refuse("bad_lines");
    }
    const parsed = parseLinesFile(raw, amount);
    if (!parsed) refuse("bad_lines");

    const storedRaw = factString(state, "lines_json");
    if (storedRaw !== "") {
      const storedLines = parseLines(storedRaw);
      const storedCap = factNumber(state, "cap_cents");
      if (sameAttachment(storedLines, storedCap, parsed)) {
        finish(0, { order_id: orderId, cap_cents: storedCap, lines: storedLines } as unknown as Json);
      }
      refuse("conflict");
    }

    const linesForStorage: LineView[] = parsed.lines.map((line) => ({
      line_id: line.line_id,
      price_cents: line.price_cents,
      refund: "none",
    }));
    await existing.command("attach_lines", {
      cap_cents: parsed.cap_cents,
      lines_json: JSON.stringify(linesForStorage),
    });
    flushStore(this.storePath);
    finish(0, { order_id: orderId, cap_cents: parsed.cap_cents, lines: linesForStorage } as unknown as Json);
  }

  async ship(orderId: string): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    const named = existing.namedState();
    if (named === "attempting" || named === "refunded") {
      try {
        await existing.command("ship");
      } catch (err) {
        if (err instanceof KernelError) refuse("refund_open");
        throw err;
      }
      refuse("refund_open");
    }
    const shipped = await existing.command("ship");
    flushStore(this.storePath);
    finish(0, viewOf(orderId, shipped) as unknown as Json);
  }

  async status(orderId: string): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    finish(0, viewOf(orderId, existing) as unknown as Json);
  }

  async cancel(orderId: string): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    const named = existing.namedState();
    const state = existing.state as { [key: string]: Json };
    const hasLines = factString(state, "lines_json") !== "";

    if (!hasLines) {
      if (named === "refunded") {
        finish(0, viewOf(orderId, existing) as unknown as Json);
      }
      if (named === "shipped") refuse("shipped");
      if (!this.serviceUrl) refuse("unavailable");
      let current = existing;
      if (named === "open") {
        const amount = factNumber(state, "amount_cents");
        current = await this.startNewAttempt(existing, orderId, null, amount);
      }
      await this.driveAttempt(current, orderId);
    }

    if (named === "attempting") {
      await this.continueAttempt(existing, orderId);
    }

    const lines = parseLines(factString(state, "lines_json"));
    const unrefunded = lines.filter((line) => line.refund !== "refunded");
    if (unrefunded.length === 0) {
      finish(0, viewOf(orderId, existing) as unknown as Json);
    }
    if (named === "shipped") refuse("shipped");
    const capCents = factNumber(state, "cap_cents");
    const refundedCents = factNumber(state, "refunded_cents");
    const sum = unrefunded.reduce((total, line) => total + line.price_cents, 0);
    if (refundedCents + sum > capCents) refuse("over_cap");
    if (!this.serviceUrl) refuse("unavailable");
    const ids = unrefunded.map((line) => line.line_id);
    const started = await this.startNewAttempt(existing, orderId, ids, sum);
    await this.driveAttempt(started, orderId);
  }

  async refund(orderId: string, lineIds: string[]): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    const state = existing.state as { [key: string]: Json };
    const linesRaw = factString(state, "lines_json");
    if (linesRaw === "") refuse("not_attached");
    const lines = parseLines(linesRaw);
    const byId = new Map(lines.map((line) => [line.line_id, line]));
    const unique = new Set(lineIds);
    if (unique.size !== lineIds.length) refuse("unknown_line");
    for (const id of lineIds) {
      if (!byId.has(id)) refuse("unknown_line");
    }
    const named = existing.namedState();
    if (named === "shipped") refuse("shipped");
    if (lineIds.some((id) => byId.get(id)!.refund === "refunded")) refuse("already_refunded");

    if (named === "attempting") {
      const savedSet = [...(JSON.parse(factString(state, "attempt_lines_json") || "[]") as string[])].sort();
      const requested = [...lineIds].sort();
      const sameSelection =
        savedSet.length === requested.length && savedSet.every((value, index) => value === requested[index]);
      if (!sameSelection) refuse("refund_open");
      await this.continueAttempt(existing, orderId);
    }

    const capCents = factNumber(state, "cap_cents");
    const refundedCents = factNumber(state, "refunded_cents");
    const sum = lineIds.reduce((total, id) => total + byId.get(id)!.price_cents, 0);
    if (refundedCents + sum > capCents) refuse("over_cap");
    if (!this.serviceUrl) refuse("unavailable");
    const started = await this.startNewAttempt(existing, orderId, lineIds, sum);
    await this.driveAttempt(started, orderId);
  }

  async reconcile(orderId: string): Promise<never> {
    const existing = await this.show(orderId);
    if (!existing) refuse("unknown_order");
    const named = existing.namedState();
    if (named === "refunded") {
      finish(0, reconcileView(viewOf(orderId, existing), "refunded"));
    }
    if (named !== "attempting") {
      finish(0, reconcileView(viewOf(orderId, existing), "not_applicable"));
    }
    if (!this.serviceUrl) refuse("unavailable");
    const lookup = await this.lookup(existing);
    if (lookup.kind === "accepted") {
      const committed = await this.commitRefunded(existing, lookup.digest);
      crash("after-record-before-exit");
      finish(0, reconcileView(viewOf(orderId, committed), "refunded"));
    }
    if (lookup.kind === "absent") {
      finish(0, reconcileView(viewOf(orderId, existing), "not_sent"));
    }
    if (lookup.kind === "mismatch") refuse("conflict");
    refuse("unavailable");
  }

  private async postAndCommit(aggregate: Aggregate): Promise<never> {
    const state = aggregate.state as { [key: string]: Json };
    const refundId = factString(state, "refund_id");
    const amount = factNumber(state, "attempt_amount_cents");
    const orderId = aggregate.id;
    const posted = await postRefund(this.serviceUrl, {
      refund_id: refundId,
      order_id: orderId,
      amount_cents: amount,
      currency: "USD",
    });
    if (posted.kind === "unavailable") refuse("unavailable");
    if (posted.kind === "mismatch") refuse("conflict");
    crash("after-accept-before-record");
    const committed = await this.commitRefunded(aggregate, posted.digest);
    crash("after-record-before-exit");
    finish(0, viewOf(orderId, committed) as unknown as Json);
  }

  private async lookup(aggregate: Aggregate): Promise<Lookup> {
    const state = aggregate.state as { [key: string]: Json };
    const refundId = factString(state, "refund_id");
    const amount = factNumber(state, "attempt_amount_cents");
    return getRefund(this.serviceUrl, refundId, aggregate.id, amount);
  }
}

type Lookup =
  | { kind: "accepted"; digest: string }
  | { kind: "absent" }
  | { kind: "mismatch" }
  | { kind: "unavailable" };

// The exact canonical byte layout bound into the effect intent's
// payload_digest, so a crash-then-retry recomputes the identical digest.
function payloadDigest(orderId: string, amount: number, refundId: string): string {
  const body = JSON.stringify({
    amount_cents: amount,
    currency: "USD",
    order_id: orderId,
    refund_id: refundId,
  });
  return createHash("sha256").update(body).digest("hex");
}

function matchesAcceptance(
  parsed: Json,
  refundId: string,
  orderId: string,
  amount: number,
): "match" | "mismatch" | "malformed" {
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return "malformed";
  const body = parsed as { [key: string]: Json };
  const sameOrder = body.order_id === orderId;
  const sameAmount = body.amount_cents === amount;
  const sameId = body.refund_id === refundId;
  const sameCurrency = body.currency === "USD";
  const refunded = body.outcome === "refunded";
  if (sameId && sameOrder && sameAmount && sameCurrency && refunded) return "match";
  if (body.order_id !== undefined && !sameOrder) return "mismatch";
  if (body.amount_cents !== undefined && !sameAmount) return "mismatch";
  if (body.refund_id !== undefined && !sameId) return "mismatch";
  if (body.currency !== undefined && !sameCurrency) return "mismatch";
  return "malformed";
}

async function readHttp(response: Response): Promise<{ status: number; text: string } | null> {
  try {
    const text = await response.text();
    return { status: response.status, text };
  } catch {
    return null;
  }
}

async function getRefund(serviceUrl: string, refundId: string, orderId: string, amount: number): Promise<Lookup> {
  let response: Response;
  try {
    response = await fetch(serviceUrl + "/v1/refunds/" + refundId, {
      method: "GET",
      redirect: "error",
    });
  } catch {
    return { kind: "unavailable" };
  }
  const read = await readHttp(response);
  if (!read) return { kind: "unavailable" };
  if (read.status === 404) return { kind: "absent" };
  if (read.status !== 200) return { kind: "unavailable" };
  let parsed: Json;
  try {
    parsed = JSON.parse(read.text) as Json;
  } catch {
    return { kind: "unavailable" };
  }
  const match = matchesAcceptance(parsed, refundId, orderId, amount);
  if (match === "match") return { kind: "accepted", digest: createHash("sha256").update(read.text).digest("hex") };
  if (match === "mismatch") return { kind: "mismatch" };
  return { kind: "unavailable" };
}

async function postRefund(
  serviceUrl: string,
  body: { refund_id: string; order_id: string; amount_cents: number; currency: "USD" },
): Promise<Lookup> {
  let response: Response;
  try {
    response = await fetch(serviceUrl + "/v1/refunds", {
      method: "POST",
      redirect: "error",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch {
    return { kind: "unavailable" };
  }
  const read = await readHttp(response);
  if (!read) return { kind: "unavailable" };
  if (read.status === 500) return { kind: "unavailable" };
  if (read.status === 409) return { kind: "mismatch" };
  if (read.status !== 200) return { kind: "unavailable" };
  let parsed: Json;
  try {
    parsed = JSON.parse(read.text) as Json;
  } catch {
    return { kind: "unavailable" };
  }
  const match = matchesAcceptance(parsed, body.refund_id, body.order_id, body.amount_cents);
  if (match === "match") return { kind: "accepted", digest: createHash("sha256").update(read.text).digest("hex") };
  if (match === "mismatch") return { kind: "mismatch" };
  return { kind: "unavailable" };
}

async function main(): Promise<void> {
  const argv = process.argv.slice(2);
  const command = argv[0];
  if (!command) refuse("bad_args");
  const stateDir = process.env.STATE_DIR;
  if (!stateDir) refuse("bad_args");
  const serviceUrl = process.env.SERVICE_URL ?? "";
  const desk = new Desk(join(stateDir, STORE_NAME), serviceUrl);

  if (command === "record") {
    if (argv.length !== 3) refuse("bad_args");
    const orderId = argv[1];
    if (!validId(orderId)) refuse("bad_id");
    const amount = parseAmount(argv[2]);
    if (amount === null) refuse("bad_amount");
    await desk.record(orderId, amount);
    return;
  }
  if (command === "attach") {
    if (argv.length !== 3) refuse("bad_args");
    const orderId = argv[1];
    if (!validId(orderId)) refuse("bad_id");
    await desk.attach(orderId, argv[2]);
    return;
  }
  if (command === "refund") {
    if (argv.length < 3) refuse("bad_args");
    const orderId = argv[1];
    if (!validId(orderId)) refuse("bad_id");
    await desk.refund(orderId, argv.slice(2));
    return;
  }
  if (command === "ship" || command === "cancel" || command === "status" || command === "reconcile") {
    if (argv.length !== 2) refuse("bad_args");
    const orderId = argv[1];
    if (!validId(orderId)) refuse("bad_id");
    if (command === "ship") await desk.ship(orderId);
    if (command === "cancel") await desk.cancel(orderId);
    if (command === "status") await desk.status(orderId);
    await desk.reconcile(orderId);
    return;
  }
  refuse("bad_args");
}

main().catch((err: unknown) => {
  const detail = err instanceof Error ? err.message : String(err);
  finish(1, { error: "internal", detail });
});
