# Paid-order cancellation desk

Local desk that records a paid order and refunds it once through the payment provider.
An order may optionally have line items attached, with a per-order refund cap; see
"Line attachments" below. Lifecycle rules and their durable records live in the Ikaros
machine `machines/paid_order.ik.toml`. `./run` is the only operator interface.

## Setup

Node 22 is required. From this directory, with network access to the npm registry unavailable:

```sh
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x ./run
```

`./run` uses `/Users/galbal/.nvm/versions/node/v22.17.1/bin/node` when that binary exists, otherwise `node` on `PATH`.

## Run

```sh
export STATE_DIR=/tmp/desk-state
export SERVICE_URL=http://127.0.0.1:9
./run record ORDER-1 1000
./run status ORDER-1
./run ship ORDER-1
./run cancel ORDER-1
./run reconcile ORDER-1
```

Each invocation prints one JSON object on stdout. Exit 0 is success. A refusal is a nonzero exit and `{"error":"<code>"}`.

The payment provider is `stub/server.mjs`. It prints `service_url` and `control_url` on startup. Point `SERVICE_URL` at `service_url`.

Optional `CRASH_AT` kills the process with `SIGKILL` at one named boundary: `after-attempt-saved-before-request`, `after-accept-before-record`, or `after-record-before-exit`.

## Line attachments

Before any refund attempt, an unshipped order may have line items attached once:

```sh
cat > /tmp/lines.json <<'EOF'
{"cap_cents":4000,"lines":[{"line_id":"sku-a","price_cents":3000},{"line_id":"sku-b","price_cents":5000}]}
EOF
./run attach ORDER-1 /tmp/lines.json
./run refund ORDER-1 sku-a
```

`status` always includes `cap_cents` and `lines` (an empty array before attachment).
`cancel` on an order with lines attached refunds every not-yet-refunded line as one
submission, bounded by the same cap; `refund` targets an explicit line selection. Both
commands follow the same exactly-once, crash-safe, lookup-before-retry rules as the
original whole-order `cancel`. See `CHANGE.md` for the full command and requirement text.

## Tests

```sh
node test/desk.test.mjs
```

The test starts the stub itself.
