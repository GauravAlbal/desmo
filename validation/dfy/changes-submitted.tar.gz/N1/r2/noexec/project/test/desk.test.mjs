import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const NODE = "/Users/galbal/.nvm/versions/node/v22.17.1/bin/node";
const RUN = join(ROOT, "run");

function fail(message) {
  console.error("FAIL", message);
  process.exit(1);
}

function assert(cond, message) {
  if (!cond) fail(message);
}

function run(args, env, { allowSignal = false } = {}) {
  return new Promise((resolve) => {
    const child = spawn(RUN, args, {
      cwd: ROOT,
      env: { ...process.env, ...env },
      stdio: ["ignore", "pipe", "pipe"],
    });
    const out = [];
    const err = [];
    child.stdout.on("data", (chunk) => out.push(chunk));
    child.stderr.on("data", (chunk) => err.push(chunk));
    child.on("close", (code, signal) => {
      const stdout = Buffer.concat(out).toString("utf8");
      const stderr = Buffer.concat(err).toString("utf8");
      resolve({ code, signal, stdout, stderr, allowSignal });
    });
  });
}

function parseOne(result, label) {
  const text = result.stdout.trim();
  assert(text.length > 0, `${label} produced no stdout (code=${result.code} signal=${result.signal} stderr=${result.stderr})`);
  const lines = text.split("\n").filter((line) => line.length > 0);
  assert(lines.length === 1, `${label} stdout was not one JSON object: ${JSON.stringify(result.stdout)}`);
  let body;
  try {
    body = JSON.parse(lines[0]);
  } catch (err) {
    fail(`${label} stdout was not JSON: ${result.stdout}`);
  }
  return body;
}

async function ok(args, env, label) {
  const result = await run(args, env);
  assert(result.code === 0 && !result.signal, `${label} exit ${result.code} signal ${result.signal} stdout ${result.stdout} stderr ${result.stderr}`);
  return parseOne(result, label);
}

async function refused(args, env, error, label) {
  const result = await run(args, env);
  assert(result.code !== 0 && !result.signal, `${label} expected refusal, code=${result.code} signal=${result.signal} stdout=${result.stdout}`);
  const body = parseOne(result, label);
  assert(body.error === error, `${label} error ${body.error} expected ${error} body ${result.stdout}`);
  return body;
}

async function killed(args, env, label) {
  const result = await run(args, env, { allowSignal: true });
  assert(result.signal === "SIGKILL" || result.code === 137, `${label} expected SIGKILL, code=${result.code} signal=${result.signal} stdout=${result.stdout} stderr=${result.stderr}`);
  assert(!result.stdout.trim(), `${label} wrote stdout before kill: ${result.stdout}`);
  return result;
}

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [join(ROOT, "stub/server.mjs")], {
      cwd: ROOT,
      stdio: ["ignore", "pipe", "pipe"],
    });
    let buf = "";
    const onData = (chunk) => {
      buf += chunk.toString("utf8");
      const nl = buf.indexOf("\n");
      if (nl === -1) return;
      child.stdout.off("data", onData);
      try {
        const info = JSON.parse(buf.slice(0, nl));
        resolve({ child, ...info });
      } catch (err) {
        reject(err);
      }
    };
    child.stdout.on("data", onData);
    child.on("error", reject);
    child.on("exit", (code) => reject(new Error(`stub exited ${code} before ready`)));
  });
}

async function effects(control) {
  const response = await fetch(control + "/effects");
  return response.json();
}

async function traffic(control) {
  const response = await fetch(control + "/traffic");
  return response.json();
}

async function fault(control, body) {
  const response = await fetch(control + "/fault", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  assert(response.status === 200, "fault injection failed");
}

const root = mkdtempSync(join(tmpdir(), "desk-"));
const stub = await startStub();
const baseEnv = { STATE_DIR: join(root, "state"), SERVICE_URL: stub.service_url };
let failures = 0;

try {
  const recorded = await ok(["record", "A._-1", "1000"], baseEnv, "record");
  assert(recorded.shipment === "open" && recorded.refund === "none" && recorded.refund_id === null && recorded.refunded_cents === 0, "record view");
  assert(recorded.amount_cents === 1000 && recorded.currency === "USD" && recorded.order_id === "A._-1", "record fields");
  assert(recorded.cap_cents === 1000 && Array.isArray(recorded.lines) && recorded.lines.length === 0, "record has no lines before attach");

  const again = await ok(["record", "A._-1", "1000"], baseEnv, "record same");
  assert(again.amount_cents === 1000 && again.refund === "none", "idempotent record");
  await refused(["record", "A._-1", "1001"], baseEnv, "conflict", "record conflict");
  const afterConflict = await ok(["status", "A._-1"], baseEnv, "status after conflict");
  assert(afterConflict.amount_cents === 1000, "conflict changed amount");

  await refused(["record", "bad id", "1000"], baseEnv, "bad_id", "bad id");
  await refused(["record", "ok", "01"], baseEnv, "bad_amount", "leading zero");
  await refused(["record", "ok", "0"], baseEnv, "bad_amount", "zero amount");
  await refused(["record", "ok"], baseEnv, "bad_args", "too few");
  await refused(["cancel", "missing"], baseEnv, "unknown_order", "unknown cancel");
  await refused(["nope"], baseEnv, "bad_args", "unknown command");

  const status = await ok(["status", "A._-1"], baseEnv, "status restart");
  assert(status.amount_cents === 1000 && status.shipment === "open", "restart lost record");

  const marker = join(baseEnv.STATE_DIR, "unrelated.txt");
  writeFileSync(marker, "keep-me");
  await ok(["ship", "A._-1"], baseEnv, "ship");
  await ok(["ship", "A._-1"], baseEnv, "ship again");
  const shipped = await ok(["status", "A._-1"], baseEnv, "shipped status");
  assert(shipped.shipment === "shipped" && shipped.refund === "none", "ship view");
  assert(readFileSync(marker, "utf8") === "keep-me", "unrelated file changed");
  const beforeTraffic = await traffic(stub.control_url);
  await refused(["cancel", "A._-1"], baseEnv, "shipped", "cancel shipped");
  const afterTraffic = await traffic(stub.control_url);
  assert(afterTraffic.requests.length === beforeTraffic.requests.length, "shipped cancel contacted provider");
  const stillShipped = await ok(["status", "A._-1"], baseEnv, "still shipped");
  assert(stillShipped.shipment === "shipped" && stillShipped.refund === "none", "shipped cancel mutated refund");

  await ok(["record", "B", "2500"], baseEnv, "record B");
  const cancelled = await ok(["cancel", "B"], baseEnv, "cancel B");
  assert(cancelled.refund === "refunded" && cancelled.refunded_cents === 2500 && cancelled.shipment === "open", "cancel view");
  assert(typeof cancelled.refund_id === "string" && cancelled.refund_id.length > 0, "refund id missing");
  const provider = await effects(stub.control_url);
  assert(provider.count === 1, `expected one effect, got ${provider.count}`);
  assert(provider.effects[0].order_id === "B" && provider.effects[0].amount_cents === 2500 && provider.effects[0].refund_id === cancelled.refund_id, "effect mismatch");
  const second = await ok(["cancel", "B"], baseEnv, "cancel again");
  assert(second.refund_id === cancelled.refund_id && second.refunded_cents === 2500, "second cancel changed refund");
  const provider2 = await effects(stub.control_url);
  assert(provider2.count === 1, "second cancel added an effect");
  const posts = (await traffic(stub.control_url)).requests.filter((row) => row.method === "POST");
  assert(posts.length === 1, `expected one POST, got ${posts.length}`);
  const other = await ok(["status", "A._-1"], baseEnv, "A independent");
  assert(other.shipment === "shipped" && other.refund === "none", "orders were not independent");

  await refused(["ship", "B"], baseEnv, "refund_open", "ship after refund");

  const crashDir = join(root, "crash");
  const crashEnv = { STATE_DIR: crashDir, SERVICE_URL: stub.service_url };
  await ok(["record", "C", "400"], crashEnv, "record C");
  await killed(["cancel", "C"], { ...crashEnv, CRASH_AT: "after-attempt-saved-before-request" }, "crash before request");
  const saved = await ok(["status", "C"], crashEnv, "status after crash before request");
  assert(saved.refund === "attempt_saved" && saved.refund_id, "attempt not saved");
  const countAfterCrash = (await effects(stub.control_url)).count;
  assert(countAfterCrash === 1, "crash before request counted an effect");
  const reconciled = await ok(["reconcile", "C"], crashEnv, "reconcile not sent");
  assert(reconciled.outcome === "not_sent" && reconciled.refund === "attempt_saved" && reconciled.refund_id === saved.refund_id, "reconcile not_sent");
  const postsAfter = (await traffic(stub.control_url)).requests.filter((row) => row.method === "POST").length;
  assert(postsAfter === 1, "reconcile posted");
  assert((await effects(stub.control_url)).count === 1, "reconcile added an effect");
  const resumed = await ok(["cancel", "C"], crashEnv, "resume after crash before request");
  assert(resumed.refund === "refunded" && resumed.refund_id === saved.refund_id && resumed.refunded_cents === 400, "resume refund id");
  assert((await effects(stub.control_url)).count === 2, "resume did not count exactly one new effect");
  const onlyC = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "C");
  assert(onlyC.length === 1 && onlyC[0].refund_id === saved.refund_id, "C effect id changed");

  const acceptDir = join(root, "accept");
  const acceptEnv = { STATE_DIR: acceptDir, SERVICE_URL: stub.service_url };
  await ok(["record", "D", "700"], acceptEnv, "record D");
  await killed(["cancel", "D"], { ...acceptEnv, CRASH_AT: "after-accept-before-record" }, "crash after accept");
  const pending = await ok(["status", "D"], acceptEnv, "status after accept crash");
  assert(pending.refund === "attempt_saved" && pending.refund_id, "accept crash lost attempt");
  const dEffects = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "D");
  assert(dEffects.length === 1 && dEffects[0].refund_id === pending.refund_id, "accept crash effect");
  const recovered = await ok(["cancel", "D"], acceptEnv, "recover accept crash");
  assert(recovered.refund === "refunded" && recovered.refund_id === pending.refund_id && recovered.refunded_cents === 700, "recover refunded");
  const dEffects2 = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "D");
  assert(dEffects2.length === 1, "recover added an effect");

  const doneDir = join(root, "done");
  const doneEnv = { STATE_DIR: doneDir, SERVICE_URL: stub.service_url };
  await ok(["record", "E", "80"], doneEnv, "record E");
  await killed(["cancel", "E"], { ...doneEnv, CRASH_AT: "after-record-before-exit" }, "crash after record");
  const durable = await ok(["status", "E"], doneEnv, "status after record crash");
  assert(durable.refund === "refunded" && durable.refunded_cents === 80 && durable.refund_id, "record crash not durable");
  const beforeE = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "E").length;
  const againE = await ok(["cancel", "E"], doneEnv, "cancel after record crash");
  assert(againE.refund === "refunded" && againE.refund_id === durable.refund_id, "later cancel changed refund");
  const afterE = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "E").length;
  assert(beforeE === 1 && afterE === 1, "later cancel added an effect");

  await fault(stub.control_url, { drop_reply: true });
  const lostDir = join(root, "lost");
  const lostEnv = { STATE_DIR: lostDir, SERVICE_URL: stub.service_url };
  await ok(["record", "F", "55"], lostEnv, "record F");
  await refused(["cancel", "F"], lostEnv, "unavailable", "lost reply");
  const lostStatus = await ok(["status", "F"], lostEnv, "status lost reply");
  assert(lostStatus.refund === "attempt_saved" && lostStatus.refund_id, "lost reply dropped attempt");
  const fCount = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "F");
  assert(fCount.length === 1 && fCount[0].refund_id === lostStatus.refund_id, "lost reply effect");
  await fault(stub.control_url, { drop_reply: false });
  const reconciledLost = await ok(["reconcile", "F"], lostEnv, "reconcile lost reply");
  assert(reconciledLost.outcome === "refunded" && reconciledLost.refund === "refunded" && reconciledLost.refund_id === lostStatus.refund_id, "lost reply reconcile");
  assert(reconciledLost.refunded_cents === 55, "lost reply amount");
  const fCount2 = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "F").length;
  assert(fCount2 === 1, "reconcile lost reply added an effect");

  await fault(stub.control_url, { status_5xx: true });
  const fiveDir = join(root, "five");
  const fiveEnv = { STATE_DIR: fiveDir, SERVICE_URL: stub.service_url };
  await ok(["record", "G", "15"], fiveEnv, "record G");
  await refused(["cancel", "G"], fiveEnv, "unavailable", "http 500");
  const fiveStatus = await ok(["status", "G"], fiveEnv, "status 500");
  assert(fiveStatus.refund === "attempt_saved", "500 cleared attempt");
  assert((await effects(stub.control_url)).effects.filter((row) => row.order_id === "G").length === 0, "500 stored an effect");
  await fault(stub.control_url, { status_5xx: false });
  const fiveDone = await ok(["cancel", "G"], fiveEnv, "retry after 500");
  assert(fiveDone.refund === "refunded" && fiveDone.refund_id === fiveStatus.refund_id, "retry after 500 changed id");

  const na = await ok(["reconcile", "A._-1"], baseEnv, "reconcile shipped");
  assert(na.outcome === "not_applicable" && na.refund === "none" && na.refund_id === null, "not applicable");

  const conflictDir = join(root, "conflict");
  const conflictEnv = { STATE_DIR: conflictDir, SERVICE_URL: stub.service_url };
  await ok(["record", "H", "90"], conflictEnv, "record H");
  await killed(["cancel", "H"], { ...conflictEnv, CRASH_AT: "after-attempt-saved-before-request" }, "crash H");
  const h = await ok(["status", "H"], conflictEnv, "status H");
  const planted = await fetch(stub.service_url + "/v1/refunds", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ refund_id: h.refund_id, order_id: "H", amount_cents: 91, currency: "USD" }),
  });
  assert(planted.status === 200, "plant conflict refund failed");
  await refused(["cancel", "H"], conflictEnv, "conflict", "lookup conflict");
  const h2 = await ok(["status", "H"], conflictEnv, "status after conflict lookup");
  assert(h2.refund === "attempt_saved" && h2.refund_id === h.refund_id, "conflict lookup changed attempt");
  await refused(["reconcile", "H"], conflictEnv, "conflict", "reconcile conflict");

  const deadEnv = { STATE_DIR: join(root, "dead"), SERVICE_URL: "http://127.0.0.1:9" };
  await ok(["record", "I", "10"], deadEnv, "record without provider");
  await refused(["cancel", "I"], deadEnv, "unavailable", "provider down");
  const i = await ok(["status", "I"], deadEnv, "status provider down");
  assert(i.refund === "attempt_saved" && i.refund_id, "provider down lost attempt");
  await refused(["reconcile", "I"], deadEnv, "unavailable", "reconcile down");
  const i2 = await ok(["status", "I"], deadEnv, "status after reconcile down");
  assert(i2.refund === "attempt_saved" && i2.refund_id === i.refund_id, "reconcile down changed attempt");

  const maxId = "Z".repeat(64);
  await ok(["record", maxId, "100000000"], baseEnv, "max record");
  await refused(["record", "Z".repeat(65), "1"], baseEnv, "bad_id", "id too long");

  // ---- Line attachments and per-order cap (CHANGE.md) ----

  // C1: attach, idempotent re-attach (even from a mutated source file with
  // the same content), a different attachment conflicts and leaves lines
  // unchanged, and attach never contacts the provider.
  const linesDir = join(root, "lines");
  const linesEnv = { STATE_DIR: linesDir, SERVICE_URL: stub.service_url };
  await ok(["record", "L1", "8000"], linesEnv, "record L1");

  const linesFile = join(root, "lines-l1.json");
  writeFileSync(
    linesFile,
    JSON.stringify({
      cap_cents: 4000,
      lines: [
        { line_id: "sku-a", price_cents: 3000 },
        { line_id: "sku-b", price_cents: 5000 },
      ],
    }),
  );
  const attachBeforeTraffic = await traffic(stub.control_url);
  const attached = await ok(["attach", "L1", linesFile], linesEnv, "attach L1");
  assert(attached.cap_cents === 4000, "attach cap");
  assert(
    attached.lines.length === 2 &&
      attached.lines.every((line) => line.refund === "none") &&
      attached.lines.some((line) => line.line_id === "sku-a" && line.price_cents === 3000) &&
      attached.lines.some((line) => line.line_id === "sku-b" && line.price_cents === 5000),
    "attach lines shape",
  );
  const attachAfterTraffic = await traffic(stub.control_url);
  assert(attachAfterTraffic.requests.length === attachBeforeTraffic.requests.length, "attach contacted provider");
  const afterAttachStatus = await ok(["status", "L1"], linesEnv, "status after attach");
  assert(afterAttachStatus.cap_cents === 4000 && afterAttachStatus.lines.length === 2, "status reflects attach");

  writeFileSync(
    linesFile,
    JSON.stringify({
      cap_cents: 4000,
      lines: [
        { line_id: "sku-b", price_cents: 5000 },
        { line_id: "sku-a", price_cents: 3000 },
      ],
    }),
  );
  const reattached = await ok(["attach", "L1", linesFile], linesEnv, "re-attach identical");
  assert(reattached.cap_cents === 4000 && reattached.lines.length === 2, "idempotent attach");

  writeFileSync(
    linesFile,
    JSON.stringify({
      cap_cents: 4000,
      lines: [
        { line_id: "sku-a", price_cents: 3000 },
        { line_id: "sku-c", price_cents: 5000 },
      ],
    }),
  );
  await refused(["attach", "L1", linesFile], linesEnv, "conflict", "different attach");
  const stillOriginal = await ok(["status", "L1"], linesEnv, "status after conflicting attach");
  assert(stillOriginal.lines.some((line) => line.line_id === "sku-b"), "conflict attach changed stored lines");

  // C2: a line over the cap is refused and adds no effect; a line under the
  // cap refunds exactly once; a second refund of the same line is refused.
  await refused(["refund", "L1", "sku-b"], linesEnv, "over_cap", "sku-b over cap");
  const l1Before = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "L1").length;
  assert(l1Before === 0, "over_cap refusal added an effect");
  const refundedA = await ok(["refund", "L1", "sku-a"], linesEnv, "refund sku-a");
  assert(refundedA.refund === "refunded" && refundedA.refunded_cents === 3000, "refund sku-a view");
  const l1AfterA = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "L1");
  assert(l1AfterA.length === 1 && l1AfterA[0].amount_cents === 3000, "sku-a effect amount");
  const statusAfterA = await ok(["status", "L1"], linesEnv, "status after sku-a refund");
  assert(
    statusAfterA.lines.find((line) => line.line_id === "sku-a").refund === "refunded" && statusAfterA.refunded_cents === 3000,
    "sku-a status",
  );
  await refused(["refund", "L1", "sku-a"], linesEnv, "already_refunded", "sku-a again");
  const l1AfterSecond = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "L1");
  assert(l1AfterSecond.length === 1, "second sku-a refund added an effect");

  // not_attached and unknown_line / duplicate line id refusals.
  const miscDir = join(root, "misc-lines");
  const miscEnv = { STATE_DIR: miscDir, SERVICE_URL: stub.service_url };
  await ok(["record", "M1", "1000"], miscEnv, "record M1");
  await refused(["refund", "M1", "whatever"], miscEnv, "not_attached", "refund before attach");
  const badFile = join(root, "bad-lines.json");
  writeFileSync(badFile, JSON.stringify({ cap_cents: 500, lines: [{ line_id: "a", price_cents: 999 }] }));
  await refused(["attach", "M1", badFile], miscEnv, "bad_lines", "sum mismatch");
  writeFileSync(badFile, JSON.stringify({ cap_cents: 1000, lines: [{ line_id: "a", price_cents: 1000 }] }));
  await ok(["attach", "M1", badFile], miscEnv, "attach M1");
  await refused(["refund", "M1", "a", "a"], miscEnv, "unknown_line", "duplicate line id");
  await refused(["refund", "M1", "nope"], miscEnv, "unknown_line", "unknown line id");

  // C3: an open submission blocks every other selection and counts against
  // the cap; a lost reply is recovered by reconcile without a second POST.
  // Three lines so a "different, uninvolved" line is always available to
  // probe refund_open against, distinct from whichever line is already
  // refunded or mid-attempt.
  const openDir = join(root, "openattempt");
  const openEnv = { STATE_DIR: openDir, SERVICE_URL: stub.service_url };
  await ok(["record", "P1", "9000"], openEnv, "record P1");
  const openFile = join(root, "lines-p1.json");
  writeFileSync(
    openFile,
    JSON.stringify({
      cap_cents: 9000,
      lines: [
        { line_id: "x", price_cents: 3000 },
        { line_id: "y", price_cents: 3000 },
        { line_id: "z", price_cents: 3000 },
      ],
    }),
  );
  await ok(["attach", "P1", openFile], openEnv, "attach P1");
  await killed(["refund", "P1", "x"], { ...openEnv, CRASH_AT: "after-attempt-saved-before-request" }, "crash refund x");
  const pSaved = await ok(["status", "P1"], openEnv, "status after crash x");
  assert(pSaved.refund === "attempt_saved" && pSaved.refund_id, "P1 attempt saved");
  assert(pSaved.lines.find((line) => line.line_id === "x").refund === "pending", "x is pending");
  const pPostsBeforeBlocked = (await traffic(stub.control_url)).requests.filter((row) => row.method === "POST").length;
  await refused(["refund", "P1", "z"], openEnv, "refund_open", "z blocked while x open");
  const pPostsAfterBlocked = (await traffic(stub.control_url)).requests.filter((row) => row.method === "POST").length;
  assert(pPostsAfterBlocked === pPostsBeforeBlocked, "blocked refund posted");
  const pResume = await ok(["refund", "P1", "x"], openEnv, "resume refund x");
  assert(pResume.refund === "refunded" && pResume.refund_id === pSaved.refund_id && pResume.refunded_cents === 3000, "x resumed with same id");
  const pEffectsAfterX = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "P1");
  assert(pEffectsAfterX.length === 1, "x resume added a second effect");

  await fault(stub.control_url, { drop_reply: true });
  await refused(["refund", "P1", "y"], openEnv, "unavailable", "y lost reply");
  await fault(stub.control_url, { drop_reply: false });
  const pLostStatus = await ok(["status", "P1"], openEnv, "status after y lost reply");
  assert(pLostStatus.refund === "attempt_saved" && pLostStatus.lines.find((line) => line.line_id === "y").refund === "pending", "y lost reply still pending");
  await refused(["refund", "P1", "z"], openEnv, "refund_open", "z blocked while y open (lost reply)");
  const pReconcileY = await ok(["reconcile", "P1"], openEnv, "reconcile y lost reply");
  assert(pReconcileY.outcome === "refunded" && pReconcileY.refund_id === pLostStatus.refund_id, "reconcile y adopts");
  const pEffectsAfterY = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "P1");
  assert(pEffectsAfterY.length === 2, "reconcile y changed the effect count");
  const pStatusAfterReconcile = await ok(["status", "P1"], openEnv, "status after reconcile y");
  assert(
    pStatusAfterReconcile.lines.find((line) => line.line_id === "y").refund === "refunded" && pStatusAfterReconcile.refunded_cents === 6000,
    "y adopted via reconcile",
  );
  const zRefunded = await ok(["refund", "P1", "z"], openEnv, "refund z fills the cap");
  assert(zRefunded.refund === "refunded" && zRefunded.refunded_cents === 9000, "z fills the cap");
  const pEffectsAfterZ = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "P1");
  assert(pEffectsAfterZ.length === 3, "refund z added more than one effect");

  // C4: shipping still wins over a remaining cap, and a refund still blocks
  // shipping.
  const shipDir = join(root, "shipblock");
  const shipEnv = { STATE_DIR: shipDir, SERVICE_URL: stub.service_url };
  await ok(["record", "S1", "5000"], shipEnv, "record S1");
  const s1File = join(root, "lines-s1.json");
  writeFileSync(s1File, JSON.stringify({ cap_cents: 5000, lines: [{ line_id: "only", price_cents: 5000 }] }));
  await ok(["attach", "S1", s1File], shipEnv, "attach S1");
  await ok(["ship", "S1"], shipEnv, "ship S1");
  const sBeforeTraffic = await traffic(stub.control_url);
  await refused(["refund", "S1", "only"], shipEnv, "shipped", "refund after ship");
  const sAfterTraffic = await traffic(stub.control_url);
  assert(sAfterTraffic.requests.length === sBeforeTraffic.requests.length, "shipped refund contacted provider");

  const refundFirstDir = join(root, "refundfirst");
  const refundFirstEnv = { STATE_DIR: refundFirstDir, SERVICE_URL: stub.service_url };
  await ok(["record", "S2", "5000"], refundFirstEnv, "record S2");
  const s2File = join(root, "lines-s2.json");
  writeFileSync(s2File, JSON.stringify({ cap_cents: 5000, lines: [{ line_id: "only", price_cents: 5000 }] }));
  await ok(["attach", "S2", s2File], refundFirstEnv, "attach S2");
  await ok(["refund", "S2", "only"], refundFirstEnv, "refund only");
  await refused(["ship", "S2"], refundFirstEnv, "refund_open", "ship after refund");
  const s2Status = await ok(["status", "S2"], refundFirstEnv, "status S2 still open");
  assert(s2Status.shipment === "open", "ship after refund changed shipment");
  const s2Effects = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "S2");
  assert(s2Effects.length === 1, "blocked ship added an effect");

  // C5: cancel the remainder once, or refuse over the cap.
  const remDir = join(root, "remainder");
  const remEnv = { STATE_DIR: remDir, SERVICE_URL: stub.service_url };
  await ok(["record", "R1", "9000"], remEnv, "record R1");
  const remFile = join(root, "lines-r1.json");
  writeFileSync(
    remFile,
    JSON.stringify({
      cap_cents: 9000,
      lines: [
        { line_id: "x", price_cents: 4000 },
        { line_id: "y", price_cents: 5000 },
      ],
    }),
  );
  await ok(["attach", "R1", remFile], remEnv, "attach R1");
  await ok(["refund", "R1", "x"], remEnv, "refund x");
  const rEffectsBefore = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "R1");
  assert(rEffectsBefore.length === 1 && rEffectsBefore[0].amount_cents === 4000, "x effect");
  const cancelRemainder = await ok(["cancel", "R1"], remEnv, "cancel remainder");
  assert(cancelRemainder.refund === "refunded" && cancelRemainder.refunded_cents === 9000, "cancel remainder view");
  const rEffectsAfter = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "R1");
  assert(rEffectsAfter.length === 2, "cancel remainder effect count");
  assert(rEffectsAfter[0].amount_cents === 4000, "cancel remainder changed the first effect");
  const cancelAgain = await ok(["cancel", "R1"], remEnv, "cancel again after remainder done");
  assert(cancelAgain.refund === "refunded" && cancelAgain.refunded_cents === 9000, "idempotent cancel after lines done");
  const rEffectsIdempotent = (await effects(stub.control_url)).effects.filter((row) => row.order_id === "R1");
  assert(rEffectsIdempotent.length === 2, "idempotent cancel added an effect");

  const overDir = join(root, "overcap");
  const overEnv = { STATE_DIR: overDir, SERVICE_URL: stub.service_url };
  await ok(["record", "O1", "9000"], overEnv, "record O1");
  const overFile = join(root, "lines-o1.json");
  writeFileSync(
    overFile,
    JSON.stringify({
      cap_cents: 5000,
      lines: [
        { line_id: "x", price_cents: 4000 },
        { line_id: "y", price_cents: 5000 },
      ],
    }),
  );
  await ok(["attach", "O1", overFile], overEnv, "attach O1");
  await ok(["refund", "O1", "x"], overEnv, "refund x (fits cap)");
  const oBeforeTraffic = await traffic(stub.control_url);
  await refused(["cancel", "O1"], overEnv, "over_cap", "cancel remainder over cap");
  const oAfterTraffic = await traffic(stub.control_url);
  assert(oAfterTraffic.requests.length === oBeforeTraffic.requests.length, "over_cap cancel contacted provider");
  const oStatus = await ok(["status", "O1"], overEnv, "status after over cap cancel");
  assert(oStatus.lines.find((line) => line.line_id === "y").refund === "none", "remainder was refunded over cap");

  console.log("ok");
} catch (err) {
  failures += 1;
  console.error(err);
  process.exitCode = 1;
} finally {
  stub.child.kill("SIGTERM");
  rmSync(root, { recursive: true, force: true });
}
if (failures) process.exit(1);
