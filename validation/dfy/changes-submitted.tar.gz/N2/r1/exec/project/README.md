# Plan-change scheduler

Records one account plan and one pending plan change, then asks the billing provider to apply that change at most once.

## Setup

From this directory, with the npm registry unavailable:

```
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x ./run
```

`./run` is a Node program. Its shebang points at `/Users/galbal/.nvm/versions/node/v22.17.1/bin/node`. Invoke it from this directory so relative `STATE_DIR` and callback paths resolve as the brief requires.

## Run

```
export STATE_DIR=./state
export SERVICE_URL=http://127.0.0.1:9
export NOW_MS=0
./run open acct-1 basic 0
./run schedule plus
./run status
```

Each invocation prints one JSON object on stdout. Exit 0 is success. A refusal is nonzero and has an `error` field.

Start the provider with `node stub/server.mjs`. It prints `service_url`. This tool does not call the control port.

Durable lifecycle state is the Ikaros store `STATE_DIR/kernel.sqlite`. Files this tool did not create are left unchanged.

## Invoice commands

An open account may record one unpaid invoice without contacting the provider:

```
./run invoice inv-1 2500
./run pay inv-1
```

While an invoice is unpaid, scheduling, replacing, or applying a lower plan is
refused with `unpaid_downgrade`. Paying the invoice only changes local state;
the pending plan change can then be applied normally. `status` includes
`invoice_id`, `invoice`, and `amount_cents`.

## Tests

```
/Users/galbal/.nvm/versions/node/v22.17.1/bin/node --test tests/lifecycle.test.mjs
```
