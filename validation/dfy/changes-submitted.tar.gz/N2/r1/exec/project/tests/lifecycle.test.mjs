import { spawn } from "node:child_process";
import { mkdtempSync, readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const NODE = "/Users/galbal/.nvm/versions/node/v22.17.1/bin/node";
const CYCLE = 2592000000;

let serviceUrl;
let controlUrl;
let stub;

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, ["stub/server.mjs"], { cwd: ROOT, stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    const timer = setTimeout(() => reject(new Error("stub did not start")), 5000);
    child.stdout.on("data", (chunk) => {
      buf += chunk.toString();
      const line = buf.split("\n")[0];
      if (line) {
        clearTimeout(timer);
        resolve({ child, info: JSON.parse(line) });
      }
    });
    child.on("exit", (code) => reject(new Error("stub exited " + code)));
  });
}

before(async () => {
  const started = await startStub();
  stub = started.child;
  serviceUrl = started.info.service_url;
  controlUrl = started.info.control_url;
});

after(() => {
  if (stub) stub.kill("SIGKILL");
});

function freshDir() {
  return mkdtempSync(path.join(tmpdir(), "plan-change-"));
}

function run(args, env) {
  return new Promise((resolve) => {
    const childEnv = {
      ...process.env,
      PATH: path.dirname(NODE) + ":" + (process.env.PATH || ""),
      SERVICE_URL: serviceUrl,
      ...env,
    };
    for (const key of Object.keys(childEnv)) {
      if (childEnv[key] === undefined) delete childEnv[key];
    }
    if (!Object.prototype.hasOwnProperty.call(env, "NOW_MS")) delete childEnv.NOW_MS;
    const child = spawn(path.join(ROOT, "run"), args, {
      cwd: ROOT,
      env: childEnv,
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (c) => { stdout += c.toString(); });
    child.stderr.on("data", (c) => { stderr += c.toString(); });
    child.on("exit", (code, signal) => resolve({ code, signal, stdout, stderr }));
  });
}

function jsonOut(result) {
  const text = result.stdout.trim();
  assert.equal(text.split("\n").length, 1, result.stdout + result.stderr);
  return JSON.parse(text);
}

async function effects() {
  const res = await fetch(controlUrl + "/effects");
  return res.json();
}

async function posts() {
  const res = await fetch(controlUrl + "/posts");
  return res.json();
}

async function fault(body) {
  const res = await fetch(controlUrl + "/fault", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  assert.equal(res.status, 200);
}

test("empty status, clock, and open protocol", async () => {
  const dir = freshDir();
  const missing = await run(["status"], { STATE_DIR: dir });
  delete missing.env;
  const noClock = await run(["status"], { STATE_DIR: dir, NOW_MS: undefined });
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  const status = await run(["status"], env);
  assert.equal(status.code, 0);
  assert.deepEqual(jsonOut(status), {
    account_id: null,
    current_plan: null,
    cycle_anchor_ms: null,
    change_id: null,
    from_plan: null,
    to_plan: null,
    effective_at_ms: null,
    pending: "none",
    submission: "none",
    submission_id: null,
    applied_plan: null,
    invoice_id: null,
    invoice: "none",
    amount_cents: null,
  });
  const unset = await run(["open", "acct", "basic", "0"], { STATE_DIR: dir });
  assert.notEqual(unset.code, 0);
  assert.equal(jsonOut(unset).error, "missing_clock");
  const bad = await run(["open", "acct", "basic", "0"], { ...env, NOW_MS: "01" });
  assert.equal(jsonOut(bad).error, "bad_clock");
  const opened = await run(["open", "acct-1", "basic", "0"], env);
  assert.equal(opened.code, 0);
  assert.deepEqual(jsonOut(opened), {
    account_id: "acct-1",
    current_plan: "basic",
    cycle_anchor_ms: 0,
    pending: "none",
    submission: "none",
  });
  const again = await run(["open", "other", "plus", "0"], env);
  assert.notEqual(again.code, 0);
  assert.equal(jsonOut(again).error, "already_open");
  const unknown = await run(["open", "acct-2", "mega", "0"], { STATE_DIR: freshDir(), NOW_MS: "0" });
  assert.equal(jsonOut(unknown).error, "unknown_plan");
  const crashStatus = await run(["status"], { ...env, CRASH_AT: "after-accept-before-record" });
  assert.equal(crashStatus.code, 0);
  assert.equal(crashStatus.signal, null);
  assert.equal(jsonOut(crashStatus).account_id, "acct-1");
});

test("schedule boundary, replace, cancel, and refusals do not call the provider", async () => {
  const before = await posts();
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  await run(["open", "acct-1", "basic", "0"], env);
  const same = await run(["schedule", "basic"], env);
  assert.equal(jsonOut(same).error, "same_plan");
  const unknown = await run(["schedule", "mega"], env);
  assert.equal(jsonOut(unknown).error, "unknown_plan");
  const scheduled = await run(["schedule", "plus"], env);
  assert.equal(scheduled.code, 0);
  const body = jsonOut(scheduled);
  assert.equal(body.effective_at_ms, CYCLE);
  assert.equal(body.from_plan, "basic");
  assert.equal(body.to_plan, "plus");
  assert.equal(body.pending, "scheduled");
  assert.equal(body.submission_id, null);
  const again = await run(["schedule", "pro"], env);
  assert.equal(jsonOut(again).error, "pending_exists");
  const status = await run(["status"], env);
  assert.equal(jsonOut(status).change_id, body.change_id);
  const sameTarget = await run(["replace", "plus"], { ...env, NOW_MS: "10" });
  assert.equal(jsonOut(sameTarget).error, "same_target");
  const replaced = await run(["replace", "pro"], { ...env, NOW_MS: "10" });
  assert.equal(replaced.code, 0);
  const repl = jsonOut(replaced);
  assert.notEqual(repl.change_id, body.change_id);
  assert.equal(repl.effective_at_ms, CYCLE);
  assert.equal(repl.from_plan, "basic");
  assert.equal(repl.to_plan, "pro");
  const oldCancel = await run(["cancel", body.change_id], env);
  assert.equal(jsonOut(oldCancel).error, "change_mismatch");
  assert.equal(jsonOut(await run(["status"], env)).change_id, repl.change_id);
  const due = await run(["replace", "plus"], { ...env, NOW_MS: String(CYCLE) });
  assert.equal(jsonOut(due).error, "already_due");
  const early = await run(["apply"], { ...env, NOW_MS: String(CYCLE - 1) });
  assert.equal(jsonOut(early).error, "not_due");
  const cancelled = await run(["cancel", repl.change_id], { ...env, NOW_MS: String(CYCLE) });
  assert.equal(cancelled.code, 0);
  assert.equal(jsonOut(cancelled).pending, "none");
  assert.equal(jsonOut(cancelled).current_plan, "basic");
  const applyGone = await run(["apply"], { ...env, NOW_MS: String(CYCLE) });
  assert.equal(jsonOut(applyGone).error, "no_pending");
  const after = await posts();
  assert.equal(after.count, before.count);
});

test("anchor examples", async () => {
  const dir = freshDir();
  await run(["open", "acct-1", "basic", "100"], { STATE_DIR: dir, NOW_MS: "50" });
  const early = jsonOut(await run(["schedule", "plus"], { STATE_DIR: dir, NOW_MS: "50" }));
  assert.equal(early.effective_at_ms, 100);
  const dir2 = freshDir();
  await run(["open", "acct-1", "plus", "0"], { STATE_DIR: dir2, NOW_MS: String(CYCLE) });
  const next = jsonOut(await run(["schedule", "pro"], { STATE_DIR: dir2, NOW_MS: String(CYCLE) }));
  assert.equal(next.effective_at_ms, CYCLE * 2);
});

test("healthy apply is once, callbacks do not overwrite, restart sees applied", async () => {
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  const marker = path.join(dir, "unrelated.txt");
  mkdirSync(dir, { recursive: true });
  writeFileSync(marker, "keep-me");
  assert.equal((await run(["open", "acct-1", "basic", "0"], env)).code, 0);
  const scheduled = jsonOut(await run(["schedule", "plus"], env));
  const before = await effects();
  const applied = await run(["apply"], { ...env, NOW_MS: String(scheduled.effective_at_ms) });
  assert.equal(applied.code, 0, applied.stdout + applied.stderr);
  const body = jsonOut(applied);
  assert.equal(body.submission, "applied");
  assert.equal(body.current_plan, "plus");
  assert.equal(body.applied_plan, "plus");
  assert.equal(body.pending, "none");
  const after = await effects();
  assert.equal(after.count, before.count + 1);
  const second = await run(["apply"], { ...env, NOW_MS: String(scheduled.effective_at_ms) });
  assert.equal(second.code, 0);
  assert.equal(jsonOut(second).submission_id, body.submission_id);
  assert.equal((await effects()).count, after.count);
  const account = await fetch(serviceUrl + "/v1/accounts/acct-1");
  const stored = await account.json();
  assert.equal(stored.to_plan, "plus");
  assert.equal(stored.submission_id, body.submission_id);
  const cb = {
    callback_id: "cb-1",
    submission_id: body.submission_id,
    account_id: "acct-1",
    to_plan: "plus",
    effective_at_ms: scheduled.effective_at_ms,
    outcome: "applied",
  };
  const cbPath = path.join(dir, "cb.json");
  writeFileSync(cbPath, JSON.stringify(cb));
  assert.equal((await run(["callback", cbPath], env)).code, 0);
  writeFileSync(cbPath, JSON.stringify(cb));
  assert.equal(jsonOut(await run(["callback", cbPath], env)).callback, "accepted");
  writeFileSync(cbPath, JSON.stringify({ ...cb, to_plan: "pro", callback_id: "cb-2" }));
  assert.equal((await run(["callback", cbPath], env)).code, 0);
  const status = jsonOut(await run(["status"], env));
  assert.equal(status.current_plan, "plus");
  assert.equal(status.applied_plan, "plus");
  assert.equal(status.submission, "applied");
  assert.equal((await effects()).count, after.count);
  assert.equal(readFileSync(marker, "utf8"), "keep-me");
  writeFileSync(cbPath, "{");
  assert.equal(jsonOut(await run(["callback", cbPath], env)).error, "bad_callback");
  writeFileSync(cbPath, JSON.stringify({ ...cb, outcome: "nope" }));
  assert.equal(jsonOut(await run(["callback", cbPath], env)).error, "bad_callback");
});

test("crash before request then later apply uses the same submission", async () => {
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  await run(["open", "acct-1", "basic", "0"], env);
  const scheduled = jsonOut(await run(["schedule", "plus"], env));
  const before = await effects();
  const crashed = await run(["apply"], {
    ...env,
    NOW_MS: String(scheduled.effective_at_ms),
    CRASH_AT: "after-attempt-saved-before-request",
  });
  assert.equal(crashed.signal, "SIGKILL");
  const status = jsonOut(await run(["status"], env));
  assert.equal(status.submission, "attempt_saved");
  assert.ok(status.submission_id);
  assert.equal((await effects()).count, before.count);
  const applied = await run(["apply"], { ...env, NOW_MS: String(scheduled.effective_at_ms) });
  assert.equal(applied.code, 0, applied.stdout + applied.stderr);
  const body = jsonOut(applied);
  assert.equal(body.submission_id, status.submission_id);
  assert.equal(body.submission, "applied");
  assert.equal((await effects()).count, before.count + 1);
  const postsAfter = await posts();
  const mine = postsAfter.posts.filter((p) => p.submission_id === status.submission_id && p.http_status === 200);
  assert.equal(mine.length, 1);
});

test("crash after accept is adopted without a second effect", async () => {
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  await run(["open", "acct-1", "basic", "0"], env);
  const scheduled = jsonOut(await run(["schedule", "plus"], env));
  const before = await effects();
  const crashed = await run(["apply"], {
    ...env,
    NOW_MS: String(scheduled.effective_at_ms),
    CRASH_AT: "after-accept-before-record",
  });
  assert.equal(crashed.signal, "SIGKILL");
  assert.equal((await effects()).count, before.count + 1);
  const pending = jsonOut(await run(["status"], env));
  assert.equal(pending.submission, "attempt_saved");
  const applied = await run(["apply"], { ...env, NOW_MS: String(scheduled.effective_at_ms) });
  assert.equal(applied.code, 0, applied.stdout + applied.stderr);
  const body = jsonOut(applied);
  assert.equal(body.submission_id, pending.submission_id);
  assert.equal(body.current_plan, "plus");
  assert.equal((await effects()).count, before.count + 1);
  const postsAfter = await posts();
  const mine = postsAfter.posts.filter((p) => p.submission_id === pending.submission_id);
  assert.equal(mine.length, 1);
});

test("crash after durable record and lost reply reconcile", async () => {
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  await run(["open", "acct-1", "basic", "0"], env);
  const scheduled = jsonOut(await run(["schedule", "plus"], env));
  const before = await effects();
  const crashed = await run(["apply"], {
    ...env,
    NOW_MS: String(scheduled.effective_at_ms),
    CRASH_AT: "after-record-before-exit",
  });
  assert.equal(crashed.signal, "SIGKILL");
  const status = jsonOut(await run(["status"], env));
  assert.equal(status.submission, "applied");
  assert.equal(status.current_plan, "plus");
  const again = await run(["apply"], { ...env, NOW_MS: String(scheduled.effective_at_ms) });
  assert.equal(again.code, 0);
  assert.equal((await effects()).count, before.count + 1);

  const dir2 = freshDir();
  const env2 = { STATE_DIR: dir2, NOW_MS: "0" };
  await run(["open", "acct-2", "basic", "0"], env2);
  const sched2 = jsonOut(await run(["schedule", "pro"], env2));
  await fault({ drop_reply: true });
  const lost = await run(["apply"], { ...env2, NOW_MS: String(sched2.effective_at_ms) });
  await fault({ drop_reply: false });
  assert.notEqual(lost.code, 0);
  assert.equal(jsonOut(lost).error, "service_unavailable");
  const saved = jsonOut(await run(["status"], env2));
  assert.equal(saved.submission, "attempt_saved");
  const counted = await effects();
  const mismatch = await run(["reconcile", "other-id"], env2);
  assert.equal(jsonOut(mismatch).error, "submission_mismatch");
  const none = await run(["reconcile", saved.submission_id], { STATE_DIR: freshDir(), NOW_MS: "0" });
  assert.equal(jsonOut(none).error, "no_attempt");
  const reconCrash = await run(["reconcile", saved.submission_id], {
    ...env2,
    CRASH_AT: "after-record-before-exit",
  });
  assert.equal(reconCrash.signal, "SIGKILL");
  const finalStatus = jsonOut(await run(["status"], env2));
  assert.equal(finalStatus.submission, "applied");
  assert.equal(finalStatus.applied_plan, "pro");
  assert.equal((await effects()).count, counted.count);

  const dir3 = freshDir();
  const env3 = { STATE_DIR: dir3, NOW_MS: "0" };
  await run(["open", "acct-3", "basic", "0"], env3);
  const sched3 = jsonOut(await run(["schedule", "plus"], env3));
  const crashed3 = await run(["apply"], {
    ...env3,
    NOW_MS: String(sched3.effective_at_ms),
    CRASH_AT: "after-attempt-saved-before-request",
  });
  assert.equal(crashed3.signal, "SIGKILL");
  const id = jsonOut(await run(["status"], env3)).submission_id;
  const notSent = jsonOut(await run(["reconcile", id], env3));
  assert.equal(notSent.lookup, "not_sent");
  assert.equal(notSent.submission, "attempt_saved");
  const still = jsonOut(await run(["status"], env3));
  assert.equal(still.submission, "attempt_saved");
});

test("attempt_saved blocks replace and cancel", async () => {
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  await run(["open", "acct-1", "basic", "0"], env);
  const scheduled = jsonOut(await run(["schedule", "plus"], env));
  const crashed = await run(["apply"], {
    ...env,
    NOW_MS: String(scheduled.effective_at_ms),
    CRASH_AT: "after-attempt-saved-before-request",
  });
  assert.equal(crashed.signal, "SIGKILL");
  const status = jsonOut(await run(["status"], env));
  assert.equal(jsonOut(await run(["replace", "pro"], env)).error, "attempt_saved");
  assert.equal(jsonOut(await run(["cancel", status.change_id], env)).error, "attempt_saved");
  assert.equal(jsonOut(await run(["status"], env)).submission_id, status.submission_id);
});

test("unpaid invoices block downgrades at schedule, replace, and apply", async () => {
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  await run(["open", "acct-1", "plus", "0"], env);
  const invoice = await run(["invoice", "inv-1", "2500"], env);
  assert.deepEqual(jsonOut(invoice), { invoice_id: "inv-1", amount_cents: 2500, invoice: "unpaid" });
  assert.equal(jsonOut(await run(["schedule", "basic"], env)).error, "unpaid_downgrade");
  assert.equal(jsonOut(await run(["schedule", "pro"], env)).to_plan, "pro");
  const upgrade = jsonOut(await run(["status"], env));
  assert.equal(upgrade.invoice, "unpaid");
  assert.equal(upgrade.pending, "scheduled");
  assert.equal(jsonOut(await run(["replace", "basic"], { ...env, NOW_MS: "10" })).error, "unpaid_downgrade");
  const afterReplace = jsonOut(await run(["status"], env));
  assert.equal(afterReplace.change_id, upgrade.change_id);
  assert.equal(afterReplace.to_plan, "pro");
  assert.equal(afterReplace.effective_at_ms, upgrade.effective_at_ms);

  const dir2 = freshDir();
  const env2 = { STATE_DIR: dir2, NOW_MS: "0" };
  await run(["open", "acct-2", "plus", "0"], env2);
  const low = jsonOut(await run(["schedule", "basic"], env2));
  await run(["invoice", "inv-2", "2500"], env2);
  const high = await run(["replace", "pro"], { ...env2, NOW_MS: "10" });
  assert.equal(high.code, 0);
  const highBody = jsonOut(high);
  assert.notEqual(highBody.change_id, low.change_id);
  assert.equal(highBody.to_plan, "pro");
  assert.equal(highBody.effective_at_ms, low.effective_at_ms);
  assert.equal(jsonOut(await run(["cancel", low.change_id], env2)).error, "change_mismatch");
  assert.equal(jsonOut(await run(["status"], env2)).change_id, highBody.change_id);

  const dir3 = freshDir();
  const env3 = { STATE_DIR: dir3, NOW_MS: "0" };
  await run(["open", "acct-3", "plus", "0"], env3);
  const low3 = jsonOut(await run(["schedule", "basic"], env3));
  await run(["invoice", "inv-3", "2500"], env3);
  const before = await effects();
  const blocked = await run(["apply"], { ...env3, NOW_MS: String(low3.effective_at_ms) });
  assert.equal(jsonOut(blocked).error, "unpaid_downgrade");
  const blockedStatus = jsonOut(await run(["status"], env3));
  assert.equal(blockedStatus.pending, "scheduled");
  assert.equal(blockedStatus.submission, "none");
  assert.equal((await effects()).count, before.count);
  assert.deepEqual(jsonOut(await run(["pay", "inv-3"], env3)), {
    invoice_id: "inv-3",
    amount_cents: 2500,
    invoice: "paid",
  });
  const applied = await run(["apply"], { ...env3, NOW_MS: String(low3.effective_at_ms) });
  assert.equal(applied.code, 0, applied.stdout + applied.stderr);
  assert.equal(jsonOut(applied).current_plan, "basic");
  const after = await effects();
  assert.equal(after.count, before.count + 1);
  assert.equal((await run(["apply"], { ...env3, NOW_MS: String(low3.effective_at_ms) })).code, 0);
  assert.equal((await effects()).count, after.count);
});
