# Plan-change scheduler

Records one account plan and one pending plan change, then asks the billing provider to apply that change at most once. A durable local invoice record can block downgrades until it is paid.

## Setup

From this directory, with the npm registry unavailable:

```
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x ./run
```

`./run` is a Node program. Its shebang points at `/Users/galbal/.nvm/versions/node/v22.17.1/bin/node`. Invoke it from this directory so relative `STATE_DIR` and callback paths resolve as the brief requires.

## Run

```
export STATE_DIR=./state
export SERVICE_URL=http://127.0.0.1:9
export NOW_MS=0
./run open acct-1 plus 0
./run invoice inv-1 2500
./run schedule pro
./run pay inv-1
./run status
```

`invoice <invoice_id> <amount_cents>` records one unpaid invoice. `pay <invoice_id>` marks it paid. While it is unpaid, scheduling, replacing, or applying a downgrade is refused with `unpaid_downgrade`; upgrades remain available.

Each invocation prints one JSON object on stdout. Exit 0 is success. A refusal is nonzero and has an `error` field.

Start the provider with `node stub/server.mjs`. It prints `service_url`. This tool does not call the control port. Invoice and payment commands are local and never contact the provider.

Durable lifecycle state is the Ikaros store `STATE_DIR/kernel.sqlite`. Files this tool did not create are left unchanged.

## Tests

```
/Users/galbal/.nvm/versions/node/v22.17.1/bin/node --test tests/lifecycle.test.mjs tests/invoice.test.mjs
```
