import { spawn } from "node:child_process";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import { fileURLToPath } from "node:url";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const NODE = "/Users/galbal/.nvm/versions/node/v22.17.1/bin/node";

let serviceUrl;
let controlUrl;
let stub;

before(async () => {
  const started = await new Promise((resolve, reject) => {
    const child = spawn(NODE, ["stub/server.mjs"], { cwd: ROOT, stdio: ["ignore", "pipe", "pipe"] });
    let output = "";
    const timer = setTimeout(() => reject(new Error("stub did not start")), 5000);
    child.stdout.on("data", (chunk) => {
      output += chunk.toString();
      const line = output.split("\n")[0];
      if (line) {
        clearTimeout(timer);
        resolve({ child, info: JSON.parse(line) });
      }
    });
    child.on("exit", (code) => reject(new Error("stub exited " + code)));
  });
  stub = started.child;
  serviceUrl = started.info.service_url;
  controlUrl = started.info.control_url;
});

after(() => {
  if (stub) stub.kill("SIGKILL");
});

function freshDir() {
  return mkdtempSync(path.join(tmpdir(), "plan-change-invoice-"));
}

function run(args, env) {
  return new Promise((resolve) => {
    const child = spawn(path.join(ROOT, "run"), args, {
      cwd: ROOT,
      env: {
        ...process.env,
        PATH: path.dirname(NODE) + ":" + (process.env.PATH || ""),
        SERVICE_URL: serviceUrl,
        ...env,
      },
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => { stdout += chunk.toString(); });
    child.stderr.on("data", (chunk) => { stderr += chunk.toString(); });
    child.on("exit", (code, signal) => resolve({ code, signal, stdout, stderr }));
  });
}

function jsonOut(result) {
  assert.equal(result.stdout.trim().split("\n").length, 1, result.stdout + result.stderr);
  return JSON.parse(result.stdout);
}

async function posts() {
  const response = await fetch(controlUrl + "/posts");
  return response.json();
}

async function effects() {
  const response = await fetch(controlUrl + "/effects");
  return response.json();
}

test("invoice and pay persist, validate, and never call the provider", async () => {
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  const before = await posts();
  assert.equal(jsonOut(await run(["invoice", "inv-1", "2500"], env)).error, "not_open");
  await run(["open", "acct-invoice", "plus", "0"], env);
  assert.equal(jsonOut(await run(["invoice", "inv-1", "0"], env)).error, "bad_amount");
  assert.equal(jsonOut(await run(["invoice", "inv-1", "01"], env)).error, "bad_amount");
  const recorded = await run(["invoice", "inv-1", "2500"], env);
  assert.equal(recorded.code, 0, recorded.stdout + recorded.stderr);
  assert.deepEqual(jsonOut(recorded), { invoice_id: "inv-1", amount_cents: 2500, invoice: "unpaid" });
  assert.equal(jsonOut(await run(["invoice", "inv-2", "500"], env)).error, "invoice_exists");
  assert.equal(jsonOut(await run(["pay", "other"], env)).error, "invoice_mismatch");
  const paid = await run(["pay", "inv-1"], env);
  assert.equal(paid.code, 0);
  assert.deepEqual(jsonOut(paid), { invoice_id: "inv-1", amount_cents: 2500, invoice: "paid" });
  assert.equal((await run(["pay", "inv-1"], env)).code, 0);
  assert.equal((await run(["invoice", "inv-2", "500"], env)).code, 0);
  const status = jsonOut(await run(["status"], env));
  assert.equal(status.invoice_id, "inv-2");
  assert.equal(status.amount_cents, 500);
  assert.equal(status.invoice, "unpaid");
  assert.equal((await posts()).count, before.count);
});

test("unpaid invoice blocks scheduling a downgrade but permits an upgrade", async () => {
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  const before = await posts();
  await run(["open", "acct-schedule", "plus", "0"], env);
  await run(["invoice", "inv-schedule", "2500"], env);
  const blocked = await run(["schedule", "basic"], env);
  assert.notEqual(blocked.code, 0);
  assert.equal(jsonOut(blocked).error, "unpaid_downgrade");
  const unchanged = jsonOut(await run(["status"], env));
  assert.equal(unchanged.current_plan, "plus");
  assert.equal(unchanged.pending, "none");
  const upgrade = await run(["schedule", "pro"], env);
  assert.equal(upgrade.code, 0, upgrade.stdout + upgrade.stderr);
  assert.equal(jsonOut(upgrade).to_plan, "pro");
  assert.equal((await posts()).count, before.count);
});

test("blocked replacement preserves a legal pending upgrade", async () => {
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  const before = await posts();
  await run(["open", "acct-replace-blocked", "plus", "0"], env);
  const scheduled = jsonOut(await run(["schedule", "pro"], env));
  await run(["invoice", "inv-replace", "100"], env);
  const blocked = await run(["replace", "basic"], env);
  assert.equal(jsonOut(blocked).error, "unpaid_downgrade");
  const status = jsonOut(await run(["status"], env));
  assert.equal(status.change_id, scheduled.change_id);
  assert.equal(status.to_plan, "pro");
  assert.equal(status.effective_at_ms, scheduled.effective_at_ms);
  assert.equal((await posts()).count, before.count);
});

test("a pending downgrade can be replaced by an upgrade while unpaid", async () => {
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  const before = await posts();
  await run(["open", "acct-replace-upgrade", "plus", "0"], env);
  const downgrade = jsonOut(await run(["schedule", "basic"], env));
  await run(["invoice", "inv-upgrade", "100"], env);
  const replacement = await run(["replace", "pro"], env);
  assert.equal(replacement.code, 0, replacement.stdout + replacement.stderr);
  const upgraded = jsonOut(replacement);
  assert.notEqual(upgraded.change_id, downgrade.change_id);
  assert.equal(upgraded.to_plan, "pro");
  assert.equal(upgraded.effective_at_ms, downgrade.effective_at_ms);
  assert.equal(jsonOut(await run(["cancel", downgrade.change_id], env)).error, "change_mismatch");
  assert.equal(jsonOut(await run(["status"], env)).change_id, upgraded.change_id);
  assert.equal((await posts()).count, before.count);
});

test("due downgrade waits for payment and then applies exactly once", async () => {
  const dir = freshDir();
  const env = { STATE_DIR: dir, NOW_MS: "0" };
  await run(["open", "acct-apply", "plus", "0"], env);
  const downgrade = jsonOut(await run(["schedule", "basic"], env));
  await run(["invoice", "inv-apply", "2500"], env);
  const beforePosts = await posts();
  const beforeEffects = await effects();
  const early = await run(["apply"], { ...env, NOW_MS: String(downgrade.effective_at_ms - 1) });
  assert.equal(jsonOut(early).error, "not_due");
  const blocked = await run(["apply"], { ...env, NOW_MS: String(downgrade.effective_at_ms) });
  assert.equal(jsonOut(blocked).error, "unpaid_downgrade");
  const waiting = jsonOut(await run(["status"], env));
  assert.equal(waiting.pending, "scheduled");
  assert.equal(waiting.submission, "none");
  assert.equal(waiting.to_plan, "basic");
  assert.equal((await posts()).count, beforePosts.count);
  assert.equal((await run(["pay", "inv-apply"], env)).code, 0);
  assert.equal((await posts()).count, beforePosts.count);
  const applied = await run(["apply"], { ...env, NOW_MS: String(downgrade.effective_at_ms) });
  assert.equal(applied.code, 0, applied.stdout + applied.stderr);
  assert.equal(jsonOut(applied).current_plan, "basic");
  const afterEffects = await effects();
  assert.equal(afterEffects.count, beforeEffects.count + 1);
  assert.equal((await run(["apply"], { ...env, NOW_MS: String(downgrade.effective_at_ms) })).code, 0);
  assert.equal((await effects()).count, afterEffects.count);
});
