import { createHash, randomBytes } from "node:crypto";
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { writeSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { HistoricalResult, Kernel, classify } from "@ikaros/runtime";

const AGGREGATE_ID = "account";
const PLANS = new Set(["basic", "plus", "pro"]);
const PLAN_RANK = { basic: 1, plus: 2, pro: 3 };
const CYCLE = 2592000000n;
const MAX_MS = 9007199254740991n;
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const MACHINE_PATH = fileURLToPath(new URL("../machines/plan_change.ik.toml", import.meta.url));

function emit(obj, code) {
  writeSync(1, JSON.stringify(obj) + "\n");
  process.exit(code);
}

function fail(error) {
  emit({ error }, 1);
}

function crashAt(boundary) {
  if (process.env.CRASH_AT === boundary) {
    process.kill(process.pid, "SIGKILL");
  }
}

function parseClock(raw, missingCode) {
  if (raw === undefined || raw === "") return { error: missingCode };
  if (!/^(0|[1-9][0-9]*)$/.test(raw)) return { error: "bad_clock" };
  let value;
  try {
    value = BigInt(raw);
  } catch {
    return { error: "bad_clock" };
  }
  if (value < 0n || value > MAX_MS) return { error: "bad_clock" };
  return { value };
}

function parseAmount(raw) {
  if (!/^(0|[1-9][0-9]*)$/.test(raw ?? "")) return null;
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value < 1 || value > 100000000) return null;
  return value;
}

function asNumber(value) {
  if (typeof value === "bigint") return Number(value);
  return value;
}

function nextBoundary(anchor, now) {
  let effective;
  if (now < anchor) effective = anchor;
  else effective = anchor + CYCLE * ((now - anchor) / CYCLE + 1n);
  if (effective <= now || effective > MAX_MS) return null;
  return effective;
}

function newId(prefix) {
  return prefix + randomBytes(8).toString("hex");
}

function digestOf(text) {
  return createHash("sha256").update(text).digest("hex");
}

function isDowngrade(fromPlan, toPlan) {
  return PLAN_RANK[toPlan] < PLAN_RANK[fromPlan];
}

function postBody(saved) {
  return JSON.stringify({
    submission_id: saved.submission_id,
    account_id: saved.account_id,
    from_plan: saved.from_plan,
    to_plan: saved.to_plan,
    effective_at_ms: asNumber(saved.effective_at_ms),
  });
}

function matches(saved, body) {
  if (!body || typeof body !== "object") return false;
  return body.outcome === "applied"
    && body.submission_id === saved.submission_id
    && body.account_id === saved.account_id
    && body.from_plan === saved.from_plan
    && body.to_plan === saved.to_plan
    && body.effective_at_ms === asNumber(saved.effective_at_ms);
}

function emptyStatus() {
  return {
    account_id: null,
    current_plan: null,
    cycle_anchor_ms: null,
    change_id: null,
    from_plan: null,
    to_plan: null,
    effective_at_ms: null,
    pending: "none",
    submission: "none",
    submission_id: null,
    applied_plan: null,
    invoice_id: null,
    invoice: "none",
    amount_cents: null,
  };
}

function project(agg) {
  if (!agg) return emptyStatus();
  const facts = agg.state || {};
  const state = agg.namedState();
  const view = emptyStatus();
  view.account_id = facts.account_id ?? null;
  view.current_plan = facts.current_plan ?? null;
  view.cycle_anchor_ms = asNumber(facts.cycle_anchor_ms ?? null);
  view.invoice_id = facts.invoice_id ?? null;
  view.invoice = facts.invoice_status ?? "none";
  view.amount_cents = asNumber(facts.amount_cents ?? null);
  if (state === "scheduled" || state === "attempt") {
    view.change_id = facts.change_id;
    view.from_plan = facts.from_plan;
    view.to_plan = facts.to_plan;
    view.effective_at_ms = asNumber(facts.effective_at_ms);
    view.pending = "scheduled";
  }
  if (state === "attempt") {
    view.submission = "attempt_saved";
    view.submission_id = facts.submission_id;
  }
  if (state === "applied") {
    view.change_id = facts.change_id;
    view.from_plan = facts.from_plan;
    view.to_plan = facts.to_plan;
    view.effective_at_ms = asNumber(facts.effective_at_ms);
    view.pending = "none";
    view.submission = "applied";
    view.submission_id = facts.submission_id;
    view.applied_plan = facts.current_plan;
    view.current_plan = facts.current_plan;
  }
  return view;
}

function appliedObject(view) {
  return {
    account_id: view.account_id,
    change_id: view.change_id,
    submission_id: view.submission_id,
    from_plan: view.from_plan,
    to_plan: view.to_plan,
    effective_at_ms: view.effective_at_ms,
    current_plan: view.current_plan,
    pending: "none",
    submission: "applied",
    applied_plan: view.applied_plan,
  };
}

function invoiceObject(view) {
  return {
    invoice_id: view.invoice_id,
    amount_cents: view.amount_cents,
    invoice: view.invoice,
  };
}

function storePath(stateDir) {
  return path.join(stateDir, "kernel.sqlite");
}

function isCorrupt(err) {
  if (!err) return false;
  if (err.code === "IK_STORE_CORRUPT" || err.code === "IK_JOURNAL_CORRUPT" || err.code === "IK_PROJECTION_CORRUPT") return true;
  try {
    return classify(err) === "corrupt";
  } catch {
    return false;
  }
}

async function openMachine(stateDir) {
  const kernel = new Kernel(storePath(stateDir));
  const machine = await kernel.machine(MACHINE_PATH);
  return { kernel, machine };
}

async function load(stateDir) {
  const file = storePath(stateDir);
  if (!existsSync(file)) return null;
  try {
    const opened = await openMachine(stateDir);
    const agg = await opened.machine.show(AGGREGATE_ID);
    return { ...opened, agg };
  } catch (err) {
    if (isCorrupt(err)) fail("corrupt_state");
    if (err && err.code === "IK_ILLEGAL_STATE" && err.rule === "aggregate.not_found") return null;
    if (err && err.code === "IK_STORE_NOT_FOUND") return null;
    throw err;
  }
}

async function httpCall(method, url, body) {
  const init = { method };
  if (body !== undefined) {
    init.headers = { "content-type": "application/json" };
    init.body = body;
  }
  let res;
  try {
    res = await fetch(url, init);
  } catch {
    return { failed: true };
  }
  let text;
  try {
    text = await res.text();
  } catch {
    return { failed: true };
  }
  let parsed = null;
  if (text) {
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = null;
    }
  }
  return { failed: false, status: res.status, text, parsed };
}

function savedFrom(view) {
  return {
    submission_id: view.submission_id,
    account_id: view.account_id,
    from_plan: view.from_plan,
    to_plan: view.to_plan,
    effective_at_ms: view.effective_at_ms,
  };
}

async function commitApplied(stateDir, saved, responseText) {
  let opened = await load(stateDir);
  if (!opened) fail("service_unavailable");
  const alreadyApplied = opened.agg.namedState() === "applied";
  if (opened.agg.pendingIntent) {
    const recorded = await opened.agg.recordEffectOutcome(digestOf(responseText));
    if (recorded instanceof HistoricalResult) opened = await load(stateDir);
    else opened = { ...opened, agg: recorded };
  }
  if (opened.agg.namedState() === "attempt") {
    const marked = await opened.agg.command("mark_applied", { applied_plan: saved.to_plan });
    if (marked instanceof HistoricalResult) opened = await load(stateDir);
    else opened = { ...opened, agg: marked };
  }
  if (!alreadyApplied) crashAt("after-record-before-exit");
  return project(opened.agg);
}

async function postSaved(serviceUrl, stateDir, saved) {
  const body = postBody(saved);
  const result = await httpCall("POST", serviceUrl + "/v1/plan-changes", body);
  if (result.failed) fail("service_unavailable");
  if (result.status === 200 && matches(saved, result.parsed)) {
    crashAt("after-accept-before-record");
    return commitApplied(stateDir, saved, result.text);
  }
  if (result.status >= 500) fail("service_unavailable");
  if (result.status === 409 || result.status === 200) fail("lookup_conflict");
  fail("service_unavailable");
}

async function adoptOrPost(serviceUrl, stateDir, view) {
  const saved = savedFrom(view);
  const looked = await httpCall("GET", serviceUrl + "/v1/submissions/" + saved.submission_id);
  if (looked.failed) fail("service_unavailable");
  if (looked.status === 200 && matches(saved, looked.parsed)) {
    return commitApplied(stateDir, saved, looked.text);
  }
  if (looked.status === 200) fail("lookup_conflict");
  if (looked.status !== 404) fail("service_unavailable");
  return postSaved(serviceUrl, stateDir, saved);
}

async function cmdOpen(stateDir, args) {
  if (args.length !== 3) fail("bad_args");
  const [accountId, plan, anchorRaw] = args;
  if (!ID_RE.test(accountId)) fail("bad_args");
  if (!PLANS.has(plan)) fail("unknown_plan");
  if (!/^(0|[1-9][0-9]*)$/.test(anchorRaw)) fail("bad_args");
  let anchor;
  try {
    anchor = BigInt(anchorRaw);
  } catch {
    fail("bad_args");
  }
  if (anchor < 0n || anchor > MAX_MS) fail("bad_args");
  const existing = await load(stateDir);
  if (existing) fail("already_open");
  mkdirSync(stateDir, { recursive: true });
  const opened = await openMachine(stateDir);
  let created;
  try {
    created = await opened.machine.createWith({
      aggregateId: AGGREGATE_ID,
      command: {
        name: "admit",
        args: { account_id: accountId, plan, anchor: Number(anchor) },
      },
    });
  } catch (err) {
    if (isCorrupt(err)) fail("corrupt_state");
    const again = await load(stateDir);
    if (again) fail("already_open");
    throw err;
  }
  const agg = created instanceof HistoricalResult ? (await load(stateDir)).agg : created;
  const view = project(agg);
  emit({
    account_id: view.account_id,
    current_plan: view.current_plan,
    cycle_anchor_ms: view.cycle_anchor_ms,
    pending: "none",
    submission: "none",
  }, 0);
}

async function cmdSchedule(stateDir, args, now) {
  if (args.length !== 1) fail("bad_args");
  const plan = args[0];
  if (!PLANS.has(plan)) fail("unknown_plan");
  const opened = await load(stateDir);
  if (!opened) fail("bad_args");
  const state = opened.agg.namedState();
  if (state === "scheduled" || state === "attempt") fail("pending_exists");
  if (state !== "ready" && state !== "applied") fail("bad_args");
  const view = project(opened.agg);
  if (plan === view.current_plan) fail("same_plan");
  if (view.invoice === "unpaid" && isDowngrade(view.current_plan, plan)) fail("unpaid_downgrade");
  const effective = nextBoundary(BigInt(view.cycle_anchor_ms), now);
  if (effective === null) fail("bad_clock");
  const changeId = newId("chg-");
  const updated = await opened.agg.command("schedule", {
    plan,
    change_id: changeId,
    from_plan: view.current_plan,
    effective: Number(effective),
    now: Number(now),
  });
  const next = project(updated);
  emit({
    change_id: next.change_id,
    account_id: next.account_id,
    from_plan: next.from_plan,
    to_plan: next.to_plan,
    effective_at_ms: next.effective_at_ms,
    pending: "scheduled",
    submission: "none",
    submission_id: null,
  }, 0);
}

async function cmdReplace(stateDir, args, now) {
  if (args.length !== 1) fail("bad_args");
  const plan = args[0];
  const opened = await load(stateDir);
  if (!opened) fail("no_pending");
  const state = opened.agg.namedState();
  if (state === "attempt") fail("attempt_saved");
  if (state !== "scheduled") fail("no_pending");
  const view = project(opened.agg);
  if (now >= BigInt(view.effective_at_ms)) fail("already_due");
  if (!PLANS.has(plan)) fail("unknown_plan");
  if (plan === view.current_plan) fail("same_plan");
  if (plan === view.to_plan) fail("same_target");
  if (view.invoice === "unpaid" && isDowngrade(view.current_plan, plan)) fail("unpaid_downgrade");
  let changeId = newId("chg-");
  if (changeId === view.change_id) changeId = newId("chg-");
  const updated = await opened.agg.command("replace", {
    plan,
    change_id: changeId,
    now: Number(now),
  });
  const next = project(updated);
  emit({
    change_id: next.change_id,
    account_id: next.account_id,
    from_plan: next.from_plan,
    to_plan: next.to_plan,
    effective_at_ms: next.effective_at_ms,
    pending: "scheduled",
    submission: "none",
    submission_id: null,
  }, 0);
}

async function cmdCancel(stateDir, args) {
  if (args.length !== 1) fail("bad_args");
  const changeId = args[0];
  if (!ID_RE.test(changeId)) fail("bad_args");
  const opened = await load(stateDir);
  if (!opened) fail("no_pending");
  const state = opened.agg.namedState();
  if (state === "attempt") fail("attempt_saved");
  if (state !== "scheduled") fail("no_pending");
  const view = project(opened.agg);
  if (changeId !== view.change_id) fail("change_mismatch");
  await opened.agg.command("cancel", { change_id: changeId });
  emit({
    account_id: view.account_id,
    change_id: changeId,
    current_plan: view.current_plan,
    pending: "none",
    submission: "none",
  }, 0);
}

async function cmdInvoice(stateDir, args) {
  if (args.length !== 2) fail("bad_args");
  const [invoiceId, amountRaw] = args;
  if (!ID_RE.test(invoiceId)) fail("bad_args");
  const amount = parseAmount(amountRaw);
  if (amount === null) fail("bad_amount");
  const opened = await load(stateDir);
  if (!opened) fail("not_open");
  const view = project(opened.agg);
  if (view.invoice === "unpaid") fail("invoice_exists");
  const state = opened.agg.namedState();
  const updated = await opened.agg.command("record_invoice_" + state, {
    invoice_id: invoiceId,
    amount,
    invoice: "unpaid",
  });
  emit(invoiceObject(project(updated)), 0);
}

async function cmdPay(stateDir, args) {
  if (args.length !== 1) fail("bad_args");
  const invoiceId = args[0];
  if (!ID_RE.test(invoiceId)) fail("bad_args");
  const opened = await load(stateDir);
  if (!opened) fail("no_invoice");
  const view = project(opened.agg);
  if (view.invoice === "none") fail("no_invoice");
  if (view.invoice_id !== invoiceId) fail("invoice_mismatch");
  const state = opened.agg.namedState();
  const updated = await opened.agg.command("pay_invoice_" + state, {
    invoice_id: invoiceId,
    invoice: "paid",
  });
  emit(invoiceObject(project(updated)), 0);
}

async function cmdApply(stateDir, serviceUrl, now) {
  const opened = await load(stateDir);
  if (!opened) fail("no_pending");
  const state = opened.agg.namedState();
  const view = project(opened.agg);
  if (state === "applied") {
    emit(appliedObject(view), 0);
  }
  if (state === "attempt") {
    const adopted = await adoptOrPost(serviceUrl, stateDir, view);
    emit(appliedObject(adopted), 0);
  }
  if (state !== "scheduled") fail("no_pending");
  if (now < BigInt(view.effective_at_ms)) fail("not_due");
  if (view.invoice === "unpaid" && isDowngrade(view.current_plan, view.to_plan)) fail("unpaid_downgrade");
  const submissionId = newId("sub-");
  const saved = {
    submission_id: submissionId,
    account_id: view.account_id,
    from_plan: view.from_plan,
    to_plan: view.to_plan,
    effective_at_ms: view.effective_at_ms,
  };
  const body = postBody(saved);
  await opened.agg.command("save_attempt", {
    now: Number(now),
    submission_id: submissionId,
    payload_digest: digestOf(body),
  });
  crashAt("after-attempt-saved-before-request");
  const applied = await postSaved(serviceUrl, stateDir, saved);
  emit(appliedObject(applied), 0);
}

async function cmdReconcile(stateDir, serviceUrl, args) {
  if (args.length !== 1) fail("bad_args");
  const submissionId = args[0];
  if (!ID_RE.test(submissionId)) fail("bad_args");
  const opened = await load(stateDir);
  if (!opened) fail("no_attempt");
  const view = project(opened.agg);
  if (view.submission === "none" || !view.submission_id) fail("no_attempt");
  if (submissionId !== view.submission_id) fail("submission_mismatch");
  if (view.submission === "applied") {
    emit({ ...appliedObject(view), lookup: "applied" }, 0);
  }
  const saved = savedFrom(view);
  const looked = await httpCall("GET", serviceUrl + "/v1/submissions/" + saved.submission_id);
  if (looked.failed) fail("service_unavailable");
  if (looked.status === 404) {
    emit({
      lookup: "not_sent",
      submission_id: saved.submission_id,
      submission: "attempt_saved",
      account_id: view.account_id,
      change_id: view.change_id,
      pending: "scheduled",
    }, 0);
  }
  if (looked.status === 200 && matches(saved, looked.parsed)) {
    const applied = await commitApplied(stateDir, saved, looked.text);
    emit({ ...appliedObject(applied), lookup: "applied" }, 0);
  }
  if (looked.status === 200) fail("lookup_conflict");
  fail("service_unavailable");
}

function cmdStatus(stateDir) {
  return load(stateDir).then((opened) => {
    emit(opened ? project(opened.agg) : emptyStatus(), 0);
  });
}

function cmdCallback(filePath) {
  let text;
  try {
    text = readFileSync(filePath, "utf8");
  } catch {
    fail("bad_callback");
  }
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    fail("bad_callback");
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) fail("bad_callback");
  const required = ["callback_id", "submission_id", "account_id", "to_plan", "effective_at_ms", "outcome"];
  for (const field of required) {
    if (!(field in parsed)) fail("bad_callback");
  }
  if (parsed.outcome !== "applied" && parsed.outcome !== "rejected") fail("bad_callback");
  if (typeof parsed.effective_at_ms !== "number") fail("bad_callback");
  emit({ callback: "accepted" }, 0);
}

async function main() {
  const clock = parseClock(process.env.NOW_MS, "missing_clock");
  if (clock.error) fail(clock.error);
  const serviceUrl = process.env.SERVICE_URL;
  if (!serviceUrl) fail("bad_args");
  const baseUrl = serviceUrl.endsWith("/") ? serviceUrl.slice(0, -1) : serviceUrl;
  const stateDir = process.env.STATE_DIR;
  if (!stateDir) fail("bad_args");
  const [command, ...args] = process.argv.slice(2);
  if (!command) fail("bad_args");
  if (command === "callback") {
    if (args.length !== 1) fail("bad_args");
    cmdCallback(args[0]);
  }
  if (command === "status") {
    if (args.length !== 0) fail("bad_args");
    await cmdStatus(stateDir);
    return;
  }
  if (command === "open") return cmdOpen(stateDir, args);
  if (command === "schedule") return cmdSchedule(stateDir, args, clock.value);
  if (command === "replace") return cmdReplace(stateDir, args, clock.value);
  if (command === "cancel") return cmdCancel(stateDir, args);
  if (command === "invoice") return cmdInvoice(stateDir, args);
  if (command === "pay") return cmdPay(stateDir, args);
  if (command === "apply") {
    if (args.length !== 0) fail("bad_args");
    return cmdApply(stateDir, baseUrl, clock.value);
  }
  if (command === "reconcile") return cmdReconcile(stateDir, baseUrl, args);
  fail("bad_args");
}

main().catch((err) => {
  if (isCorrupt(err)) fail("corrupt_state");
  fail("service_unavailable");
});
