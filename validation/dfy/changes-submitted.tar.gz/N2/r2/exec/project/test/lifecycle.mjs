import { spawn } from "node:child_process";
import { mkdtempSync, writeFileSync, readFileSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { createHash } from "node:crypto";

const ROOT = new URL("..", import.meta.url).pathname;
const NODE = "/Users/galbal/.nvm/versions/node/v22.17.1/bin/node";
const CYCLE = 2592000000;

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, ["stub/server.mjs"], { cwd: ROOT, stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    child.stdout.on("data", (chunk) => {
      buf += chunk.toString();
      const line = buf.split("\n")[0];
      if (line.trim().startsWith("{")) {
        resolve({ child, info: JSON.parse(line) });
      }
    });
    child.on("error", reject);
    child.stderr.on("data", () => {});
  });
}

function run(args, env, { allowSignal = false } = {}) {
  return new Promise((resolve) => {
    const child = spawn(join(ROOT, "run"), args, {
      cwd: ROOT,
      env: { ...process.env, PATH: process.env.PATH, ...env },
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (c) => { stdout += c.toString(); });
    child.stderr.on("data", (c) => { stderr += c.toString(); });
    child.on("close", (code, signal) => {
      let json = null;
      const trimmed = stdout.trim();
      if (trimmed) {
        try { json = JSON.parse(trimmed); } catch { json = { _raw: stdout }; }
      }
      resolve({ code, signal, stdout, stderr, json });
    });
  });
}

async function get(url) {
  const response = await fetch(url);
  return response.json();
}

async function fault(control, body) {
  const response = await fetch(control + "/fault", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!response.ok) throw new Error("fault " + response.status);
}

function assert(cond, message, extra) {
  if (!cond) {
    const detail = extra === undefined ? "" : " " + JSON.stringify(extra);
    throw new Error(message + detail);
  }
}

function stateDir() {
  return mkdtempSync(join(tmpdir(), "plan-change-"));
}

const failures = [];
async function test(name, fn) {
  try {
    await fn();
    console.log("ok", name);
  } catch (err) {
    failures.push(name + ": " + err.message);
    console.error("FAIL", name, err.message);
  }
}

const stub = await startStub();
const SERVICE_URL = stub.info.service_url;
const CONTROL = stub.info.control_url;

function env(dir, now, extra = {}) {
  return { STATE_DIR: dir, SERVICE_URL, NOW_MS: String(now), ...extra };
}

await test("empty status and missing clock", async () => {
  const dir = stateDir();
  const status = await run(["status"], env(dir, 0));
  assert(status.code === 0, "status exit", status);
  assert(status.json.account_id === null && status.json.pending === "none" && status.json.submission === "none", "empty shape", status.json);
  assert(status.json.submission_id === null && status.json.applied_plan === null, "nulls", status.json);
  assert(status.json.invoice_id === null && status.json.invoice === "none" && status.json.amount_cents === null, "empty invoice", status.json);
  const missing = await run(["status"], { STATE_DIR: dir, SERVICE_URL });
  assert(missing.code !== 0 && missing.json.error === "missing_clock", "missing clock", missing);
  const bad = await run(["status"], env(dir, 0, { NOW_MS: "01" }));
  assert(bad.code !== 0 && bad.json.error === "bad_clock", "bad clock", bad);
  const crash = await run(["status"], env(dir, 0, { CRASH_AT: "after-accept-before-record" }));
  assert(crash.code === 0 && crash.signal === null, "status does not crash", crash);
});

await test("open binds one account and survives restart", async () => {
  const dir = stateDir();
  const opened = await run(["open", "acct-1", "basic", "0"], env(dir, 0));
  assert(opened.code === 0, "open", opened);
  assert(opened.json.account_id === "acct-1" && opened.json.current_plan === "basic" && opened.json.cycle_anchor_ms === 0, "open body", opened.json);
  assert(opened.json.pending === "none" && opened.json.submission === "none", "open pending", opened.json);
  const again = await run(["open", "acct-1", "basic", "0"], env(dir, 1));
  assert(again.code !== 0 && again.json.error === "already_open", "repeat open", again);
  const other = await run(["open", "acct-2", "plus", "0"], env(dir, 1));
  assert(other.code !== 0 && other.json.error === "already_open", "second account", other);
  const status = await run(["status"], env(dir, 9));
  assert(status.code === 0 && status.json.account_id === "acct-1" && status.json.current_plan === "basic", "restart status", status.json);
  const posts = await get(CONTROL + "/posts");
  assert(posts.count === 0, "open did not post", posts);
});

await test("schedule boundary, replace, cancel", async () => {
  const before = await get(CONTROL + "/posts");
  const dir = stateDir();
  await run(["open", "acct-1", "basic", "0"], env(dir, 0));
  const unknown = await run(["schedule", "gold"], env(dir, 0));
  assert(unknown.json.error === "unknown_plan" && unknown.code !== 0, "unknown plan", unknown);
  const same = await run(["schedule", "basic"], env(dir, 0));
  assert(same.json.error === "same_plan", "same plan", same);
  const scheduled = await run(["schedule", "plus"], env(dir, 0));
  assert(scheduled.code === 0, "schedule", scheduled);
  assert(scheduled.json.effective_at_ms === CYCLE && scheduled.json.to_plan === "plus" && scheduled.json.from_plan === "basic", "boundary", scheduled.json);
  assert(scheduled.json.submission === "none" && scheduled.json.submission_id === null && scheduled.json.pending === "scheduled", "not sent", scheduled.json);
  const changeId = scheduled.json.change_id;
  const second = await run(["schedule", "pro"], env(dir, 0));
  assert(second.json.error === "pending_exists", "pending", second);
  const status = await run(["status"], env(dir, 1));
  assert(status.json.change_id === changeId && status.json.effective_at_ms === CYCLE, "status keeps change", status.json);
  const early = await run(["apply"], env(dir, CYCLE - 1));
  assert(early.code !== 0 && early.json.error === "not_due", "not due", early);
  const still = await run(["status"], env(dir, CYCLE - 1));
  assert(still.json.change_id === changeId && still.json.pending === "scheduled", "pending remains", still.json);
  const sameTarget = await run(["replace", "plus"], env(dir, 10));
  assert(sameTarget.json.error === "same_target", "same target", sameTarget);
  const due = await run(["replace", "pro"], env(dir, CYCLE));
  assert(due.json.error === "already_due", "already due", due);
  const replaced = await run(["replace", "pro"], env(dir, 10));
  assert(replaced.code === 0 && replaced.json.to_plan === "pro" && replaced.json.effective_at_ms === CYCLE, "replace", replaced.json);
  assert(replaced.json.change_id !== changeId, "new change id", replaced.json);
  const mismatch = await run(["cancel", changeId], env(dir, CYCLE));
  assert(mismatch.json.error === "change_mismatch", "old id", mismatch);
  const kept = await run(["status"], env(dir, CYCLE));
  assert(kept.json.change_id === replaced.json.change_id && kept.json.to_plan === "pro", "replace stuck", kept.json);
  const cancelled = await run(["cancel", replaced.json.change_id], env(dir, CYCLE));
  assert(cancelled.code === 0 && cancelled.json.change_id === replaced.json.change_id && cancelled.json.pending === "none", "cancel due", cancelled.json);
  const apply = await run(["apply"], env(dir, CYCLE));
  assert(apply.code !== 0 && apply.json.error === "no_pending", "apply after cancel", apply);
  const after = await get(CONTROL + "/posts");
  assert(after.count === before.count, "refusals did not post", { before: before.count, after: after.count });
});

await test("anchor examples", async () => {
  const early = stateDir();
  await run(["open", "acct-1", "basic", "100"], env(early, 50));
  const scheduled = await run(["schedule", "plus"], env(early, 50));
  assert(scheduled.json.effective_at_ms === 100, "before anchor", scheduled.json);
  const boundary = stateDir();
  await run(["open", "acct-1", "plus", "0"], env(boundary, CYCLE));
  const next = await run(["schedule", "pro"], env(boundary, CYCLE));
  assert(next.json.effective_at_ms === CYCLE * 2, "on boundary", next.json);
});

await test("healthy apply is once", async () => {
  await fault(CONTROL, {});
  const dir = stateDir();
  const opened = await run(["open", "acct-1", "basic", "0"], env(dir, 0));
  const scheduled = await run(["schedule", "plus"], env(dir, 0));
  assert(opened.code === 0 && scheduled.code === 0, "setup", { opened, scheduled });
  const applied = await run(["apply"], env(dir, scheduled.json.effective_at_ms));
  assert(applied.code === 0 && applied.json.submission === "applied", "apply", applied);
  assert(applied.json.current_plan === "plus" && applied.json.applied_plan === "plus", "plan", applied.json);
  assert(applied.json.submission_id && applied.json.change_id === scheduled.json.change_id, "ids", applied.json);
  const status = await run(["status"], env(dir, scheduled.json.effective_at_ms));
  assert(status.json.submission === "applied" && status.json.current_plan === "plus" && status.json.applied_plan === "plus", "status", status.json);
  const account = await get(SERVICE_URL + "/v1/accounts/acct-1");
  assert(account.to_plan === "plus" && account.submission_id === applied.json.submission_id, "provider", account);
  const effects = await get(CONTROL + "/effects");
  const posts = await get(CONTROL + "/posts");
  const second = await run(["apply"], env(dir, scheduled.json.effective_at_ms));
  assert(second.code === 0 && second.json.submission_id === applied.json.submission_id, "second apply", second);
  const effects2 = await get(CONTROL + "/effects");
  const posts2 = await get(CONTROL + "/posts");
  assert(effects2.count === effects.count && effects.count === 1, "one effect", { effects, effects2 });
  assert(posts2.count === posts.count, "no second post", { posts, posts2 });
});

await test("callbacks do not overwrite", async () => {
  await fault(CONTROL, {});
  const dir = stateDir();
  await run(["open", "acct-1", "basic", "0"], env(dir, 0));
  const scheduled = await run(["schedule", "plus"], env(dir, 0));
  const applied = await run(["apply"], env(dir, scheduled.json.effective_at_ms));
  assert(applied.code === 0, "apply", applied);
  const effects = await get(CONTROL + "/effects");
  const file = join(dir, "cb.json");
  const callback = {
    callback_id: "cb-1",
    submission_id: applied.json.submission_id,
    account_id: "acct-1",
    to_plan: "plus",
    effective_at_ms: scheduled.json.effective_at_ms,
    outcome: "applied",
  };
  writeFileSync(file, JSON.stringify(callback));
  const once = await run(["callback", file], env(dir, 1));
  const twice = await run(["callback", file], env(dir, 1));
  callback.to_plan = "pro";
  callback.callback_id = "cb-2";
  writeFileSync(file, JSON.stringify(callback));
  const other = await run(["callback", file], env(dir, 1));
  assert(once.code === 0 && twice.code === 0 && other.code === 0, "callbacks accepted", { once, twice, other });
  const status = await run(["status"], env(dir, 1));
  assert(status.json.current_plan === "plus" && status.json.applied_plan === "plus" && status.json.submission === "applied", "unchanged", status.json);
  const effects2 = await get(CONTROL + "/effects");
  assert(effects2.count === effects.count, "no extra effect", { effects, effects2 });
  writeFileSync(file, "{");
  const bad = await run(["callback", file], env(dir, 1));
  assert(bad.code !== 0 && bad.json.error === "bad_callback", "bad callback", bad);
});

await test("crash before request then resume same submission", async () => {
  await fault(CONTROL, {});
  const dir = stateDir();
  await run(["open", "acct-1", "basic", "0"], env(dir, 0));
  const scheduled = await run(["schedule", "plus"], env(dir, 0));
  const beforeEffects = await get(CONTROL + "/effects");
  const killed = await run(["apply"], env(dir, CYCLE, { CRASH_AT: "after-attempt-saved-before-request" }));
  assert(killed.signal === "SIGKILL", "sigkill", killed);
  const effects = await get(CONTROL + "/effects");
  assert(effects.count === beforeEffects.count, "no effect yet", { before: beforeEffects.count, after: effects.count });
  const status = await run(["status"], env(dir, CYCLE));
  assert(status.json.submission === "attempt_saved" && status.json.submission_id, "saved", status.json);
  const savedId = status.json.submission_id;
  const cancel = await run(["cancel", status.json.change_id], env(dir, CYCLE));
  assert(cancel.json.error === "attempt_saved", "cancel blocked", cancel);
  const replace = await run(["replace", "pro"], env(dir, 1));
  assert(replace.json.error === "attempt_saved", "replace blocked", replace);
  const resumed = await run(["apply"], env(dir, CYCLE));
  assert(resumed.code === 0 && resumed.json.submission_id === savedId && resumed.json.submission === "applied", "resume", resumed);
  const effects2 = await get(CONTROL + "/effects");
  assert(effects2.count === beforeEffects.count + 1 && effects2.effects.at(-1).submission_id === savedId, "one effect same id", effects2);
});

await test("crash after accept adopts without a second effect", async () => {
  await fault(CONTROL, {});
  const dir = stateDir();
  await run(["open", "acct-1", "basic", "0"], env(dir, 0));
  await run(["schedule", "plus"], env(dir, 0));
  const beforeEffects = await get(CONTROL + "/effects");
  const killed = await run(["apply"], env(dir, CYCLE, { CRASH_AT: "after-accept-before-record" }));
  assert(killed.signal === "SIGKILL", "sigkill", killed);
  const effects = await get(CONTROL + "/effects");
  assert(effects.count === beforeEffects.count + 1, "provider counted", { before: beforeEffects.count, after: effects.count });
  const status = await run(["status"], env(dir, CYCLE));
  assert(status.json.submission === "attempt_saved", "not locally applied", status.json);
  const savedId = status.json.submission_id;
  const resumed = await run(["apply"], env(dir, CYCLE));
  assert(resumed.code === 0 && resumed.json.submission === "applied" && resumed.json.submission_id === savedId, "adopt", resumed);
  assert(resumed.json.lookup !== "not_sent", "not not_sent", resumed.json);
  const effects2 = await get(CONTROL + "/effects");
  assert(effects2.count === effects.count, "no second effect", { effects: effects.count, effects2: effects2.count });
  const posts = await get(CONTROL + "/posts");
  assert(posts.posts.filter((p) => p.submission_id === savedId).length === 1, "one post", posts);
});

await test("crash after record then apply adds no effect", async () => {
  await fault(CONTROL, {});
  const dir = stateDir();
  await run(["open", "acct-1", "basic", "0"], env(dir, 0));
  await run(["schedule", "pro"], env(dir, 0));
  const beforeEffects = await get(CONTROL + "/effects");
  const killed = await run(["apply"], env(dir, CYCLE, { CRASH_AT: "after-record-before-exit" }));
  assert(killed.signal === "SIGKILL", "sigkill", killed);
  const status = await run(["status"], env(dir, CYCLE));
  assert(status.json.submission === "applied" && status.json.current_plan === "pro", "recorded", status.json);
  const effects = await get(CONTROL + "/effects");
  assert(effects.count === beforeEffects.count + 1, "recorded one effect", { before: beforeEffects.count, after: effects.count });
  const again = await run(["apply"], env(dir, CYCLE));
  assert(again.code === 0, "later apply", again);
  const effects2 = await get(CONTROL + "/effects");
  assert(effects2.count === effects.count && effects.count === beforeEffects.count + 1, "unchanged count", { before: beforeEffects.count, effects: effects.count, effects2: effects2.count });
});

await test("lost reply then reconcile", async () => {
  await fault(CONTROL, { drop_reply: true });
  const dir = stateDir();
  await run(["open", "acct-1", "basic", "0"], env(dir, 0));
  const scheduled = await run(["schedule", "plus"], env(dir, 0));
  const beforeEffects = await get(CONTROL + "/effects");
  const applied = await run(["apply"], env(dir, CYCLE));
  assert(applied.code !== 0 && applied.json.error === "service_unavailable", "lost reply", applied);
  const status = await run(["status"], env(dir, CYCLE));
  assert(status.json.submission === "attempt_saved" && status.json.submission_id, "still saved", status.json);
  const effects = await get(CONTROL + "/effects");
  assert(effects.count === beforeEffects.count + 1, "effect counted", { before: beforeEffects.count, after: effects.count });
  const posts = await get(CONTROL + "/posts");
  const mismatch = await run(["reconcile", "other-id"], env(dir, CYCLE, { SERVICE_URL: "http://127.0.0.1:9" }));
  assert(mismatch.code !== 0 && mismatch.json.error === "submission_mismatch", "mismatch", mismatch);
  const reconciled = await run(["reconcile", status.json.submission_id], env(dir, CYCLE, { CRASH_AT: "after-record-before-exit" }));
  assert(reconciled.signal === "SIGKILL", "reconcile crash", reconciled);
  const after = await run(["status"], env(dir, CYCLE));
  assert(after.json.submission === "applied" && after.json.current_plan === "plus" && after.json.applied_plan === "plus", "adopted", after.json);
  const effects2 = await get(CONTROL + "/effects");
  const posts2 = await get(CONTROL + "/posts");
  assert(effects2.count === effects.count, "no second effect", { effects, effects2 });
  assert(posts2.count === posts.count, "reconcile did not post", { posts, posts2 });
  await fault(CONTROL, {});
  const again = await run(["reconcile", status.json.submission_id], env(dir, CYCLE));
  assert(again.code === 0 && again.json.lookup === "applied" && again.json.submission_id === status.json.submission_id, "already applied lookup", again);
});

await test("reconcile not_sent does not post", async () => {
  await fault(CONTROL, {});
  const dir = stateDir();
  await run(["open", "acct-1", "basic", "0"], env(dir, 0));
  await run(["schedule", "plus"], env(dir, 0));
  const killed = await run(["apply"], env(dir, CYCLE, { CRASH_AT: "after-attempt-saved-before-request" }));
  assert(killed.signal === "SIGKILL", "saved", killed);
  const status = await run(["status"], env(dir, CYCLE));
  const posts = await get(CONTROL + "/posts");
  const none = await run(["reconcile", "nope"], env(dir, CYCLE, { SERVICE_URL: "http://127.0.0.1:9" }));
  assert(none.json.error === "submission_mismatch", "no contact mismatch", none);
  const looked = await run(["reconcile", status.json.submission_id], env(dir, CYCLE));
  assert(looked.code === 0 && looked.json.lookup === "not_sent" && looked.json.submission === "attempt_saved", "not sent", looked.json);
  assert(looked.json.submission_id === status.json.submission_id, "same id", looked.json);
  const status2 = await run(["status"], env(dir, CYCLE));
  assert(status2.json.submission === "attempt_saved" && status2.json.applied_plan === null, "not applied", status2.json);
  const posts2 = await get(CONTROL + "/posts");
  assert(posts2.count === posts.count, "no post", { posts, posts2 });
  const empty = stateDir();
  const missing = await run(["reconcile", "abc"], env(empty, 0, { SERVICE_URL: "http://127.0.0.1:9" }));
  assert(missing.json.error === "no_attempt", "no attempt", missing);
});

await test("unrelated writer and corrupt store", async () => {
  const dir = stateDir();
  const alien = join(dir, "other.txt");
  writeFileSync(alien, "keep-me");
  await run(["open", "acct-1", "basic", "0"], env(dir, 0));
  writeFileSync(alien, "keep-me-still");
  const before = readFileSync(alien);
  await run(["schedule", "plus"], env(dir, 0));
  const after = readFileSync(alien);
  assert(Buffer.compare(before, after) === 0, "bytes unchanged");
  const corruptDir = stateDir();
  writeFileSync(join(corruptDir, "plan-change.sqlite"), "{not-json");
  const beforeCorrupt = readFileSync(join(corruptDir, "plan-change.sqlite"));
  const corrupt = await run(["status"], env(corruptDir, 0));
  assert(corrupt.code !== 0 && corrupt.json.error === "corrupt_state", "corrupt", corrupt);
  const afterCorrupt = readFileSync(join(corruptDir, "plan-change.sqlite"));
  assert(Buffer.compare(beforeCorrupt, afterCorrupt) === 0, "corrupt file not rewritten");
});

await test("bad open does not bind", async () => {
  const dir = stateDir();
  const badPlan = await run(["open", "acct-1", "nope", "0"], env(dir, 0));
  assert(badPlan.json.error === "unknown_plan", "unknown", badPlan);
  const badId = await run(["open", "bad id", "basic", "0"], env(dir, 0));
  assert(badId.json.error === "bad_args", "bad id", badId);
  const status = await run(["status"], env(dir, 0));
  assert(status.json.account_id === null, "unbound", status.json);
});

await test("unpaid invoice blocks downgrade scheduling but permits upgrade", async () => {
  const dir = stateDir();
  await run(["open", "acct-1", "plus", "0"], env(dir, 0));
  const invoice = await run(["invoice", "inv-1", "2500"], env(dir, 0));
  assert(invoice.code === 0 && invoice.json.invoice === "unpaid", "invoice", invoice);
  const blocked = await run(["schedule", "basic"], env(dir, 0));
  assert(blocked.code !== 0 && blocked.json.error === "unpaid_downgrade", "blocked downgrade", blocked);
  const status = await run(["status"], env(dir, 0));
  assert(status.json.pending === "none" && status.json.current_plan === "plus", "blocked state", status.json);
  const upgrade = await run(["schedule", "pro"], env(dir, 0));
  assert(upgrade.code === 0 && upgrade.json.to_plan === "pro", "upgrade", upgrade);
});

await test("unpaid replacement preserves legal pending changes", async () => {
  const blockedDir = stateDir();
  await run(["open", "acct-1", "plus", "0"], env(blockedDir, 0));
  const pending = await run(["schedule", "pro"], env(blockedDir, 0));
  await run(["invoice", "inv-2", "100"], env(blockedDir, 0));
  const blocked = await run(["replace", "basic"], env(blockedDir, 1));
  assert(blocked.code !== 0 && blocked.json.error === "unpaid_downgrade", "blocked replacement", blocked);
  const kept = await run(["status"], env(blockedDir, 1));
  assert(kept.json.change_id === pending.json.change_id && kept.json.to_plan === "pro", "pending survived", kept.json);

  const allowedDir = stateDir();
  await run(["open", "acct-2", "plus", "0"], env(allowedDir, 0));
  const old = await run(["schedule", "basic"], env(allowedDir, 0));
  await run(["invoice", "inv-3", "100"], env(allowedDir, 0));
  const replaced = await run(["replace", "pro"], env(allowedDir, 1));
  assert(replaced.code === 0 && replaced.json.to_plan === "pro", "upgrade replacement", replaced);
  assert(replaced.json.change_id !== old.json.change_id && replaced.json.effective_at_ms === old.json.effective_at_ms, "replacement ids/time", replaced);
  const oldCancel = await run(["cancel", old.json.change_id], env(allowedDir, 1));
  assert(oldCancel.code !== 0 && oldCancel.json.error === "change_mismatch", "old cancellation", oldCancel);
});

await test("unpaid due downgrade waits for payment", async () => {
  await fault(CONTROL, {});
  const dir = stateDir();
  await run(["open", "acct-1", "plus", "0"], env(dir, 0));
  const pending = await run(["schedule", "basic"], env(dir, 0));
  await run(["invoice", "inv-4", "500"], env(dir, 0));
  const blocked = await run(["apply"], env(dir, pending.json.effective_at_ms));
  assert(blocked.code !== 0 && blocked.json.error === "unpaid_downgrade", "blocked apply", blocked);
  const saved = await run(["status"], env(dir, pending.json.effective_at_ms));
  assert(saved.json.submission === "none" && saved.json.pending === "scheduled", "not attempted", saved.json);
  const paid = await run(["pay", "inv-4"], env(dir, pending.json.effective_at_ms));
  assert(paid.code === 0 && paid.json.invoice === "paid", "paid", paid);
  const applied = await run(["apply"], env(dir, pending.json.effective_at_ms));
  assert(applied.code === 0 && applied.json.current_plan === "basic" && applied.json.submission === "applied", "apply after payment", applied);
  const effects = await get(CONTROL + "/effects");
  const again = await run(["apply"], env(dir, pending.json.effective_at_ms));
  const effects2 = await get(CONTROL + "/effects");
  assert(again.code === 0 && effects2.count === effects.count, "apply once", { again, effects, effects2 });
});

stub.child.kill("SIGKILL");
if (failures.length) {
  console.error(failures.join("\n"));
  process.exit(1);
}
console.log("all passed");
