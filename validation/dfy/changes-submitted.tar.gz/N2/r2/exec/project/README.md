# Plan-change scheduler

Local tool that records one account's subscription plan and a single pending
plan change, then asks the billing provider to apply that change at most once.

Lifecycle transitions and their durable record live in the Ikaros machine
`machines/plan_change.ik.toml`. The process around `./run` only parses the
command, computes the next cycle boundary from `NOW_MS`, and performs the
billing HTTP call.

## Setup

Node 22. From this directory, with the shipped tarballs:

```sh
npm install --offline --no-audit --no-fund
```

`package.json` already points at `KIT/npm/ikaros-runtime-0.5.0.tgz` and
`KIT/npm/ikaros-darwin-arm64-0.5.0.tgz`. No network registry is required.

## Run

```sh
export STATE_DIR=/tmp/plan-change
export SERVICE_URL=http://127.0.0.1:9
export NOW_MS=0
./run open acct-1 basic 0
```

Each invocation prints one JSON object. Exit 0 is success. A refusal is a nonzero exit and `{"error":"..."}`.

## Invoices

An invoice is local durable state and is never sent to the provider. While an
invoice is unpaid, a lower plan cannot be scheduled, substituted, or applied.
Paying the invoice removes that block without contacting the provider:

```sh
./run invoice invoice-1 2500
./run pay invoice-1
```

`status` includes `invoice_id`, `invoice` (`none`, `unpaid`, or `paid`), and
`amount_cents`.

The machine definition is now version 2. Existing stores made by the prior
machine version are not migrated. `machines/plan_change_v1.ik.toml` remains
available for an explicitly pinned old reader; the current `./run` refuses
mutating commands for those stores rather than silently changing their
machine identity. Recreate a store before using invoice commands.

## Provider and crash testing

The billing provider is `stub/server.mjs` (see `stub/CONTRACT.md`). It chooses
its own port and prints `{"service_url","control_url"}`. Point `SERVICE_URL` at
`service_url`. This tool never calls the control port.

Optional `CRASH_AT` is `after-attempt-saved-before-request`,
`after-accept-before-record`, or `after-record-before-exit`. Reaching that
boundary kills the process with `SIGKILL`.

## Tests

```sh
node test/lifecycle.mjs
```

The tests start `stub/server.mjs`, including process restart, crash labels, and
a dropped provider reply.
