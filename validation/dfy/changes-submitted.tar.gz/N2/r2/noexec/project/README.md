# Plan-change scheduler

Local tool that records one account's subscription plan and a single pending
plan change, then asks the billing provider to apply that change at most once.
An optional unpaid invoice on the account blocks scheduling, replacing, or
applying a downgrade until it is paid or the pending target is raised back to
an upgrade; it never blocks an upgrade and never reaches the billing provider.

Lifecycle transitions and their durable record live in the Ikaros machine
`machines/plan_change.ik.toml`, authored as two orthogonal regions: `lifecycle`
(`unbound` → `bound` → `scheduled`/`attempting` → `applied`) and `invoice`
(`none` → `unpaid` → `paid`). The process around `./run` only parses the
command, computes the next cycle boundary from `NOW_MS`, ranks plans for the
downgrade gate, and performs the billing HTTP call.

## Setup

Node 22. From this directory, with the shipped tarballs:

```sh
npm install --offline --no-audit --no-fund
```

`package.json` already points at `KIT/npm/ikaros-runtime-0.5.0.tgz` and
`KIT/npm/ikaros-darwin-arm64-0.5.0.tgz`. No network registry is required.

## Run

```sh
export STATE_DIR=/tmp/plan-change
export SERVICE_URL=http://127.0.0.1:9
export NOW_MS=0
./run open acct-1 basic 0
```

Each invocation prints one JSON object on stdout. Exit 0 is success. A refusal
is a nonzero exit and `{"error":"..."}`.

The billing provider is `stub/server.mjs` (see `stub/CONTRACT.md`). It chooses
its own port and prints `{"service_url","control_url"}`. Point `SERVICE_URL` at
`service_url`. This tool never calls the control port.

Optional `CRASH_AT` is `after-attempt-saved-before-request`,
`after-accept-before-record`, or `after-record-before-exit`. Reaching that
boundary kills the process with `SIGKILL`.

### Invoices

```sh
./run invoice inv-1 2500    # record an unpaid invoice for 2500 cents
./run pay inv-1              # mark it paid
```

While an invoice is `unpaid`, `schedule` of a lower-rank plan, `replace` into a
lower-rank plan, and a due `apply` of an already-pending downgrade each refuse
`unpaid_downgrade` and change nothing. An upgrade is never blocked. Plan rank
is `basic` < `plus` < `pro`. `status` always reports `invoice_id`, `invoice`
(`none`/`unpaid`/`paid`), and `amount_cents`.

## Tests

```sh
node test/lifecycle.mjs
```

The tests start `stub/server.mjs`, including process restart, crash labels,
a dropped provider reply, and the unpaid-downgrade gate on `schedule`,
`replace`, and `apply`.

## Changing this machine

`machines/plan_change.ik.toml` is `machine_version = 2` (schema 2, with the
`invoice` region added alongside the original `lifecycle` region). A store
created by the prior `machine_version = 1` definition cannot be opened by this
binary: the kernel reports `IK_MACHINE_MISMATCH`, which this tool maps to the
existing `corrupt_state` refusal rather than a stack trace. There is no
migrator. A pre-existing `STATE_DIR` from before this change must be reopened
under a fresh, empty `STATE_DIR`; its account/plan/pending-change history is
not carried forward automatically.
