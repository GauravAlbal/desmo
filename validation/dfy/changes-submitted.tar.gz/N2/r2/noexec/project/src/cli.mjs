import { createHash, randomBytes } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, statSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { Kernel, StoreNotFoundError, classify } from "@ikaros/runtime";

const AGGREGATE_ID = "account";
const CYCLE_MS = 2592000000;
const PLANS = new Set(["basic", "plus", "pro"]);
const RANK = { basic: 1, plus: 2, pro: 3 };
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const CLOCK_RE = /^(0|[1-9][0-9]*)$/;
const AMOUNT_RE = /^[1-9][0-9]*$/;
const MAX_AMOUNT_CENTS = 100000000;
const ROOT = dirname(fileURLToPath(import.meta.url));
const MACHINE_PATH = join(ROOT, "..", "machines", "plan_change.ik.toml");
const require = createRequire(import.meta.url);
const IK_BINARY = join(dirname(require.resolve("@ikaros/darwin-arm64/package.json")), "bin", "ik");

const EMPTY_STATUS = {
  account_id: null,
  current_plan: null,
  cycle_anchor_ms: null,
  change_id: null,
  from_plan: null,
  to_plan: null,
  effective_at_ms: null,
  pending: "none",
  submission: "none",
  submission_id: null,
  applied_plan: null,
  invoice_id: null,
  invoice: "none",
  amount_cents: null,
};

function emit(obj, code) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(code);
}

function ok(obj) {
  emit(obj, 0);
}

function fail(error) {
  emit({ error }, 1);
}

function dieAt(label) {
  if (process.env.CRASH_AT !== label) return;
  process.kill(process.pid, "SIGKILL");
  for (;;) {}
}

function sha256(text) {
  return createHash("sha256").update(text).digest("hex");
}

function newId(prefix) {
  return prefix + randomBytes(16).toString("hex");
}

function parseClock(raw) {
  if (raw === undefined) return { error: "missing_clock" };
  if (!CLOCK_RE.test(raw)) return { error: "bad_clock" };
  if (raw.length > 16) return { error: "bad_clock" };
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || String(value) !== raw) return { error: "bad_clock" };
  return { value };
}

function parseAmount(raw) {
  if (raw === undefined || !AMOUNT_RE.test(raw)) return null;
  if (raw.length > 9) return null;
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || String(value) !== raw) return null;
  if (value > MAX_AMOUNT_CENTS) return null;
  return value;
}

function isDowngrade(fromPlan, toPlan) {
  return RANK[toPlan] < RANK[fromPlan];
}

function nextBoundary(anchor, now) {
  if (now < anchor) return anchor;
  const delta = now - anchor;
  const cycles = Math.floor(delta / CYCLE_MS) + 1;
  if (!Number.isSafeInteger(cycles)) return null;
  if (cycles > Math.floor((Number.MAX_SAFE_INTEGER - anchor) / CYCLE_MS)) return null;
  const effective = anchor + cycles * CYCLE_MS;
  if (!Number.isSafeInteger(effective) || effective <= now) return null;
  return effective;
}

function storePath() {
  return join(process.env.STATE_DIR, "plan-change.sqlite");
}

function sqlitePresent() {
  const path = storePath();
  if (!existsSync(path)) return false;
  try {
    const head = readFileSync(path).subarray(0, 16);
    return head.toString("utf8") === "SQLite format 3\u0000";
  } catch {
    return false;
  }
}

function assertStoreReadable() {
  const path = storePath();
  if (!existsSync(path)) return;
  let bytes;
  try {
    bytes = readFileSync(path);
  } catch {
    fail("corrupt_state");
  }
  if (bytes.length < 16 || bytes.subarray(0, 16).toString("utf8") !== "SQLite format 3\u0000") {
    fail("corrupt_state");
  }
}

function kernel() {
  return new Kernel(storePath(), { binary: IK_BINARY });
}

async function loadMachine() {
  return kernel().machine(MACHINE_PATH);
}

async function loadAggregate() {
  assertStoreReadable();
  if (!sqlitePresent()) return null;
  const machine = await loadMachine();
  try {
    return await machine.show(AGGREGATE_ID);
  } catch (err) {
    if (classify(err) === "corrupt") fail("corrupt_state");
    if (err instanceof StoreNotFoundError || err.rule === "store.missing") return null;
    if (err.rule === "aggregate.not_found" || err.code === "IK_ILLEGAL_STATE") return null;
    if (classify(err) === "not_found") return null;
    // A store created under a prior machine_version (before the invoice
    // region existed) cannot be read by this definition. There is no
    // migrator; treat it the same as an unreadable store.
    if (err.code === "IK_MACHINE_MISMATCH") fail("corrupt_state");
    throw err;
  }
}

function viewOf(aggregate) {
  if (!aggregate) return { ...EMPTY_STATUS };
  const f = aggregate.state;
  const name = f.region_lifecycle;
  const pending = name === "scheduled" || name === "attempting" ? "scheduled" : "none";
  let submission = "none";
  if (name === "attempting") submission = "attempt_saved";
  if (name === "applied") submission = "applied";
  const showChange = submission !== "none" || pending === "scheduled";
  const invoiceState = f.region_invoice ?? "none";
  return {
    account_id: f.account_id ?? null,
    current_plan: f.current_plan ?? null,
    cycle_anchor_ms: f.cycle_anchor_ms ?? null,
    change_id: showChange ? f.change_id ?? null : null,
    from_plan: showChange ? f.from_plan ?? null : null,
    to_plan: showChange ? f.to_plan ?? null : null,
    effective_at_ms: showChange ? f.effective_at_ms ?? null : null,
    pending,
    submission,
    submission_id: submission === "none" ? null : f.submission_id ?? null,
    applied_plan: submission === "applied" ? f.applied_plan ?? null : null,
    invoice_id: invoiceState === "none" ? null : f.invoice_id ?? null,
    invoice: invoiceState,
    amount_cents: invoiceState === "none" ? null : f.invoice_amount_cents ?? null,
  };
}

function scheduleShape(view) {
  return {
    change_id: view.change_id,
    account_id: view.account_id,
    from_plan: view.from_plan,
    to_plan: view.to_plan,
    effective_at_ms: view.effective_at_ms,
    pending: "scheduled",
    submission: "none",
    submission_id: null,
  };
}

function appliedShape(view) {
  return {
    account_id: view.account_id,
    change_id: view.change_id,
    submission_id: view.submission_id,
    from_plan: view.from_plan,
    to_plan: view.to_plan,
    effective_at_ms: view.effective_at_ms,
    current_plan: view.current_plan,
    pending: "none",
    submission: "applied",
    applied_plan: view.applied_plan,
  };
}

function requestBody(view) {
  return {
    submission_id: view.submission_id,
    account_id: view.account_id,
    from_plan: view.from_plan,
    to_plan: view.to_plan,
    effective_at_ms: view.effective_at_ms,
  };
}

function matchesAttempt(parsed, view) {
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return false;
  return parsed.submission_id === view.submission_id
    && parsed.account_id === view.account_id
    && parsed.to_plan === view.to_plan
    && parsed.effective_at_ms === view.effective_at_ms
    && parsed.outcome === "applied"
    && (parsed.from_plan === undefined || parsed.from_plan === view.from_plan);
}

async function httpCall(method, path, body) {
  const url = process.env.SERVICE_URL + path;
  try {
    const response = await fetch(url, {
      method,
      headers: body === undefined ? undefined : { "content-type": "application/json" },
      body,
    });
    let text;
    try {
      text = await response.text();
    } catch {
      return { kind: "unavailable" };
    }
    return { kind: "http", status: response.status, text };
  } catch {
    return { kind: "unavailable" };
  }
}

function parseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return undefined;
  }
}

async function commitApplied(aggregate, responseText, lookup) {
  let current = aggregate;
  if (current.effect.status === "pending") {
    current = await current.recordEffectOutcome(sha256(responseText));
  }
  if (current.state.region_lifecycle === "attempting") {
    const f = current.state;
    current = await current.command("complete", {
      applied_plan: f.to_plan,
      submission_id: f.submission_id,
      effective_at_ms: f.effective_at_ms,
    });
  }
  dieAt("after-record-before-exit");
  const body = appliedShape(viewOf(current));
  if (lookup) ok({ lookup: "applied", ...body });
  ok(body);
}

async function postSaved(view, aggregate) {
  const payload = JSON.stringify(requestBody(view));
  const http = await httpCall("POST", "/v1/plan-changes", payload);
  if (http.kind !== "http") fail("service_unavailable");
  if (http.status >= 500) fail("service_unavailable");
  const parsed = parseJson(http.text);
  if (http.status === 200 && matchesAttempt(parsed, view)) {
    dieAt("after-accept-before-record");
    await commitApplied(aggregate, http.text);
    return;
  }
  if (http.status === 409 || http.status === 200) fail("lookup_conflict");
  fail("service_unavailable");
}

async function resumeAttempt(aggregate) {
  const view = viewOf(aggregate);
  const looked = await httpCall("GET", "/v1/submissions/" + view.submission_id);
  if (looked.kind !== "http") fail("service_unavailable");
  if (looked.status === 404) {
    await postSaved(view, aggregate);
    return;
  }
  if (looked.status >= 500) fail("service_unavailable");
  const parsed = parseJson(looked.text);
  if (looked.status === 200 && matchesAttempt(parsed, view)) {
    await commitApplied(aggregate, looked.text);
    return;
  }
  fail("lookup_conflict");
}

async function firstAttempt(aggregate, now) {
  const before = viewOf(aggregate);
  const submissionId = newId("sub-");
  const body = {
    submission_id: submissionId,
    account_id: before.account_id,
    from_plan: before.from_plan,
    to_plan: before.to_plan,
    effective_at_ms: before.effective_at_ms,
  };
  const payload = JSON.stringify(body);
  const saved = await aggregate.command("save_attempt", {
    submission_id: submissionId,
    effect_id: submissionId,
    payload_digest: sha256(payload),
    idempotency_key: submissionId,
    now_ms: now,
  });
  dieAt("after-attempt-saved-before-request");
  const http = await httpCall("POST", "/v1/plan-changes", payload);
  if (http.kind !== "http") fail("service_unavailable");
  if (http.status >= 500) fail("service_unavailable");
  const parsed = parseJson(http.text);
  const view = viewOf(saved);
  if (http.status === 200 && matchesAttempt(parsed, view)) {
    dieAt("after-accept-before-record");
    await commitApplied(saved, http.text);
    return;
  }
  if (http.status === 409 || http.status === 200) fail("lookup_conflict");
  fail("service_unavailable");
}

function requirePlan(plan) {
  if (!PLANS.has(plan)) fail("unknown_plan");
}

function requireId(value) {
  if (!ID_RE.test(value ?? "")) fail("bad_args");
}

async function open(args, now) {
  if (args.length !== 3) fail("bad_args");
  const [accountId, plan, anchorRaw] = args;
  requireId(accountId);
  requirePlan(plan);
  const anchor = parseClock(anchorRaw);
  if (anchor.error) fail(anchor.error === "missing_clock" ? "bad_clock" : anchor.error);
  const existing = await loadAggregate();
  if (existing) fail("already_open");
  mkdirSync(process.env.STATE_DIR, { recursive: true });
  const machine = await loadMachine();
  const created = await machine.createWith({
    aggregateId: AGGREGATE_ID,
    command: {
      name: "bind",
      args: { account_id: accountId, current_plan: plan, cycle_anchor_ms: anchor.value },
    },
  });
  const view = viewOf(created);
  ok({
    account_id: view.account_id,
    current_plan: view.current_plan,
    cycle_anchor_ms: view.cycle_anchor_ms,
    pending: "none",
    submission: "none",
  });
}

async function schedule(args, now) {
  if (args.length !== 1) fail("bad_args");
  const plan = args[0];
  requirePlan(plan);
  const aggregate = await loadAggregate();
  if (!aggregate) fail("bad_args");
  const name = aggregate.state.region_lifecycle;
  if (name === "scheduled" || name === "attempting") fail("pending_exists");
  if (name !== "bound" && name !== "applied") fail("bad_args");
  const view = viewOf(aggregate);
  if (plan === view.current_plan) fail("same_plan");
  if (view.invoice === "unpaid" && isDowngrade(view.current_plan, plan)) fail("unpaid_downgrade");
  const effective = nextBoundary(view.cycle_anchor_ms, now);
  if (effective === null) fail("bad_clock");
  const changeId = newId("chg-");
  const updated = await aggregate.command("schedule", {
    change_id: changeId,
    from_plan: view.current_plan,
    to_plan: plan,
    effective_at_ms: effective,
  });
  ok(scheduleShape(viewOf(updated)));
}

async function replace(args, now) {
  if (args.length !== 1) fail("bad_args");
  const plan = args[0];
  requirePlan(plan);
  const aggregate = await loadAggregate();
  if (!aggregate) fail("no_pending");
  const name = aggregate.state.region_lifecycle;
  if (name === "attempting") fail("attempt_saved");
  if (name !== "scheduled") fail("no_pending");
  const view = viewOf(aggregate);
  if (now >= view.effective_at_ms) fail("already_due");
  if (plan === view.current_plan) fail("same_plan");
  if (plan === view.to_plan) fail("same_target");
  if (view.invoice === "unpaid" && isDowngrade(view.current_plan, plan)) fail("unpaid_downgrade");
  let changeId = newId("chg-");
  if (changeId === view.change_id) changeId = newId("chg-");
  const updated = await aggregate.command("replace", {
    change_id: changeId,
    to_plan: plan,
    now_ms: now,
  });
  ok(scheduleShape(viewOf(updated)));
}

async function cancel(args) {
  if (args.length !== 1) fail("bad_args");
  const changeId = args[0];
  requireId(changeId);
  const aggregate = await loadAggregate();
  if (!aggregate) fail("no_pending");
  const name = aggregate.state.region_lifecycle;
  if (name === "attempting") fail("attempt_saved");
  if (name !== "scheduled") fail("no_pending");
  const view = viewOf(aggregate);
  if (changeId !== view.change_id) fail("change_mismatch");
  const updated = await aggregate.command("cancel", { change_id: changeId });
  const after = viewOf(updated);
  ok({
    account_id: after.account_id,
    change_id: changeId,
    current_plan: after.current_plan,
    pending: "none",
    submission: "none",
  });
}

async function apply(now) {
  const aggregate = await loadAggregate();
  if (!aggregate) fail("no_pending");
  const name = aggregate.state.region_lifecycle;
  if (name === "applied") ok(appliedShape(viewOf(aggregate)));
  if (name === "attempting") await resumeAttempt(aggregate);
  if (name !== "scheduled") fail("no_pending");
  const view = viewOf(aggregate);
  if (now < view.effective_at_ms) fail("not_due");
  if (view.invoice === "unpaid" && isDowngrade(view.from_plan, view.to_plan)) fail("unpaid_downgrade");
  await firstAttempt(aggregate, now);
}

async function reconcile(args) {
  if (args.length !== 1) fail("bad_args");
  const submissionId = args[0];
  requireId(submissionId);
  const aggregate = await loadAggregate();
  if (!aggregate) fail("no_attempt");
  const name = aggregate.state.region_lifecycle;
  const view = viewOf(aggregate);
  if (name !== "attempting" && name !== "applied") fail("no_attempt");
  if (submissionId !== view.submission_id) fail("submission_mismatch");
  if (name === "applied") {
    ok({ lookup: "applied", ...appliedShape(view) });
  }
  const looked = await httpCall("GET", "/v1/submissions/" + submissionId);
  if (looked.kind !== "http") fail("service_unavailable");
  if (looked.status === 404) {
    ok({
      lookup: "not_sent",
      submission_id: view.submission_id,
      submission: "attempt_saved",
    });
  }
  if (looked.status >= 500) fail("service_unavailable");
  const parsed = parseJson(looked.text);
  if (looked.status === 200 && matchesAttempt(parsed, view)) {
    await commitApplied(aggregate, looked.text, true);
  }
  fail("lookup_conflict");
}

function callback(args) {
  if (args.length !== 1) fail("bad_args");
  let text;
  try {
    text = readFileSync(args[0], "utf8");
  } catch {
    fail("bad_callback");
  }
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    fail("bad_callback");
  }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) fail("bad_callback");
  for (const field of ["callback_id", "submission_id", "account_id", "to_plan"]) {
    if (typeof parsed[field] !== "string") fail("bad_callback");
  }
  if (typeof parsed.effective_at_ms !== "number" || !Number.isFinite(parsed.effective_at_ms)) {
    fail("bad_callback");
  }
  if (parsed.outcome !== "applied" && parsed.outcome !== "rejected") fail("bad_callback");
  ok({ callback: "accepted" });
}

async function recordInvoice(args) {
  if (args.length !== 2) fail("bad_args");
  const [invoiceId, amountRaw] = args;
  requireId(invoiceId);
  const aggregate = await loadAggregate();
  if (!aggregate) fail("not_open");
  const amount = parseAmount(amountRaw);
  if (amount === null) fail("bad_amount");
  const view = viewOf(aggregate);
  if (view.invoice === "unpaid") fail("invoice_exists");
  const updated = await aggregate.command("record_invoice", {
    invoice_id: invoiceId,
    amount_cents: amount,
  });
  const after = viewOf(updated);
  ok({ invoice_id: after.invoice_id, amount_cents: after.amount_cents, invoice: after.invoice });
}

async function payInvoice(args) {
  if (args.length !== 1) fail("bad_args");
  const invoiceId = args[0];
  requireId(invoiceId);
  const aggregate = await loadAggregate();
  if (!aggregate) fail("no_invoice");
  const view = viewOf(aggregate);
  if (view.invoice === "none") fail("no_invoice");
  if (invoiceId !== view.invoice_id) fail("invoice_mismatch");
  if (view.invoice === "paid") {
    ok({ invoice_id: view.invoice_id, amount_cents: view.amount_cents, invoice: "paid" });
  }
  const updated = await aggregate.command("pay_invoice", { invoice_id: invoiceId });
  const after = viewOf(updated);
  ok({ invoice_id: after.invoice_id, amount_cents: after.amount_cents, invoice: after.invoice });
}

async function status() {
  const aggregate = await loadAggregate();
  ok(viewOf(aggregate));
}

function requireEnv() {
  if (process.env.STATE_DIR === undefined || process.env.STATE_DIR === "") fail("bad_args");
  if (process.env.SERVICE_URL === undefined || process.env.SERVICE_URL === "") fail("bad_args");
  const clock = parseClock(process.env.NOW_MS);
  if (clock.error) fail(clock.error);
  if (existsSync(process.env.STATE_DIR) && !statSync(process.env.STATE_DIR).isDirectory()) {
    fail("bad_args");
  }
  return clock.value;
}

async function main() {
  const argv = process.argv.slice(2);
  const command = argv[0];
  const args = argv.slice(1);
  if (!command) fail("bad_args");
  const now = requireEnv();
  if (command === "status") return status();
  if (command === "open") return open(args, now);
  if (command === "schedule") return schedule(args, now);
  if (command === "replace") return replace(args, now);
  if (command === "cancel") return cancel(args);
  if (command === "apply") {
    if (args.length !== 0) fail("bad_args");
    return apply(now);
  }
  if (command === "reconcile") return reconcile(args);
  if (command === "callback") return callback(args);
  if (command === "invoice") return recordInvoice(args);
  if (command === "pay") return payInvoice(args);
  fail("bad_args");
}

main().catch((err) => {
  if (classify(err) === "corrupt" || err.code === "IK_STORE_CORRUPT") fail("corrupt_state");
  process.stderr.write(String(err && err.stack ? err.stack : err) + "\n");
  fail("service_unavailable");
});
