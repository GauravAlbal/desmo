# Freelancer payout desk

The program behind `./run` is a durable local payout desk for one freelancer and one accounting period. Payout requests are submitted, a manager approves all or part of a request within the period cap, and an external payment provider pays an approved amount at most once. A request may be rejected or cancelled before payment. A provider reply may be lost; reconciliation uses the saved payment id.

## Scope and invocation

One machine and one process at a time. One freelancer and one period are bound to a state directory. An unrelated writer may create or modify other files in `STATE_DIR`; those files must survive byte-for-byte. The tool may keep its own durable files in `STATE_DIR` under any names. It must use only `STATE_DIR`, `SERVICE_URL` and `CRASH_AT`; `NOW_MS` is not used. `SERVICE_URL` is required for every command, including status (status must not contact it). `CRASH_AT` is optional.

`./run <command> [args]` prints exactly one JSON object and nothing else (one trailing newline is allowed). Exit 0 is success. Refusals are nonzero and print `{ "error": "<code>" }`. Identifiers are 1–64 characters matching `A-Za-z0-9._-`. Amounts are canonical decimal integers from 1 through 100000000 cents; malformed values are `bad_amount`. Manager ids use the same identifier rule.

Durable commits are flushed before the command treats them as committed. A malformed owned state file is `corrupt_state` and is not rewritten. Refusals do not modify state. `CRASH_AT` labels are:

* `after-payment-saved-before-request`: after saving a payment id and request snapshot, before sending any request;
* `after-accept-before-record`: after reading a complete successful provider response, before saving paid state;
* `after-record-before-exit`: after saving paid state, before success JSON is written.

A process must kill itself with SIGKILL at a reached label. A later process must observe committed state.

## Commands

`open <freelancer_id> <period_id> <cap_cents>` binds the empty store. It returns `{freelancer_id,period_id,cap_cents,request_id:null,status:"none",payment:"none"}`. A second open is `already_open`; malformed ids are `bad_args`; malformed cap is `bad_amount`.

`submit <amount_cents> [memo]` creates one request with a generated request id and status `submitted`. The memo is optional, at most 200 UTF-8 characters, and otherwise `bad_args`. It returns `{request_id,freelancer_id,period_id,requested_cents,approved_cents:0,memo,status:"submitted",payment:"none",payment_id:null}`. No provider call is made. Only one nonterminal request may exist; otherwise `request_exists`. An amount above the cap is `over_cap`.

`approve <request_id> <manager_id> [approved_cents]` approves all requested cents when the third argument is omitted, or a positive amount no greater than requested when supplied. It is a partial approval when smaller. The manager cannot approve a request twice (`already_approved`), and a manager id must not be reused as a second distinct approval. The approved amount plus amounts reserved by other non-cancelled approved requests must not exceed `cap_cents`; otherwise `over_cap`. The request becomes `approved` and is eligible for payment. A request id mismatch is `request_mismatch`; absent/non-submitted is `no_request` or `bad_status`. `reject <request_id> [reason]` marks a submitted request `rejected` without contacting the provider. Reason is optional and max 200 chars. A rejected request is terminal.

`cancel <request_id>` initially is allowed only for a submitted request. It marks it `cancelled`, releases its cap reservation, and returns `{request_id,status:"cancelled",payment:"none"}`. An id mismatch is `request_mismatch`; an absent or terminal request is `no_request`/`bad_status`; an approved request is `already_approved`; a saved payment is `payment_started`.

`pay` pays the saved approved request. If no request exists, return `no_request`; if it is not approved, return `not_approved`. A payment attempt is committed with a generated payment id before POST. `apply` is an alias for `pay`. If an attempt is saved, retain its payment id and snapshot, skip cap/status checks, and first `GET /v1/payments/<payment_id>`: a matching 200 is adopted without POST; a 404 causes one POST with the saved id. Never allocate a replacement id. With no attempt, an approved request allocates one id and POSTs exactly once.

POST `/v1/payouts` body is `{payment_id,freelancer_id,period_id,request_id,amount_cents}`. A matching 200 `{...,outcome:"paid"}` commits request status `paid`, payment `paid`, and returns `{request_id,payment_id,amount_cents,status:"paid",payment:"paid"}`. A connection failure, incomplete response, or HTTP 5xx is `service_unavailable`, leaves `payment:"attempt_saved"`, and does not lookup in that invocation. A mismatching success is `lookup_conflict` and changes nothing. A second `pay` after paid returns success without contacting the provider.

`reconcile <payment_id>` never POSTs or allocates. No saved payment is `no_payment`; another id is `payment_mismatch`. Lookup 200 with matching ids and amount commits paid and returns the success object plus `lookup:"paid"`; 404 returns exit 0 `{lookup:"not_sent",request_id,payment_id,payment:"attempt_saved",status:"approved"}`. A mismatch is `lookup_conflict`; transport failure is `service_unavailable`.

`status` never contacts the provider and returns all fields, using nulls on an empty store:
`{freelancer_id,period_id,cap_cents,request_id,requested_cents,approved_cents,manager_id,memo,status,payment,payment_id}`. Status values are `none`, `submitted`, `approved`, `rejected`, `cancelled`, `paid`; payment values are `none`, `attempt_saved`, `paid`.

`callback <path>` reads one JSON callback. It must not POST or allocate. A malformed callback is `bad_callback`; a well-formed callback may be ignored. It must never overwrite paid, rejected, or cancelled state.

## Provider

The supplied service has `POST /v1/payouts` and `GET /v1/payments/<payment_id>`. A first valid payment id records one effect and returns the body with `outcome:"paid"`; repeating the same id and identical fields returns the same object without another effect; any differing field is HTTP 409. Unknown lookup is 404. The provider may drop a reply after accepting, hold a reply, or return 5xx without storing. Control endpoints are not part of this contract.

## Requirements

R1. Open and every later committed record survive new processes, including a payment attempt killed at `after-payment-saved-before-request`.

R2. Submission validates amount and cap, creates one durable request, preserves memo, refuses a second active request, and does not contact the provider.

R3. A manager can approve all or a smaller positive amount once; approvals reserve cap and partial approval is visible. Over-cap, duplicate-manager, unknown request, and invalid amounts refuse without mutation.

R4. Rejection is terminal, durable, provider-free, and cannot be paid or approved later. Submitted cancellation is terminal, durable, releases cap, and cannot be paid.

R5. A healthy provider permits submit, approve, and pay of an approved request. Status is paid and the provider has exactly one effect; repeating pay has no effect.

R6. Callback files never overwrite local terminal outcomes and never cause provider effects.

R7. Paying a submitted, rejected, cancelled, or absent request is refused without contacting the provider.

R8. A crash before POST leaves one saved payment id and zero effects; later pay POSTs that same id and ends paid exactly once.

R9. A crash after provider acceptance leaves attempt_saved locally and one provider effect; later pay adopts by lookup without a second effect.

R10. A crash after the durable paid record leaves paid state and later pay is a no-op; reconcile can likewise survive its record-before-exit crash.

R11. A dropped payment reply yields service_unavailable and attempt_saved; following reconcile adopts paid by lookup, never reports not_sent, and never posts again.

R12. Reconcile never POSTs: a saved-but-unaccepted id returns not_sent with attempt_saved; a wrong id is submission/payment mismatch and leaves state unchanged.

R13. Unrelated files in STATE_DIR retain identical bytes through commits and refusals.

R14. Every invocation emits one JSON object; status on empty is the null shape; missing SERVICE_URL is a refusal; the first open binds the only freelancer/period and no command can pay another.
