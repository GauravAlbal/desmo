import assert from 'node:assert/strict';
import { spawn, execFileSync } from 'node:child_process';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const root = new URL('.', import.meta.url).pathname;
const provider = spawn(process.execPath, ['stub/server.mjs'], {cwd: root});
let line = '';
provider.stdout.setEncoding('utf8');
const info = await new Promise((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error('stub startup timeout')), 5000);
  provider.stdout.on('data', chunk => { line += chunk; if (line.includes('\n')) { clearTimeout(timer); resolve(JSON.parse(line)); } });
  provider.once('error', reject);
});
const dirs = [];
function invoke(dir, args, extra={}) {
  dirs.push(dir);
  const env = {...process.env, STATE_DIR:dir, SERVICE_URL:info.service_url, ...extra};
  try { return {code:0, value:JSON.parse(execFileSync(join(root,'run'), args, {cwd:root,env,encoding:'utf8'}))}; }
  catch (e) { const raw=(e.stdout||'').trim(); return {code:e.status ?? 1, value:raw?JSON.parse(raw):null}; }
}
async function control(path, method='GET', body) { const r=await fetch(info.control_url+path,{method,headers:{'content-type':'application/json','connection':'close'},body:body&&JSON.stringify(body)}); return r.json(); }
function setup(period, requested='100', cap='1000') { const d=mkdtempSync(join(tmpdir(),'payout-test-')); const opened=invoke(d,['open','freelancer',period,cap]); const s=invoke(d,['submit',requested]); assert.equal(s.code,0,JSON.stringify({opened,s})); const a=invoke(d,['approve',s.value.request_id,'manager']); assert.equal(a.code,0,JSON.stringify({opened,s,a})); return {d,id:s.value.request_id}; }
try {
  const empty=mkdtempSync(join(tmpdir(),'payout-empty-')); assert.deepEqual(invoke(empty,['status']).value,{freelancer_id:null,period_id:null,cap_cents:null,request_id:null,requested_cents:null,approved_cents:null,manager_id:null,second_manager_id:null,memo:null,status:'none',payment:'none',payment_id:null});
  const healthy=setup('healthy'); const paid=invoke(healthy.d,['pay']); assert.equal(paid.value.status,'paid'); assert.equal((await control('/effects')).count,1); assert.equal(invoke(healthy.d,['pay']).value.status,'paid'); assert.equal((await control('/effects')).count,1);
  const exact=setup('exact','50000','50000'); assert.equal(invoke(exact.d,['status']).value.status,'approved'); assert.equal(invoke(exact.d,['pay']).value.status,'paid');
  const high=setup('high','50001','60000'); const waiting=invoke(high.d,['status']).value; assert.equal(waiting.status,'awaiting_second'); assert.equal(waiting.second_manager_id,null); assert.equal(invoke(high.d,['pay']).value.error,'not_approved'); assert.equal(invoke(high.d,['approve-second',high.id,'manager']).value.error,'duplicate_manager'); const second=invoke(high.d,['approve-second',high.id,'manager-2']); assert.equal(second.code,0); assert.equal(second.value.status,'approved'); assert.equal(second.value.second_manager_id,'manager-2'); assert.equal(invoke(high.d,['approve-second',high.id,'manager-2']).code,0); assert.equal(invoke(high.d,['approve-second',high.id,'manager-3']).value.error,'bad_status'); assert.equal(invoke(high.d,['pay']).value.status,'paid');
  const cancelSubmitted=mkdtempSync(join(tmpdir(),'payout-cancel-submitted-')); invoke(cancelSubmitted,['open','freelancer','cancel-submitted','1000']); const cs=invoke(cancelSubmitted,['submit','100']); assert.equal(invoke(cancelSubmitted,['cancel',cs.value.request_id]).value.status,'cancelled'); assert.deepEqual(invoke(cancelSubmitted,['status']).value,{freelancer_id:'freelancer',period_id:'cancel-submitted',cap_cents:1000,request_id:cs.value.request_id,requested_cents:100,approved_cents:0,manager_id:null,second_manager_id:null,memo:'',status:'cancelled',payment:'none',payment_id:null});
  const cancelWaiting=setup('cancel-waiting','50001','60000'); assert.equal(invoke(cancelWaiting.d,['cancel',cancelWaiting.id]).value.status,'cancelled'); const waitingStatus=invoke(cancelWaiting.d,['status']).value; assert.equal(waitingStatus.approved_cents,0); assert.equal(waitingStatus.manager_id,null); assert.equal(waitingStatus.second_manager_id,null); assert.equal(invoke(cancelWaiting.d,['pay']).value.error,'not_approved');
  const cancelApproved=setup('cancel-approved'); assert.equal(invoke(cancelApproved.d,['cancel',cancelApproved.id]).value.status,'cancelled'); assert.equal(invoke(cancelApproved.d,['pay']).value.error,'not_approved');
  const cancelStarted=setup('cancel-started'); assert.notEqual(invoke(cancelStarted.d,['pay'],{CRASH_AT:'after-payment-saved-before-request'}).code,0); assert.equal(invoke(cancelStarted.d,['cancel',cancelStarted.id]).value.error,'payment_started'); assert.equal(invoke(cancelStarted.d,['pay']).value.status,'paid');
  const pre=setup('pre'); const crash=invoke(pre.d,['pay'],{CRASH_AT:'after-payment-saved-before-request'}); assert.notEqual(crash.code,0); assert.equal(invoke(pre.d,['status']).value.payment,'attempt_saved'); assert.equal(invoke(pre.d,['pay']).value.status,'paid');
  const accepted=setup('accepted'); assert.notEqual(invoke(accepted.d,['pay'],{CRASH_AT:'after-accept-before-record'}).code,0); assert.equal(invoke(accepted.d,['status']).value.payment,'attempt_saved'); assert.equal(invoke(accepted.d,['cancel',accepted.id]).value.error,'payment_started'); assert.equal(invoke(accepted.d,['pay']).value.status,'paid');
  const recorded=setup('recorded'); assert.notEqual(invoke(recorded.d,['pay'],{CRASH_AT:'after-record-before-exit'}).code,0); assert.equal(invoke(recorded.d,['status']).value.status,'paid'); assert.equal(invoke(recorded.d,['pay']).value.status,'paid');
  const drop=setup('drop'); await control('/fault','POST',{drop_reply:true}); assert.equal(invoke(drop.d,['pay']).value.error,'service_unavailable'); const pending=invoke(drop.d,['status']).value; assert.equal(pending.payment,'attempt_saved'); await control('/fault','POST',{}); const rec=invoke(drop.d,['reconcile',pending.payment_id]); assert.equal(rec.value.lookup,'paid'); assert.equal((await control('/posts')).count,(await control('/effects')).count);
  const noPost=setup('not-sent'); const before=await control('/posts'); const p=invoke(noPost.d,['pay'],{CRASH_AT:'after-payment-saved-before-request'}); assert.notEqual(p.code,0); const saved=invoke(noPost.d,['status']).value; const notSent=invoke(noPost.d,['reconcile',saved.payment_id]); assert.equal(notSent.value.lookup,'not_sent'); assert.deepEqual(await control('/posts'),before);
  const cb=join(noPost.d,'cb.json'); writeFileSync(cb,'{"payment_id":"other","outcome":"paid"}'); assert.equal(invoke(noPost.d,['callback',cb]).value.ignored,true);
  console.log('tests ok');
} finally { provider.kill('SIGTERM'); }
