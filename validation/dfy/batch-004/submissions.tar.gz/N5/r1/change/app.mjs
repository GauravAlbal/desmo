import { Kernel, StoreNotFoundError } from '@ikaros/runtime';
import { createHash, randomUUID } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const ROOT = new URL('.', import.meta.url).pathname;
const machinePath = resolve(ROOT, 'payout_desk.ik.toml');
const stateDir = process.env.STATE_DIR;
const serviceUrl = process.env.SERVICE_URL;
const crashAt = process.env.CRASH_AT;
const db = stateDir ? resolve(stateDir, 'payout-desk.sqlite') : null;
const ok = x => ({ok:true,value:x});
const fail = error => ({ok:false,error});
function out(x){ process.stdout.write(JSON.stringify(x)+'\n'); }
function die(code){ out({error:code}); process.exitCode=1; }
function id(x){ return typeof x==='string' && /^[A-Za-z0-9._-]{1,64}$/.test(x); }
function amount(x){ return typeof x==='string' && /^[1-9][0-9]*$/.test(x) && BigInt(x)<=100000000n; }
function n(x){ return Number(BigInt(x)); }
function digest(s){ return createHash('sha256').update(s).digest('hex'); }
function bodyFor(s,p,r,a){ return {payment_id:p,freelancer_id:s.freelancer_id,period_id:s.period_id,request_id:s.request_id,amount_cents:a}; }
function paymentResult(s){ return {request_id:s.request_id,payment_id:s.payment_id,amount_cents:s.approved_cents,status:'paid',payment:'paid'}; }
function statusOf(s,e){
  const state=s?.state ?? 'none';
  const payment=state==='paid' ? 'paid' : (s?.payment_id && s.payment_id!=='unassigned' ? 'attempt_saved' : 'none');
  const managerId=s?.manager_id&&s.manager_id!=='unassigned'?s.manager_id:null;
  const secondManagerId=s?.second_manager_id&&s.second_manager_id!=='unassigned'?s.second_manager_id:null;
  return {freelancer_id:s?.freelancer_id??null,period_id:s?.period_id??null,cap_cents:s?.cap_cents??null,request_id:s?.request_id??null,requested_cents:s?.requested_cents??null,approved_cents:s?.approved_cents??null,manager_id:managerId,second_manager_id:secondManagerId,memo:s?.memo??null,status:state,payment,payment_id:payment==='none'?null:s.payment_id};
}
function approvalResult(s){
  return {request_id:s.request_id,approved_cents:s.approved_cents,manager_id:s.manager_id==='unassigned'?null:s.manager_id,second_manager_id:s.second_manager_id==='unassigned'?null:s.second_manager_id,status:s.state,payment:'none',payment_id:null};
}
async function openMachine(){ const k=new Kernel(db); return {k,m:await k.machine(machinePath)}; }
async function show(){ const x=await openMachine(); return {...x,a:await x.m.show('desk')}; }
async function command(a,name,args){ return await a.command(name,args); }
function state(a){ return a.state; }
function validateEnv(){ if(!stateDir) return 'missing_state_dir'; if(!serviceUrl) return 'missing_service_url'; return null; }
async function fetchJson(url, opts={}){
  const ac=new AbortController(); const t=setTimeout(()=>ac.abort(),2500); try { const r=await fetch(url,{...opts,signal:ac.signal}); const text=await r.text(); let data=null; try{data=JSON.parse(text)}catch{} return {r,data}; } catch(e){ throw e; } finally { clearTimeout(t); }
}
async function lookup(s,p){ return fetchJson(serviceUrl.replace(/\/$/,'')+'/v1/payments/'+encodeURIComponent(p)); }
function matching(data,b){ return data && data.payment_id===b.payment_id && data.freelancer_id===b.freelancer_id && data.period_id===b.period_id && data.request_id===b.request_id && data.amount_cents===b.amount_cents && data.outcome==='paid'; }
async function recordAndFinish(x,a,b,extra={}){
  const operationId=x.k.newOperationId();
  try { await a.recordEffectOutcome(digest(JSON.stringify(b)),{operationId,intent:a.pendingIntent}); } catch(e) { if(e?.outcome==='submission-unknown') return fail('service_unavailable'); throw e; }
  const fresh=await x.m.show('desk');
  const paid=await fresh.command('finish',{request_id:fresh.state.request_id,payment_id:fresh.state.payment_id,amount_cents:fresh.state.approved_cents});
  if(crashAt==='after-record-before-exit') process.kill(process.pid,'SIGKILL');
  return ok({...paymentResult(paid.state),...extra});
}
async function pay(){
  let x; try{x=await show()}catch(e){ if(e instanceof StoreNotFoundError)return fail('no_request'); throw e; }
  let a=x.a; let s=a.state;
  if(s.state==='paid') return ok(paymentResult(s));
  if(s.state!=='approved') return fail('not_approved');
  if(s.payment_id==='unassigned'){
    const p='pay_'+randomUUID().replaceAll('-',''); const b=bodyFor(s,p,s.request_id,s.approved_cents); const pd=digest(JSON.stringify(b));
    a=await command(a,'plan_payment',{payment_id:p,payload_digest:pd,idempotency_key:p});
    if(crashAt==='after-payment-saved-before-request') process.kill(process.pid,'SIGKILL');
    x={...x,a}; s=a.state;
  }
  const b=bodyFor(s,s.payment_id,s.request_id,s.approved_cents);
  let got; try{got=await lookup(s,s.payment_id)}catch{return fail('service_unavailable');}
  if(got.r.status===200){ if(!matching(got.data,b)) return fail('lookup_conflict'); return recordAndFinish(x,a,got.data); }
  if(got.r.status!==404) return fail('service_unavailable');
  let sent; try{sent=await fetchJson(serviceUrl.replace(/\/$/,'')+'/v1/payouts',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)});}catch{return fail('service_unavailable');}
  if(sent.r.status!==200) return fail('service_unavailable');
  if(!matching(sent.data,b)) return fail('lookup_conflict');
  if(crashAt==='after-accept-before-record') process.kill(process.pid,'SIGKILL');
  return recordAndFinish(x,a,sent.data);
}
async function reconcile(p){
  if(!id(p)) return fail('bad_args'); let x; try{x=await show()}catch(e){if(e instanceof StoreNotFoundError)return fail('no_payment');throw e;}
  const s=x.a.state; if(!s.payment_id||s.payment_id==='unassigned')return fail('no_payment'); if(p!==s.payment_id)return fail('payment_mismatch');
  if(s.state==='paid')return ok({...paymentResult(s),lookup:'paid'});
  const b=bodyFor(s,s.payment_id,s.request_id,s.approved_cents); let got; try{got=await lookup(s,p)}catch{return fail('service_unavailable');}
  if(got.r.status===404)return ok({lookup:'not_sent',request_id:s.request_id,payment_id:p,payment:'attempt_saved',status:s.state});
  if(got.r.status!==200)return fail('service_unavailable'); if(!matching(got.data,b))return fail('lookup_conflict'); if(s.state!=='approved')return fail('bad_status');
  return recordAndFinish(x,x.a,got.data,{lookup:'paid'});
}
async function main(){
  const env=validateEnv(); if(env)return die(env);
  const [cmd,...args]=process.argv.slice(2);
  try{
    if(cmd==='status'){
      if(!existsSync(db)) return out(statusOf(null));
      try{const x=await show(); return out(statusOf(x.a.state,x.a.effect));}catch(e){if(e instanceof StoreNotFoundError)return out(statusOf(null));throw e;}
    }
    if(cmd==='open'){
      if(args.length!==3||!id(args[0])||!id(args[1]))return die('bad_args'); if(!amount(args[2]))return die('bad_amount');
      let x; try{x=await openMachine();}catch(e){throw e;}
      if(existsSync(db)){try{await x.m.show('desk');return die('already_open')}catch(e){} }
      const a=await x.m.createWith({aggregateId:'desk',command:{name:'open',args:{freelancer_id:args[0],period_id:args[1],cap_cents:n(args[2])}}}); return out(statusOf(a.state));
    }
    if(cmd==='submit'){
      if(args.length<1||args.length>2||!amount(args[0]))return die(args[0]&&!amount(args[0])?'bad_amount':'bad_args');
      const memo=args[1]??''; if([...memo].length>200)return die('bad_args'); let x; try{x=await show()}catch(e){if(e instanceof StoreNotFoundError)return die('no_request');throw e;}
      const s=x.a.state; if(['submitted','awaiting_second','approved'].includes(s.state))return die('request_exists'); if(!['open','rejected','cancelled'].includes(s.state))return die('request_exists'); if(n(args[0])>s.cap_cents)return die('over_cap');
      const rid='req_'+randomUUID().replaceAll('-',''); const a=await x.a.command('submit',{request_id:rid,requested_cents:n(args[0]),memo,manager_seed:'unassigned',second_manager_seed:'unassigned',payment_seed:'unassigned',payload_seed:'unassigned'});
      return out({request_id:rid,freelancer_id:a.state.freelancer_id,period_id:a.state.period_id,requested_cents:a.state.requested_cents,approved_cents:0,memo,status:'submitted',payment:'none',payment_id:null});
    }
    if(cmd==='approve'){
      if(args.length<2||args.length>3||!id(args[0])||!id(args[1]))return die('bad_args'); let x;try{x=await show()}catch(e){if(e instanceof StoreNotFoundError)return die('no_request');throw e;} const s=x.a.state;
      if(!s.request_id)return die('no_request'); if(args[0]!==s.request_id)return die('request_mismatch'); if(s.state!=='submitted')return die(s.state==='approved'?'already_approved':'bad_status');
      const v=args[2]??String(s.requested_cents); if(!amount(v)||n(v)>s.requested_cents)return die('bad_amount'); if(n(v)>s.cap_cents)return die('over_cap');
      const a=await x.a.command('approve',{request_id:args[0],manager_id:args[1],approved_cents:n(v)}); return out(approvalResult(a.state));
    }
    if(cmd==='approve-second'){
      if(args.length!==2||!id(args[0])||!id(args[1]))return die('bad_args'); let x;try{x=await show()}catch(e){if(e instanceof StoreNotFoundError)return die('no_request');throw e;} const s=x.a.state;
      if(!s.request_id)return die('no_request'); if(args[0]!==s.request_id)return die('request_mismatch');
      if(s.state==='approved' && s.second_manager_id===args[1])return out(approvalResult(s));
      if(s.state!=='awaiting_second')return die('bad_status'); if(s.manager_id===args[1])return die('duplicate_manager');
      const a=await x.a.command('approve_second',{request_id:args[0],manager_id:args[1]}); return out(approvalResult(a.state));
    }
    if(cmd==='reject'||cmd==='cancel'){
      if(args.length<1||args.length>2||!id(args[0]))return die('bad_args'); let x;try{x=await show()}catch(e){if(e instanceof StoreNotFoundError)return die('no_request');throw e;} const s=x.a.state;
      if(!s.request_id)return die('no_request'); if(args[0]!==s.request_id)return die('request_mismatch');
      if(cmd==='cancel'){
        if(s.payment_id&&s.payment_id!=='unassigned')return die('payment_started');
        if(!['submitted','awaiting_second','approved'].includes(s.state))return die('bad_status');
      } else if(s.state!=='submitted') return die('bad_status');
      const a=await x.a.command(cmd,cmd==='reject'?{request_id:args[0],reason:args[1]??''}:{request_id:args[0],manager_seed:'unassigned',second_manager_seed:'unassigned',payment_seed:'unassigned',payload_seed:'unassigned'});
      return out(cmd==='cancel'?{request_id:a.state.request_id,status:'cancelled',payment:'none'}:{request_id:a.state.request_id,status:'rejected',payment:'none',reason:args[1]??null});
    }
    if(cmd==='pay'||cmd==='apply'){const r=await pay();return r.ok?out(r.value):die(r.error)}
    if(cmd==='reconcile'){const r=await reconcile(args[0]);return r.ok?out(r.value):die(r.error)}
    if(cmd==='callback'){
      if(args.length!==1)return die('bad_args'); let v;try{v=JSON.parse(readFileSync(resolve(args[0]),'utf8'))}catch{return die('bad_callback');} if(!v||typeof v!=='object'||Array.isArray(v))return die('bad_callback'); return out({ignored:true});
    }
    return die('bad_args');
  }catch(e){ if(e?.code==='IK_STORE_CORRUPT')return die('corrupt_state'); if(e?.code==='IK_STORE_NOT_FOUND')return die('no_request'); if(e?.code==='IK_COMMAND_INVALID')return die('bad_status'); return die('internal_error'); }
}
main();
