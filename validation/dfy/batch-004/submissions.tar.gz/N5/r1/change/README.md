# Freelancer payout desk

This project is a durable payout desk backed by the local Ikaros runtime. The
CLI is `./run`; every successful or refused invocation prints one JSON object.

## Setup

Use Node 22 (the supplied Ikaros native package is for macOS arm64), then run
from this directory:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

Each invocation requires both `STATE_DIR` and `SERVICE_URL`. `status` requires
the variables too, but never contacts the provider. State is stored in
`$STATE_DIR/payout-desk.sqlite`; unrelated files are not touched.

```sh
export STATE_DIR=/tmp/payout-state
export SERVICE_URL=http://127.0.0.1:50500
./run open freelancer-1 2026-01 100000
./run submit 60000 "January work"
./run approve REQUEST_ID manager-1
./run approve-second REQUEST_ID manager-2   # required when approved cents > 50000
./run pay                         # apply is an alias
./run status
./run reconcile PAYMENT_ID
./run callback callback.json
```

Approvals of 50000 cents or less become `approved` immediately. A larger
approval becomes `awaiting_second` until a distinct manager runs
`approve-second`; `status` exposes that manager as `second_manager_id`.
Cancellation is allowed while submitted, awaiting second approval, or approved
until a payment attempt is saved. After that point it returns `payment_started`
and preserves the payment identity.

The supplied provider can be started with `node stub/server.mjs`; it prints a
service URL and a separate control URL. `CRASH_AT` is only for recovery tests:
`after-payment-saved-before-request`, `after-accept-before-record`, and
`after-record-before-exit` terminate the process at the corresponding durable
boundary. A later `pay` or `reconcile` resumes from the saved Ikaros state.

Commands return nonzero with `{ "error": "<code>" }` when refused. Provider
transport failures leave a saved payment attempt and return
`service_unavailable`; reconciliation performs GET only and never allocates or
POSTs.

## Scoped smoke tests

```sh
node tests.mjs
```

The test starts the supplied stub on its own ephemeral ports and uses isolated
state directories under the system temporary directory.
