# Freelancer payout desk

This is a single-process durable payout desk. The lifecycle authority and its facts are stored by Ikaros in `STATE_DIR/kernel.db`; the application keeps no second state machine. The supplied provider is contacted only by `pay`/`apply` and `reconcile`.

## Setup

Node 22 is required. From this directory, with the supplied local tarballs:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

No Python or registry access is needed. `./run` invokes the pinned Node 22 executable. The command requires both `STATE_DIR` and `SERVICE_URL` on every invocation; `SERVICE_URL` is not contacted by `status`.

```sh
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50600 ./run status
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50600 ./run open freelancer period 100000
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50600 ./run submit 250 "March invoice"
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50600 ./run approve REQUEST_ID manager
# Requests above 50000 cents remain awaiting_second:
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50600 ./run approve-second REQUEST_ID second-manager
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:50600 ./run pay

The provider URL must be the service URL printed by `stub/server.mjs`, not its control URL. Only TCP ports 50600–50609 are used by local test fixtures; the supplied stub chooses its own ephemeral port.

## Recovery labels

Set `CRASH_AT` for the required SIGKILL boundaries: `after-payment-saved-before-request`, `after-accept-before-record`, and `after-record-before-exit`. A later process uses the saved payment id. `reconcile PAYMENT_ID` only performs GET and never allocates or POSTs. Callback JSON is deliberately ignored after parsing and never changes lifecycle state.

Approvals over 50000 cents enter `awaiting_second` and require `approve-second REQUEST_ID MANAGER_ID`; cancellation is allowed before a payment attempt for submitted, awaiting-second, and approved requests.

Run the focused tests with:

```sh
node tests.mjs
```

## Known limits / decisions

The brief leaves the exact public error spelling for a duplicate manager open; this implementation uses `duplicate_manager`. An omitted memo is returned as JSON `null`, while an explicitly supplied empty memo is treated equivalently. New stores use machine version 2; existing version-one stores remain routed to `payout_desk_v1.ik.toml` and retain their original lifecycle behavior rather than being migrated. There is no unresolved permission or external behavior decision: the provider contract and the brief determine the behavior.
