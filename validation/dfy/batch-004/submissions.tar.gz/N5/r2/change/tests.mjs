import assert from "node:assert/strict";
import { createServer } from "node:http";
import { execFile, spawn } from "node:child_process";
import { promisify } from "node:util";
import { fileURLToPath } from "node:url";
import { mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";

const execFileAsync = promisify(execFile);
const ROOT = dirname(fileURLToPath(import.meta.url));
const root = `/tmp/payout-desk-tests-${process.pid}`;
rmSync(root, { recursive: true, force: true });
mkdirSync(root, { recursive: true });
const effects = new Map();
let postCount = 0;
let dropNext = false;
const server = createServer((req, res) => {
  const chunks = [];
  req.on("data", (chunk) => chunks.push(chunk));
  req.on("end", () => {
    const path = new URL(req.url, "http://127.0.0.1").pathname;
    if (req.method === "GET" && path.startsWith("/v1/payments/")) {
      const id = decodeURIComponent(path.split("/").at(-1));
      const body = effects.get(id);
      if (!body) { res.writeHead(404, { "content-type": "application/json" }); res.end(JSON.stringify({ error: "not_found" })); return; }
      res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify(body)); return;
    }
    if (req.method !== "POST" || path !== "/v1/payouts") { res.writeHead(404); res.end(); return; }
    postCount += 1;
    const body = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    const stored = { ...body, outcome: "paid" };
    const old = effects.get(body.payment_id);
    if (old && JSON.stringify(old) !== JSON.stringify(stored)) { res.writeHead(409); res.end(); return; }
    effects.set(body.payment_id, old || stored);
    if (dropNext) { dropNext = false; req.socket.destroy(); return; }
    res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify(old || stored));
  });
});
await new Promise((resolve) => server.listen(50601, "127.0.0.1", resolve));
const service = "http://127.0.0.1:50601";
const env = (dir, extra = {}) => ({ ...process.env, STATE_DIR: dir, SERVICE_URL: service, ...extra });
async function invoke(dir, ...args) {
  try {
    const { stdout } = await execFileAsync(join(ROOT, "run"), args, { cwd: ROOT, env: env(dir), encoding: "utf8" });
    const lines = stdout.trim().split("\n");
    assert.equal(lines.length, 1, `expected one JSON line, got ${stdout}`);
    return JSON.parse(lines[0]);
  } catch (error) {
    error.parsed = JSON.parse(String(error.stdout || "{}").trim());
    throw error;
  }
}
function crash(dir, label) {
  return new Promise((resolve, reject) => {
    const child = spawn(join(ROOT, "run"), ["pay"], { cwd: ROOT, env: env(dir, { CRASH_AT: label }) });
    child.on("exit", (code, signal) => signal === "SIGKILL" ? resolve() : reject(new Error(`expected SIGKILL, got ${code}/${signal}`)));
    child.on("error", reject);
  });
}
async function setup(dir, amount = "400") {
  const opened = await invoke(dir, "open", "freelancer", "period", "1000");
  assert.equal(opened.status, "none");
  const submitted = await invoke(dir, "submit", amount, "memo");
  assert.equal(submitted.status, "submitted");
  const approved = await invoke(dir, "approve", submitted.request_id, "manager");
  assert.equal(approved.status, "approved");
  return submitted.request_id;
}

const empty = await invoke(join(root, "empty"), "status");
assert.deepEqual(empty, { freelancer_id: null, period_id: null, cap_cents: null, request_id: null, requested_cents: null, approved_cents: null, manager_id: null, second_manager_id: null, memo: null, status: "none", payment: "none", payment_id: null });
const healthy = join(root, "healthy");
await setup(healthy);
assert.equal((await invoke(healthy, "pay")).status, "paid");
assert.equal((await invoke(healthy, "pay")).status, "paid");
assert.equal((await invoke(healthy, "status")).status, "paid");
assert.equal(postCount, 1);

const beforePost = join(root, "before-post");
const beforeRequest = await setup(beforePost, "250");
const unrelated = join(beforePost, "unrelated.bin");
writeFileSync(unrelated, Buffer.from([0, 1, 2, 255]));
await crash(beforePost, "after-payment-saved-before-request");
const saved = await invoke(beforePost, "status");
assert.equal(saved.payment, "attempt_saved");
assert.equal((await invoke(beforePost, "reconcile", saved.payment_id)).lookup, "not_sent");
assert.equal((await invoke(beforePost, "pay")).status, "paid");
assert.deepEqual(readFileSync(unrelated), Buffer.from([0, 1, 2, 255]));
assert.equal((await invoke(beforePost, "status")).request_id, beforeRequest);

const afterAccept = join(root, "after-accept");
await setup(afterAccept, "300");
await crash(afterAccept, "after-accept-before-record");
assert.equal((await invoke(afterAccept, "status")).payment, "attempt_saved");
assert.equal((await invoke(afterAccept, "pay")).status, "paid");

const afterRecord = join(root, "after-record");
await setup(afterRecord, "325");
await crash(afterRecord, "after-record-before-exit");
assert.equal((await invoke(afterRecord, "status")).status, "paid");
const postsAfterRecord = postCount;
assert.equal((await invoke(afterRecord, "pay")).status, "paid");
assert.equal(postCount, postsAfterRecord);
const paidId = (await invoke(afterRecord, "status")).payment_id;
assert.equal((await invoke(afterRecord, "reconcile", paidId)).lookup, "paid");

const dropped = join(root, "dropped");
await setup(dropped, "350");
dropNext = true;
let failed = false;
try { await invoke(dropped, "pay"); } catch (error) { failed = true; assert.equal(error.parsed.error, "service_unavailable"); }
assert.equal(failed, true);
const droppedStatus = await invoke(dropped, "status");
assert.equal(droppedStatus.payment, "attempt_saved");
const postsAfterDrop = postCount;
assert.equal((await invoke(dropped, "reconcile", droppedStatus.payment_id)).lookup, "paid");
assert.equal(postCount, postsAfterDrop);
const threshold = join(root, "threshold");
await invoke(threshold, "open", "freelancer", "period", "100000");
const thresholdRequest = (await invoke(threshold, "submit", "60000")).request_id;
assert.equal((await invoke(threshold, "approve", thresholdRequest, "first")).status, "awaiting_second");
const thresholdPosts = postCount;
let notApproved = false;
try { await invoke(threshold, "pay"); } catch (error) { notApproved = true; assert.equal(error.parsed.error, "not_approved"); }
assert.equal(notApproved, true);
assert.equal(postCount, thresholdPosts);
let duplicate = false;
try { await invoke(threshold, "approve-second", thresholdRequest, "first"); } catch (error) { duplicate = true; assert.equal(error.parsed.error, "duplicate_manager"); }
assert.equal(duplicate, true);
assert.equal((await invoke(threshold, "approve-second", thresholdRequest, "second")).status, "approved");
assert.equal((await invoke(threshold, "approve-second", thresholdRequest, "second")).second_manager_id, "second");
assert.equal((await invoke(threshold, "pay")).status, "paid");
assert.equal(postCount, thresholdPosts + 1);

const boundary = join(root, "boundary");
await invoke(boundary, "open", "freelancer", "period", "100000");
const boundaryRequest = (await invoke(boundary, "submit", "50000")).request_id;
assert.equal((await invoke(boundary, "approve", boundaryRequest, "manager")).status, "approved");
assert.equal((await invoke(boundary, "status")).second_manager_id, null);

const cancelAwaiting = join(root, "cancel-awaiting");
await invoke(cancelAwaiting, "open", "freelancer", "period", "100000");
const cancelAwaitingRequest = (await invoke(cancelAwaiting, "submit", "60000")).request_id;
await invoke(cancelAwaiting, "approve", cancelAwaitingRequest, "manager");
assert.equal((await invoke(cancelAwaiting, "cancel", cancelAwaitingRequest)).status, "cancelled");
const cancelledStatus = await invoke(cancelAwaiting, "status");
assert.equal(cancelledStatus.approved_cents, 0);
assert.equal(cancelledStatus.manager_id, null);
assert.equal(cancelledStatus.second_manager_id, null);
assert.equal((await invoke(cancelAwaiting, "submit", "100")).status, "submitted");

const cancelApproved = join(root, "cancel-approved");
await setup(cancelApproved, "400");
const cancelApprovedRequest = (await invoke(cancelApproved, "status")).request_id;
assert.equal((await invoke(cancelApproved, "cancel", cancelApprovedRequest)).status, "cancelled");
let cancelledPay = false;
try { await invoke(cancelApproved, "pay"); } catch (error) { cancelledPay = true; assert.equal(error.parsed.error, "not_approved"); }
assert.equal(cancelledPay, true);

const cancelSaved = join(root, "cancel-saved");
await setup(cancelSaved, "450");
await crash(cancelSaved, "after-payment-saved-before-request");
const cancelSavedStatus = await invoke(cancelSaved, "status");
const cancelSavedPosts = postCount;
let started = false;
try { await invoke(cancelSaved, "cancel", cancelSavedStatus.request_id); } catch (error) { started = true; assert.equal(error.parsed.error, "payment_started"); }
assert.equal(started, true);
assert.equal((await invoke(cancelSaved, "status")).payment_id, cancelSavedStatus.payment_id);
assert.equal((await invoke(cancelSaved, "pay")).status, "paid");
assert.equal(postCount, cancelSavedPosts + 1);

const cancelAccepted = join(root, "cancel-accepted");
await setup(cancelAccepted, "475");
await crash(cancelAccepted, "after-accept-before-record");
const cancelAcceptedPosts = postCount;
const cancelAcceptedStatus = await invoke(cancelAccepted, "status");
let acceptedStarted = false;
try { await invoke(cancelAccepted, "cancel", cancelAcceptedStatus.request_id); } catch (error) { acceptedStarted = true; assert.equal(error.parsed.error, "payment_started"); }
assert.equal(acceptedStarted, true);
assert.equal((await invoke(cancelAccepted, "pay")).status, "paid");
assert.equal(postCount, cancelAcceptedPosts);

const callback = join(root, "callback");
await setup(callback, "200");
const callbackFile = join(root, "callback.json");
writeFileSync(callbackFile, JSON.stringify({ outcome: "paid", payment_id: "wrong" }));
assert.equal((await invoke(callback, "callback", callbackFile)).callback, "ignored");
assert.equal((await invoke(callback, "status")).status, "approved");
server.close();
console.log(JSON.stringify({ ok: true, postCount }));
