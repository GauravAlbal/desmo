#!/usr/bin/env node
import { randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { Kernel, HistoricalResult, StoreNotFoundError } from "@ikaros/runtime";

const ROOT = dirname(fileURLToPath(import.meta.url));
const MACHINE_PATH = join(ROOT, "payout_desk.ik.toml");
const V1_MACHINE_PATH = join(ROOT, "payout_desk_v1.ik.toml");
const IDENT = /^[A-Za-z0-9._-]{1,64}$/;
const MAX_CENTS = 100000000;
const SECOND_APPROVAL_THRESHOLD = 50000;
const EMPTY_STATUS = {
  freelancer_id: null, period_id: null, cap_cents: null, request_id: null,
  requested_cents: null, approved_cents: null, manager_id: null, second_manager_id: null, memo: null,
  status: "none", payment: "none", payment_id: null,
};

function fail(code) { const error = new Error(code); error.publicCode = code; throw error; }
function validId(value) { return typeof value === "string" && IDENT.test(value); }
function amount(value) {
  if (typeof value !== "string" || !/^[1-9][0-9]*$/.test(value)) return null;
  const n = Number(value);
  return Number.isSafeInteger(n) && n >= 1 && n <= MAX_CENTS ? n : null;
}
function textOk(value, max = 200) {
  return typeof value === "string" && Array.from(value).length <= max;
}
function facts(aggregate) { return aggregate.raw.state ?? {}; }
function stateOf(aggregate) { return aggregate.namedState(); }
function empty(v) { return v === undefined || v === "" ? null : v; }
function resultValue(value) { return typeof value === "bigint" ? Number(value) : value; }
function responseFor(aggregate) {
  const s = stateOf(aggregate);
  if (s === "unbound") return { ...EMPTY_STATUS };
  const f = facts(aggregate);
  const payment = f.payment_status || "none";
  return {
    freelancer_id: empty(f.freelancer_id), period_id: empty(f.period_id),
    cap_cents: resultValue(f.cap_cents ?? 0), request_id: empty(f.request_id),
    requested_cents: f.request_id ? resultValue(f.requested_cents) : null,
    approved_cents: f.request_id ? resultValue(f.approved_cents) : null,
    manager_id: empty(f.manager_id), second_manager_id: empty(f.second_manager_id), memo: f.request_id ? empty(f.memo) : null,
    status: s === "bound" ? "none" : s,
    payment: payment, payment_id: payment === "none" ? null : empty(f.payment_id),
  };
}
function success(aggregate, extra = {}) {
  const f = facts(aggregate);
  return {
    request_id: f.request_id,
    payment_id: f.payment_id,
    amount_cents: resultValue(f.approved_cents),
    status: "paid", payment: "paid", ...extra,
  };
}
function kernelFor(stateDir) {
  mkdirSync(stateDir, { recursive: true });
  return new Kernel(join(stateDir, "kernel.db"));
}
async function loadMachine(stateDir, machinePath = MACHINE_PATH) {
  const kernel = kernelFor(stateDir);
  return { kernel, machine: await kernel.machine(machinePath) };
}
function machineVersion(aggregate) {
  return Number(aggregate.raw?.last_receipt?.machine_version ?? 1);
}
async function loadAggregate(stateDir, create = false) {
  const opened = await loadMachine(stateDir);
  try {
    if (create) {
      const aggregate = await opened.machine.create("desk");
      return { ...opened, aggregate };
    }
    let aggregate = await opened.machine.show("desk");
    if (machineVersion(aggregate) === 1) {
      const routed = await loadMachine(stateDir, V1_MACHINE_PATH);
      aggregate = await routed.machine.show("desk");
      return { ...routed, aggregate };
    }
    return { ...opened, aggregate };
  } catch (error) {
    if (error instanceof StoreNotFoundError && !create) return { ...opened, aggregate: null };
    throw error;
  }
}
function mappedKernelError(error) {
  if (error?.publicCode) return error.publicCode;
  if (error?.code === "IK_STORE_CORRUPT" || error?.code === "IK_JOURNAL_CORRUPT" || error?.code === "IK_PROTOCOL_INVALID") return "corrupt_state";
  if (error?.code === "IK_STORE_NOT_FOUND") return "no_request";
  return "corrupt_state";
}
async function commandOpen(stateDir, args) {
  if (args.length !== 3) fail("bad_args");
  const [freelancerId, periodId, capText] = args;
  const cap = amount(capText);
  if (!validId(freelancerId) || !validId(periodId)) fail("bad_args");
  if (cap === null) fail("bad_amount");
  const loaded = await loadAggregate(stateDir, false);
  if (loaded.aggregate) fail("already_open");
  const created = await loadAggregate(stateDir, true);
  await created.aggregate.command("open", { freelancer_id: freelancerId, period_id: periodId, cap_cents: cap, payment_status: "none", used_managers: "", second_manager_id: "" });
  return { freelancer_id: freelancerId, period_id: periodId, cap_cents: cap, request_id: null, status: "none", payment: "none" };
}
async function commandSubmit(stateDir, args) {
  if (args.length < 1 || args.length > 2) fail("bad_args");
  const [amountText, memo = ""] = args;
  const requested = amount(amountText);
  if (requested === null) fail("bad_amount");
  if (!textOk(memo)) fail("bad_args");
  const { aggregate } = await loadAggregate(stateDir);
  if (!aggregate || stateOf(aggregate) === "unbound") fail("no_request");
  const s = stateOf(aggregate); const f = facts(aggregate);
  if (s === "submitted" || s === "awaiting_second" || s === "approved") fail("request_exists");
  if (requested > resultValue(f.cap_cents)) fail("over_cap");
  const requestId = randomUUID();
  const submitArgs = {
    request_id: requestId, requested_cents: requested, approved_cents: 0, manager_id: "",
    memo, reason: "", payment_status: "none", payment_id: "", snapshot_freelancer_id: "",
    snapshot_period_id: "", snapshot_request_id: "", snapshot_amount_cents: 0, second_manager_id: "",
  };
  if (machineVersion(aggregate) === 1) delete submitArgs.second_manager_id;
  await aggregate.command("submit", submitArgs);
  return { request_id: requestId, freelancer_id: f.freelancer_id, period_id: f.period_id,
    requested_cents: requested, approved_cents: 0, memo: memo || null, status: "submitted", payment: "none", payment_id: null };
}
function currentRequest(aggregate, requestId) {
  const f = facts(aggregate);
  if (!f.request_id) fail("no_request");
  if (f.request_id !== requestId) fail("request_mismatch");
  return f;
}
async function commandApprove(stateDir, args) {
  if (args.length < 2 || args.length > 3) fail("bad_args");
  const [requestId, managerId, approvedText] = args;
  if (!validId(requestId) || !validId(managerId)) fail("bad_args");
  const { aggregate } = await loadAggregate(stateDir); if (!aggregate) fail("no_request");
  const f = currentRequest(aggregate, requestId); const s = stateOf(aggregate);
  if (s !== "submitted") fail(s === "approved" ? "already_approved" : "bad_status");
  const approved = approvedText === undefined ? resultValue(f.requested_cents) : amount(approvedText);
  if (approved === null || approved > resultValue(f.requested_cents)) fail("bad_amount");
  const managers = String(f.used_managers || "").split("|").filter(Boolean);
  if (managers.includes(managerId)) fail("duplicate_manager");
  const reserved = resultValue(f.reserved_cents || 0) + approved;
  if (reserved > resultValue(f.cap_cents)) fail("over_cap");
  managers.push(managerId);
  if (machineVersion(aggregate) === 1) {
    await aggregate.command("approve", { manager_id: managerId, approved_cents: approved, reserved_cents: reserved, used_managers: managers.join("|") });
    return { request_id: requestId, approved_cents: approved, manager_id: managerId, status: "approved", payment: "none", payment_id: null };
  }
  const command = approved > SECOND_APPROVAL_THRESHOLD ? "approve_first" : "approve";
  await aggregate.command(command, {
    manager_id: managerId, approved_cents: approved, reserved_cents: reserved,
    used_managers: managers.join("|"), second_manager_id: "",
  });
  return { request_id: requestId, approved_cents: approved, manager_id: managerId,
    status: approved > SECOND_APPROVAL_THRESHOLD ? "awaiting_second" : "approved", payment: "none", payment_id: null };
}
async function commandApproveSecond(stateDir, args) {
  if (args.length !== 2) fail("bad_args");
  const [requestId, managerId] = args;
  if (!validId(requestId) || !validId(managerId)) fail("bad_args");
  const { aggregate } = await loadAggregate(stateDir); if (!aggregate) fail("no_request");
  const f = currentRequest(aggregate, requestId); const s = stateOf(aggregate);
  if (s === "approved" && f.second_manager_id === managerId) {
    return { request_id: requestId, approved_cents: resultValue(f.approved_cents), manager_id: f.manager_id,
      second_manager_id: managerId, status: "approved", payment: f.payment_status || "none", payment_id: empty(f.payment_id) };
  }
  if (s !== "awaiting_second") fail("bad_status");
  const managers = String(f.used_managers || "").split("|").filter(Boolean);
  if (managers.includes(managerId)) fail("duplicate_manager");
  await aggregate.command("approve_second", { second_manager_id: managerId });
  return { request_id: requestId, approved_cents: resultValue(f.approved_cents), manager_id: f.manager_id,
    second_manager_id: managerId, status: "approved", payment: "none", payment_id: null };
}
async function commandReject(stateDir, args) {
  if (args.length > 2) fail("bad_args");
  const [requestId, reason = ""] = args;
  if (!validId(requestId) || !textOk(reason)) fail("bad_args");
  const { aggregate } = await loadAggregate(stateDir); if (!aggregate) fail("no_request");
  currentRequest(aggregate, requestId); if (stateOf(aggregate) !== "submitted") fail("bad_status");
  await aggregate.command("reject", { reason, payment_status: "none" });
  return { request_id: requestId, status: "rejected", payment: "none" };
}
async function commandCancel(stateDir, args) {
  if (args.length !== 1 || !validId(args[0])) fail("bad_args");
  const { aggregate } = await loadAggregate(stateDir); if (!aggregate) fail("no_request");
  const requestId = args[0]; currentRequest(aggregate, requestId); const s = stateOf(aggregate);
  const f = facts(aggregate);
  if (s === "approved" && f.payment_status === "attempt_saved") fail("payment_started");
  if (machineVersion(aggregate) === 1) {
    if (s === "approved") fail("already_approved");
    if (s !== "submitted") fail("bad_status");
    await aggregate.command("cancel", { payment_status: "none" });
  } else {
    if (!["submitted", "awaiting_second", "approved"].includes(s)) fail("bad_status");
    await aggregate.command("cancel", {
      payment_status: "none", manager_id: "", approved_cents: 0, reserved_cents: 0,
      used_managers: "", second_manager_id: "",
    });
  }
  return { request_id: requestId, status: "cancelled", payment: "none" };
}
function crashIf(label) { if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL"); }
function providerUrl(base, path) { return new URL(path, base.endsWith("/") ? base : `${base}/`).toString(); }
async function httpJson(base, path, options = {}) {
  let response;
  try { response = await fetch(providerUrl(base, path), { ...options, signal: AbortSignal.timeout(3000) }); }
  catch { return { kind: "unavailable" }; }
  let body = null;
  try { body = JSON.parse(await response.text()); } catch { return { kind: "unavailable" }; }
  if (response.status === 404) return { kind: "not_found", body };
  if (response.status !== 200 || !body || typeof body !== "object") return { kind: "unavailable", body };
  return { kind: "ok", body };
}
function matches(body, expected) {
  return body?.payment_id === expected.payment_id && body?.freelancer_id === expected.freelancer_id &&
    body?.period_id === expected.period_id && body?.request_id === expected.request_id &&
    resultValue(body?.amount_cents) === expected.amount_cents && body?.outcome === "paid";
}
async function markPaid(aggregate) {
  await aggregate.command("mark_paid", { payment_status: "paid" });
  crashIf("after-record-before-exit");
}
async function commandPay(stateDir, serviceUrl) {
  const loaded = await loadAggregate(stateDir); if (!loaded.aggregate) fail("no_request");
  let aggregate = loaded.aggregate; let s = stateOf(aggregate); let f = facts(aggregate);
  if (s === "paid") return success(aggregate);
  if (s !== "approved") fail("not_approved");
  let hadAttempt = f.payment_status === "attempt_saved" && Boolean(f.payment_id);
  if (!hadAttempt) {
    const paymentId = randomUUID();
    await aggregate.command("start_payment", { payment_id: paymentId, snapshot_freelancer_id: f.freelancer_id, snapshot_period_id: f.period_id, snapshot_request_id: f.request_id, snapshot_amount_cents: resultValue(f.approved_cents), payment_status: "attempt_saved" });
    aggregate = (await loadAggregate(stateDir)).aggregate; f = facts(aggregate);
    crashIf("after-payment-saved-before-request");
  }
  const expected = { payment_id: f.payment_id, freelancer_id: f.snapshot_freelancer_id, period_id: f.snapshot_period_id, request_id: f.snapshot_request_id, amount_cents: resultValue(f.snapshot_amount_cents) };
  if (hadAttempt) {
    const lookup = await httpJson(serviceUrl, `/v1/payments/${encodeURIComponent(expected.payment_id)}`);
    if (lookup.kind === "ok") {
      if (!matches(lookup.body, expected)) fail("lookup_conflict");
      await markPaid(aggregate); return success((await loadAggregate(stateDir)).aggregate);
    }
    if (lookup.kind === "unavailable") fail("service_unavailable");
  }
  const posted = await httpJson(serviceUrl, "/v1/payouts", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(expected) });
  if (posted.kind !== "ok") fail("service_unavailable");
  if (!matches(posted.body, expected)) fail("lookup_conflict");
  crashIf("after-accept-before-record");
  await markPaid(aggregate); return success((await loadAggregate(stateDir)).aggregate);
}
async function commandReconcile(stateDir, serviceUrl, args) {
  if (args.length !== 1 || !validId(args[0])) fail("bad_args");
  const { aggregate } = await loadAggregate(stateDir); if (!aggregate) fail("no_payment");
  const f = facts(aggregate); if (!f.payment_id) fail("no_payment");
  if (f.payment_id !== args[0]) fail("payment_mismatch");
  if (stateOf(aggregate) === "paid") return success(aggregate, { lookup: "paid" });
  if (f.payment_status !== "attempt_saved") fail("no_payment");
  const expected = { payment_id: f.payment_id, freelancer_id: f.snapshot_freelancer_id, period_id: f.snapshot_period_id, request_id: f.snapshot_request_id, amount_cents: resultValue(f.snapshot_amount_cents) };
  const found = await httpJson(serviceUrl, `/v1/payments/${encodeURIComponent(f.payment_id)}`);
  if (found.kind === "unavailable") fail("service_unavailable");
  if (found.kind === "not_found") return { lookup: "not_sent", request_id: f.request_id, payment_id: f.payment_id, payment: "attempt_saved", status: "approved" };
  if (!matches(found.body, expected)) fail("lookup_conflict");
  await markPaid(aggregate); return success((await loadAggregate(stateDir)).aggregate, { lookup: "paid" });
}
async function commandCallback(args) {
  if (args.length !== 1) fail("bad_args");
  try { JSON.parse(readFileSync(resolve(args[0]), "utf8")); } catch { fail("bad_callback"); }
  return { callback: "ignored" };
}
async function main() {
  const [command, ...args] = process.argv.slice(2);
  const stateDir = process.env.STATE_DIR;
  const serviceUrl = process.env.SERVICE_URL;
  if (!stateDir || !serviceUrl) fail("bad_args");
  switch (command) {
    case "open": return commandOpen(stateDir, args);
    case "submit": return commandSubmit(stateDir, args);
    case "approve": return commandApprove(stateDir, args);
    case "approve-second": return commandApproveSecond(stateDir, args);
    case "cancel": return commandCancel(stateDir, args);
    case "pay": case "apply": return commandPay(stateDir, serviceUrl);
    case "reconcile": return commandReconcile(stateDir, serviceUrl, args);
    case "status": {
      if (args.length) fail("bad_args");
      const store = join(stateDir, "kernel.db");
      if (!existsSync(store)) return { ...EMPTY_STATUS };
      const loaded = await loadAggregate(stateDir); return responseFor(loaded.aggregate);
    }
    case "callback": return commandCallback(args);
    default: fail("bad_args");
  }
}
main().then((value) => { process.stdout.write(`${JSON.stringify(value)}\n`); }).catch((error) => {
  process.stdout.write(`${JSON.stringify({ error: error.publicCode || mappedKernelError(error) })}\n`);
  process.exitCode = 1;
});
