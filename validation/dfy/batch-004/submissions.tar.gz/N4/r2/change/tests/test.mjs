import assert from "node:assert/strict";
import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { spawn, spawnSync } from "node:child_process";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { once } from "node:events";

const project = resolve(new URL("..", import.meta.url).pathname);
const run = join(project, "run");

async function startStub() {
  const child = spawn(process.execPath, ["stub/server.mjs"], { cwd: project, stdio: ["ignore", "pipe", "inherit"] });
  let line = "";
  for await (const chunk of child.stdout) {
    line += chunk;
    const newline = line.indexOf("\n");
    if (newline >= 0) return { child, ...JSON.parse(line.slice(0, newline)) };
  }
  throw new Error("stub exited before announcing its URLs");
}

async function control(url, body) {
  const response = await fetch(`${url}/fault`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  assert.equal(response.status, 200);
}
async function effects(url) {
  const response = await fetch(`${url}/effects`);
  return response.json();
}
function invoke(state, service, args, extra = {}) {
  const result = spawnSync(run, args, {
    cwd: project,
    encoding: "utf8",
    env: { ...process.env, STATE_DIR: state, SERVICE_URL: service, NOW_MS: "100" , ...extra },
  });
  assert.equal((result.stdout.match(/\n/g) || []).length, result.stdout ? 1 : 0, `one JSON result: ${result.stderr}`);
  return { ...result, value: result.stdout ? JSON.parse(result.stdout) : null };
}
function ok(state, service, args, extra) {
  const result = invoke(state, service, args, extra);
  assert.equal(result.status, 0, `${args.join(" ")} failed: ${result.stdout}${result.stderr}`);
  return result.value;
}
function refused(state, service, args, error, extra) {
  const result = invoke(state, service, args, extra);
  assert.notEqual(result.status, 0, `${args.join(" ")} unexpectedly succeeded`);
  assert.deepEqual(result.value, { error });
}

const state = await mkdtemp(join(tmpdir(), "seat-desk-"));
const preserved = Buffer.from("other writer bytes\n\0\xff", "binary");
await writeFile(join(state, "unrelated.bin"), preserved);
const stub = await startStub();
try {
  ok(state, stub.service_url, ["section", "hall-a", "3"]);
  assert.deepEqual(ok(state, stub.service_url, ["section", "hall-a", "3"]), { section_id: "hall-a", capacity: 3, held: 0, available: 3 });
  refused(state, stub.service_url, ["section", "hall-a", "4"], "conflict");
  assert.equal(ok(state, stub.service_url, ["hold", "h1", "hall-a", "A1", "5000"]).state, "held");
  refused(state, stub.service_url, ["hold", "h2", "hall-a", "A1", "5000"], "seat_taken");
  assert.equal(ok(state, stub.service_url, ["status", "h1"]).state, "held");
  const issued = ok(state, stub.service_url, ["issue", "h1"]);
  assert.equal(issued.state, "ticketed");
  assert.equal(ok(state, stub.service_url, ["issue", "h1"]).ticket_id, issued.ticket_id);
  assert.equal((await effects(stub.control_url)).count, 1);

  ok(state, stub.service_url, ["hold", "h2", "hall-a", "A2", "5000"]);
  const pre = invoke(state, stub.service_url, ["issue", "h2"], { CRASH_AT: "after-hold-saved-before-request" });
  assert.notEqual(pre.status, 0);
  assert.deepEqual(ok(state, stub.service_url, ["reconcile", "h2"]), { outcome: "not_sent" });
  assert.equal((await effects(stub.control_url)).count, 1);
  assert.equal(ok(state, stub.service_url, ["issue", "h2"]).state, "ticketed");
  assert.equal((await effects(stub.control_url)).count, 2);

  ok(state, stub.service_url, ["hold", "h3", "hall-a", "A3", "5000"]);
  const accepted = invoke(state, stub.service_url, ["issue", "h3"], { CRASH_AT: "after-accept-before-record" });
  assert.notEqual(accepted.status, 0);
  assert.equal((await effects(stub.control_url)).count, 3);
  assert.equal(ok(state, stub.service_url, ["reconcile", "h3"]).outcome, "ticketed");
  assert.equal((await effects(stub.control_url)).count, 3);

  ok(state, stub.service_url, ["section", "hall-b", "2"]);
  ok(state, stub.service_url, ["hold", "h4", "hall-b", "B1", "5000"]);
  const recorded = invoke(state, stub.service_url, ["issue", "h4"], { CRASH_AT: "after-record-before-exit" });
  assert.notEqual(recorded.status, 0);
  assert.equal(ok(state, stub.service_url, ["status", "h4"]).state, "ticketed");
  assert.equal((await effects(stub.control_url)).count, 4);
  assert.equal(ok(state, stub.service_url, ["issue", "h4"]).state, "ticketed");
  assert.equal((await effects(stub.control_url)).count, 4);

  ok(state, stub.service_url, ["hold", "h5", "hall-b", "B2", "5000"]);
  await control(stub.control_url, { drop_reply: true });
  refused(state, stub.service_url, ["issue", "h5"], "unavailable");
  await control(stub.control_url, { drop_reply: false });
  assert.equal(ok(state, stub.service_url, ["reconcile", "h5"]).outcome, "ticketed");
  assert.equal((await effects(stub.control_url)).count, 5);

  ok(state, stub.service_url, ["section", "hall-c", "1"]);
  const past = ok(state, stub.service_url, ["hold", "h6", "hall-c", "C1", "100"]);
  assert.equal(past.state, "held");
  refused(state, stub.service_url, ["issue", "h6"], "expired");
  assert.equal(ok(state, stub.service_url, ["status", "h6"]).state, "expired");

  ok(state, stub.service_url, ["section", "hall-group", "4"]);
  refused(state, stub.service_url, ["hold", "g-bad", "hall-group", "B1", "B1", "5000"], "bad_args");
  ok(state, stub.service_url, ["section", "hall-cap", "2"]);
  assert.deepEqual(ok(state, stub.service_url, ["hold", "cap1", "hall-cap", "C1", "C2", "5000"]).seat_ids, ["C1", "C2"]);
  refused(state, stub.service_url, ["hold", "cap2", "hall-cap", "C3", "5000"], "capacity_exceeded");
  assert.deepEqual(ok(state, stub.service_url, ["section-status", "hall-cap"]), { section_id: "hall-cap", capacity: 2, held: 2, available: 0 });
  const group = ok(state, stub.service_url, ["hold", "g1", "hall-group", "A2", "A1", "5000"]);
  assert.deepEqual(group.seat_ids, ["A1", "A2"]);
  assert.deepEqual(ok(state, stub.service_url, ["hold", "g1", "hall-group", "A1", "A2", "5000"]).seat_ids, ["A1", "A2"]);
  assert.deepEqual(ok(state, stub.service_url, ["section-status", "hall-group"]), { section_id: "hall-group", capacity: 4, held: 2, available: 2 });
  refused(state, stub.service_url, ["hold", "g2", "hall-group", "A2", "A3", "5000"], "seat_taken");
  assert.deepEqual(ok(state, stub.service_url, ["status", "g1"]).seat_ids, ["A1", "A2"]);
  assert.deepEqual(ok(state, stub.service_url, ["release", "g1", "A1"]).seat_ids, ["A2"]);
  assert.deepEqual(ok(state, stub.service_url, ["section-status", "hall-group"]), { section_id: "hall-group", capacity: 4, held: 1, available: 3 });
  assert.deepEqual(ok(state, stub.service_url, ["hold", "g2", "hall-group", "A1", "5000"]).seat_ids, ["A1"]);
  refused(state, stub.service_url, ["release", "g1", "A2"], "bad_args");
  assert.deepEqual(ok(state, stub.service_url, ["status", "g1"]).seat_ids, ["A2"]);
  assert.deepEqual(ok(state, stub.service_url, ["release", "g1"]).seat_ids, []);
  refused(state, stub.service_url, ["release", "g1", "A1"], "already_released");
  const grouped = ok(state, stub.service_url, ["hold", "g3", "hall-group", "A3", "A4", "5000"]);
  const groupedTicket = ok(state, stub.service_url, ["issue", "g3"]);
  assert.equal(groupedTicket.state, "ticketed");
  const observed = await effects(stub.control_url);
  assert.equal(observed.effects.at(-1).hold_id, "g3");
  assert.deepEqual([...observed.effects.at(-1).seat_ids].sort(), ["A3", "A4"]);
  assert.equal(ok(state, stub.service_url, ["issue", "g3"]).ticket_id, groupedTicket.ticket_id);
  assert.equal((await effects(stub.control_url)).count, 6);

  assert.deepEqual(await readFile(join(state, "unrelated.bin")), preserved);
  console.log(JSON.stringify({ ok: true, effects: (await effects(stub.control_url)).count }));
} finally {
  stub.child.kill("SIGTERM");
  await once(stub.child, "exit").catch(() => {});
  await rm(state, { recursive: true, force: true });
}
