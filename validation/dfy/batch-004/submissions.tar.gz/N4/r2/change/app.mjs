#!/usr/bin/env node
import { randomUUID } from "node:crypto";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { mkdir, open, readFile, rename, writeFile } from "node:fs/promises";
import { Kernel, HistoricalResult } from "@ikaros/runtime";

const PROJECT_DIR = dirname(fileURLToPath(import.meta.url));
const MACHINE_PATH = join(PROJECT_DIR, "desk.ik.toml");
const LEGACY_MACHINE_PATH = join(PROJECT_DIR, "desk.v1.ik.toml");
const STATE_DIR = resolve(process.env.STATE_DIR || join(PROJECT_DIR, ".state"));
const SECTIONS_PATH = join(STATE_DIR, "sections.json");
const KERNEL_STORE = join(STATE_DIR, "lifecycle.sqlite");
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const SEAT_RE = /^[A-Za-z0-9._-]{1,32}$/;
const MAX_SAFE = 9007199254740991n;

class Refusal extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
}

function fail(code) { throw new Refusal(code); }
function isId(value) { return typeof value === "string" && ID_RE.test(value); }
function isSeat(value) { return typeof value === "string" && SEAT_RE.test(value); }
function parseCapacity(value) {
  if (!/^\d+$/.test(value || "")) fail("bad_capacity");
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n < 1 || n > 100000) fail("bad_capacity");
  return n;
}
function parseDeadline(value) {
  if (!/^\d+$/.test(value || "")) fail("bad_deadline");
  const n = BigInt(value);
  if (n > MAX_SAFE) fail("bad_deadline");
  return n;
}
function nowMs() {
  const raw = process.env.NOW_MS;
  if (!/^\d+$/.test(raw || "")) fail("bad_args");
  const n = BigInt(raw);
  if (n > MAX_SAFE) fail("bad_args");
  return n;
}
function jsonSafe(value) {
  if (typeof value === "bigint") return Number(value);
  if (Array.isArray(value)) return value.map(jsonSafe);
  if (value && typeof value === "object") {
    const out = {};
    for (const [key, item] of Object.entries(value)) out[key] = jsonSafe(item);
    return out;
  }
  return value;
}
function stateName(aggregate) { return aggregate.namedState(); }
function fact(aggregate, name) {
  const value = aggregate.state?.[name];
  return value === undefined ? null : value;
}
function deadlineOf(aggregate) { return BigInt(fact(aggregate, "deadline_ms")); }

async function loadSections() {
  await mkdir(STATE_DIR, { recursive: true });
  try {
    const raw = await readFile(SECTIONS_PATH, "utf8");
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || !parsed.sections || typeof parsed.sections !== "object") {
      fail("unavailable");
    }
    return parsed;
  } catch (error) {
    if (error instanceof Refusal) throw error;
    if (error.code === "ENOENT") return { sections: {} };
    fail("unavailable");
  }
}

async function saveSections(sections) {
  const temp = `${SECTIONS_PATH}.tmp-${process.pid}-${randomUUID()}`;
  const handle = await open(temp, "w", 0o600);
  try {
    await handle.writeFile(JSON.stringify(sections) + "\n", "utf8");
    await handle.sync();
  } finally {
    await handle.close();
  }
  await rename(temp, SECTIONS_PATH);
}

function sectionRecord(sections, sectionId) {
  const section = sections.sections[sectionId];
  if (!section) fail("unknown_section");
  return section;
}

function parseSeatFact(value) {
  if (typeof value !== "string") return null;
  try {
    const seats = JSON.parse(value);
    if (Array.isArray(seats) && seats.every(isSeat)) return seats;
  } catch {}
  fail("unavailable");
}

function seatIdsOf(aggregate) {
  const encoded = fact(aggregate, "seat_ids");
  if (encoded !== null) return parseSeatFact(encoded);
  const seatId = fact(aggregate, "seat_id");
  return seatId === null ? [] : [seatId];
}

function allSeatIdsOf(aggregate) {
  const encoded = fact(aggregate, "all_seat_ids");
  return encoded === null ? seatIdsOf(aggregate) : parseSeatFact(encoded);
}

function encodeSeats(seats) { return JSON.stringify(seats); }
function sameSeats(left, right) {
  return left.length === right.length && left.every((seat, index) => seat === right[index]);
}
function isLegacyAggregate(aggregate) {
  return Number(aggregate.raw?.receipt?.machine_version ?? aggregate.raw?.last_receipt?.machine_version) === 1;
}

function holdResult(aggregate) {
  const state = stateName(aggregate);
  return {
    hold_id: aggregate.id,
    section_id: fact(aggregate, "section_id"),
    seat_ids: seatIdsOf(aggregate),
    deadline_ms: jsonSafe(fact(aggregate, "deadline_ms")),
    state,
    request_id: fact(aggregate, "request_id"),
    ticket_id: fact(aggregate, "ticket_id"),
  };
}

async function machine() {
  const kernel = new Kernel(KERNEL_STORE);
  return {
    kernel,
    machine: await kernel.machine(MACHINE_PATH),
    legacy: await kernel.machine(LEGACY_MACHINE_PATH),
  };
}

function missingHoldError(error) {
  return error?.code === "IK_STORE_NOT_FOUND" || error?.code === "IK_ILLEGAL_STATE" || error?.rule === "aggregate.not_found";
}

async function findHold(machineApi, holdId, legacyApi) {
  try {
    const inspected = await machineApi.show(holdId);
    if (legacyApi && isLegacyAggregate(inspected)) return legacyApi.show(holdId);
    return inspected;
  } catch (error) {
    if (missingHoldError(error)) fail("unknown_hold");
    throw error;
  }
}

async function expireIfDue(aggregate, now, sections) {
  if (stateName(aggregate) !== "held" || deadlineOf(aggregate) > now) return aggregate;
  const next = await aggregate.command("expire");
  return next;
}

function addHoldToSection(sections, sectionId, holdId) {
  const section = sectionRecord(sections, sectionId);
  if (!section.holds.includes(holdId)) section.holds.push(holdId);
}

async function sectionStatus(sectionId, expireDue = true) {
  const sections = await loadSections();
  const section = sectionRecord(sections, sectionId);
  const { machine: machineApi, legacy } = await machine();
  const now = expireDue ? nowMs() : null;
  let changed = false;
  let held = 0;
  for (const holdId of section.holds) {
    let aggregate;
    try { aggregate = await findHold(machineApi, holdId, legacy); } catch (error) {
      if (error instanceof Refusal && error.code === "unknown_hold") continue;
      throw error;
    }
    const before = stateName(aggregate);
    if (now !== null) aggregate = await expireIfDue(aggregate, now, sections);
    if (stateName(aggregate) !== before) changed = true;
    if (!["released", "expired"].includes(stateName(aggregate))) held += seatIdsOf(aggregate).length;
  }
  if (changed) await saveSections(sections);
  return { section_id: sectionId, capacity: section.capacity, held, available: section.capacity - held };
}

async function sectionCommand(sectionId, capacity) {
  const sections = await loadSections();
  const existing = sections.sections[sectionId];
  if (existing) {
    if (existing.capacity !== capacity) fail("conflict");
    return sectionStatus(sectionId, false);
  }
  sections.sections[sectionId] = { capacity, holds: [] };
  await saveSections(sections);
  return { section_id: sectionId, capacity, held: 0, available: capacity };
}

async function holdCommand(holdId, sectionId, seatIds, deadline) {
  const now = nowMs();
  const sections = await loadSections();
  const section = sectionRecord(sections, sectionId);
  const { machine: machineApi, legacy } = await machine();
  let existing = null;
  try { existing = await findHold(machineApi, holdId, legacy); } catch (error) {
    if (!(error instanceof Refusal && error.code === "unknown_hold")) throw error;
  }
  if (existing) {
    const existingSeats = seatIdsOf(existing);
    const same = fact(existing, "section_id") === sectionId && sameSeats(existingSeats, seatIds) && deadlineOf(existing) === deadline;
    if (!same) fail("conflict");
    const hadIndex = section.holds.includes(holdId);
    addHoldToSection(sections, sectionId, holdId);
    const before = stateName(existing);
    const after = await expireIfDue(existing, now, sections);
    if (!hadIndex || stateName(after) !== before) await saveSections(sections);
    return holdResult(after);
  }
  let heldCount = 0;
  for (const priorId of section.holds) {
    let prior;
    try { prior = await findHold(machineApi, priorId, legacy); } catch (error) {
      if (error instanceof Refusal && error.code === "unknown_hold") continue;
      throw error;
    }
    const before = stateName(prior);
    prior = await expireIfDue(prior, now, sections);
    if (stateName(prior) !== before) await saveSections(sections);
    if (!["released", "expired"].includes(stateName(prior))) {
      const priorSeats = seatIdsOf(prior);
      heldCount += priorSeats.length;
      if (priorSeats.some((seat) => seatIds.includes(seat))) fail("seat_taken");
    }
  }
  if (heldCount + seatIds.length > section.capacity) fail("capacity_exceeded");
  const created = await machineApi.createWith({
    aggregateId: holdId,
    command: { name: "initialize", args: { section_id: sectionId, seat_ids: encodeSeats(seatIds), all_seat_ids: encodeSeats(seatIds), deadline_ms: deadline } },
    operationId: `create-${holdId}-${randomUUID()}`,
  });
  const result = created instanceof HistoricalResult ? await machineApi.show(holdId) : created;
  addHoldToSection(sections, sectionId, holdId);
  await saveSections(sections);
  return holdResult(result);
}

async function expireForUse(aggregate, sections, now) {
  if (stateName(aggregate) === "held" && deadlineOf(aggregate) <= now) {
    aggregate = await aggregate.command("expire");
    await saveSections(sections);
  }
  return aggregate;
}

function providerUrl(path) {
  const base = process.env.SERVICE_URL;
  if (!base) fail("unavailable");
  return `${base.replace(/\/$/, "")}${path}`;
}

async function requestProvider(method, path, body) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(providerUrl(path), {
      method,
      headers: body === undefined ? {} : { "content-type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: controller.signal,
    });
    const text = await response.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = null; }
    return { status: response.status, data };
  } catch {
    return { status: 0, data: null };
  } finally {
    clearTimeout(timeout);
  }
}

function matchesTicket(data, aggregate) {
  const expected = seatIdsOf(aggregate);
  const actual = data?.seat_ids;
  return data && data.request_id === fact(aggregate, "request_id") && data.hold_id === aggregate.id &&
    data.section_id === fact(aggregate, "section_id") && Array.isArray(actual) &&
    actual.length === expected.length && new Set(actual).size === actual.length &&
    expected.every((seat) => actual.includes(seat)) && typeof data.ticket_id === "string";
}

async function commitTicket(aggregate, ticketId) {
  try {
    return await aggregate.command("mark_ticketed", { ticket_id: ticketId });
  } catch (error) {
    if (error?.outcome === "submission-unknown") {
      const { machine: machineApi } = await machine();
      const current = await machineApi.show(aggregate.id);
      if (stateName(current) === "ticketed") return current;
    }
    throw error;
  }
}

function crashAt(name) {
  if (process.env.CRASH_AT === name) process.kill(process.pid, "SIGKILL");
}

async function issueCommand(holdId) {
  const now = nowMs();
  const sections = await loadSections();
  const { machine: machineApi, legacy } = await machine();
  let aggregate = await findHold(machineApi, holdId, legacy);
  aggregate = await expireForUse(aggregate, sections, now);
  let state = stateName(aggregate);
  if (state === "expired") fail("expired");
  if (state === "released") fail("released");
  if (state === "ticketed") return holdResult(aggregate);
  let justSaved = false;
  if (state === "held") {
    const requestId = randomUUID().replaceAll("-", "");
    aggregate = await aggregate.command("save_attempt", { request_id: requestId });
    crashAt("after-hold-saved-before-request");
    justSaved = true;
    state = stateName(aggregate);
  }
  if (state !== "attempt_saved") fail("release_open");
  const requestId = fact(aggregate, "request_id");
  let response;
  if (!justSaved) {
    response = await requestProvider("GET", `/v1/tickets/${encodeURIComponent(requestId)}`);
    if (response.status === 200) {
      if (!matchesTicket(response.data, aggregate)) fail("conflict");
      crashAt("after-accept-before-record");
      aggregate = await commitTicket(aggregate, response.data.ticket_id);
      crashAt("after-record-before-exit");
      return holdResult(aggregate);
    }
    if (response.status !== 404) fail("unavailable");
  }
  response = await requestProvider("POST", "/v1/tickets", {
    request_id: requestId,
    hold_id: aggregate.id,
    section_id: fact(aggregate, "section_id"),
    seat_ids: seatIdsOf(aggregate),
  });
  if (response.status === 409 || (response.status === 200 && !matchesTicket(response.data, aggregate))) fail("conflict");
  if (response.status !== 200) fail("unavailable");
  crashAt("after-accept-before-record");
  aggregate = await commitTicket(aggregate, response.data.ticket_id);
  crashAt("after-record-before-exit");
  return holdResult(aggregate);
}

async function releaseCommand(holdId, requestedSeats) {
  const now = nowMs();
  const sections = await loadSections();
  const { machine: machineApi, legacy } = await machine();
  let aggregate = await findHold(machineApi, holdId, legacy);
  aggregate = await expireForUse(aggregate, sections, now);
  const state = stateName(aggregate);
  if (requestedSeats === null) {
    if (state === "released" || state === "expired") return holdResult(aggregate);
    if (state !== "held") fail("release_open");
    if (isLegacyAggregate(aggregate)) aggregate = await aggregate.command("release");
    else aggregate = await aggregate.command("release", { seat_ids: encodeSeats([]) });
    await saveSections(sections);
    return holdResult(aggregate);
  }
  const allSeats = allSeatIdsOf(aggregate);
  const currentSeats = seatIdsOf(aggregate);
  for (const seat of requestedSeats) {
    if (!allSeats.includes(seat)) fail("unknown_seat");
    if (!currentSeats.includes(seat)) fail("already_released");
  }
  if (state !== "held") fail(state === "attempt_saved" || state === "ticketed" ? "release_open" : "already_released");
  if (requestedSeats.length === currentSeats.length) fail("bad_args");
  const remaining = currentSeats.filter((seat) => !requestedSeats.includes(seat));
  aggregate = await aggregate.command("release_selected", { seat_ids: encodeSeats(remaining) });
  await saveSections(sections);
  return holdResult(aggregate);
}

async function expireCommand(holdId) {
  const now = nowMs();
  const sections = await loadSections();
  const { machine: machineApi, legacy } = await machine();
  const aggregate = await findHold(machineApi, holdId, legacy);
  const state = stateName(aggregate);
  if (state === "released" || state === "expired") return holdResult(aggregate);
  if (state !== "held") fail("release_open");
  if (now < deadlineOf(aggregate)) fail("not_due");
  const next = await aggregate.command("expire");
  await saveSections(sections);
  return holdResult(next);
}

async function statusCommand(holdId) {
  const now = nowMs();
  const sections = await loadSections();
  const { machine: machineApi, legacy } = await machine();
  const aggregate = await findHold(machineApi, holdId, legacy);
  const next = await expireForUse(aggregate, sections, now);
  return holdResult(next);
}

async function reconcileCommand(holdId) {
  const sections = await loadSections();
  const { machine: machineApi, legacy } = await machine();
  const aggregate = await findHold(machineApi, holdId, legacy);
  const state = stateName(aggregate);
  if (state === "ticketed") return { ...holdResult(aggregate), outcome: "ticketed" };
  if (state !== "attempt_saved") return { outcome: "not_applicable" };
  const response = await requestProvider("GET", `/v1/tickets/${encodeURIComponent(fact(aggregate, "request_id"))}`);
  if (response.status === 404) return { outcome: "not_sent" };
  if (response.status !== 200) fail("unavailable");
  if (!matchesTicket(response.data, aggregate)) fail("conflict");
  const next = await commitTicket(aggregate, response.data.ticket_id);
  return { ...holdResult(next), outcome: "ticketed" };
}

function requireArity(args, count) { if (args.length !== count) fail("bad_args"); }
function validateId(value) { if (!isId(value)) fail("bad_id"); return value; }
function validateSeat(value) { if (!isSeat(value)) fail("bad_id"); return value; }
function validateSeatList(values) {
  if (values.length === 0) fail("bad_args");
  const seats = values.map(validateSeat);
  if (new Set(seats).size !== seats.length) fail("bad_args");
  return seats.sort();
}

async function dispatch(args) {
  const command = args[0];
  switch (command) {
    case "section":
      requireArity(args, 3); return sectionCommand(validateId(args[1]), parseCapacity(args[2]));
    case "section-status":
      requireArity(args, 2); return sectionStatus(validateId(args[1]));
    case "hold": {
      if (args.length < 5) fail("bad_args");
      const seats = validateSeatList(args.slice(3, -1));
      return holdCommand(validateId(args[1]), validateId(args[2]), seats, parseDeadline(args[args.length - 1]));
    }
    case "issue":
      requireArity(args, 2); return issueCommand(validateId(args[1]));
    case "release": {
      if (args.length < 2) fail("bad_args");
      const seats = args.length === 2 ? null : validateSeatList(args.slice(2));
      return releaseCommand(validateId(args[1]), seats);
    }
    case "expire":
      requireArity(args, 2); return expireCommand(validateId(args[1]));
    case "status":
      requireArity(args, 2); return statusCommand(validateId(args[1]));
    case "reconcile":
      requireArity(args, 2); return reconcileCommand(validateId(args[1]));
    default: fail("bad_args");
  }
}

try {
  const result = await dispatch(process.argv.slice(2));
  process.stdout.write(`${JSON.stringify(jsonSafe(result))}\n`);
  process.exitCode = 0;
} catch (error) {
  const code = error instanceof Refusal ? error.code : (error?.code === "IK_ILLEGAL_STATE" ? "unknown_hold" : "unavailable");
  process.stdout.write(`${JSON.stringify({ error: code })}\n`);
  process.exitCode = 1;
}
