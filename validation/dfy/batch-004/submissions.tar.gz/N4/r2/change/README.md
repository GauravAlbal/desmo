# Conference seat-hold desk

This is a single-process local desk for named conference seats. A hold may
reserve one or more seats; partial release is available while a group remains
held. Hold lifecycle transitions are persisted by the Ikaros
`conference_seat_hold` machine in `lifecycle.sqlite`; section capacity/index data
is stored in `sections.json`. The application never writes files it does not own
in `STATE_DIR`. New holds use machine version 2; existing version 1 single-seat
holds are routed through `desk.v1.ik.toml` and remain usable.

## Setup

Node 22 is required. From this directory:

```sh
<home>/.nvm/versions/node/v22.17.1/bin/npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

`npm install` may be replaced by the equivalent Node 22/npm command on another
machine with the two supplied tarballs. No registry access is needed.

## Running

`./run` prints exactly one JSON object. Set `STATE_DIR` to the durable state
directory, and set `NOW_MS` for commands that use the clock. `SERVICE_URL` is
needed by `issue` and `reconcile` when they contact the provider.

```sh
export STATE_DIR="$PWD/.state"
export SERVICE_URL="http://127.0.0.1:PORT"
./run section hall-a 3
NOW_MS=500 ./run hold h1 hall-a A1 A2 5000
NOW_MS=500 ./run release h1 A1
NOW_MS=500 ./run issue h1
NOW_MS=500 ./run status h1
NOW_MS=500 ./run reconcile h1
```

The supplied provider can be started with `node stub/server.mjs`; it prints the
service and control URLs as one JSON line. Its service data plane is the only
HTTP API used by the desk.

Commands are `section`, `hold`, `issue`, `release`, `expire`, `status`,
`section-status`, and `reconcile`, with the argument forms in `BRIEF.md`.
Refusals print `{"error":"..."}` and exit nonzero. A saved issuance attempt
is always reconciled by lookup before a later request; no second request id is
allocated.

## Tests

The deterministic integration test starts the supplied stub, exercises process
restart behavior, single- and multi-seat holds, partial release, seat/capacity
refusals, all three crash boundaries, and a dropped provider reply:

```sh
<home>/.nvm/versions/node/v22.17.1/bin/npm test
```

The stub intentionally uses an ephemeral loopback port. Production/provider
ports are supplied through `SERVICE_URL`.
