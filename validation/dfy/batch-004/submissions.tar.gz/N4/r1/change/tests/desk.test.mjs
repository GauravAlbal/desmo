import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm, writeFile, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";

const ROOT = path.resolve(new URL("..", import.meta.url).pathname);
const NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node";

function invoke(state, service, args, extra = {}) {
  const result = spawnSync(path.join(ROOT, "run"), args, {
    cwd: ROOT,
    encoding: "utf8",
    env: { ...process.env, STATE_DIR: state, SERVICE_URL: service, ...extra },
  });
  const lines = result.stdout.trim().split("\n").filter(Boolean);
  assert.equal(lines.length, result.stdout.trim() ? 1 : 0, `stdout=${result.stdout} stderr=${result.stderr}`);
  return { ...result, json: lines.length ? JSON.parse(lines[0]) : null };
}

async function startStub() {
  const child = spawn(NODE, ["stub/server.mjs"], { cwd: ROOT, stdio: ["ignore", "pipe", "pipe"] });
  let buffer = "";
  const info = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("provider did not start")), 5000);
    child.stdout.on("data", (chunk) => {
      buffer += chunk;
      const line = buffer.split("\n")[0];
      if (!line) return;
      clearTimeout(timer);
      resolve(JSON.parse(line));
    });
    child.once("error", reject);
  });
  return { child, ...info };
}

async function control(url, body) {
  const response = await fetch(`${url}/fault`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  assert.equal(response.status, 200);
}

async function effects(url) {
  return await (await fetch(`${url}/effects`)).json();
}

function makeHold(state, service, id, seat, deadline = 5000) {
  assert.equal(invoke(state, service, ["hold", id, "hall-a", seat, String(deadline)], { NOW_MS: "100" }).json.state, "held");
}

 test("desk survives restart and resolves all uncertain boundaries", async (t) => {
  const state = await mkdtemp(path.join(tmpdir(), "desk-test-"));
  const stub = await startStub();
  t.after(async () => {
    await rm(state, { recursive: true, force: true });
    stub.child.kill("SIGTERM");
  });
  const service = stub.service_url;
  const controlUrl = stub.control_url;

  assert.deepEqual(invoke(state, service, ["section", "hall-a", "5"]).json, { section_id: "hall-a", capacity: 5, held: 0, available: 5 });
  makeHold(state, service, "h1", "A1");
  assert.equal(invoke(state, service, ["hold", "h1", "hall-a", "A1", "5000"], { NOW_MS: "100" }).json.state, "held");
  assert.equal(invoke(state, service, ["issue", "h1"], { NOW_MS: "100" }).json.state, "ticketed");
  assert.equal(invoke(state, service, ["release", "h1"], { NOW_MS: "100" }).json.error, "release_open");
  const beforeRepeat = await effects(controlUrl);
  assert.equal(beforeRepeat.count, 1);
  assert.equal(invoke(state, service, ["issue", "h1"], { NOW_MS: "100" }).json.state, "ticketed");
  assert.equal((await effects(controlUrl)).count, 1);

  makeHold(state, service, "pre", "A2");
  const preCrash = invoke(state, service, ["issue", "pre"], { NOW_MS: "100", CRASH_AT: "after-hold-saved-before-request" });
  assert.equal(preCrash.signal, "SIGKILL");
  assert.deepEqual(invoke(state, service, ["reconcile", "pre"], { NOW_MS: "100" }).json, { outcome: "not_sent" });
  assert.equal((await effects(controlUrl)).count, 1);
  assert.equal(invoke(state, service, ["issue", "pre"], { NOW_MS: "100" }).json.state, "ticketed");
  assert.equal((await effects(controlUrl)).count, 2);

  makeHold(state, service, "accept", "A3");
  const acceptCrash = invoke(state, service, ["issue", "accept"], { NOW_MS: "100", CRASH_AT: "after-accept-before-record" });
  assert.equal(acceptCrash.signal, "SIGKILL");
  const accepted = invoke(state, service, ["reconcile", "accept"], { NOW_MS: "100" }).json;
  assert.equal(accepted.outcome, "ticketed");
  assert.equal(accepted.state, "ticketed");
  assert.equal((await effects(controlUrl)).count, 3);

  makeHold(state, service, "record", "A4");
  const recordCrash = invoke(state, service, ["issue", "record"], { NOW_MS: "100", CRASH_AT: "after-record-before-exit" });
  assert.equal(recordCrash.signal, "SIGKILL");
  assert.equal(invoke(state, service, ["status", "record"], { NOW_MS: "100" }).json.state, "ticketed");
  assert.equal((await effects(controlUrl)).count, 4);

  await control(controlUrl, { drop_reply: true });
  makeHold(state, service, "drop", "B1");
  const dropped = invoke(state, service, ["issue", "drop"], { NOW_MS: "100" });
  assert.equal(dropped.json.error, "unavailable");
  await control(controlUrl, { drop_reply: false });
  const recovered = invoke(state, service, ["reconcile", "drop"], { NOW_MS: "100" }).json;
  assert.equal(recovered.outcome, "ticketed");
  assert.notEqual(recovered.outcome, "not_sent");
  assert.equal((await effects(controlUrl)).count, 5);

  assert.equal(invoke(state, service, ["section-status", "hall-a"]).json.held, 5);
});

test("local invariants and refusals do not call provider or damage neighbors", async (t) => {
  const state = await mkdtemp(path.join(tmpdir(), "desk-refusal-"));
  const stub = await startStub();
  t.after(async () => {
    await rm(state, { recursive: true, force: true });
    stub.child.kill("SIGTERM");
  });
  const service = stub.service_url;
  const controlUrl = stub.control_url;
  const unrelated = path.join(state, "other-writer.bin");
  await writeFile(unrelated, Buffer.from([0, 1, 2, 3, 255]));

  assert.equal(invoke(state, service, ["section", "hall-a", "1"]).json.available, 1);
  assert.equal(invoke(state, service, ["section", "hall-a", "1"]).json.available, 1);
  assert.equal(invoke(state, service, ["section", "hall-a", "2"]).json.error, "conflict");
  makeHold(state, service, "a", "A1");
  assert.equal(invoke(state, service, ["hold", "b", "hall-a", "A1", "5000"], { NOW_MS: "100" }).json.error, "seat_taken");
  assert.equal(invoke(state, service, ["hold", "c", "hall-a", "C1", "5000"], { NOW_MS: "100" }).json.error, "capacity_exceeded");
  assert.equal((await effects(controlUrl)).count, 0);

  assert.equal(invoke(state, service, ["release", "a"], { NOW_MS: "100" }).json.state, "released");
  makeHold(state, service, "b", "A1");
  assert.equal(invoke(state, service, ["expire", "b"], { NOW_MS: "99" }).json.error, "not_due");
  assert.equal(invoke(state, service, ["release", "b"], { NOW_MS: "100" }).json.state, "released");
  makeHold(state, service, "due", "A1", 100);
  assert.equal(invoke(state, service, ["status", "due"], { NOW_MS: "100" }).json.state, "expired");
  assert.equal(invoke(state, service, ["issue", "due"], { NOW_MS: "100" }).json.error, "expired");
  assert.equal(invoke(state, service, ["status", "missing"], { NOW_MS: "100" }).json.error, "unknown_hold");
  assert.equal(invoke(state, service, ["section-status", "missing"]).json.error, "unknown_section");
  assert.equal(invoke(state, service, ["section", "bad/id", "1"]).json.error, "bad_id");
  assert.deepEqual(await readFile(unrelated), Buffer.from([0, 1, 2, 3, 255]));
});
 
test("group holds reserve, partially release atomically, and issue the remaining list once", async (t) => {
  const state = await mkdtemp(path.join(tmpdir(), "desk-group-"));
  const stub = await startStub();
  t.after(async () => {
    await rm(state, { recursive: true, force: true });
    stub.child.kill("SIGTERM");
  });
  const service = stub.service_url;
  const controlUrl = stub.control_url;

  assert.deepEqual(invoke(state, service, ["section", "hall-a", "3"]).json, {
    section_id: "hall-a", capacity: 3, held: 0, available: 3,
  });
  assert.deepEqual(
    invoke(state, service, ["hold", "g1", "hall-a", "A2", "A1", "5000"], { NOW_MS: "100" }).json,
    { hold_id: "g1", section_id: "hall-a", seat_ids: ["A1", "A2"], deadline_ms: 5000, state: "held", request_id: null, ticket_id: null },
  );
  assert.equal(invoke(state, service, ["hold", "collision", "hall-a", "A2", "A3", "5000"], { NOW_MS: "100" }).json.error, "seat_taken");
  assert.deepEqual(invoke(state, service, ["section-status", "hall-a"], { NOW_MS: "100" }).json, {
    section_id: "hall-a", capacity: 3, held: 2, available: 1,
  });
  assert.equal(invoke(state, service, ["release", "g1", "A9"], { NOW_MS: "100" }).json.error, "unknown_seat");
  assert.equal(invoke(state, service, ["release", "g1", "A1", "A2"], { NOW_MS: "100" }).json.error, "bad_args");
  assert.deepEqual(invoke(state, service, ["status", "g1"], { NOW_MS: "100" }).json.seat_ids, ["A1", "A2"]);
  assert.deepEqual(invoke(state, service, ["release", "g1", "A1"], { NOW_MS: "100" }).json.seat_ids, ["A2"]);
  assert.equal(invoke(state, service, ["release", "g1", "A1"], { NOW_MS: "100" }).json.error, "already_released");
  assert.deepEqual(invoke(state, service, ["hold", "freed", "hall-a", "A1", "A3", "5000"], { NOW_MS: "100" }).json.seat_ids, ["A1", "A3"]);
  assert.deepEqual(invoke(state, service, ["issue", "g1"], { NOW_MS: "100" }).json.seat_ids, ["A2"]);
  const effect = await effects(controlUrl);
  assert.equal(effect.count, 1);
  assert.deepEqual(effect.effects[0].seat_ids, ["A2"]);
  assert.equal(invoke(state, service, ["issue", "g1"], { NOW_MS: "100" }).json.state, "ticketed");
  assert.equal((await effects(controlUrl)).count, 1);
});

test("a mismatching group response stays open and recovery adopts the complete provider list", async (t) => {
  const state = await mkdtemp(path.join(tmpdir(), "desk-group-mismatch-"));
  const stub = await startStub();
  t.after(async () => {
    await rm(state, { recursive: true, force: true });
    stub.child.kill("SIGTERM");
  });
  const service = stub.service_url;
  const controlUrl = stub.control_url;

  await control(controlUrl, { mismatch: true });
  invoke(state, service, ["section", "hall-a", "4"]);
  invoke(state, service, ["hold", "g1", "hall-a", "A1", "A2", "5000"], { NOW_MS: "100" });
  assert.equal(invoke(state, service, ["issue", "g1"], { NOW_MS: "100" }).json.error, "conflict");
  assert.equal(invoke(state, service, ["status", "g1"], { NOW_MS: "100" }).json.state, "attempt_saved");
  assert.equal((await effects(controlUrl)).count, 1);
  await control(controlUrl, { mismatch: false });
  const recovered = invoke(state, service, ["reconcile", "g1"], { NOW_MS: "100" }).json;
  assert.equal(recovered.outcome, "ticketed");
  assert.deepEqual(recovered.seat_ids, ["A1", "A2"]);
  assert.equal((await effects(controlUrl)).count, 1);
});
