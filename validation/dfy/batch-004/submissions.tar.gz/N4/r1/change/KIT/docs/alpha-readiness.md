# Scoped public alpha: readiness status

A status ledger for the scoped-alpha work packages. Evidence classes are kept apart: **accepted** = merged through
the repository acceptance gate; **executed** = a command/run was actually performed and its output observed;
**gap** = not done, with the reason. Nothing here is a publication, a proof, or a claim beyond the stated
topology (`docs/alpha-contract.md`).

| WP | Status | Evidence | Open gap |
|---|---|---|---|
| IK-00 contract and baseline | accepted | `docs/alpha-contract.md`, `validation/ik00/` | owner sign-off of the scope text |
| IK-01 valid genesis | accepted | `tests/genesis_validity.rs` | native machines must opt in to `validate_initial` |
| IK-02 operation identity | accepted | `docs/operation-identity.md` | none |
| IK-03 durable operation attribution | accepted | `tests/operation_attribution.rs`; three attribution mutants killed | none known |
| IK-04 client recovery | accepted | Python/TypeScript/Go operation tests, `docs/client-recovery.md` | client walls have no deleted-wall (mutation) control |
| IK-05 evidence honesty | accepted | `ik check --release`, `tests/release_evidence.rs`, trace v2 | none |
| IK-06 qualification manifest | accepted + executed | `validation/ik06/` (rows run, self-test, strict mutant firing) | independent review performed by a separate agent; findings closed (see `validation/ik06/SELF_REVIEW.md`); not examined: Linux, Hegel, hostile or multi-replica use |
| IK-07 contention | accepted + executed | `validation/ik07/`, `docs/execution-envelope.md` | macOS arm64 only; Linux not measured |
| IK-08 TypeScript contracts | accepted | `ik schema`, `ikaros codegen`, `typescript/src/codegen.test.ts` | none |
| IK-09 approval example | accepted + executed | `examples/publish-approval/`, `python/tests/test_publish_approval_app.py` | none for the stated claims; external execution is at-least-once, not exactly-once |
| IK-10 consumer qualification | **partial, executed in scratch** | one source break found and fixed; both native consumers compile; differential host tests identical to the released pin | not a consumer acceptance receipt: no consumer-side acceptance contract, no live host run, no pin move, unpublished bytes. Needs an owner decision on which lifecycle is the qualified one |
| IK-11 artifacts | **partial** | `0.5.0` identifiers, `scripts/pack_npm.py`, `scripts/qualify_artifacts.py`; host-target pack + installed-artifact run and previous-release store compatibility (see below) | **Linux x64 not qualified**; Linux aarch64 source test suite and packaged-artifact qualification pass in a container (`validation/linux/`); x64 and the release script on Linux not run; nothing published; license texts absent (owner) |
| IK-12 public source candidate | **tooling accepted; owner gates open** | `scripts/public_export.py`, `export/allowlist.json`, clean-export verification (`validation/ik12/export-run.md`) | disclosure/licensing authority, license files, branding, consumer naming, security channel, history policy: `docs/public-release-checklist.md` |
| IK-13 cold runs | agent run executed; human run open | `docs/cold-run-protocol.md`, `validation/ik13/cold-run-agent.md` | 7/7 tasks done by an agent with honor-system isolation; no human run |
| IK-14 maintenance comparison | greenfield tranche 1 executed, 2 replicas (descriptive) | `validation/ik14/greenfield/` (contract, evaluators validated on defect controls, results.jsonl, decision.md); prepared-fixture pilot in `validation/ik14/pilot/` | ordinary stack 6/6 and Ikaros arm 4/6 complete trajectories (both Ikaros-arm failures on one project, different requirements); no comparative claim; source review and new-brief replication open |
| IK-15 launch film | **not started** | observed and bounded-witness trace bundles from `examples/publish-approval/scenarios.py` render to HTML with `ikaros trace` | no film, no silent-comprehension check; depends on released artifacts (IK-11) |
| IK-16 publication and cohort | **not started (owner-only)** | none | repository visibility, registry publication, `LATEST_RELEASE` update and the adoption cohort are owner-authorized actions |

## Lifecycle workbench and agent-DFY goal (separate from the alpha table)

Three levels stay apart: **EngineeringReady**, **DFYJourneyQualified**, **PublicReleaseReady**. None below has moved a human, Linux, consumer, or publication gate.

| Package | Status | Open gap |
|---|---|---|
| X00-X07 workbench (`ik check --profile`, `scenario`, `analysis`, `graph export`, `report`, `regression`, `profile diff`, `evidence verify`) | accepted + executed; TLC adapter run against real TLC 2.19 | Hegel evidence is sampled; no human use |
| X08 adapter starter and conformance | accepted; independent extension exercise executed once (`validation/x08/`): conformance exit 0 on a new question, re-run by the orchestrator. P route prepared and **unqualified** (no dotnet/P here) | one attempt, one model family; conformance does not test checker correctness |
| X09 packaged journey and blind usability | executed for tasks 3, 4, 5, 7 plus the X08 exercise, single attempts (`validation/x09/`) | tasks 1 and 2 not run in that form; one model family; not human review |
| D0-D2 design, skill, client helpers | accepted | the independent plan-review pass for plan-shaped work was not run; a causal audit was substituted |
| D3 BUILD | executed: 6/6 cold builds passed 14/14 on three new families (`validation/dfy/`) | one attempt each; no claim about rates; installed-artifact journey and handoff review not fully qualified |
| D4 CHANGE | executed twice on the dfy-001 builds: agents without code execution 4/6 evaluator-complete; agents with a shell 5/6 (`validation/dfy/decision.md`) | N3 r2 failed C2/C3 under both models; different model family from the build stage; the evaluator does not score stale scenarios or old-store continuity |
| D5 DIAGNOSE/RECOVER | executed: 14/18 first-pass evaluator passes; guide patched; the 4 failed cases re-run 4/4 as a regression track (`validation/dfy/decision.md`) | regression only, one rerun each, not blind; 8 of 18 first-pass runs had an orchestrator message after harness gaps |
| D6 `ik handoff` | accepted | no human readability evaluation |
| D7 specialist routing | skill text accepted with this change | not exercised by a cold agent |
| D8 audits, readiness | **open**: a regression batch (`validation/dfy/batch-002/`: build 4/6, change 4/6, diagnose 17/18) and a blind batch on fresh families (`validation/dfy/batch-003/`: build 5/6, change 5/6, diagnose 16/18 after a brief fix and rerun) | mandatory requirements do not all pass; evaluator defects were found and fixed during the blind batch, so it is not a zero-fix instrument; configuration not identical across runs; two authority-negative controls ran, the rest and the A3 audits did not; audit status by stage in `validation/dfy/audits.md` (A1 to A3 partial, A4 not met) |

## Release decision

- **Quiet public alpha** needs IK-00 through IK-13 plus IK-16's release checks. Currently blocked by: a human
  review of IK-06, IK-10 consumer acceptance, IK-11 Linux qualification, IK-12 owner decisions, IK-13 human runs.
- **Promoted launch** additionally needs IK-15. **Comparative superiority language** needs IK-14.

## What the host-target artifact run established (macOS arm64)

See `validation/ik11/artifact-run.md` for the commands, digests and results. It qualifies only the bytes it
names, on that host, from a local stand-in for the owner-created public commit.
