#!/usr/bin/env node
import { promises as fs } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomUUID } from "node:crypto";
import { Kernel, StoreNotFoundError } from "@ikaros/runtime";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const MACHINE = path.join(ROOT, "hold.ik.toml");
const stateDir = process.env.STATE_DIR;
const serviceUrl = process.env.SERVICE_URL;
const nowRaw = process.env.NOW_MS;
const crashAt = process.env.CRASH_AT;
const MAX_SAFE = Number.MAX_SAFE_INTEGER;

class Refusal extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
}

const idPattern = /^[A-Za-z0-9._-]{1,64}$/;
const seatPattern = /^[A-Za-z0-9._-]{1,32}$/;
const decimal = /^(0|[1-9][0-9]*)$/;

function parseId(value, code = "bad_id") {
  if (typeof value !== "string" || !idPattern.test(value)) throw new Refusal(code);
  return value;
}

function parseSeat(value) {
  if (typeof value !== "string" || !seatPattern.test(value)) throw new Refusal("bad_id");
  return value;
}

function parseBoundedInt(value, code, max = MAX_SAFE) {
  if (typeof value !== "string" || !decimal.test(value)) throw new Refusal(code);
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n < 0 || n > max) throw new Refusal(code);
  return n;
}

function requireNow() {
  return parseBoundedInt(nowRaw, "bad_args");
}

function requireStateDir() {
  if (!stateDir) throw new Refusal("unavailable");
  return stateDir;
}

function file(name) {
  return path.join(requireStateDir(), name);
}

async function readJson(name, fallback) {
  try {
    return JSON.parse(await fs.readFile(file(name), "utf8"));
  } catch (error) {
    if (error?.code === "ENOENT") return fallback;
    throw new Refusal("unavailable");
  }
}

async function writeJson(name, value) {
  const target = file(name);
  const temporary = `${target}.tmp-${process.pid}-${randomUUID()}`;
  try {
    await fs.writeFile(temporary, JSON.stringify(value), { mode: 0o600 });
    await fs.rename(temporary, target);
  } catch (error) {
    await fs.rm(temporary, { force: true }).catch(() => {});
    throw new Refusal("unavailable");
  }
}

async function readSections() {
  const value = await readJson(".desk-sections.json", { sections: {} });
  if (!value || typeof value !== "object" || !value.sections || typeof value.sections !== "object") {
    throw new Refusal("unavailable");
  }
  return value.sections;
}

async function readIndex() {
  const value = await readJson(".desk-index.json", { holds: [] });
  if (!value || !Array.isArray(value.holds)) throw new Refusal("unavailable");
  return value.holds;
}

async function saveIndex(holds) {
  await writeJson(".desk-index.json", { holds: [...new Set(holds)] });
}

// The machine's original seat_id fact is deliberately retained so stores made
// by the previous version keep their identity. New groups encode their full
// canonical list in that string; this sidecar only records later partial trims.
async function readSeatOverrides() {
  const value = await readJson(".desk-seat-overrides.json", { holds: {} });
  if (!value || typeof value !== "object" || !value.holds || typeof value.holds !== "object") {
    throw new Refusal("unavailable");
  }
  for (const seats of Object.values(value.holds)) {
    if (!Array.isArray(seats) || seats.some((seat) => typeof seat !== "string" || !seatPattern.test(seat))) {
      throw new Refusal("unavailable");
    }
  }
  return value.holds;
}

async function saveSeatOverrides(holds) {
  await writeJson(".desk-seat-overrides.json", { holds });
}

async function openMachine() {
  const dir = requireStateDir();
  await fs.mkdir(dir, { recursive: true });
  const kernel = new Kernel(path.join(dir, "holds.sqlite"));
  const machine = await kernel.machine(MACHINE);
  return { kernel, machine };
}

function factsOf(aggregate) {
  const candidates = [
    aggregate?.state,
    aggregate?.state?.facts,
    aggregate?.raw?.state,
    aggregate?.raw?.state?.facts,
    aggregate?.raw?.facts,
  ];
  for (const value of candidates) {
    if (value && typeof value === "object" && !Array.isArray(value)) return value;
  }
  return {};
}

function encodedSeats(aggregate) {
  const raw = factsOf(aggregate).seat_id;
  if (typeof raw !== "string") return [];
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0 && parsed.every((seat) => typeof seat === "string")) {
      return parsed;
    }
  } catch {
    // A one-seat hold from the old machine stores the plain seat id.
  }
  return [raw];
}

function asNumber(value) {
  if (typeof value === "bigint") return Number(value);
  return Number(value);
}

function holdObject(holdId, aggregate, overrides = undefined) {
  const facts = factsOf(aggregate);
  const original = encodedSeats(aggregate);
  const seats = Array.isArray(overrides?.[holdId]) && overrides[holdId].length > 0
    ? overrides[holdId]
    : original;
  return {
    hold_id: holdId,
    section_id: String(facts.section_id ?? ""),
    seat_ids: seats,
    deadline_ms: asNumber(facts.deadline_ms),
    state: aggregate.namedState(),
    request_id: facts.request_id ? String(facts.request_id) : null,
    ticket_id: facts.ticket_id ? String(facts.ticket_id) : null,
  };
}

function activeState(state) {
  return state === "held" || state === "attempt_saved" || state === "ticketed";
}

function mapKernel(error, fallback = "unavailable") {
  if (error instanceof Refusal) throw error;
  if (error instanceof StoreNotFoundError || error?.rule === "store.missing" || error?.rule === "aggregate.not_found") {
    throw new Refusal("unknown_hold");
  }
  throw new Refusal(fallback);
}

async function showHold(machine, holdId) {
  try {
    return await machine.show(holdId);
  } catch (error) {
    mapKernel(error, "unknown_hold");
  }
}

async function tryShowHold(machine, holdId) {
  try {
    return await machine.show(holdId);
  } catch (error) {
    if (error instanceof StoreNotFoundError || error?.rule === "store.missing" || error?.rule === "aggregate.not_found") return null;
    mapKernel(error);
  }
}

async function command(aggregate, name, args) {
  try {
    return await aggregate.command(name, args);
  } catch (error) {
    mapKernel(error);
  }
}

function checkCrash(boundary) {
  if (crashAt === boundary) process.kill(process.pid, "SIGKILL");
}

function baseUrl() {
  if (typeof serviceUrl !== "string" || serviceUrl.length === 0) throw new Refusal("unavailable");
  return serviceUrl.replace(/\/+$/, "");
}

async function provider(method, requestPath, body) {
  let response;
  try {
    response = await fetch(`${baseUrl()}${requestPath}`, {
      method,
      headers: body === undefined ? undefined : { "content-type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const text = await response.text();
    let parsed;
    try { parsed = JSON.parse(text); } catch { parsed = null; }
    return { status: response.status, body: parsed };
  } catch {
    throw new Refusal("unavailable");
  }
}

function sameSeats(a, b) {
  if (!Array.isArray(a) || a.length !== b.length) return false;
  const left = [...a].map(String).sort();
  const right = [...b].map(String).sort();
  return left.every((seat, index) => seat === right[index]);
}

function matchingProviderResult(body, requestId, hold) {
  return body && body.request_id === requestId && body.hold_id === hold.hold_id && body.section_id === hold.section_id
    && sameSeats(body.seat_ids, hold.seat_ids) && typeof body.ticket_id === "string" && body.outcome === "ticketed";
}

async function lookupProvider(requestId, hold) {
  const result = await provider("GET", `/v1/tickets/${encodeURIComponent(requestId)}`);
  if (result.status === 404) return { kind: "not_sent" };
  if (result.status !== 200) throw new Refusal("unavailable");
  if (!matchingProviderResult(result.body, requestId, hold)) throw new Refusal("conflict");
  return { kind: "ticketed", ticketId: result.body.ticket_id };
}

async function postProvider(requestId, hold) {
  const result = await provider("POST", "/v1/tickets", {
    request_id: requestId,
    hold_id: hold.hold_id,
    section_id: hold.section_id,
    seat_ids: hold.seat_ids,
  });
  if (result.status !== 200) throw new Refusal("unavailable");
  if (!matchingProviderResult(result.body, requestId, hold)) throw new Refusal("conflict");
  return result.body.ticket_id;
}

async function commitTicket(machine, aggregate, hold, ticketId, overrides) {
  const updated = await command(aggregate, "accept", { ticket_id: ticketId });
  checkCrash("after-record-before-exit");
  return holdObject(hold.hold_id, updated, overrides);
}

async function expireObserved(machine, aggregate, hold, now, overrides) {
  if (hold.state === "held" && now >= hold.deadline_ms) {
    const expired = await command(aggregate, "expire", { now_ms: now });
    return { aggregate: expired, hold: holdObject(hold.hold_id, expired, overrides) };
  }
  return { aggregate, hold };
}

async function indexAndHold(holdId, sectionId, seatIds, deadlineMs) {
  const now = requireNow();
  const sections = await readSections();
  const section = sections[sectionId];
  if (!section) throw new Refusal("unknown_section");
  const overrides = await readSeatOverrides();
  const { machine } = await openMachine();
  const existing = await tryShowHold(machine, holdId);
  if (existing) {
    const originalSeats = encodedSeats(existing);
    let prior = holdObject(holdId, existing, overrides);
    if (prior.state === "held" && now >= prior.deadline_ms) {
      const expired = await command(existing, "expire", { now_ms: now });
      prior = holdObject(holdId, expired, overrides);
    }
    if (prior.section_id !== sectionId || !sameSeats(originalSeats, seatIds) || prior.deadline_ms !== deadlineMs) {
      throw new Refusal("conflict");
    }
    const ids = await readIndex();
    if (!ids.includes(holdId)) await saveIndex([...ids, holdId]);
    return prior;
  }
  const ids = await readIndex();
  const live = [];
  const retained = [];
  for (const id of ids) {
    const aggregate = await tryShowHold(machine, id);
    if (!aggregate) continue;
    let value = holdObject(id, aggregate, overrides);
    if (value.state === "held" && now >= value.deadline_ms) {
      const expired = await command(aggregate, "expire", { now_ms: now });
      value = holdObject(id, expired, overrides);
    }
    retained.push(id);
    if (value.section_id === sectionId && activeState(value.state)) live.push(value);
  }
  if (live.some((value) => value.seat_ids.some((seat) => seatIds.includes(seat)))) throw new Refusal("seat_taken");
  if (live.reduce((total, value) => total + value.seat_ids.length, 0) + seatIds.length > Number(section.capacity)) {
    throw new Refusal("capacity_exceeded");
  }
  await saveIndex([...retained, holdId]);
  let created;
  try {
    created = await machine.createWith({
      aggregateId: holdId,
      command: {
        name: "initialize",
        args: { section_id: sectionId, seat_id: JSON.stringify(seatIds), deadline_ms: deadlineMs },
      },
    });
  } catch (error) {
    if (error?.rule === "aggregate.exists") throw new Refusal("conflict");
    mapKernel(error);
  }
  if (!created || typeof created.namedState !== "function") throw new Refusal("unavailable");
  return holdObject(holdId, created, overrides);
}

async function commandStatus(holdId) {
  const now = requireNow();
  const { machine } = await openMachine();
  const overrides = await readSeatOverrides();
  const aggregate = await showHold(machine, holdId);
  const current = holdObject(holdId, aggregate, overrides);
  const result = await expireObserved(machine, aggregate, current, now, overrides);
  return result.hold;
}

async function commandRelease(holdId, requestedSeats = null) {
  const now = requireNow();
  const { machine } = await openMachine();
  const overrides = await readSeatOverrides();
  let aggregate = await showHold(machine, holdId);
  let hold = holdObject(holdId, aggregate, overrides);
  const expired = await expireObserved(machine, aggregate, hold, now, overrides);
  aggregate = expired.aggregate;
  hold = expired.hold;
  if (requestedSeats === null) {
    if (hold.state === "released" || hold.state === "expired") return hold;
    if (hold.state !== "held") throw new Refusal("release_open");
    const released = await command(aggregate, "release");
    if (Object.prototype.hasOwnProperty.call(overrides, holdId)) {
      delete overrides[holdId];
      await saveSeatOverrides(overrides);
    }
    return holdObject(holdId, released, overrides);
  }
  if (hold.state === "attempt_saved" || hold.state === "ticketed") throw new Refusal("release_open");
  const original = encodedSeats(aggregate);
  if (hold.state === "released" || hold.state === "expired") {
    for (const seat of requestedSeats) {
      if (!original.includes(seat)) throw new Refusal("unknown_seat");
    }
    throw new Refusal("already_released");
  }
  if (hold.state !== "held") throw new Refusal("release_open");
  for (const seat of requestedSeats) {
    if (!original.includes(seat)) throw new Refusal("unknown_seat");
    if (!hold.seat_ids.includes(seat)) throw new Refusal("already_released");
  }
  if (requestedSeats.length >= hold.seat_ids.length) throw new Refusal("bad_args");
  const remaining = hold.seat_ids.filter((seat) => !requestedSeats.includes(seat));
  if (remaining.length === 0) throw new Refusal("bad_args");
  overrides[holdId] = remaining;
  await saveSeatOverrides(overrides);
  return holdObject(holdId, aggregate, overrides);
}

async function commandExpire(holdId) {
  const now = requireNow();
  const { machine } = await openMachine();
  const overrides = await readSeatOverrides();
  const aggregate = await showHold(machine, holdId);
  const hold = holdObject(holdId, aggregate, overrides);
  if (hold.state === "released" || hold.state === "expired") return hold;
  if (hold.state !== "held") throw new Refusal("release_open");
  if (now < hold.deadline_ms) throw new Refusal("not_due");
  const expired = await command(aggregate, "expire", { now_ms: now });
  return holdObject(holdId, expired, overrides);
}

async function commandIssue(holdId) {
  const now = requireNow();
  const { machine } = await openMachine();
  const overrides = await readSeatOverrides();
  let aggregate = await showHold(machine, holdId);
  let hold = holdObject(holdId, aggregate, overrides);
  const expired = await expireObserved(machine, aggregate, hold, now, overrides);
  aggregate = expired.aggregate;
  hold = expired.hold;
  if (hold.state === "expired") throw new Refusal("expired");
  if (hold.state === "released") throw new Refusal("released");
  if (hold.state === "ticketed") return hold;
  if (hold.state === "held") {
    const requestId = randomUUID();
    aggregate = await command(aggregate, "save_attempt", { request_id: requestId });
    hold = holdObject(holdId, aggregate, overrides);
    checkCrash("after-hold-saved-before-request");
  }
  if (hold.state !== "attempt_saved") throw new Refusal("release_open");
  const recovered = await lookupProvider(hold.request_id, hold);
  let ticketId;
  if (recovered.kind === "ticketed") {
    ticketId = recovered.ticketId;
  } else {
    ticketId = await postProvider(hold.request_id, hold);
    checkCrash("after-accept-before-record");
  }
  return await commitTicket(machine, aggregate, hold, ticketId, overrides);
}

async function commandReconcile(holdId) {
  const { machine } = await openMachine();
  const overrides = await readSeatOverrides();
  let aggregate = await showHold(machine, holdId);
  let hold = holdObject(holdId, aggregate, overrides);
  if (hold.state === "ticketed") return { outcome: "ticketed", ...hold };
  if (hold.state !== "attempt_saved") return { outcome: "not_applicable" };
  const recovered = await lookupProvider(hold.request_id, hold);
  if (recovered.kind === "not_sent") return { outcome: "not_sent" };
  const result = await commitTicket(machine, aggregate, hold, recovered.ticketId, overrides);
  return { outcome: "ticketed", ...result };
}

async function commandSection(sectionId, capacity) {
  await fs.mkdir(requireStateDir(), { recursive: true });
  const sections = await readSections();
  const existing = sections[sectionId];
  if (existing) {
    if (existing.capacity !== capacity) throw new Refusal("conflict");
  } else {
    sections[sectionId] = { section_id: sectionId, capacity };
    await writeJson(".desk-sections.json", { sections });
  }
  return await sectionStatus(sectionId, sections);
}

async function sectionStatus(sectionId, sections = undefined) {
  const allSections = sections ?? await readSections();
  const section = allSections[sectionId];
  if (!section) throw new Refusal("unknown_section");
  const { machine } = await openMachine();
  const overrides = await readSeatOverrides();
  const ids = await readIndex();
  const retained = [];
  let held = 0;
  const now = nowRaw === undefined ? null : requireNow();
  for (const id of ids) {
    const aggregate = await tryShowHold(machine, id);
    if (!aggregate) continue;
    let hold = holdObject(id, aggregate, overrides);
    if (now !== null && hold.state === "held" && now >= hold.deadline_ms) {
      const expired = await command(aggregate, "expire", { now_ms: now });
      hold = holdObject(id, expired, overrides);
    }
    retained.push(id);
    if (hold.section_id === sectionId && activeState(hold.state)) held += hold.seat_ids.length;
  }
  if (retained.length !== ids.length) await saveIndex(retained);
  return { section_id: sectionId, capacity: Number(section.capacity), held, available: Number(section.capacity) - held };
}

async function main() {
  const args = process.argv.slice(2);
  const op = args[0];
  if (!op) throw new Refusal("bad_args");
  let result;
  if (op === "section") {
    if (args.length !== 3) throw new Refusal("bad_args");
    const sectionId = parseId(args[1]);
    const capacity = parseBoundedInt(args[2], "bad_capacity", 100000);
    result = await commandSection(sectionId, capacity);
  } else if (op === "hold") {
    if (args.length < 5) throw new Refusal("bad_args");
    const holdId = parseId(args[1]);
    const sectionId = parseId(args[2]);
    const seatIds = args.slice(3, -1).map(parseSeat);
    if (seatIds.length === 0 || new Set(seatIds).size !== seatIds.length) throw new Refusal("bad_args");
    const deadline = parseBoundedInt(args.at(-1), "bad_deadline");
    result = await indexAndHold(holdId, sectionId, [...seatIds].sort(), deadline);
  } else if (op === "issue" || op === "expire" || op === "status" || op === "reconcile") {
    if (args.length !== 2) throw new Refusal("bad_args");
    const holdId = parseId(args[1]);
    if (op === "issue") result = await commandIssue(holdId);
    if (op === "expire") result = await commandExpire(holdId);
    if (op === "status") result = await commandStatus(holdId);
    if (op === "reconcile") result = await commandReconcile(holdId);
  } else if (op === "release") {
    if (args.length < 2) throw new Refusal("bad_args");
    const holdId = parseId(args[1]);
    const requested = args.length === 2 ? null : args.slice(2).map(parseSeat);
    if (requested !== null && (requested.length === 0 || new Set(requested).size !== requested.length)) throw new Refusal("bad_args");
    result = await commandRelease(holdId, requested);
  } else if (op === "section-status") {
    if (args.length !== 2) throw new Refusal("bad_args");
    result = await sectionStatus(parseId(args[1]));
  } else {
    throw new Refusal("bad_args");
  }
  process.stdout.write(`${JSON.stringify(result)}\n`);
}

try {
  await main();
} catch (error) {
  const code = error instanceof Refusal ? error.code : "unavailable";
  process.stdout.write(`${JSON.stringify({ error: code })}\n`);
  process.exitCode = 1;
}
