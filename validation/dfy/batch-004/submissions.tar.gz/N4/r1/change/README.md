# Conference seat-hold desk

This is a single-process local desk. Ikaros owns each hold's lifecycle and its
SQLite journal; the desk owns section metadata, the provider adapter, and the
small hold-id index used to enumerate section occupancy. Group seat lists are
stored canonically in the existing machine seat fact so old one-seat stores
retain their machine identity. The override file records only seats removed by
partial release. The index is rebuilt
from Ikaros aggregates whenever it is read, and unrelated files in `STATE_DIR`
are never touched.

## Setup

From this directory with Node 22.17.1 installed:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

The included `run` launcher uses `<home>/.nvm/versions/node/v22.17.1/bin/node`.
If Node is installed elsewhere, edit that one launcher path before deploying.

## Running

Start the supplied provider and use the `service_url` it prints:

```sh
node stub/server.mjs
STATE_DIR=/tmp/desk-state SERVICE_URL=http://127.0.0.1:PORT NOW_MS=100 ./run section hall-a 3
STATE_DIR=/tmp/desk-state SERVICE_URL=http://127.0.0.1:PORT NOW_MS=100 ./run hold g1 hall-a A1 A2 5000
STATE_DIR=/tmp/desk-state SERVICE_URL=http://127.0.0.1:PORT NOW_MS=100 ./run release g1 A1
STATE_DIR=/tmp/desk-state SERVICE_URL=http://127.0.0.1:PORT NOW_MS=100 ./run issue g1

Every normal invocation writes one JSON object to stdout. `STATE_DIR` is
required. `SERVICE_URL` is needed only for `issue` and `reconcile` when a saved
attempt needs provider lookup. Clock-sensitive commands require non-negative
integer `NOW_MS`; no wall clock is read. `CRASH_AT` is intended for recovery
exercises and accepts the three boundaries in `BRIEF.md`.

The desk's files are `.desk-sections.json`, `.desk-index.json`,
`.desk-seat-overrides.json`, and `holds.sqlite` under `STATE_DIR`. The
override file records the remaining seats after a partial release; it is only
written for holds that have been partially released. Do not share one state
directory between desk processes.

## Tests

The focused lifecycle test starts the supplied stub, exercises process restart
and all three crash labels, then exercises a dropped provider reply:

```sh
node --test tests/desk.test.mjs
```
