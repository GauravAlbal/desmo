# Clinic appointment desk

A local clinic desk manages appointment slots and bookings. Staff can define a slot, book one patient, replace a pending booking by rescheduling it, cancel a booking with a time-based fee, and send one reminder through an external messaging service. The desk is local: it has one durable state directory and does not coordinate with a remote scheduling database.

The builder owns an executable `./run`, implemented in Python 3.9+ using only the standard library. The supplied messaging service is specified in `stub/CONTRACT.md`.

## Scope and invocation

One process runs one command at a time. An unrelated writer may create or modify another file in `STATE_DIR`; the desk must preserve that file byte-for-byte. A fresh process with the same `STATE_DIR` sees committed records. The desk never reads the wall clock: every command that needs time receives `now_ms`.

`./run <command> [args]` prints exactly one JSON object to stdout (a trailing newline is allowed). Exit 0 means success. A refusal exits nonzero and prints one object with an `error` code from this brief. stderr is ignored. Extra JSON fields are allowed.

Environment:

- `STATE_DIR`: durable store, created if absent. The desk chooses its own filenames.
- `SERVICE_URL`: messaging-service base URL without a trailing slash.
- `CRASH_AT`: optional crash boundary; at a reached boundary the process must self-kill with SIGKILL.

Identifiers are 1–64 characters matching `[A-Za-z0-9._-]`. Email addresses are `local@domain`, where local is 1–64 `[A-Za-z0-9._+-]` and domain is 1–63 `[A-Za-z0-9.-]`. `now_ms` and slot `start_ms` are canonical decimal integers from 0 through 9999999999999 (zero or non-leading-zero digits). Malformed arguments are `bad_args`.

## Crash boundaries

The following labels apply to a reminder send. A boundary is honored only when the command reaches it; a command that does not send must not kill itself.

- `after-attempt-saved-before-request`: on `remind`, after the reminder attempt (booking id, slot, patient, address, kind) is durably committed and before any request byte is sent. A retry finding the saved attempt does not crash here again.
- `after-accept-before-record`: after a complete successful POST response has been read, before `reminder` is committed `sent`. A lookup of an earlier acceptance does not crash here.
- `after-record-before-exit`: after a terminal reminder outcome is durably committed and before this invocation writes its JSON. It is not honored when the outcome was already committed before this invocation.

## Commands

### `add-slot <slot_id> <start_ms>`

Create an open slot. Success:
`{"slot_id":"...","start_ms":0,"availability":"open"}`.

Refuse malformed ids/time with `bad_args`, or any existing slot/booking id collision with `id_in_use`. No service request is made.

### `book <slot_id> <booking_id> <patient_id> <address> <now_ms>`

Create a pending booking for an open slot. The booking stores the exact patient, address, slot, and booking id. Success:
`{"slot_id":"...","booking_id":"...","patient_id":"...","address":"...","state":"pending","reminder":"none","now_ms":0}`.

A slot may have multiple pending bookings. This command must not reject a second booking merely because another booking exists. Refuse with `unknown_slot`, `bad_args`, or `id_in_use` as applicable. Booking does not contact the service.

### `reschedule <booking_id> <new_slot_id> <now_ms>`

Replace the pending booking's slot with `new_slot_id`, retaining the same booking id, patient, address, and reminder state. The old slot is released. The new slot must exist. Success:
`{"booking_id":"...","slot_id":"...","state":"pending","reminder":"none|attempt_saved|sent","now_ms":0}`.

A booking that is `cancelled` is refused `already_cancelled`; a booking that has reminder `sent` is still pending and may be rescheduled. A missing booking is `unknown_booking`, a missing slot is `unknown_slot`, and malformed arguments are `bad_args`. A refusal makes no store change. Reschedule never contacts the service.

### `cancel <booking_id> <now_ms>`

Cancel a pending booking. The slot is released and the booking remains durably recorded as `cancelled`. The initial fee rule is: if `start_ms - now_ms` is at least 86400000 milliseconds, `fee_cents` is 0; otherwise it is 2500. `now_ms` may be after the start. Success:
`{"booking_id":"...","slot_id":"...","state":"cancelled","fee_cents":0|2500,"now_ms":0}`.

A second cancel is refused `already_cancelled` with no change. Unknown booking and malformed arguments use `unknown_booking` and `bad_args`. Cancellation does not contact the service.

### `remind <booking_id>`

Send the appointment reminder. Only a pending booking can start a reminder; a cancelled booking is refused `already_cancelled`. A pending booking with a terminal reminder already `sent` returns success without contacting the service. If no attempt exists, save one durably first with request id equal to `booking_id`, kind `appointment_reminder`, then honor `after-attempt-saved-before-request`.

For an attempt, first `GET /v1/requests/<booking_id>`. A matching 200 response (same slot, patient, address, and kind) commits `reminder: sent` and succeeds without POST. A 404 causes one POST with exactly:
`{"request_id":"booking_id","slot_id":"...","patient_id":"...","address":"...","kind":"appointment_reminder"}`.
After reading a complete 200 POST body, honor `after-accept-before-record`, then commit `reminder: sent` and return:
`{"booking_id":"...","slot_id":"...","patient_id":"...","address":"...","reminder":"sent","request_id":"..."}`.

A lookup mismatch or POST 409 is `conflict`. A failed connection, incomplete response, HTTP 500, or other non-200 POST is `service_unavailable`; retain `attempt_saved` and never invent another request id. A pending booking with a saved attempt for the same booking must continue that attempt. A different operation cannot overwrite it.

### `reconcile <booking_id>`

Resolve a saved reminder attempt by lookup only. It must never POST. If no reminder attempt exists, return exit 0 with `{"booking_id":"...","reminder":"none","request_id":null}`. A lookup 404 returns exit 0 with `reminder:"not_sent"` and leaves the attempt. A matching 200 commits `sent` and returns the normal terminal fields. A mismatch is `conflict`; service failure is `service_unavailable`. If already sent, return it unchanged without honoring a crash boundary.

### `status <booking_id>`

Read-only; no expiry, fee, or other commit. Success includes:
`{"booking_id":"...","slot_id":"...|null","start_ms":0|null,"patient_id":"...|null","address":"...|null","state":"pending|cancelled","reminder":"none|attempt_saved|sent","request_id":"...|null","now_ms":0}`.
A cancelled booking has `slot_id` null in the current assignment result but retains its historical slot in `cancelled_slot_id`; implementations may include both. Refuse `unknown_booking` or `bad_args`.

### `callback <callback_path>`

The file must be one JSON callback object with `callback_id`, `request_id`, `slot_id`, `patient_id`, `address`, `kind`, and `outcome` (`accepted` or `rejected`). Malformed files or missing fields are `bad_args`. The desk may ignore a valid callback. It must not POST or allocate an id. If a reminder is terminal, repeated or conflicting callbacks leave the booking unchanged and exit 0. A callback for an unknown request id also exits 0 without a change. A callback may be used only as a hint to lookup a saved attempt; it cannot make `sent` true without a matching service record.

## Messaging service

The service has `POST /v1/messages` and `GET /v1/requests/<request_id>`. A new request id is accepted once and counts one effect. Repeating the same id and exact payload returns the same 200 result without another effect; changing any payload field returns 409. The accepted object has `outcome:"accepted"`; kind for this family is `appointment_reminder`. A 404 lookup means only that this id was never accepted. The service may drop a reply after accepting, delay, or return an unavailable status without storing. A dropped reply is not evidence of no acceptance.

## Requirements

R1. **Persistence.** Slots and bookings survive new processes. Rescheduling and cancellation remain visible after restart, and a reminder killed after its durable record remains `sent`.

R2. **Booking record.** `status` presents the exact slot, start time, booking id, patient, address, state, and reminder fields saved by `book`.

R3. **Reschedule replacement.** A pending booking can be moved to an existing slot in one durable update; its booking id, patient, address, and reminder state are retained, and the old slot is released. A refusal leaves the original booking unchanged.

R4. **Fee window.** `cancel` computes and durably returns the initial 24-hour fee rule exactly, with no service call; repeat cancellation is refused without changing the first fee.

R5. **Legitimate progress.** A valid add-slot, book, reschedule, cancel, and reminder sequence is not refused; a healthy reminder creates exactly one accepted service effect.

R6. **Booking identity.** Booking ids and slot ids are namespace-safe. Reusing an existing id is refused `id_in_use` and does not overwrite another booking or slot.

R7. **Cancellation semantics.** Cancelling releases the booking's slot and preserves a terminal cancelled record. A second cancel is `already_cancelled`; reminding a cancelled booking is refused and does not contact the service.

R8. **Crash after accept.** If reminder is killed at `after-accept-before-record`, the service has one effect and local state is `attempt_saved`; a later remind adopts the same request by lookup and causes no second effect.

R9. **Crash before request.** If killed at `after-attempt-saved-before-request`, there is no service POST and the attempt is visible. A later remind sends exactly one request for that same booking id; no other booking id can replace it.

R10. **Crash after durable record.** If killed at `after-record-before-exit`, later status is `sent`; another remind adds no effect.

R11. **Lost reply.** An accepted reminder whose reply is dropped is reconciled by lookup. `reconcile` never POSTs, does not report `not_sent` after a 200 lookup, and leaves exactly one effect.

R12. **Result protocol.** Every invocation emits exactly one JSON object. Success exits 0; refusals exit nonzero with a listed error code.

R13. **Unrelated writer.** A file not owned by the desk in `STATE_DIR` keeps identical bytes across commands, including refusals, while desk records remain readable.

R14. **Late callback.** Repeated and conflicting valid callbacks after a sent reminder leave slot, booking, patient, address, and reminder unchanged and add no effect.

## Error codes

`bad_args`, `unknown_slot`, `unknown_booking`, `id_in_use`, `already_cancelled`, `conflict`, `service_unavailable`.
