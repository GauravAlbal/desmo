import json
import os
import signal
import subprocess
import tempfile
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ClinicLifecycleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = subprocess.Popen(
            ["node", "stub/server.mjs"], cwd=str(ROOT), stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True,
        )
        startup = json.loads(cls.server.stdout.readline())
        cls.service = startup["service_url"]
        cls.control_url = startup["control_url"]

    @classmethod
    def tearDownClass(cls):
        cls.server.terminate()
        try:
            cls.server.wait(timeout=3)
        except subprocess.TimeoutExpired:
            cls.server.kill()
            cls.server.wait()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.state = self.tmp.name
        self.env = dict(os.environ, STATE_DIR=self.state, SERVICE_URL=self.service)

    def tearDown(self):
        self.tmp.cleanup()

    def invoke(self, *args, **extra):
        env = dict(self.env, **extra)
        return subprocess.run([str(ROOT / "run"), *args], cwd=str(ROOT), env=env,
                              text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    def obj(self, result):
        self.assertTrue(result.stdout.strip(), result.stderr)
        return json.loads(result.stdout)

    def control(self, path, payload=None):
        request = urllib.request.Request(
            self.control_url + path,
            data=None if payload is None else json.dumps(payload).encode(),
            method="POST" if payload is not None else "GET",
            headers={"content-type": "application/json"},
        )
        return json.loads(urllib.request.urlopen(request).read())

    def seed(self, slot="slot-a", booking="booking-a"):
        self.assertEqual(self.invoke("add-slot", slot, "172800000").returncode, 0)
        self.assertEqual(self.invoke("book", slot, booking, "patient-a", "a@example.com", "0").returncode, 0)

    def test_restart_reschedule_cancel_and_unrelated_file(self):
        self.assertEqual(self.invoke("add-slot", "old", "172800000").returncode, 0)
        self.assertEqual(self.invoke("add-slot", "new", "172800001").returncode, 0)
        self.assertEqual(self.invoke("book", "old", "booking", "patient", "a@example.com", "0").returncode, 0)
        unrelated = Path(self.state) / "unrelated.bin"
        unrelated.write_bytes(b"do not touch\x00bytes")
        result = self.invoke("reschedule", "booking", "new", "0")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(self.obj(self.invoke("status", "booking"))["slot_id"], "new")
        self.assertEqual(self.invoke("cancel", "booking", "0").returncode, 0)
        cancelled = self.obj(self.invoke("status", "booking"))
        self.assertEqual(cancelled["state"], "cancelled")
        self.assertIsNone(cancelled["slot_id"])
        self.assertEqual(unrelated.read_bytes(), b"do not touch\x00bytes")
        self.assertEqual(self.obj(self.invoke("cancel", "booking", "0"))["error"], "already_cancelled")

    def test_crash_boundaries_and_idempotent_retry(self):
        self.seed()
        self.assertEqual(self.invoke("add-slot", "slot-r", "172800000").returncode, 0)
        result = self.invoke("remind", "booking-a", CRASH_AT="after-attempt-saved-before-request")
        self.assertEqual(result.returncode, -signal.SIGKILL)
        self.assertEqual(self.invoke("reschedule", "booking-a", "slot-r", "0").returncode, 0)
        self.assertEqual(self.obj(self.invoke("status", "booking-a"))["reminder"], "attempt_saved")
        self.assertEqual(self.invoke("remind", "booking-a").returncode, 0)
        effects = self.control("/effects")
        accepted = [item for item in effects["effects"] if item["request_id"] == "booking-a"]
        self.assertEqual(accepted[-1]["slot_id"], "slot-a")
        self.assertEqual(self.obj(self.invoke("status", "booking-a"))["reminder"], "sent")
        self.assertEqual(self.invoke("add-slot", "slot-c", "172800000").returncode, 0)
        self.assertEqual(self.invoke("book", "slot-c", "booking-c", "patient-c", "c@example.com", "0").returncode, 0)
        result = self.invoke("remind", "booking-c", CRASH_AT="after-accept-before-record")
        self.assertEqual(result.returncode, -signal.SIGKILL)
        self.assertEqual(self.obj(self.invoke("status", "booking-c"))["reminder"], "attempt_saved")
        self.assertEqual(self.invoke("remind", "booking-c").returncode, 0)
        self.assertEqual(self.invoke("add-slot", "slot-b", "172800000").returncode, 0)
        self.assertEqual(self.invoke("book", "slot-b", "booking-b", "patient-b", "b@example.com", "0").returncode, 0)
        result = self.invoke("remind", "booking-b", CRASH_AT="after-record-before-exit")
        self.assertEqual(result.returncode, -signal.SIGKILL)
        self.assertEqual(self.obj(self.invoke("status", "booking-b"))["reminder"], "sent")
        self.assertEqual(self.invoke("remind", "booking-b").returncode, 0)

    def test_lost_reply_reconciles_without_post(self):
        self.seed(slot="slot-l", booking="booking-l")
        self.control("/fault", {"drop_reply": True})
        result = self.invoke("remind", "booking-l")
        self.assertEqual(result.returncode, 1)
        self.control("/fault", {"drop_reply": False})
        result = self.invoke("reconcile", "booking-l")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(self.obj(result)["reminder"], "sent")
        effects = self.control("/effects")
        matching = [item for item in effects["effects"] if item["request_id"] == "booking-l"]
        self.assertEqual(len(matching), 1)

    def test_late_callbacks_are_noops(self):
        self.seed(slot="slot-cb", booking="booking-cb")
        self.assertEqual(self.invoke("remind", "booking-cb").returncode, 0)
        callback = self.control("/callbacks")["callbacks"][-1]
        callback["address"] = "other@example.com"
        callback_path = Path(self.state) / "callback.json"
        callback_path.write_text(json.dumps(callback))
        result = self.invoke("callback", str(callback_path))
        self.assertEqual(result.returncode, 0)
        self.assertEqual(self.obj(self.invoke("status", "booking-cb"))["reminder"], "sent")


    def test_overbooking_guard_and_released_slot(self):
        self.assertEqual(self.invoke("add-slot", "slot-a", "200000000").returncode, 0)
        self.assertEqual(self.invoke("add-slot", "slot-b", "300000000").returncode, 0)
        self.assertEqual(self.invoke("book", "slot-a", "booking-a", "patient-a", "a@example.com", "0").returncode, 0)

        result = self.invoke("book", "slot-a", "booking-b", "patient-b", "b@example.com", "0")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.obj(result)["error"], "slot_full")
        self.assertEqual(self.obj(self.invoke("status", "booking-a"))["slot_id"], "slot-a")
        self.assertEqual(self.invoke("book", "slot-b", "booking-b", "patient-b", "b@example.com", "0").returncode, 0)

        result = self.invoke("reschedule", "booking-b", "slot-a", "0")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(self.obj(result)["error"], "slot_full")
        self.assertEqual(self.obj(self.invoke("status", "booking-b"))["slot_id"], "slot-b")

        self.assertEqual(self.invoke("cancel", "booking-a", "0").returncode, 0)
        self.assertEqual(self.invoke("book", "slot-a", "booking-c", "patient-c", "c@example.com", "0").returncode, 0)

    def test_fee_quote_and_revised_cancellation_window(self):
        self.assertEqual(self.invoke("add-slot", "fee-slot", "172800000").returncode, 0)
        self.assertEqual(self.invoke("book", "fee-slot", "fee-booking", "patient", "a@example.com", "0").returncode, 0)
        before = {path: path.read_bytes() for path in Path(self.state).rglob("*") if path.is_file()}

        quote = self.invoke("fee-quote", "fee-booking", "0")
        self.assertEqual(quote.returncode, 0)
        self.assertEqual(self.obj(quote)["fee_cents"], 0)
        self.assertEqual(self.obj(self.invoke("fee-quote", "fee-booking", "1"))["fee_cents"], 5000)
        after = {path: path.read_bytes() for path in Path(self.state).rglob("*") if path.is_file()}
        self.assertEqual(before, after)

        cancelled = self.invoke("cancel", "fee-booking", "0")
        self.assertEqual(cancelled.returncode, 0)
        self.assertEqual(self.obj(cancelled)["fee_cents"], 0)
        quoted_cancelled = self.invoke("fee-quote", "fee-booking", "999999")
        self.assertEqual(quoted_cancelled.returncode, 0)
        self.assertEqual(self.obj(quoted_cancelled)["state"], "cancelled")
        self.assertEqual(self.obj(quoted_cancelled)["fee_cents"], 0)

if __name__ == "__main__":
    unittest.main()
