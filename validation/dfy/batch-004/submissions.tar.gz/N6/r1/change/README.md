# Clinic appointment desk

The desk stores its canonical lifecycle in an Ikaros reducer-backed SQLite store under `STATE_DIR`. It keeps only `desk.sqlite` there and never rewrites unrelated files.

## Setup

The repository includes the Ikaros wheel and packed `ik` binary. With Python 3.9 or newer:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
chmod +x run
```

No npm package is required. The supplied fake messaging service can be started with:

```sh
node stub/server.mjs
```

Use the printed `service_url` as `SERVICE_URL`. Every invocation also needs `STATE_DIR`; `CRASH_AT` is optional. `run` resolves the interpreter, package, and binary relative to this directory, so an activated environment is not required.

## Commands

```sh
STATE_DIR=.state SERVICE_URL=http://127.0.0.1:PORT ./run add-slot slot-a 172800000
STATE_DIR=.state SERVICE_URL=http://127.0.0.1:PORT ./run book slot-a booking-a patient-a patient@example.com 0
STATE_DIR=.state SERVICE_URL=http://127.0.0.1:PORT ./run fee-quote booking-a 0
STATE_DIR=.state SERVICE_URL=http://127.0.0.1:PORT ./run remind booking-a
STATE_DIR=.state SERVICE_URL=http://127.0.0.1:PORT ./run status booking-a
STATE_DIR=.state SERVICE_URL=http://127.0.0.1:PORT ./run reconcile booking-a
```

Each slot accepts one non-cancelled booking. A second booking or reschedule into
an occupied slot returns `slot_full`; cancelling releases the slot. New
cancellations use a 48-hour fee window: at least 172800000 milliseconds before
the slot costs 0 cents, otherwise 5000 cents. `fee-quote` is read-only and
returns that fee for pending bookings, or the committed fee for cancelled ones.

`./run` emits one JSON object per invocation. Refusals emit `{"error":"..."}` and exit nonzero. Reminder attempts are saved before POST, use the booking id as the external request id, and are reconciled by GET after uncertain replies. Crash-boundary labels are the three labels in `BRIEF.md`.


## Tests

Run the focused lifecycle tests after setup:

```sh
.venv/bin/python -m unittest discover -s tests -v
```
