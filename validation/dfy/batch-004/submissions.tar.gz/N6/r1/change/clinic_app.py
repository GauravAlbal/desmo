"""Clinic appointment desk backed by the Ikaros external-reducer lifecycle."""
from __future__ import annotations

import json
import os
import re
import signal
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Tuple

from invariant_kernel import ApplyOutcome, Decision, DomainEvent, Kernel, KernelError, ReducerDiagnostic, ReducerIdentity, TransportError
from invariant_kernel.reducer import thaw

ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
ADDRESS_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$")
DECIMAL_RE = re.compile(r"^(0|[1-9][0-9]*)$")
CANCELLATION_WINDOW_MS = 172800000
CANCELLATION_FEE_CENTS = 5000
KIND = "appointment_reminder"


def _diag(code: str, message: str) -> ReducerDiagnostic:
    return ReducerDiagnostic(code, message, "clinic.lifecycle")


def _event(name: str, args: Mapping[str, Any]) -> Decision:
    return Decision.emit(DomainEvent("clinic." + name, 1, {"name": name, "args": dict(args)}))


class ClinicReducer:
    identity = ReducerIdentity(
        "clinic_appointment_desk", 1,
        "1111111111111111111111111111111111111111111111111111111111111111",
        "2222222222222222222222222222222222222222222222222222222222222222",
        "3333333333333333333333333333333333333333333333333333333333333333",
    )

    @staticmethod
    def _slot_occupied(bookings: Mapping[str, Any], slot_id: Any, excluding: Optional[str] = None) -> bool:
        return any(
            booking_id != excluding
            and booking.get("state") != "cancelled"
            and booking.get("slot_id") == slot_id
            for booking_id, booking in bookings.items()
        )

    def initial_state(self) -> Dict[str, Any]:
        return {"slots": {}, "bookings": {}}

    def decide(self, state: Any, observation: Optional[Any], effect: Any, command: Any) -> Any:
        del observation, effect
        if not isinstance(command, Mapping):
            return _diag("bad_args", "command must be an object")
        name = command.get("name")
        args = command.get("args", {})
        if not isinstance(name, str) or not isinstance(args, Mapping):
            return _diag("bad_args", "malformed command")
        slots = state.get("slots", {})
        bookings = state.get("bookings", {})
        if name == "add_slot":
            slot_id = args.get("slot_id")
            if slot_id in slots or slot_id in bookings:
                return _diag("id_in_use", "identifier is already in use")
            return _event(name, args)
        if name == "book":
            slot_id = args.get("slot_id")
            booking_id = args.get("booking_id")
            if slot_id not in slots:
                return _diag("unknown_slot", "slot does not exist")
            if booking_id in slots or booking_id in bookings:
                return _diag("id_in_use", "identifier is already in use")
            if self._slot_occupied(bookings, slot_id):
                return _diag("slot_full", "slot is already occupied")
            return _event(name, args)

        if name == "reschedule":
            booking_id = args.get("booking_id")
            booking = bookings.get(booking_id)
            if booking is None:
                return _diag("unknown_booking", "booking does not exist")
            if booking.get("state") == "cancelled":
                return _diag("already_cancelled", "booking is cancelled")
            if args.get("new_slot_id") not in slots:
                return _diag("unknown_slot", "slot does not exist")
            if self._slot_occupied(bookings, args.get("new_slot_id"), excluding=booking_id):
                return _diag("slot_full", "slot is already occupied")
            return _event(name, args)

        if name == "cancel":
            booking = bookings.get(args.get("booking_id"))
            if booking is None:
                return _diag("unknown_booking", "booking does not exist")
            if booking.get("state") == "cancelled":
                return _diag("already_cancelled", "booking is cancelled")
            return _event(name, args)
        if name == "save_attempt":
            booking = bookings.get(args.get("booking_id"))
            if booking is None:
                return _diag("unknown_booking", "booking does not exist")
            if booking.get("state") == "cancelled":
                return _diag("already_cancelled", "booking is cancelled")
            if booking.get("reminder") == "sent":
                return Decision.noop()
            if booking.get("reminder") == "attempt_saved":
                return Decision.noop()
            return _event(name, args)
        if name == "mark_sent":
            booking = bookings.get(args.get("booking_id"))
            if booking is None:
                return _diag("unknown_booking", "booking does not exist")
            if booking.get("state") == "cancelled":
                return _diag("already_cancelled", "booking is cancelled")
            if booking.get("reminder") == "sent":
                return Decision.noop()
            if booking.get("reminder") != "attempt_saved":
                return _diag("conflict", "reminder attempt is not saved")
            return _event(name, args)
        return _diag("bad_args", "unknown command")

    def apply(self, state: Any, event: DomainEvent) -> Any:
        next_state = thaw(state)
        payload = thaw(event.payload)
        name = payload["name"]
        args = payload["args"]
        slots = next_state["slots"]
        bookings = next_state["bookings"]
        if name == "add_slot":
            slots[args["slot_id"]] = {"start_ms": args["start_ms"], "availability": "open"}
        elif name == "book":
            bookings[args["booking_id"]] = {
                "slot_id": args["slot_id"], "patient_id": args["patient_id"],
                "address": args["address"], "state": "pending", "reminder": "none",
                "request_id": None,
            }
        elif name == "reschedule":
            bookings[args["booking_id"]]["slot_id"] = args["new_slot_id"]
        elif name == "cancel":
            booking = bookings[args["booking_id"]]
            booking["cancelled_slot_id"] = booking["slot_id"]
            booking["slot_id"] = None
            booking["state"] = "cancelled"
            booking["fee_cents"] = args["fee_cents"]
        elif name == "save_attempt":
            booking = bookings[args["booking_id"]]
            booking["reminder"] = "attempt_saved"
            booking["request_id"] = args["booking_id"]
            booking["attempt"] = {
                "request_id": args["booking_id"], "slot_id": booking["slot_id"],
                "patient_id": booking["patient_id"], "address": booking["address"],
                "kind": KIND,
            }
        elif name == "mark_sent":
            bookings[args["booking_id"]]["reminder"] = "sent"
        else:
            raise ValueError("unknown event")
        return ApplyOutcome.new(next_state)


def valid_id(value: str) -> bool:
    return bool(ID_RE.fullmatch(value))


def valid_ms(value: str) -> bool:
    return bool(DECIMAL_RE.fullmatch(value)) and int(value) <= 9999999999999


def parse_ms(value: str) -> int:
    return int(value)


def require_id(value: str) -> None:
    if not valid_id(value):
        raise DeskError("bad_args")


def require_ms(value: str) -> int:
    if not valid_ms(value):
        raise DeskError("bad_args")
    return parse_ms(value)

def cancellation_fee(start_ms: int, now_ms: int) -> int:
    return 0 if start_ms - now_ms >= CANCELLATION_WINDOW_MS else CANCELLATION_FEE_CENTS



def require_address(value: str) -> None:
    if not ADDRESS_RE.fullmatch(value):
        raise DeskError("bad_args")


class DeskError(Exception):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


def crash(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


def public_booking(booking_id: str, booking: Mapping[str, Any], slots: Mapping[str, Any], now_ms: int) -> Dict[str, Any]:
    slot_id = booking.get("slot_id")
    slot = slots.get(slot_id) if slot_id is not None else None
    return {
        "booking_id": booking_id,
        "slot_id": slot_id,
        "start_ms": slot["start_ms"] if slot is not None else None,
        "patient_id": booking.get("patient_id"),
        "address": booking.get("address"),
        "state": booking.get("state"),
        "reminder": booking.get("reminder", "none"),
        "request_id": booking.get("request_id"),
        "now_ms": now_ms,
    }


class Desk:
    def __init__(self, state_dir: Path) -> None:
        self.state_dir = state_dir
        self.state_dir.mkdir(parents=True, exist_ok=True)
        binary = os.environ.get("IK_BINARY")
        self.kernel = Kernel(str(self.state_dir / "desk.sqlite"), binary=binary)
        self.machine = self.kernel.reducer("clinic_app:ClinicReducer", python=sys.executable)
        try:
            self.aggregate = self.machine.show("desk")
        except Exception as exc:
            if getattr(exc, "code", None) not in ("IK_ILLEGAL_STATE", "IK_STORE_NOT_FOUND"):
                raise
            self.aggregate = self.machine.create("desk")

    def state(self) -> Dict[str, Any]:
        return thaw(self.aggregate.state)

    def commit(self, name: str, args: Mapping[str, Any]) -> Dict[str, Any]:
        try:
            result = self.aggregate.execute({"name": name, "args": dict(args)})
        except KernelError as exc:
            code = None
            if exc.diagnostic:
                code = exc.diagnostic.get("code")
            raise DeskError(code if code in ERROR_CODES else "service_unavailable")
        except TransportError:
            raise DeskError("service_unavailable")
        self.aggregate = result
        return self.state()

    def booking(self, booking_id: str) -> Mapping[str, Any]:
        booking = self.state()["bookings"].get(booking_id)
        if booking is None:
            raise DeskError("unknown_booking")
        return booking


ERROR_CODES = {"bad_args", "unknown_slot", "unknown_booking", "id_in_use", "slot_full", "already_cancelled", "conflict", "service_unavailable"}


def http_json(method: str, url: str, body: Optional[Mapping[str, Any]] = None) -> Tuple[int, Any]:
    data = None if body is None else json.dumps(body, separators=(",", ":")).encode("utf-8")
    req = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=5) as response:
            raw = response.read()
            return response.status, json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as exc:
        try:
            payload = json.loads(exc.read().decode("utf-8"))
        except Exception:
            payload = None
        return exc.code, payload
    except Exception as exc:
        raise DeskError("service_unavailable") from exc


def attempt_payload(booking_id: str, booking: Mapping[str, Any]) -> Dict[str, Any]:
    attempt = booking.get("attempt")
    if isinstance(attempt, Mapping):
        return dict(attempt)
    return {
        "request_id": booking_id, "slot_id": booking["slot_id"], "patient_id": booking["patient_id"],
        "address": booking["address"], "kind": KIND,
    }


def matching_response(payload: Any, expected: Mapping[str, Any]) -> bool:
    return isinstance(payload, Mapping) and all(payload.get(key) == value for key, value in expected.items()) and payload.get("outcome") == "accepted"


def send_reminder(desk: Desk, booking_id: str) -> Dict[str, Any]:
    booking = desk.booking(booking_id)
    if booking["state"] == "cancelled":
        raise DeskError("already_cancelled")
    state = desk.state()
    if booking["reminder"] == "sent":
        return {"booking_id": booking_id, **attempt_payload(booking_id, booking), "reminder": "sent", "request_id": booking_id}
    if booking["reminder"] == "none":
        state = desk.commit("save_attempt", {"booking_id": booking_id})
        booking = state["bookings"][booking_id]
        crash("after-attempt-saved-before-request")
    expected = attempt_payload(booking_id, booking)
    base = os.environ.get("SERVICE_URL", "").rstrip("/")
    if not base:
        raise DeskError("service_unavailable")
    status, response = http_json("GET", base + "/v1/requests/" + booking_id)
    if status == 200:
        if not matching_response(response, expected):
            raise DeskError("conflict")
    elif status == 404:
        status, response = http_json("POST", base + "/v1/messages", expected)
        if status == 409:
            raise DeskError("conflict")
        if status != 200 or not matching_response(response, expected):
            raise DeskError("service_unavailable")
        crash("after-accept-before-record")
    else:
        raise DeskError("service_unavailable")
    desk.commit("mark_sent", {"booking_id": booking_id})
    crash("after-record-before-exit")
    return {"booking_id": booking_id, **expected, "reminder": "sent", "request_id": booking_id}


def reconcile(desk: Desk, booking_id: str) -> Dict[str, Any]:
    booking = desk.booking(booking_id)
    if booking["state"] == "cancelled":
        raise DeskError("already_cancelled")
    if booking["reminder"] == "none":
        return {"booking_id": booking_id, "reminder": "none", "request_id": None}
    if booking["reminder"] == "sent":
        return {"booking_id": booking_id, **attempt_payload(booking_id, booking), "reminder": "sent", "request_id": booking_id}
    base = os.environ.get("SERVICE_URL", "").rstrip("/")
    if not base:
        raise DeskError("service_unavailable")
    expected = attempt_payload(booking_id, booking)
    status, response = http_json("GET", base + "/v1/requests/" + booking_id)
    if status == 404:
        return {"booking_id": booking_id, "reminder": "not_sent", "request_id": booking_id}
    if status != 200:
        raise DeskError("service_unavailable")
    if not matching_response(response, expected):
        raise DeskError("conflict")
    desk.commit("mark_sent", {"booking_id": booking_id})
    return {"booking_id": booking_id, **expected, "reminder": "sent", "request_id": booking_id}


def callback(desk: Desk, path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            value = json.load(handle)
    except Exception as exc:
        raise DeskError("bad_args") from exc
    required = {"callback_id", "request_id", "slot_id", "patient_id", "address", "kind", "outcome"}
    if not isinstance(value, Mapping) or not required.issubset(value) or value["outcome"] not in ("accepted", "rejected"):
        raise DeskError("bad_args")
    if not isinstance(value["callback_id"], str) or not value["callback_id"]:
        raise DeskError("bad_args")
    for key in ("request_id", "slot_id", "patient_id"):
        if not isinstance(value[key], str) or not valid_id(value[key]):
            raise DeskError("bad_args")
    if not isinstance(value["kind"], str) or value["kind"] != KIND:
        raise DeskError("bad_args")
    require_address(value["address"])
    booking = desk.state()["bookings"].get(value["request_id"])
    if booking is None or booking["reminder"] == "sent":
        return {"callback_id": value["callback_id"], "applied": False}
    if booking["reminder"] != "attempt_saved":
        return {"callback_id": value["callback_id"], "applied": False}
    # The callback is only a hint.  Reconcile by lookup and never POST here.
    base = os.environ.get("SERVICE_URL", "").rstrip("/")
    if not base:
        raise DeskError("service_unavailable")
    expected = attempt_payload(value["request_id"], booking)
    status, response = http_json("GET", base + "/v1/requests/" + value["request_id"])
    if status == 200 and matching_response(response, expected):
        desk.commit("mark_sent", {"booking_id": value["request_id"]})
        return {"callback_id": value["callback_id"], "applied": True}
    if status in (200, 409):
        raise DeskError("conflict")
    if status == 404:
        return {"callback_id": value["callback_id"], "applied": False}
    raise DeskError("service_unavailable")


def run_command(argv: list[str], desk: Desk) -> Dict[str, Any]:
    if not argv:
        raise DeskError("bad_args")
    command = argv[0]
    if command == "add-slot" and len(argv) == 3:
        slot_id, start = argv[1], require_ms(argv[2])
        require_id(slot_id)
        desk.commit("add_slot", {"slot_id": slot_id, "start_ms": start})
        return {"slot_id": slot_id, "start_ms": start, "availability": "open"}
    if command == "book" and len(argv) == 6:
        slot_id, booking_id, patient_id, address = argv[1:5]
        require_id(slot_id); require_id(booking_id); require_id(patient_id); require_address(address)
        now = require_ms(argv[5])
        desk.commit("book", {"slot_id": slot_id, "booking_id": booking_id, "patient_id": patient_id, "address": address})
        return {"slot_id": slot_id, "booking_id": booking_id, "patient_id": patient_id, "address": address, "state": "pending", "reminder": "none", "now_ms": now}
    if command == "reschedule" and len(argv) == 4:
        booking_id, new_slot = argv[1], argv[2]; require_id(booking_id); require_id(new_slot); now = require_ms(argv[3])
        desk.commit("reschedule", {"booking_id": booking_id, "new_slot_id": new_slot})
        booking = desk.booking(booking_id)
        return {"booking_id": booking_id, "slot_id": new_slot, "state": booking["state"], "reminder": booking["reminder"], "now_ms": now}
    if command == "cancel" and len(argv) == 3:
        booking_id = argv[1]; require_id(booking_id); now = require_ms(argv[2]); booking = desk.booking(booking_id)
        if booking["state"] == "cancelled":
            raise DeskError("already_cancelled")
        start = desk.state()["slots"].get(booking["slot_id"], {}).get("start_ms")
        fee = cancellation_fee(start, now)

        desk.commit("cancel", {"booking_id": booking_id, "fee_cents": fee})
        return {"booking_id": booking_id, "slot_id": booking["slot_id"], "state": "cancelled", "fee_cents": fee, "now_ms": now}
    if command == "fee-quote" and len(argv) == 3:
        booking_id = argv[1]
        require_id(booking_id)
        now = require_ms(argv[2])
        booking = desk.booking(booking_id)
        if booking["state"] == "cancelled":
            return {"booking_id": booking_id, "state": "cancelled", "fee_cents": booking["fee_cents"], "now_ms": now}
        start = desk.state()["slots"][booking["slot_id"]]["start_ms"]
        return {"booking_id": booking_id, "state": "pending", "fee_cents": cancellation_fee(start, now), "now_ms": now}

    if command == "remind" and len(argv) == 2:
        require_id(argv[1]); return send_reminder(desk, argv[1])
    if command == "reconcile" and len(argv) == 2:
        require_id(argv[1]); return reconcile(desk, argv[1])
    if command == "status" and len(argv) == 2:
        booking_id = argv[1]; require_id(booking_id); booking = desk.booking(booking_id); return public_booking(booking_id, booking, desk.state()["slots"], 0)
    if command == "callback" and len(argv) == 2:
        return callback(desk, argv[1])
    raise DeskError("bad_args")


def main(argv: list[str]) -> int:
    try:
        state_dir = os.environ.get("STATE_DIR")
        if not state_dir:
            raise DeskError("bad_args")
        desk = Desk(Path(state_dir))
        result = run_command(argv, desk)
        print(json.dumps(result, separators=(",", ":"), sort_keys=True))
        return 0
    except DeskError as exc:
        print(json.dumps({"error": exc.code}, separators=(",", ":"), sort_keys=True))
        return 1
    except Exception:
        print(json.dumps({"error": "service_unavailable"}, separators=(",", ":"), sort_keys=True))
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
