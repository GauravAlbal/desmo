from __future__ import annotations

import json
import os
import subprocess
import tempfile
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node"


class ClinicTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = subprocess.Popen(
            [NODE, str(ROOT / "stub" / "server.mjs")],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        assert cls.server.stdout is not None
        cls.server_info = json.loads(cls.server.stdout.readline())
        cls.service = cls.server_info["service_url"]
        cls.control = cls.server_info["control_url"]

    @classmethod
    def tearDownClass(cls):
        cls.server.terminate()
        cls.server.wait(timeout=5)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.env = os.environ.copy()
        self.env.update({"STATE_DIR": self.tmp.name, "SERVICE_URL": self.service})

    def tearDown(self):
        self.tmp.cleanup()

    def invoke(self, *args, **extra):
        env = dict(self.env)
        env.update(extra)
        return subprocess.run([str(ROOT / "run"), *args], env=env, text=True, capture_output=True)

    def json(self, result):
        return json.loads(result.stdout)

    def seed(self, slot="slot-1", booking="booking-1"):
        self.assertEqual(self.invoke("add-slot", slot, "172800000").returncode, 0)
        self.assertEqual(self.invoke("book", slot, booking, "patient-1", "patient@example.com", "0").returncode, 0)

    def fault(self, **fields):
        body = json.dumps(fields).encode()
        request = urllib.request.Request(self.control + "/fault", data=body, method="POST", headers={"content-type": "application/json"})
        with urllib.request.urlopen(request) as response:
            self.assertEqual(response.status, 200)

    def effects(self):
        with urllib.request.urlopen(self.control + "/effects") as response:
            return json.load(response)["count"]

    def test_restart_and_unrelated_file(self):
        unrelated = Path(self.tmp.name) / "unrelated.bin"
        unrelated.write_bytes(b"keep these exact bytes\x00")
        self.seed()
        self.assertEqual(self.invoke("add-slot", "slot-2", "200000000").returncode, 0)
        result = self.invoke("status", "booking-1")
        self.assertEqual(self.json(result)["slot_id"], "slot-1")
        self.assertEqual(unrelated.read_bytes(), b"keep these exact bytes\x00")
        self.assertEqual(self.invoke("reschedule", "booking-1", "slot-2", "0").returncode, 0)
        self.assertEqual(self.json(self.invoke("status", "booking-1"))["slot_id"], "slot-2")

    def test_crash_labels(self):
        for index, label in enumerate(("after-attempt-saved-before-request", "after-accept-before-record", "after-record-before-exit")):
            with self.subTest(label=label):
                self.seed(slot=f"slot-{index}", booking=f"booking-{index}")
                crashed = self.invoke("remind", f"booking-{index}", CRASH_AT=label)
                self.assertEqual(crashed.returncode, -9 if os.name != "nt" else 137)
                status = self.json(self.invoke("status", f"booking-{index}"))
                if label == "after-record-before-exit":
                    self.assertEqual(status["reminder"], "sent")
                else:
                    self.assertEqual(status["reminder"], "attempt_saved")
                self.assertEqual(self.invoke("remind", f"booking-{index}").returncode, 0)

    def test_lost_reply_reconcile_without_second_effect(self):
        self.seed(slot="slot-lost", booking="booking-lost")
        baseline = self.effects()
        self.fault(drop_reply=True)
        first = self.invoke("remind", "booking-lost")
        self.assertNotEqual(first.returncode, 0)
        self.assertEqual(self.json(first)["error"], "service_unavailable")
        self.fault(drop_reply=False)
        self.assertEqual(self.invoke("reconcile", "booking-lost").returncode, 0)
        self.assertEqual(self.json(self.invoke("status", "booking-lost"))["reminder"], "sent")
        self.assertEqual(self.effects(), baseline + 1)


    def test_overbooking_and_guarded_reschedule(self):
        self.assertEqual(self.invoke("add-slot", "slot-a", "200000000").returncode, 0)
        self.assertEqual(self.invoke("add-slot", "slot-b", "300000000").returncode, 0)
        self.assertEqual(self.invoke("book", "slot-a", "booking-a", "patient-a", "a@example.com", "0").returncode, 0)
        full = self.invoke("book", "slot-a", "booking-b", "patient-b", "b@example.com", "0")
        self.assertNotEqual(full.returncode, 0)
        self.assertEqual(self.json(full)["error"], "slot_full")
        self.assertEqual(self.invoke("book", "slot-b", "booking-b", "patient-b", "b@example.com", "0").returncode, 0)
        blocked = self.invoke("reschedule", "booking-a", "slot-b", "0")
        self.assertNotEqual(blocked.returncode, 0)
        self.assertEqual(self.json(blocked)["error"], "slot_full")
        self.assertEqual(self.json(self.invoke("status", "booking-a"))["slot_id"], "slot-a")
        self.assertEqual(self.json(self.invoke("status", "booking-b"))["slot_id"], "slot-b")
        self.assertEqual(self.invoke("cancel", "booking-b", "0").returncode, 0)
        self.assertEqual(self.invoke("reschedule", "booking-a", "slot-b", "0").returncode, 0)
        self.assertEqual(self.json(self.invoke("status", "booking-a"))["slot_id"], "slot-b")

    def test_revised_fee_and_read_only_quote(self):
        self.assertEqual(self.invoke("add-slot", "slot-fee", "172800000").returncode, 0)
        self.assertEqual(self.invoke("book", "slot-fee", "booking-fee", "patient-1", "patient@example.com", "0").returncode, 0)
        self.assertEqual(self.invoke("add-slot", "slot-exact", "172800000").returncode, 0)
        self.assertEqual(self.invoke("book", "slot-exact", "booking-exact", "patient-2", "exact@example.com", "0").returncode, 0)
        exact_cancel = self.invoke("cancel", "booking-exact", "0")
        self.assertEqual(exact_cancel.returncode, 0)
        self.assertEqual(self.json(exact_cancel)["fee_cents"], 0)
        store = Path(self.tmp.name) / "clinic.kernel.db"
        before = store.read_bytes()
        exact = self.invoke("fee-quote", "booking-fee", "0")
        self.assertEqual(exact.returncode, 0)
        self.assertEqual(self.json(exact)["fee_cents"], 0)
        inside = self.invoke("fee-quote", "booking-fee", "1")
        self.assertEqual(inside.returncode, 0)
        self.assertEqual(self.json(inside)["fee_cents"], 5000)
        self.assertEqual(store.read_bytes(), before)
        cancelled = self.invoke("cancel", "booking-fee", "1")
        self.assertEqual(cancelled.returncode, 0)
        self.assertEqual(self.json(cancelled)["fee_cents"], 5000)
        quoted_cancelled = self.invoke("fee-quote", "booking-fee", "0")
        self.assertEqual(quoted_cancelled.returncode, 0)
        self.assertEqual(self.json(quoted_cancelled)["state"], "cancelled")
        self.assertEqual(self.json(quoted_cancelled)["fee_cents"], 5000)
        repeat = self.invoke("cancel", "booking-fee", "0")
        self.assertNotEqual(repeat.returncode, 0)
        self.assertEqual(self.json(repeat)["error"], "already_cancelled")

    def test_overbooking_does_not_block_reminder_recovery(self):
        self.seed(slot="slot-recovery", booking="booking-recovery")
        refused = self.invoke("book", "slot-recovery", "booking-other", "patient-2", "other@example.com", "0")
        self.assertNotEqual(refused.returncode, 0)
        self.assertEqual(self.json(refused)["error"], "slot_full")
        baseline = self.effects()
        crashed = self.invoke("remind", "booking-recovery", CRASH_AT="after-accept-before-record")
        self.assertEqual(crashed.returncode, -9 if os.name != "nt" else 137)
        self.assertEqual(self.effects(), baseline + 1)
        self.assertEqual(self.invoke("reconcile", "booking-recovery").returncode, 0)
        self.assertEqual(self.json(self.invoke("status", "booking-recovery"))["reminder"], "sent")
        self.assertEqual(self.effects(), baseline + 1)


if __name__ == "__main__":
    unittest.main()
