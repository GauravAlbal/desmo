# Clinic appointment desk

This is a single-process-at-a-time local appointment desk. Durable lifecycle state is held by the supplied Ikaros runtime in `STATE_DIR/clinic.kernel.db`; other files in `STATE_DIR` are not read or rewritten.

## Setup

The supplied wheel and packed runtime are used offline:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
chmod +x run
```

`./run` locates `.venv/bin/python` and `KIT/bin/ik` itself. It requires `STATE_DIR`, `SERVICE_URL`, and optionally `CRASH_AT`; no wall clock is read. `SERVICE_URL` is the stub base URL without a trailing slash.

## Commands

```sh
./run add-slot <slot_id> <start_ms>
./run book <slot_id> <booking_id> <patient_id> <address> <now_ms>
./run reschedule <booking_id> <new_slot_id> <now_ms>
./run cancel <booking_id> <now_ms>
./run fee-quote <booking_id> <now_ms>
./run remind <booking_id>
./run reconcile <booking_id>
./run status <booking_id>
./run callback <callback.json>

Every normal invocation prints one JSON object. Refusals print `{"error":"..."}` and exit nonzero. Each slot accepts at most one non-cancelled booking; a full slot returns `slot_full` without a waitlist. Cancellation charges 0 cents at least 48 hours before the appointment and 5000 cents inside that window. `fee-quote` computes that rule without changing state. A reminder attempt is saved before the HTTP request, and lookup by the booking id is used after a lost reply; the desk never retries a request with a new identity.

For local integration exercises, start the supplied fake service with `node stub/server.mjs`; it prints a JSON line containing `service_url` and `control_url`.

## Tests

The standard-library test driver starts the supplied stub and covers restart persistence, all three crash labels, a dropped reply/reconcile path, unrelated files, the single-booking guard, guarded rescheduling, revised fee boundaries, read-only fee quotes, and reminder recovery:

```sh
.venv/bin/python tests/test_app.py
```
