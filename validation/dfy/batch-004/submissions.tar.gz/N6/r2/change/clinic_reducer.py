from __future__ import annotations

import re
from typing import Any, Mapping, Optional

from invariant_kernel import ApplyOutcome, Decision, DomainEvent, ReducerDiagnostic, ReducerIdentity

_ID = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
_MAX_MS = 9_999_999_999_999
_DAY_MS = 86_400_000


def _diag(code: str, message: str) -> ReducerDiagnostic:
    return ReducerDiagnostic(code, message)


def _id(value: Any) -> bool:
    return isinstance(value, str) and _ID.fullmatch(value) is not None


def _ms(value: Any) -> bool:
    return type(value) is int and 0 <= value <= _MAX_MS


def _address(value: Any) -> bool:
    if not isinstance(value, str) or "@" not in value:
        return False
    local, domain = value.split("@", 1)
    return (
        1 <= len(local) <= 64
        and re.fullmatch(r"[A-Za-z0-9._+-]+", local) is not None
        and 1 <= len(domain) <= 63
        and re.fullmatch(r"[A-Za-z0-9.-]+", domain) is not None
    )


def _copy_state(state: Mapping[str, Any]) -> dict[str, Any]:
    slots = {
        str(slot_id): {"start_ms": int(row["start_ms"]), "availability": "open"}
        for slot_id, row in dict(state.get("slots", {})).items()
    }
    bookings: dict[str, dict[str, Any]] = {}
    for booking_id, row in dict(state.get("bookings", {})).items():
        bookings[str(booking_id)] = dict(row)
    return {"slots": slots, "bookings": bookings}


def _slot_occupied(bookings: Mapping[str, Any], slot_id: str, excluding: str | None = None) -> bool:
    return any(
        booking_id != excluding
        and row.get("state") != "cancelled"
        and row.get("slot_id") == slot_id
        for booking_id, row in bookings.items()
    )


class ClinicReducer:
    identity = ReducerIdentity(
        "clinic_appointment_desk",
        1,
        "0000000000000000000000000000000000000000000000000000000000000001",
        "0000000000000000000000000000000000000000000000000000000000000002",
        "0000000000000000000000000000000000000000000000000000000000000003",
    )

    def initial_state(self) -> Any:
        return {"slots": {}, "bookings": {}}

    def decide(
        self, state: Any, observation: Optional[Any], effect: Any, command: Any
    ) -> Decision | ReducerDiagnostic:
        del observation, effect
        if not isinstance(command, Mapping):
            return _diag("bad_args", "command must be an object")
        name = command.get("name")
        args = command.get("args", {})
        if not isinstance(name, str) or not isinstance(args, Mapping):
            return _diag("bad_args", "command name and args are required")
        current = _copy_state(state)
        slots, bookings = current["slots"], current["bookings"]

        if name == "add_slot":
            slot_id, start_ms = args.get("slot_id"), args.get("start_ms")
            if not _id(slot_id) or not _ms(start_ms):
                return _diag("bad_args", "invalid slot id or start time")
            if slot_id in slots or slot_id in bookings:
                return _diag("id_in_use", "identifier is already in use")
            slots[slot_id] = {"start_ms": start_ms, "availability": "open"}

        elif name == "book":
            slot_id = args.get("slot_id")
            booking_id = args.get("booking_id")
            patient_id = args.get("patient_id")
            address = args.get("address")
            now_ms = args.get("now_ms")
            if not (
                _id(slot_id) and _id(booking_id) and _id(patient_id)
                and _address(address) and _ms(now_ms)
            ):
                return _diag("bad_args", "invalid booking arguments")
            if slot_id not in slots:
                return _diag("unknown_slot", "slot does not exist")
            if booking_id in slots or booking_id in bookings:
                return _diag("id_in_use", "identifier is already in use")
            if _slot_occupied(bookings, slot_id):
                return _diag("slot_full", "slot is already occupied")
            bookings[booking_id] = {
                "slot_id": slot_id,
                "start_ms": slots[slot_id]["start_ms"],
                "patient_id": patient_id,
                "address": address,
                "state": "pending",
                "reminder": "none",
                "request_id": None,
                "fee_cents": None,
                "cancelled_slot_id": None,
            }

        elif name == "reschedule":
            booking_id, new_slot_id, now_ms = (
                args.get("booking_id"), args.get("new_slot_id"), args.get("now_ms")
            )
            if not (_id(booking_id) and _id(new_slot_id) and _ms(now_ms)):
                return _diag("bad_args", "invalid reschedule arguments")
            if booking_id not in bookings:
                return _diag("unknown_booking", "booking does not exist")
            booking = bookings[booking_id]
            if booking["state"] == "cancelled":
                return _diag("already_cancelled", "booking is cancelled")
            if new_slot_id not in slots:
                return _diag("unknown_slot", "slot does not exist")
            if _slot_occupied(bookings, new_slot_id, excluding=booking_id):
                return _diag("slot_full", "slot is already occupied")
            booking["slot_id"] = new_slot_id
            booking["start_ms"] = slots[new_slot_id]["start_ms"]

        elif name == "cancel":
            booking_id, now_ms = args.get("booking_id"), args.get("now_ms")
            if not (_id(booking_id) and _ms(now_ms)):
                return _diag("bad_args", "invalid cancellation arguments")
            if booking_id not in bookings:
                return _diag("unknown_booking", "booking does not exist")
            booking = bookings[booking_id]
            if booking["state"] == "cancelled":
                return _diag("already_cancelled", "booking is cancelled")
            start_ms = booking["start_ms"]
            booking["cancelled_slot_id"] = booking["slot_id"]
            booking["slot_id"] = None
            booking["state"] = "cancelled"
            booking["fee_cents"] = 0 if start_ms - now_ms >= 172_800_000 else 5_000

        elif name == "save_attempt":
            booking_id = args.get("booking_id")
            if not _id(booking_id):
                return _diag("bad_args", "invalid booking id")
            if booking_id not in bookings:
                return _diag("unknown_booking", "booking does not exist")
            booking = bookings[booking_id]
            if booking["state"] == "cancelled":
                return _diag("already_cancelled", "booking is cancelled")
            if booking["reminder"] == "sent":
                return Decision.noop()
            if booking["reminder"] == "attempt_saved":
                return Decision.noop()
            booking["reminder"] = "attempt_saved"
            booking["request_id"] = booking_id

        elif name == "mark_sent":
            booking_id = args.get("booking_id")
            request_id = args.get("request_id")
            if not (_id(booking_id) and _id(request_id)):
                return _diag("bad_args", "invalid reminder identity")
            if booking_id not in bookings:
                return _diag("unknown_booking", "booking does not exist")
            booking = bookings[booking_id]
            if booking["state"] == "cancelled":
                return _diag("already_cancelled", "booking is cancelled")
            if booking["reminder"] == "sent":
                return Decision.noop()
            if booking["reminder"] != "attempt_saved" or booking["request_id"] != request_id:
                return _diag("conflict", "reminder attempt does not match")
            booking["reminder"] = "sent"

        else:
            return _diag("bad_args", "unknown command")

        event = DomainEvent("state_replaced", 1, current)
        return Decision.emit(event)

    def apply(self, state: Any, event: DomainEvent) -> ApplyOutcome | ReducerDiagnostic:
        del state
        if event.event_type != "state_replaced" or event.event_version != 1:
            return _diag("bad_args", "unknown lifecycle event")
        return ApplyOutcome.new(event.payload)
