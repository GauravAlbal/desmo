from __future__ import annotations

import json
import os
import signal
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Mapping

from invariant_kernel import Kernel, KernelError, HistoricalResult
import re
import signal
_STATE_FILE = "clinic.kernel.db"
_DAY_MS = 86_400_000
_REQUIRED_CALLBACK = {"callback_id", "request_id", "slot_id", "patient_id", "address", "kind", "outcome"}
_ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")

def _die_at(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


def _valid_id(value: Any) -> bool:
    return isinstance(value, str) and _ID_RE.fullmatch(value) is not None


def _valid_address(value: Any) -> bool:
    if not isinstance(value, str) or "@" not in value:
        return False
    local, domain = value.split("@", 1)
    return (
        1 <= len(local) <= 64
        and re.fullmatch(r"[A-Za-z0-9._+-]+", local) is not None
        and 1 <= len(domain) <= 63
        and re.fullmatch(r"[A-Za-z0-9.-]+", domain) is not None
    )

def _service_url() -> str:
    value = os.environ.get("SERVICE_URL", "")
    return value[:-1] if value.endswith("/") else value


def _json_request(method: str, path: str, body: bytes | None = None) -> tuple[int, Any]:
    url = _service_url() + path
    request = urllib.request.Request(url, data=body, method=method)
    request.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(request, timeout=5) as response:
            status = int(response.status)
            raw = response.read()
    except urllib.error.HTTPError as exc:
        status = int(exc.code)
        try:
            raw = exc.read()
        except OSError:
            raw = b""
    except (urllib.error.URLError, TimeoutError, OSError):
        raise ServiceUnavailable()
    if not raw:
        raise ServiceUnavailable()
    try:
        return status, json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ServiceUnavailable()


class ServiceUnavailable(Exception):
    pass


class Conflict(Exception):
    pass


def _kernel(create: bool = True) -> tuple[Kernel, Any, Any]:
    state_dir = Path(os.environ.get("STATE_DIR", ""))
    if not str(state_dir):
        raise ValueError("STATE_DIR is required")
    state_dir.mkdir(parents=True, exist_ok=True)
    binary = os.environ.get("IK_BINARY") or str(ROOT / "KIT" / "bin" / "ik")
    python = sys.executable
    store = state_dir / _STATE_FILE
    if not store.exists() and not create:
        raise DomainError("unknown_booking")
    kernel = Kernel(store, binary=binary, timeout=15.0)
    machine = kernel.reducer("clinic_reducer:ClinicReducer", python=python)
    if not store.exists():
        aggregate = machine.create("clinic")
    else:
        aggregate = machine.show("clinic")
    return kernel, machine, aggregate


def _state(aggregate: Any) -> Mapping[str, Any]:
    value = aggregate.state
    return value if isinstance(value, Mapping) else {"slots": {}, "bookings": {}}


def _booking(aggregate: Any, booking_id: str) -> Mapping[str, Any]:
    if not _valid_id(booking_id):
        raise DomainError("bad_args")
    row = _state(aggregate).get("bookings", {}).get(booking_id)
    if not isinstance(row, Mapping):
        raise DomainError("unknown_booking")
    return row


class DomainError(Exception):
    def __init__(self, code: str):
        self.code = code


def _execute(aggregate: Any, name: str, args: Mapping[str, Any]) -> Any:
    result = aggregate.execute({"name": name, "args": dict(args)})
    if isinstance(result, HistoricalResult):
        return aggregate.show()
    return result


def _normal_booking(booking_id: str, row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "booking_id": booking_id,
        "slot_id": row.get("slot_id"),
        "patient_id": row.get("patient_id"),
        "address": row.get("address"),
        "state": row.get("state"),
        "reminder": row.get("reminder"),
        "request_id": row.get("request_id"),
    }


def _service_payload(booking_id: str, row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "request_id": booking_id,
        "slot_id": row["slot_id"],
        "patient_id": row["patient_id"],
        "address": row["address"],
        "kind": "appointment_reminder",
    }


def _matches(value: Any, expected: Mapping[str, Any]) -> bool:
    return isinstance(value, Mapping) and all(value.get(k) == v for k, v in expected.items()) and value.get("outcome") == "accepted"


def _mark_sent(kernel: Kernel, machine: Any, aggregate: Any, booking_id: str, crash_after_record: bool) -> dict[str, Any]:
    result = _execute(aggregate, "mark_sent", {"booking_id": booking_id, "request_id": booking_id})
    current = result.show() if isinstance(result, HistoricalResult) else result
    row = _booking(current, booking_id)
    if crash_after_record:
        _die_at("after-record-before-exit")
    return {
        "booking_id": booking_id,
        "slot_id": row["slot_id"],
        "patient_id": row["patient_id"],
        "address": row["address"],
        "reminder": "sent",
        "request_id": booking_id,
    }


def add_slot(args: list[str]) -> dict[str, Any]:
    if len(args) != 2:
        raise DomainError("bad_args")
    slot_id, start_text = args
    if not _valid_id(slot_id):
        raise DomainError("bad_args")
    try:
        start_ms = _parse_ms(start_text)
    except ValueError:
        raise DomainError("bad_args")
    kernel, machine, aggregate = _kernel()
    try:
        result = _execute(aggregate, "add_slot", {"slot_id": slot_id, "start_ms": start_ms})
        row = _state(result)["slots"][slot_id]
        return {"slot_id": slot_id, "start_ms": row["start_ms"], "availability": "open"}
    finally:
        kernel.close()


def book(args: list[str]) -> dict[str, Any]:
    if len(args) != 5:
        raise DomainError("bad_args")
    slot_id, booking_id, patient_id, address, now_text = args
    if not (_valid_id(slot_id) and _valid_id(booking_id) and _valid_id(patient_id) and _valid_address(address)):
        raise DomainError("bad_args")
    try:
        now_ms = _parse_ms(now_text)
    except ValueError:
        raise DomainError("bad_args")
    kernel, machine, aggregate = _kernel()
    try:
        result = _execute(aggregate, "book", {"slot_id": slot_id, "booking_id": booking_id, "patient_id": patient_id, "address": address, "now_ms": now_ms})
        return {**_normal_booking(booking_id, _booking(result, booking_id)), "now_ms": now_ms}
    finally:
        kernel.close()


def reschedule(args: list[str]) -> dict[str, Any]:
    if len(args) != 3:
        raise DomainError("bad_args")
    booking_id, slot_id, now_text = args
    if not (_valid_id(booking_id) and _valid_id(slot_id)):
        raise DomainError("bad_args")
    try:
        now_ms = _parse_ms(now_text)
    except ValueError:
        raise DomainError("bad_args")
    kernel, machine, aggregate = _kernel()
    try:
        result = _execute(aggregate, "reschedule", {"booking_id": booking_id, "new_slot_id": slot_id, "now_ms": now_ms})
        row = _booking(result, booking_id)
        return {"booking_id": booking_id, "slot_id": row["slot_id"], "state": row["state"], "reminder": row["reminder"], "now_ms": now_ms}
    finally:
        kernel.close()


def cancel(args: list[str]) -> dict[str, Any]:
    if len(args) != 2:
        raise DomainError("bad_args")
    booking_id, now_text = args
    if not _valid_id(booking_id):
        raise DomainError("bad_args")
    try:
        now_ms = _parse_ms(now_text)
    except ValueError:
        raise DomainError("bad_args")
    kernel, machine, aggregate = _kernel()
    try:
        result = _execute(aggregate, "cancel", {"booking_id": booking_id, "now_ms": now_ms})
        row = _booking(result, booking_id)
        return {"booking_id": booking_id, "slot_id": row["cancelled_slot_id"], "state": "cancelled", "fee_cents": row["fee_cents"], "now_ms": now_ms}
    finally:
        kernel.close()

def fee_quote(args: list[str]) -> dict[str, Any]:
    if len(args) != 2:
        raise DomainError("bad_args")
    booking_id, now_text = args
    if not _valid_id(booking_id):
        raise DomainError("bad_args")
    try:
        now_ms = _parse_ms(now_text)
    except ValueError:
        raise DomainError("bad_args")
    kernel, machine, aggregate = _kernel(create=False)
    try:
        row = _booking(aggregate, booking_id)
        if row["state"] == "cancelled":
            return {
                "booking_id": booking_id,
                "state": "cancelled",
                "fee_cents": row["fee_cents"],
                "now_ms": now_ms,
            }
        fee_cents = 0 if row["start_ms"] - now_ms >= 172_800_000 else 5_000
        return {
            "booking_id": booking_id,
            "state": "pending",
            "fee_cents": fee_cents,
            "now_ms": now_ms,
        }
    finally:
        kernel.close()


def remind(args: list[str]) -> dict[str, Any]:
    if len(args) != 1:
        raise DomainError("bad_args")
    booking_id = args[0]
    if not _valid_id(booking_id):
        raise DomainError("bad_args")
    kernel, machine, aggregate = _kernel()
    try:
        row = _booking(aggregate, booking_id)
        if row["state"] == "cancelled":
            raise DomainError("already_cancelled")
        if row["reminder"] == "sent":
            return {"booking_id": booking_id, "slot_id": row["slot_id"], "patient_id": row["patient_id"], "address": row["address"], "reminder": "sent", "request_id": row["request_id"]}
        if row["reminder"] == "none":
            aggregate = _execute(aggregate, "save_attempt", {"booking_id": booking_id})
            _die_at("after-attempt-saved-before-request")
            row = _booking(aggregate, booking_id)
        expected = _service_payload(booking_id, row)
        status, body = _json_request("GET", "/v1/requests/" + booking_id)
        if status == 200:
            if not _matches(body, expected):
                raise Conflict()
            return _mark_sent(kernel, machine, aggregate, booking_id, True)
        if status != 404:
            raise ServiceUnavailable()
        payload = json.dumps(expected, separators=(",", ":")).encode("utf-8")
        status, body = _json_request("POST", "/v1/messages", payload)
        if status == 409:
            raise Conflict()
        if status != 200:
            raise ServiceUnavailable()
        if not _matches(body, expected):
            raise Conflict()
        _die_at("after-accept-before-record")
        return _mark_sent(kernel, machine, aggregate, booking_id, True)
    finally:
        kernel.close()


def reconcile(args: list[str]) -> dict[str, Any]:
    if len(args) != 1:
        raise DomainError("bad_args")
    booking_id = args[0]
    if not _valid_id(booking_id):
        raise DomainError("bad_args")
    kernel, machine, aggregate = _kernel()
    try:
        row = _booking(aggregate, booking_id)
        if row["state"] == "cancelled":
            raise DomainError("already_cancelled")
        if row["reminder"] == "none":
            return {"booking_id": booking_id, "reminder": "none", "request_id": None}
        if row["reminder"] == "sent":
            return {"booking_id": booking_id, "slot_id": row["slot_id"], "patient_id": row["patient_id"], "address": row["address"], "reminder": "sent", "request_id": row["request_id"]}
        expected = _service_payload(booking_id, row)
        status, body = _json_request("GET", "/v1/requests/" + booking_id)
        if status == 404:
            return {"booking_id": booking_id, "reminder": "not_sent", "request_id": booking_id}
        if status != 200:
            raise ServiceUnavailable()
        if not _matches(body, expected):
            raise Conflict()
        return _mark_sent(kernel, machine, aggregate, booking_id, False)
    finally:
        kernel.close()


def status(args: list[str]) -> dict[str, Any]:
    if len(args) != 1:
        raise DomainError("bad_args")
    booking_id = args[0]
    if not _valid_id(booking_id):
        raise DomainError("bad_args")
    kernel, machine, aggregate = _kernel()
    try:
        row = _booking(aggregate, booking_id)
        slot_id = row["slot_id"]
        start_ms = row["start_ms"] if row["state"] == "pending" else None
        return {"booking_id": booking_id, "slot_id": slot_id, "start_ms": start_ms, "patient_id": row["patient_id"], "address": row["address"], "state": row["state"], "reminder": row["reminder"], "request_id": row["request_id"], "cancelled_slot_id": row.get("cancelled_slot_id"), "now_ms": 0}
    finally:
        kernel.close()


def callback(args: list[str]) -> dict[str, Any]:
    if len(args) != 1:
        raise DomainError("bad_args")
    try:
        value = json.loads(Path(args[0]).read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        raise DomainError("bad_args")
    if not isinstance(value, Mapping) or not _REQUIRED_CALLBACK.issubset(value):
        raise DomainError("bad_args")
    if not (
        isinstance(value.get("callback_id"), str) and bool(value.get("callback_id"))
        and _valid_id(value.get("request_id"))
        and _valid_id(value.get("slot_id"))
        and _valid_id(value.get("patient_id"))
        and _valid_address(value.get("address"))
        and value.get("kind") == "appointment_reminder"
        and value.get("outcome") in {"accepted", "rejected"}
    ):
        raise DomainError("bad_args")
    return {"callback_id": value["callback_id"], "request_id": value["request_id"], "ignored": True}


def _parse_ms(value: str) -> int:
    if not isinstance(value, str) or not (value == "0" or (value.isdigit() and not value.startswith("0"))):
        raise ValueError()
    parsed = int(value)
    if parsed > 9_999_999_999_999:
        raise ValueError()
    return parsed


def dispatch(argv: list[str]) -> dict[str, Any]:
    if not argv:
        raise DomainError("bad_args")
    commands = {"add-slot": add_slot, "book": book, "reschedule": reschedule, "cancel": cancel, "fee-quote": fee_quote, "remind": remind, "reconcile": reconcile, "status": status, "callback": callback}
    command = commands.get(argv[0])
    if command is None:
        raise DomainError("bad_args")
    return command(argv[1:])


def main(argv: list[str]) -> int:
    try:
        result = dispatch(argv)
    except DomainError as exc:
        print(json.dumps({"error": exc.code}, separators=(",", ":")))
        return 1
    except ServiceUnavailable:
        print(json.dumps({"error": "service_unavailable"}, separators=(",", ":")))
        return 1
    except Conflict:
        print(json.dumps({"error": "conflict"}, separators=(",", ":")))
        return 1
    except KernelError as exc:
        code = exc.code if exc.code in {"bad_args", "unknown_slot", "unknown_booking", "id_in_use", "already_cancelled", "conflict", "service_unavailable", "slot_full"} else "service_unavailable"
        print(json.dumps({"error": code}, separators=(",", ":")))
        return 1
    except (ValueError, OSError):
        print(json.dumps({"error": "bad_args"}, separators=(",", ":")))
        return 1
    print(json.dumps(result, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
