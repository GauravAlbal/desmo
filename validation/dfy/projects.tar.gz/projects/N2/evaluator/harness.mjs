import { spawn } from "node:child_process";
import { mkdtemp, rm, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import assert from "node:assert/strict";

export const CYCLE_MS = 2_592_000_000;
export const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
export const PROJECT_DIR = process.env.PROJECT_DIR;
export const STUB_DIR = process.env.STUB_DIR;
export const OPTS = { timeout: 30000 };

export function nextCycle(anchor, now) {
  if (now < anchor) return anchor;
  return anchor + CYCLE_MS * (Math.floor((now - anchor) / CYCLE_MS) + 1);
}

export function parseOut(stdout) {
  const text = stdout.endsWith("\n") ? stdout.slice(0, -1) : stdout;
  assert.equal(text.includes("\n"), false, "extra stdout: " + JSON.stringify(stdout));
  return JSON.parse(text);
}

export function runDesk(stateDir, serviceUrl, args, now, crash) {
  return new Promise((resolve) => {
    const env = { ...process.env, STATE_DIR: stateDir, SERVICE_URL: serviceUrl };
    delete env.CRASH_AT;
    delete env.NOW_MS;
    if (now !== undefined && now !== null) env.NOW_MS = String(now);
    if (crash) env.CRASH_AT = crash;
    const child = spawn(path.join(PROJECT_DIR, "run"), args, {
      env,
      cwd: PROJECT_DIR,
    });
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => child.kill("SIGKILL"), 8000);
    child.stdout.on("data", (d) => { stdout += d; });
    child.stderr.on("data", (d) => { stderr += d; });
    child.on("close", (code, signal) => {
      clearTimeout(timer);
      resolve({ code, signal, stdout, stderr });
    });
  });
}

export function expectOk(res) {
  assert.equal(res.signal, null, "signal " + res.signal + " " + res.stderr + res.stdout);
  assert.equal(res.code, 0, res.stdout + "\n" + res.stderr);
  return parseOut(res.stdout);
}

export function expectRefuse(res, code) {
  assert.equal(res.signal, null, "signal " + res.signal + " " + res.stdout);
  assert.notEqual(res.code, 0);
  const body = parseOut(res.stdout);
  assert.equal(typeof body.error, "string");
  assert.ok(body.error.length > 0);
  if (code) assert.equal(body.error, code);
  return body;
}

export function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [path.join(STUB_DIR, "server.mjs")], {
      stdio: ["ignore", "pipe", "pipe"],
    });
    let buf = "";
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error("stub did not start: " + buf));
    }, 5000);
    child.stdout.on("data", (d) => {
      buf += d.toString();
      const i = buf.indexOf("\n");
      if (i >= 0) {
        clearTimeout(timer);
        resolve({ child, ...JSON.parse(buf.slice(0, i)) });
      }
    });
    child.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

export async function session(fn) {
  if (!PROJECT_DIR || !STUB_DIR) throw new Error("PROJECT_DIR and STUB_DIR are required");
  const state = await mkdtemp(path.join(tmpdir(), "n2-"));
  const stub = await startStub();
  try {
    await fn({ state, service: stub.service_url, control: stub.control_url });
  } finally {
    stub.child.kill("SIGKILL");
    await rm(state, { recursive: true, force: true });
  }
}

export async function effects(control) {
  const res = await fetch(control + "/effects");
  return res.json();
}

export async function posts(control) {
  const res = await fetch(control + "/posts");
  return res.json();
}

export async function setFault(control, body) {
  const res = await fetch(control + "/fault", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error("fault " + res.status);
  return res.json();
}

export async function accountOf(service, id) {
  const res = await fetch(service + "/v1/accounts/" + id);
  return { status: res.status, body: await res.json() };
}

export async function writeCallback(dir, obj) {
  const file = path.join(dir, "callback.json");
  await writeFile(file, JSON.stringify(obj));
  return file;
}

export async function readText(file) {
  return readFile(file, "utf8");
}
