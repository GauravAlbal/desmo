import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import path from "node:path";
import { readFile } from "node:fs/promises";
import {
  CYCLE_MS, ID_RE, OPTS, nextCycle, session, runDesk, expectOk, expectRefuse,
  effects, posts, setFault, accountOf, writeCallback,
} from "./harness.mjs";

async function openBasic(state, service, account, plan, anchor, now) {
  return expectOk(await runDesk(state, service, ["open", account, plan, String(anchor)], now));
}

test("R1 persistence across restart and kill", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    const opened = await openBasic(state, service, "acct-r1", "basic", 0, 0);
    assert.equal(opened.account_id, "acct-r1");
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    const again = expectOk(await runDesk(state, service, ["status"], 0));
    assert.equal(again.change_id, scheduled.change_id);
    assert.equal(again.to_plan, "plus");
    assert.equal(again.effective_at_ms, CYCLE_MS);
    assert.equal(again.pending, "scheduled");
    const killed = await runDesk(state, service, ["apply"], CYCLE_MS, "after-attempt-saved-before-request");
    assert.equal(killed.signal, "SIGKILL");
    const after = expectOk(await runDesk(state, service, ["status"], CYCLE_MS));
    assert.equal(after.submission, "attempt_saved");
    assert.equal(after.submission_id, after.submission_id);
    assert.match(after.submission_id, ID_RE);
    assert.equal(after.change_id, scheduled.change_id);
    assert.equal(after.to_plan, "plus");
    assert.equal(after.effective_at_ms, CYCLE_MS);
    assert.equal((await effects(control)).count, 0);
  });
});

test("R2 schedule binds the next cycle boundary", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r2", "basic", 0, 0);
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    assert.equal(scheduled.effective_at_ms, nextCycle(0, 0));
    assert.equal(scheduled.to_plan, "plus");
    assert.equal(scheduled.from_plan, "basic");
    assert.match(scheduled.change_id, ID_RE);
    const status = expectOk(await runDesk(state, service, ["status"], 0));
    assert.equal(status.change_id, scheduled.change_id);
    assert.equal(status.effective_at_ms, CYCLE_MS);
    const blocked = await runDesk(state, service, ["schedule", "pro"], 0);
    expectRefuse(blocked, "pending_exists");
    const still = expectOk(await runDesk(state, service, ["status"], 0));
    assert.equal(still.change_id, scheduled.change_id);
    assert.equal(still.to_plan, "plus");
    expectRefuse(await runDesk(state, service, ["schedule", "nope"], 0), "unknown_plan");
    assert.equal((await posts(control)).count, 0);
  });
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r2b", "basic", 0, 0);
    expectRefuse(await runDesk(state, service, ["schedule", "basic"], 0), "same_plan");
    const later = expectOk(await runDesk(state, service, ["schedule", "pro"], CYCLE_MS + 5));
    assert.equal(later.effective_at_ms, nextCycle(0, CYCLE_MS + 5));
    assert.equal(later.effective_at_ms, CYCLE_MS * 2);
    assert.equal((await posts(control)).count, 0);
  });
  await session(async ({ state, service }) => {
    await openBasic(state, service, "acct-r2c", "plus", 5000, 0);
    const early = expectOk(await runDesk(state, service, ["schedule", "pro"], 0));
    assert.equal(early.effective_at_ms, 5000);
  });
});

test("R3 replace supersedes the pending target", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r3", "basic", 0, 0);
    expectRefuse(await runDesk(state, service, ["replace", "plus"], 0), "no_pending");
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    expectRefuse(await runDesk(state, service, ["replace", "plus"], 0), "same_target");
    const replaced = expectOk(await runDesk(state, service, ["replace", "pro"], 0));
    assert.notEqual(replaced.change_id, scheduled.change_id);
    assert.equal(replaced.to_plan, "pro");
    assert.equal(replaced.effective_at_ms, scheduled.effective_at_ms);
    assert.match(replaced.change_id, ID_RE);
    expectRefuse(await runDesk(state, service, ["cancel", scheduled.change_id], 0), "change_mismatch");
    const kept = expectOk(await runDesk(state, service, ["status"], 0));
    assert.equal(kept.change_id, replaced.change_id);
    assert.equal(kept.to_plan, "pro");
    expectRefuse(await runDesk(state, service, ["replace", "plus"], CYCLE_MS), "already_due");
    const due = expectOk(await runDesk(state, service, ["status"], CYCLE_MS));
    assert.equal(due.change_id, replaced.change_id);
    assert.equal(due.to_plan, "pro");
    const killed = await runDesk(state, service, ["apply"], CYCLE_MS, "after-attempt-saved-before-request");
    assert.equal(killed.signal, "SIGKILL");
    expectRefuse(await runDesk(state, service, ["replace", "plus"], CYCLE_MS), "attempt_saved");
    const after = expectOk(await runDesk(state, service, ["status"], CYCLE_MS));
    assert.equal(after.submission, "attempt_saved");
    assert.equal(after.to_plan, "pro");
    assert.equal((await posts(control)).count, 0);
  });
});

test("R4 cancel before send clears the pending change", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r4", "basic", 0, 0);
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    expectRefuse(await runDesk(state, service, ["cancel", "other-id"], 0), "change_mismatch");
    const kept = expectOk(await runDesk(state, service, ["status"], 0));
    assert.equal(kept.change_id, scheduled.change_id);
    const cancelled = expectOk(await runDesk(state, service, ["cancel", scheduled.change_id], CYCLE_MS));
    assert.equal(cancelled.pending, "none");
    assert.equal(cancelled.change_id, scheduled.change_id);
    assert.equal(cancelled.current_plan, "basic");
    expectRefuse(await runDesk(state, service, ["apply"], CYCLE_MS), "no_pending");
    assert.equal((await posts(control)).count, 0);
    const again = expectOk(await runDesk(state, service, ["schedule", "pro"], 0));
    const killed = await runDesk(state, service, ["apply"], again.effective_at_ms, "after-attempt-saved-before-request");
    assert.equal(killed.signal, "SIGKILL");
    expectRefuse(await runDesk(state, service, ["cancel", again.change_id], again.effective_at_ms), "attempt_saved");
    const status = expectOk(await runDesk(state, service, ["status"], again.effective_at_ms));
    assert.equal(status.submission, "attempt_saved");
    assert.equal(status.change_id, again.change_id);
  });
});

test("R5 legitimate progress is not refused", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r5", "basic", 0, 0);
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    const applied = expectOk(await runDesk(state, service, ["apply"], scheduled.effective_at_ms));
    assert.equal(applied.submission, "applied");
    assert.equal(applied.current_plan, "plus");
    assert.equal(applied.applied_plan, "plus");
    assert.equal(applied.submission_id, applied.submission_id);
    const status = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(status.current_plan, "plus");
    assert.equal(status.applied_plan, "plus");
    assert.equal(status.submission, "applied");
    assert.equal(status.pending, "none");
    const acct = await accountOf(service, "acct-r5");
    assert.equal(acct.status, 200);
    assert.equal(acct.body.to_plan, "plus");
    assert.equal(acct.body.submission_id, status.submission_id);
    assert.equal(acct.body.from_plan, "basic");
    const fx = await effects(control);
    assert.equal(fx.count, 1);
    assert.equal(fx.effects[0].submission_id, status.submission_id);
    expectOk(await runDesk(state, service, ["apply"], scheduled.effective_at_ms));
    assert.equal((await effects(control)).count, 1);
    assert.equal((await posts(control)).count, 1);
  });
});

test("R6 callback cannot overwrite an applied plan", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r6", "basic", 0, 0);
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    const applied = expectOk(await runDesk(state, service, ["apply"], scheduled.effective_at_ms));
    const same = {
      callback_id: "cb-1",
      submission_id: applied.submission_id,
      account_id: "acct-r6",
      to_plan: "plus",
      effective_at_ms: scheduled.effective_at_ms,
      outcome: "applied",
    };
    const file = await writeCallback(state, same);
    expectOk(await runDesk(state, service, ["callback", file], scheduled.effective_at_ms));
    expectOk(await runDesk(state, service, ["callback", file], scheduled.effective_at_ms));
    const conflict = await writeCallback(state, { ...same, callback_id: "cb-2", to_plan: "basic", outcome: "rejected" });
    expectOk(await runDesk(state, service, ["callback", conflict], scheduled.effective_at_ms));
    const status = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(status.current_plan, "plus");
    assert.equal(status.applied_plan, "plus");
    assert.equal(status.submission, "applied");
    assert.equal((await effects(control)).count, 1);
    assert.equal((await posts(control)).count, 1);
  });
});

test("R7 apply before the effective time is refused", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r7", "basic", 0, 0);
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    expectRefuse(await runDesk(state, service, ["apply"], 0), "not_due");
    const status = expectOk(await runDesk(state, service, ["status"], 0));
    assert.equal(status.pending, "scheduled");
    assert.equal(status.submission, "none");
    assert.equal(status.change_id, scheduled.change_id);
    assert.equal((await posts(control)).count, 0);
    expectOk(await runDesk(state, service, ["apply"], scheduled.effective_at_ms));
    assert.equal((await effects(control)).count, 1);
  });
});

test("R8 crash before request still completes once", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r8", "basic", 0, 0);
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    const killed = await runDesk(state, service, ["apply"], scheduled.effective_at_ms, "after-attempt-saved-before-request");
    assert.equal(killed.signal, "SIGKILL");
    assert.equal((await effects(control)).count, 0);
    const mid = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(mid.submission, "attempt_saved");
    assert.match(mid.submission_id, ID_RE);
    const applied = expectOk(await runDesk(state, service, ["apply"], scheduled.effective_at_ms));
    assert.equal(applied.submission, "applied");
    assert.equal(applied.submission_id, mid.submission_id);
    assert.equal(applied.current_plan, "plus");
    const fx = await effects(control);
    assert.equal(fx.count, 1);
    assert.equal(fx.effects[0].submission_id, mid.submission_id);
    assert.equal((await posts(control)).count, 1);
  });
});

test("R9 crash after accept reconciles without a second effect", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r9", "basic", 0, 0);
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    const killed = await runDesk(state, service, ["apply"], scheduled.effective_at_ms, "after-accept-before-record");
    assert.equal(killed.signal, "SIGKILL");
    const fx = await effects(control);
    assert.equal(fx.count, 1);
    const mid = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(mid.submission, "attempt_saved");
    assert.equal(mid.submission_id, fx.effects[0].submission_id);
    const applied = expectOk(await runDesk(state, service, ["apply"], scheduled.effective_at_ms));
    assert.equal(applied.submission, "applied");
    assert.equal(applied.current_plan, "plus");
    assert.equal(applied.submission_id, mid.submission_id);
    const after = await effects(control);
    assert.equal(after.count, 1);
    assert.equal(after.effects[0].submission_id, mid.submission_id);
    const sent = await posts(control);
    assert.equal(sent.count, 1);
    assert.equal(sent.posts[0].submission_id, mid.submission_id);
  });
});

test("R10 crash after durable record keeps the outcome", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r10", "basic", 0, 0);
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    const killed = await runDesk(state, service, ["apply"], scheduled.effective_at_ms, "after-record-before-exit");
    assert.equal(killed.signal, "SIGKILL");
    const status = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(status.submission, "applied");
    assert.equal(status.current_plan, "plus");
    expectOk(await runDesk(state, service, ["apply"], scheduled.effective_at_ms));
    assert.equal((await effects(control)).count, 1);
  });
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r10b", "basic", 0, 0);
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "pro"], 0));
    const killed = await runDesk(state, service, ["apply"], scheduled.effective_at_ms, "after-accept-before-record");
    assert.equal(killed.signal, "SIGKILL");
    const mid = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    const rec = await runDesk(state, service, ["reconcile", mid.submission_id], scheduled.effective_at_ms, "after-record-before-exit");
    assert.equal(rec.signal, "SIGKILL");
    const status = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(status.submission, "applied");
    assert.equal(status.current_plan, "pro");
    assert.equal((await effects(control)).count, 1);
    assert.equal((await posts(control)).count, 1);
  });
});

test("R11 lost reply is reconciled without misattribution", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r11", "basic", 0, 0);
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    await setFault(control, { drop_reply: true });
    const lost = await runDesk(state, service, ["apply"], scheduled.effective_at_ms);
    expectRefuse(lost, "service_unavailable");
    const mid = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(mid.submission, "attempt_saved");
    assert.equal(mid.current_plan, "basic");
    assert.match(mid.submission_id, ID_RE);
    const fx = await effects(control);
    assert.equal(fx.count, 1);
    assert.equal(fx.effects[0].submission_id, mid.submission_id);
    await setFault(control, {});
    const rec = expectOk(await runDesk(state, service, ["reconcile", mid.submission_id], scheduled.effective_at_ms));
    assert.equal(rec.lookup, "applied");
    assert.notEqual(rec.lookup, "not_sent");
    const status = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(status.submission, "applied");
    assert.equal(status.current_plan, "plus");
    assert.equal(status.applied_plan, "plus");
    assert.equal(status.submission_id, mid.submission_id);
    assert.equal((await effects(control)).count, 1);
    assert.equal((await posts(control)).count, 1);
  });
});

test("R12 reconcile never posts", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    await openBasic(state, service, "acct-r12", "basic", 0, 0);
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    const killed = await runDesk(state, service, ["apply"], scheduled.effective_at_ms, "after-attempt-saved-before-request");
    assert.equal(killed.signal, "SIGKILL");
    const mid = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    expectRefuse(await runDesk(state, service, ["reconcile", "other-id"], scheduled.effective_at_ms), "submission_mismatch");
    const still = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(still.submission_id, mid.submission_id);
    assert.equal(still.submission, "attempt_saved");
    const rec = expectOk(await runDesk(state, service, ["reconcile", mid.submission_id], scheduled.effective_at_ms));
    assert.equal(rec.lookup, "not_sent");
    assert.equal(rec.submission, "attempt_saved");
    const after = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(after.submission, "attempt_saved");
    assert.equal(after.current_plan, "basic");
    assert.equal((await effects(control)).count, 0);
    assert.equal((await posts(control)).count, 0);
  });
});

test("R13 unrelated writer file is preserved", OPTS, async () => {
  await session(async ({ state, service }) => {
    await openBasic(state, service, "acct-r13", "basic", 0, 0);
    const foreign = path.join(state, "other-writer.txt");
    const writer = spawn(process.execPath, ["-e", "const fs=require('node:fs'); fs.writeFileSync(process.argv[1], process.argv[2]); setInterval(()=>{}, 1000);", foreign, "alpha-from-other-process"], { stdio: "ignore" });
    for (let i = 0; i < 50; i += 1) {
      try {
        const text = await readFile(foreign, "utf8");
        if (text === "alpha-from-other-process") break;
      } catch {}
      await new Promise((r) => setTimeout(r, 20));
    }
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "plus"], 0));
    expectOk(await runDesk(state, service, ["apply"], scheduled.effective_at_ms));
    const text = await readFile(foreign, "utf8");
    assert.equal(text, "alpha-from-other-process");
    const status = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(status.current_plan, "plus");
    writer.kill("SIGKILL");
  });
});

test("R14 success and refusal JSON protocol", OPTS, async () => {
  await session(async ({ state, service }) => {
    const empty = expectOk(await runDesk(state, service, ["status"], 0));
    assert.equal(empty.account_id, null);
    assert.equal(empty.pending, "none");
    assert.equal(empty.submission, "none");
    const opened = expectOk(await runDesk(state, service, ["open", "acct-r14", "basic", "0"], 0));
    assert.equal(opened.account_id, "acct-r14");
    assert.equal(opened.current_plan, "basic");
    expectRefuse(await runDesk(state, service, ["open", "acct-other", "pro", "0"], 0), "already_open");
    const status = expectOk(await runDesk(state, service, ["status"], 0));
    assert.equal(status.account_id, "acct-r14");
    assert.equal(status.current_plan, "basic");
    const quiet = expectOk(await runDesk(state, service, ["status"], 0, "after-accept-before-record"));
    assert.equal(quiet.account_id, "acct-r14");
    const missing = await runDesk(state, service, ["status"]);
    expectRefuse(missing, "missing_clock");
  });
});
