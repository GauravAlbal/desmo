import { readFileSync } from "node:fs";

const text = readFileSync(process.argv[2], "utf8");
const mode = process.argv[3] || "initial";
const ids = ["R1","R2","R3","R4","R5","R6","R7","R8","R9","R10","R11","R12","R13","R14"];
if (mode === "change") ids.push("C1", "C2", "C3");
const seen = {};
const failed = {};
for (const id of ids) seen[id] = "fail";
for (const line of text.split(/\n/)) {
  const match = line.match(/^(not )?ok \d+ - ((?:R|C)\d+)\b/);
  if (!match) continue;
  const id = match[2];
  if (!Object.prototype.hasOwnProperty.call(seen, id)) continue;
  if (match[1]) failed[id] = true;
  else if (!failed[id]) seen[id] = "pass";
}
for (const id of Object.keys(failed)) seen[id] = "fail";
const bad = Object.entries(seen).filter((pair) => pair[1] !== "pass").map((pair) => pair[0]);
const out = { requirements: seen, ok: bad.length === 0 };
process.stdout.write(JSON.stringify(out) + "\n");
process.exit(out.ok ? 0 : 1);
