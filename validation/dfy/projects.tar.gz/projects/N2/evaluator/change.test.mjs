import test from "node:test";
import assert from "node:assert/strict";
import {
  OPTS, session, runDesk, expectOk, expectRefuse, effects, posts,
} from "./harness.mjs";

test("C1 unpaid invoice blocks a new downgrade not an upgrade", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    expectOk(await runDesk(state, service, ["open", "acct-c1", "plus", "0"], 0));
    const invoice = expectOk(await runDesk(state, service, ["invoice", "inv-c1", "2500"], 0));
    assert.equal(invoice.invoice, "unpaid");
    assert.equal(invoice.amount_cents, 2500);
    expectRefuse(await runDesk(state, service, ["schedule", "basic"], 0), "unpaid_downgrade");
    const blocked = expectOk(await runDesk(state, service, ["status"], 0));
    assert.equal(blocked.pending, "none");
    assert.equal(blocked.current_plan, "plus");
    assert.equal(blocked.invoice, "unpaid");
    assert.equal((await posts(control)).count, 0);
    const upgrade = expectOk(await runDesk(state, service, ["schedule", "pro"], 0));
    assert.equal(upgrade.to_plan, "pro");
    assert.equal(upgrade.pending, "scheduled");
    assert.equal((await posts(control)).count, 0);
    assert.equal((await effects(control)).count, 0);
  });
});

test("C2 replace interacts with the unpaid downgrade rule", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    expectOk(await runDesk(state, service, ["open", "acct-c2", "plus", "0"], 0));
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "pro"], 0));
    expectOk(await runDesk(state, service, ["invoice", "inv-c2", "900"], 0));
    expectRefuse(await runDesk(state, service, ["replace", "basic"], 0), "unpaid_downgrade");
    const kept = expectOk(await runDesk(state, service, ["status"], 0));
    assert.equal(kept.change_id, scheduled.change_id);
    assert.equal(kept.to_plan, "pro");
    assert.equal(kept.effective_at_ms, scheduled.effective_at_ms);
    assert.equal(kept.pending, "scheduled");
    assert.equal((await posts(control)).count, 0);
  });
  await session(async ({ state, service, control }) => {
    expectOk(await runDesk(state, service, ["open", "acct-c2b", "plus", "0"], 0));
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "basic"], 0));
    expectOk(await runDesk(state, service, ["invoice", "inv-c2b", "900"], 0));
    const replaced = expectOk(await runDesk(state, service, ["replace", "pro"], 0));
    assert.notEqual(replaced.change_id, scheduled.change_id);
    assert.equal(replaced.to_plan, "pro");
    assert.equal(replaced.effective_at_ms, scheduled.effective_at_ms);
    expectRefuse(await runDesk(state, service, ["cancel", scheduled.change_id], 0), "change_mismatch");
    const kept = expectOk(await runDesk(state, service, ["status"], 0));
    assert.equal(kept.change_id, replaced.change_id);
    assert.equal(kept.to_plan, "pro");
    assert.equal((await posts(control)).count, 0);
  });
});

test("C3 apply of a downgrade waits until the invoice is paid", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    expectOk(await runDesk(state, service, ["open", "acct-c3", "plus", "0"], 0));
    const scheduled = expectOk(await runDesk(state, service, ["schedule", "basic"], 0));
    expectOk(await runDesk(state, service, ["invoice", "inv-c3", "500"], 0));
    expectRefuse(await runDesk(state, service, ["apply"], scheduled.effective_at_ms), "unpaid_downgrade");
    const blocked = expectOk(await runDesk(state, service, ["status"], scheduled.effective_at_ms));
    assert.equal(blocked.submission, "none");
    assert.equal(blocked.pending, "scheduled");
    assert.equal(blocked.to_plan, "basic");
    assert.equal(blocked.current_plan, "plus");
    assert.equal((await posts(control)).count, 0);
    const paid = expectOk(await runDesk(state, service, ["pay", "inv-c3"], scheduled.effective_at_ms));
    assert.equal(paid.invoice, "paid");
    assert.equal((await posts(control)).count, 0);
    const applied = expectOk(await runDesk(state, service, ["apply"], scheduled.effective_at_ms));
    assert.equal(applied.current_plan, "basic");
    assert.equal(applied.submission, "applied");
    assert.equal((await effects(control)).count, 1);
    expectOk(await runDesk(state, service, ["apply"], scheduled.effective_at_ms));
    assert.equal((await effects(control)).count, 1);
    assert.equal((await posts(control)).count, 1);
  });
});
