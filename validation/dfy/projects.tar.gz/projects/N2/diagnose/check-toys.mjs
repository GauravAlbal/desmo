import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");
const project = path.join(root, "controls", "reference-toy-changed");
const stub = path.join(root, "stub");
const kinds = ["lost-reply", "no-incident", "not-sent", "refused-by-rule"];
const modes = ["investigate-only", "authorized-recovery"];
const toys = [
  ["correct", path.join(here, "toys", "correct.mjs"), true],
  ["over-diagnose", path.join(here, "toys", "over-diagnose.mjs"), false],
];

function run(cmd, args) {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, { cwd: root });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => { stdout += d; });
    child.stderr.on("data", (d) => { stderr += d; });
    child.on("close", (code) => resolve({ code, stdout, stderr }));
  });
}

let bad = 0;
for (const kind of kinds) {
  for (const mode of modes) {
    for (const [name, toy, expectOk] of toys) {
      const state = await mkdtemp(path.join(tmpdir(), "n2-state-"));
      const out = await mkdtemp(path.join(tmpdir(), "n2-out-"));
      const made = await run(process.execPath, [
        path.join(here, "incident.mjs"),
        "--project", project,
        "--stub", stub,
        "--state", state,
        "--out", out,
        "--kind", kind,
      ]);
      let pid = 0;
      try {
        if (made.code !== 0) {
          process.stdout.write(name + " " + kind + " " + mode + " SETUP_FAIL " + made.stderr + "\n");
          bad += 1;
          continue;
        }
        pid = JSON.parse(made.stdout).pid;
        const toyRun = await run(process.execPath, [toy, path.join(out, "ground.json"), mode, out]);
        if (name === "correct" && toyRun.code !== 0) {
          process.stdout.write("correct toy failed " + kind + " " + mode + " " + toyRun.stderr + toyRun.stdout + "\n");
          bad += 1;
          continue;
        }
        const checked = await run(process.execPath, [
          path.join(here, "diagnose-eval.mjs"),
          "--ground", path.join(out, "ground.json"),
          "--diagnosis", path.join(out, "diagnosis.json"),
          "--mode", mode,
        ]);
        const passed = checked.code === 0;
        const ok = passed === expectOk;
        if (!ok) {
          bad += 1;
          process.stdout.write("MISMATCH " + name + " " + kind + " " + mode + " eval=" + checked.stdout.trim() + "\n");
        } else {
          process.stdout.write("ok " + name + " " + kind + " " + mode + "\n");
        }
      } finally {
        if (pid) {
          try { process.kill(pid, "SIGKILL"); } catch {}
        }
        await rm(state, { recursive: true, force: true });
        await rm(out, { recursive: true, force: true });
      }
    }
  }
}
process.exit(bad === 0 ? 0 : 1);
