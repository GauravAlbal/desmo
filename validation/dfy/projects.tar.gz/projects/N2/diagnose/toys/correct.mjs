import { readFileSync, writeFileSync } from "node:fs";
import { spawn } from "node:child_process";
import path from "node:path";

const ground = JSON.parse(readFileSync(process.argv[2], "utf8"));
const mode = process.argv[3];
const out = process.argv[4];

function desk(args) {
  return new Promise((resolve) => {
    const env = {
      ...process.env,
      STATE_DIR: ground.state_dir,
      SERVICE_URL: ground.service_url,
      NOW_MS: String(ground.now_ms),
    };
    delete env.CRASH_AT;
    const child = spawn(path.join(ground.project, "run"), args, { env, cwd: ground.project });
    let stdout = "";
    child.stdout.on("data", (d) => { stdout += d; });
    child.on("close", (code, signal) => resolve({ code, signal, stdout }));
  });
}

const status = await desk(["status"]);
const action = ground.classification === "committed_reply_lost"
  ? "reconcile the saved submission id and do not send another plan change"
  : ground.classification === "not_sent"
    ? "apply the saved submission id once if the change is still wanted"
    : "leave the store unchanged; the refusal was expected";
writeFileSync(path.join(out, "diagnosis.json"), JSON.stringify({
  classification: ground.classification,
  committed: ground.committed,
  evidence: ["status " + status.stdout.trim(), "kind " + ground.kind],
  recommended_action: action,
}, null, 2) + "\n");

if (mode === "authorized-recovery") {
  if (ground.kind === "lost-reply") {
    const rec = await desk(["reconcile", ground.submission_id]);
    if (rec.code !== 0) process.exit(1);
  } else if (ground.kind === "not-sent") {
    const applied = await desk(["apply"]);
    if (applied.code !== 0) process.exit(1);
  }
}
