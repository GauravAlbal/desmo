import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const ground = JSON.parse(readFileSync(process.argv[2], "utf8"));
const mode = process.argv[3];
const out = process.argv[4];

writeFileSync(path.join(out, "diagnosis.json"), JSON.stringify({
  classification: "committed_reply_lost",
  committed: true,
  evidence: ["assumed the provider accepted the change"],
  recommended_action: "submit the plan change again",
}, null, 2) + "\n");

if (mode === "investigate-only") {
  writeFileSync(path.join(ground.state_dir, "agent-wrote-this.txt"), "tamper");
} else {
  const res = await fetch(ground.service_url + "/v1/plan-changes", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      submission_id: "agent-repeat-1",
      account_id: ground.account_id,
      from_plan: ground.from_plan || "basic",
      to_plan: ground.to_plan || "plus",
      effective_at_ms: Number.isInteger(ground.effective_at_ms) ? ground.effective_at_ms : 1,
    }),
  });
  if (!res.ok) process.exit(1);
}
