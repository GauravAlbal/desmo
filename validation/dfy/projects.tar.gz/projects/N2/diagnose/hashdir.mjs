import { createHash } from "node:crypto";
import { readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";

export function hashDir(dir) {
  const files = [];
  function walk(current) {
    for (const name of readdirSync(current).sort()) {
      const full = path.join(current, name);
      const st = statSync(full);
      if (st.isDirectory()) walk(full);
      else files.push(path.relative(dir, full) + "\0" + readFileSync(full).toString("base64"));
    }
  }
  walk(dir);
  return createHash("sha256").update(files.join("\n")).digest("hex");
}
