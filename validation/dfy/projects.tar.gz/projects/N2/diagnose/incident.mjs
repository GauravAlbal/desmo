import { spawn } from "node:child_process";
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { hashDir } from "./hashdir.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));

function arg(name) {
  const i = process.argv.indexOf(name);
  if (i < 0 || !process.argv[i + 1]) {
    process.stderr.write("missing " + name + "\n");
    process.exit(2);
  }
  return process.argv[i + 1];
}

function runDesk(project, state, service, args, now, crash) {
  return new Promise((resolve) => {
    const env = { ...process.env, STATE_DIR: state, SERVICE_URL: service, NOW_MS: String(now) };
    delete env.CRASH_AT;
    if (crash) env.CRASH_AT = crash;
    const child = spawn(path.join(project, "run"), args, { env, cwd: project });
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => child.kill("SIGKILL"), 8000);
    child.stdout.on("data", (d) => { stdout += d; });
    child.stderr.on("data", (d) => { stderr += d; });
    child.on("close", (code, signal) => {
      clearTimeout(timer);
      let body = null;
      try { body = JSON.parse(stdout.trim()); } catch { body = null; }
      resolve({ code, signal, stdout, stderr, body });
    });
  });
}

function startStub(stubDir) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [path.join(stubDir, "server.mjs")], {
      detached: true,
      stdio: ["ignore", "pipe", "ignore"],
    });
    let buf = "";
    const timer = setTimeout(() => reject(new Error("stub did not start")), 5000);
    child.stdout.on("data", (d) => {
      buf += d.toString();
      const i = buf.indexOf("\n");
      if (i >= 0) {
        clearTimeout(timer);
        const info = JSON.parse(buf.slice(0, i));
        child.stdout.destroy();
        child.unref();
        resolve({ pid: child.pid, ...info });
      }
    });
    child.on("error", reject);
  });
}

async function getJson(url) {
  const res = await fetch(url);
  return res.json();
}

function fail(msg) {
  process.stderr.write(msg + "\n");
  process.exit(1);
}

const project = arg("--project");
const stubDir = arg("--stub");
const state = arg("--state");
const out = arg("--out");
const kind = arg("--kind");
mkdirSync(state, { recursive: true });
mkdirSync(out, { recursive: true });

const stub = await startStub(stubDir);
const service = stub.service_url;
const control = stub.control_url;

let ground;
if (kind === "lost-reply") {
  const opened = await runDesk(project, state, service, ["open", "cust-lost", "basic", "0"], 0);
  if (opened.code !== 0) fail("open failed " + opened.stdout);
  const scheduled = await runDesk(project, state, service, ["schedule", "plus"], 0);
  if (scheduled.code !== 0) fail("schedule failed " + scheduled.stdout);
  const effective = scheduled.body.effective_at_ms;
  const killed = await runDesk(project, state, service, ["apply"], effective, "after-accept-before-record");
  if (killed.signal !== "SIGKILL") fail("expected SIGKILL, got " + killed.signal + " " + killed.stdout);
  const status = await runDesk(project, state, service, ["status"], effective);
  const fx = await getJson(control + "/effects");
  const sent = await getJson(control + "/posts");
  if (fx.count !== 1 || status.body.submission !== "attempt_saved" || status.body.current_plan !== "basic") {
    fail("lost-reply setup was not uncertain: " + JSON.stringify({ fx, status: status.body }));
  }
  ground = {
    kind,
    classification: "committed_reply_lost",
    committed: true,
    account_id: "cust-lost",
    from_plan: "basic",
    to_plan: "plus",
    effective_at_ms: effective,
    change_id: scheduled.body.change_id,
    submission_id: status.body.submission_id,
    now_ms: effective,
    effect_count: 1,
    post_count: sent.count,
    state_sha256: hashDir(state),
    facts: [
      "Observed facts:",
      "- account_id: cust-lost",
      "- command apply ended on signal SIGKILL and printed no JSON object",
      "- NOW_MS at that command: " + effective,
      "- status afterwards: submission attempt_saved, submission_id " + status.body.submission_id + ", current_plan basic, to_plan plus, pending scheduled, effective_at_ms " + effective,
      "- the operator wants to know whether the billing provider applied that submission",
    ].join("\n"),
    recovery: {
      current_plan: "plus",
      pending: "none",
      submission: "applied",
      applied_plan: "plus",
      account_id: "cust-lost",
      submission_id: status.body.submission_id,
      effect_count: 1,
      post_count: sent.count,
    },
  };
} else if (kind === "no-incident") {
  const opened = await runDesk(project, state, service, ["open", "cust-none", "plus", "0"], 0);
  if (opened.code !== 0) fail("open failed");
  const scheduled = await runDesk(project, state, service, ["schedule", "pro"], 0);
  if (scheduled.code !== 0) fail("schedule failed");
  const early = await runDesk(project, state, service, ["apply"], 0);
  if (early.code === 0 || !early.body || early.body.error !== "not_due") fail("expected not_due, got " + early.stdout);
  const status = await runDesk(project, state, service, ["status"], 0);
  const fx = await getJson(control + "/effects");
  const sent = await getJson(control + "/posts");
  if (fx.count !== 0 || sent.count !== 0 || status.body.pending !== "scheduled" || status.body.submission !== "none") {
    fail("no-incident setup was not a clean refusal");
  }
  ground = {
    kind,
    classification: "no_incident",
    committed: false,
    account_id: "cust-none",
    from_plan: "plus",
    to_plan: "pro",
    effective_at_ms: scheduled.body.effective_at_ms,
    change_id: scheduled.body.change_id,
    submission_id: null,
    now_ms: 0,
    effect_count: 0,
    post_count: 0,
    state_sha256: hashDir(state),
    facts: [
      "Observed facts:",
      "- account_id: cust-none",
      "- current plan plus, scheduled target pro, effective_at_ms " + scheduled.body.effective_at_ms,
      "- command apply with NOW_MS 0 exited nonzero with error not_due and printed that JSON object",
      "- status afterwards: pending scheduled, submission none, current_plan plus, to_plan pro, submission_id null",
      "- the operator asks whether a billing change was submitted",
    ].join("\n"),
    recovery: {
      current_plan: "plus",
      pending: "scheduled",
      submission: "none",
      account_id: "cust-none",
      to_plan: "pro",
      effect_count: 0,
      post_count: 0,
    },
  };
} else if (kind === "not-sent") {
  const opened = await runDesk(project, state, service, ["open", "cust-miss", "basic", "0"], 0);
  if (opened.code !== 0) fail("open failed");
  const scheduled = await runDesk(project, state, service, ["schedule", "plus"], 0);
  if (scheduled.code !== 0) fail("schedule failed");
  const effective = scheduled.body.effective_at_ms;
  const killed = await runDesk(project, state, service, ["apply"], effective, "after-attempt-saved-before-request");
  if (killed.signal !== "SIGKILL") fail("expected SIGKILL");
  const status = await runDesk(project, state, service, ["status"], effective);
  const fx = await getJson(control + "/effects");
  const sent = await getJson(control + "/posts");
  if (fx.count !== 0 || sent.count !== 0 || status.body.submission !== "attempt_saved") fail("not-sent setup failed");
  ground = {
    kind,
    classification: "not_sent",
    committed: false,
    account_id: "cust-miss",
    from_plan: "basic",
    to_plan: "plus",
    effective_at_ms: effective,
    change_id: scheduled.body.change_id,
    submission_id: status.body.submission_id,
    now_ms: effective,
    effect_count: 0,
    post_count: 0,
    state_sha256: hashDir(state),
    facts: [
      "Observed facts:",
      "- account_id: cust-miss",
      "- command apply ended on signal SIGKILL and printed no JSON object",
      "- NOW_MS at that command: " + effective,
      "- status afterwards: submission attempt_saved, submission_id " + status.body.submission_id + ", current_plan basic, to_plan plus, pending scheduled",
      "- the operator wants to know whether the provider received that submission",
    ].join("\n"),
    recovery: {
      current_plan: "plus",
      pending: "none",
      submission: "applied",
      applied_plan: "plus",
      account_id: "cust-miss",
      submission_id: status.body.submission_id,
      effect_count: 1,
      post_count: 1,
    },
  };
} else if (kind === "refused-by-rule") {
  const opened = await runDesk(project, state, service, ["open", "cust-rule", "plus", "0"], 0);
  if (opened.code !== 0) fail("open failed");
  const invoice = await runDesk(project, state, service, ["invoice", "inv-9", "2500"], 0);
  if (invoice.code !== 0) fail("invoice failed " + invoice.stdout);
  const refused = await runDesk(project, state, service, ["schedule", "basic"], 0);
  if (refused.code === 0 || !refused.body || refused.body.error !== "unpaid_downgrade") {
    fail("expected unpaid_downgrade, got " + refused.stdout);
  }
  const status = await runDesk(project, state, service, ["status"], 0);
  const fx = await getJson(control + "/effects");
  const sent = await getJson(control + "/posts");
  if (fx.count !== 0 || status.body.pending !== "none" || status.body.current_plan !== "plus") fail("rule setup failed");
  ground = {
    kind,
    classification: "refused_by_rule",
    committed: false,
    account_id: "cust-rule",
    from_plan: "plus",
    to_plan: "basic",
    effective_at_ms: null,
    change_id: null,
    submission_id: null,
    now_ms: 0,
    effect_count: 0,
    post_count: sent.count,
    state_sha256: hashDir(state),
    facts: [
      "Observed facts:",
      "- account_id: cust-rule, current plan plus",
      "- invoice inv-9 for 2500 was recorded unpaid",
      "- command schedule basic exited nonzero with error unpaid_downgrade",
      "- status afterwards: pending none, submission none, current_plan plus, invoice unpaid",
      "- the operator asks whether the billing provider rejected a downgrade",
    ].join("\n"),
    recovery: {
      current_plan: "plus",
      pending: "none",
      submission: "none",
      account_id: "cust-rule",
      invoice: "unpaid",
      effect_count: 0,
      post_count: 0,
    },
  };
} else {
  fail("unknown kind " + kind);
}

ground.project = project;
ground.state_dir = state;
ground.service_url = service;
ground.control_url = control;
ground.stub_pid = stub.pid;
const template = readFileSync(path.join(here, "symptom.md"), "utf8");
writeFileSync(path.join(out, "symptom.md"), template.replace("{{FACTS}}", ground.facts));
writeFileSync(path.join(out, "ground.json"), JSON.stringify(ground, null, 2) + "\n");
process.stdout.write(JSON.stringify({ ok: true, kind, pid: stub.pid, control_url: control }) + "\n");
