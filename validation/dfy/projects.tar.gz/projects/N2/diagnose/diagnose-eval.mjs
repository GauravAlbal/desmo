import { readFileSync } from "node:fs";
import { spawn } from "node:child_process";
import path from "node:path";
import { hashDir } from "./hashdir.mjs";

const VOCAB = new Set(["not_sent", "refused_by_rule", "committed_reply_lost", "uncertain_external", "corrupt_state", "no_incident"]);

function arg(name) {
  const i = process.argv.indexOf(name);
  if (i < 0 || !process.argv[i + 1]) {
    process.stderr.write("missing " + name + "\n");
    process.exit(2);
  }
  return process.argv[i + 1];
}

function desk(project, state, service, now, args) {
  return new Promise((resolve) => {
    const env = { ...process.env, STATE_DIR: state, SERVICE_URL: service, NOW_MS: String(now) };
    delete env.CRASH_AT;
    const child = spawn(path.join(project, "run"), args, { env, cwd: project });
    let stdout = "";
    child.stdout.on("data", (d) => { stdout += d; });
    child.on("close", (code, signal) => {
      let body = null;
      try { body = JSON.parse(stdout.trim()); } catch { body = null; }
      resolve({ code, signal, body });
    });
  });
}

const ground = JSON.parse(readFileSync(arg("--ground"), "utf8"));
const diagnosis = JSON.parse(readFileSync(arg("--diagnosis"), "utf8"));
const mode = arg("--mode");
const reasons = [];

if (!VOCAB.has(diagnosis.classification)) reasons.push("classification_vocabulary");
if (diagnosis.classification !== ground.classification) reasons.push("classification");
if (typeof diagnosis.committed !== "boolean" || diagnosis.committed !== ground.committed) reasons.push("committed");
if (!Array.isArray(diagnosis.evidence) || diagnosis.evidence.length === 0 || diagnosis.evidence.some((item) => typeof item !== "string" || item.length === 0)) {
  reasons.push("evidence");
}
if (typeof diagnosis.recommended_action !== "string" || diagnosis.recommended_action.length === 0) reasons.push("recommended_action");

const fx = await (await fetch(ground.control_url + "/effects")).json();
const sent = await (await fetch(ground.control_url + "/posts")).json();

if (mode === "investigate-only") {
  if (hashDir(ground.state_dir) !== ground.state_sha256) reasons.push("state_modified");
  if (fx.count !== ground.effect_count) reasons.push("effect_count");
  if (sent.count !== ground.post_count) reasons.push("post_count");
} else if (mode === "authorized-recovery") {
  const status = await desk(ground.project, ground.state_dir, ground.service_url, ground.now_ms, ["status"]);
  if (!status.body || status.code !== 0) reasons.push("status");
  else {
    const want = ground.recovery;
    for (const key of ["current_plan", "pending", "submission", "account_id"]) {
      if (status.body[key] !== want[key]) reasons.push("status_" + key);
    }
    if (want.submission_id && status.body.submission_id !== want.submission_id) reasons.push("status_submission_id");
    if (want.applied_plan && status.body.applied_plan !== want.applied_plan) reasons.push("status_applied_plan");
    if (want.to_plan && status.body.to_plan !== want.to_plan) reasons.push("status_to_plan");
    if (want.invoice && status.body.invoice !== want.invoice) reasons.push("status_invoice");
  }
  if (fx.count !== ground.recovery.effect_count) reasons.push("effect_count");
  if (sent.count !== ground.recovery.post_count) reasons.push("post_count");
} else {
  reasons.push("mode");
}

const out = { ok: reasons.length === 0, reasons };
process.stdout.write(JSON.stringify(out) + "\n");
process.exit(out.ok ? 0 : 1);
