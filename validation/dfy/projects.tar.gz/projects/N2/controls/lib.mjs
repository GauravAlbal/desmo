import { randomBytes } from "node:crypto";
import { closeSync, fsyncSync, mkdirSync, openSync, readFileSync, renameSync, writeSync, existsSync } from "node:fs";
import path from "node:path";

const CYCLE_MS = 2592000000;
const RANK = { basic: 1, plus: 2, pro: 3 };
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const INT_RE = /^(0|[1-9][0-9]*)$/;
const FILE = "plan-desk.json";

let defect = "none";

function finish(code, obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(code);
}

function ok(obj) {
  finish(0, obj);
}

function refuse(error) {
  finish(1, { error });
}

function crashIf(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
    for (;;) {}
  }
}

function now() {
  const raw = process.env.NOW_MS;
  if (raw === undefined || raw === "") refuse("missing_clock");
  if (!INT_RE.test(raw)) refuse("bad_clock");
  const n = Number(raw);
  if (!Number.isSafeInteger(n)) refuse("bad_clock");
  return n;
}

function statePath() {
  if (!process.env.STATE_DIR) refuse("bad_args");
  return path.join(process.env.STATE_DIR, FILE);
}

function empty() {
  return {
    account_id: null,
    current_plan: null,
    cycle_anchor_ms: null,
    change_id: null,
    from_plan: null,
    to_plan: null,
    effective_at_ms: null,
    pending: "none",
    submission: "none",
    submission_id: null,
    applied_plan: null,
    invoice_id: null,
    invoice: "none",
    amount_cents: null,
    transport_failed: false,
  };
}

function load() {
  const file = statePath();
  if (!existsSync(file)) return empty();
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(file, "utf8"));
  } catch {
    refuse("corrupt_state");
  }
  return Object.assign(empty(), parsed);
}

function commit(state) {
  const dir = process.env.STATE_DIR;
  mkdirSync(dir, { recursive: true });
  const file = path.join(dir, FILE);
  const tmp = path.join(dir, ".plan-desk.json.tmp");
  const fd = openSync(tmp, "w");
  writeSync(fd, JSON.stringify(state));
  fsyncSync(fd);
  closeSync(fd);
  renameSync(tmp, file);
  const dfd = openSync(dir, "r");
  try { fsyncSync(dfd); } catch { /* directory sync is best-effort */ }
  closeSync(dfd);
}

function newId() {
  return randomBytes(8).toString("hex");
}

function changed() {
  return defect !== "initial";
}

function publicView(state) {
  const view = {
    account_id: state.account_id,
    current_plan: state.current_plan,
    cycle_anchor_ms: state.cycle_anchor_ms,
    change_id: state.change_id,
    from_plan: state.from_plan,
    to_plan: state.to_plan,
    effective_at_ms: state.effective_at_ms,
    pending: state.pending,
    submission: state.submission,
    submission_id: state.submission_id,
    applied_plan: state.applied_plan,
  };
  if (changed()) {
    view.invoice_id = state.invoice_id;
    view.invoice = state.invoice;
    view.amount_cents = state.amount_cents;
  }
  return view;
}

function nextCycle(anchor, clock) {
  if (clock < anchor) return anchor;
  return anchor + CYCLE_MS * (Math.floor((clock - anchor) / CYCLE_MS) + 1);
}

function requireOpen(state) {
  if (!state.account_id) refuse("not_open");
}

function serviceBase() {
  const url = process.env.SERVICE_URL;
  if (!url) refuse("bad_args");
  return url;
}

function blocked(kind, state, target) {
  if (!changed()) return false;
  if (state.invoice !== "unpaid") return false;
  if (RANK[target] >= RANK[state.current_plan]) return false;
  if (defect === "unpaid-replace" && kind === "replace") return false;
  if (defect === "unpaid-apply" && kind === "apply") return false;
  return true;
}

function openAccount(account, plan, anchorRaw) {
  const state = load();
  if (state.account_id) refuse("already_open");
  if (!ID_RE.test(account)) refuse("bad_args");
  if (!RANK[plan]) refuse("unknown_plan");
  if (!INT_RE.test(anchorRaw)) refuse("bad_args");
  const anchor = Number(anchorRaw);
  if (!Number.isSafeInteger(anchor)) refuse("bad_args");
  state.account_id = account;
  state.current_plan = plan;
  state.cycle_anchor_ms = anchor;
  commit(state);
  ok({
    account_id: account,
    current_plan: plan,
    cycle_anchor_ms: anchor,
    pending: "none",
    submission: "none",
  });
}

function schedule(plan) {
  const state = load();
  requireOpen(state);
  if (!RANK[plan]) refuse("unknown_plan");
  if (plan === state.current_plan) refuse("same_plan");
  if (state.pending === "scheduled") refuse("pending_exists");
  if (blocked("schedule", state, plan)) refuse("unpaid_downgrade");
  const effective = nextCycle(state.cycle_anchor_ms, now());
  if (!Number.isSafeInteger(effective)) refuse("bad_clock");
  state.change_id = newId();
  state.from_plan = state.current_plan;
  state.to_plan = plan;
  state.effective_at_ms = effective;
  state.pending = "scheduled";
  state.submission = "none";
  state.submission_id = null;
  state.applied_plan = null;
  commit(state);
  ok({
    change_id: state.change_id,
    account_id: state.account_id,
    from_plan: state.from_plan,
    to_plan: state.to_plan,
    effective_at_ms: state.effective_at_ms,
    pending: "scheduled",
    submission: "none",
    submission_id: null,
  });
}

function replace(plan) {
  const state = load();
  requireOpen(state);
  if (state.pending !== "scheduled") refuse("no_pending");
  if (state.submission !== "none") refuse("attempt_saved");
  if (now() >= state.effective_at_ms) refuse("already_due");
  if (!RANK[plan]) refuse("unknown_plan");
  if (plan === state.current_plan) refuse("same_plan");
  if (plan === state.to_plan) refuse("same_target");
  if (blocked("replace", state, plan)) refuse("unpaid_downgrade");
  state.change_id = newId();
  state.to_plan = plan;
  commit(state);
  ok({
    change_id: state.change_id,
    account_id: state.account_id,
    from_plan: state.from_plan,
    to_plan: state.to_plan,
    effective_at_ms: state.effective_at_ms,
    pending: "scheduled",
    submission: "none",
    submission_id: null,
  });
}

function cancel(id) {
  const state = load();
  requireOpen(state);
  if (state.pending !== "scheduled") refuse("no_pending");
  if (state.submission !== "none") refuse("attempt_saved");
  if (id !== state.change_id) refuse("change_mismatch");
  const cancelled = state.change_id;
  state.pending = "none";
  state.change_id = null;
  state.from_plan = null;
  state.to_plan = null;
  state.effective_at_ms = null;
  commit(state);
  ok({
    account_id: state.account_id,
    change_id: cancelled,
    current_plan: state.current_plan,
    pending: "none",
    submission: "none",
  });
}

function appliedObject(state, extra) {
  return Object.assign({
    account_id: state.account_id,
    change_id: state.change_id,
    submission_id: state.submission_id,
    from_plan: state.from_plan,
    to_plan: state.to_plan,
    effective_at_ms: state.effective_at_ms,
    current_plan: state.current_plan,
    pending: state.pending,
    submission: state.submission,
    applied_plan: state.applied_plan,
  }, extra || {});
}

function matches(state, body) {
  return body
    && body.outcome === "applied"
    && body.submission_id === state.submission_id
    && body.account_id === state.account_id
    && body.to_plan === state.to_plan
    && body.effective_at_ms === state.effective_at_ms;
}

function adopt(state, body) {
  if (!matches(state, body)) refuse("lookup_conflict");
  const changedOutcome = state.submission !== "applied";
  state.current_plan = state.to_plan;
  state.applied_plan = state.to_plan;
  state.pending = "none";
  state.submission = "applied";
  state.transport_failed = false;
  commit(state);
  if (changedOutcome) crashIf("after-record-before-exit");
  ok(appliedObject(state));
}

async function lookup(id) {
  try {
    const res = await fetch(serviceBase() + "/v1/submissions/" + id);
    const text = await res.text();
    let body = null;
    try { body = JSON.parse(text); } catch { body = null; }
    return { status: res.status, body };
  } catch {
    return { status: 0, body: null };
  }
}

async function postSaved(state) {
  let res;
  try {
    res = await fetch(serviceBase() + "/v1/plan-changes", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        submission_id: state.submission_id,
        account_id: state.account_id,
        from_plan: state.from_plan,
        to_plan: state.to_plan,
        effective_at_ms: state.effective_at_ms,
      }),
    });
  } catch {
    if (defect === "lost-reply-misattribution") {
      state.transport_failed = true;
      commit(state);
    }
    refuse("service_unavailable");
  }
  const text = await res.text();
  if (!res.ok) refuse("service_unavailable");
  let body;
  try { body = JSON.parse(text); } catch { refuse("service_unavailable"); }
  crashIf("after-accept-before-record");
  adopt(state, body);
}

async function apply() {
  const state = load();
  requireOpen(state);
  if (state.submission === "applied" && state.pending === "none") {
    ok(appliedObject(state));
  }
  if (state.submission === "none") {
    if (state.pending !== "scheduled") refuse("no_pending");
    if (now() < state.effective_at_ms) refuse("not_due");
    if (blocked("apply", state, state.to_plan)) refuse("unpaid_downgrade");
    state.submission_id = newId();
    state.submission = "attempt_saved";
    state.transport_failed = false;
    commit(state);
    crashIf("after-attempt-saved-before-request");
  }
  if (state.submission !== "attempt_saved") refuse("no_pending");
  const looked = await lookup(state.submission_id);
  if (looked.status === 200) {
    if (defect === "duplicate-effect") {
      state.submission_id = newId();
      state.submission = "attempt_saved";
      commit(state);
      await postSaved(state);
      return;
    }
    adopt(state, looked.body);
  }
  if (looked.status === 404) {
    await postSaved(state);
    return;
  }
  refuse("service_unavailable");
}

async function reconcile(id) {
  const state = load();
  if (!state.submission_id) refuse("no_attempt");
  if (id !== state.submission_id) refuse("submission_mismatch");
  if (state.submission === "applied") {
    ok(appliedObject(state, { lookup: "applied" }));
  }
  if (state.submission !== "attempt_saved") refuse("no_attempt");
  if (defect === "lost-reply-misattribution" && state.transport_failed) {
    ok({
      lookup: "not_sent",
      submission_id: state.submission_id,
      change_id: state.change_id,
      pending: state.pending,
      submission: state.submission,
    });
  }
  const looked = await lookup(id);
  if (looked.status === 404) {
    ok({
      lookup: "not_sent",
      submission_id: state.submission_id,
      change_id: state.change_id,
      pending: state.pending,
      submission: "attempt_saved",
    });
  }
  if (looked.status === 200) {
    const before = state.submission;
    if (!matches(state, looked.body)) refuse("lookup_conflict");
    const changedOutcome = before !== "applied";
    state.current_plan = state.to_plan;
    state.applied_plan = state.to_plan;
    state.pending = "none";
    state.submission = "applied";
    state.transport_failed = false;
    commit(state);
    if (changedOutcome) crashIf("after-record-before-exit");
    ok(appliedObject(state, { lookup: "applied" }));
  }
  refuse("service_unavailable");
}

function callback(file) {
  let body;
  try {
    body = JSON.parse(readFileSync(file, "utf8"));
  } catch {
    refuse("bad_callback");
  }
  if (!body || typeof body !== "object") refuse("bad_callback");
  for (const key of ["callback_id", "submission_id", "account_id", "to_plan", "effective_at_ms", "outcome"]) {
    if (body[key] === undefined || body[key] === null) refuse("bad_callback");
  }
  if (body.outcome !== "applied" && body.outcome !== "rejected") refuse("bad_callback");
  const state = load();
  if (defect === "late-overwrite" && state.submission === "applied" && body.to_plan !== state.applied_plan) {
    state.current_plan = body.to_plan;
    state.applied_plan = body.to_plan;
    commit(state);
  }
  ok({ callback: "accepted" });
}

function invoice(id, amountRaw) {
  if (!changed()) refuse("unknown_command");
  const state = load();
  requireOpen(state);
  if (!ID_RE.test(id)) refuse("bad_args");
  if (!INT_RE.test(amountRaw)) refuse("bad_amount");
  const amount = Number(amountRaw);
  if (!Number.isSafeInteger(amount) || amount < 1 || amount > 100000000) refuse("bad_amount");
  if (state.invoice === "unpaid") refuse("invoice_exists");
  state.invoice_id = id;
  state.invoice = "unpaid";
  state.amount_cents = amount;
  commit(state);
  ok({ invoice_id: id, amount_cents: amount, invoice: "unpaid" });
}

function pay(id) {
  if (!changed()) refuse("unknown_command");
  const state = load();
  if (state.invoice === "none") refuse("no_invoice");
  if (id !== state.invoice_id) refuse("invoice_mismatch");
  state.invoice = "paid";
  commit(state);
  ok({ invoice_id: id, amount_cents: state.amount_cents, invoice: "paid" });
}

function status() {
  ok(publicView(load()));
}

export async function main(kind, args) {
  defect = kind;
  if (defect === "always-refuse") refuse("refused");
  now();
  if (!process.env.SERVICE_URL) refuse("bad_args");
  const [cmd, ...rest] = args;
  if (cmd === "open" && rest.length === 3) openAccount(rest[0], rest[1], rest[2]);
  else if (cmd === "schedule" && rest.length === 1) schedule(rest[0]);
  else if (cmd === "replace" && rest.length === 1) replace(rest[0]);
  else if (cmd === "cancel" && rest.length === 1) cancel(rest[0]);
  else if (cmd === "apply" && rest.length === 0) await apply();
  else if (cmd === "reconcile" && rest.length === 1) await reconcile(rest[0]);
  else if (cmd === "status" && rest.length === 0) status();
  else if (cmd === "callback" && rest.length === 1) callback(rest[0]);
  else if (cmd === "invoice" && rest.length === 2) invoice(rest[0], rest[1]);
  else if (cmd === "pay" && rest.length === 1) pay(rest[0]);
  else if (cmd === "invoice" || cmd === "pay") refuse("bad_args");
  else refuse("unknown_command");
}
