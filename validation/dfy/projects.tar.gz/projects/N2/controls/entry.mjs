import { main } from "./lib.mjs";
await main(process.argv[2], process.argv.slice(3));
