# Freeze

This directory is the experiment material for one local subscription plan-change scheduler. Builders receive `brief.md` plus `stub/server.mjs` and `stub/CONTRACT.md`. A later maintainer receives `change.md`. The acceptance harness is `evaluator/`. The diagnosis materials are `diagnose/`. The controls are not implementations to copy.

`reference-toy` passes the initial suite only to prove the harness can pass. `reference-toy-changed` passes the initial suite and the change suite. Neither is a model solution. A failing control proves only that the check can detect that defect. It does not prove the check detects every other defect, and a pass does not prove the control is otherwise correct.

`evaluator/run.sh` scores R1-R14. `evaluator/run-change.sh` scores R1-R14 and C1-C3. Both print one JSON object `{"requirements":{"R1":"pass"|"fail",...},"ok":true|false}`.

Set `PROJECT_DIR` to the directory that contains `run`, and `STUB_DIR` to `stub/`. The checker uses `node --test`.

## Requirement ids

- R1 Persistence across process restart, including an attempt record after SIGKILL
- R2 Schedule binds the next cycle boundary and refuses a second pending schedule
- R3 Replace supersedes the pending target and change id
- R4 Cancel before send clears the pending change
- R5 Legitimate progress is not refused, and a second apply does not send again
- R6 A callback cannot overwrite an applied plan or add an effect
- R7 Apply before the effective time is refused, and a later apply succeeds
- R8 Crash before the request still completes with one effect and the same submission id
- R9 Crash after accept is recovered without a second effect or a different submission id
- R10 Crash after the durable record keeps the outcome and does not add an effect
- R11 Lost reply is reconciled by lookup and is not reported as not_sent
- R12 Reconcile never posts; a 404 lookup is not_sent; a wrong id is refused
- R13 An unrelated writer file in STATE_DIR is preserved
- R14 Success and refusal are one JSON object, and one account is bound
- C1 An unpaid invoice blocks a new downgrade and does not block an upgrade
- C2 Replace of a pending upgrade with a downgrade is refused while unpaid; replace of a pending downgrade with an upgrade is allowed
- C3 Apply of a pending downgrade is refused while unpaid, and succeeds once after pay

## Crash points

Honored only when the running command reaches the boundary. Otherwise the command must not kill itself. The kill is SIGKILL.

- `after-attempt-saved-before-request`: on `apply`, after the attempt record is committed, before any byte of the plan-change HTTP request is sent. Not on a retry that finds the attempt already saved.
- `after-accept-before-record`: on `apply`, after the complete HTTP response body has been read, before the durable applied outcome is committed. Not on a lookup of an acceptance from an earlier process.
- `after-record-before-exit`: on `apply` or `reconcile`, after this invocation commits the applied outcome, before the success JSON is written.

The clock is `NOW_MS`, a canonical integer. Cycle length is `2592000000` milliseconds. The next boundary is computed only at `schedule`. `replace` keeps that effective time.

## Diagnosis

`diagnose/incident.mjs` drives only `./run` and the stub control port. It leaves the stub running and writes `ground.json` plus a filled `symptom.md`. Kinds: `lost-reply` (`committed_reply_lost`), `no-incident` (`no_incident`, the expected-refusal control), `not-sent`, `refused-by-rule`. `diagnose/expected.md` is for the evaluator only. `diagnose/diagnose-eval.mjs` checks `diagnosis.json` and, by mode, either an unchanged store with no new POST, or the safe recovery in `expected.md`.

`diagnose/check-toys.mjs` runs that checker against `toys/correct.mjs` and `toys/over-diagnose.mjs`. Observed: all 16 rows matched (correct passes, over-diagnose fails) for both modes of all four kinds.

## Deliberate ambiguities

- stderr is unconstrained.
- Extra JSON fields are allowed. Initial `status` is not required to omit the invoice fields added by the change.
- Refusal exit status is any nonzero. The reference uses 1.
- Change ids and submission ids are only constrained to 1-64 characters from `A-Za-z0-9._-`. The tool chooses them.
- After a dropped reply, `apply` must exit nonzero `service_unavailable`, leave `attempt_saved`, and must not adopt the acceptance in that same invocation. `reconcile` is the required recovery command.
- A well-formed callback may be ignored. It must not change an applied plan and must not add an effect. It must not by itself mark `applied`.
- No numeric HTTP timeout is specified. A closed connection must make the command return rather than send a new submission id.
- HTTP 5xx and hold are specified and not separately scored.
- Overlapping `./run` processes are unsupported and unspecified.
- A second plan change after one has been applied is allowed by the command rules and is not separately scored.
- Store filename and encoding are internal, provided committed records survive SIGKILL and unrelated files are left alone.
- If both `not_due` and `unpaid_downgrade` could apply, `not_due` wins. The unpaid apply gate is only for a due change with no saved attempt.
- The unpaid gate does not block lookup adoption of an effect that already happened.
- `uncertain_external` and `corrupt_state` are in the diagnosis vocabulary and are not produced by the bundled incidents.

## Control-run table

Observed with `PROJECT_DIR` set to each control and `STUB_DIR` set to `stub/`.

| Control | `run.sh` failed | `run-change.sh` failed |
| --- | --- | --- |
| reference-toy | none | C1 C2 C3 |
| reference-toy-changed | none | none |
| late-overwrite | R6 | R6 |
| duplicate-effect | R9 | R9 |
| lost-reply-misattribution | R11 | R11 |
| always-refuse | R1-R14 | R1-R14 C1-C3 |
| unpaid-replace | none | C2 |
| unpaid-apply | none | C3 |

`unpaid-replace` implements the unpaid gate on `schedule` and `apply` but not on `replace`, so a pending upgrade can be overwritten by a downgrade. `unpaid-apply` implements the gate on `schedule` and `replace` but not on `apply`, so a due downgrade is sent while the invoice is unpaid. Those two rows are how C2 and C3 are shown to be separate checks. `always-refuse` fails every id because each check includes a successful action; it does not, by itself, show that R6 detects a late overwrite. That isolation is the `late-overwrite` row.
