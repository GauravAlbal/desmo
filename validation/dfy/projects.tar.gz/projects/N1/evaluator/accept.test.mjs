import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { readFileSync } from "node:fs";
import path from "node:path";
import { desk, session, effects, traffic, setFault, forOrder, OPTS } from "./harness.mjs";

test("R1 persistence across restart", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r1", "2500"]);
    assert.equal(rec.code, 0);
    assert.equal(rec.body.amount_cents, 2500);
    const ship = await desk(ctx.stateDir, ctx.service, ["ship", "ord-r1"]);
    assert.equal(ship.code, 0);
    const again = await desk(ctx.stateDir, ctx.service, ["status", "ord-r1"]);
    assert.equal(again.code, 0);
    assert.equal(again.body.order_id, "ord-r1");
    assert.equal(again.body.amount_cents, 2500);
    assert.equal(again.body.shipment, "shipped");
    assert.equal(again.body.refund, "none");
    assert.equal(again.body.refunded_cents, 0);
  });
});

test("R2 record is local and stable", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r2", "1800"]);
    assert.equal(rec.code, 0);
    const same = await desk(ctx.stateDir, ctx.service, ["record", "ord-r2", "1800"]);
    assert.equal(same.code, 0);
    assert.equal(same.body.amount_cents, 1800);
    const clash = await desk(ctx.stateDir, ctx.service, ["record", "ord-r2", "1900"]);
    assert.notEqual(clash.code, 0);
    assert.equal(clash.body.error, "conflict");
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-r2"]);
    assert.equal(st.code, 0);
    assert.equal(st.body.amount_cents, 1800);
    assert.equal(st.body.refund, "none");
    const seen = await traffic(ctx.control);
    assert.equal(seen.requests.length, 0);
  });
});

test("R3 shipment blocks a new refund", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r3", "3200"]);
    assert.equal(rec.code, 0);
    const ship = await desk(ctx.stateDir, ctx.service, ["ship", "ord-r3"]);
    assert.equal(ship.code, 0);
    assert.equal(ship.body.shipment, "shipped");
    const again = await desk(ctx.stateDir, ctx.service, ["ship", "ord-r3"]);
    assert.equal(again.code, 0);
    const cancel = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r3"]);
    assert.notEqual(cancel.code, 0);
    assert.equal(cancel.body.error, "shipped");
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-r3"]);
    assert.equal(st.body.shipment, "shipped");
    assert.equal(st.body.refund, "none");
    assert.equal(st.body.refund_id, null);
    const seen = await traffic(ctx.control);
    assert.equal(seen.requests.length, 0);
    const fx = await effects(ctx.control);
    assert.equal(fx.count, 0);
  });
});

test("R4 one full refund", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r4", "4400"]);
    assert.equal(rec.code, 0);
    const cancel = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r4"]);
    assert.equal(cancel.code, 0);
    assert.equal(cancel.body.refund, "refunded");
    assert.equal(cancel.body.refunded_cents, 4400);
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-r4"]);
    assert.equal(st.code, 0);
    assert.equal(st.body.refund, "refunded");
    assert.equal(st.body.refunded_cents, 4400);
    assert.equal(typeof st.body.refund_id, "string");
    const fx = await effects(ctx.control);
    const rows = forOrder(fx, "ord-r4");
    assert.equal(rows.length, 1);
    assert.equal(rows[0].amount_cents, 4400);
    assert.equal(rows[0].currency, "USD");
    assert.equal(rows[0].refund_id, st.body.refund_id);
  });
});

test("R5 legitimate progress is not refused", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r5", "1500"]);
    assert.equal(rec.code, 0);
    const cancel = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r5"]);
    assert.equal(cancel.code, 0);
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-r5"]);
    assert.equal(st.code, 0);
    assert.equal(st.body.refund, "refunded");
  });
});

test("R6 cancel after refund is idempotent", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r6", "2700"]);
    assert.equal(rec.code, 0);
    const first = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r6"]);
    assert.equal(first.code, 0);
    const before = await desk(ctx.stateDir, ctx.service, ["status", "ord-r6"]);
    const second = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r6"]);
    assert.equal(second.code, 0);
    const after = await desk(ctx.stateDir, ctx.service, ["status", "ord-r6"]);
    assert.equal(after.body.refund, "refunded");
    assert.equal(after.body.refund_id, before.body.refund_id);
    assert.equal(after.body.refunded_cents, 2700);
    const fx = await effects(ctx.control);
    assert.equal(forOrder(fx, "ord-r6").length, 1);
    assert.equal(fx.posts, 1);
  });
});

test("R7 reconcile does not send", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r7", "2100"]);
    assert.equal(rec.code, 0);
    const killed = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r7"], "after-attempt-saved-before-request");
    assert.equal(killed.signal, "SIGKILL");
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-r7"]);
    assert.equal(st.code, 0);
    assert.equal(st.body.refund, "attempt_saved");
    assert.equal(typeof st.body.refund_id, "string");
    const recn = await desk(ctx.stateDir, ctx.service, ["reconcile", "ord-r7"]);
    assert.equal(recn.code, 0);
    assert.equal(recn.body.outcome, "not_sent");
    assert.equal(recn.body.refund_id, st.body.refund_id);
    const after = await desk(ctx.stateDir, ctx.service, ["status", "ord-r7"]);
    assert.equal(after.body.refund, "attempt_saved");
    assert.equal(after.body.refund_id, st.body.refund_id);
    const fx = await effects(ctx.control);
    assert.equal(fx.count, 0);
    assert.equal(fx.posts, 0);
  });
});

test("R8 crash after accept", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r8", "3600"]);
    assert.equal(rec.code, 0);
    const killed = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r8"], "after-accept-before-record");
    assert.equal(killed.signal, "SIGKILL");
    const mid = await desk(ctx.stateDir, ctx.service, ["status", "ord-r8"]);
    assert.equal(mid.body.refund, "attempt_saved");
    const saved = mid.body.refund_id;
    assert.equal(typeof saved, "string");
    const fx1 = await effects(ctx.control);
    assert.equal(forOrder(fx1, "ord-r8").length, 1);
    assert.equal(forOrder(fx1, "ord-r8")[0].refund_id, saved);
    const again = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r8"]);
    assert.equal(again.code, 0);
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-r8"]);
    assert.equal(st.body.refund, "refunded");
    assert.equal(st.body.refund_id, saved);
    assert.equal(st.body.refunded_cents, 3600);
    const fx = await effects(ctx.control);
    assert.equal(forOrder(fx, "ord-r8").length, 1);
    assert.equal(fx.posts, 1);
  });
});

test("R9 crash before the request", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r9", "1250"]);
    assert.equal(rec.code, 0);
    const killed = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r9"], "after-attempt-saved-before-request");
    assert.equal(killed.signal, "SIGKILL");
    const mid = await desk(ctx.stateDir, ctx.service, ["status", "ord-r9"]);
    assert.equal(mid.body.refund, "attempt_saved");
    const saved = mid.body.refund_id;
    const fx0 = await effects(ctx.control);
    assert.equal(fx0.count, 0);
    const again = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r9"]);
    assert.equal(again.code, 0);
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-r9"]);
    assert.equal(st.body.refund, "refunded");
    assert.equal(st.body.refund_id, saved);
    assert.equal(st.body.refunded_cents, 1250);
    const fx = await effects(ctx.control);
    assert.equal(forOrder(fx, "ord-r9").length, 1);
    assert.equal(fx.posts, 1);
    assert.equal(forOrder(fx, "ord-r9")[0].refund_id, saved);
  });
});

test("R10 crash after the durable record", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r10", "5100"]);
    assert.equal(rec.code, 0);
    const killed = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r10"], "after-record-before-exit");
    assert.equal(killed.signal, "SIGKILL");
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-r10"]);
    assert.equal(st.code, 0);
    assert.equal(st.body.refund, "refunded");
    assert.equal(st.body.refunded_cents, 5100);
    const again = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r10"]);
    assert.equal(again.code, 0);
    const after = await desk(ctx.stateDir, ctx.service, ["status", "ord-r10"]);
    assert.equal(after.body.refund, "refunded");
    assert.equal(after.body.refunded_cents, 5100);
    const fx = await effects(ctx.control);
    assert.equal(forOrder(fx, "ord-r10").length, 1);
    assert.equal(fx.posts, 1);
  });
});

test("R11 orders are independent", OPTS, async () => {
  await session(async (ctx) => {
    const a = await desk(ctx.stateDir, ctx.service, ["record", "ord-a", "1000"]);
    const b = await desk(ctx.stateDir, ctx.service, ["record", "ord-b", "2000"]);
    assert.equal(a.code, 0);
    assert.equal(b.code, 0);
    const ship = await desk(ctx.stateDir, ctx.service, ["ship", "ord-a"]);
    assert.equal(ship.code, 0);
    const cancel = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-b"]);
    assert.equal(cancel.code, 0);
    const sa = await desk(ctx.stateDir, ctx.service, ["status", "ord-a"]);
    const sb = await desk(ctx.stateDir, ctx.service, ["status", "ord-b"]);
    assert.equal(sa.body.shipment, "shipped");
    assert.equal(sa.body.refund, "none");
    assert.equal(sa.body.amount_cents, 1000);
    assert.equal(sb.body.refund, "refunded");
    assert.equal(sb.body.refunded_cents, 2000);
    const fx = await effects(ctx.control);
    assert.equal(forOrder(fx, "ord-a").length, 0);
    assert.equal(forOrder(fx, "ord-b").length, 1);
    assert.equal(forOrder(fx, "ord-b")[0].amount_cents, 2000);
  });
});

test("R12 result protocol", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r12", "900"]);
    assert.equal(rec.code, 0);
    assert.equal(typeof rec.body, "object");
    assert.equal(rec.body.order_id, "ord-r12");
    const missing = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-missing"]);
    assert.notEqual(missing.code, 0);
    assert.equal(missing.body.error, "unknown_order");
    const fx = await effects(ctx.control);
    assert.equal(fx.posts, 0);
  });
});

test("R13 unrelated writer file is preserved", OPTS, async () => {
  await session(async (ctx) => {
    const marker = path.join(ctx.stateDir, "unrelated-marker.txt");
    await new Promise((resolve, reject) => {
      const writer = spawn(process.execPath, ["-e", "require('fs').writeFileSync(process.argv[1], 'keep-me')", marker], { stdio: "ignore" });
      writer.on("close", (code) => code === 0 ? resolve() : reject(new Error("writer " + code)));
    });
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r13", "640"]);
    assert.equal(rec.code, 0);
    const cancel = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r13"]);
    assert.equal(cancel.code, 0);
    assert.equal(readFileSync(marker, "utf8"), "keep-me");
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-r13"]);
    assert.equal(st.body.refund, "refunded");
  });
});

test("R14 lost reply is reconciled", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-r14", "2750"]);
    assert.equal(rec.code, 0);
    await setFault(ctx.control, { drop_reply: true, delay_ms: 0, status_5xx: false, callback: null });
    const cancel = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-r14"]);
    const fx1 = await effects(ctx.control);
    assert.equal(forOrder(fx1, "ord-r14").length, 1);
    assert.equal(fx1.posts, 1);
    const saved = forOrder(fx1, "ord-r14")[0].refund_id;
    await setFault(ctx.control, { drop_reply: false, delay_ms: 0, status_5xx: false, callback: null });
    const recn = await desk(ctx.stateDir, ctx.service, ["reconcile", "ord-r14"]);
    assert.equal(recn.code, 0);
    assert.equal(recn.body.outcome, "refunded");
    assert.notEqual(recn.body.outcome, "not_sent");
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-r14"]);
    assert.equal(st.body.refund, "refunded");
    assert.equal(st.body.refund_id, saved);
    assert.equal(st.body.refunded_cents, 2750);
    const fx = await effects(ctx.control);
    assert.equal(forOrder(fx, "ord-r14").length, 1);
    assert.equal(fx.posts, 1);
    assert.equal(cancel.signal, null);
  });
});
