import { spawn } from "node:child_process";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";

export const PROJECT_DIR = process.env.PROJECT_DIR;
export const STUB_DIR = process.env.STUB_DIR;
export const OPTS = { timeout: 20000 };

export function desk(stateDir, serviceUrl, args, crash) {
  return new Promise((resolve) => {
    const env = {
      PATH: process.env.PATH,
      HOME: process.env.HOME || "",
      STATE_DIR: stateDir,
      SERVICE_URL: serviceUrl,
    };
    if (crash) env.CRASH_AT = crash;
    const child = spawn(path.join(PROJECT_DIR, "run"), args, { env });
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => child.kill("SIGKILL"), 8000);
    child.stdout.on("data", (d) => { stdout += d; });
    child.stderr.on("data", (d) => { stderr += d; });
    child.on("close", (code, signal) => {
      clearTimeout(timer);
      let body = null;
      if (signal == null) {
        try { body = JSON.parse(stdout); } catch { body = null; }
      }
      resolve({ code, signal, stdout, stderr, body });
    });
  });
}

export function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ["server.mjs"], {
      cwd: STUB_DIR,
      stdio: ["ignore", "pipe", "pipe"],
    });
    let buf = "";
    let err = "";
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error("stub start timeout " + err));
    }, 5000);
    child.stderr.on("data", (d) => { err += d; });
    child.stdout.on("data", (d) => {
      buf += d.toString();
      const nl = buf.indexOf("\n");
      if (nl >= 0) {
        clearTimeout(timer);
        resolve({ child, info: JSON.parse(buf.slice(0, nl)) });
      }
    });
    child.on("error", (e) => {
      clearTimeout(timer);
      reject(e);
    });
  });
}

export async function session(fn) {
  if (!PROJECT_DIR) throw new Error("PROJECT_DIR is required");
  if (!STUB_DIR) throw new Error("STUB_DIR is required");
  const stub = await startStub();
  const stateDir = mkdtempSync(path.join(tmpdir(), "n1-"));
  try {
    await fn({
      stateDir,
      service: stub.info.service_url,
      control: stub.info.control_url,
    });
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(stateDir, { recursive: true, force: true });
  }
}

export async function effects(control) {
  const res = await fetch(control + "/effects");
  if (res.status !== 200) throw new Error("effects " + res.status);
  return await res.json();
}

export async function traffic(control) {
  const res = await fetch(control + "/traffic");
  if (res.status !== 200) throw new Error("traffic " + res.status);
  return await res.json();
}

export async function setFault(control, body) {
  const res = await fetch(control + "/fault", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  if (res.status !== 200) throw new Error("fault " + res.status);
}

export function forOrder(fx, orderId) {
  return fx.effects.filter((row) => row.order_id === orderId);
}

export function writeLines(dir, name, obj) {
  const file = path.join(dir, name);
  writeFileSync(file, JSON.stringify(obj));
  return file;
}
