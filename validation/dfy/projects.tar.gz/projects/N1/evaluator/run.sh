#!/bin/sh
set -u
HERE=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
TAP=$(mktemp)
node --test --test-reporter=tap "$HERE/accept.test.mjs" >"$TAP" 2>"$TAP.err" || true
node "$HERE/summarize.mjs" "$TAP" R1 R2 R3 R4 R5 R6 R7 R8 R9 R10 R11 R12 R13 R14
rc=$?
rm -f "$TAP" "$TAP.err"
exit "$rc"
