import test from "node:test";
import assert from "node:assert/strict";
import { writeFileSync } from "node:fs";
import path from "node:path";
import { desk, session, effects, traffic, setFault, forOrder, writeLines, OPTS } from "./harness.mjs";

test("C1 attach lines", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-c1", "8000"]);
    assert.equal(rec.code, 0);
    const file = writeLines(ctx.stateDir, "lines.json", {
      cap_cents: 4000,
      lines: [
        { line_id: "sku-a", price_cents: 3000 },
        { line_id: "sku-b", price_cents: 5000 },
      ],
    });
    const attached = await desk(ctx.stateDir, ctx.service, ["attach", "ord-c1", file]);
    assert.equal(attached.code, 0);
    assert.equal(attached.body.cap_cents, 4000);
    writeFileSync(file, JSON.stringify({ cap_cents: 100, lines: [{ line_id: "other", price_cents: 8000 }] }));
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-c1"]);
    assert.equal(st.code, 0);
    assert.equal(st.body.cap_cents, 4000);
    assert.deepEqual(st.body.lines, [
      { line_id: "sku-a", price_cents: 3000, refund: "none" },
      { line_id: "sku-b", price_cents: 5000, refund: "none" },
    ]);
    const other = path.join(ctx.stateDir, "other.json");
    writeFileSync(other, JSON.stringify({
      cap_cents: 8000,
      lines: [{ line_id: "sku-a", price_cents: 8000 }],
    }));
    const clash = await desk(ctx.stateDir, ctx.service, ["attach", "ord-c1", other]);
    assert.notEqual(clash.code, 0);
    assert.equal(clash.body.error, "conflict");
    const after = await desk(ctx.stateDir, ctx.service, ["status", "ord-c1"]);
    assert.equal(after.body.cap_cents, 4000);
    assert.equal(after.body.lines.length, 2);
    const seen = await traffic(ctx.control);
    assert.equal(seen.requests.length, 0);
  });
});

test("C2 line refund stays inside the cap and happens once", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-c2", "8000"]);
    assert.equal(rec.code, 0);
    const file = writeLines(ctx.stateDir, "lines.json", {
      cap_cents: 3000,
      lines: [
        { line_id: "big", price_cents: 6000 },
        { line_id: "small", price_cents: 2000 },
      ],
    });
    const attached = await desk(ctx.stateDir, ctx.service, ["attach", "ord-c2", file]);
    assert.equal(attached.code, 0);
    const over = await desk(ctx.stateDir, ctx.service, ["refund", "ord-c2", "big"]);
    assert.notEqual(over.code, 0);
    assert.equal(over.body.error, "over_cap");
    const st0 = await desk(ctx.stateDir, ctx.service, ["status", "ord-c2"]);
    assert.equal(st0.body.refund, "none");
    assert.equal(st0.body.refund_id, null);
    const fx0 = await effects(ctx.control);
    assert.equal(fx0.count, 0);
    const ok = await desk(ctx.stateDir, ctx.service, ["refund", "ord-c2", "small"]);
    assert.equal(ok.code, 0);
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-c2"]);
    assert.equal(st.body.refunded_cents, 2000);
    assert.equal(st.body.lines.find((line) => line.line_id === "small").refund, "refunded");
    assert.equal(st.body.lines.find((line) => line.line_id === "big").refund, "none");
    const again = await desk(ctx.stateDir, ctx.service, ["refund", "ord-c2", "small"]);
    assert.notEqual(again.code, 0);
    assert.equal(again.body.error, "already_refunded");
    const fx = await effects(ctx.control);
    const rows = forOrder(fx, "ord-c2");
    assert.equal(rows.length, 1);
    assert.equal(rows[0].amount_cents, 2000);
    assert.equal(fx.posts, 1);
  });
});

test("C3 open submission blocks other lines and counts against the cap", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-open", "2000"]);
    assert.equal(rec.code, 0);
    const file = writeLines(ctx.stateDir, "open.json", {
      cap_cents: 2000,
      lines: [
        { line_id: "a", price_cents: 1000 },
        { line_id: "b", price_cents: 1000 },
      ],
    });
    assert.equal((await desk(ctx.stateDir, ctx.service, ["attach", "ord-open", file])).code, 0);
    const killed = await desk(ctx.stateDir, ctx.service, ["refund", "ord-open", "a"], "after-attempt-saved-before-request");
    assert.equal(killed.signal, "SIGKILL");
    const mid = await desk(ctx.stateDir, ctx.service, ["status", "ord-open"]);
    const saved = mid.body.refund_id;
    const blocked = await desk(ctx.stateDir, ctx.service, ["refund", "ord-open", "b"]);
    assert.notEqual(blocked.code, 0);
    assert.equal(blocked.body.error, "refund_open");
    const still = await desk(ctx.stateDir, ctx.service, ["status", "ord-open"]);
    assert.equal(still.body.refund_id, saved);
    const fx0 = await effects(ctx.control);
    assert.equal(fx0.posts, 0);
    assert.equal(fx0.count, 0);
    const retry = await desk(ctx.stateDir, ctx.service, ["refund", "ord-open", "a"]);
    assert.equal(retry.code, 0);
    const done = await desk(ctx.stateDir, ctx.service, ["status", "ord-open"]);
    assert.equal(done.body.refund_id, saved);
    assert.equal(done.body.refunded_cents, 1000);
    const fx1 = await effects(ctx.control);
    assert.equal(forOrder(fx1, "ord-open").length, 1);
    assert.equal(forOrder(fx1, "ord-open")[0].refund_id, saved);

    const rec2 = await desk(ctx.stateDir, ctx.service, ["record", "ord-cap", "4500"]);
    assert.equal(rec2.code, 0);
    const file2 = writeLines(ctx.stateDir, "cap.json", {
      cap_cents: 3000,
      lines: [
        { line_id: "left", price_cents: 2500 },
        { line_id: "right", price_cents: 2000 },
      ],
    });
    assert.equal((await desk(ctx.stateDir, ctx.service, ["attach", "ord-cap", file2])).code, 0);
    await setFault(ctx.control, { drop_reply: true, delay_ms: 0, status_5xx: false, callback: null });
    const dropped = await desk(ctx.stateDir, ctx.service, ["refund", "ord-cap", "left"]);
    assert.equal(dropped.signal, null);
    await setFault(ctx.control, { drop_reply: false, delay_ms: 0, status_5xx: false, callback: null });
    const postsAfterDrop = (await effects(ctx.control)).posts;
    const other = await desk(ctx.stateDir, ctx.service, ["refund", "ord-cap", "right"]);
    assert.notEqual(other.code, 0);
    assert.equal(other.body.error, "refund_open");
    assert.equal((await effects(ctx.control)).posts, postsAfterDrop);
    const recn = await desk(ctx.stateDir, ctx.service, ["reconcile", "ord-cap"]);
    assert.equal(recn.code, 0);
    assert.equal(recn.body.outcome, "refunded");
    const adopted = await desk(ctx.stateDir, ctx.service, ["status", "ord-cap"]);
    assert.equal(adopted.body.refunded_cents, 2500);
    assert.equal(adopted.body.lines.find((line) => line.line_id === "left").refund, "refunded");
    const over = await desk(ctx.stateDir, ctx.service, ["refund", "ord-cap", "right"]);
    assert.notEqual(over.code, 0);
    assert.equal(over.body.error, "over_cap");
    const fx = await effects(ctx.control);
    assert.equal(forOrder(fx, "ord-cap").length, 1);
    assert.equal(fx.posts, postsAfterDrop);
  });
});

test("C4 shipping still wins over a remaining cap", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-ship", "2000"]);
    assert.equal(rec.code, 0);
    const file = writeLines(ctx.stateDir, "ship.json", {
      cap_cents: 2000,
      lines: [
        { line_id: "a", price_cents: 1000 },
        { line_id: "b", price_cents: 1000 },
      ],
    });
    assert.equal((await desk(ctx.stateDir, ctx.service, ["attach", "ord-ship", file])).code, 0);
    const ship = await desk(ctx.stateDir, ctx.service, ["ship", "ord-ship"]);
    assert.equal(ship.code, 0);
    const blocked = await desk(ctx.stateDir, ctx.service, ["refund", "ord-ship", "a"]);
    assert.notEqual(blocked.code, 0);
    assert.equal(blocked.body.error, "shipped");
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-ship"]);
    assert.equal(st.body.refund, "none");
    assert.equal(st.body.refund_id, null);
    assert.equal(st.body.shipment, "shipped");
    const seen = await traffic(ctx.control);
    assert.equal(seen.requests.filter((row) => row.method === "POST").length, 0);

    const rec2 = await desk(ctx.stateDir, ctx.service, ["record", "ord-held", "2000"]);
    assert.equal(rec2.code, 0);
    const file2 = writeLines(ctx.stateDir, "held.json", {
      cap_cents: 2000,
      lines: [
        { line_id: "a", price_cents: 1000 },
        { line_id: "b", price_cents: 1000 },
      ],
    });
    assert.equal((await desk(ctx.stateDir, ctx.service, ["attach", "ord-held", file2])).code, 0);
    const refunded = await desk(ctx.stateDir, ctx.service, ["refund", "ord-held", "a"]);
    assert.equal(refunded.code, 0);
    const noship = await desk(ctx.stateDir, ctx.service, ["ship", "ord-held"]);
    assert.notEqual(noship.code, 0);
    assert.equal(noship.body.error, "refund_open");
    const held = await desk(ctx.stateDir, ctx.service, ["status", "ord-held"]);
    assert.equal(held.body.shipment, "open");
    const fx = await effects(ctx.control);
    assert.equal(forOrder(fx, "ord-held").length, 1);
    assert.equal(forOrder(fx, "ord-ship").length, 0);
  });
});

test("C5 cancel the remainder once or not at all", OPTS, async () => {
  await session(async (ctx) => {
    const rec = await desk(ctx.stateDir, ctx.service, ["record", "ord-rest", "5000"]);
    assert.equal(rec.code, 0);
    const file = writeLines(ctx.stateDir, "rest.json", {
      cap_cents: 5000,
      lines: [
        { line_id: "a", price_cents: 3000 },
        { line_id: "b", price_cents: 2000 },
      ],
    });
    assert.equal((await desk(ctx.stateDir, ctx.service, ["attach", "ord-rest", file])).code, 0);
    const first = await desk(ctx.stateDir, ctx.service, ["refund", "ord-rest", "a"]);
    assert.equal(first.code, 0);
    const cancel = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-rest"]);
    assert.equal(cancel.code, 0);
    const st = await desk(ctx.stateDir, ctx.service, ["status", "ord-rest"]);
    assert.equal(st.body.refunded_cents, 5000);
    assert.equal(st.body.lines.every((line) => line.refund === "refunded"), true);
    const fx = await effects(ctx.control);
    const rows = forOrder(fx, "ord-rest");
    assert.equal(rows.length, 2);
    assert.deepEqual(rows.map((row) => row.amount_cents).sort(), [2000, 3000]);
    const again = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-rest"]);
    assert.equal(again.code, 0);
    const fx2 = await effects(ctx.control);
    assert.equal(forOrder(fx2, "ord-rest").length, 2);

    const rec2 = await desk(ctx.stateDir, ctx.service, ["record", "ord-stop", "8000"]);
    assert.equal(rec2.code, 0);
    const file2 = writeLines(ctx.stateDir, "stop.json", {
      cap_cents: 4000,
      lines: [
        { line_id: "a", price_cents: 3000 },
        { line_id: "b", price_cents: 5000 },
      ],
    });
    assert.equal((await desk(ctx.stateDir, ctx.service, ["attach", "ord-stop", file2])).code, 0);
    const part = await desk(ctx.stateDir, ctx.service, ["refund", "ord-stop", "a"]);
    assert.equal(part.code, 0);
    const posts = (await effects(ctx.control)).posts;
    const refused = await desk(ctx.stateDir, ctx.service, ["cancel", "ord-stop"]);
    assert.notEqual(refused.code, 0);
    assert.equal(refused.body.error, "over_cap");
    const stopped = await desk(ctx.stateDir, ctx.service, ["status", "ord-stop"]);
    assert.equal(stopped.body.lines.find((line) => line.line_id === "b").refund, "none");
    assert.equal(stopped.body.refunded_cents, 3000);
    const fx3 = await effects(ctx.control);
    assert.equal(forOrder(fx3, "ord-stop").length, 1);
    assert.equal(fx3.posts, posts);
  });
});
