# Freeze

This directory is the experiment material for one paid-order cancellation desk. Builders receive `brief.md` plus `stub/server.mjs` and `stub/CONTRACT.md`. A later maintainer receives `change.md`. The acceptance harness is `evaluator/`. Diagnosis materials are `diagnose/`. The controls are not implementations to copy.

`reference-toy` passes the initial suite only to prove the harness can pass. `reference-toy-changed` passes the initial suite and the change suite. Neither is a model solution. A failing control proves only that the check can detect that defect. It does not prove the check detects every other defect, and a pass does not prove the control is otherwise correct.

Initial requirements are R1-R14. Change requirements are C1-C5. `evaluator/run.sh` scores R1-R14. `evaluator/run-change.sh` scores R1-R14 and C1-C5. A project that has not applied the change fails C1-C5 and can still pass R1-R14.

## Requirement ids

- R1 Persistence across a new process
- R2 Record is local, idempotent for the same amount, and refuses a different amount
- R3 Shipment blocks a new refund and does not contact the provider
- R4 One full refund of the recorded amount
- R5 Legitimate progress is not refused
- R6 Cancel after refund does not change the outcome or add an effect
- R7 Reconcile after a kill before the request reports not_sent and does not POST
- R8 Crash after accept is recovered with the same refund id and one effect
- R9 Crash before the request still completes with the same refund id and one effect
- R10 Crash after the durable record keeps refunded and a further cancel adds no effect
- R11 Orders are independent
- R12 Success and refusal are one JSON object, and an unknown order is `unknown_order`
- R13 An unrelated writer file in STATE_DIR is preserved
- R14 A dropped reply is reconciled as refunded and is not reported as not_sent
- C1 Attach lines and cap without contacting the provider
- C2 A line refund stays inside the cap and is not repeated
- C3 An open or lost submission blocks every other line and still counts against the cap
- C4 Shipping blocks a fitting line, and a completed line refund blocks shipping
- C5 Cancel refunds only the remainder, or refuses the whole remainder when it exceeds the cap

## Crash points

Honored only when the running command reaches the boundary. Otherwise the command must not kill itself. The kill is SIGKILL.

- `after-attempt-saved-before-request`: on `cancel`, and after the change also on `refund`, after the attempt record is committed, before any byte of the refund HTTP request is sent. Not on a retry that finds the attempt already saved. Not on a lookup.
- `after-accept-before-record`: on `cancel` or `refund`, after the complete HTTP response body has been read, before the durable outcome is committed. Not on a lookup of an acceptance from an earlier process.
- `after-record-before-exit`: on `cancel`, `refund`, or `reconcile`, after this invocation commits `refunded`, before the success JSON is written. Not when this invocation did not commit that outcome.

## Deliberate ambiguities

- stderr is unconstrained.
- Extra JSON fields are allowed. Named `error` codes are not optional when the brief or the change names the code.
- Refund ids are only constrained to 1-64 characters from `A-Za-z0-9._-`. The desk chooses them.
- After a dropped reply, `cancel` or `refund` may return `unavailable` and leave `attempt_saved`, or it may look up the refund id and adopt `refunded` before returning. It must not POST a different refund id. The suite accepts either local state immediately after that command, then requires `reconcile` to report `refunded`.
- No numeric HTTP timeout is specified. A closed connection must make the command return rather than send a new refund id.
- Overlapping `./run` processes are unsupported and unspecified.
- Store filename and encoding are internal, provided committed records survive SIGKILL and unrelated files are left alone.
- HTTP 500 with nothing stored, and a delayed complete response, are specified desk obligations and are not separately scored.
- Provider callbacks are not delivered to the desk. The desk has no callback command. Duplicate and conflicting callbacks are control-port records only.
- Before the change, `status` may omit `cap_cents` and `lines`. After the change, both are required. Initial checks allow extra fields.
- The scored unrelated-writer check creates the file from another process and then runs desk commands. A command that deleted the file and recreated the same bytes before returning would not be distinguished.
- R1's own check is a new process after `record` and `ship` return. SIGKILL survival of a committed attempt or outcome is scored by R7, R8, R9, and R10.
- `late-overwrite` fails both R6 and R10 because both require a later `cancel` to leave a committed refund in place. That is one defect seen by two checks, not two independent defects.

## Control-run table

Observed with `PROJECT_DIR` set to each control and `STUB_DIR` set to `stub/`. Initial column is `evaluator/run.sh`. Change column is `evaluator/run-change.sh`.

| Control | Initial failed ids | Change failed ids |
| --- | --- | --- |
| reference-toy | none | C1 C2 C3 C4 C5 |
| reference-toy-changed | none | none |
| always-refuse | R1-R14 | R1-R14 C1-C5 |
| late-overwrite | R6 R10 | R6 R10 C1-C5 |
| duplicate-effect | R8 | R8 C1-C5 |
| lost-reply-misattribution | R14 | R14 C1-C5 |
| ignores-inflight | none | C3 |

`ignores-inflight` implements the change and then sends a different line while an attempt is open. It passes the initial suite. C1, C2, C4, and C5 pass. C3 fails.

`diagnose/check-toys.mjs` against `controls/reference-toy`: the correct toy passed all six kind/mode pairs. The over-diagnose toy failed `no-incident` / investigate-only on `classification` and `committed`, and failed `reply-lost` / authorized-recovery on `refund`, `refunded_cents`, `effect_count`, and `post_count`. A failing toy proves only that the check can detect that mistake.
