import { randomBytes } from "node:crypto";
import { closeSync, fsyncSync, mkdirSync, openSync, readFileSync, renameSync, writeSync, existsSync } from "node:fs";
import path from "node:path";

const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const LINE_RE = /^[A-Za-z0-9._-]{1,32}$/;

let defect = "none";

function finish(code, obj) {
  writeSync(1, JSON.stringify(obj) + "\n");
  process.exit(code);
}

function ok(obj) {
  finish(0, obj);
}

function refuse(error, extra) {
  finish(1, Object.assign({ error }, extra || {}));
}

function crash(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

function requireStateDir() {
  if (!process.env.STATE_DIR) refuse("missing_state_dir");
  mkdirSync(process.env.STATE_DIR, { recursive: true });
}

function serviceBase() {
  const raw = process.env.SERVICE_URL;
  if (!raw) refuse("missing_service_url");
  return raw.endsWith("/") ? raw.slice(0, -1) : raw;
}

function stateFile() {
  return path.join(process.env.STATE_DIR, "refund-desk.json");
}

function emptyState() {
  return { orders: {} };
}

function load() {
  requireStateDir();
  const file = stateFile();
  if (!existsSync(file)) return emptyState();
  const parsed = JSON.parse(readFileSync(file, "utf8"));
  if (!parsed || typeof parsed !== "object" || !parsed.orders) return emptyState();
  return parsed;
}

function commit(state) {
  requireStateDir();
  const dest = stateFile();
  const tmp = dest + ".tmp";
  const fd = openSync(tmp, "w");
  writeSync(fd, JSON.stringify(state));
  fsyncSync(fd);
  closeSync(fd);
  renameSync(tmp, dest);
  try {
    const dirfd = openSync(process.env.STATE_DIR, "r");
    try {
      fsyncSync(dirfd);
    } finally {
      closeSync(dirfd);
    }
  } catch {
    /* directory fsync is best-effort */
  }
}

function newId() {
  return randomBytes(16).toString("hex");
}

function parseAmount(raw) {
  if (typeof raw !== "string" || !/^[1-9][0-9]{0,8}$/.test(raw)) refuse("bad_amount");
  const n = Number(raw);
  if (n > 100000000) refuse("bad_amount");
  return n;
}

function parseOrderId(raw) {
  if (typeof raw !== "string" || !ID_RE.test(raw)) refuse("bad_id");
  return raw;
}

function blankOrder(orderId, amount) {
  return {
    order_id: orderId,
    amount_cents: amount,
    currency: "USD",
    shipment: "open",
    refund: "none",
    refund_id: null,
    refunded_cents: 0,
    cap_cents: amount,
    lines: [],
    attempt: null,
  };
}

function changedKind() {
  return defect === "reference-changed" || defect === "ignores-inflight";
}

function publicLines(order) {
  return order.lines.map((line) => ({
    line_id: line.line_id,
    price_cents: line.price_cents,
    refund: line.refund,
  }));
}

function statusView(order) {
  const view = {
    order_id: order.order_id,
    amount_cents: order.amount_cents,
    currency: "USD",
    shipment: order.shipment,
    refund: order.refund,
    refund_id: order.attempt ? order.attempt.refund_id : order.refund_id,
    refunded_cents: order.refunded_cents,
  };
  if (changedKind()) {
    view.cap_cents = order.cap_cents;
    view.lines = publicLines(order);
  }
  return view;
}

function successView(order) {
  return {
    order_id: order.order_id,
    amount_cents: order.amount_cents,
    currency: "USD",
    shipment: order.shipment,
    refund: order.refund,
    refund_id: order.refund_id,
    refunded_cents: order.refunded_cents,
  };
}

function reconcileView(order, outcome) {
  return {
    order_id: order.order_id,
    refund: order.refund,
    refund_id: order.attempt ? order.attempt.refund_id : order.refund_id,
    outcome,
    amount_cents: order.amount_cents,
    refunded_cents: order.refunded_cents,
  };
}

function mustOrder(state, orderId) {
  const order = state.orders[orderId];
  if (!order) refuse("unknown_order");
  return order;
}

function sameSet(a, b) {
  if (a.length !== b.length) return false;
  const left = [...a].sort();
  const right = [...b].sort();
  return left.every((value, i) => value === right[i]);
}

async function getJson(url) {
  const res = await fetch(url);
  const text = await res.text();
  let body = null;
  try {
    body = JSON.parse(text);
  } catch {
    body = null;
  }
  return { status: res.status, body };
}

function adopt(state, order) {
  const attempt = order.attempt;
  if (!attempt) refuse("unavailable");
  if (order.lines.length > 0) {
    for (const line of order.lines) {
      if (attempt.line_ids.includes(line.line_id)) line.refund = "refunded";
    }
    order.refunded_cents = order.lines
      .filter((line) => line.refund === "refunded")
      .reduce((sum, line) => sum + line.price_cents, 0);
  } else {
    order.refunded_cents = attempt.amount_cents;
  }
  order.refund_id = attempt.refund_id;
  order.attempt = null;
  order.refund = "refunded";
  commit(state);
}

function finishAdopted(state, order) {
  adopt(state, order);
  crash("after-record-before-exit");
  ok(successView(order));
}

async function postRefund(state, order) {
  const attempt = order.attempt;
  let res;
  try {
    res = await fetch(serviceBase() + "/v1/refunds", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        refund_id: attempt.refund_id,
        order_id: order.order_id,
        amount_cents: attempt.amount_cents,
        currency: "USD",
      }),
    });
  } catch {
    refuse("unavailable");
  }
  const text = await res.text();
  crash("after-accept-before-record");
  let body = null;
  try {
    body = JSON.parse(text);
  } catch {
    body = null;
  }
  if (res.status === 200 && body && body.outcome === "refunded" &&
      body.amount_cents === attempt.amount_cents && body.order_id === order.order_id) {
    finishAdopted(state, order);
  }
  if (res.status >= 500) refuse("unavailable");
  if (res.status === 409) refuse("conflict");
  refuse("unavailable");
}

async function continueSaved(state, order) {
  let lookup;
  try {
    lookup = await getJson(serviceBase() + "/v1/refunds/" + order.attempt.refund_id);
  } catch {
    refuse("unavailable");
  }
  if (lookup.status === 200 && lookup.body &&
      lookup.body.outcome === "refunded" &&
      lookup.body.amount_cents === order.attempt.amount_cents &&
      lookup.body.order_id === order.order_id) {
    if (defect === "duplicate-effect") {
      order.attempt.refund_id = newId();
      order.refund_id = order.attempt.refund_id;
      commit(state);
      await postRefund(state, order);
      return;
    }
    finishAdopted(state, order);
  }
  if (lookup.status === 200) {
    refuse("conflict");
  }
  if (lookup.status === 404) return false;
  refuse("unavailable");
}

async function submitNew(state, order, amount, lineIds) {
  const refundId = newId();
  order.attempt = { refund_id: refundId, amount_cents: amount, line_ids: lineIds };
  order.refund = "attempt_saved";
  order.refund_id = refundId;
  for (const line of order.lines) {
    if (lineIds.includes(line.line_id)) line.refund = "pending";
  }
  commit(state);
  crash("after-attempt-saved-before-request");
  await postRefund(state, order);
}

async function resumeOrPost(state, order) {
  const adopted = await continueSaved(state, order);
  if (adopted === false) await postRefund(state, order);
}

function clearRefund(state, order) {
  order.refund = "none";
  order.refund_id = null;
  order.refunded_cents = 0;
  order.attempt = null;
  for (const line of order.lines) line.refund = "none";
  commit(state);
}

function record(orderId, amountRaw) {
  const id = parseOrderId(orderId);
  const amount = parseAmount(amountRaw);
  const state = load();
  const existing = state.orders[id];
  if (existing) {
    if (existing.amount_cents !== amount) refuse("conflict");
    ok(statusView(existing));
  }
  state.orders[id] = blankOrder(id, amount);
  commit(state);
  ok(statusView(state.orders[id]));
}

function ship(orderId) {
  const id = parseOrderId(orderId);
  const state = load();
  const order = mustOrder(state, id);
  if (order.attempt || order.refund === "attempt_saved" || order.refunded_cents > 0 || order.refund === "refunded") {
    refuse("refund_open");
  }
  order.shipment = "shipped";
  commit(state);
  ok(statusView(order));
}

function status(orderId) {
  const id = parseOrderId(orderId);
  const state = load();
  ok(statusView(mustOrder(state, id)));
}

async function reconcile(orderId) {
  const id = parseOrderId(orderId);
  const state = load();
  const order = mustOrder(state, id);
  if (!order.attempt && order.refund === "refunded") {
    ok(reconcileView(order, "refunded"));
  }
  if (!order.attempt) {
    ok(reconcileView(order, "not_applicable"));
  }
  if (defect === "lost-reply-misattribution") {
    ok(reconcileView(order, "not_sent"));
  }
  let lookup;
  try {
    lookup = await getJson(serviceBase() + "/v1/refunds/" + order.attempt.refund_id);
  } catch {
    refuse("unavailable");
  }
  if (lookup.status === 200 && lookup.body &&
      lookup.body.outcome === "refunded" &&
      lookup.body.amount_cents === order.attempt.amount_cents &&
      lookup.body.order_id === order.order_id) {
    adopt(state, order);
    crash("after-record-before-exit");
    ok(reconcileView(order, "refunded"));
  }
  if (lookup.status === 404) {
    ok(reconcileView(order, "not_sent"));
  }
  if (lookup.status === 200) refuse("conflict");
  refuse("unavailable");
}

async function cancel(orderId) {
  const id = parseOrderId(orderId);
  const state = load();
  const order = mustOrder(state, id);
  if (order.lines.length > 0) {
    await cancelLines(state, order);
    return;
  }
  if (order.shipment === "shipped" && !order.attempt) refuse("shipped");
  if (order.refund === "refunded" && !order.attempt) {
    if (defect === "late-overwrite") clearRefund(state, order);
    ok(successView(order));
  }
  if (!order.attempt) {
    await submitNew(state, order, order.amount_cents, []);
    return;
  }
  await resumeOrPost(state, order);
}

async function cancelLines(state, order) {
  if (order.attempt) {
    await resumeOrPost(state, order);
    return;
  }
  const remaining = order.lines.filter((line) => line.refund !== "refunded");
  if (remaining.length === 0) {
    if (defect === "late-overwrite") clearRefund(state, order);
    ok(successView(order));
  }
  if (order.shipment === "shipped") refuse("shipped");
  const amount = remaining.reduce((sum, line) => sum + line.price_cents, 0);
  if (order.refunded_cents + amount > order.cap_cents) refuse("over_cap");
  await submitNew(state, order, amount, remaining.map((line) => line.line_id));
}

function linesEqual(order, cap, lines) {
  if (order.cap_cents !== cap || order.lines.length !== lines.length) return false;
  return lines.every((line, i) => order.lines[i].line_id === line.line_id && order.lines[i].price_cents === line.price_cents);
}

function attach(orderId, file) {
  if (!changedKind()) refuse("unknown_command");
  const id = parseOrderId(orderId);
  if (!file) refuse("bad_args");
  const state = load();
  const order = mustOrder(state, id);
  if (order.shipment === "shipped") refuse("shipped");
  if (order.attempt || order.refund !== "none" || order.refunded_cents > 0) refuse("refund_open");
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(file, "utf8"));
  } catch {
    refuse("bad_lines");
  }
  if (!parsed || typeof parsed !== "object" || !Array.isArray(parsed.lines)) refuse("bad_lines");
  const cap = parsed.cap_cents;
  if (!Number.isInteger(cap) || cap < 1 || cap > order.amount_cents) refuse("bad_lines");
  if (parsed.lines.length < 1 || parsed.lines.length > 20) refuse("bad_lines");
  const seen = new Set();
  let sum = 0;
  const lines = [];
  for (const line of parsed.lines) {
    if (!line || typeof line.line_id !== "string" || !LINE_RE.test(line.line_id)) refuse("bad_lines");
    if (seen.has(line.line_id)) refuse("bad_lines");
    seen.add(line.line_id);
    if (!Number.isInteger(line.price_cents) || line.price_cents < 1 || line.price_cents > 100000000) refuse("bad_lines");
    sum += line.price_cents;
    lines.push({ line_id: line.line_id, price_cents: line.price_cents, refund: "none" });
  }
  if (sum !== order.amount_cents) refuse("bad_lines");
  if (order.lines.length > 0) {
    if (linesEqual(order, cap, lines)) ok({ order_id: order.order_id, cap_cents: order.cap_cents, lines: publicLines(order) });
    refuse("conflict");
  }
  order.cap_cents = cap;
  order.lines = lines;
  commit(state);
  ok({ order_id: order.order_id, cap_cents: order.cap_cents, lines: publicLines(order) });
}

async function refund(orderId, lineIds) {
  if (!changedKind()) refuse("unknown_command");
  const id = parseOrderId(orderId);
  if (!lineIds.length) refuse("bad_args");
  const state = load();
  const order = mustOrder(state, id);
  if (order.lines.length === 0) refuse("not_attached");
  if (new Set(lineIds).size !== lineIds.length) refuse("unknown_line");
  for (const lineId of lineIds) {
    if (!LINE_RE.test(lineId) || !order.lines.some((line) => line.line_id === lineId)) refuse("unknown_line");
  }
  if (order.attempt && !sameSet(order.attempt.line_ids, lineIds)) {
    if (defect === "ignores-inflight") {
      order.attempt = null;
      for (const line of order.lines) {
        if (line.refund === "pending") line.refund = "none";
      }
    } else {
      refuse("refund_open");
    }
  }
  if (order.attempt && sameSet(order.attempt.line_ids, lineIds)) {
    await resumeOrPost(state, order);
    return;
  }
  if (order.shipment === "shipped") refuse("shipped");
  const selected = lineIds.map((lineId) => order.lines.find((line) => line.line_id === lineId));
  if (selected.some((line) => line.refund === "refunded")) refuse("already_refunded");
  const amount = selected.reduce((sum, line) => sum + line.price_cents, 0);
  if (order.refunded_cents + amount > order.cap_cents) refuse("over_cap");
  await submitNew(state, order, amount, lineIds);
}

export async function main(kind) {
  defect = kind;
  if (defect === "always-refuse") refuse("refused");
  const [cmd, ...args] = process.argv.slice(2);
  if (cmd === "record") {
    if (args.length < 2) refuse("bad_args");
    record(args[0], args[1]);
  } else if (cmd === "ship") {
    if (args.length < 1) refuse("bad_args");
    ship(args[0]);
  } else if (cmd === "status") {
    if (args.length < 1) refuse("bad_args");
    status(args[0]);
  } else if (cmd === "cancel") {
    if (args.length < 1) refuse("bad_args");
    await cancel(args[0]);
  } else if (cmd === "reconcile") {
    if (args.length < 1) refuse("bad_args");
    await reconcile(args[0]);
  } else if (cmd === "attach") {
    if (args.length < 2) refuse("bad_args");
    attach(args[0], args[1]);
  } else if (cmd === "refund") {
    if (args.length < 2) refuse("bad_args");
    await refund(args[0], args.slice(1));
  } else {
    refuse("unknown_command");
  }
}
