# Payment provider contract

The desk calls this service at `SERVICE_URL` (no trailing slash). The runnable server is `stub/server.mjs`:

```text
node server.mjs
```

It listens on `127.0.0.1` and prints one JSON line on stdout, then serves until killed:

```json
{"service_url":"http://127.0.0.1:PORT","control_url":"http://127.0.0.1:CPORT"}
```

State is in memory for that process only. Restarting the server drops every refund.

## Data plane

### `POST /v1/refunds`

`Content-Type: application/json`

```json
{"refund_id":"...","order_id":"...","amount_cents":1000,"currency":"USD"}
```

`refund_id` and `order_id` match `^[A-Za-z0-9._-]{1,64}$`. `amount_cents` is an integer from 1 to 100000000. `currency` is `USD`.

Responses:

- HTTP 400 `{"error":"bad_request"}` if the body is not JSON or a required field is missing or invalid. Nothing is stored.
- HTTP 500 `{"error":"unavailable"}` when the evaluator has asked for a provider failure. Nothing is stored. This is not a normal response. The running server returns it only under fault injection, described at the end of this file.
- HTTP 200 if this `refund_id` is new, or if it was already accepted with the same order id, amount, and currency:

```json
{"refund_id":"...","order_id":"...","amount_cents":1000,"currency":"USD","outcome":"refunded"}
```

The first acceptance stores the refund and counts one refund effect. A repeat of the same id and the same body returns the stored result and does not count another effect.

- HTTP 409 `{"error":"conflict"}` if this `refund_id` was already accepted with a different order id, amount, or currency. The stored effect is unchanged.

A different `refund_id` always counts as another effect, even if the order id and amount are identical.

### `GET /v1/refunds/<refund_id>`

HTTP 200 with the stored refund object, or HTTP 404 `{"error":"not_found"}` if that id was never accepted.

### `GET /v1/orders/<order_id>/refunds`

HTTP 200:

```json
{"order_id":"...","refunds":[]}
```

`refunds` lists every accepted refund for that order, in acceptance order. An order with none has an empty array, not HTTP 404.

Ids in paths are from `A-Za-z0-9._-`, so they need no extra encoding. Other characters are not part of the desk contract.

## Idempotency and lookup

Identity of an effect is `refund_id`. Lookup by refund id returns the acceptance even when the HTTP client never saw the response. Lookup by order id returns every acceptance for that order, so a second refund id is visible there as a second array entry. `reconcile` is required to lookup the saved refund id and is required not to POST.

A duplicate or conflicting callback does not change a stored refund. The desk has no callback receiver. Callback bodies exist only for the evaluator, on the control port.

## Evaluator fault injection

This section is for the acceptance harness, not for the desk. The desk brief does not describe these controls. The desk is only required to cope with a dropped reply, a late reply, an HTTP 500 that stored nothing, and the fact that a callback may be recorded twice or in conflict with an outcome already stored. The desk does not call the control port.

The control base URL is `control_url` from the startup line. Faults apply only to `POST /v1/refunds` on the data plane. `GET` routes are not delayed, dropped, or turned into HTTP 500.

`POST /fault` with JSON, for example `{"drop_reply":true,"delay_ms":0,"status_5xx":false,"callback":null}`.

- `drop_reply`: after the effect is stored, the server destroys the socket and writes no HTTP response. A repeat POST of the same id is still stored only once; if `drop_reply` is still set, that repeat is also dropped.
- `delay_ms`: non-negative integer. After the effect is stored, or before an HTTP 500, the server waits this many milliseconds before the response or the drop. `0` means no wait.
- `status_5xx`: the POST returns HTTP 500 `{"error":"unavailable"}` and does not store an effect. If this is set together with `drop_reply`, the HTTP 500 wins and nothing is stored.
- `callback`: `duplicate`, `conflict`, or `null`. `duplicate` appends a callback whose amount and `outcome` `refunded` match the latest stored effect. `conflict` appends a callback for that refund id with a different amount and `outcome` `disputed`. If an effect already exists, the callback is appended when the fault is posted. A later new effect also appends one while the flag stays set. Neither callback changes the stored effect.

`GET /effects` returns `{"count":N,"posts":M,"effects":[{"refund_id","order_id","amount_cents","currency","outcome"}]}` in acceptance order. `posts` counts `POST /v1/refunds` requests, including requests that stored nothing.

`GET /traffic` returns `{"requests":[{"method","path"}]}` for data-plane requests, in arrival order.

`GET /callbacks` returns `{"callbacks":[...]}`.

`GET /health` returns `{"ok":true}`.
