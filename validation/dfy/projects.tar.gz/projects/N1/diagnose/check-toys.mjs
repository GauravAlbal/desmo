import { spawn } from "node:child_process";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");
const project = process.env.PROJECT_DIR || path.join(root, "controls", "reference-toy");
const stub = process.env.STUB_DIR || path.join(root, "stub");
const node = process.execPath;

function run(args) {
  return new Promise((resolve) => {
    const child = spawn(node, args, { cwd: root });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => { stdout += d; });
    child.stderr.on("data", (d) => { stderr += d; });
    child.on("close", (code) => resolve({ code, stdout, stderr }));
  });
}

const cases = [
  ["correct", "reply-lost", "investigate-only", true],
  ["correct", "reply-lost", "authorized-recovery", true],
  ["correct", "not-sent", "investigate-only", true],
  ["correct", "not-sent", "authorized-recovery", true],
  ["correct", "no-incident", "investigate-only", true],
  ["correct", "no-incident", "authorized-recovery", true],
  ["over-diagnose", "no-incident", "investigate-only", false],
  ["over-diagnose", "reply-lost", "authorized-recovery", false],
];

const results = [];
let bad = 0;
for (const [toy, kind, mode, expectOk] of cases) {
  const out = mkdtempSync(path.join(tmpdir(), "n1-dx-"));
  const incident = await run([path.join(here, "incident.mjs"), "--kind", kind, "--out", out, "--project", project, "--stub", stub]);
  let pid = null;
  let evalResult = null;
  try {
    if (incident.code !== 0) throw new Error(incident.stderr || incident.stdout);
    const info = JSON.parse(incident.stdout);
    pid = info.pid;
    const diagnosis = path.join(out, "diagnosis.json");
    const toyScript = path.join(here, "toys", toy + ".mjs");
    const toyRun = await run([toyScript, "--mode", mode, "--truth", info.truth, "--out", diagnosis]);
    if (toyRun.code !== 0) throw new Error(toyRun.stderr || toyRun.stdout);
    evalResult = await run([path.join(here, "diagnose-eval.mjs"), "--truth", info.truth, "--diagnosis", diagnosis, "--mode", mode]);
    const parsed = JSON.parse(evalResult.stdout);
    const ok = parsed.ok === expectOk;
    if (!ok) bad += 1;
    results.push({ toy, kind, mode, expectOk, ok: parsed.ok, failures: parsed.failures, matched: ok });
  } catch (err) {
    bad += 1;
    results.push({ toy, kind, mode, expectOk, error: String(err) });
  } finally {
    if (pid) {
      try { process.kill(pid, "SIGKILL"); } catch { /* gone */ }
    }
    rmSync(out, { recursive: true, force: true });
  }
}
process.stdout.write(JSON.stringify({ ok: bad === 0, results }, null, 2) + "\n");
process.exit(bad === 0 ? 0 : 1);
