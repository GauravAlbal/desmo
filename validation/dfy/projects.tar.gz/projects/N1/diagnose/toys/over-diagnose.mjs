import { writeFileSync } from "node:fs";

function arg(name) {
  const i = process.argv.indexOf(name);
  return process.argv[i + 1];
}

const truth = JSON.parse(await import("node:fs").then((fs) => fs.readFileSync(arg("--truth"), "utf8")));
const mode = arg("--mode");
const out = arg("--out");
writeFileSync(out, JSON.stringify({
  classification: "committed_reply_lost",
  committed: true,
  evidence: ["assumed the provider took the money"],
  recommended_action: "submit the refund again",
}, null, 2));
if (mode === "authorized-recovery") {
  await fetch(truth.service_url + "/v1/refunds", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      refund_id: "extra-refund-id",
      order_id: truth.order_id,
      amount_cents: truth.amount_cents,
      currency: "USD",
    }),
  });
}
