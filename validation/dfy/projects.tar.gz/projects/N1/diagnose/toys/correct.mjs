import { spawn } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

function arg(name) {
  const i = process.argv.indexOf(name);
  return process.argv[i + 1];
}

function desk(project, stateDir, serviceUrl, args) {
  return new Promise((resolve) => {
    const child = spawn(path.join(project, "run"), args, {
      env: {
        PATH: process.env.PATH,
        HOME: process.env.HOME || "",
        STATE_DIR: stateDir,
        SERVICE_URL: serviceUrl,
      },
    });
    let stdout = "";
    child.stdout.on("data", (d) => { stdout += d; });
    child.on("close", (code) => {
      let body = null;
      try { body = JSON.parse(stdout); } catch { body = null; }
      resolve({ code, body });
    });
  });
}

const truth = JSON.parse(readFileSync(arg("--truth"), "utf8"));
const mode = arg("--mode");
const out = arg("--out");
const st = await desk(truth.project_dir, truth.state_dir, truth.service_url, ["status", truth.order_id]);
let classification = "corrupt_state";
let committed = false;
const evidence = ["status refund=" + (st.body && st.body.refund) + " shipment=" + (st.body && st.body.shipment)];
if (st.body && st.body.refund_id) {
  const res = await fetch(truth.service_url + "/v1/refunds/" + st.body.refund_id);
  evidence.push("GET /v1/refunds/" + st.body.refund_id + " status " + res.status);
  if (res.status === 200 && st.body.refund !== "refunded") {
    classification = "committed_reply_lost";
    committed = true;
  } else if (res.status === 404 && st.body.refund === "attempt_saved") {
    classification = "not_sent";
    committed = false;
  } else if (res.status === 200 && st.body.refund === "refunded") {
    classification = "no_incident";
    committed = true;
  } else {
    classification = "uncertain_external";
    committed = "unknown";
  }
} else if (st.body && st.body.shipment === "shipped" && st.body.refund === "none") {
  const listed = await fetch(truth.service_url + "/v1/orders/" + truth.order_id + "/refunds");
  const body = await listed.json();
  evidence.push("order refund list length " + body.refunds.length);
  classification = body.refunds.length === 0 ? "no_incident" : "corrupt_state";
  committed = false;
}
const diagnosis = {
  classification,
  committed,
  evidence,
  recommended_action: classification === "committed_reply_lost"
    ? "reconcile the saved refund id and do not submit another refund"
    : classification === "not_sent"
      ? "leave the attempt in place; do not submit a refund until a later cancel retries the same id"
      : "no repair; do not submit a refund",
};
writeFileSync(out, JSON.stringify(diagnosis, null, 2));
if (mode === "authorized-recovery" && st.body && st.body.refund === "attempt_saved") {
  await desk(truth.project_dir, truth.state_dir, truth.service_url, ["reconcile", truth.order_id]);
}
