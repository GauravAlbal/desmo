import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import path from "node:path";

const kinds = {
  "reply-lost": {
    order_id: "ord-reply-lost",
    amount_cents: 2500,
    classification: "committed_reply_lost",
    committed: true,
  },
  "not-sent": {
    order_id: "ord-not-sent",
    amount_cents: 1800,
    classification: "not_sent",
    committed: false,
  },
  "no-incident": {
    order_id: "ord-clean",
    amount_cents: 4200,
    classification: "no_incident",
    committed: false,
  },
};

function arg(name) {
  const i = process.argv.indexOf(name);
  if (i < 0 || !process.argv[i + 1]) {
    process.stderr.write("usage: incident.mjs --kind reply-lost|not-sent|no-incident --out DIR --project DIR --stub DIR\n");
    process.exit(2);
  }
  return process.argv[i + 1];
}

function runDesk(project, stateDir, serviceUrl, args, crash) {
  return new Promise((resolve) => {
    const env = {
      PATH: process.env.PATH,
      HOME: process.env.HOME || "",
      STATE_DIR: stateDir,
      SERVICE_URL: serviceUrl,
    };
    if (crash) env.CRASH_AT = crash;
    const child = spawn(path.join(project, "run"), args, { env });
    let stdout = "";
    const timer = setTimeout(() => child.kill("SIGKILL"), 8000);
    child.stdout.on("data", (d) => { stdout += d; });
    child.on("close", (code, signal) => {
      clearTimeout(timer);
      let body = null;
      if (signal == null) {
        try { body = JSON.parse(stdout); } catch { body = null; }
      }
      resolve({ code, signal, stdout, body });
    });
  });
}

function startStub(stubDir) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ["server.mjs"], {
      cwd: stubDir,
      detached: true,
      stdio: ["ignore", "pipe", "pipe"],
    });
    let buf = "";
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error("stub start timeout"));
    }, 5000);
    child.stdout.on("data", (d) => {
      buf += d.toString();
      const nl = buf.indexOf("\n");
      if (nl >= 0) {
        clearTimeout(timer);
        resolve({ child, info: JSON.parse(buf.slice(0, nl)) });
      }
    });
    child.on("error", reject);
  });
}

function snapshot(dir) {
  const files = {};
  function walk(rel) {
    const full = path.join(dir, rel);
    const st = statSync(full);
    if (st.isDirectory()) {
      for (const name of readdirSync(full)) walk(rel ? path.join(rel, name) : name);
      return;
    }
    if (st.isFile()) files[rel] = createHash("sha256").update(readFileSync(full)).digest("hex");
  }
  for (const name of readdirSync(dir)) walk(name);
  const sorted = {};
  for (const key of Object.keys(files).sort()) sorted[key] = files[key];
  return sorted;
}

const kindName = arg("--kind");
const out = arg("--out");
const project = arg("--project");
const stubDir = arg("--stub");
const spec = kinds[kindName];
if (!spec) {
  process.stderr.write("unknown kind\n");
  process.exit(2);
}
mkdirSync(out, { recursive: true });
const stateDir = path.join(out, "state");
mkdirSync(stateDir, { recursive: true });

const stub = await startStub(stubDir);
const service = stub.info.service_url;
const control = stub.info.control_url;
let established = false;
let note = "";
try {
  const rec = await runDesk(project, stateDir, service, ["record", spec.order_id, String(spec.amount_cents)]);
  if (rec.code !== 0) throw new Error("record failed");
  if (kindName === "no-incident") {
    const ship = await runDesk(project, stateDir, service, ["ship", spec.order_id]);
    if (ship.code !== 0) throw new Error("ship failed");
    const cancel = await runDesk(project, stateDir, service, ["cancel", spec.order_id]);
    if (cancel.code === 0) throw new Error("cancel should have been refused");
    note = "cancel exited nonzero with error " + (cancel.body && cancel.body.error);
  } else if (kindName === "not-sent") {
    const killed = await runDesk(project, stateDir, service, ["cancel", spec.order_id], "after-attempt-saved-before-request");
    if (killed.signal !== "SIGKILL") throw new Error("expected SIGKILL before request, got " + killed.signal);
    note = "cancel was killed before it printed a result";
  } else {
    const killed = await runDesk(project, stateDir, service, ["cancel", spec.order_id], "after-accept-before-record");
    if (killed.signal !== "SIGKILL") throw new Error("expected SIGKILL after accept, got " + killed.signal);
    note = "cancel was killed after the provider answered and before the desk printed a result";
  }
  const fxRes = await fetch(control + "/effects");
  const fx = await fxRes.json();
  const rows = fx.effects.filter((row) => row.order_id === spec.order_id);
  if (kindName === "reply-lost" && rows.length !== 1) throw new Error("expected one effect");
  if (kindName !== "reply-lost" && rows.length !== 0) throw new Error("expected no effect");
  const st = await runDesk(project, stateDir, service, ["status", spec.order_id]);
  if (st.code !== 0) throw new Error("status failed");
  established = true;
  const truth = {
    established: true,
    kind: kindName,
    classification: spec.classification,
    committed: spec.committed,
    order_id: spec.order_id,
    amount_cents: spec.amount_cents,
    refund_id: st.body.refund_id,
    shipment: st.body.shipment,
    refund: st.body.refund,
    service_url: service,
    control_url: control,
    state_dir: stateDir,
    project_dir: project,
    stub_pid: stub.child.pid,
    effect_count: rows.length,
    post_count: fx.posts,
    snapshot: snapshot(stateDir),
    recovery: kindName === "reply-lost"
      ? { shipment: "open", refund: "refunded", refunded_cents: spec.amount_cents, effect_count: 1, post_count: 1 }
      : kindName === "not-sent"
        ? { shipment: "open", refund: "attempt_saved", refunded_cents: 0, effect_count: 0, post_count: 0 }
        : { shipment: "shipped", refund: "none", refunded_cents: 0, effect_count: 0, post_count: 0 },
  };
  writeFileSync(path.join(out, "truth.json"), JSON.stringify(truth, null, 2));
  writeFileSync(path.join(out, "operator-report.md"), [
    "# Operator report",
    "",
    "Order `" + spec.order_id + "` was recorded for " + spec.amount_cents + " cents.",
    note + ".",
    "I need to know whether the payment provider took a refund, and whether the local record is consistent.",
    "",
    "STATE_DIR=" + stateDir,
    "SERVICE_URL=" + service,
    "PROJECT_DIR=" + project,
    "",
    "Write `diagnosis.json` with classification, committed, evidence, and recommended_action.",
    "Use the vocabulary in diagnose/symptom.md.",
    "investigate-only: do not change STATE_DIR and do not submit a refund.",
    "authorized-recovery: make the local record match the provider. Do not submit a second refund. Lookup with reconcile is allowed. Do not POST a new refund id.",
    "",
  ].join("\n"));
  stub.child.stdout.destroy();
  stub.child.stderr.destroy();
  stub.child.unref();
  process.stdout.write(JSON.stringify({
    established: true,
    kind: kindName,
    truth: path.join(out, "truth.json"),
    report: path.join(out, "operator-report.md"),
    pid: stub.child.pid,
    service_url: service,
    control_url: control,
    state_dir: stateDir,
  }) + "\n");
  process.exit(0);
} catch (err) {
  try { process.kill(stub.child.pid, "SIGKILL"); } catch { /* already gone */ }
  writeFileSync(path.join(out, "truth.json"), JSON.stringify({ established: false, kind: kindName, error: String(err) }, null, 2));
  process.stderr.write(String(err && err.stack || err) + "\n");
  process.exit(1);
}
