import { closeSync, fsyncSync, mkdirSync, openSync, readFileSync, renameSync, writeSync, existsSync } from "node:fs";
import path from "node:path";

const mode = process.argv[2] || "reference";
const argv = process.argv.slice(3);
const withChange = mode !== "reference" && mode !== "always-refuse";
const defect = mode;

const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const ADDR_RE = /^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$/;
const TIME_RE = /^(0|[1-9][0-9]*)$/;

function finish(code, obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(code);
}

function ok(obj) {
  finish(0, obj);
}

function refuse(error, extra) {
  finish(1, extra ? Object.assign({ error }, extra) : { error });
}

function maybeCrash(label) {
  if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL");
}

function statePath() {
  if (!process.env.STATE_DIR) refuse("bad_args");
  return path.join(process.env.STATE_DIR, "desk-state.json");
}

function load() {
  const file = statePath();
  if (!existsSync(file)) return { items: {}, ids: {} };
  return JSON.parse(readFileSync(file, "utf8"));
}

function commit(state) {
  const dir = process.env.STATE_DIR;
  mkdirSync(dir, { recursive: true });
  const tmp = path.join(dir, ".desk-state.tmp");
  const fd = openSync(tmp, "w");
  writeSync(fd, JSON.stringify(state));
  fsyncSync(fd);
  closeSync(fd);
  renameSync(tmp, path.join(dir, "desk-state.json"));
}

function parseId(text) {
  return typeof text === "string" && ID_RE.test(text) ? text : null;
}

function parseAddress(text) {
  return typeof text === "string" && ADDR_RE.test(text) ? text : null;
}

function parseTime(text, max) {
  if (typeof text !== "string" || !TIME_RE.test(text)) return null;
  const n = Number(text);
  if (!Number.isSafeInteger(n) || n < 0 || n > max) return null;
  return n;
}

function blankItem() {
  return {
    availability: "available",
    reservation_id: null,
    borrower_id: null,
    address: null,
    collect_by: null,
    reservation_state: "none",
    loan_id: null,
    loan_state: "none",
    notify: "none",
    waitlist: [],
    promotion: {
      request_id: null,
      notify: "none",
      wait_id: null,
      borrower_id: null,
      address: null,
      trigger_reservation_id: null,
      trigger_loan_id: null,
    },
    expired_reservation_ids: [],
  };
}

function pastDeadline(item, now) {
  if (item.reservation_state === "expired") return true;
  return item.reservation_state === "active" && item.collect_by !== null && now >= item.collect_by;
}

function statusView(itemId, item, now) {
  const view = {
    item_id: itemId,
    availability: item.availability,
    reservation_id: item.reservation_id,
    borrower_id: item.borrower_id,
    address: item.address,
    collect_by: item.collect_by,
    reservation_state: item.reservation_state,
    past_deadline: pastDeadline(item, now),
    loan_id: item.loan_id,
    loan_state: item.loan_state,
    notify: item.notify,
    now,
  };
  if (withChange) {
    view.waitlist = item.waitlist.map((row) => ({
      wait_id: row.wait_id,
      borrower_id: row.borrower_id,
      address: row.address,
      hold_seconds: row.hold_seconds,
    }));
    view.promotion = {
      request_id: item.promotion.request_id,
      notify: item.promotion.notify,
      wait_id: item.promotion.wait_id,
    };
  }
  return view;
}

function payloadMatch(body, notice) {
  return body && body.item_id === notice.item_id && body.borrower_id === notice.borrower_id && body.address === notice.address && body.kind === notice.kind && body.outcome === "accepted";
}

async function serviceFetch(method, pathname, body) {
  if (!process.env.SERVICE_URL) return { error: "no-url" };
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 5000);
  try {
    const res = await fetch(process.env.SERVICE_URL + pathname, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      signal: ctrl.signal,
    });
    const text = await res.text();
    let parsed = null;
    try {
      parsed = JSON.parse(text);
    } catch {
      return { error: "bad-body", status: res.status };
    }
    return { status: res.status, body: parsed };
  } catch {
    return { error: "network" };
  } finally {
    clearTimeout(timer);
  }
}

async function deliver(notice, fresh) {
  if (fresh) maybeCrash("after-attempt-saved-before-request");
  const looked = await serviceFetch("GET", "/v1/requests/" + notice.request_id);
  if (looked.error) return { error: "service_unavailable" };
  if (looked.status === 200) {
    if (!payloadMatch(looked.body, notice)) return { error: "conflict" };
    if (defect === "duplicate-effect" && notice.kind === "checkout") {
      await serviceFetch("POST", "/v1/messages", Object.assign({}, notice, { request_id: notice.request_id + "x" }));
    }
    return { ok: true };
  }
  if (looked.status !== 404) return { error: "service_unavailable" };
  const posted = await serviceFetch("POST", "/v1/messages", notice);
  if (posted.error) return { error: "service_unavailable" };
  if (posted.status === 409) return { error: "conflict" };
  if (posted.status !== 200) return { error: "service_unavailable" };
  if (!payloadMatch(posted.body, notice)) return { error: "conflict" };
  maybeCrash("after-accept-before-record");
  return { ok: true };
}

function markSent(item, kind) {
  if (kind === "checkout") {
    item.availability = "checked_out";
    item.loan_state = "checked_out";
    item.notify = "sent";
    item.reservation_state = "collected";
  } else {
    item.promotion.notify = "sent";
  }
}

function findLoan(state, loanId) {
  for (const [itemId, item] of Object.entries(state.items)) {
    if (item.loan_id === loanId && item.loan_state !== "none") return { itemId, item };
  }
  return null;
}

function findPromotion(state, id) {
  for (const [itemId, item] of Object.entries(state.items)) {
    if (item.promotion && item.promotion.request_id === id && item.promotion.notify !== "none") return { itemId, item };
  }
  return null;
}

function findExpired(state, reservationId) {
  for (const [itemId, item] of Object.entries(state.items)) {
    if (item.expired_reservation_ids.includes(reservationId)) return { itemId, item };
    if (item.reservation_id === reservationId && item.reservation_state === "expired") return { itemId, item };
  }
  return null;
}

function promote(item, itemId, now, oldReservationId, triggerLoanId) {
  const head = item.waitlist.shift();
  if (oldReservationId) item.expired_reservation_ids.push(oldReservationId);
  item.availability = "reserved";
  item.reservation_id = head.wait_id;
  item.borrower_id = head.borrower_id;
  item.address = head.address;
  item.collect_by = now + head.hold_seconds;
  item.reservation_state = "active";
  item.promotion = {
    request_id: head.wait_id,
    notify: "attempt_saved",
    wait_id: head.wait_id,
    borrower_id: head.borrower_id,
    address: head.address,
    trigger_reservation_id: oldReservationId,
    trigger_loan_id: triggerLoanId,
  };
  return {
    request_id: head.wait_id,
    item_id: itemId,
    borrower_id: head.borrower_id,
    address: head.address,
    kind: "waitlist_ready",
  };
}

function expireInPlace(item) {
  item.availability = "available";
  item.reservation_state = "expired";
}

async function finishPromotion(state, item, notice, fresh) {
  const sent = await deliver(notice, fresh);
  if (sent.error) refuse(sent.error);
  markSent(item, "waitlist_ready");
  commit(state);
  maybeCrash("after-record-before-exit");
}

async function continuePromotion(state, item, itemId) {
  if (!withChange || item.promotion.notify !== "attempt_saved") return false;
  const notice = {
    request_id: item.promotion.request_id,
    item_id: itemId,
    borrower_id: item.promotion.borrower_id,
    address: item.promotion.address,
    kind: "waitlist_ready",
  };
  await finishPromotion(state, item, notice, false);
  return true;
}

function addItem(itemId) {
  const id = parseId(itemId);
  if (!id) refuse("bad_args");
  const state = load();
  if (state.ids[id]) refuse("id_in_use");
  state.items[id] = blankItem();
  state.ids[id] = { kind: "item", item_id: id };
  commit(state);
  ok({ item_id: id, availability: "available", reservation_id: null, loan_id: null });
}

function reserve(itemId, reservationId, borrowerId, address, collectByText, nowText) {
  const id = parseId(itemId);
  const reservation = parseId(reservationId);
  const borrower = parseId(borrowerId);
  const addr = parseAddress(address);
  const collectBy = parseTime(collectByText, 9999999999);
  const now = parseTime(nowText, 9999999999);
  if (!id || !reservation || !borrower || !addr || collectBy === null || now === null || collectBy <= now) refuse("bad_args");
  const state = load();
  const item = state.items[id];
  if (!item) refuse("unknown_item");
  if (state.ids[reservation]) refuse("id_in_use");
  return reserveAsync(state, item, id, reservation, borrower, addr, collectBy, now);
}

async function reserveAsync(state, item, id, reservation, borrower, addr, collectBy, now) {
  if (item.availability === "reserved" && item.reservation_state === "active" && now >= item.collect_by) {
    const oldId = item.reservation_id;
    if (withChange && item.waitlist.length > 0) {
      const notice = promote(item, id, now, oldId, null);
      commit(state);
      await finishPromotion(state, item, notice, true);
      refuse("not_available");
    }
    expireInPlace(item);
    commit(state);
  }
  if (item.availability !== "available") refuse("not_available");
  item.availability = "reserved";
  item.reservation_id = reservation;
  item.borrower_id = borrower;
  item.address = addr;
  item.collect_by = collectBy;
  item.reservation_state = "active";
  state.ids[reservation] = { kind: "reservation", item_id: id };
  commit(state);
  ok({
    item_id: id,
    reservation_id: reservation,
    borrower_id: borrower,
    address: addr,
    collect_by: collectBy,
    availability: "reserved",
    now,
  });
}

async function expire(itemId, nowText) {
  const id = parseId(itemId);
  const now = parseTime(nowText, 9999999999);
  if (!id || now === null) refuse("bad_args");
  const state = load();
  const item = state.items[id];
  if (!item) refuse("unknown_item");
  if (withChange && item.promotion.notify === "attempt_saved") {
    await continuePromotion(state, item, id);
  }
  if (item.availability === "reserved" && item.reservation_state === "active" && now >= item.collect_by) {
    const oldId = item.reservation_id;
    if (withChange && item.waitlist.length > 0) {
      const notice = promote(item, id, now, oldId, null);
      commit(state);
      await finishPromotion(state, item, notice, true);
      ok({
        item_id: id,
        availability: "reserved",
        expired: true,
        reservation_id: item.reservation_id,
        promoted_wait_id: notice.request_id,
        notify: "sent",
        now,
      });
    }
    expireInPlace(item);
    commit(state);
    ok({ item_id: id, availability: "available", expired: true, reservation_id: item.reservation_id, promoted_wait_id: null, notify: "none", now });
  }
  ok({
    item_id: id,
    availability: item.availability,
    expired: false,
    reservation_id: item.reservation_id,
    promoted_wait_id: null,
    notify: "none",
    now,
  });
}

async function checkout(itemId, reservationId, loanId, nowText) {
  const id = parseId(itemId);
  const reservation = parseId(reservationId);
  const loan = parseId(loanId);
  const now = parseTime(nowText, 9999999999);
  if (!id || !reservation || !loan || now === null) refuse("bad_args");
  const state = load();
  const item = state.items[id];
  if (!item) refuse("unknown_item");
  if (item.availability === "checked_out") refuse("already_checked_out");
  if (withChange && item.promotion.notify === "attempt_saved" && item.promotion.trigger_reservation_id === reservation) {
    await continuePromotion(state, item, id);
    refuse("expired");
  }
  if (item.availability === "reserved" && item.reservation_state === "active" && item.reservation_id === reservation && now >= item.collect_by) {
    const oldId = item.reservation_id;
    if (withChange && item.waitlist.length > 0) {
      const notice = promote(item, id, now, oldId, null);
      commit(state);
      await finishPromotion(state, item, notice, true);
      refuse("expired", { promoted_wait_id: notice.request_id, notify: "sent" });
    }
    expireInPlace(item);
    commit(state);
    refuse("expired");
  }
  if (findExpired(state, reservation) && (item.reservation_id !== reservation || item.reservation_state === "expired")) refuse("expired");
  if (item.reservation_state === "expired" && item.reservation_id === reservation) refuse("expired");
  if (item.reservation_state !== "active") refuse("not_reserved");
  if (item.reservation_id !== reservation) refuse("reservation_mismatch");
  if (item.loan_state === "attempt_saved" && item.loan_id !== loan) refuse("checkout_in_progress");
  if (item.loan_state === "attempt_saved" && item.reservation_id !== reservation) refuse("reservation_mismatch");
  let fresh = false;
  if (item.loan_state !== "attempt_saved") {
    if (state.ids[loan]) refuse("id_in_use");
    item.loan_id = loan;
    item.loan_state = "attempt_saved";
    item.notify = "attempt_saved";
    state.ids[loan] = { kind: "loan", item_id: id };
    commit(state);
    fresh = true;
  }
  const notice = {
    request_id: item.loan_id,
    item_id: id,
    borrower_id: item.borrower_id,
    address: item.address,
    kind: "checkout",
  };
  const sent = await deliver(notice, fresh);
  if (sent.error) refuse(sent.error);
  markSent(item, "checkout");
  commit(state);
  maybeCrash("after-record-before-exit");
  ok({
    item_id: id,
    reservation_id: item.reservation_id,
    loan_id: item.loan_id,
    borrower_id: item.borrower_id,
    address: item.address,
    availability: "checked_out",
    notify: "sent",
    request_id: item.loan_id,
    now,
  });
}

async function returnItem(itemId, loanId, nowText) {
  const id = parseId(itemId);
  const loan = parseId(loanId);
  const now = parseTime(nowText, 9999999999);
  if (!id || !loan || now === null) refuse("bad_args");
  const state = load();
  const item = state.items[id];
  if (!item) refuse("unknown_item");
  if (withChange && item.loan_state === "returned" && item.promotion.notify === "attempt_saved" && item.promotion.trigger_loan_id === loan) {
    await continuePromotion(state, item, id);
    ok({
      item_id: id,
      loan_id: loan,
      availability: item.availability,
      loan_state: "returned",
      promoted_wait_id: item.promotion.wait_id,
      notify: "sent",
      now,
    });
  }
  if (item.availability !== "checked_out") refuse("not_checked_out");
  if (item.loan_id !== loan) refuse("loan_mismatch");
  item.loan_state = "returned";
  if (withChange && item.waitlist.length > 0) {
    const oldId = item.reservation_id;
    const notice = promote(item, id, now, oldId, loan);
    commit(state);
    await finishPromotion(state, item, notice, true);
    ok({
      item_id: id,
      loan_id: loan,
      availability: "reserved",
      loan_state: "returned",
      promoted_wait_id: notice.request_id,
      notify: "sent",
      now,
    });
  }
  item.availability = "available";
  commit(state);
  ok({ item_id: id, loan_id: loan, availability: "available", loan_state: "returned", promoted_wait_id: null, now });
}

function status(itemId, nowText) {
  const id = parseId(itemId);
  const now = parseTime(nowText, 9999999999);
  if (!id || now === null) refuse("bad_args");
  const state = load();
  const item = state.items[id];
  if (!item) refuse("unknown_item");
  ok(statusView(id, item, now));
}

function reconcileView(id, item, kind, notify) {
  return {
    request_id: id,
    loan_id: item ? item.loan_id : null,
    item_id: item ? undefined : null,
    kind: kind,
    notify: notify,
    availability: item ? item.availability : null,
    loan_state: item ? item.loan_state : "none",
  };
}

async function reconcile(idText) {
  const id = parseId(idText);
  if (!id) refuse("bad_args");
  const state = load();
  const loanHit = findLoan(state, id);
  const promoHit = withChange ? findPromotion(state, id) : null;
  const hit = loanHit || promoHit;
  if (!hit) {
    ok({ request_id: id, loan_id: null, item_id: null, kind: null, notify: "none", availability: null, loan_state: "none" });
  }
  const item = hit.item;
  const kind = loanHit ? "checkout" : "waitlist_ready";
  const notify = loanHit ? item.notify : item.promotion.notify;
  if (defect === "lost-reply-misattribution" && notify === "attempt_saved") {
    ok({
      request_id: id,
      loan_id: item.loan_id,
      item_id: hit.itemId,
      kind,
      notify: "not_sent",
      availability: item.availability,
      loan_state: item.loan_state,
    });
  }
  if (notify === "sent") {
    ok({
      request_id: id,
      loan_id: item.loan_id,
      item_id: hit.itemId,
      kind,
      notify: "sent",
      availability: item.availability,
      loan_state: item.loan_state,
    });
  }
  const looked = await serviceFetch("GET", "/v1/requests/" + id);
  if (looked.error) refuse("service_unavailable");
  if (looked.status === 404) {
    ok({
      request_id: id,
      loan_id: item.loan_id,
      item_id: hit.itemId,
      kind,
      notify: "not_sent",
      availability: item.availability,
      loan_state: item.loan_state,
    });
  }
  if (looked.status !== 200) refuse("service_unavailable");
  const notice = kind === "checkout"
    ? { request_id: id, item_id: hit.itemId, borrower_id: item.borrower_id, address: item.address, kind: "checkout" }
    : { request_id: id, item_id: hit.itemId, borrower_id: item.promotion.borrower_id, address: item.promotion.address, kind: "waitlist_ready" };
  if (!payloadMatch(looked.body, notice)) refuse("conflict");
  markSent(item, kind);
  commit(state);
  maybeCrash("after-record-before-exit");
  ok({
    request_id: id,
    loan_id: item.loan_id,
    item_id: hit.itemId,
    kind,
    notify: "sent",
    availability: item.availability,
    loan_state: item.loan_state,
  });
}

function callback(file) {
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(file, "utf8"));
  } catch {
    refuse("bad_args");
  }
  const fields = ["callback_id", "request_id", "item_id", "borrower_id", "address", "kind", "outcome"];
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) refuse("bad_args");
  for (const field of fields) {
    if (typeof parsed[field] !== "string" || parsed[field].length === 0) refuse("bad_args");
  }
  if (parsed.outcome !== "accepted" && parsed.outcome !== "rejected") refuse("bad_args");
  if (parsed.kind !== "checkout" && parsed.kind !== "waitlist_ready") refuse("bad_args");
  const state = load();
  if (defect === "late-overwrite") {
    const item = state.items[parsed.item_id];
    if (item && item.notify === "sent" && parsed.address !== item.address) {
      item.address = parsed.address;
      commit(state);
    }
  }
  ok({ ok: true });
}

function wait(itemId, waitId, borrowerId, address, holdText, nowText) {
  if (!withChange) refuse("bad_args");
  const id = parseId(itemId);
  const wid = parseId(waitId);
  const borrower = parseId(borrowerId);
  const addr = parseAddress(address);
  const hold = parseTime(holdText, 2592000);
  const now = parseTime(nowText, 9999999999);
  if (!id || !wid || !borrower || !addr || hold === null || hold < 1 || now === null) refuse("bad_args");
  const state = load();
  const item = state.items[id];
  if (!item) refuse("unknown_item");
  if (state.ids[wid]) refuse("id_in_use");
  if (item.availability === "available") refuse("not_needed");
  if (item.borrower_id === borrower || item.waitlist.some((row) => row.borrower_id === borrower)) refuse("already_waiting");
  item.waitlist.push({ wait_id: wid, borrower_id: borrower, address: addr, hold_seconds: hold });
  state.ids[wid] = { kind: "wait", item_id: id };
  commit(state);
  ok({
    item_id: id,
    wait_id: wid,
    borrower_id: borrower,
    address: addr,
    hold_seconds: hold,
    position: item.waitlist.length,
    availability: item.availability,
    now,
  });
}

async function main() {
  if (defect === "always-refuse") refuse("refused");
  const cmd = argv[0];
  if (cmd === "add-item") addItem(argv[1]);
  else if (cmd === "reserve") await reserve(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6]);
  else if (cmd === "expire") await expire(argv[1], argv[2]);
  else if (cmd === "checkout") await checkout(argv[1], argv[2], argv[3], argv[4]);
  else if (cmd === "return") await returnItem(argv[1], argv[2], argv[3]);
  else if (cmd === "status") status(argv[1], argv[2]);
  else if (cmd === "reconcile") await reconcile(argv[1]);
  else if (cmd === "callback") callback(argv[1]);
  else if (cmd === "wait") wait(argv[1], argv[2], argv[3], argv[4], argv[5], argv[6]);
  else refuse("bad_args");
}

main();
