# Freeze

This directory is the experiment material for one equipment loan desk. Builders receive `brief.md` plus `stub/server.mjs` and `stub/CONTRACT.md`. A later maintainer receives `change.md`. The acceptance harness is `evaluator/`. The controls are not implementations to copy.

`reference-toy` passes the initial suite only to prove the harness can pass. `reference-toy-changed` passes the initial suite and the change suite. Neither is a model solution. A failing control proves only that the check can detect that defect. It does not prove the check detects every other defect, and a pass does not prove the control is otherwise correct.

The initial suite is R1-R14 from `brief.md`. The change suite is those plus C1-C5 from `change.md`. `change.md` revises R3 and R7 for the non-empty waitlist and leaves their empty-waitlist behavior in force. A project that has not applied the change fails C1-C5.

The builder entry point is `./run`, implemented by builders in Python 3.9+ using only the standard library. The harness and the controls are Node programs. They use the same executable interface.

## Requirement ids

- R1 Persistence across process restart, including a second item and a SIGKILL after the checkout record
- R2 Reservation fields are stored and presented by status
- R3 Expiry commits availability and refuses a late checkout with no mail
- R4 Checkout confirmation payload matches the loan
- R5 Legitimate progress is not refused
- R6 Double checkout is refused and adds no effect
- R7 Return of an item that is not checked out is refused; a real return completes
- R8 Crash after accept is recovered without a second effect
- R9 Crash before the request still completes with one effect
- R10 Crash after the durable record keeps the outcome and adds no effect
- R11 Lost reply is reconciled by lookup and is not reported as not-sent
- R12 Success and refusal are one JSON object with a defined error code
- R13 An unrelated writer file in STATE_DIR is preserved
- R14 A late or conflicting callback does not overwrite a terminal outcome or add an effect
- C1 Waitlist join order, and refusals for an available item, a reused id, and a repeated borrower
- C2 Return promotes the head once and does not notify again
- C3 Expiry promotes, chains to the next head, and a due reserve with a waiter does not steal the item
- C4 An uncertain promotion send is finished by lookup or by continuing the same request id
- C5 Checkout at expiry sends the waitlist notice and not a checkout confirmation

## Crash points

Honored only when the running command reaches the boundary. Otherwise the command must not kill itself. The kill is SIGKILL.

- `after-attempt-saved-before-request`: on `checkout`, after the attempt record is committed, before any byte of the confirmation HTTP request is sent. Not on a retry that finds the attempt already saved. The change applies the same label to a promotion send, after that attempt is committed and before any byte of the promotion POST.
- `after-accept-before-record`: on `checkout`, after the complete confirmation POST body has been read, before the durable checkout outcome is committed. Not on a lookup of an acceptance from an earlier process. The change applies the same label to a promotion POST body.
- `after-record-before-exit`: on `checkout` or `reconcile`, after a terminal confirmation outcome is committed, before the success JSON is written. The change also applies it after a promotion `notify` `sent` is committed, before that command writes its JSON, including the `expired` refusal on the checkout expiry path.

## Deliberate ambiguities

- stderr is unconstrained.
- Extra JSON fields are allowed.
- After a dropped reply, `checkout` or a promotion send may return `service_unavailable` and leave `attempt_saved`, or it may look up the request id and commit `sent` before returning. It must not POST a different request id. The suite accepts either local state immediately after that command, then requires `reconcile` to report `sent` without a new POST.
- A well-formed callback may be ignored, or used only as a hint to look up the request. The suite requires that a callback not change a terminal outcome and not add an effect. It does not require a callback alone to finish a lost reply. `reconcile` is the required recovery command.
- No numeric HTTP timeout is specified. A closed connection must make the command return rather than send a new request id.
- Overlapping `./run` processes are unsupported and unspecified.
- Store filename and encoding are internal, provided committed records survive SIGKILL and unrelated files are left alone.
- HTTP 500 that stores nothing, and a held or delayed reply, are specified service conditions and are not separately scored.
- `status` computes `past_deadline` and must not commit it. A supplied `now` may be earlier than a previous command. A committed expiry is not reversed.
- The scored unrelated-writer check creates the file from another process and then runs desk commands. A command that deleted the file and recreated the same bytes before returning would not be distinguished.
- The diagnosing agent is given the filled case `symptom.md`. `diagnose/harness/` is evaluator-only. `expected.md` is evaluator-only.

## Control-run table

Observed with `PROJECT_DIR` set to each control and `STUB_DIR` set to `stub/`.

Initial suite, `evaluator/run.sh`:

| Control | Failed requirement ids | Passed |
| --- | --- | --- |
| reference-toy | none | R1-R14 |
| reference-toy-changed | none | R1-R14 |
| late-overwrite | R14 | every other initial id |
| duplicate-effect | R8 | every other initial id |
| lost-reply-misattribution | R11 | every other initial id |
| always-refuse | R1-R14 | none |

Change suite, `evaluator/run-change.sh`:

| Control | Failed requirement ids | Passed |
| --- | --- | --- |
| reference-toy | C1-C5 | R1-R14 |
| reference-toy-changed | none | R1-R14, C1-C5 |
| late-overwrite | R14 | every other id, including C1-C5 |
| duplicate-effect | R8 | every other id, including C1-C5 |
| lost-reply-misattribution | R11, C4, C5 | every other id |
| always-refuse | R1-R14, C1-C5 | none |

`lost-reply-misattribution` reports `not_sent` for an attempt the service already accepted, without adopting the lookup. C4 and C5 include that recovery for a promotion notice, so they fail too. That does not, by itself, show that R14 detects a late overwrite. That isolation is the `late-overwrite` row.

## Diagnosis self-check

Observed with `diagnose/self-check.mjs` against `controls/reference-toy`.

`diagnose/incident.mjs` leaves a conforming `reference-toy` in a concrete case. `diagnose/diagnose-eval.mjs` compares `diagnosis.json` with the ground truth recorded from the stub.

| Toy | Case | Mode | diagnose-eval |
| --- | --- | --- | --- |
| correct | lost-reply | investigate-only | pass |
| correct | lost-reply | authorized-recovery | pass |
| correct | expected-refusal | investigate-only | pass |
| correct | expected-refusal | authorized-recovery | pass |
| over-diagnose | lost-reply | investigate-only | fail |
| over-diagnose | lost-reply | authorized-recovery | fail |
| over-diagnose | expected-refusal | authorized-recovery | fail |
| repeat-effect | lost-reply | authorized-recovery | fail |
| repeat-effect | expected-refusal | investigate-only | fail |

The correct toy passes. The over-diagnose toy writes `corrupt_state` and either tampers with `STATE_DIR` or posts a new confirmation. The repeat-effect toy writes the right classification and still tampers or posts. A failing toy proves only that the checker can detect that mistake.
