# Mail service contract

The desk calls this service at `SERVICE_URL` (no trailing slash). The runnable server is `stub/server.mjs`:

```text
node server.mjs
```

It listens on `127.0.0.1` and prints one JSON line on stdout, then serves until killed:

```json
{"service_url":"http://127.0.0.1:PORT","control_url":"http://127.0.0.1:CPORT"}
```

State is in memory for that process only. Restarting the server drops every message.

## Data plane

### `POST /v1/messages`

`Content-Type: application/json`

```json
{"request_id":"...","item_id":"...","borrower_id":"...","address":"...","kind":"checkout"}
```

`request_id`, `item_id`, and `borrower_id` are non-empty strings of 1 to 64 characters from `A-Za-z0-9._-`. `address` is `local@domain` as in the desk brief. `kind` is `checkout` or `waitlist_ready`.

Responses:

- HTTP 400 `{"error":"bad_request"}` if a required field is missing or malformed. Nothing is stored.
- HTTP 200 if this `request_id` is new, or if it was already accepted with the same item, borrower, address, and kind:

```json
{"request_id":"...","item_id":"...","borrower_id":"...","address":"...","kind":"checkout","outcome":"accepted"}
```

The first acceptance counts one send effect. A repeat of the same id and the same payload returns the stored result and does not count another effect.

- HTTP 409 `{"error":"conflict"}` if this `request_id` was already accepted with a different item, borrower, address, or kind. The stored effect is unchanged.

A different `request_id` always counts as another effect, even if the other fields are identical.

### `GET /v1/requests/<request_id>`

HTTP 200 with the stored message object, or HTTP 404 `{"error":"not_found"}` if that id was never accepted.

Ids in paths use the desk id alphabet, so they need no extra encoding.

## Callback shape

The service does not call the desk. An operator or an acceptance harness delivers this JSON in a file:

```json
{"callback_id":"...","request_id":"...","item_id":"...","borrower_id":"...","address":"...","kind":"checkout","outcome":"accepted"}
```

`outcome` is `accepted` or `rejected`. `kind` is `checkout` or `waitlist_ready`. The same object may be delivered more than once. A later object may name a different address or borrower for a request the service already accepted.

On each new effect the server keeps one callback body, available from the control port, with `callback_id` set to `cb-` plus the request id and `outcome` `accepted`. That list is a convenience for the harness. The desk never reads the control port.

## Idempotency and lookup

Identity of an effect is `request_id`. Lookup by request id returns the acceptance even when the HTTP client never saw the response. There is no lookup by item. A second request id is a second effect even when the payload matches.

## Evaluator fault injection

This section is for the acceptance harness, not for the desk. The desk brief does not describe these control routes. The desk is only required to cope with a dropped reply, a late reply, an HTTP 500 that stores nothing, and a callback delivered twice or in conflict with a recorded outcome.

The control base URL is `control_url` from the startup line. Faults apply only to `POST /v1/messages` on the data plane. `GET` routes are not delayed, dropped, or failed.

`POST /fault` with JSON, for example `{"drop_reply":true,"delay_ms":0,"hold":false,"next_status":0}`.

- `drop_reply`: after the effect is stored, the server destroys the socket and writes no HTTP response. A repeat POST of the same id is still stored only once; if `drop_reply` is still set, that repeat is also dropped after the stored result is found.
- `delay_ms`: non-negative integer. After the effect is stored, or after a `next_status` decision, the server waits this many milliseconds before the response or the drop.
- `hold`: if true, the server waits until `POST /release` before the response or the drop. The harness must release. The stored effect, if any, is already counted before the wait.
- `next_status`: if this is an integer from 400 through 599, the next POST returns that status and `{"error":"unavailable"}`, stores nothing, and does not drop the socket. The value is cleared after that one response. It wins over `drop_reply` for that request.

`POST /release` completes a held request. Body is ignored.

`GET /effects` returns:

```json
{"count":0,"effects":[{"request_id":"...","item_id":"...","borrower_id":"...","address":"...","kind":"checkout"}],"posts":[{"request_id":"...","kind":"checkout","stored":true}]}
```

`count` is the number of accepted effects. `posts` lists every data-plane POST that reached the handler, including idempotent repeats, conflicts, and responses that stored nothing (`stored` false).

`GET /callbacks` returns `{"callbacks":[...]}` for effects this process accepted.

`GET /health` returns `{"ok":true}`.

The harness may also hand the desk a callback file the server never stored (a conflicting or duplicate delivery). That does not require a control-port call.
