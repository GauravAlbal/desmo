#!/bin/sh
set -u
NODE="$HOME/.nvm/versions/node/v22.17.1/bin/node"
HERE=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
: "${PROJECT_DIR:?}"
: "${STUB_DIR:?}"
export PROJECT_DIR STUB_DIR
TAP=$(mktemp)
"$NODE" --test --test-concurrency=1 --test-reporter=tap "$HERE/accept.test.mjs" >"$TAP" 2>"$TAP.err" || true
"$NODE" "$HERE/summarize.mjs" "$TAP" R1 R2 R3 R4 R5 R6 R7 R8 R9 R10 R11 R12 R13 R14
rc=$?
rm -f "$TAP" "$TAP.err"
exit "$rc"
