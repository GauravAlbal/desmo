import test from "node:test";
import assert from "node:assert/strict";
import { CODES, OPTS, desk, effects, errJson, killed, marker, okJson, ofKind, readMarker, session, setFault, writeCb } from "./harness.mjs";

const ADDR = "pat@loan.desk";

test("R1 persistence across restart", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    okJson(desk(state, service, ["add-item", "cam-2"]));
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    const again = okJson(desk(state, service, ["status", "cam-1", "1000"]));
    assert.equal(again.reservation_id, "res-1");
    assert.equal(again.availability, "reserved");
    const other = okJson(desk(state, service, ["status", "cam-2", "1000"]));
    assert.equal(other.availability, "available");
    const crashed = desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"], "after-record-before-exit");
    assert.equal(killed(crashed), true);
    const after = okJson(desk(state, service, ["status", "cam-1", "1001"]));
    assert.equal(after.availability, "checked_out");
    assert.equal(after.notify, "sent");
    assert.equal(after.loan_id, "loan-1");
    const still = okJson(desk(state, service, ["status", "cam-2", "1001"]));
    assert.equal(still.availability, "available");
    const fx = await effects(control);
    assert.equal(ofKind(fx, "checkout").length, 1);
  });
});

test("R2 reservation record is presented", OPTS, async () => {
  await session(async ({ state, service }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    const view = okJson(desk(state, service, ["status", "cam-1", "1100"]));
    assert.equal(view.reservation_id, "res-1");
    assert.equal(view.borrower_id, "pat");
    assert.equal(view.address, ADDR);
    assert.equal(view.collect_by, 5000);
    assert.equal(view.availability, "reserved");
    assert.equal(view.reservation_state, "active");
  });
});

test("R3 expiry refuses late checkout", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    const early = okJson(desk(state, service, ["expire", "cam-1", "1000"]));
    assert.equal(early.expired, false);
    assert.equal(okJson(desk(state, service, ["status", "cam-1", "1000"])).reservation_state, "active");
    const due = okJson(desk(state, service, ["expire", "cam-1", "5000"]));
    assert.equal(due.expired, true);
    assert.equal(due.availability, "available");
    const late = errJson(desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "5000"]), CODES);
    assert.equal(late.error, "expired");
    okJson(desk(state, service, ["reserve", "cam-1", "res-2", "pat", ADDR, "9000", "5000"]));
    assert.equal(okJson(desk(state, service, ["status", "cam-1", "5000"])).reservation_id, "res-2");
    okJson(desk(state, service, ["add-item", "cam-b"]));
    okJson(desk(state, service, ["reserve", "cam-b", "res-b", "pat", ADDR, "3000", "1000"]));
    const direct = errJson(desk(state, service, ["checkout", "cam-b", "res-b", "loan-b", "3000"]), CODES);
    assert.equal(direct.error, "expired");
    assert.equal(okJson(desk(state, service, ["status", "cam-b", "3000"])).availability, "available");
    const fx = await effects(control);
    assert.equal(fx.posts.length, 0);
    assert.equal(fx.count, 0);
  });
});

test("R4 confirmation payload matches the loan", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    okJson(desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"]));
    const view = okJson(desk(state, service, ["status", "cam-1", "1000"]));
    assert.equal(view.availability, "checked_out");
    assert.equal(view.loan_id, "loan-1");
    assert.equal(view.borrower_id, "pat");
    assert.equal(view.address, ADDR);
    const fx = await effects(control);
    assert.equal(fx.count, 1);
    assert.equal(fx.effects[0].request_id, "loan-1");
    assert.equal(fx.effects[0].item_id, "cam-1");
    assert.equal(fx.effects[0].borrower_id, "pat");
    assert.equal(fx.effects[0].address, ADDR);
    assert.equal(fx.effects[0].kind, "checkout");
  });
});

test("R5 legitimate progress is not refused", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    assert.equal(desk(state, service, ["add-item", "cam-1"]).status, 0);
    assert.equal(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]).status, 0);
    assert.equal(desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"]).status, 0);
    const view = okJson(desk(state, service, ["status", "cam-1", "1000"]));
    assert.equal(view.availability, "checked_out");
    const fx = await effects(control);
    assert.equal(fx.count, 1);
  });
});

test("R6 double checkout is refused", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    okJson(desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"]));
    const same = errJson(desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1100"]), CODES);
    const other = errJson(desk(state, service, ["checkout", "cam-1", "res-1", "loan-2", "1100"]), CODES);
    assert.equal(same.error, "already_checked_out");
    assert.equal(other.error, "already_checked_out");
    const view = okJson(desk(state, service, ["status", "cam-1", "1100"]));
    assert.equal(view.loan_id, "loan-1");
    assert.equal(view.borrower_id, "pat");
    const fx = await effects(control);
    assert.equal(fx.count, 1);
    assert.equal(fx.effects[0].request_id, "loan-1");
  });
});

test("R7 return refuses a loan that is not out", OPTS, async () => {
  await session(async ({ state, service }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    okJson(desk(state, service, ["add-item", "cam-2"]));
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    const reserved = errJson(desk(state, service, ["return", "cam-1", "loan-1", "1000"]), CODES);
    assert.equal(reserved.error, "not_checked_out");
    assert.equal(okJson(desk(state, service, ["status", "cam-1", "1000"])).availability, "reserved");
    const bare = errJson(desk(state, service, ["return", "cam-2", "loan-x", "1000"]), CODES);
    assert.equal(bare.error, "not_checked_out");
    okJson(desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"]));
    const wrong = errJson(desk(state, service, ["return", "cam-1", "loan-z", "1200"]), CODES);
    assert.equal(wrong.error, "loan_mismatch");
    assert.equal(okJson(desk(state, service, ["status", "cam-1", "1200"])).availability, "checked_out");
    const done = okJson(desk(state, service, ["return", "cam-1", "loan-1", "1300"]));
    assert.equal(done.availability, "available");
    assert.equal(done.loan_state, "returned");
  });
});

test("R8 crash after accept reconciles without a second effect", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    const crashed = desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"], "after-accept-before-record");
    assert.equal(killed(crashed), true);
    let fx = await effects(control);
    assert.equal(fx.count, 1);
    assert.equal(fx.effects[0].request_id, "loan-1");
    const mid = okJson(desk(state, service, ["status", "cam-1", "1000"]));
    assert.equal(mid.loan_state, "attempt_saved");
    assert.equal(mid.notify, "attempt_saved");
    okJson(desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"]));
    fx = await effects(control);
    assert.equal(fx.count, 1);
    assert.equal(fx.effects.every((row) => row.request_id === "loan-1"), true);
    const view = okJson(desk(state, service, ["status", "cam-1", "1000"]));
    assert.equal(view.availability, "checked_out");
    assert.equal(view.notify, "sent");
  });
});

test("R9 crash before request still completes once", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    const crashed = desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"], "after-attempt-saved-before-request");
    assert.equal(killed(crashed), true);
    let fx = await effects(control);
    assert.equal(fx.count, 0);
    assert.equal(fx.posts.length, 0);
    const mid = okJson(desk(state, service, ["status", "cam-1", "1000"]));
    assert.equal(mid.loan_state, "attempt_saved");
    assert.equal(mid.loan_id, "loan-1");
    const blocked = errJson(desk(state, service, ["checkout", "cam-1", "res-1", "loan-2", "1000"]), CODES);
    assert.equal(blocked.error, "checkout_in_progress");
    fx = await effects(control);
    assert.equal(fx.count, 0);
    okJson(desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"]));
    fx = await effects(control);
    assert.equal(fx.count, 1);
    assert.equal(fx.effects[0].request_id, "loan-1");
    assert.equal(okJson(desk(state, service, ["status", "cam-1", "1000"])).availability, "checked_out");
  });
});

test("R10 crash after durable record keeps outcome", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    const crashed = desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"], "after-record-before-exit");
    assert.equal(killed(crashed), true);
    const view = okJson(desk(state, service, ["status", "cam-1", "1000"]));
    assert.equal(view.availability, "checked_out");
    assert.equal(view.notify, "sent");
    const again = errJson(desk(state, service, ["checkout", "cam-1", "res-1", "loan-2", "1100"]), CODES);
    assert.equal(again.error, "already_checked_out");
    const fx = await effects(control);
    assert.equal(fx.count, 1);
    assert.equal(fx.effects[0].request_id, "loan-1");
  });
});

test("R11 lost reply is reconciled without a new post", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    await setFault(control, { drop_reply: true });
    desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"]);
    let fx = await effects(control);
    assert.equal(fx.count, 1);
    assert.equal(fx.effects[0].request_id, "loan-1");
    assert.equal(fx.effects.every((row) => row.request_id === "loan-1"), true);
    const posts = fx.posts.length;
    const rec = okJson(desk(state, service, ["reconcile", "loan-1"]));
    assert.equal(rec.notify, "sent");
    assert.equal(rec.availability, "checked_out");
    assert.notEqual(rec.notify, "not_sent");
    fx = await effects(control);
    assert.equal(fx.posts.length, posts);
    assert.equal(fx.count, 1);
    assert.equal(fx.effects[0].request_id, "loan-1");
    const view = okJson(desk(state, service, ["status", "cam-1", "1000"]));
    assert.equal(view.availability, "checked_out");
    assert.equal(view.notify, "sent");
  });
});

test("R12 success and refusal JSON protocol", OPTS, async () => {
  await session(async ({ state, service }) => {
    const made = okJson(desk(state, service, ["add-item", "cam-1"]));
    assert.equal(made.item_id, "cam-1");
    const refused = errJson(desk(state, service, ["checkout", "missing", "res-1", "loan-1", "1"]), CODES);
    assert.equal(typeof refused.error, "string");
  });
});

test("R13 unrelated writer file is preserved", OPTS, async () => {
  await session(async ({ state, service }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    const file = marker(state, "other.bin", "marker-bytes-9");
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    errJson(desk(state, service, ["return", "cam-1", "loan-1", "1000"]), CODES);
    okJson(desk(state, service, ["status", "cam-1", "1000"]));
    assert.equal(readMarker(file).toString("utf8"), "marker-bytes-9");
    assert.equal(okJson(desk(state, service, ["status", "cam-1", "1000"])).reservation_id, "res-1");
  });
});

test("R14 late callback does not overwrite", OPTS, async () => {
  await session(async ({ state, service, control }) => {
    okJson(desk(state, service, ["add-item", "cam-1"]));
    okJson(desk(state, service, ["reserve", "cam-1", "res-1", "pat", ADDR, "5000", "1000"]));
    okJson(desk(state, service, ["checkout", "cam-1", "res-1", "loan-1", "1000"]));
    const file = writeCb(state, {
      callback_id: "cb-loan-1",
      request_id: "loan-1",
      item_id: "cam-1",
      borrower_id: "pat",
      address: "other@loan.desk",
      kind: "checkout",
      outcome: "accepted",
    });
    assert.equal(desk(state, service, ["callback", file]).status, 0);
    assert.equal(desk(state, service, ["callback", file]).status, 0);
    const view = okJson(desk(state, service, ["status", "cam-1", "1000"]));
    assert.equal(view.address, ADDR);
    assert.equal(view.borrower_id, "pat");
    assert.equal(view.loan_id, "loan-1");
    assert.equal(view.availability, "checked_out");
    assert.equal(view.notify, "sent");
    const fx = await effects(control);
    assert.equal(fx.count, 1);
  });
});
