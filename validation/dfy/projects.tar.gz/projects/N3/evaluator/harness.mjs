import { spawn, spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import assert from "node:assert/strict";

export const PROJECT_DIR = process.env.PROJECT_DIR;
export const STUB_DIR = process.env.STUB_DIR;
export const OPTS = { timeout: 20000 };

export const CODES = new Set([
  "bad_args",
  "unknown_item",
  "id_in_use",
  "not_available",
  "not_reserved",
  "reservation_mismatch",
  "expired",
  "already_checked_out",
  "checkout_in_progress",
  "not_checked_out",
  "loan_mismatch",
  "service_unavailable",
  "conflict",
]);

export const CHANGE_CODES = new Set([...CODES, "not_needed", "already_waiting"]);

export function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ["server.mjs"], { cwd: STUB_DIR, stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    const timer = setTimeout(() => {
      child.kill("SIGKILL");
      reject(new Error("stub start timeout"));
    }, 5000);
    child.stdout.on("data", (chunk) => {
      buf += chunk.toString("utf8");
      const nl = buf.indexOf("\n");
      if (nl < 0) return;
      clearTimeout(timer);
      const line = JSON.parse(buf.slice(0, nl));
      resolve({
        service: line.service_url,
        control: line.control_url,
        kill() { child.kill("SIGKILL"); },
      });
    });
    child.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

export async function session(fn) {
  const stub = await startStub();
  const state = mkdtempSync(path.join(tmpdir(), "n3-"));
  try {
    await fn({ state, service: stub.service, control: stub.control });
  } finally {
    stub.kill();
    rmSync(state, { recursive: true, force: true });
  }
}

export function desk(stateDir, serviceUrl, args, crash) {
  const env = Object.assign({}, process.env, { STATE_DIR: stateDir, SERVICE_URL: serviceUrl });
  delete env.CRASH_AT;
  if (crash) env.CRASH_AT = crash;
  return spawnSync(path.join(PROJECT_DIR, "run"), args, { env, encoding: "utf8", timeout: 15000 });
}

export function killed(res) {
  return res.signal === "SIGKILL" || res.status === 137;
}

export function oneJson(res) {
  assert.equal(res.signal, null, "signal " + res.signal);
  const text = res.stdout.endsWith("\n") ? res.stdout.slice(0, -1) : res.stdout;
  assert.equal(text.includes("\n"), false, text);
  return JSON.parse(text);
}

export function okJson(res) {
  assert.equal(res.status, 0, res.stdout + res.stderr);
  return oneJson(res);
}

export function errJson(res, codes) {
  assert.notEqual(res.status, 0);
  assert.equal(res.signal, null);
  const obj = oneJson(res);
  assert.equal(typeof obj.error, "string");
  assert.equal(obj.error.length > 0, true);
  assert.equal(codes.has(obj.error), true, obj.error);
  return obj;
}

export async function effects(control) {
  const res = await fetch(control + "/effects");
  return res.json();
}

export async function setFault(control, body) {
  const res = await fetch(control + "/fault", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  assert.equal(res.status, 200);
}

export function ofKind(fx, kind) {
  return fx.effects.filter((row) => row.kind === kind);
}

export function writeCb(dir, obj) {
  const file = path.join(dir, "cb.json");
  writeFileSync(file, JSON.stringify(obj));
  return file;
}

export function marker(state, name, bytes) {
  const file = path.join(state, name);
  const res = spawnSync(process.execPath, ["-e", "require(\"fs\").writeFileSync(process.argv[1], process.argv[2])", file, bytes], { encoding: "utf8" });
  assert.equal(res.status, 0, res.stderr);
  return file;
}

export function readMarker(file) {
  return readFileSync(file);
}
