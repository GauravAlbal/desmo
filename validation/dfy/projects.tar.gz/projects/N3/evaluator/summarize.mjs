import { readFileSync } from "node:fs";

const file = process.argv[2];
const ids = process.argv.slice(3);
const text = file === "-" ? readFileSync(0, "utf8") : readFileSync(file, "utf8");
const seen = {};
for (const id of ids) seen[id] = "missing";
for (const line of text.split(/\n/)) {
  const match = line.match(/^(not )?ok \d+ - ((?:R|C)\d+)\b/);
  if (!match) continue;
  const id = match[2];
  if (!Object.prototype.hasOwnProperty.call(seen, id)) continue;
  if (match[1]) seen[id] = "fail";
  else if (seen[id] !== "fail") seen[id] = "pass";
}
for (const id of ids) {
  if (seen[id] !== "pass") seen[id] = "fail";
}
const failed = ids.filter((id) => seen[id] !== "pass");
const out = { requirements: seen, ok: failed.length === 0 };
process.stdout.write(JSON.stringify(out) + "\n");
process.exit(out.ok ? 0 : 1);
