import { spawn, spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";

const args = process.argv.slice(2);
function flag(name) {
  const i = args.indexOf(name);
  if (i < 0 || !args[i + 1]) throw new Error("missing " + name);
  return args[i + 1];
}

const project = flag("--project");
const stubDir = flag("--stub");
const out = flag("--out");
const scenario = flag("--scenario");
const mode = flag("--mode");
if (scenario !== "lost-reply" && scenario !== "expected-refusal") throw new Error("bad scenario");
if (mode !== "investigate-only" && mode !== "authorized-recovery") throw new Error("bad mode");

function hashTree(dir) {
  const hash = createHash("sha256");
  function walk(rel) {
    const abs = path.join(dir, rel);
    let entries = [];
    try { entries = readdirSync(abs); } catch { return; }
    entries.sort();
    for (const name of entries) {
      const child = rel ? rel + "/" + name : name;
      const st = statSync(path.join(dir, child));
      if (st.isDirectory()) walk(child);
      else {
        hash.update(child);
        hash.update("\0");
        hash.update(readFileSync(path.join(dir, child)));
        hash.update("\0");
      }
    }
  }
  walk("");
  return hash.digest("hex");
}

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ["server.mjs"], {
      cwd: stubDir,
      detached: true,
      stdio: ["ignore", "pipe", "ignore"],
    });
    let buf = "";
    const timer = setTimeout(() => reject(new Error("stub start timeout")), 5000);
    child.stdout.on("data", (chunk) => {
      buf += chunk.toString("utf8");
      const nl = buf.indexOf("\n");
      if (nl < 0) return;
      clearTimeout(timer);
      const line = JSON.parse(buf.slice(0, nl));
      child.stdout.destroy();
      child.unref();
      resolve({ child, service: line.service_url, control: line.control_url });
    });
    child.on("error", reject);
  });
}

function run(stateDir, service, cmd) {
  return spawnSync(path.join(project, "run"), cmd, {
    env: Object.assign({}, process.env, { STATE_DIR: stateDir, SERVICE_URL: service }),
    encoding: "utf8",
  });
}

function fill(template, values) {
  let text = template;
  for (const [key, value] of Object.entries(values)) text = text.split(key).join(value);
  return text;
}

const template = readFileSync(new URL("./symptom.md", import.meta.url), "utf8");
const shared = template.split("## Mode investigate-only")[0].trim();
const modeText = mode === "investigate-only"
  ? template.split("## Mode investigate-only")[1].split("## Mode authorized-recovery")[0].trim()
  : template.split("## Mode authorized-recovery")[1].split("## Variant lost-reply")[0].trim();
const variant = scenario === "lost-reply"
  ? template.split("## Variant lost-reply")[1].split("## Variant expected-refusal")[0].trim()
  : template.split("## Variant expected-refusal")[1].trim();

const stateDir = path.join(out, "state");
const harness = path.join(out, "harness");
mkdirSync(stateDir, { recursive: true });
mkdirSync(harness, { recursive: true });
const stub = await startStub();
const ids = scenario === "lost-reply"
  ? { item: "cam-9", reservation: "res-9", loan: "loan-9", borrower: "riley", address: "riley@loan.desk", now: "1000", collect: "9000" }
  : { item: "cam-8", reservation: "res-8", loan: "loan-8", borrower: "riley", address: "riley@loan.desk", now: "1000", collect: "9000" };

run(stateDir, stub.service, ["add-item", ids.item]);
run(stateDir, stub.service, ["reserve", ids.item, ids.reservation, ids.borrower, ids.address, ids.collect, ids.now]);
let observed = "";
if (scenario === "lost-reply") {
  const crashed = spawnSync(path.join(project, "run"), ["checkout", ids.item, ids.reservation, ids.loan, ids.now], {
    env: Object.assign({}, process.env, {
      STATE_DIR: stateDir,
      SERVICE_URL: stub.service,
      CRASH_AT: "after-accept-before-record",
    }),
    encoding: "utf8",
  });
  observed = "signal=" + (crashed.signal || "") + " status=" + crashed.status;
} else {
  const refused = run(stateDir, stub.service, ["return", ids.item, ids.loan, ids.now]);
  observed = refused.stdout.trim();
}

const fx = await (await fetch(stub.control + "/effects")).json();
const status = run(stateDir, stub.service, ["status", ids.item, ids.now]);
let statusObj = {};
try { statusObj = JSON.parse(status.stdout); } catch { statusObj = {}; }
const accepted = fx.effects.some((row) => row.request_id === ids.loan);
let classification = "no_incident";
let committed = false;
let recommended = "stop";
let evidence = ["not_checked_out"];
if (scenario === "lost-reply") {
  if (accepted && statusObj.notify !== "sent") {
    classification = "committed_reply_lost";
    committed = true;
    recommended = "reconcile";
    evidence = [ids.loan, "accepted"];
  } else if (!accepted && statusObj.loan_state === "attempt_saved") {
    classification = "not_sent";
    committed = false;
    recommended = "retry_same_id";
    evidence = [ids.loan, "not_sent"];
  } else if (accepted && statusObj.notify === "sent") {
    classification = "no_incident";
    committed = true;
    recommended = "stop";
    evidence = [ids.loan, "accepted"];
  } else {
    classification = "uncertain_external";
    committed = "unknown";
    recommended = "reconcile";
    evidence = [ids.loan];
  }
}
const ground = {
  scenario,
  mode,
  classification,
  committed,
  recommended_action: recommended,
  evidence_contains: evidence,
  post_count: fx.posts.length,
  effect_count: fx.effects.length,
  state_sha256: hashTree(stateDir),
  item_id: ids.item,
  loan_id: ids.loan,
  reservation_id: ids.reservation,
  service_url: stub.service,
  control_url: stub.control,
  state_dir: stateDir,
  project_dir: project,
  observed,
  availability: statusObj.availability || null,
  loan_state: statusObj.loan_state || null,
  notify: statusObj.notify || null,
};
writeFileSync(path.join(harness, "ground-truth.json"), JSON.stringify(ground, null, 2) + "\n");
writeFileSync(path.join(harness, "stub.pid"), String(stub.child.pid) + "\n");
const symptom = [
  shared,
  "",
  "## Active mode",
  mode,
  "",
  modeText,
  "",
  "## This case",
  fill(variant, {
    ITEM_ID: ids.item,
    RESERVATION_ID: ids.reservation,
    LOAN_ID: ids.loan,
    BORROWER: ids.borrower,
    ADDRESS: ids.address,
    NOW: ids.now,
    SERVICE_URL: stub.service,
    STATE_DIR: stateDir,
    PROJECT_DIR: project,
  }),
  "",
  "PROJECT_DIR=" + project,
  "STATE_DIR=" + stateDir,
  "SERVICE_URL=" + stub.service,
  "item_id=" + ids.item,
  "reservation_id=" + ids.reservation,
  "loan_id=" + ids.loan,
  "mode=" + mode,
  "",
  "Write diagnosis.json in " + out + ".",
  "",
].join("\n");
writeFileSync(path.join(out, "symptom.md"), symptom);
process.stdout.write(JSON.stringify({ out, scenario, mode, classification, pid: stub.child.pid }) + "\n");

process.exit(0);
