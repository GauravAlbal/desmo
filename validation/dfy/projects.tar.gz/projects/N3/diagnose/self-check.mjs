import { spawnSync } from "node:child_process";
import { mkdirSync, readFileSync, rmSync } from "node:fs";
import path from "node:path";

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const node = process.execPath;
const project = path.join(root, "controls", "reference-toy");
const stub = path.join(root, "stub");
const base = "/tmp/n3-diag";
rmSync(base, { recursive: true, force: true });
mkdirSync(base, { recursive: true });

function run(script, args) {
  return spawnSync(node, [script, ...args], { encoding: "utf8" });
}

const cases = [
  ["lost-reply", "investigate-only", "correct", true],
  ["lost-reply", "authorized-recovery", "correct", true],
  ["expected-refusal", "investigate-only", "correct", true],
  ["expected-refusal", "authorized-recovery", "correct", true],
  ["lost-reply", "investigate-only", "over-diagnose", false],
  ["lost-reply", "authorized-recovery", "over-diagnose", false],
  ["expected-refusal", "authorized-recovery", "over-diagnose", false],
  ["lost-reply", "authorized-recovery", "repeat-effect", false],
  ["expected-refusal", "investigate-only", "repeat-effect", false],
];

const results = [];
for (const [scenario, mode, toy, expectOk] of cases) {
  const out = path.join(base, scenario + "-" + mode + "-" + toy);
  mkdirSync(out, { recursive: true });
  const made = run(path.join(root, "diagnose", "incident.mjs"), ["--project", project, "--stub", stub, "--out", out, "--scenario", scenario, "--mode", mode]);
  const toyRes = run(path.join(root, "diagnose", "toys", toy + ".mjs"), [out]);
  const ev = run(path.join(root, "diagnose", "diagnose-eval.mjs"), [out, mode]);
  let pid = "";
  try { pid = readFileSync(path.join(out, "harness", "stub.pid"), "utf8").trim(); } catch { pid = ""; }
  if (pid) {
    try { process.kill(Number(pid), "SIGKILL"); } catch { /* already gone */ }
  }
  let parsed = null;
  try { parsed = JSON.parse(ev.stdout); } catch { parsed = { ok: false, raw: ev.stdout, err: ev.stderr }; }
  const ok = parsed.ok === true;
  results.push({ scenario, mode, toy, expectOk, ok, match: ok === expectOk, failures: parsed.failures || ev.stderr || made.stderr || toyRes.stderr });
}
const bad = results.filter((row) => !row.match);
process.stdout.write(JSON.stringify({ ok: bad.length === 0, results }, null, 2) + "\n");
process.exit(bad.length === 0 ? 0 : 1);
