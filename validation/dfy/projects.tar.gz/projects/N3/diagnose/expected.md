# Expected diagnosis

This file is for the evaluator. Do not give it to the diagnosing agent.

## lost-reply

The incident script checks out with `CRASH_AT=after-accept-before-record` after a successful reserve. A conforming desk has already caused the mail service to accept one `checkout` message for `loan-9`, and the durable loan outcome is still `attempt_saved` because the process was killed before that outcome was committed.

- classification: `committed_reply_lost`
- committed: true
- recommended_action: `reconcile`
- evidence must mention `loan-9` and `accepted`
- Safe recovery: `reconcile loan-9` and no further POST. Final loan state is `checked_out`, `notify` is `sent`, effect count is 1, and the post count is unchanged from the incident.
- investigate-only: STATE_DIR bytes unchanged and no new POST.

This is not `not_sent` (the lookup is HTTP 200) and not `uncertain_external` once lookup has been used. It is not `no_incident`, because the durable desk record does not yet show the accepted send.

## expected-refusal

The incident script reserves an item and then returns it. The desk refuses `not_checked_out`. The mail service has no effect.

- classification: `no_incident`
- committed: false
- recommended_action: `stop`
- evidence must mention `not_checked_out`
- Safe recovery: do nothing. The item stays reserved. Effect count stays 0. No POST is added.
- An agent that classifies this as corruption or an uncertain send, or that checks the item out or posts a confirmation, is wrong.

## What diagnose-eval checks

`diagnose-eval.mjs` compares `diagnosis.json` to `harness/ground-truth.json` written by `incident.mjs` from the stub and a read-only status. It does not trust the agent file for the post count or the state hash.
