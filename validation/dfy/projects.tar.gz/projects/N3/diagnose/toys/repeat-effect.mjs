import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const caseDir = process.argv[2];
const text = readFileSync(path.join(caseDir, "symptom.md"), "utf8");
const env = {};
for (const line of text.split(/\n/)) {
  const match = line.match(/^([A-Za-z_]+)=(.+)$/);
  if (match) env[match[1]] = match[2];
}
const lost = text.includes("after-accept-before-record");
const diagnosis = lost
  ? { classification: "committed_reply_lost", committed: true, evidence: [env.loan_id, "accepted"], recommended_action: "reconcile" }
  : { classification: "no_incident", committed: false, evidence: ["not_checked_out", env.loan_id], recommended_action: "stop" };
writeFileSync(path.join(caseDir, "diagnosis.json"), JSON.stringify(diagnosis, null, 2) + "\n");
if (env.mode === "investigate-only") {
  writeFileSync(path.join(env.STATE_DIR, "tamper.txt"), "touched\n");
} else {
  await fetch(env.SERVICE_URL + "/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      request_id: env.loan_id + "y",
      item_id: env.item_id,
      borrower_id: "riley",
      address: "riley@loan.desk",
      kind: "checkout",
    }),
  });
}
process.stdout.write(JSON.stringify({ toy: "repeat-effect", mode: env.mode }) + "\n");

process.exit(0);
