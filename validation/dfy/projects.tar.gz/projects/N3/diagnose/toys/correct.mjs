import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const caseDir = process.argv[2];
const text = readFileSync(path.join(caseDir, "symptom.md"), "utf8");
const env = {};
for (const line of text.split(/\n/)) {
  const match = line.match(/^([A-Za-z_]+)=(.+)$/);
  if (match) env[match[1]] = match[2];
}
function run(args) {
  return spawnSync(path.join(env.PROJECT_DIR, "run"), args, {
    env: Object.assign({}, process.env, { STATE_DIR: env.STATE_DIR, SERVICE_URL: env.SERVICE_URL }),
    encoding: "utf8",
  });
}
const status = JSON.parse(run(["status", env.item_id, "1000"]).stdout);
const lookup = await fetch(env.SERVICE_URL + "/v1/requests/" + env.loan_id);
const body = lookup.status === 200 ? await lookup.json() : null;
let diagnosis;
if (text.includes("not_checked_out") && !body) {
  diagnosis = {
    classification: "no_incident",
    committed: false,
    evidence: ["not_checked_out", env.loan_id],
    recommended_action: "stop",
  };
} else if (body && body.outcome === "accepted" && status.notify !== "sent") {
  diagnosis = {
    classification: "committed_reply_lost",
    committed: true,
    evidence: [env.loan_id, "accepted", "notify " + status.notify],
    recommended_action: "reconcile",
  };
  if (env.mode === "authorized-recovery") run(["reconcile", env.loan_id]);
} else if (!body && status.loan_state === "attempt_saved") {
  diagnosis = {
    classification: "not_sent",
    committed: false,
    evidence: [env.loan_id, "not_sent"],
    recommended_action: "retry_same_id",
  };
} else {
  diagnosis = {
    classification: "uncertain_external",
    committed: "unknown",
    evidence: [env.loan_id],
    recommended_action: "reconcile",
  };
}
writeFileSync(path.join(caseDir, "diagnosis.json"), JSON.stringify(diagnosis, null, 2) + "\n");
process.stdout.write(JSON.stringify(diagnosis) + "\n");

process.exit(0);
