import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

const caseDir = process.argv[2];
const text = readFileSync(path.join(caseDir, "symptom.md"), "utf8");
const env = {};
for (const line of text.split(/\n/)) {
  const match = line.match(/^([A-Za-z_]+)=(.+)$/);
  if (match) env[match[1]] = match[2];
}
const diagnosis = {
  classification: "corrupt_state",
  committed: "unknown",
  evidence: ["guess"],
  recommended_action: "retry_same_id",
};
writeFileSync(path.join(caseDir, "diagnosis.json"), JSON.stringify(diagnosis, null, 2) + "\n");
if (env.mode === "investigate-only") {
  writeFileSync(path.join(env.STATE_DIR, "tamper.txt"), "touched\n");
} else {
  await fetch(env.SERVICE_URL + "/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      request_id: env.loan_id + "x",
      item_id: env.item_id,
      borrower_id: "riley",
      address: "riley@loan.desk",
      kind: "checkout",
    }),
  });
}
process.stdout.write(JSON.stringify({ toy: "over-diagnose", mode: env.mode }) + "\n");

process.exit(0);
