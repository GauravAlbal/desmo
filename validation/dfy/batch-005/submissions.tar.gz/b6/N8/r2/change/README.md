# Subscription renewal ledger

`./run` is a single-subscription durable ledger. Lifecycle transitions and the
pending card effect are persisted by the Ikaros machine in `subscription.ik.toml`;
Node owns argument validation, local file selection, HTTP transport, and output.

## Setup

Node 22.17.1 is required. From this directory, with the supplied offline kit:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

The checked-in `run` wrapper uses the task's installed Node path. On another
machine, update that path in `run` (or invoke `app.mjs` with Node 22 directly).

## Running

Every invocation requires `STATE_DIR`, `SERVICE_URL`, and a canonical
non-negative `NOW_MS` value. `SERVICE_URL` is required even for `status`; status
never makes an HTTP request. The supplied service can be started with:

```sh
node stub/server.mjs
```

Use the printed `service_url` as `SERVICE_URL` (the stub's control URL is not
used by the application). Examples:

```sh
STATE_DIR=/tmp/subscription-state SERVICE_URL=http://127.0.0.1:53100 NOW_MS=0 \
  ./run open customer-1 subscription-1 basic 1730000000000 86400000 3
STATE_DIR=/tmp/subscription-state SERVICE_URL=http://127.0.0.1:53100 NOW_MS=1730000000000 \
  ./run renew
STATE_DIR=/tmp/subscription-state SERVICE_URL=http://127.0.0.1:53100 NOW_MS=1730000000000 \
  ./run status
```

The `downgrade <subscription_id> <new_plan>` command changes only to a
cheaper plan while active and without a saved attempt. It records
`last_plan`, exposes the calculated `proration_cents` (also retained as the
legacy `credit_cents` status field), and applies the credit once to the next
charge. A failed first POST records `first_failure_ms`; later retry grace is
measured from that failure rather than from the original renewal date.

Stores created by the prior machine definition remain readable and continue
under `subscription_v1.ik.toml`; new stores use the version-2 definition.
The new downgrade command is unavailable for those legacy stores.

After an uncertain external result, use `reconcile <charge_id>`; it never POSTs.

## Tests

The focused regression suite starts the supplied fake service and exercises
process-restart persistence, all three crash labels, dropped-reply recovery,
provider-effect idempotence, downgrade proration, revised failure grace,
status on an empty store, cancellation, and unrelated-file preservation:

```sh
node test.mjs
```

## Decisions and limits

- The kernel aggregate has a fixed internal id and stores the user-facing
  subscription id as a fact; this enforces the one-subscription-per-state-
  directory boundary without a second binding database.
- `first_failure_ms` is the timestamp of the first failed renewal POST; it is
  cleared after a successful renewal, and retry grace is measured from it.
- A syntactically valid JSON object passed to `callback` is intentionally
  ignored, as permitted by the brief. No callback shape was specified.
- No behavior or permission decision is outstanding. The application does not
  claim exactly-once external execution; it uses the provider's charge id and
  lookup reconciliation as specified.
