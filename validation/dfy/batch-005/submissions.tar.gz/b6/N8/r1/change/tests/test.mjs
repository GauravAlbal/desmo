import assert from "node:assert/strict";
import { mkdtemp, readFile, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawn, spawnSync } from "node:child_process";

const root = new URL("..", import.meta.url).pathname;
const node = "<home>/.nvm/versions/node/v22.17.1/bin/node";
const runPath = join(root, "run");
function cli(dir, url, now, args, extra = {}) {
  const p = spawnSync(runPath, args, { encoding: "utf8", env: { ...process.env, STATE_DIR: dir, SERVICE_URL: url, NOW_MS: String(now), ...extra } });
  let body = null;
  if (p.stdout.trim()) body = JSON.parse(p.stdout);
  return { ...p, body };
}
function ok(r) { assert.equal(r.status, 0, `${r.stderr}\n${r.stdout}`); assert.ok(r.body); return r.body; }
function refused(r, code) { assert.notEqual(r.status, 0); assert.deepEqual(r.body, { error: code }); }
async function service() {
  const child = spawn(node, [join(root, "stub/server.mjs")], { cwd: root, stdio: ["ignore", "pipe", "inherit"] });
  let line = "";
  const info = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("stub did not start")), 5000);
    child.stdout.on("data", chunk => { line += chunk; const i = line.indexOf("\n"); if (i >= 0) { clearTimeout(timer); resolve(JSON.parse(line.slice(0, i))); } });
    child.once("error", reject);
  });
  return { child, ...info };
}
async function control(url, body) { await fetch(url + "/fault", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }); }
const s = await service();
try {
  const empty = await mkdtemp(join(tmpdir(), "ledger-empty-"));
  ok(cli(empty, s.service_url, 1, ["status"]));
  await writeFile(join(empty, "unrelated.bin"), Buffer.from([0, 1, 2, 255]));
  ok(cli(empty, s.service_url, 1, ["open", "cust", "sub", "basic", "1000", "5000", "3"]));
  refused(cli(empty, s.service_url, 1, ["renew"]), "not_due");
  const before = await readFile(join(empty, "unrelated.bin"));
  const paid = ok(cli(empty, s.service_url, 1000, ["renew"]));
  assert.equal(paid.amount_cents, 1000);
  assert.deepEqual(await readFile(join(empty, "unrelated.bin")), before);
  assert.equal(ok(cli(empty, s.service_url, 1000, ["status"])).status, "active");

  const crashBefore = await mkdtemp(join(tmpdir(), "ledger-before-"));
  ok(cli(crashBefore, s.service_url, 2000, ["open", "cust", "before", "pro", "2000", "5000", "3"]));
  const killed = cli(crashBefore, s.service_url, 2000, ["renew"], { CRASH_AT: "after-charge-saved-before-request" });
  assert.notEqual(killed.status, 0);
  const saved = ok(cli(crashBefore, s.service_url, 2000, ["status"]));
  assert.equal(saved.status, "past_due"); assert.equal(saved.attempts, 1); assert.ok(saved.charge_id);
  assert.equal(ok(cli(crashBefore, s.service_url, 2000, ["renew"])).status, "active");

  const crashAfter = await mkdtemp(join(tmpdir(), "ledger-after-"));
  ok(cli(crashAfter, s.service_url, 3000, ["open", "cust", "after", "team", "3000", "5000", "3"]));
  const acceptedKilled = cli(crashAfter, s.service_url, 3000, ["renew"], { CRASH_AT: "after-accept-before-record" });
  assert.notEqual(acceptedKilled.status, 0);
  assert.equal(ok(cli(crashAfter, s.service_url, 3000, ["status"])).payment, "attempt_saved");
  assert.equal(ok(cli(crashAfter, s.service_url, 3000, ["renew"])).status, "active");

  const lost = await mkdtemp(join(tmpdir(), "ledger-lost-"));
  ok(cli(lost, s.service_url, 4000, ["open", "cust", "lost", "basic", "4000", "5000", "3"]));
  await control(s.control_url, { drop_reply: true });
  refused(cli(lost, s.service_url, 4000, ["renew"]), "service_unavailable");
  const lostStatus = ok(cli(lost, s.service_url, 4000, ["status"]));
  assert.equal(lostStatus.payment, "attempt_saved");
  await control(s.control_url, {});
  const reconciled = ok(cli(lost, s.service_url, 4000, ["reconcile", lostStatus.charge_id]));
  assert.equal(reconciled.lookup, "paid");
  refused(cli(lost, s.service_url, 4000, ["reconcile", "wrong-id"]), "charge_mismatch");

  const downgraded = await mkdtemp(join(tmpdir(), "ledger-downgrade-"));
  const cycle = 2592000000;
  ok(cli(downgraded, s.service_url, 0, ["open", "cust", "downgrade", "pro", String(cycle), "100", "3"]));
  const down = ok(cli(downgraded, s.service_url, 0, ["downgrade", "downgrade", "basic"]));
  assert.equal(down.plan, "basic");
  assert.equal(down.last_plan, "pro");
  assert.equal(down.proration_cents, 2000);
  assert.deepEqual(ok(cli(downgraded, s.service_url, 0, ["downgrade", "downgrade", "basic"])), down);
  refused(cli(downgraded, s.service_url, 0, ["downgrade", "downgrade", "team"]), "not_cheaper");
  const preparedDiscounted = cli(downgraded, s.service_url, cycle, ["renew"], { CRASH_AT: "after-charge-saved-before-request" });
  assert.notEqual(preparedDiscounted.status, 0);
  const preparedStatus = ok(cli(downgraded, s.service_url, cycle, ["status"]));
  assert.equal(preparedStatus.amount_cents, 1);
  const discounted = ok(cli(downgraded, s.service_url, cycle, ["renew"]));
  const effects = await (await fetch(s.control_url + "/effects")).json();
  assert.equal(effects.effects.filter(effect => effect.subscription_id === "downgrade").at(-1).amount_cents, 1);
  assert.equal(ok(cli(downgraded, s.service_url, cycle, ["status"])).proration_cents, 0);

  const revisedGrace = await mkdtemp(join(tmpdir(), "ledger-revised-grace-"));
  ok(cli(revisedGrace, s.service_url, 0, ["open", "cust", "revised", "basic", "1000", "100", "3"]));
  await control(s.control_url, { error_status: 503 });
  refused(cli(revisedGrace, s.service_url, 1050, ["renew"]), "service_unavailable");
  assert.equal(ok(cli(revisedGrace, s.service_url, 1050, ["status"])).first_failure_ms, 1050);
  await control(s.control_url, {});
  assert.equal(ok(cli(revisedGrace, s.service_url, 1125, ["renew"])).status, "active");
  assert.equal(ok(cli(revisedGrace, s.service_url, 1125, ["status"])).first_failure_ms, null);
  const expiredGrace = await mkdtemp(join(tmpdir(), "ledger-expired-grace-"));
  ok(cli(expiredGrace, s.service_url, 0, ["open", "cust", "expired-grace", "basic", "2000", "100", "3"]));
  await control(s.control_url, { error_status: 503 });
  refused(cli(expiredGrace, s.service_url, 2050, ["renew"]), "service_unavailable");
  await control(s.control_url, {});
  const postsBeforeExpiry = (await (await fetch(s.control_url + "/posts")).json()).count;
  refused(cli(expiredGrace, s.service_url, 2151, ["renew"]), "grace_elapsed");
  const postsAfterExpiry = (await (await fetch(s.control_url + "/posts")).json()).count;
  assert.equal(postsAfterExpiry, postsBeforeExpiry);
  assert.equal(ok(cli(expiredGrace, s.service_url, 2151, ["status"])).status, "expired");

  const callback = await mkdtemp(join(tmpdir(), "ledger-callback-"));
  ok(cli(callback, s.service_url, 5000, ["open", "cust", "callback", "basic", "5000", "5000", "3"]));
  const cbPath = join(callback, "callback.json"); await writeFile(cbPath, '{"status":"paid"}');
  assert.equal(ok(cli(callback, s.service_url, 5000, ["callback", cbPath])).callback, "ignored");
  await writeFile(cbPath, "not json"); refused(cli(callback, s.service_url, 5000, ["callback", cbPath]), "bad_callback");
  console.log("lifecycle tests passed");
} finally {
  s.child.kill("SIGTERM");
}
