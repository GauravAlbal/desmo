# Subscription renewal ledger

`./run` is a single-customer durable renewal ledger. Lifecycle transitions and
commits are owned by the installed Ikaros runtime; Node owns CLI validation,
files, and the HTTP adapter.

## Setup

From a clean checkout of this directory, with Node 22 available:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

The checked-in `package-lock.json` pins these local tarballs. No registry access
is needed. `run` uses `<home>/.nvm/versions/node/v22.17.1/bin/node`; edit
that one path if the named Node 22 installation is elsewhere.

## Running

Every invocation needs `STATE_DIR`, `SERVICE_URL`, and a non-negative decimal
`NOW_MS`:

```sh
SERVICE_URL=http://127.0.0.1:53000 NOW_MS=1700000000000 \
  STATE_DIR="$PWD/.state" ./run status
SERVICE_URL=http://127.0.0.1:53000 NOW_MS=1700000000000 \
  STATE_DIR="$PWD/.state" ./run open customer subscription basic 1700000000000 3600000 3
SERVICE_URL=http://127.0.0.1:53000 NOW_MS=1700000000000 \
  STATE_DIR="$PWD/.state" ./run renew
```

The supplied service can be started for local exercise with `node
stub/server.mjs`; it prints a `service_url` and a separate control URL. Only the
printed `service_url` belongs in `SERVICE_URL`. The service's control URL is for
test fault injection only, not for the application.

Commands are `open`, `renew`, `cancel`, `downgrade`, `reconcile <charge_id>`, `status`, and `callback <path>`. `downgrade <subscription_id> <new_plan>` records a cheaper plan and its whole-cent proration credit; the credit is applied once to the next charge. `CRASH_AT` may be set to any of the three labels in `BRIEF.md` to exercise recovery. A crash is intentional SIGKILL and leaves the last durable Ikaros commit intact.

## Tests

```sh
npm test
```

The test suite starts the supplied fake service, then covers process restart,
future-renewal refusal, unrelated-file preservation, all three crash labels,
dropped replies and reconciliation, wrong-charge reconciliation, and callback
handling.

The machine definition for new stores is `subscription.ik.toml`; its aggregate is stored as `ledger.sqlite` under `STATE_DIR`. Stores created by the previous release remain readable through `subscription.v1.ik.toml` and continue using their original machine identity. The provider charge id is allocated and committed before POST, and is reused for lookup and retry. A failed first POST records `first_failure_ms`; later retry deadlines are measured from that marker. No command retries an uncertain POST automatically. Provider matching is checked against the saved subscription, plan, renewal snapshot, and amount before an active record is committed.
