import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const root = new URL(".", import.meta.url).pathname;
const stateDir = mkdtempSync(join(tmpdir(), "warehouse-desk-"));
const unrelatedPath = join(stateDir, "unrelated.bin");
writeFileSync(unrelatedPath, Buffer.from([0, 1, 2, 255, 4]));
const stub = spawn(process.execPath, [join(root, "stub/server.mjs")], { cwd: root, stdio: ["ignore", "pipe", "inherit"] });
let line = "";
stub.stdout.setEncoding("utf8");
const info = await new Promise((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error("stub did not start")), 5000);
  stub.stdout.on("data", chunk => {
    line += chunk;
    const end = line.indexOf("\n");
    if (end >= 0) { clearTimeout(timer); resolve(JSON.parse(line.slice(0, end))); }
  });
});
const base = { STATE_DIR: stateDir, SERVICE_URL: info.service_url, NOW_MS: "100" };
function call(args, extra = {}) {
  const result = spawnSync(join(root, "run"), args, { cwd: root, env: { ...process.env, ...base, ...extra }, encoding: "utf8" });
  const text = result.stdout.trim();
  if (!text && result.signal) return { status: result.status, signal: result.signal, value: null };
  assert.ok(text, `no JSON for ${args.join(" ")}: ${result.stderr}`);
  return { status: result.status, signal: result.signal, value: JSON.parse(text) };
}
async function control(body) {
  const response = await fetch(`${info.control_url}/fault`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  assert.equal(response.status, 200);
}
async function effects() { return await (await fetch(`${info.control_url}/effects`)).json(); }

assert.deepEqual(call(["facility", "north", "5"]).value, { facility_id: "north", capacity: 5, held: 0, available: 5 });
assert.equal(call(["order", "o1", "north", "P1", "5000"]).value.state, "picked");
assert.equal(call(["pack", "o1"]).value.state, "packed");
let crashed = call(["book", "o1"], { CRASH_AT: "after-booking-saved-before-request" });
assert.equal(crashed.signal, "SIGKILL");
assert.deepEqual(call(["reconcile", "o1"]).value, { order_id: "o1", outcome: "not_sent" });
assert.equal((await effects()).count, 0);
assert.equal(call(["book", "o1"]).value.state, "booked");
assert.equal((await effects()).count, 1);

assert.equal(call(["order", "o2", "north", "P2", "5000"]).value.state, "picked");
assert.equal(call(["pack", "o2"]).value.state, "packed");
await control({ drop_reply: true });
assert.equal(call(["book", "o2"]).value.error, "unavailable");
await control({ drop_reply: false });
assert.equal(call(["reconcile", "o2"]).value.outcome, "booked");
assert.equal((await effects()).count, 2);

assert.equal(call(["order", "o3", "north", "P3", "5000"]).value.state, "picked");
assert.equal(call(["pack", "o3"]).value.state, "packed");
crashed = call(["book", "o3"], { CRASH_AT: "after-accept-before-record" });
assert.equal(crashed.signal, "SIGKILL");
assert.equal((await effects()).count, 3);
assert.equal(call(["book", "o3"]).value.state, "booked");
assert.equal((await effects()).count, 3);

assert.equal(call(["order", "o4", "north", "P4", "5000"]).value.state, "picked");
assert.equal(call(["pack", "o4"]).value.state, "packed");
crashed = call(["book", "o4"], { CRASH_AT: "after-record-before-exit" });
assert.equal(crashed.signal, "SIGKILL");
assert.equal(call(["status", "o4"]).value.state, "booked");
assert.equal(call(["book", "o4"]).value.state, "booked");
assert.equal((await effects()).count, 4);

assert.equal(call(["order", "o5", "north", "P4", "5000"]).value.error, "parcel_taken");
assert.equal(call(["facility-status", "north"]).value.held, 4);
assert.equal(call(["status", "o1"]).value.state, "booked");
assert.equal(call(["order", "o6", "north", "P6", "200"]).value.state, "picked");
assert.equal(call(["order", "o7", "north", "P7", "5000"]).value.error, "capacity_exceeded");
assert.equal(call(["status", "o6"], { NOW_MS: "200" }).value.state, "expired");
assert.equal(call(["facility-status", "north"]).value.held, 4);

assert.deepEqual(call(["facility", "south", "4"]).value, { facility_id: "south", capacity: 4, held: 0, available: 4 });
assert.deepEqual(call(["order", "s1", "south", "C2", "C1", "5000"]).value, {
  order_id: "s1", facility_id: "south", parcel_ids: ["C1", "C2"], pickup_deadline_ms: 5000,
  state: "picked", request_id: null, booking_id: null,
});
assert.deepEqual(call(["facility-status", "south"]).value, { facility_id: "south", capacity: 4, held: 2, available: 2 });
assert.equal(call(["pack", "s1"]).value.state, "packed");
assert.equal(call(["cancel", "s1"]).value.state, "cancelled");
assert.equal(call(["facility-status", "south"]).value.held, 0);
assert.equal(call(["order", "s2", "south", "D2", "D1", "5000"]).value.state, "picked");
assert.equal(call(["pack", "s2"]).value.state, "packed");
assert.equal(call(["unpack", "s2"]).value.state, "picked");
assert.equal(call(["unpack", "s2"]).value.error, "picked");
assert.equal(call(["pack", "s2"]).value.state, "packed");
assert.equal(call(["book", "s2"]).value.state, "booked");
const consolidatedEffects = await effects();
assert.equal(consolidatedEffects.count, 5);
assert.deepEqual(consolidatedEffects.effects.at(-1).parcel_ids, ["D1", "D2"]);
assert.equal(call(["book", "s2"]).value.state, "booked");
assert.equal((await effects()).count, 5);
assert.equal(call(["order", "s3", "south", "D3", "D1", "5000"]).value.error, "parcel_taken");
assert.equal(call(["facility-status", "south"]).value.held, 2);

assert.deepEqual(readFileSync(unrelatedPath), Buffer.from([0, 1, 2, 255, 4]));
const finalEffects = await effects();
stub.kill("SIGTERM");
await new Promise(resolve => stub.once("exit", resolve));
console.log(JSON.stringify({ ok: true, stateDir, effects: finalEffects.count }));
