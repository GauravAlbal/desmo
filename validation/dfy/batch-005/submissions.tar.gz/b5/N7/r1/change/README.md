# Warehouse outbound shipment desk

This is a single-process local desk for facilities and outbound orders. The order
lifecycle is persisted by Ikaros in `STATE_DIR/ikaros.sqlite`; the facility and
order lookup indexes are the desk's own `facilities.json` and `orders.json` files.
The desk only creates or replaces those files and leaves other files in `STATE_DIR`
alone.

New orders use the version-2 shipment machine and may hold one or more parcels.
Parcel lists are sorted in the stored/result representation and one booking covers
the complete list. Existing order-index rows without `lifecycle_version` continue
to use the version-1 machine and remain readable without migration.

## Setup

Node 22 is required. From this directory, with the supplied local tarballs available:

```sh
<home>/.nvm/versions/node/v22.17.1/bin/npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

`run` already names the required Node 22 executable and is executable after checkout.
No Python environment or network package download is needed.

## Running

Every invocation needs `STATE_DIR`; lifecycle operations also need a decimal `NOW_MS`.
Booking needs `SERVICE_URL`, the base URL printed by `node stub/server.mjs` (or a
compatible carrier service).

```sh
export STATE_DIR=/path/to/state
export SERVICE_URL=http://127.0.0.1:PORT
export NOW_MS=1000
./run facility north 3
./run order order-1 north parcel-1 parcel-2 5000
./run pack order-1
./run unpack order-1       # optional: packed -> picked
./run pack order-1
./run book order-1         # or cancel while packed, before booking
./run status order-1
./run facility-status north
./run reconcile order-1
./run expire order-1
```

The original one-parcel order form (`order <id> <facility> <parcel> <deadline>`)
remains valid. A packed version-2 order can be cancelled or unpacked while it has
no open booking attempt. Attempt-saved and booked orders cannot be cancelled or
unpacked.

Each process writes exactly one JSON object to stdout. Successful commands exit 0;
refusals exit nonzero and have an `error` field. `CRASH_AT` can be set to one of the
three documented crash boundaries in `BRIEF.md` to exercise recovery. A crashed
booking must be reconciled or retried with the same saved request id; the desk never
allocates a replacement id for an open attempt.

For a local carrier stub:

```sh
node stub/server.mjs
# use its service_url as SERVICE_URL
```

## Checks and tests

The machine identities and advisory law inventory are available with:

```sh
node_modules/@ikaros/darwin-arm64/bin/ik identity shipment.ik.toml
node_modules/@ikaros/darwin-arm64/bin/ik identity shipment_v2.ik.toml
node_modules/@ikaros/darwin-arm64/bin/ik laws shipment_v2.ik.toml
node_modules/@ikaros/darwin-arm64/bin/ik check shipment_v2.ik.toml --profile .ik/checks.toml --corpus shipment_v2.ik.cases.json
node test.mjs
```

`test.mjs` starts the supplied stub and covers process restart, all three crash
boundaries, a dropped provider reply, lookup-only reconciliation, idempotent
booking, parcel exclusivity, capacity, expiration, multi-parcel booking,
packed cancellation, unpack, and preservation of an unrelated file.
