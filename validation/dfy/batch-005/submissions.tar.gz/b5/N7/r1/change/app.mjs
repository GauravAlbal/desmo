import { createHash, randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync, openSync, closeSync, fsyncSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { Kernel, Capability, HistoricalResult, KernelError, StoreNotFoundError, TransportError } from "@ikaros/runtime";

const ROOT = dirname(fileURLToPath(import.meta.url));
const MACHINE_PATH = join(ROOT, "shipment.ik.toml");
const MACHINE_V2_PATH = join(ROOT, "shipment_v2.ik.toml");
const stateDir = process.env.STATE_DIR;
const serviceUrl = process.env.SERVICE_URL;
const crashAt = process.env.CRASH_AT || "";
const commandArgs = process.argv.slice(2);
const own = {
  facilities: () => join(stateDir, "facilities.json"),
  orders: () => join(stateDir, "orders.json"),
  store: () => join(stateDir, "ikaros.sqlite"),
};

function fail(error) { throw new Error(error); }
function id(value, parcel = false) {
  const max = parcel ? 32 : 64;
  return typeof value === "string" && value.length >= 1 && value.length <= max && /^[A-Za-z0-9._-]+$/.test(value);
}
function decimal(value, max, error) {
  if (typeof value !== "string" || !/^\d+$/.test(value)) fail(error);
  const n = BigInt(value);
  if (n > BigInt(max)) fail(error);
  return n <= BigInt(Number.MAX_SAFE_INTEGER) ? Number(n) : n;
}
function nowMs() {
  return decimal(process.env.NOW_MS, Number.MAX_SAFE_INTEGER, "bad_deadline");
}
function jsonSafe(value) {
  return JSON.stringify(value, (_, v) => typeof v === "bigint" ? Number(v) : v);
}
function readJson(path, initial) {
  if (!existsSync(path)) return initial;
  return JSON.parse(readFileSync(path, "utf8"));
}
function durableJson(path, value) {
  mkdirSync(dirname(path), { recursive: true });
  const tmp = `${path}.tmp-${process.pid}`;
  const fd = openSync(tmp, "w", 0o600);
  try {
    writeFileSync(fd, jsonSafe(value) + "\n", "utf8");
    fsyncSync(fd);
  } finally { closeSync(fd); }
  renameSync(tmp, path);
}
function facilities() { return readJson(own.facilities(), { facilities: {} }); }
function orders() { return readJson(own.orders(), { orders: {} }); }
function saveOrders(value) { durableJson(own.orders(), value); }
function saveFacilities(value) { durableJson(own.facilities(), value); }
function kernel() { return new Kernel(own.store()); }
async function machine(version = 1) {
  return (await kernel().machine(version === 2 ? MACHINE_V2_PATH : MACHINE_PATH));
}
function factsOf(aggregate) { return aggregate.state || {}; }
function decodeParcelIds(value) {
  if (typeof value !== "string") return [];
  if (value.startsWith("[")) {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed) && parsed.every(item => typeof item === "string")) return parsed;
    } catch { /* a legacy parcel id cannot start with '[' */ }
  }
  return [value];
}
function encodeParcelIds(parcelIds) {
  return parcelIds.length === 1 ? parcelIds[0] : JSON.stringify(parcelIds);
}
function metadataParcelIds(meta) {
  if (Array.isArray(meta?.parcel_ids)) return meta.parcel_ids;
  return meta?.parcel_id === undefined ? [] : decodeParcelIds(meta.parcel_id);
}
function lifecycleVersion(meta) { return meta?.lifecycle_version === 2 ? 2 : 1; }
function sameArray(a, b) { return a.length === b.length && a.every((value, index) => value === b[index]); }
function outputOrder(aggregate) {
  const f = factsOf(aggregate);
  return {
    order_id: aggregate.id,
    facility_id: f.facility_id,
    parcel_ids: decodeParcelIds(f.parcel_id),
    pickup_deadline_ms: typeof f.pickup_deadline_ms === "bigint" ? Number(f.pickup_deadline_ms) : f.pickup_deadline_ms,
    state: aggregate.namedState(),
    request_id: f.request_id ?? null,
    booking_id: f.booking_id ?? null,
  };
}
function providerUrl(path) {
  if (!serviceUrl) fail("unavailable");
  return `${serviceUrl.replace(/\/$/, "")}${path}`;
}
function sha256(text) { return createHash("sha256").update(text).digest("hex"); }
function crash(boundary) { if (crashAt === boundary) process.kill(process.pid, "SIGKILL"); }

async function showOrder(idValue, m = null, version = 1) {
  try { return await (m || await machine(version)).show(idValue); }
  catch (error) {
    if (error instanceof StoreNotFoundError || error?.code === "IK_STORE_NOT_FOUND" || error?.rule === "aggregate.not_found") fail("unknown_order");
    if (error instanceof KernelError && error.code === "IK_ILLEGAL_STATE") fail("unknown_order");
    throw error;
  }
}
function orderMeta(orderId) {
  const meta = orders().orders[orderId];
  if (!meta) fail("unknown_order");
  return meta;
}
async function transition(aggregate, name, args) {
  const result = await aggregate.execute({ name, ...(args === undefined ? {} : { args }) });
  if (result instanceof HistoricalResult) return await aggregate.machine.show(aggregate.id);
  return result;
}
async function expireIfDue(aggregate, currentNow) {
  const state = aggregate.namedState();
  const deadline = factsOf(aggregate).pickup_deadline_ms;
  if ((state === "picked" || state === "packed") && BigInt(currentNow) >= BigInt(deadline)) {
    return await transition(aggregate, "expire", { now_ms: currentNow });
  }
  return aggregate;
}
async function knownOrders() {
  const data = orders();
  const rows = [];
  for (const [orderId, meta] of Object.entries(data.orders)) {
    try { rows.push({ id: orderId, meta, aggregate: await showOrder(orderId, null, lifecycleVersion(meta)) }); }
    catch (error) { if (error?.message === "unknown_order") continue; throw error; }
  }
  return rows;
}
async function observeFacility(facilityId, currentNow) {
  const fdata = facilities();
  if (!fdata.facilities[facilityId]) fail("unknown_facility");
  const rows = await knownOrders();
  for (const row of rows) {
    if (row.meta.facility_id !== facilityId) continue;
    row.aggregate = await expireIfDue(row.aggregate, currentNow);
  }
  return { facility: fdata.facilities[facilityId], rows: rows.filter(r => r.meta.facility_id === facilityId) };
}
function held(state) { return state !== "cancelled" && state !== "expired"; }
function ensureArity(n) { if (commandArgs.length !== n) fail("bad_args"); }
function validateOrderIds(orderId, facilityId, parcelIds) {
  if (!id(orderId) || !id(facilityId) || parcelIds.length === 0 || parcelIds.some(parcelId => !id(parcelId, true))) fail("bad_id");
  if (new Set(parcelIds).size !== parcelIds.length) fail("bad_id");
}
async function commandFacility() {
  ensureArity(2);
  const [facilityId, capacityText] = commandArgs;
  if (!id(facilityId)) fail("bad_id");
  const capacity = decimal(capacityText, 100000, "bad_capacity");
  if (!Number.isInteger(capacity) || capacity < 1) fail("bad_capacity");
  const data = facilities();
  const old = data.facilities[facilityId];
  if (old && old.capacity !== capacity) fail("conflict");
  if (!old) { data.facilities[facilityId] = { capacity }; saveFacilities(data); }
  return facilityStatusObject(facilityId, nowMs());
}
async function facilityStatusObject(facilityId, currentNow) {
  const observed = await observeFacility(facilityId, currentNow);
  const active = observed.rows.filter(r => held(r.aggregate.namedState()));
  const heldCount = active.reduce((sum, row) => sum + metadataParcelIds(row.meta).length, 0);
  return { facility_id: facilityId, capacity: observed.facility.capacity, held: heldCount, available: observed.facility.capacity - heldCount };
}
async function commandFacilityStatus() {
  ensureArity(1);
  const [facilityId] = commandArgs;
  if (!id(facilityId)) fail("bad_id");
  return facilityStatusObject(facilityId, nowMs());
}
async function commandOrder() {
  if (commandArgs.length < 4) fail("bad_args");
  const orderId = commandArgs[0];
  const facilityId = commandArgs[1];
  const parcelIds = commandArgs.slice(2, -1).slice().sort();
  const deadline = decimal(commandArgs.at(-1), Number.MAX_SAFE_INTEGER, "bad_deadline");
  validateOrderIds(orderId, facilityId, parcelIds);
  const fdata = facilities();
  if (!fdata.facilities[facilityId]) fail("unknown_facility");
  const odata = orders();
  const existing = odata.orders[orderId];
  if (existing) {
    if (existing.facility_id !== facilityId || !sameArray(metadataParcelIds(existing), parcelIds) || BigInt(existing.pickup_deadline_ms) !== BigInt(deadline)) fail("conflict");
    try { return outputOrder(await showOrder(orderId, null, lifecycleVersion(existing))); }
    catch (error) {
      if (error?.message !== "unknown_order") throw error;
      delete odata.orders[orderId];
      saveOrders(odata);
    }
  }
  const observed = await observeFacility(facilityId, nowMs());
  if (observed.rows.some(r => held(r.aggregate.namedState()) && metadataParcelIds(r.meta).some(parcelId => parcelIds.includes(parcelId)))) fail("parcel_taken");
  const heldCount = observed.rows.filter(r => held(r.aggregate.namedState())).reduce((sum, row) => sum + metadataParcelIds(row.meta).length, 0);
  if (heldCount + parcelIds.length > observed.facility.capacity) fail("capacity_exceeded");
  const encodedParcelIds = encodeParcelIds(parcelIds);
  odata.orders[orderId] = { facility_id: facilityId, parcel_ids: parcelIds, parcel_id: encodedParcelIds, pickup_deadline_ms: deadline, lifecycle_version: 2 };
  saveOrders(odata);
  const m = await machine(2);
  const created = await m.createWith({ aggregateId: orderId, command: { name: "initialize", args: { facility_id: facilityId, parcel_id: encodedParcelIds, pickup_deadline_ms: deadline } } });
  const aggregate = created instanceof HistoricalResult ? await m.show(orderId) : created;
  return outputOrder(aggregate);
}
async function commandPack() {
  ensureArity(1);
  const [orderId] = commandArgs;
  if (!id(orderId)) fail("bad_id");
  const meta = orderMeta(orderId);
  const currentNow = nowMs();
  let aggregate = await showOrder(orderId, null, lifecycleVersion(meta));
  aggregate = await expireIfDue(aggregate, currentNow);
  const state = aggregate.namedState();
  if (state === "packed") return outputOrder(aggregate);
  if (state === "expired") fail("expired");
  if (state === "cancelled") fail("cancelled");
  if (state === "attempt_saved") fail("attempt_saved");
  if (state === "booked") fail("booked");
  return outputOrder(await transition(aggregate, "pack", { now_ms: currentNow }));
}
async function commandCancel() {
  ensureArity(1);
  const [orderId] = commandArgs;
  if (!id(orderId)) fail("bad_id");
  const meta = orderMeta(orderId);
  let aggregate = await showOrder(orderId, null, lifecycleVersion(meta));
  aggregate = await expireIfDue(aggregate, nowMs());
  const state = aggregate.namedState();
  if (state === "cancelled" || state === "expired") return outputOrder(aggregate);
  if (state === "attempt_saved" || state === "booked") fail("cancel_open");
  if (state === "packed") {
    if (lifecycleVersion(meta) === 1) fail("not_picked");
    return outputOrder(await transition(aggregate, "cancel_packed"));
  }
  return outputOrder(await transition(aggregate, "cancel_picked"));
}
async function commandUnpack() {
  ensureArity(1);
  const [orderId] = commandArgs;
  if (!id(orderId)) fail("bad_id");
  const meta = orderMeta(orderId);
  let aggregate = await showOrder(orderId, null, lifecycleVersion(meta));
  aggregate = await expireIfDue(aggregate, nowMs());
  const state = aggregate.namedState();
  if (state === "picked") fail("picked");
  if (state === "cancelled") fail("cancelled");
  if (state === "expired") fail("expired");
  if (state === "attempt_saved") fail("attempt_saved");
  if (state === "booked") fail("booked");
  return outputOrder(await transition(aggregate, "unpack"));
}
async function commandExpire() {
  ensureArity(1);
  const [orderId] = commandArgs;
  if (!id(orderId)) fail("bad_id");
  const meta = orderMeta(orderId);
  let aggregate = await showOrder(orderId, null, lifecycleVersion(meta));
  const currentNow = nowMs();
  const state = aggregate.namedState();
  if (state === "attempt_saved" || state === "booked") fail("cancel_open");
  if (state === "expired") return outputOrder(aggregate);
  if (state === "cancelled") return outputOrder(aggregate);
  if (BigInt(currentNow) < BigInt(factsOf(aggregate).pickup_deadline_ms)) fail("not_due");
  return outputOrder(await transition(aggregate, "expire", { now_ms: currentNow }));
}
function requestBody(orderId, aggregate, requestId) {
  const f = factsOf(aggregate);
  return { request_id: requestId, order_id: orderId, facility_id: f.facility_id, parcel_ids: decodeParcelIds(f.parcel_id) };
}
async function callProvider(method, path, body) {
  let response;
  try {
    response = await fetch(providerUrl(path), { method, headers: body === undefined ? {} : { "content-type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(5000) });
  } catch { fail("unavailable"); }
  let text;
  try { text = await response.text(); } catch { fail("unavailable"); }
  if (response.status === 404) return { kind: "not_found", text };
  if (response.status !== 200) {
    if (response.status === 409) return { kind: "conflict", text };
    fail("unavailable");
  }
  let parsed;
  try { parsed = JSON.parse(text); } catch { fail("unavailable"); }
  return { kind: "ok", text, value: parsed };
}
function matchingProvider(value, expected) {
  const actualParcels = Array.isArray(value?.parcel_ids) ? value.parcel_ids.slice().sort() : null;
  const expectedParcels = expected.parcel_ids.slice().sort();
  if (!value || value.request_id !== expected.request_id || value.order_id !== expected.order_id || value.facility_id !== expected.facility_id || !actualParcels || !sameArray(actualParcels, expectedParcels) || typeof value.booking_id !== "string" || value.outcome !== "booked") fail("conflict");
  return value;
}
function effectBody(intent, digest) {
  return { effect_id: intent.effectId, aggregate_id: intent.aggregateId, planned_generation: intent.generation, payload_digest: intent.payloadDigest, idempotency_key: intent.idempotencyKey, outcome_digest: digest };
}
async function recordOutcome(aggregate, digest) {
  if (!aggregate.pendingIntent) return aggregate;
  const intent = aggregate.pendingIntent;
  const operationId = aggregate.machine.kernel.newOperationId();
  const capability = Capability.fromWire(aggregate.capability.toWire());
  const effect = effectBody(intent, digest);
  try {
    const result = await aggregate.recordEffectOutcome(digest, { operationId, intent });
    return result instanceof HistoricalResult ? await aggregate.machine.show(aggregate.id) : result;
  } catch (error) {
    if (!(error instanceof TransportError)) throw error;
    const found = await aggregate.machine.lookupOperation(aggregate.id, capability, operationId, { effect });
    if (found.outcome === "committed_exact") return await aggregate.machine.show(aggregate.id);
    fail("unavailable");
  }
}
async function commandBook() {
  ensureArity(1);
  const [orderId] = commandArgs;
  if (!id(orderId)) fail("bad_id");
  const meta = orderMeta(orderId);
  let aggregate = await showOrder(orderId, null, lifecycleVersion(meta));
  aggregate = await expireIfDue(aggregate, nowMs());
  const state = aggregate.namedState();
  if (state === "booked") return outputOrder(aggregate);
  if (state === "expired") fail("expired");
  if (state === "cancelled") fail("cancelled");
  if (state === "picked") fail("picked");
  if (state === "packed") {
    const requestId = randomUUID().replace(/-/g, "");
    const body = requestBody(orderId, aggregate, requestId);
    aggregate = await transition(aggregate, "save_attempt", { request_id: requestId, payload_digest: sha256(JSON.stringify(body)) });
    crash("after-booking-saved-before-request");
  }
  if (aggregate.namedState() !== "attempt_saved") fail("unavailable");
  const f = factsOf(aggregate);
  const expected = requestBody(orderId, aggregate, f.request_id);
  let response = await callProvider("GET", `/v1/bookings/${encodeURIComponent(f.request_id)}`);
  if (response.kind === "not_found") response = await callProvider("POST", "/v1/bookings", expected);
  if (response.kind === "conflict") fail("conflict");
  const booking = matchingProvider(response.value, expected);
  crash("after-accept-before-record");
  aggregate = await recordOutcome(aggregate, sha256(response.text));
  aggregate = await transition(aggregate, "accept_booking", { booking_id: booking.booking_id });
  crash("after-record-before-exit");
  return outputOrder(aggregate);
}
async function commandReconcile() {
  ensureArity(1);
  const [orderId] = commandArgs;
  if (!id(orderId)) fail("bad_id");
  const meta = orderMeta(orderId);
  const aggregate = await showOrder(orderId, null, lifecycleVersion(meta));
  const state = aggregate.namedState();
  if (state === "booked") return { ...outputOrder(aggregate), outcome: "booked" };
  if (state !== "attempt_saved") return { order_id: orderId, outcome: "not_applicable" };
  const f = factsOf(aggregate);
  const expected = requestBody(orderId, aggregate, f.request_id);
  const response = await callProvider("GET", `/v1/bookings/${encodeURIComponent(f.request_id)}`);
  if (response.kind === "not_found") return { order_id: orderId, outcome: "not_sent" };
  if (response.kind === "conflict") fail("conflict");
  const booking = matchingProvider(response.value, expected);
  let current = await recordOutcome(aggregate, sha256(response.text));
  current = await transition(current, "accept_booking", { booking_id: booking.booking_id });
  return { ...outputOrder(current), outcome: "booked" };
}
async function commandStatus() {
  ensureArity(1);
  const [orderId] = commandArgs;
  if (!id(orderId)) fail("bad_id");
  const meta = orderMeta(orderId);
  let aggregate = await showOrder(orderId, null, lifecycleVersion(meta));
  aggregate = await expireIfDue(aggregate, nowMs());
  return outputOrder(aggregate);
}
async function dispatch() {
  if (!stateDir) fail("unavailable");
  mkdirSync(stateDir, { recursive: true });
  if (commandArgs.length === 0) fail("bad_args");
  const command = commandArgs[0];
  commandArgs.shift();
  switch (command) {
    case "facility": return commandFacility();
    case "order": return commandOrder();
    case "pack": return commandPack();
    case "book": return commandBook();
    case "cancel": return commandCancel();
    case "unpack": return commandUnpack();
    case "expire": return commandExpire();
    case "status": return commandStatus();
    case "facility-status": return commandFacilityStatus();
    case "reconcile": return commandReconcile();
    default: fail("bad_args");
  }
}
try {
  const result = await dispatch();
  process.stdout.write(jsonSafe(result) + "\n");
} catch (error) {
  const message = error?.message || "unavailable";
  process.stdout.write(JSON.stringify({ error: message }) + "\n");
  process.exitCode = 1;
}
