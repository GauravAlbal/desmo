import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { once } from "node:events";

const ROOT = path.dirname(new URL(import.meta.url).pathname);
const RUN = path.join(ROOT, "run");
const state = fs.mkdtempSync(path.join(os.tmpdir(), "warehouse-test-"));
const unrelated = path.join(state, "unrelated.bin");
const unrelatedBytes = Buffer.from([0, 1, 2, 255, 254, 10]);
fs.writeFileSync(unrelated, unrelatedBytes);

const stub = spawn(process.execPath, [path.join(ROOT, "stub/server.mjs")], { cwd: ROOT, stdio: ["ignore", "pipe", "inherit"] });
let line = "";
stub.stdout.on("data", (chunk) => { line += chunk.toString(); });
while (!line.includes("\n")) await once(stub.stdout, "data");
const config = JSON.parse(line.trim().split("\n")[0]);

function invoke(args, extra = {}) {
  const result = spawnSync(RUN, args, {
    cwd: ROOT,
    env: { ...process.env, STATE_DIR: state, NOW_MS: "10", SERVICE_URL: config.service_url, ...extra },
   encoding: "utf8",
   });
   const text = String(result.stdout ?? "").trim();
   const json = text ? JSON.parse(text) : null;
   if (json) assert.equal(text.split("\n").length, 1, `one JSON result: ${text}`);
   return { ...result, json };
}
function ok(args, extra) {
  const result = invoke(args, extra);
  assert.equal(result.status, 0, `${args.join(" ")}: ${result.stdout}${result.stderr}`);
  return result.json;
}
function refused(args, code, extra) {
  const result = invoke(args, extra);
  assert.notEqual(result.status, 0, `${args.join(" ")} unexpectedly succeeded`);
  assert.deepEqual(result.json, { error: code });
}
async function control(pathname, method = "GET", body) {
  const response = await fetch(config.control_url + pathname, {
    method,
    headers: body ? { "content-type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  return response.json();
}

try {
   assert.deepEqual(ok(["facility", "north", "10"]), { facility_id: "north", capacity: 10, held: 0, available: 10 });
  assert.deepEqual(ok(["order", "o1", "north", "P1", "1000"]), { order_id: "o1", facility_id: "north", parcel_ids: ["P1"], pickup_deadline_ms: 1000, state: "picked", request_id: null, booking_id: null });
  assert.equal(ok(["pack", "o1"]).state, "packed");
  const booked = ok(["book", "o1"]);
  assert.equal(booked.state, "booked");
  assert.equal((await control("/effects")).count, 1);
  assert.deepEqual(ok(["book", "o1"]), booked);
  assert.equal((await control("/effects")).count, 1);
   refused(["pack", "o1"], "booked");

  ok(["order", "o2", "north", "P2", "1000"]);
  ok(["pack", "o2"]);
  const pre = invoke(["book", "o2"], { CRASH_AT: "after-booking-saved-before-request" });
  assert.notEqual(pre.status, 0);
  assert.deepEqual(ok(["reconcile", "o2"]), { outcome: "not_sent" });
  assert.equal((await control("/effects")).count, 1);

  ok(["order", "o3", "north", "P3", "1000"]);
  ok(["pack", "o3"]);
  const accepted = invoke(["book", "o3"], { CRASH_AT: "after-accept-before-record" });
  assert.notEqual(accepted.status, 0);
  assert.equal((await control("/effects")).count, 2);
  assert.equal(ok(["reconcile", "o3"]).outcome, "booked");
  assert.equal((await control("/effects")).count, 2);

  ok(["order", "o4", "north", "P4", "1000"]);
  ok(["pack", "o4"]);
  const afterRecord = invoke(["book", "o4"], { CRASH_AT: "after-record-before-exit" });
  assert.notEqual(afterRecord.status, 0);
  assert.equal(ok(["status", "o4"]).state, "booked");
  ok(["book", "o4"]);
  assert.equal((await control("/effects")).count, 3);

  ok(["order", "o5", "north", "P5", "1000"]);
  ok(["pack", "o5"]);
  await control("/fault", "POST", { drop_reply: true });
  refused(["book", "o5"], "unavailable");
  await control("/fault", "POST", { drop_reply: false });
  assert.equal(ok(["reconcile", "o5"]).outcome, "booked");
  assert.equal((await control("/effects")).count, 4);

  refused(["order", "other", "north", "P1", "1000"], "parcel_taken");
  ok(["order", "cancel-me", "north", "P6", "1000"]);
  assert.equal(ok(["cancel", "cancel-me"]).state, "cancelled");
  assert.equal(ok(["facility-status", "north"]).held, 5);
  refused(["pack", "cancel-me"], "cancelled");
  refused(["status", "missing"], "unknown_order");
  refused(["facility-status", "missing"], "unknown_facility");
  assert.deepEqual(fs.readFileSync(unrelated), unrelatedBytes);

  assert.deepEqual(ok(["facility", "change", "6"]), { facility_id: "change", capacity: 6, held: 0, available: 6 });
  const consolidated = ok(["order", "c1", "change", "C2", "C1", "1000"]);
  assert.deepEqual(consolidated.parcel_ids, ["C1", "C2"]);
  assert.deepEqual(ok(["order", "c1", "change", "C1", "C2", "1000"]), consolidated);
  refused(["order", "c2", "change", "C2", "C3", "1000"], "parcel_taken");
  const c3 = ok(["order", "c3", "change", "C3", "C4", "1000"]);
  assert.deepEqual(c3.parcel_ids, ["C3", "C4"]);
  ok(["pack", "c1"]);
  assert.equal(ok(["unpack", "c1"]).state, "picked");
  refused(["unpack", "c1"], "picked");
  ok(["pack", "c1"]);
  const consolidatedBooking = ok(["book", "c1"]);
  assert.equal(consolidatedBooking.state, "booked");
  assert.equal((await control("/effects")).count, 5);
  const effects = await control("/effects");
  assert.deepEqual(effects.effects.at(-1).parcel_ids, ["C1", "C2"]);
  ok(["order", "ccancel", "change", "C5", "1000"]);
  ok(["pack", "ccancel"]);
  assert.equal(ok(["cancel", "ccancel"]).state, "cancelled");
  assert.equal((await control("/effects")).count, 5);
  assert.equal((await control("/effects")).effects.at(-1).parcel_ids.join(","), "C1,C2");
  ok(["order", "cexpire", "change", "C5", "1000"]);
  ok(["pack", "cexpire"]);
  refused(["unpack", "cexpire"], "expired", { NOW_MS: "1000" });
  assert.equal(ok(["status", "cexpire"], { NOW_MS: "1000" }).state, "expired");
  const replacement = ok(["order", "c4", "change", "C5", "C6", "1000"]);
  console.log(JSON.stringify({ ok: true, state_dir: state, effects: (await control("/effects")).count }));
} finally {
  stub.kill("SIGTERM");
}
