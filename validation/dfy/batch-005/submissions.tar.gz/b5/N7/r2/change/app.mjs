import fs from "node:fs";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { fileURLToPath } from "node:url";
import { Kernel, HistoricalResult } from "@ikaros/runtime";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const MACHINE_PATH = path.join(ROOT, "warehouse.ik.toml");
const MACHINE_V2_PATH = path.join(ROOT, "warehouse_v2.ik.toml");
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const PARCEL_RE = /^[A-Za-z0-9._-]{1,32}$/;
const MAX_SAFE = Number.MAX_SAFE_INTEGER;
const LIVE_STATES = new Set(["picked", "packed", "attempt_saved", "booked"]);
const CLOCK_COMMANDS = new Set(["order", "pack", "book", "cancel", "expire", "status", "facility-status", "unpack"]);

class Refusal extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
}

function fail(code) { throw new Refusal(code); }

function parseDecimal(value, code, max = MAX_SAFE) {
  if (!/^\d+$/.test(value ?? "")) fail(code);
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n < 0 || n > max) fail(code);
  return n;
}

function requireId(value, parcel = false) {
  if (!(parcel ? PARCEL_RE : ID_RE).test(value ?? "")) fail("bad_id");
  return value;
}

function nowMs() {
  return parseDecimal(process.env.NOW_MS, "bad_args");
}


 function storeRoot() {
   const root = process.env.STATE_DIR;
   if (!root) fail("bad_args");
   return root;
 }
function catalogPath(root) { return path.join(root, "warehouse-catalog.json"); }
function storePath(root) { return path.join(root, "warehouse.sqlite"); }

function readCatalog(root) {
  const file = catalogPath(root);
  if (!fs.existsSync(file)) return { facilities: {}, orders: {} };
  try {
    const value = JSON.parse(fs.readFileSync(file, "utf8"));
    if (!value || typeof value !== "object" || !value.facilities || !value.orders) fail("unavailable");
    return value;
  } catch (error) {
    if (error instanceof Refusal) throw error;
    fail("unavailable");
  }
}

 function writeCatalog(root, catalog) {
   fs.mkdirSync(root, { recursive: true });
   const file = catalogPath(root);
   const tmp = `${file}.tmp-${process.pid}`;
   const fd = fs.openSync(tmp, "w", 0o600);
   try {
     const bytes = Buffer.from(JSON.stringify(catalog, null, 2) + "\n");
     fs.writeSync(fd, bytes);
     fs.fsyncSync(fd);
   } finally {
     fs.closeSync(fd);
   }
   fs.renameSync(tmp, file);
   try {
     const dirfd = fs.openSync(root, "r");
     fs.fsyncSync(dirfd);
     fs.closeSync(dirfd);
   } catch {}
 }

 function kernelFor(root) {
   return new Kernel(storePath(root));
 }
 
async function machineFor(root, row = undefined) {
  const machinePath = row?.machine_version === 2 ? MACHINE_V2_PATH : MACHINE_PATH;
  return (await kernelFor(root).machine(machinePath));
}
 
 
 function factsOf(aggregate) {
   const state = aggregate.raw?.state;
   return state && typeof state === "object" ? state : {};
 }

function orderView(orderId, aggregate) {
  const facts = factsOf(aggregate);
  let parcelIds;
  if (typeof facts.parcel_ids === "string") {
    try {
      const decoded = JSON.parse(facts.parcel_ids);
      parcelIds = Array.isArray(decoded) ? decoded.map(String) : [];
    } catch {
      parcelIds = [];
    }
  }
  if (!parcelIds?.length && typeof facts.parcel_id === "string") parcelIds = [facts.parcel_id];
  return {
    order_id: orderId,
    facility_id: String(facts.facility_id),
    parcel_ids: parcelIds ?? [],
    pickup_deadline_ms: Number(facts.pickup_deadline_ms),
    state: aggregate.namedState(),
    request_id: typeof facts.request_id === "string" ? facts.request_id : null,
    booking_id: typeof facts.booking_id === "string" ? facts.booking_id : null,
  };
}

function syncOrder(catalog, orderId, aggregate) {
  const view = orderView(orderId, aggregate);
  const row = catalog.orders[orderId];
  if (row) row.state = view.state;
  return view;
}

async function showOrder(root, catalog, orderId) {
  const row = catalog.orders[orderId];
  if (!row) fail("unknown_order");
  const machine = await machineFor(root, row);
  let aggregate;
  try {
    aggregate = await machine.show(orderId);
  } catch {
    fail("unavailable");
  }
  const view = syncOrder(catalog, orderId, aggregate);
  writeCatalog(root, catalog);
  return { machine, aggregate, view };
}

async function transition(root, catalog, orderId, name, args) {
  const current = await showOrder(root, catalog, orderId);
  let result;
  try {
    result = await current.aggregate.command(name, args);
  } catch (error) {
    if (error instanceof HistoricalResult) fail("unavailable");
    throw error;
  }
  const view = syncOrder(catalog, orderId, result);
  writeCatalog(root, catalog);
  return { machine: current.machine, aggregate: result, view };
}

async function expireIfDue(root, catalog, orderId, current, now) {
  if ((current.view.state === "picked" || current.view.state === "packed") && now >= current.view.pickup_deadline_ms) {
    return transition(root, catalog, orderId, "expire", { now_ms: now });
  }
  return current;
}

function crashAt(label) {
  if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL");
}

function providerUrl(suffix) {
  const base = process.env.SERVICE_URL;
  if (!base) fail("unavailable");
  return `${base.replace(/\/$/, "")}${suffix}`;
}

async function fetchJson(url, options = {}) {
  try {
    const response = await fetch(url, { ...options, signal: AbortSignal.timeout(10000) });
    let body;
    try { body = await response.json(); } catch { return { kind: "unavailable" }; }
    return { kind: "response", status: response.status, body };
  } catch {
    return { kind: "unavailable" };
  }
}

function bodyFor(order, requestId) {
  return { request_id: requestId, order_id: order.order_id, facility_id: order.facility_id, parcel_ids: order.parcel_ids };
}

function digest(body) { return createHash("sha256").update(JSON.stringify(body)).digest("hex"); }

function matchesBooking(body, order, requestId) {
  if (!body || body.request_id !== requestId || body.order_id !== order.order_id || body.facility_id !== order.facility_id || !Array.isArray(body.parcel_ids) || body.parcel_ids.length !== order.parcel_ids.length || !body.parcel_ids.every((parcelId) => typeof parcelId === "string") || typeof body.booking_id !== "string" || body.outcome !== "booked") return false;
  const expected = [...order.parcel_ids].sort();
  const actual = [...body.parcel_ids].sort();
  return expected.every((parcelId, index) => actual[index] === parcelId);
}

async function recordAccepted(root, catalog, orderId, current, providerBody) {
  if (!matchesBooking(providerBody, current.view, current.view.request_id)) fail("conflict");
  const digestValue = digest(providerBody);
  let aggregate = current.aggregate;
  if (aggregate.effect.status !== "recorded") {
    aggregate = await aggregate.recordEffectOutcome(digestValue, { intent: aggregate.pendingIntent });
  }
  const viewAfterRecord = syncOrder(catalog, orderId, aggregate);
  writeCatalog(root, catalog);
  if (viewAfterRecord.state !== "booked") {
    aggregate = await aggregate.command("complete_booking", { booking_id: providerBody.booking_id });
    const view = syncOrder(catalog, orderId, aggregate);
    writeCatalog(root, catalog);
    return { aggregate, view };
  }
  return { aggregate, view: viewAfterRecord };
}

async function lookupBooking(root, catalog, orderId, current) {
  const lookup = await fetchJson(providerUrl(`/v1/bookings/${encodeURIComponent(current.view.request_id)}`));
  if (lookup.kind === "unavailable") fail("unavailable");
  if (lookup.status === 404) return { found: false, current };
  if (lookup.status !== 200) fail("unavailable");
  if (!matchesBooking(lookup.body, current.view, current.view.request_id)) fail("conflict");
  return { found: true, current, body: lookup.body };
}

async function postBooking(order) {
  const body = bodyFor(order, order.request_id);
  return fetchJson(providerUrl("/v1/bookings"), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function ensureDueForAll(root, catalog, now) {
  for (const orderId of Object.keys(catalog.orders)) {
    const row = catalog.orders[orderId];
    if (row.state === "picked" || row.state === "packed") {
      const current = await showOrder(root, catalog, orderId);
      await expireIfDue(root, catalog, orderId, current, now);
    }
  }
}

async function createFacility(root, catalog, facilityId, capacity) {
  const existing = catalog.facilities[facilityId];
  if (existing) {
    if (existing.capacity !== capacity) fail("conflict");
    return { facility_id: facilityId, capacity, held: heldCount(catalog, facilityId), available: capacity - heldCount(catalog, facilityId) };
  }
  catalog.facilities[facilityId] = { facility_id: facilityId, capacity };
  writeCatalog(root, catalog);
  return { facility_id: facilityId, capacity, held: 0, available: capacity };
}

function rowParcelIds(row) {
  if (Array.isArray(row.parcel_ids)) return row.parcel_ids;
  if (typeof row.parcel_id === "string") return [row.parcel_id];
  return [];
}

function heldCount(catalog, facilityId) {
  let held = 0;
  for (const row of Object.values(catalog.orders)) {
    if (row.facility_id === facilityId && LIVE_STATES.has(row.state)) held += rowParcelIds(row).length;
  }
  return held;
}

async function facilityStatus(root, catalog, facilityId, now) {
  if (!catalog.facilities[facilityId]) fail("unknown_facility");
  await ensureDueForAll(root, catalog, now);
  const capacity = catalog.facilities[facilityId].capacity;
  const held = heldCount(catalog, facilityId);
  return { facility_id: facilityId, capacity, held, available: capacity - held };
}

async function createOrder(root, catalog, orderId, facilityId, parcelIds, deadline, now) {
  const facility = catalog.facilities[facilityId];
  if (!facility) fail("unknown_facility");
  const existing = catalog.orders[orderId];
  if (existing) {
    const existingParcels = rowParcelIds(existing);
    if (existing.facility_id !== facilityId || existingParcels.length !== parcelIds.length || existingParcels.some((parcelId, index) => parcelId !== parcelIds[index]) || existing.pickup_deadline_ms !== deadline) fail("conflict");
    const current = await showOrder(root, catalog, orderId);
    return current.view;
  }
  await ensureDueForAll(root, catalog, now);
  for (const row of Object.values(catalog.orders)) {
    if (row.facility_id === facilityId && LIVE_STATES.has(row.state) && rowParcelIds(row).some((parcelId) => parcelIds.includes(parcelId))) fail("parcel_taken");
  }
  if (heldCount(catalog, facilityId) + parcelIds.length > facility.capacity) fail("capacity_exceeded");
  catalog.orders[orderId] = { order_id: orderId, facility_id: facilityId, parcel_ids: parcelIds, pickup_deadline_ms: deadline, machine_version: 2, state: "pending_creation" };
  writeCatalog(root, catalog);
  const machine = await machineFor(root, catalog.orders[orderId]);
  const operationId = `init-${orderId}`.slice(0, 128);
  let result;
  try {
    result = await machine.createWith({ aggregateId: orderId, operationId, command: { name: "initialize", args: { facility_id: facilityId, parcel_ids: JSON.stringify(parcelIds), pickup_deadline_ms: deadline } } });
  } catch (error) {
    throw error;
  }
  if (result instanceof HistoricalResult) {
    const current = await showOrder(root, catalog, orderId);
    return current.view;
  }
  const view = syncOrder(catalog, orderId, result);
  writeCatalog(root, catalog);
  return view;
}

async function bookOrder(root, catalog, orderId, now) {
  let current = await showOrder(root, catalog, orderId);
  current = await expireIfDue(root, catalog, orderId, current, now);
  if (current.view.state === "booked") return current.view;
  if (current.view.state === "expired") fail("expired");
  if (current.view.state === "cancelled") fail("cancelled");
  if (current.view.state === "picked") fail("picked");
  if (current.view.state !== "packed" && current.view.state !== "attempt_saved") fail("unavailable");
  if (current.view.state === "packed") {
    const requestId = randomUUID().replace(/[^A-Za-z0-9._-]/g, "");
    const payload = bodyFor(current.view, requestId);
    const payloadDigest = digest(payload);
    const result = await current.aggregate.command("begin_booking", { request_id: requestId, payload_digest: payloadDigest });
    current = { machine: current.machine, aggregate: result, view: syncOrder(catalog, orderId, result) };
    writeCatalog(root, catalog);
    crashAt("after-booking-saved-before-request");
  } else {
    const looked = await lookupBooking(root, catalog, orderId, current);
    if (looked.found) {
      const adopted = await recordAccepted(root, catalog, orderId, current, looked.body);
      crashAt("after-record-before-exit");
      return adopted.view;
    }
  }
  const response = await postBooking(current.view);
  if (response.kind === "unavailable") fail("unavailable");
  if (response.status === 409) fail("conflict");
  if (response.status !== 200 || !matchesBooking(response.body, current.view, current.view.request_id)) fail(response.status >= 500 ? "unavailable" : "conflict");
  crashAt("after-accept-before-record");
  const adopted = await recordAccepted(root, catalog, orderId, current, response.body);
  crashAt("after-record-before-exit");
  return adopted.view;
}

async function reconcileOrder(root, catalog, orderId) {
  const current = await showOrder(root, catalog, orderId);
  if (current.view.state === "booked") return { outcome: "booked", ...current.view };
  if (current.view.state !== "attempt_saved") return { outcome: "not_applicable" };
  const looked = await lookupBooking(root, catalog, orderId, current);
  if (!looked.found) return { outcome: "not_sent" };
  const adopted = await recordAccepted(root, catalog, orderId, current, looked.body);
  return { outcome: "booked", ...adopted.view };
}

async function command(argv) {
  const name = argv[0];
  if (!name) fail("bad_args");
  if (CLOCK_COMMANDS.has(name) && process.env.NOW_MS === undefined) fail("bad_args");
  const root = storeRoot();
  const catalog = readCatalog(root);
  switch (name) {
    case "facility":
      if (argv.length !== 3) fail("bad_args");
      return createFacility(root, catalog, requireId(argv[1]), parseDecimal(argv[2], "bad_capacity", 100000) || fail("bad_capacity"));
    case "facility-status":
      if (argv.length !== 2) fail("bad_args");
      return facilityStatus(root, catalog, requireId(argv[1]), nowMs());
    case "order": {
      if (argv.length < 5) fail("bad_args");
      const parcelIds = argv.slice(3, -1).map((parcelId) => requireId(parcelId, true)).sort();
      if (parcelIds.length === 0 || new Set(parcelIds).size !== parcelIds.length) fail("bad_id");
      return createOrder(root, catalog, requireId(argv[1]), requireId(argv[2]), parcelIds, parseDecimal(argv.at(-1), "bad_deadline"), nowMs());
    }
    case "pack": {
      if (argv.length !== 2) fail("bad_args");
      const id = requireId(argv[1]);
      let current = await showOrder(root, catalog, id);
      current = await expireIfDue(root, catalog, id, current, nowMs());
      if (current.view.state === "packed") return current.view;
       if (current.view.state === "expired") fail("expired");
       if (current.view.state === "cancelled") fail("cancelled");
       if (current.view.state === "attempt_saved") fail("attempt_saved");
       if (current.view.state === "booked") fail("booked");
       if (current.view.state !== "picked") fail("unavailable");
      return (await transition(root, catalog, id, "pack", { now_ms: nowMs() })).view;
    }
    case "unpack": {
      if (argv.length !== 2) fail("bad_args");
      const id = requireId(argv[1]);
      let current = await showOrder(root, catalog, id);
      current = await expireIfDue(root, catalog, id, current, nowMs());
      if (current.view.state === "picked") fail("picked");
      if (current.view.state === "cancelled") fail("cancelled");
      if (current.view.state === "expired") fail("expired");
      if (current.view.state === "attempt_saved") fail("attempt_saved");
      if (current.view.state === "booked") fail("booked");
      if (current.view.state !== "packed") fail("unavailable");
      return (await transition(root, catalog, id, "unpack", {})).view;
    }
    case "book":
      if (argv.length !== 2) fail("bad_args");
      return bookOrder(root, catalog, requireId(argv[1]), nowMs());
    case "cancel": {
      if (argv.length !== 2) fail("bad_args");
      const id = requireId(argv[1]);
      let current = await showOrder(root, catalog, id);
      current = await expireIfDue(root, catalog, id, current, nowMs());
      if (current.view.state === "cancelled" || current.view.state === "expired") return current.view;
      if (current.view.state === "attempt_saved" || current.view.state === "booked") fail("cancel_open");
      if (current.view.state === "packed" && catalog.orders[id].machine_version !== 2) fail("not_picked");
      return (await transition(root, catalog, id, "cancel", {})).view;
    }
    case "expire": {
      if (argv.length !== 2) fail("bad_args");
      const id = requireId(argv[1]);
      const current = await showOrder(root, catalog, id);
      if (current.view.state === "cancelled" || current.view.state === "expired") return current.view;
      if (current.view.state === "attempt_saved" || current.view.state === "booked") fail("cancel_open");
      if (nowMs() < current.view.pickup_deadline_ms) fail("not_due");
      return (await transition(root, catalog, id, "expire", { now_ms: nowMs() })).view;
    }
    case "status":
      if (argv.length !== 2) fail("bad_args");
      return (await expireIfDue(root, catalog, requireId(argv[1]), await showOrder(root, catalog, requireId(argv[1])), nowMs())).view;
    case "reconcile":
      if (argv.length !== 2) fail("bad_args");
      return reconcileOrder(root, catalog, requireId(argv[1]));
    default:
      fail("bad_args");
  }
}

async function main() {
  try {
    const result = await command(process.argv.slice(2));
    process.stdout.write(JSON.stringify(result) + "\n");
    process.exitCode = 0;
  } catch (error) {
    const code = error instanceof Refusal ? error.code : (error?.code === "IK_OPERATION_CONFLICT" ? "conflict" : "unavailable");
    process.stdout.write(JSON.stringify({ error: code }) + "\n");
    process.exitCode = 1;
  }
}

await main();
 
