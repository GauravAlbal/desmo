# Warehouse outbound shipment desk

This is a single-process CLI for facilities, outbound orders, packing, carrier
booking, and recovery. Order lifecycle transitions and durable order state are
owned by the installed Ikaros runtime (`warehouse.ik.toml`); the catalog file
contains the facility/index projection used to route order ids.

## Setup

Use Node 22.17.1 (or another Node 22 release), then install the bundled local
tarballs without registry access:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x run
```

The launcher uses `<home>/.nvm/versions/node/v22.17.1/bin/node` as
provided by the qualification environment. Set `STATE_DIR` for every command.
Clock-sensitive commands also require `NOW_MS`; booking and reconciliation
require `SERVICE_URL`.

## Commands

```text
./run facility <facility_id> <capacity>
./run order <order_id> <facility_id> <parcel_id> [parcel_id...] <pickup_deadline_ms>
./run pack <order_id>
./run unpack <order_id>
./run book <order_id>
./run cancel <order_id>
./run expire <order_id>
./run status <order_id>
./run facility-status <facility_id>
./run reconcile <order_id>
```

Every invocation emits one JSON object. A refusal emits `{"error":"..."}` and
exits nonzero. `CRASH_AT` may be set to one of the three boundaries in
`BRIEF.md` for crash/recovery exercises. The fake carrier can be started with
`node stub/server.mjs`; use its printed `service_url` as `SERVICE_URL`.

State files created by the desk are `warehouse.sqlite` and
`warehouse-catalog.json`. Other files in `STATE_DIR` are not touched.

## Tests

Run the scoped lifecycle tests (they start the supplied fake carrier and use
only temporary state directories):

```sh
node tests.mjs
```
