#!/usr/bin/env python3
import json
import os
import signal
import subprocess
import tempfile
import time
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node"


def request_json(url, method="GET", value=None):
    body = None if value is None else json.dumps(value).encode()
    req = urllib.request.Request(url, data=body, method=method)
    if body is not None:
        req.add_header("content-type", "application/json")
    with urllib.request.urlopen(req) as response:
        return json.loads(response.read())


class DeskIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.stub = subprocess.Popen([NODE, str(ROOT / "stub" / "server.mjs")], stdout=subprocess.PIPE, text=True)
        line = cls.stub.stdout.readline()
        cls.service = json.loads(line)["service_url"]
        cls.control = json.loads(line)["control_url"]

    @classmethod
    def tearDownClass(cls):
        cls.stub.terminate()
        cls.stub.wait(timeout=5)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.state = Path(self.tmp.name)
        (self.state / "unrelated.bin").write_bytes(b"keep these bytes\\x00\\xff")

    def tearDown(self):
        self.tmp.cleanup()

    def invoke(self, *args, crash=None):
        env = os.environ.copy()
        env.update(STATE_DIR=str(self.state), SERVICE_URL=self.service)
        if crash is not None:
            env["CRASH_AT"] = crash
        else:
            env.pop("CRASH_AT", None)
        return subprocess.run([str(ROOT / "run"), *args], env=env, capture_output=True, text=True)

    def create(self, envelope="env", document="doc"):
        result = self.invoke("create-envelope", envelope, document, "signer", "person@example.com", "100", "0")
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        return json.loads(result.stdout)

    def test_process_restart_and_progression(self):
        self.create()
        self.assertEqual(json.loads(self.invoke("send", "env").stdout)["state"], "sent")
        self.assertEqual(json.loads(self.invoke("sign", "env", "100").stdout)["state"], "signed")
        self.assertEqual(json.loads(self.invoke("archive", "env", "100").stdout)["state"], "archived")
        self.assertEqual(json.loads(self.invoke("status", "env").stdout)["state"], "archived")
        self.assertEqual((self.state / "unrelated.bin").read_bytes(), b"keep these bytes\\x00\\xff")

    def test_crash_labels(self):
        self.create("before", "before-doc")
        crashed = self.invoke("send", "before", crash="after-attempt-saved-before-request")
        self.assertEqual(crashed.returncode, -signal.SIGKILL)
        self.assertEqual(json.loads(self.invoke("status", "before").stdout)["send"], "attempt_saved")
        self.assertEqual(json.loads(self.invoke("send", "before").stdout)["state"], "sent")

        self.create("after", "after-doc")
        crashed = self.invoke("send", "after", crash="after-record-before-exit")
        self.assertEqual(crashed.returncode, -signal.SIGKILL)
        self.assertEqual(json.loads(self.invoke("status", "after").stdout)["state"], "sent")
        self.assertEqual(json.loads(self.invoke("send", "after").stdout)["state"], "sent")

    def test_lost_reply_reconcile_lookup_only(self):
        self.create("lost", "lost-doc")
        request_json(self.control + "/fault", "POST", {"drop_reply": True})
        result = self.invoke("send", "lost")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(json.loads(self.invoke("status", "lost").stdout)["send"], "attempt_saved")
        request_json(self.control + "/fault", "POST", {"drop_reply": False})
        reconciled = json.loads(self.invoke("reconcile", "lost").stdout)
        effects = request_json(self.control + "/effects")
        self.assertEqual(sum(1 for effect in effects["effects"] if effect["request_id"] == "lost"), 1)
        self.assertEqual(json.loads(self.invoke("send", "lost").stdout)["state"], "sent")

    def create_two(self, envelope="two", document="two-doc", deadline="100"):
        result = self.invoke(
            "create-envelope", envelope, document, "signer-one", "one@example.com",
            "signer-two", "two@example.com", deadline, "0",
        )
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        return json.loads(result.stdout)

    def test_two_signer_effects_and_projection(self):
        created = self.create_two()
        self.assertEqual(created["signer2_id"], "signer-two")
        self.assertEqual(created["address2"], "two@example.com")
        sent = json.loads(self.invoke("send", "two").stdout)
        self.assertEqual(sent["state"], "sent")
        status = json.loads(self.invoke("status", "two").stdout)
        self.assertEqual(status["signer2_id"], "signer-two")
        self.assertEqual(status["address2"], "two@example.com")
        effects = request_json(self.control + "/effects")
        self.assertEqual({effect["request_id"] for effect in effects["effects"] if effect["envelope_id"] == "two"}, {"two.s1", "two.s2"})
        self.assertEqual(json.loads(self.invoke("sign", "two", "86400100").stdout)["state"], "signed")

    def test_extend_deadline_and_duplicate_signer_fields(self):
        self.create_two("extended", "extended-doc", deadline="100")
        extended = json.loads(self.invoke("extend-deadline", "extended", "200", "100").stdout)
        self.assertEqual(extended["deadline_ms"], 200)
        self.assertEqual(json.loads(self.invoke("status", "extended").stdout)["deadline_ms"], 200)
        self.assertEqual(json.loads(self.invoke("send", "extended").stdout)["state"], "sent")
        extended_sent = json.loads(self.invoke("extend-deadline", "extended", "300", "200").stdout)
        self.assertEqual(extended_sent["state"], "sent")
        self.assertEqual(json.loads(self.invoke("sign", "extended", "300").stdout)["state"], "signed")
        duplicate = self.invoke(
            "create-envelope", "bad", "bad-doc", "same", "one@example.com",
            "same", "two@example.com", "100", "0",
        )
        self.assertNotEqual(duplicate.returncode, 0)
        self.assertEqual(json.loads(duplicate.stdout)["error"], "bad_args")

    def test_two_signer_after_accept_recovery(self):
        self.create_two("recover", "recover-doc")
        crashed = self.invoke("send", "recover", crash="after-accept-before-record")
        self.assertEqual(crashed.returncode, -signal.SIGKILL)
        self.assertEqual(json.loads(self.invoke("status", "recover").stdout)["send"], "attempt_saved")
        self.assertEqual(json.loads(self.invoke("send", "recover").stdout)["state"], "sent")
        effects = request_json(self.control + "/effects")
        self.assertEqual(sum(1 for effect in effects["effects"] if effect["envelope_id"] == "recover"), 2)
