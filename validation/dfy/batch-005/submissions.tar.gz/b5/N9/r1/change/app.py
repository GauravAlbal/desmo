#!/usr/bin/env python3
"""Local e-signature envelope desk.

Ikaros owns durable lifecycle transitions and effect intent records.  This
module owns argument validation, service transport, and the CLI projection.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import signal
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

from invariant_kernel import Aggregate, HistoricalResult, Kernel, KernelError

ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$")
DECIMAL_RE = re.compile(r"^(?:0|[1-9][0-9]*)$")
MAX_MS = 9_999_999_999_999
EXTENSION_MS = 86_400_000

ROOT = Path(__file__).resolve().parent
MACHINE_V1_PATH = ROOT / "envelope.ik.toml"
MACHINE_V2_PATH = ROOT / "envelope_v2.ik.toml"


class DeskError(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def require_id(value: str) -> str:
    if not isinstance(value, str) or not ID_RE.fullmatch(value):
        raise DeskError("bad_args")
    return value


def require_email(value: str) -> str:
    if not isinstance(value, str) or not EMAIL_RE.fullmatch(value):
        raise DeskError("bad_args")
    return value


def require_ms(value: str) -> int:
    if not isinstance(value, str) or not DECIMAL_RE.fullmatch(value):
        raise DeskError("bad_args")
    result = int(value)
    if result > MAX_MS:
        raise DeskError("bad_args")
    return result


def required_object(value: Any) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        raise DeskError("bad_args")
    return value


def crash_at(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


def load_index(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {"envelopes": {}, "signers": {}}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            return {"envelopes": {}, "signers": {}}
        raw_rows = value.get("envelopes", value)
        if not isinstance(raw_rows, dict):
            return {"envelopes": {}, "signers": {}}
        rows = {str(k): str(v) for k, v in raw_rows.items()}
        raw_signers = value.get("signers", {})
        signers = {str(k): str(v) for k, v in raw_signers.items()} if isinstance(raw_signers, dict) else {}
        return {"envelopes": rows, "signers": signers}
    except (OSError, ValueError, TypeError):
        return {"envelopes": {}, "signers": {}}


def save_index(path: Path, index: Mapping[str, Any]) -> None:
    payload = json.dumps(
        {"envelopes": dict(sorted(index.get("envelopes", {}).items())),
         "signers": dict(sorted(index.get("signers", {}).items()))},
        sort_keys=True,
        separators=(",", ":"),
    )
    fd, name = tempfile.mkstemp(prefix=".index.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
    finally:
        try:
            os.unlink(name)
        except FileNotFoundError:
            pass


class Service:
    def __init__(self, base: str):
        if not base or base.endswith("/"):
            raise DeskError("bad_args")
        self.base = base

    def _request(self, method: str, path: str, body: Optional[bytes] = None) -> Tuple[int, Any]:
        request = urllib.request.Request(self.base + path, data=body, method=method)
        if body is not None:
            request.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                raw = response.read()
                status = int(response.status)
        except urllib.error.HTTPError as exc:
            try:
                raw = exc.read()
            except OSError:
                raw = b""
            status = int(exc.code)
        except (OSError, urllib.error.URLError, TimeoutError):
            raise DeskError("service_unavailable")
        try:
            parsed = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            parsed = None
        return status, parsed

    def lookup(self, request_id: str) -> Tuple[str, Optional[Dict[str, Any]]]:
        encoded = urllib.parse.quote(request_id, safe="")
        status, value = self._request("GET", "/v1/requests/" + encoded)
        if status == 404:
            return "missing", None
        if status != 200 or not isinstance(value, dict):
            raise DeskError("service_unavailable")
        return "found", value

    def post(self, payload: Mapping[str, Any]) -> Dict[str, Any]:
        status, value = self._request("POST", "/v1/envelopes", canonical_json(payload))
        if status == 409:
            raise DeskError("conflict")
        if status != 200 or not isinstance(value, dict):
            raise DeskError("service_unavailable")
        return value


def matches(payload: Mapping[str, Any], response: Mapping[str, Any]) -> bool:
    if response.get("outcome") != "accepted":
        return False
    return all(response.get(key) == value for key, value in payload.items())


class Desk:
    def __init__(self, state_dir: Path, service_url: str):
        state_dir.mkdir(parents=True, exist_ok=True)
        self.state_dir = state_dir
        self.index_path = state_dir / "envelopes.json"
        binary = os.environ.get("IK_BINARY") or str(ROOT / "KIT" / "bin" / "ik")
        self.kernel = Kernel(state_dir / "kernel.db", binary=binary)
        self.machine_v1 = self.kernel.machine(MACHINE_V1_PATH)
        self.machine_v2 = self.kernel.machine(MACHINE_V2_PATH)
        self.service = Service(service_url)

    def close(self) -> None:
        self.kernel.close()

    def show(self, envelope_id: str) -> Aggregate:
        try:
            candidate = self.machine_v2.show(envelope_id)
            if "signer_count" in candidate.facts:
                return candidate
        except KernelError:
            pass
        try:
            return self.machine_v1.show(envelope_id)
        except KernelError as exc:
            raise DeskError("unknown_envelope") from exc

    @staticmethod
    def facts(aggregate: Aggregate) -> Mapping[str, Any]:
        facts = aggregate.facts
        if not all(key in facts for key in ("document_id", "signer_id", "address", "deadline_ms")):
            raise DeskError("unknown_envelope")
        return facts

    @staticmethod
    def is_v2(aggregate: Aggregate) -> bool:
        return "signer_count" in aggregate.facts

    @staticmethod
    def is_two_signer(aggregate: Aggregate) -> bool:
        return int(aggregate.facts.get("signer_count", 1)) == 2

    @staticmethod
    def effect_id(aggregate: Aggregate) -> Optional[str]:
        value = getattr(aggregate.effect, "id", None)
        return str(value) if value is not None else None

    def projection(self, envelope_id: str, aggregate: Aggregate, now_ms: int = 0) -> Dict[str, Any]:
        facts = self.facts(aggregate)
        state = str(aggregate.state)
        sending = state in {"sending", "sending_s1", "sending_s2"}
        send = "sent" if state in {"sent", "signed", "declined", "archived"} else ("attempt_saved" if sending else "none")
        request_id = self.effect_id(aggregate) if send != "none" else None
        if request_id is None and send != "none":
            request_id = envelope_id
        result: Dict[str, Any] = {
            "envelope_id": envelope_id,
            "document_id": facts["document_id"],
            "signer_id": facts["signer_id"],
            "address": facts["address"],
            "deadline_ms": int(facts["deadline_ms"]),
            "state": "draft" if sending else state,
            "send": send,
            "request_id": request_id,
            "now_ms": now_ms,
        }
        if self.is_two_signer(aggregate):
            result["signer2_id"] = facts["signer2_id"]
            result["address2"] = facts["address2"]
            result["request_ids"] = [envelope_id + ".s1", envelope_id + ".s2"] if send != "none" else []
        return result

    def identifiers_in_use(self, index: Mapping[str, Any], envelope_or_document: List[str], signers: List[str]) -> bool:
        if set(envelope_or_document).intersection(signers):
            return True
        rows = index.get("envelopes", {})
        known_signers = index.get("signers", {})
        if any(value in rows or value in rows.values() or value in known_signers for value in envelope_or_document):
            return True
        if any(value in rows or value in rows.values() for value in signers):
            return True
        for envelope_id in rows:
            try:
                aggregate = self.show(envelope_id)
            except DeskError:
                continue
            facts = self.facts(aggregate)
            existing_signers = {facts.get("signer_id"), facts.get("signer2_id")}
            if any(value in existing_signers for value in envelope_or_document):
                return True
            existing_ids = {facts.get("document_id"), envelope_id}
            if any(value in existing_ids for value in signers):
                return True
        return False

    def create(self, args: List[str]) -> Dict[str, Any]:
        if len(args) not in (6, 8):
            raise DeskError("bad_args")
        envelope_id = require_id(args[0])
        document_id = require_id(args[1])
        signer_id = require_id(args[2])
        address = require_email(args[3])
        if len(args) == 6:
            signer2_id = None
            address2 = None
            deadline_text, now_text = args[4], args[5]
        else:
            signer2_id = require_id(args[4])
            address2 = require_email(args[5])
            if signer2_id == signer_id:
                raise DeskError("bad_args")
            deadline_text, now_text = args[6], args[7]
        deadline_ms = require_ms(deadline_text)
        now_ms = require_ms(now_text)
        if deadline_ms < now_ms:
            raise DeskError("bad_args")
        index = load_index(self.index_path)
        envelope_or_document = [envelope_id, document_id]
        signers = [signer_id] + ([signer2_id] if signer2_id is not None else [])
        if self.identifiers_in_use(index, envelope_or_document, signers):
            raise DeskError("id_in_use")
        if len(args) == 6:
            command = {"name": "initialize_one", "args": {
                "document_id": document_id, "signer_id": signer_id, "address": address,
                "signer2_id": "", "address2": "", "deadline_ms": deadline_ms,
                "decision_deadline_ms": deadline_ms, "signer_count": 1, "initialization": 1,
            }}
        else:
            command = {"name": "initialize_two", "args": {
                "document_id": document_id, "signer_id": signer_id, "address": address,
                "signer2_id": signer2_id, "address2": address2, "deadline_ms": deadline_ms,
                "decision_deadline_ms": deadline_ms + EXTENSION_MS, "signer_count": 2, "initialization": 1,
            }}
        try:
            aggregate = self.machine_v2.create_with(envelope_id, command)
        except KernelError as exc:
            try:
                self.machine_v1.show(envelope_id)
            except KernelError:
                pass
            else:
                raise DeskError("id_in_use") from exc
            if "not found" in str(exc).lower() or exc.code == "IK_ILLEGAL_STATE":
                raise DeskError("id_in_use") from exc
            raise DeskError("bad_args") from exc
        if isinstance(aggregate, HistoricalResult):
            raise DeskError("id_in_use")
        index["envelopes"][envelope_id] = document_id
        index["signers"][signer_id] = envelope_id
        if signer2_id is not None:
            index["signers"][signer2_id] = envelope_id
        save_index(self.index_path, index)
        return self.projection(envelope_id, aggregate, now_ms)

    def payload(self, envelope_id: str, aggregate: Aggregate, stage: int = 1) -> Dict[str, Any]:
        facts = self.facts(aggregate)
        if stage == 2:
            request_id = envelope_id + ".s2"
            signer_id = facts["signer2_id"]
            address = facts["address2"]
        else:
            request_id = envelope_id if not self.is_two_signer(aggregate) else envelope_id + ".s1"
            signer_id = facts["signer_id"]
            address = facts["address"]
        return {
            "request_id": request_id,
            "envelope_id": envelope_id,
            "document_id": facts["document_id"],
            "signer_id": signer_id,
            "address": address,
            "deadline_ms": int(facts["deadline_ms"]),
            "kind": "signature_request",
        }

    def record_response(self, aggregate: Aggregate, response: Mapping[str, Any]) -> Aggregate:
        try:
            result = aggregate.record_effect_outcome(digest(response))
        except KernelError as exc:
            raise DeskError("conflict") from exc
        if isinstance(result, HistoricalResult):
            return aggregate
        return result

    def send_one_v1(self, envelope_id: str, aggregate: Aggregate) -> Dict[str, Any]:
        state = str(aggregate.state)
        payload = self.payload(envelope_id, aggregate)
        if state == "draft":
            try:
                aggregate = aggregate.execute({"name": "begin_send", "args": {"request_id": envelope_id, "payload_digest": digest(payload)}})
            except KernelError as exc:
                raise DeskError("invalid_state") from exc
            if isinstance(aggregate, HistoricalResult):
                aggregate = self.show(envelope_id)
            crash_at("after-attempt-saved-before-request")
        if getattr(aggregate.effect, "status", None) == "completed":
            try:
                aggregate = aggregate.command("mark_sent")
            except KernelError as exc:
                raise DeskError("invalid_state") from exc
            if isinstance(aggregate, HistoricalResult):
                aggregate = self.show(envelope_id)
            crash_at("after-record-before-exit")
            return self.projection(envelope_id, aggregate)
        found, response = self.service.lookup(envelope_id)
        if found == "found":
            if response is None or not matches(payload, response):
                raise DeskError("conflict")
        else:
            response = self.service.post(payload)
            if not matches(payload, response):
                raise DeskError("conflict")
            crash_at("after-accept-before-record")
        aggregate = self.record_response(aggregate, response)
        try:
            aggregate = aggregate.command("mark_sent")
        except KernelError as exc:
            raise DeskError("invalid_state") from exc
        if isinstance(aggregate, HistoricalResult):
            aggregate = self.show(envelope_id)
        crash_at("after-record-before-exit")
        return self.projection(envelope_id, aggregate)

    def begin_second(self, envelope_id: str, aggregate: Aggregate) -> Aggregate:
        payload = self.payload(envelope_id, aggregate, 2)
        try:
            result = aggregate.execute({"name": "begin_send_s2", "args": {
                "request_id": envelope_id + ".s2", "payload_digest": digest(payload),
            }})
        except KernelError as exc:
            raise DeskError("invalid_state") from exc
        if isinstance(result, HistoricalResult):
            return self.show(envelope_id)
        return result

    def send_v2(self, envelope_id: str, aggregate: Aggregate) -> Dict[str, Any]:
        state = str(aggregate.state)
        two = self.is_two_signer(aggregate)
        if state == "draft":
            payload = self.payload(envelope_id, aggregate, 1)
            try:
                aggregate = aggregate.execute({"name": "begin_send_s1", "args": {
                    "request_id": payload["request_id"], "payload_digest": digest(payload),
                }})
            except KernelError as exc:
                raise DeskError("invalid_state") from exc
            if isinstance(aggregate, HistoricalResult):
                aggregate = self.show(envelope_id)
            crash_at("after-attempt-saved-before-request")
            state = str(aggregate.state)
        while state in {"sending_s1", "sending_s2"}:
            stage = 2 if state == "sending_s2" else 1
            payload = self.payload(envelope_id, aggregate, stage)
            if getattr(aggregate.effect, "status", None) != "completed":
                found, response = self.service.lookup(payload["request_id"])
                if found == "found":
                    if response is None or not matches(payload, response):
                        raise DeskError("conflict")
                else:
                    response = self.service.post(payload)
                    if not matches(payload, response):
                        raise DeskError("conflict")
                    crash_at("after-accept-before-record")
                aggregate = self.record_response(aggregate, response)
            if two and stage == 1:
                aggregate = self.begin_second(envelope_id, aggregate)
                crash_at("after-attempt-saved-before-request")
                state = str(aggregate.state)
                continue
            try:
                aggregate = aggregate.command("mark_sent_two" if two else "mark_sent_one")
            except KernelError as exc:
                raise DeskError("invalid_state") from exc
            if isinstance(aggregate, HistoricalResult):
                aggregate = self.show(envelope_id)
            crash_at("after-record-before-exit")
            return self.projection(envelope_id, aggregate)
        if state == "sent":
            return self.projection(envelope_id, aggregate)
        raise DeskError("invalid_state")

    def send(self, envelope_id: str) -> Dict[str, Any]:
        require_id(envelope_id)
        aggregate = self.show(envelope_id)
        state = str(aggregate.state)
        if state == "sent":
            return self.projection(envelope_id, aggregate)
        if state in {"signed", "declined", "archived"}:
            raise DeskError("invalid_state")
        if state not in {"draft", "sending", "sending_s1", "sending_s2"}:
            raise DeskError("invalid_state")
        if self.is_v2(aggregate):
            return self.send_v2(envelope_id, aggregate)
        return self.send_one_v1(envelope_id, aggregate)

    def decision(self, action: str, envelope_id: str, now_text: str) -> Dict[str, Any]:
        require_id(envelope_id)
        now_ms = require_ms(now_text)
        aggregate = self.show(envelope_id)
        state = str(aggregate.state)
        if state in {"draft", "sending", "sending_s1", "sending_s2"}:
            raise DeskError("not_sent")
        if state in {"signed", "declined", "archived"}:
            raise DeskError("invalid_state")
        facts = self.facts(aggregate)
        decision_deadline = int(facts.get("decision_deadline_ms", facts["deadline_ms"]))
        if now_ms > decision_deadline:
            raise DeskError("expired")
        try:
            result = aggregate.command(action, now_ms=now_ms)
        except KernelError as exc:
            raise DeskError("expired" if now_ms > decision_deadline else "invalid_state") from exc
        if isinstance(result, HistoricalResult):
            raise DeskError("invalid_state")
        return {"envelope_id": envelope_id, "state": str(result.state), "now_ms": now_ms}

    def archive(self, envelope_id: str, now_text: str) -> Dict[str, Any]:
        require_id(envelope_id)
        now_ms = require_ms(now_text)
        aggregate = self.show(envelope_id)
        if str(aggregate.state) not in {"signed", "declined"}:
            raise DeskError("invalid_state")
        try:
            result = aggregate.command("archive")
        except KernelError as exc:
            raise DeskError("invalid_state") from exc
        if isinstance(result, HistoricalResult):
            raise DeskError("invalid_state")
        return {"envelope_id": envelope_id, "state": "archived", "now_ms": now_ms}

    def extend_deadline(self, envelope_id: str, new_text: str, now_text: str) -> Dict[str, Any]:
        require_id(envelope_id)
        new_deadline = require_ms(new_text)
        now_ms = require_ms(now_text)
        aggregate = self.show(envelope_id)
        state = str(aggregate.state)
        if state not in {"draft", "sent"}:
            raise DeskError("invalid_state")
        old_deadline = int(self.facts(aggregate)["deadline_ms"])
        if new_deadline < now_ms or new_deadline <= old_deadline:
            raise DeskError("bad_args")
        if not self.is_v2(aggregate):
            raise DeskError("invalid_state")
        count = int(aggregate.facts["signer_count"])
        command_name = ("extend_two_" if count == 2 else "extend_one_") + state
        decision_deadline = new_deadline + (EXTENSION_MS if count == 2 else 0)
        try:
            result = aggregate.command(command_name, new_deadline_ms=new_deadline, now_ms=now_ms, new_decision_deadline_ms=decision_deadline)
        except KernelError as exc:
            raise DeskError("bad_args") from exc
        if isinstance(result, HistoricalResult):
            raise DeskError("invalid_state")
        return {"envelope_id": envelope_id, "deadline_ms": new_deadline, "state": state, "now_ms": now_ms}

    def reconcile(self, envelope_id: str) -> Dict[str, Any]:
        require_id(envelope_id)
        aggregate = self.show(envelope_id)
        state = str(aggregate.state)
        if state in {"draft", "sent", "signed", "declined", "archived"}:
            result = self.projection(envelope_id, aggregate)
            return {"envelope_id": envelope_id, "send": result["send"], "request_id": result["request_id"], **({k: result[k] for k in ("state", "document_id", "signer_id", "address", "deadline_ms")} if state != "draft" else {})}
        if not self.is_v2(aggregate):
            payload = self.payload(envelope_id, aggregate)
            request_id = envelope_id
        else:
            stage = 2 if state == "sending_s2" else 1
            payload = self.payload(envelope_id, aggregate, stage)
            request_id = payload["request_id"]
        if getattr(aggregate.effect, "status", None) != "completed":
            found, response = self.service.lookup(request_id)
            if found == "missing":
                return {"envelope_id": envelope_id, "send": "not_sent", "request_id": request_id}
            if response is None or not matches(payload, response):
                raise DeskError("conflict")
            aggregate = self.record_response(aggregate, response)
        if self.is_v2(aggregate):
            if self.is_two_signer(aggregate) and state == "sending_s1":
                aggregate = self.begin_second(envelope_id, aggregate)
                return self.projection(envelope_id, aggregate)
            command = "mark_sent_two" if self.is_two_signer(aggregate) else "mark_sent_one"
        else:
            command = "mark_sent"
        try:
            aggregate = aggregate.command(command)
        except KernelError as exc:
            raise DeskError("conflict") from exc
        if isinstance(aggregate, HistoricalResult):
            aggregate = self.show(envelope_id)
        return self.projection(envelope_id, aggregate)

    def callback(self, callback_path: str) -> Dict[str, Any]:
        try:
            value = json.loads(Path(callback_path).read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, ValueError):
            raise DeskError("bad_args")
        obj = required_object(value)
        required = {"callback_id", "request_id", "envelope_id", "document_id", "signer_id", "address", "deadline_ms", "kind", "outcome"}
        if set(obj) < required or obj.get("outcome") not in {"accepted", "rejected"}:
            raise DeskError("bad_args")
        for key in ("callback_id", "request_id", "envelope_id", "document_id", "signer_id", "address", "kind"):
            if not isinstance(obj.get(key), str):
                raise DeskError("bad_args")
        if not isinstance(obj.get("deadline_ms"), int) or isinstance(obj.get("deadline_ms"), bool) or not 0 <= obj["deadline_ms"] <= MAX_MS:
            raise DeskError("bad_args")
        require_id(obj["request_id"])
        require_id(obj["envelope_id"])
        try:
            aggregate = self.show(obj["envelope_id"])
        except DeskError as exc:
            if exc.code == "unknown_envelope":
                return {"callback": "ignored"}
            raise
        if str(aggregate.state) not in {"sending", "sending_s1", "sending_s2"}:
            return {"callback": "ignored"}
        expected = self.effect_id(aggregate)
        if expected is None:
            expected = obj["envelope_id"]
        if obj["request_id"] != expected:
            return {"callback": "ignored"}
        return self.reconcile(obj["envelope_id"])


def dispatch(argv: List[str]) -> Dict[str, Any]:
    state_dir_text = os.environ.get("STATE_DIR")
    service_url = os.environ.get("SERVICE_URL")
    if not state_dir_text or service_url is None:
        raise DeskError("bad_args")
    desk = Desk(Path(state_dir_text), service_url)
    try:
        if not argv:
            raise DeskError("bad_args")
        command, args = argv[0], argv[1:]
        if command == "create-envelope":
            return desk.create(args)
        if command == "send":
            if len(args) != 1:
                raise DeskError("bad_args")
            return desk.send(args[0])
        if command in {"sign", "decline"}:
            if len(args) != 2:
                raise DeskError("bad_args")
            return desk.decision(command, args[0], args[1])
        if command == "archive":
            if len(args) != 2:
                raise DeskError("bad_args")
            return desk.archive(args[0], args[1])
        if command == "extend-deadline":
            if len(args) != 3:
                raise DeskError("bad_args")
            return desk.extend_deadline(args[0], args[1], args[2])
        if command == "reconcile":
            if len(args) != 1:
                raise DeskError("bad_args")
            return desk.reconcile(args[0])
        if command == "status":
            if len(args) != 1:
                raise DeskError("bad_args")
            envelope_id = require_id(args[0])
            return desk.projection(envelope_id, desk.show(envelope_id))
        if command == "callback":
            if len(args) != 1:
                raise DeskError("bad_args")
            return desk.callback(args[0])
        raise DeskError("bad_args")
    finally:
        desk.close()


def main(argv: List[str]) -> int:
    try:
        result = dispatch(argv)
    except DeskError as exc:
        print(json.dumps({"error": exc.code}, separators=(",", ":")))
        return 1
    except Exception:
        print(json.dumps({"error": "service_unavailable"}, separators=(",", ":")))
        return 1
    print(json.dumps(result, separators=(",", ":"), sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
