# E-signature envelope desk

This is a local, durable signing desk. The lifecycle authority and durable
journal are provided by the packed Ikaros runtime in `KIT/`; Python owns CLI
validation, HTTP transport, and result projection.

## Setup

No npm package is required (the supplied `stub/server.mjs` is run with Node and
has no npm dependencies). From this directory:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
chmod +x run
```

`run` locates `.venv/bin/python` and sets `IK_BINARY` to `KIT/bin/ik`. It can be
invoked directly after setup. The evaluator must provide `STATE_DIR` and
`SERVICE_URL`; `CRASH_AT` is optional.

To exercise the fake service in a second terminal:

```sh
<home>/.nvm/versions/node/v22.17.1/bin/node stub/server.mjs
```

Copy its `service_url` into `SERVICE_URL` (the stub prints an ephemeral loopback
port). Example:
```sh
export STATE_DIR="$PWD/.state"
export SERVICE_URL="http://127.0.0.1:PORT"
./run create-envelope env-1 doc-1 signer-1 signer@example.com 2000 1000
./run send env-1
./run sign env-1 2000
./run archive env-1 2000
./run status env-1
```

For two required signers, use the eight-argument form:

```sh
./run create-envelope env-2 doc-2 signer-1 signer1@example.com signer-2 signer2@example.com 2000 1000
./run send env-2
./run extend-deadline env-2 3000 2000
./run sign env-2 3000
./run archive env-2 3000
```

`extend-deadline` accepts draft or sent envelopes and requires a strictly later
deadline that is no earlier than the supplied `now_ms`.

Run the integration tests with the same installed environment:

```sh
.venv/bin/python -m unittest discover -s tests -v
```

## Behavior

- Ikaros persists envelope facts and lifecycle transitions in
  `$STATE_DIR/kernel.db`; a small owned `envelopes.json` index enforces
  envelope/document identity uniqueness. Other files in `STATE_DIR` are not read
  or changed.
- The six-argument create form retains one-signer behavior. The eight-argument
  form creates two required signers and `send` commits and reconciles
  `<envelope_id>.s1` and `<envelope_id>.s2` in order.
- `send` commits an Ikaros effect intent before each request, reconciles with
  `GET` before attempting `POST`, and never invents a replacement request id.
- Two-signer decisions remain valid through one day after the stored deadline;
  `extend-deadline` durably replaces the deadline for draft or sent v2
  envelopes.
- `CRASH_AT` supports `after-attempt-saved-before-request`,
  `after-accept-before-record`, and `after-record-before-exit` exactly as
  described in `BRIEF.md`.
- `reconcile` is lookup-only and never POSTs. A valid callback is only a hint
  to that lookup; it cannot make an envelope sent without a matching service
  record.
- Every invocation emits one compact JSON object. Refusals are nonzero and use
  the error codes in the brief.


Pre-change one-signer aggregates remain routed through `envelope.ik.toml` and
retain their original deadline semantics. Newly created envelopes use the
version-2 machine in `envelope_v2.ik.toml`; this avoids rewriting persisted
Ikaros machine identities.

## Unresolved assumptions

The brief does not prescribe a filename for the desk-owned index, so this
implementation uses `envelopes.json`. `status` and `send` have no supplied
clock argument; their result projection uses `now_ms: 0`, while decision and
creation results echo the supplied time. This is only a response field and is
not persisted or consulted for transitions.
