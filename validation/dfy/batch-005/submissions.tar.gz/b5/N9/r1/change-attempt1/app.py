#!/usr/bin/env python3
"""Local e-signature envelope desk.

The Ikaros machine in envelope.ik.toml owns every lifecycle transition and its
SQLite journal. This module owns argument validation, HTTP transport, and the
CLI projection of canonical aggregates.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import signal
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Mapping

from invariant_kernel import Aggregate, HistoricalResult, Kernel, KernelError

ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$")
DECIMAL_RE = re.compile(r"^(?:0|[1-9][0-9]*)$")
MAX_MS = 9_999_999_999_999

ROOT = Path(__file__).resolve().parent
MACHINE_PATH = ROOT / "envelope.ik.toml"


class DeskError(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def require_id(value: str) -> str:
    if not isinstance(value, str) or not ID_RE.fullmatch(value):
        raise DeskError("bad_args")
    return value


def require_email(value: str) -> str:
    if not isinstance(value, str) or not EMAIL_RE.fullmatch(value):
        raise DeskError("bad_args")
    return value


def require_ms(value: str) -> int:
    if not isinstance(value, str) or not DECIMAL_RE.fullmatch(value):
        raise DeskError("bad_args")
    result = int(value)
    if result > MAX_MS:
        raise DeskError("bad_args")
    return result


def required_object(value: Any) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        raise DeskError("bad_args")
    return value


def crash_at(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


def load_index(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            return {}
        rows = value.get("envelopes", value)
        if not isinstance(rows, dict):
            return {}
        return {str(k): v for k, v in rows.items() if isinstance(v, (str, dict))}
    except (OSError, ValueError, TypeError):
        return {}


def save_index(path: Path, rows: Mapping[str, Any]) -> None:
    payload = json.dumps({"envelopes": dict(sorted(rows.items()))}, sort_keys=True, separators=(",", ":"))
    fd, name = tempfile.mkstemp(prefix=".index.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
    finally:
        try:
            os.unlink(name)
        except FileNotFoundError:
            pass


def load_deadlines(path: Path) -> dict[str, int]:
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            return {}
        return {str(key): int(item) for key, item in value.items() if isinstance(item, int) and 0 <= item <= MAX_MS}
    except (OSError, ValueError, TypeError):
        return {}


def save_deadlines(path: Path, rows: Mapping[str, int]) -> None:
    payload = json.dumps(dict(sorted(rows.items())), sort_keys=True, separators=(",", ":"))
    fd, name = tempfile.mkstemp(prefix=".deadlines.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(name, path)
    finally:
        try:
            os.unlink(name)
        except FileNotFoundError:
            pass
class Service:
    def __init__(self, base: str):
        if not base or base.endswith("/"):
            raise DeskError("bad_args")
        self.base = base

    def _request(self, method: str, path: str, body: bytes | None = None) -> tuple[int, Any | None]:
        url = self.base + path
        request = urllib.request.Request(url, data=body, method=method)
        if body is not None:
            request.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                raw = response.read()
                status = int(response.status)
        except urllib.error.HTTPError as exc:
            try:
                raw = exc.read()
            except OSError:
                raw = b""
            status = int(exc.code)
        except (OSError, urllib.error.URLError, TimeoutError):
            raise DeskError("service_unavailable")
        try:
            parsed = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            parsed = None
        return status, parsed

    def lookup(self, request_id: str) -> tuple[str, dict[str, Any] | None]:
        encoded = urllib.parse.quote(request_id, safe="")
        status, value = self._request("GET", "/v1/requests/" + encoded)
        if status == 404:
            return "missing", None
        if status != 200 or not isinstance(value, dict):
            raise DeskError("service_unavailable")
        return "found", value

    def post(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        status, value = self._request("POST", "/v1/envelopes", canonical_json(payload))
        if status == 409:
            raise DeskError("conflict")
        if status != 200 or not isinstance(value, dict):
            raise DeskError("service_unavailable")
        return value


def matches(payload: Mapping[str, Any], response: Mapping[str, Any]) -> bool:
    if response.get("outcome") != "accepted":
        return False
    return all(response.get(key) == value for key, value in payload.items())


class Desk:
    def __init__(self, state_dir: Path, service_url: str):
        state_dir.mkdir(parents=True, exist_ok=True)
        self.state_dir = state_dir
        self.index_path = state_dir / "envelopes.json"
        self.deadline_path = state_dir / "deadline_overrides.json"
        self.deadline_overrides = load_deadlines(self.deadline_path)
        binary = os.environ.get("IK_BINARY") or str(ROOT / "KIT" / "bin" / "ik")
        self.kernel = Kernel(state_dir / "kernel.db", binary=binary)
        self.machines = {
            1: self.kernel.machine(MACHINE_PATH),
            2: self.kernel.machine(ROOT / "envelope_v2.ik.toml"),
        }
        self.service = Service(service_url)

    def close(self) -> None:
        self.kernel.close()

    def _machine_for(self, envelope_id: str):
        try:
            raw = self.kernel.show(envelope_id).raw
        except KernelError as exc:
            raise DeskError("unknown_envelope") from exc
        receipt = raw.get("last_receipt") or raw.get("receipt") or {}
        identity = {
            "machine_id": receipt.get("machine_id"),
            "version": receipt.get("machine_version"),
            "spec_hash": receipt.get("machine_spec_hash"),
        }
        for machine in self.machines.values():
            if machine.identity.to_wire() == identity:
                return machine
        raise DeskError("unknown_envelope")

    def show(self, envelope_id: str) -> Aggregate:
        try:
            return self._machine_for(envelope_id).show(envelope_id)
        except DeskError:
            raise
        except KernelError as exc:
            raise DeskError("unknown_envelope") from exc

    @staticmethod
    def facts(aggregate: Aggregate) -> dict[str, Any]:
        facts = aggregate.facts
        if "signer2_id" in facts:
            required = ("document_id", "signer1_id", "address1", "signer2_id", "address2", "deadline_ms")
        else:
            required = ("document_id", "signer_id", "address", "deadline_ms")
        if not all(key in facts for key in required):
            raise DeskError("unknown_envelope")
        return facts

    @staticmethod
    def is_two_signer(facts: Mapping[str, Any]) -> bool:
        return "signer2_id" in facts

    def effective_deadline(self, envelope_id: str, facts: Mapping[str, Any]) -> int:
        return int(self.deadline_overrides.get(envelope_id, facts["deadline_ms"]))

    def projection(self, envelope_id: str, aggregate: Aggregate, now_ms: int = 0) -> dict[str, Any]:
        facts = self.facts(aggregate)
        state = str(aggregate.state)
        send = "sent" if state in {"sent", "signed", "declined", "archived"} else ("attempt_saved" if state == "sending" else "none")
        if self.is_two_signer(facts):
            request_ids = [
                str(facts[key]) for key in ("request1_id", "request2_id")
                if int(facts.get(key.replace("_id", "_started"), 0)) == 1
            ]
            return {
                "envelope_id": envelope_id,
                "document_id": facts["document_id"],
                "signer_id": facts["signer1_id"],
                "address": facts["address1"],
                "signer1_id": facts["signer1_id"],
                "address1": facts["address1"],
                "signer2_id": facts["signer2_id"],
                "address2": facts["address2"],
                "deadline_ms": self.effective_deadline(envelope_id, facts),
                "state": state,
                "send": send,
                "request_id": request_ids[0] if request_ids else None,
                "request_ids": request_ids,
                "now_ms": now_ms,
            }
        return {
            "envelope_id": envelope_id,
            "document_id": facts["document_id"],
            "signer_id": facts["signer_id"],
            "address": facts["address"],
            "deadline_ms": self.effective_deadline(envelope_id, facts),
            "state": "draft" if state == "sending" else state,
            "send": send,
            "request_id": envelope_id if send != "none" else None,
            "now_ms": now_ms,
        }

    def _occupied_ids(self, rows: Mapping[str, Any]) -> set[str]:
        occupied: set[str] = set()
        for existing_id, row in rows.items():
            occupied.add(existing_id)
            if isinstance(row, str):
                occupied.add(row)
            elif isinstance(row, dict):
                for key in ("document_id", "signer1_id", "signer2_id", "signer_id"):
                    if isinstance(row.get(key), str):
                        occupied.add(row[key])
                if isinstance(row.get("signer_ids"), list):
                    occupied.update(value for value in row["signer_ids"] if isinstance(value, str))
            try:
                old_facts = self.facts(self.show(existing_id))
            except DeskError:
                continue
            if self.is_two_signer(old_facts):
                occupied.update(str(old_facts[key]) for key in ("document_id", "signer1_id", "signer2_id"))
            else:
                occupied.update(str(old_facts[key]) for key in ("document_id", "signer_id"))
        return occupied

    def create(self, args: list[str]) -> dict[str, Any]:
        if len(args) != 8:
            raise DeskError("bad_args")
        envelope_id = require_id(args[0])
        document_id = require_id(args[1])
        signer1_id = require_id(args[2])
        address1 = require_email(args[3])
        signer2_id = require_id(args[4])
        address2 = require_email(args[5])
        deadline_ms = require_ms(args[6])
        now_ms = require_ms(args[7])
        if signer1_id == signer2_id or deadline_ms < now_ms:
            raise DeskError("bad_args")
        rows = load_index(self.index_path)
        occupied = self._occupied_ids(rows)
        if any(value in occupied for value in (envelope_id, document_id, signer1_id, signer2_id)):
            raise DeskError("id_in_use")
        command = {
            "name": "initialize",
            "args": {
                "document_id": document_id,
                "signer1_id": signer1_id,
                "address1": address1,
                "signer2_id": signer2_id,
                "address2": address2,
                "deadline_ms": deadline_ms,
                "expiry_ms": deadline_ms + 86_400_000,
                "initialization": 1,
                "request1_id": "",
                "request1_digest": "",
                "request1_started": 0,
                "request1_done": 0,
                "request2_id": "",
                "request2_digest": "",
                "request2_started": 0,
                "request2_done": 0,
            },
        }
        try:
            aggregate = self.machines[2].create_with(envelope_id, command)
        except KernelError as exc:
            if "not found" in str(exc).lower() or exc.code == "IK_ILLEGAL_STATE":
                raise DeskError("id_in_use") from exc
            raise DeskError("bad_args") from exc
        if isinstance(aggregate, HistoricalResult):
            raise DeskError("id_in_use")
        rows[envelope_id] = {"document_id": document_id, "signer_ids": [signer1_id, signer2_id]}
        save_index(self.index_path, rows)
        result = self.projection(envelope_id, aggregate, now_ms)
        result["state"] = "draft"
        result["send"] = "none"
        result["request_id"] = None
        result["request_ids"] = []
        return result

    def payload(self, envelope_id: str, aggregate: Aggregate, slot: int = 1) -> dict[str, Any]:
        facts = self.facts(aggregate)
        if not self.is_two_signer(facts):
            return {
                "request_id": envelope_id,
                "envelope_id": envelope_id,
                "document_id": facts["document_id"],
                "signer_id": facts["signer_id"],
                "address": facts["address"],
                "deadline_ms": self.effective_deadline(envelope_id, facts),
                "kind": "signature_request",
            }
        return {
            "request_id": str(facts[f"request{slot}_id"]),
            "envelope_id": envelope_id,
            "document_id": facts["document_id"],
            "signer_id": facts[f"signer{slot}_id"],
            "address": facts[f"address{slot}"],
            "deadline_ms": self.effective_deadline(envelope_id, facts),
            "kind": "signature_request",
        }

    def mark_sent(self, envelope_id: str, aggregate: Aggregate) -> Aggregate:
        try:
            result = aggregate.command("mark_sent")
        except KernelError as exc:
            raise DeskError("invalid_state") from exc
        if isinstance(result, HistoricalResult):
            return self.show(envelope_id)
        return result

    def _mark_two_complete(self, envelope_id: str, aggregate: Aggregate, slot: int) -> Aggregate:
        try:
            result = aggregate.command(f"mark_s{slot}_complete")
        except KernelError:
            try:
                result = self.show(envelope_id).command(f"mark_s{slot}_complete")
            except KernelError as exc:
                raise DeskError("conflict") from exc
        if isinstance(result, HistoricalResult):
            return self.show(envelope_id)
        return result

    def _record_response(self, envelope_id: str, aggregate: Aggregate, response: Mapping[str, Any]) -> Aggregate:
        try:
            result = aggregate.record_effect_outcome(digest(response))
        except KernelError as exc:
            raise DeskError("conflict") from exc
        if isinstance(result, HistoricalResult):
            return self.show(envelope_id)
        return result

    def _payload_for(self, envelope_id: str, aggregate: Aggregate, slot: int, request_id: str) -> dict[str, Any]:
        return {**self.payload(envelope_id, aggregate, slot), "request_id": request_id}

    def _send_one(self, envelope_id: str, aggregate: Aggregate) -> dict[str, Any]:
        state = str(aggregate.state)
        if state == "draft":
            payload = self.payload(envelope_id, aggregate)
            command = {"name": "begin_send", "args": {"request_id": envelope_id, "payload_digest": digest(payload)}}
            try:
                result = aggregate.execute(command)
            except KernelError as exc:
                raise DeskError("invalid_state") from exc
            aggregate = self.show(envelope_id) if isinstance(result, HistoricalResult) else result
            crash_at("after-attempt-saved-before-request")
        elif state != "sending":
            raise DeskError("invalid_state")
        if getattr(aggregate.effect, "status", None) in {"completed", "recorded"}:
            aggregate = self.mark_sent(envelope_id, aggregate)
            crash_at("after-record-before-exit")
            return self.projection(envelope_id, aggregate)
        payload = self.payload(envelope_id, aggregate)
        found, response = self.service.lookup(envelope_id)
        if found == "found":
            if response is None or not matches(payload, response):
                raise DeskError("conflict")
        else:
            response = self.service.post(payload)
            if not matches(payload, response):
                raise DeskError("conflict")
            crash_at("after-accept-before-record")
        aggregate = self._record_response(envelope_id, aggregate, response)
        aggregate = self.mark_sent(envelope_id, aggregate)
        crash_at("after-record-before-exit")
        return self.projection(envelope_id, aggregate)

    @staticmethod
    def _two_slot(facts: Mapping[str, Any]) -> int:
        if int(facts["request1_started"]) == 0:
            return 1
        if int(facts["request1_done"]) == 0:
            return 1
        if int(facts["request2_started"]) == 0:
            return 2
        if int(facts["request2_done"]) == 0:
            return 2
        return 0

    def _begin_two(self, aggregate: Aggregate, slot: int, request_id: str, payload_digest: str) -> Aggregate:
        try:
            result = aggregate.execute({
                "name": f"begin_send_s{slot}",
                "args": {"request_id": request_id, "payload_digest": payload_digest},
            })
        except KernelError as exc:
            raise DeskError("invalid_state") from exc
        return result

    def _send_two(self, envelope_id: str, aggregate: Aggregate) -> dict[str, Any]:
        fresh_request = False
        if str(aggregate.state) == "draft":
            request_id = f"{envelope_id}.s1"
            payload = self._payload_for(envelope_id, aggregate, 1, request_id)
            result = self._begin_two(aggregate, 1, request_id, digest(payload))
            aggregate = self.show(envelope_id) if isinstance(result, HistoricalResult) else result
            fresh_request = True
            crash_at("after-attempt-saved-before-request")
        while str(aggregate.state) == "sending":
            facts = self.facts(aggregate)
            slot = self._two_slot(facts)
            if slot == 0:
                return self.projection(envelope_id, aggregate)
            if slot == 2 and int(facts["request2_started"]) == 0:
                request_id = f"{envelope_id}.s2"
                payload = self._payload_for(envelope_id, aggregate, 2, request_id)
                result = self._begin_two(aggregate, 2, request_id, digest(payload))
                aggregate = self.show(envelope_id) if isinstance(result, HistoricalResult) else result
                fresh_request = True
                crash_at("after-attempt-saved-before-request")
                continue
            if slot == 1 and not fresh_request and getattr(aggregate.effect, "status", None) in {"completed", "recorded"}:
                aggregate = self._mark_two_complete(envelope_id, aggregate, slot)
                continue
            fresh_request = False
            request_id = str(facts[f"request{slot}_id"])
            payload = self._payload_for(envelope_id, aggregate, slot, request_id)
            found, response = self.service.lookup(request_id)
            if found == "found":
                if response is None or not matches(payload, response):
                    raise DeskError("conflict")
            else:
                response = self.service.post(payload)
                if not matches(payload, response):
                    raise DeskError("conflict")
                crash_at("after-accept-before-record")
            if slot == 1:
                aggregate = self._record_response(envelope_id, aggregate, response)
                crash_at("after-record-before-exit")
                aggregate = self._mark_two_complete(envelope_id, aggregate, slot)
            else:
                aggregate = self._mark_two_complete(envelope_id, aggregate, slot)
                crash_at("after-record-before-exit")
        return self.projection(envelope_id, aggregate)

    def send(self, envelope_id: str) -> dict[str, Any]:
        require_id(envelope_id)
        aggregate = self.show(envelope_id)
        state = str(aggregate.state)
        if state == "sent":
            return self.projection(envelope_id, aggregate)
        if state in {"signed", "declined", "archived"}:
            raise DeskError("invalid_state")
        facts = self.facts(aggregate)
        return self._send_two(envelope_id, aggregate) if self.is_two_signer(facts) else self._send_one(envelope_id, aggregate)

    def decision(self, action: str, envelope_id: str, now_text: str) -> dict[str, Any]:
        require_id(envelope_id)
        now_ms = require_ms(now_text)
        aggregate = self.show(envelope_id)
        state = str(aggregate.state)
        if state in {"draft", "sending"}:
            raise DeskError("not_sent")
        if state in {"signed", "declined", "archived"}:
            raise DeskError("invalid_state")
        facts = self.facts(aggregate)
        expiry = int(facts.get("expiry_ms", self.effective_deadline(envelope_id, facts)))
        if now_ms > expiry:
            raise DeskError("expired")
        kernel_now_ms = min(now_ms, int(facts["deadline_ms"])) if not self.is_two_signer(facts) else now_ms
        try:
            result = aggregate.command(action, now_ms=kernel_now_ms)
        except KernelError as exc:
            raise DeskError("expired" if now_ms > expiry else "invalid_state") from exc
        if isinstance(result, HistoricalResult):
            raise DeskError("invalid_state")
        return {"envelope_id": envelope_id, "state": str(result.state), "now_ms": now_ms}

    def extend_deadline(self, envelope_id: str, deadline_text: str, now_text: str) -> dict[str, Any]:
        require_id(envelope_id)
        new_deadline = require_ms(deadline_text)
        now_ms = require_ms(now_text)
        if new_deadline < now_ms:
            raise DeskError("bad_args")
        aggregate = self.show(envelope_id)
        state = str(aggregate.state)
        if state not in {"draft", "sent"}:
            raise DeskError("invalid_state")
        facts = self.facts(aggregate)
        current_deadline = self.effective_deadline(envelope_id, facts)
        if new_deadline <= current_deadline:
            raise DeskError("bad_args")
        if not self.is_two_signer(facts):
            self.deadline_overrides[envelope_id] = new_deadline
            save_deadlines(self.deadline_path, self.deadline_overrides)
            return {"envelope_id": envelope_id, "deadline_ms": new_deadline, "state": state, "now_ms": now_ms}
        command = {
            "name": "extend_draft" if state == "draft" else "extend_sent",
            "args": {"deadline_ms": new_deadline, "expiry_ms": new_deadline + 86_400_000},
        }
        try:
            result = aggregate.execute(command)
        except KernelError as exc:
            raise DeskError("invalid_state") from exc
        if isinstance(result, HistoricalResult):
            result = self.show(envelope_id)
        return {"envelope_id": envelope_id, "deadline_ms": new_deadline, "state": str(result.state), "now_ms": now_ms}

    def archive(self, envelope_id: str, now_text: str) -> dict[str, Any]:
        require_id(envelope_id)
        now_ms = require_ms(now_text)
        aggregate = self.show(envelope_id)
        if str(aggregate.state) not in {"signed", "declined"}:
            raise DeskError("invalid_state")
        try:
            result = aggregate.command("archive")
        except KernelError as exc:
            raise DeskError("invalid_state") from exc
        if isinstance(result, HistoricalResult):
            raise DeskError("invalid_state")
        return {"envelope_id": envelope_id, "state": "archived", "now_ms": now_ms}

    def _reconcile_two(self, envelope_id: str, aggregate: Aggregate) -> dict[str, Any]:
        while str(aggregate.state) == "sending":
            facts = self.facts(aggregate)
            slot = self._two_slot(facts)
            if slot == 0:
                break
            if slot == 2 and int(facts["request2_started"]) == 0:
                break
            if slot == 1 and getattr(aggregate.effect, "status", None) in {"completed", "recorded"}:
                aggregate = self._mark_two_complete(envelope_id, aggregate, slot)
                continue
            request_id = str(facts[f"request{slot}_id"])
            found, response = self.service.lookup(request_id)
            if found == "missing":
                return {"envelope_id": envelope_id, "send": "not_sent", "request_id": request_id}
            payload = self._payload_for(envelope_id, aggregate, slot, request_id)
            if response is None or not matches(payload, response):
                raise DeskError("conflict")
            aggregate = self._record_response(envelope_id, aggregate, response)
            aggregate = self._mark_two_complete(envelope_id, aggregate, slot)
        result = self.projection(envelope_id, aggregate)
        return {
            "envelope_id": envelope_id,
            "send": result["send"],
            "request_id": result["request_id"],
            **({k: result[k] for k in ("state", "document_id", "signer_id", "address", "signer1_id", "address1", "signer2_id", "address2", "deadline_ms")} if str(aggregate.state) != "draft" else {}),
        }

    def reconcile(self, envelope_id: str) -> dict[str, Any]:
        require_id(envelope_id)
        aggregate = self.show(envelope_id)
        state = str(aggregate.state)
        facts = self.facts(aggregate)
        if self.is_two_signer(facts):
            if state == "draft":
                return {"envelope_id": envelope_id, "send": "none", "request_id": None}
            if state == "sending":
                return self._reconcile_two(envelope_id, aggregate)
            result = self.projection(envelope_id, aggregate)
            return {"envelope_id": envelope_id, "send": result["send"], "request_id": result["request_id"], **{k: result[k] for k in ("state", "document_id", "signer_id", "address", "signer1_id", "address1", "signer2_id", "address2", "deadline_ms")}}
        if state != "sending":
            result = self.projection(envelope_id, aggregate)
            return {"envelope_id": envelope_id, "send": result["send"], "request_id": result["request_id"], **({k: result[k] for k in ("state", "document_id", "signer_id", "address", "deadline_ms")} if state != "draft" else {})}
        payload = self.payload(envelope_id, aggregate)
        found, response = self.service.lookup(envelope_id)
        if found == "missing":
            return {"envelope_id": envelope_id, "send": "not_sent", "request_id": envelope_id}
        if response is None or not matches(payload, response):
            raise DeskError("conflict")
        if getattr(aggregate.effect, "status", None) != "completed":
            aggregate = self._record_response(envelope_id, aggregate, response)
        aggregate = self.mark_sent(envelope_id, aggregate)
        return self.projection(envelope_id, aggregate)

    def callback(self, callback_path: str) -> dict[str, Any]:
        try:
            value = json.loads(Path(callback_path).read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, ValueError):
            raise DeskError("bad_args")
        obj = required_object(value)
        required = {"callback_id", "request_id", "envelope_id", "document_id", "signer_id", "address", "deadline_ms", "kind", "outcome"}
        if set(obj) < required or obj.get("outcome") not in {"accepted", "rejected"}:
            raise DeskError("bad_args")
        for key in ("callback_id", "request_id", "envelope_id", "document_id", "signer_id", "address", "kind"):
            if not isinstance(obj.get(key), str):
                raise DeskError("bad_args")
        if not isinstance(obj.get("deadline_ms"), int) or isinstance(obj.get("deadline_ms"), bool) or not 0 <= obj["deadline_ms"] <= MAX_MS:
            raise DeskError("bad_args")
        require_id(obj["request_id"])
        require_id(obj["envelope_id"])
        try:
            aggregate = self.show(obj["envelope_id"])
        except DeskError as exc:
            if exc.code == "unknown_envelope":
                return {"callback": "ignored"}
            raise
        if str(aggregate.state) != "sending":
            return {"callback": "ignored"}
        facts = self.facts(aggregate)
        if self.is_two_signer(facts):
            current_slot = self._two_slot(facts)
            expected = str(facts.get(f"request{current_slot}_id", "")) if current_slot else ""
            if obj["request_id"] != expected:
                return {"callback": "ignored"}
        elif obj["request_id"] != obj["envelope_id"]:
            return {"callback": "ignored"}
        return self.reconcile(obj["envelope_id"])


def dispatch(argv: list[str]) -> dict[str, Any]:
    state_dir_text = os.environ.get("STATE_DIR")
    service_url = os.environ.get("SERVICE_URL")
    if not state_dir_text or service_url is None:
        raise DeskError("bad_args")
    desk = Desk(Path(state_dir_text), service_url)
    try:
        if not argv:
            raise DeskError("bad_args")
        command, args = argv[0], argv[1:]
        if command == "create-envelope":
            return desk.create(args)
        if command == "send":
            if len(args) != 1:
                raise DeskError("bad_args")
            return desk.send(args[0])
        if command == "extend-deadline":
            if len(args) != 3:
                raise DeskError("bad_args")
            return desk.extend_deadline(args[0], args[1], args[2])
        if command in {"sign", "decline"}:
            if len(args) != 2:
                raise DeskError("bad_args")
            return desk.decision(command, args[0], args[1])
        if command == "archive":
            if len(args) != 2:
                raise DeskError("bad_args")
            return desk.archive(args[0], args[1])
        if command == "reconcile":
            if len(args) != 1:
                raise DeskError("bad_args")
            return desk.reconcile(args[0])
        if command == "status":
            if len(args) != 1:
                raise DeskError("bad_args")
            envelope_id = require_id(args[0])
            return desk.projection(envelope_id, desk.show(envelope_id))
        if command == "callback":
            if len(args) != 1:
                raise DeskError("bad_args")
            return desk.callback(args[0])
        raise DeskError("bad_args")
    finally:
        desk.close()


def main(argv: list[str]) -> int:
    try:
        result = dispatch(argv)
    except DeskError as exc:
        print(json.dumps({"error": exc.code}, separators=(",", ":")))
        return 1
    except Exception:
        print(json.dumps({"error": "service_unavailable"}, separators=(",", ":")))
        return 1
    print(json.dumps(result, separators=(",", ":"), sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
