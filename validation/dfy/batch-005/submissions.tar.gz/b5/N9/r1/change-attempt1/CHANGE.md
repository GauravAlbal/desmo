# Change: two required signers and renewed expiry

The e-signature desk already implements `brief.md`; R1–R14 remain in force except where this change explicitly revises R3, R4, and R5. Existing persisted envelopes remain valid: a pre-change envelope keeps its one signer and original deadline, while newly created envelopes use the two-signer form below.

## C1. Two required signers

`create-envelope` now has the form `./run create-envelope <envelope_id> <document_id> <signer1_id> <address1> <signer2_id> <address2> <deadline_ms> <now_ms>`. Both signers are required and must be distinct. The result and `status` include `signer2_id` and `address2`; both are durably retained. A collision with either signer or document id uses `id_in_use`. A malformed or duplicate signer is `bad_args`.

## C2. Revised send behavior

A two-signer envelope sends one request per required signer. Request ids are `<envelope_id>.s1` and `<envelope_id>.s2`; each payload includes the corresponding signer and the complete envelope deadline. The envelope becomes `sent` only after both requests are accepted or found by lookup. The original crash boundaries apply to the first not-yet-complete request; retries and reconciliation use the saved request id and never create another id. One-signer persisted envelopes retain the original request id equal to their envelope id.

## C3. Revised expiry

For newly created two-signer envelopes, decisions are permitted through `deadline_ms + 86400000` (one extra day); one millisecond later returns `expired`. Existing one-signer envelopes retain the original deadline rule.

## C4. New command: `extend-deadline`

`./run extend-deadline <envelope_id> <new_deadline_ms> <now_ms>` is read-only with respect to the signer set but durably replaces the deadline for a draft or sent envelope. `new_deadline_ms` must be no earlier than `now_ms` and strictly later than the stored deadline. Success returns `{"envelope_id":"...","deadline_ms":0,"state":"draft|sent","now_ms":0}`. Signed, declined, or archived envelopes return `invalid_state`; unknown or malformed arguments use the defined protocol. This command never contacts the service. Existing one-signer envelopes may use it, but their original expiry rule remains in force.

## C5. Recovery with two signers

With a two-signer envelope, killing `send` at `after-accept-before-record` for either signer and then running `reconcile` or `send` must finish both signer requests with exactly two effects total, preserve both signer records, and reach `sent`; no second request id or duplicate effect is allowed. A second envelope remains independent.

The original service, callback, state-preservation, and result-protocol requirements remain in force. Added error code: `bad_args` covers duplicate signer fields; no new error code is introduced.
