# E-signature envelope desk

This is a local, durable signing desk. The lifecycle authority and durable
journal are provided by the packed Ikaros runtime in `KIT/`; Python owns CLI
validation, HTTP transport, and result projection.

## Setup

No npm package is required (the supplied `stub/server.mjs` is run with Node and
has no npm dependencies). From this directory:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
chmod +x run
```

`run` locates `.venv/bin/python` and sets `IK_BINARY` to `KIT/bin/ik`. It can be
invoked directly after setup. The evaluator must provide `STATE_DIR` and
`SERVICE_URL`; `CRASH_AT` is optional.

To exercise the fake service in a second terminal:

```sh
<home>/.nvm/versions/node/v22.17.1/bin/node stub/server.mjs
```

Copy its `service_url` into `SERVICE_URL` (the stub prints an ephemeral loopback
port). Example:

```sh
export STATE_DIR="$PWD/.state"
export SERVICE_URL="http://127.0.0.1:PORT"
./run create-envelope env-1 doc-1 signer-1 signer1@example.com signer-2 signer2@example.com 2000 1000
./run send env-1
./run sign env-1 86402000
./run archive env-1 86402000
./run status env-1
```

Run the integration tests with the same installed environment:

```sh
.venv/bin/python -m unittest discover -s tests -v
```

## Behavior

- Ikaros persists envelope facts and lifecycle transitions in
  `$STATE_DIR/kernel.db`; v1 machine instances remain routable with their
  original one-signer facts, while new envelopes use `envelope_v2.ik.toml`.
  Deadline extensions for legacy v1 instances are kept in the owned
  `deadline_overrides.json` compatibility record.
- New envelopes retain both signer records and send one idempotent request per
  signer (`<envelope_id>.s1` and `.s2`). `request_ids` in `status` lists every
  saved request.
- `send` first commits an Ikaros effect intent for the first not-yet-complete
  signer. It reconciles with `GET` before attempting `POST`, and never invents
  a replacement request id.
- `extend-deadline` durably extends draft or sent two-signer envelopes; the
  decision window is the stored deadline plus one day.
- A small owned `envelopes.json` index enforces document and signer-id
  uniqueness. Other files in `STATE_DIR` are not read or changed.
- `CRASH_AT` supports the three boundaries described in `BRIEF.md`; retries
  continue from the saved signer request.
- `reconcile` is lookup-only and never POSTs. A valid callback is only a hint
  to that lookup; it cannot make an envelope sent without a matching service
  record.
- Every invocation emits one compact JSON object. Refusals are nonzero and use
  the error codes in the brief.

## Unresolved assumptions

The brief does not prescribe a filename for the desk-owned index, so this
implementation uses `envelopes.json`. `status` and `send` have no supplied
clock argument; their result projection uses `now_ms: 0`, while decision,
creation, and deadline-extension results echo the supplied time. This is only
a response field and is not persisted or consulted for transitions. For a
two-signer envelope, the legacy `request_id` response field is the first
saved request id; `request_ids` carries both ids.
