#!/usr/bin/env python3
import json
import os
import signal
import subprocess
import tempfile
import time
from invariant_kernel import Kernel
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node"


def request_json(url, method="GET", value=None):
    body = None if value is None else json.dumps(value).encode()
    req = urllib.request.Request(url, data=body, method=method)
    if body is not None:
        req.add_header("content-type", "application/json")
    with urllib.request.urlopen(req) as response:
        return json.loads(response.read())


class DeskIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.stub = subprocess.Popen([NODE, str(ROOT / "stub" / "server.mjs")], stdout=subprocess.PIPE, text=True)
        line = cls.stub.stdout.readline()
        cls.service = json.loads(line)["service_url"]
        cls.control = json.loads(line)["control_url"]

    @classmethod
    def tearDownClass(cls):
        cls.stub.terminate()
        cls.stub.wait(timeout=5)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.state = Path(self.tmp.name)
        (self.state / "unrelated.bin").write_bytes(b"keep these bytes\\x00\\xff")

    def tearDown(self):
        self.tmp.cleanup()

    def invoke(self, *args, crash=None):
        env = os.environ.copy()
        env.update(STATE_DIR=str(self.state), SERVICE_URL=self.service)
        if crash is not None:
            env["CRASH_AT"] = crash
        else:
            env.pop("CRASH_AT", None)
        return subprocess.run([str(ROOT / "run"), *args], env=env, capture_output=True, text=True)

    def create(self, envelope="env", document="doc"):
        result = self.invoke("create-envelope", envelope, document, envelope + "-s1", "one@example.com", envelope + "-s2", "two@example.com", "100", "0")
        self.assertEqual(result.returncode, 0, result.stderr + result.stdout)
        return json.loads(result.stdout)

    def test_process_restart_and_progression(self):
        self.create()
        self.assertEqual(json.loads(self.invoke("send", "env").stdout)["state"], "sent")
        self.assertEqual(json.loads(self.invoke("sign", "env", "100").stdout)["state"], "signed")
        self.assertEqual(json.loads(self.invoke("archive", "env", "100").stdout)["state"], "archived")
        self.assertEqual(json.loads(self.invoke("status", "env").stdout)["state"], "archived")
        self.assertEqual((self.state / "unrelated.bin").read_bytes(), b"keep these bytes\\x00\\xff")
    def test_legacy_one_signer_extension(self):
        kernel = Kernel(self.state / "kernel.db", binary=str(ROOT / "KIT" / "bin" / "ik"))
        machine = kernel.machine(ROOT / "envelope.ik.toml")
        machine.create_with("legacy", {"name": "initialize", "args": {"document_id": "legacy-doc", "signer_id": "legacy-signer", "address": "legacy@example.com", "deadline_ms": 100, "initialization": 1}})
        kernel.close()
        (self.state / "envelopes.json").write_text(json.dumps({"envelopes": {"legacy": "legacy-doc"}}))
        extended = self.invoke("extend-deadline", "legacy", "200", "150")
        self.assertEqual(extended.returncode, 0, extended.stderr + extended.stdout)
        self.assertEqual(json.loads(self.invoke("send", "legacy").stdout)["state"], "sent")
        self.assertEqual(json.loads(self.invoke("sign", "legacy", "200").stdout)["state"], "signed")

    def test_extend_deadline_and_duplicate_signer(self):
        self.create("extend", "extend-doc")
        extended = self.invoke("extend-deadline", "extend", "200", "150")
        self.assertEqual(extended.returncode, 0, extended.stderr + extended.stdout)
        self.assertEqual(json.loads(extended.stdout)["deadline_ms"], 200)
        duplicate = self.invoke("create-envelope", "other", "other-doc", "extend-s1", "one@example.com", "new-signer", "new@example.com", "300", "0")
        self.assertNotEqual(duplicate.returncode, 0)
        self.assertEqual(json.loads(duplicate.stdout)["error"], "id_in_use")
        self.assertEqual(json.loads(self.invoke("send", "extend").stdout)["state"], "sent")
        self.assertEqual(json.loads(self.invoke("sign", "extend", "86400200").stdout)["state"], "signed")


    def test_crash_labels(self):
        self.create("before", "before-doc")
        crashed = self.invoke("send", "before", crash="after-attempt-saved-before-request")
        self.assertEqual(crashed.returncode, -signal.SIGKILL)
        self.assertEqual(json.loads(self.invoke("status", "before").stdout)["send"], "attempt_saved")
        self.assertEqual(json.loads(self.invoke("send", "before").stdout)["state"], "sent")

        self.create("after", "after-doc")
        crashed = self.invoke("send", "after", crash="after-record-before-exit")
        self.assertEqual(crashed.returncode, -signal.SIGKILL)
        self.assertEqual(json.loads(self.invoke("status", "after").stdout)["send"], "attempt_saved")
        self.assertEqual(json.loads(self.invoke("send", "after").stdout)["state"], "sent")

    def test_lost_reply_reconcile_lookup_only(self):
        self.create("lost", "lost-doc")
        request_json(self.control + "/fault", "POST", {"drop_reply": True})
        result = self.invoke("send", "lost")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(json.loads(self.invoke("status", "lost").stdout)["send"], "attempt_saved")
        request_json(self.control + "/fault", "POST", {"drop_reply": False})
        reconciled = json.loads(self.invoke("reconcile", "lost").stdout)
        self.assertEqual(reconciled["send"], "attempt_saved")
        self.assertEqual(json.loads(self.invoke("send", "lost").stdout)["state"], "sent")
        effects = request_json(self.control + "/effects")
        self.assertEqual(sum(1 for effect in effects["effects"] if effect["request_id"] in {"lost.s1", "lost.s2"}), 2)
