#!/usr/bin/env python3
"""Command line envelope desk backed by the Ikaros lifecycle runtime."""
from __future__ import annotations

import json
import os
import re
import signal
import sys
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
MACHINE_V1 = ROOT / "envelope.ik.toml"
MACHINE_V2 = ROOT / "envelope-v2.ik.toml"
STATE_DIR = Path(os.environ.get("STATE_DIR", ""))
SERVICE_URL = os.environ.get("SERVICE_URL", "")
CRASH_AT = os.environ.get("CRASH_AT", "")
ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$")
DECIMAL_RE = re.compile(r"^(0|[1-9][0-9]*)$")
ERRORS = {
    "bad_args", "unknown_envelope", "id_in_use", "invalid_state", "not_sent",
    "expired", "conflict", "service_unavailable",
}


class DeskError(Exception):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


def die_at(label: str) -> None:
    if CRASH_AT == label:
        os.kill(os.getpid(), signal.SIGKILL)


def json_line(value: Dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(value, separators=(",", ":"), sort_keys=True) + "\n")
    sys.stdout.flush()


def valid_id(value: Any) -> bool:
    return isinstance(value, str) and ID_RE.fullmatch(value) is not None


def parse_decimal(value: str) -> Optional[int]:
    if not isinstance(value, str) or DECIMAL_RE.fullmatch(value) is None:
        return None
    number = int(value)
    return number if number <= 9999999999999 else None


def require_env() -> None:
    if not STATE_DIR or not SERVICE_URL or SERVICE_URL.endswith("/"):
        raise DeskError("bad_args")


def index_path() -> Path:
    return STATE_DIR / "envelopes-index.json"


def load_index() -> Dict[str, str]:
    path = index_path()
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text())
    except (OSError, ValueError):
        raise DeskError("service_unavailable")
    if not isinstance(value, dict) or any(not valid_id(k) or not valid_id(v) for k, v in value.items()):
        raise DeskError("service_unavailable")
    return {str(k): str(v) for k, v in value.items()}


def save_index(index: Dict[str, str]) -> None:
    path = index_path()
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(index, sort_keys=True, separators=(",", ":")))
    os.replace(str(temporary), str(path))


def kernel() -> Any:
    binary = str(ROOT / "KIT" / "bin" / "ik")
    os.environ["IK_BINARY"] = binary
    try:
        from invariant_kernel import Kernel
    except ImportError:
        raise DeskError("service_unavailable")
    return Kernel(str(STATE_DIR / "lifecycle.sqlite"), binary=binary)


def machine(version: int = 2) -> Any:
    return kernel().machine(str(MACHINE_V2 if version == 2 else MACHINE_V1))


def _machine_version(raw: Any) -> int:
    receipt = getattr(raw, "raw", {}).get("last_receipt", {})
    try:
        return int(receipt.get("machine_version", 1))
    except (TypeError, ValueError):
        raise DeskError("service_unavailable")


def aggregate(m: Any, envelope_id: str) -> Any:
    try:
        return m.show(envelope_id)
    except Exception as exc:
        code = getattr(exc, "code", "")
        if code in ("IK_STORE_NOT_FOUND", "IK_ILLEGAL_STATE", "IK_AGGREGATE_NOT_FOUND"):
            raise DeskError("unknown_envelope")
        raise DeskError("service_unavailable")


def load_aggregate(envelope_id: str) -> Any:
    try:
        raw = kernel().show(envelope_id)
    except Exception as exc:
        code = getattr(exc, "code", "")
        if code in ("IK_STORE_NOT_FOUND", "IK_ILLEGAL_STATE", "IK_AGGREGATE_NOT_FOUND"):
            raise DeskError("unknown_envelope")
        raise DeskError("service_unavailable")
    return aggregate(machine(_machine_version(raw)), envelope_id)


def state_of(agg: Any) -> Dict[str, Any]:
    raw = getattr(agg, "raw", {})
    state = raw.get("state")
    return state if isinstance(state, dict) else {}


def output_status(envelope_id: str, agg: Any, now_ms: int = 0) -> Dict[str, Any]:
    values = state_of(agg)
    result: Dict[str, Any] = {
        "envelope_id": envelope_id,
        "document_id": values.get("document_id", ""),
        "signer_id": values.get("signer_id", ""),
        "address": values.get("address", ""),
        "deadline_ms": values.get("deadline_ms", 0),
        "state": agg.state,
        "send": values.get("send_status", "none"),
        "request_id": values.get("request_id") or values.get("request1_id") or None,
        "now_ms": now_ms,
    }
    if values.get("signer_mode") == "two":
        result.update({
            "signer2_id": values.get("signer2_id", ""),
            "address2": values.get("address2", ""),
            "request1_id": values.get("request1_id") or None,
            "request2_id": values.get("request2_id") or None,
        })
    return result


def command(agg: Any, name: str, **args: Any) -> Any:
    try:
        return agg.command(name, **args)
    except Exception as exc:
        code = getattr(exc, "code", "")
        if code in ("IK_CAPABILITY_STALE", "IK_ILLEGAL_STATE", "IK_INVARIANT_FAILED", "IK_COMMAND_INVALID", "IK_MACHINE_MISMATCH"):
            raise DeskError("invalid_state")
        raise DeskError("service_unavailable")


def http_json(method: str, url: str, body: Optional[Dict[str, Any]] = None) -> Tuple[int, Optional[Dict[str, Any]]]:
    data = None if body is None else json.dumps(body, separators=(",", ":")).encode()
    request = Request(url, data=data, method=method, headers={"content-type": "application/json"})
    try:
        with urlopen(request, timeout=5) as response:
            status = int(response.status)
            raw = response.read()
    except HTTPError as exc:
        try:
            raw = exc.read()
        except Exception:
            raw = b""
        try:
            parsed = json.loads(raw.decode())
        except (ValueError, UnicodeDecodeError):
            parsed = None
        return int(exc.code), parsed if isinstance(parsed, dict) else None
    except (URLError, OSError, TimeoutError):
        raise DeskError("service_unavailable")
    try:
        parsed = json.loads(raw.decode())
    except (ValueError, UnicodeDecodeError):
        parsed = None
    return status, parsed if isinstance(parsed, dict) else None


def expected_payload(envelope_id: str, values: Dict[str, Any], request_id: Optional[str] = None,
                     signer_id: Optional[str] = None, address: Optional[str] = None,
                     kind: Optional[str] = None) -> Dict[str, Any]:
    return {
        "request_id": request_id or envelope_id,
        "envelope_id": envelope_id,
        "document_id": values.get("document_id"),
        "signer_id": signer_id if signer_id is not None else values.get("signer_id"),
        "address": address if address is not None else values.get("address"),
        "deadline_ms": values.get("deadline_ms"),
        "kind": kind or values.get("kind") or "signature_request",
    }


def response_matches(payload: Optional[Dict[str, Any]], expected: Dict[str, Any]) -> bool:
    if not isinstance(payload, dict) or payload.get("outcome") != "accepted":
        return False
    return all(payload.get(key) == value for key, value in expected.items())


def mark_sent(agg: Any, name: str = "mark_sent_one") -> Any:
    if name in ("mark_sent", "mark_sent_one", "mark_sent_two"):
        return command(agg, name, send_status="sent")
    return command(agg, name, **({"request1_status": "sent"} if name == "mark_sent_s1" else {"request2_status": "sent"}))


def lookup_or_post(envelope_id: str, request_id: str, values: Dict[str, Any], *, signer_id: str,
                   address: str, allow_post: bool) -> bool:
    expected = expected_payload(envelope_id, values, request_id, signer_id, address)
    status, found = http_json("GET", SERVICE_URL + "/v1/requests/" + quote(request_id, safe=""))
    if status == 200:
        if not response_matches(found, expected):
            raise DeskError("conflict")
        return True
    if status != 404 or not allow_post:
        if status == 404 and not allow_post:
            return False
        raise DeskError("service_unavailable")
    status, accepted = http_json("POST", SERVICE_URL + "/v1/envelopes", expected)
    if status == 409:
        raise DeskError("conflict")
    if status != 200:
        raise DeskError("service_unavailable")
    if not response_matches(accepted, expected):
        raise DeskError("conflict")
    die_at("after-accept-before-record")
    return True


def send_one(envelope_id: str, agg: Any, values: Dict[str, Any]) -> Dict[str, Any]:
    legacy = "signer_mode" not in values
    if values.get("send_status", "none") == "none":
        request_id = envelope_id
        if legacy:
            agg = command(agg, "save_attempt", request_id=request_id, kind="signature_request", send_status="attempt_saved")
        else:
            agg = command(agg, "save_attempt_one", request_id=request_id, kind="signature_request", send_status="attempt_saved")
        values = state_of(agg)
        die_at("after-attempt-saved-before-request")
    elif values.get("send_status") != "attempt_saved":
        raise DeskError("invalid_state")
    request_id = values.get("request_id") or envelope_id
    if lookup_or_post(envelope_id, request_id, values, signer_id=values.get("signer_id", ""), address=values.get("address", ""), allow_post=True):
        agg = mark_sent(agg, "mark_sent" if legacy else "mark_sent_one")
    die_at("after-record-before-exit")
    return output_status(envelope_id, agg)


def send_two(envelope_id: str, agg: Any, values: Dict[str, Any]) -> Dict[str, Any]:
    if values.get("request1_status", "none") == "none":
        agg = command(agg, "save_attempt_s1", request1_id=envelope_id + ".s1", request1_kind="signature_request", request1_status="attempt_saved", send_status="attempt_saved")
        values = state_of(agg)
        die_at("after-attempt-saved-before-request")
    if values.get("request1_status") == "attempt_saved":
        request1_id = values.get("request1_id") or envelope_id + ".s1"
        if lookup_or_post(envelope_id, request1_id, values, signer_id=values.get("signer_id", ""), address=values.get("address", ""), allow_post=True):
            agg = mark_sent(agg, "mark_sent_s1")
            values = state_of(agg)
    elif values.get("request1_status") != "sent":
        raise DeskError("invalid_state")
    if values.get("request2_status", "none") == "none":
        agg = command(agg, "save_attempt_s2", request2_id=envelope_id + ".s2", request2_kind="signature_request", request2_status="attempt_saved", send_status="attempt_saved")
        values = state_of(agg)
        die_at("after-attempt-saved-before-request")
    if values.get("request2_status") == "attempt_saved":
        request2_id = values.get("request2_id") or envelope_id + ".s2"
        if lookup_or_post(envelope_id, request2_id, values, signer_id=values.get("signer2_id", ""), address=values.get("address2", ""), allow_post=True):
            agg = mark_sent(agg, "mark_sent_s2")
            values = state_of(agg)
    elif values.get("request2_status") != "sent":
        raise DeskError("invalid_state")
    agg = mark_sent(agg, "mark_sent_two")
    die_at("after-record-before-exit")
    return output_status(envelope_id, agg)


def send(envelope_id: str) -> Dict[str, Any]:
    agg = load_aggregate(envelope_id)
    values = state_of(agg)
    if agg.state == "sent":
        return output_status(envelope_id, agg)
    if agg.state != "draft":
        raise DeskError("invalid_state")
    if values.get("signer_mode") == "two":
        return send_two(envelope_id, agg, values)
    if values.get("signer_mode") == "one":
        return send_one(envelope_id, agg, values)
    return send_one(envelope_id, agg, values)


def reconcile(envelope_id: str) -> Dict[str, Any]:
    agg = load_aggregate(envelope_id)
    values = state_of(agg)
    if agg.state == "sent" or values.get("send_status") == "sent":
        return output_status(envelope_id, agg)
    if values.get("signer_mode") == "two":
        statuses = (values.get("request1_status", "none"), values.get("request2_status", "none"))
        if statuses == ("none", "none"):
            return {"envelope_id": envelope_id, "send": "none", "request_id": None}
        for number, status_name in ((1, "request1_status"), (2, "request2_status")):
            if values.get(status_name) != "attempt_saved":
                continue
            request_id = values.get("request%d_id" % number)
            signer = values.get("signer_id" if number == 1 else "signer2_id", "")
            address = values.get("address" if number == 1 else "address2", "")
            found = lookup_or_post(envelope_id, request_id, values, signer_id=signer, address=address, allow_post=False)
            if not found:
                return {"envelope_id": envelope_id, "send": "not_sent", "request_id": request_id}
            agg = command(agg, "mark_sent_s%d" % number, **({"request%d_status" % number: "sent"}))
            values = state_of(agg)
        if values.get("request1_status") == "sent" and values.get("request2_status") == "sent":
            agg = mark_sent(agg, "mark_sent_two")
        return output_status(envelope_id, agg)
    if values.get("send_status", "none") == "none":
        return {"envelope_id": envelope_id, "send": "none", "request_id": None}
    if values.get("send_status") != "attempt_saved":
        raise DeskError("invalid_state")
    request_id = values.get("request_id") or envelope_id
    found = lookup_or_post(envelope_id, request_id, values, signer_id=values.get("signer_id", ""), address=values.get("address", ""), allow_post=False)
    if not found:
        return {"envelope_id": envelope_id, "send": "not_sent", "request_id": request_id}
    agg = mark_sent(agg, "mark_sent" if "signer_mode" not in values else "mark_sent_one")
    return output_status(envelope_id, agg)


def parse_callback(path: str) -> Dict[str, Any]:
    try:
        value = json.loads(Path(path).read_text())
    except (OSError, ValueError, UnicodeDecodeError):
        raise DeskError("bad_args")
    if not isinstance(value, dict):
        raise DeskError("bad_args")
    fields = ("callback_id", "request_id", "envelope_id", "document_id", "signer_id", "address", "deadline_ms", "kind", "outcome")
    if any(field not in value for field in fields):
        raise DeskError("bad_args")
    if not all(valid_id(value[field]) for field in ("callback_id", "request_id", "envelope_id", "document_id", "signer_id")):
        raise DeskError("bad_args")
    if not isinstance(value["address"], str) or EMAIL_RE.fullmatch(value["address"]) is None:
        raise DeskError("bad_args")
    if isinstance(value["deadline_ms"], bool) or not isinstance(value["deadline_ms"], int) or value["deadline_ms"] < 0 or value["deadline_ms"] > 9999999999999:
        raise DeskError("bad_args")
    if value["kind"] != "signature_request" or value["outcome"] not in ("accepted", "rejected"):
        raise DeskError("bad_args")
    return value


def all_used_ids(index: Dict[str, str]) -> set[str]:
    used = set(index) | set(index.values())
    for envelope_id in index:
        try:
            values = state_of(load_aggregate(envelope_id))
        except DeskError:
            continue
        for key in ("signer_id", "signer2_id"):
            if valid_id(values.get(key)):
                used.add(values[key])
    return used


def create_envelope(argv: list[str]) -> Dict[str, Any]:
    two = len(argv) == 9
    if len(argv) not in (7, 9):
        raise DeskError("bad_args")
    envelope_id, document_id, signer_id, address = argv[1:5]
    if two:
        signer2_id, address2 = argv[5:7]
        deadline_text, now_text = argv[7:9]
    else:
        signer2_id, address2 = "", ""
        deadline_text, now_text = argv[5:7]
    deadline = parse_decimal(deadline_text)
    now = parse_decimal(now_text)
    if not (valid_id(envelope_id) and valid_id(document_id) and valid_id(signer_id) and EMAIL_RE.fullmatch(address or "") and deadline is not None and now is not None and deadline >= now):
        raise DeskError("bad_args")
    if two and (not valid_id(signer2_id) or not EMAIL_RE.fullmatch(address2 or "") or signer2_id == signer_id):
        raise DeskError("bad_args")
    index = load_index()
    used = all_used_ids(index)
    if envelope_id in used or document_id in used or (two and (signer_id in used or signer2_id in used)):
        raise DeskError("id_in_use")
    m = machine(2)
    try:
        if two:
            decision_deadline = deadline + 86400000
            agg = m.create_with(envelope_id, {"name": "initialize_two", "args": {"document_id": document_id, "signer_id": signer_id, "address": address, "signer2_id": signer2_id, "address2": address2, "deadline_ms": deadline, "decision_deadline_ms": decision_deadline, "signer_mode": "two"}})
        else:
            agg = m.create_with(envelope_id, {"name": "initialize_one", "args": {"document_id": document_id, "signer_id": signer_id, "address": address, "deadline_ms": deadline, "decision_deadline_ms": deadline, "signer_mode": "one"}})
    except Exception as exc:
        if getattr(exc, "code", "") in ("IK_ILLEGAL_STATE", "IK_OPERATION_CONFLICT"):
            raise DeskError("id_in_use")
        raise DeskError("service_unavailable")
    index[envelope_id] = document_id
    save_index(index)
    return output_status(envelope_id, agg, now)


def extend_deadline(envelope_id: str, new_deadline: int, now: int) -> Dict[str, Any]:
    agg = load_aggregate(envelope_id)
    values = state_of(agg)
    if agg.state not in ("draft", "sent"):
        raise DeskError("invalid_state")
    old_deadline = values.get("deadline_ms")
    if not isinstance(old_deadline, int) or new_deadline < now or new_deadline <= old_deadline:
        raise DeskError("bad_args")
    if values.get("signer_mode") == "two":
        decision_deadline = new_deadline + 86400000
    else:
        decision_deadline = new_deadline
    command_name = "extend_deadline_draft" if agg.state == "draft" else "extend_deadline_sent"
    agg = command(agg, command_name, deadline_ms=new_deadline, decision_deadline_ms=decision_deadline)
    return {"envelope_id": envelope_id, "deadline_ms": new_deadline, "state": agg.state, "now_ms": now}


def handle(argv: list[str]) -> Dict[str, Any]:
    require_env()
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    if not argv:
        raise DeskError("bad_args")
    name = argv[0]
    if name == "create-envelope":
        return create_envelope(argv)
    if name in ("send", "reconcile", "status") and len(argv) == 2 and valid_id(argv[1]):
        if name == "send":
            return send(argv[1])
        if name == "reconcile":
            return reconcile(argv[1])
        return output_status(argv[1], load_aggregate(argv[1]))
    if name == "extend-deadline" and len(argv) == 4 and valid_id(argv[1]):
        new_deadline = parse_decimal(argv[2])
        now = parse_decimal(argv[3])
        if new_deadline is None or now is None:
            raise DeskError("bad_args")
        return extend_deadline(argv[1], new_deadline, now)
    if name in ("sign", "decline", "archive") and len(argv) == 3:
        envelope_id = argv[1]
        now = parse_decimal(argv[2])
        if not valid_id(envelope_id) or now is None:
            raise DeskError("bad_args")
        agg = load_aggregate(envelope_id)
        if name == "archive":
            if agg.state not in ("signed", "declined"):
                raise DeskError("invalid_state")
            agg = command(agg, "archive")
        else:
            if agg.state == "draft":
                raise DeskError("not_sent")
            if agg.state != "sent":
                raise DeskError("invalid_state")
            deadline = state_of(agg).get("decision_deadline_ms", state_of(agg).get("deadline_ms"))
            if isinstance(deadline, int) and now > deadline:
                raise DeskError("expired")
            agg = command(agg, name, now_ms=now)
        return {"envelope_id": envelope_id, "state": agg.state, "now_ms": now}
    if name == "callback" and len(argv) == 2:
        value = parse_callback(argv[1])
        return {"callback_id": value["callback_id"], "ignored": True}
    raise DeskError("bad_args")


def main() -> int:
    try:
        result = handle(sys.argv[1:])
        json_line(result)
        return 0
    except DeskError as exc:
        json_line({"error": exc.code if exc.code in ERRORS else "service_unavailable"})
        return 1
    except Exception:
        json_line({"error": "service_unavailable"})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
