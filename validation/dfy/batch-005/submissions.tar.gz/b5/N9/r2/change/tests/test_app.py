import json
import os
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node"


class DeskTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = subprocess.Popen([NODE, "stub/server.mjs"], cwd=str(ROOT), stdout=subprocess.PIPE, text=True)
        line = cls.server.stdout.readline()
        cls.service = json.loads(line)["service_url"]
        cls.control = json.loads(line)["control_url"]

    @classmethod
    def tearDownClass(cls):
        cls.server.terminate()
        cls.server.wait(timeout=5)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.state = Path(self.tmp.name)
        self.env = dict(os.environ, STATE_DIR=str(self.state), SERVICE_URL=self.service)

    def tearDown(self):
        self.tmp.cleanup()

    def call(self, *args, crash=None):
        env = dict(self.env)
        if crash is not None:
            env["CRASH_AT"] = crash
        else:
            env.pop("CRASH_AT", None)
        result = subprocess.run([str(ROOT / "run"), *args], cwd=str(ROOT), env=env, capture_output=True, text=True)
        payload = json.loads(result.stdout) if result.stdout else None
        return result.returncode, payload

    def create(self, eid="env-1", did="doc-1", now="1000", deadline="2000"):
        return self.call("create-envelope", eid, did, "signer-1", "signer@example.com", deadline, now)

    def set_fault(self, body):
        req = Request(self.control + "/fault", data=json.dumps(body).encode(), method="POST", headers={"content-type": "application/json"})
        with urlopen(req, timeout=5) as response:
            return json.loads(response.read())
    def effects(self):
        with urlopen(self.control + "/effects", timeout=5) as response:
            return json.loads(response.read())

    def test_restart_progression_and_deadline(self):
        code, created = self.create("restart-env", "restart-doc")
        self.assertEqual(code, 0)
        self.assertEqual(created["state"], "draft")
        self.assertEqual(self.call("send", "restart-env")[0], 0)
        code, signed = self.call("sign", "restart-env", "2000")
        self.assertEqual((code, signed["state"]), (0, "signed"))
        code, archived = self.call("archive", "restart-env", "2000")
        self.assertEqual((code, archived["state"]), (0, "archived"))
        code, status = self.call("status", "restart-env")
        self.assertEqual(code, 0)
        self.assertEqual(status["state"], "archived")
        self.assertEqual(self.call("send", "restart-env")[1], {"error": "invalid_state"})
        self.assertEqual(self.call("sign", "restart-env", "2000")[1], {"error": "invalid_state"})

    def test_crash_labels_and_recovery(self):
        before = self.effects()["count"]
        self.assertEqual(self.create("crash-env", "crash-doc")[0], 0)
        code, payload = self.call("send", "crash-env", crash="after-attempt-saved-before-request")
        self.assertNotEqual(code, 0)
        code, status = self.call("status", "crash-env")
        self.assertEqual((code, status["send"], status["state"]), (0, "attempt_saved", "draft"))
        code, payload = self.call("send", "crash-env", crash="after-accept-before-record")
        self.assertNotEqual(code, 0)
        code, status = self.call("status", "crash-env")
        self.assertEqual((code, status["send"], status["state"]), (0, "attempt_saved", "draft"))
        code, sent = self.call("send", "crash-env", crash="after-accept-before-record")
        self.assertEqual((code, sent["state"], sent["send"]), (0, "sent", "sent"))
        self.assertEqual(self.create("record-env", "record-doc")[0], 0)
        code, payload = self.call("send", "record-env", crash="after-record-before-exit")
        self.assertNotEqual(code, 0)
        code, status = self.call("status", "record-env")
        self.assertEqual((code, status["send"], status["state"]), (0, "sent", "sent"))
        self.assertEqual(self.effects()["count"], before + 2)

    def test_lost_reply_reconcile_lookup_only(self):
        before = self.effects()["count"]
        self.assertEqual(self.create("lost-env", "lost-doc")[0], 0)
        self.assertEqual(self.set_fault({"drop_reply": True})["ok"], True)
        code, failed = self.call("send", "lost-env")
        self.assertNotEqual(code, 0)
        self.assertEqual(failed, {"error": "service_unavailable"})
        self.assertEqual(self.set_fault({"drop_reply": False})["ok"], True)
        code, reconciled = self.call("reconcile", "lost-env")
        self.assertEqual(code, 0)
        self.assertEqual((reconciled["state"], reconciled["send"]), ("sent", "sent"))
        self.assertEqual(self.effects()["count"], before + 1)

    def test_identity_deadline_callbacks_and_unrelated_file(self):
        unrelated = self.state / "operator-notes.bin"
        unrelated.write_bytes(b"keep these exact bytes\x00\xff")
        self.assertEqual(self.create("env-a", "doc-a")[0], 0)
        self.assertEqual(self.create("env-b", "doc-a")[1], {"error": "id_in_use"})
        self.assertEqual(self.create("doc-a", "doc-b")[1], {"error": "id_in_use"})
        self.assertEqual(self.call("send", "env-a")[0], 0)
        self.assertEqual(self.call("sign", "env-a", "2001")[1], {"error": "expired"})
        callback = self.state / "callback.json"
        callback.write_text(json.dumps({"callback_id": "cb-env-a", "request_id": "env-a", "envelope_id": "env-a", "document_id": "doc-a", "signer_id": "signer-1", "address": "signer@example.com", "deadline_ms": 2000, "kind": "signature_request", "outcome": "rejected"}))
        before = self.call("status", "env-a")[1]
        self.assertEqual(self.call("callback", str(callback))[0], 0)
        self.assertEqual(self.call("status", "env-a")[1], before)
        self.assertEqual(unrelated.read_bytes(), b"keep these exact bytes\x00\xff")


    def test_two_signers_send_and_decide_with_renewed_expiry(self):
        before = self.effects()["count"]
        code, created = self.call(
            "create-envelope", "two-env", "two-doc", "alice", "alice@example.com",
            "bob", "bob@example.com", "2000", "1000",
        )
        self.assertEqual(code, 0)
        self.assertEqual((created["signer2_id"], created["address2"]), ("bob", "bob@example.com"))
        code, sent = self.call("send", "two-env")
        self.assertEqual((code, sent["state"], sent["send"]), (0, "sent", "sent"))
        self.assertEqual((sent["request1_id"], sent["request2_id"]), ("two-env.s1", "two-env.s2"))
        self.assertEqual(self.effects()["count"], before + 2)
        code, signed = self.call("sign", "two-env", "86402000")
        self.assertEqual((code, signed["state"]), (0, "signed"))
        self.assertEqual(self.call("archive", "two-env", "86402000")[1]["state"], "archived")

    def test_extend_deadline_and_duplicate_signer_validation(self):
        self.assertEqual(
            self.call(
                "create-envelope", "bad-two", "bad-doc", "same", "same@example.com",
                "same", "other@example.com", "2000", "1000",
            )[1],
            {"error": "bad_args"},
        )
        self.assertEqual(
            self.call("create-envelope", "one", "doc-one", "shared", "shared@example.com", "2000", "1000")[0],
            0,
        )
        code, duplicate = self.call(
            "create-envelope", "two", "doc-two", "shared", "other@example.com",
            "other-two", "two@example.com", "2000", "1000",
        )
        self.assertEqual((code, duplicate), (1, {"error": "id_in_use"}))
        self.assertEqual(
            self.call(
                "create-envelope", "extend", "doc-extend", "first", "first@example.com",
                "second", "second@example.com", "2000", "1000",
            )[0],
            0,
        )
        code, extended = self.call("extend-deadline", "extend", "3000", "2500")
        self.assertEqual((code, extended["deadline_ms"], extended["state"]), (0, 3000, "draft"))
        self.assertEqual(self.call("send", "extend")[0], 0)
        self.assertEqual(self.call("sign", "extend", "86403001")[1], {"error": "expired"})
        self.assertEqual(self.call("sign", "extend", "86403000")[0], 0)

    def test_two_signer_after_accept_crash_recovers_both_effects(self):
        before = self.effects()["count"]
        self.assertEqual(
            self.call(
                "create-envelope", "recover-two", "recover-doc", "first", "first@example.com",
                "second", "second@example.com", "2000", "1000",
            )[0],
            0,
        )
        code, _ = self.call("send", "recover-two", crash="after-accept-before-record")
        self.assertNotEqual(code, 0)
        code, status = self.call("status", "recover-two")
        self.assertEqual((code, status["state"], status["send"], status["request1_id"]), (0, "draft", "attempt_saved", "recover-two.s1"))
        code, sent = self.call("send", "recover-two")
        self.assertEqual((code, sent["state"], sent["send"]), (0, "sent", "sent"))
        self.assertEqual(self.effects()["count"], before + 2)

if __name__ == "__main__":
    unittest.main()
