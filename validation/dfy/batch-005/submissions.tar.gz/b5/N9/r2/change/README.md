# E-signature envelope desk

This is a Python 3.9-compatible CLI backed by the supplied Ikaros runtime. It
stores canonical lifecycle state in `STATE_DIR/lifecycle.sqlite` and its small
owned envelope index in `STATE_DIR/envelopes-index.json`; other files in the
state directory are not touched.

## Setup

From this directory, with the packed artifacts present:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
```

No npm package is required. `run` locates the local interpreter and packed
`KIT/bin/ik` relative to itself, so an activated environment is not needed.

## Running

Set `STATE_DIR` and `SERVICE_URL` (the latter has no trailing slash):

```sh
STATE_DIR=/tmp/envelope-state SERVICE_URL=http://127.0.0.1:PORT ./run \
  create-envelope env-1 doc-1 signer-1 signer@example.com 2000 1000
STATE_DIR=/tmp/envelope-state SERVICE_URL=http://127.0.0.1:PORT ./run \
  create-envelope env-2 doc-2 signer-a a@example.com signer-b b@example.com 2000 1000
STATE_DIR=/tmp/envelope-state SERVICE_URL=http://127.0.0.1:PORT ./run send env-2
STATE_DIR=/tmp/envelope-state SERVICE_URL=http://127.0.0.1:PORT ./run \
  extend-deadline env-2 3000 2500
STATE_DIR=/tmp/envelope-state SERVICE_URL=http://127.0.0.1:PORT ./run status env-2
```

`CRASH_AT` is optional and accepts the three labels in `BRIEF.md`. A killed
send is recovered with `send` or lookup-only `reconcile`; neither path invents
a request id. Two-signer requests use `<envelope_id>.s1` and `.s2` and both
must be accepted before the envelope is sent. The fake service can be started
with `node stub/server.mjs`.

## Tests

The deterministic standard-library test suite starts the supplied fake service,
exercises restart, all crash boundaries, lost replies, decisions, callbacks,
and preservation of unrelated state:

```sh
.venv/bin/python -m unittest -v tests/test_app.py
```
