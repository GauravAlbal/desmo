import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node"


class DeskTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = subprocess.Popen([NODE, "stub/server.mjs"], cwd=str(ROOT), stdout=subprocess.PIPE, text=True)
        line = cls.server.stdout.readline()
        startup = json.loads(line)
        cls.service = startup["service_url"]
        cls.control = startup["control_url"]

    @classmethod
    def tearDownClass(cls):
        cls.server.terminate()
        cls.server.wait(timeout=5)

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.state = Path(self.tmp.name)
        self.env = dict(os.environ, STATE_DIR=str(self.state), SERVICE_URL=self.service)
        self.create_count = 0
    def tearDown(self):
        self.tmp.cleanup()

    def call(self, *args, crash=None):
        env = dict(self.env)
        if crash is not None:
            env["CRASH_AT"] = crash
        else:
            env.pop("CRASH_AT", None)
        result = subprocess.run([str(ROOT / "run"), *args], cwd=str(ROOT), env=env, capture_output=True, text=True)
        payload = json.loads(result.stdout) if result.stdout else None
        return result.returncode, payload

    def create(self, eid="env-1", did="doc-1", now="1000", deadline="2000"):
        self.create_count += 1
        if self.create_count == 1:
            signer1, address1, signer2, address2 = "signer-1", "signer@example.com", "signer-2", "signer2@example.com"
        else:
            signer1 = "signer-%d" % (self.create_count * 2 - 1)
            signer2 = "signer-%d" % (self.create_count * 2)
            address1, address2 = "signer%d@example.com" % (self.create_count * 2 - 1), "signer%d@example.com" % (self.create_count * 2)
        return self.call(
            "create-envelope", eid, did, signer1, address1, signer2, address2, deadline, now,
        )

    def set_fault(self, body):
        req = Request(self.control + "/fault", data=json.dumps(body).encode(), method="POST", headers={"content-type": "application/json"})
        with urlopen(req, timeout=5) as response:
            return json.loads(response.read())

    def effects(self):
        with urlopen(self.control + "/effects", timeout=5) as response:
            return json.loads(response.read())

    def test_restart_progression_and_renewed_deadline(self):
        code, created = self.create("restart-env", "restart-doc")
        self.assertEqual(code, 0)
        self.assertEqual((created["state"], created["signer2_id"]), ("draft", "signer-2"))
        self.assertEqual(self.call("extend-deadline", "restart-env", "3000", "2500")[0], 0)
        self.assertEqual(self.call("send", "restart-env")[0], 0)
        code, signed = self.call("sign", "restart-env", "86403000")
        self.assertEqual((code, signed["state"]), (0, "signed"))
        code, archived = self.call("archive", "restart-env", "86403000")
        self.assertEqual((code, archived["state"]), (0, "archived"))
        code, status = self.call("status", "restart-env")
        self.assertEqual((code, status["state"], status["deadline_ms"]), (0, "archived", 3000))
        self.assertEqual(self.call("send", "restart-env")[1], {"error": "invalid_state"})
        self.assertEqual(self.call("sign", "restart-env", "2000")[1], {"error": "invalid_state"})

    def test_crash_labels_and_recovery(self):
        before = self.effects()["count"]
        self.assertEqual(self.create("crash-env", "crash-doc")[0], 0)
        code, payload = self.call("send", "crash-env", crash="after-attempt-saved-before-request")
        self.assertNotEqual(code, 0)
        code, status = self.call("status", "crash-env")
        self.assertEqual((code, status["send"], status["state"]), (0, "attempt_saved", "draft"))
        self.assertEqual(self.call("send", "crash-env")[0], 0)
        self.assertEqual(self.effects()["count"], before + 2)
        self.assertEqual(self.create("record-env", "record-doc")[0], 0)
        code, payload = self.call("send", "record-env", crash="after-record-before-exit")
        self.assertNotEqual(code, 0)
        code, status = self.call("status", "record-env")
        self.assertEqual((code, status["send"], status["state"]), (0, "sent", "sent"))
        self.assertEqual(self.effects()["count"], before + 4)

    def test_accept_crash_reconcile_and_lost_reply(self):
        before = self.effects()["count"]
        self.assertEqual(self.create("accept-env", "accept-doc")[0], 0)
        code, _ = self.call("send", "accept-env", crash="after-accept-before-record")
        self.assertNotEqual(code, 0)
        code, reconciled = self.call("reconcile", "accept-env")
        self.assertEqual((code, reconciled["state"], reconciled["send"]), (0, "sent", "sent"))
        self.assertEqual(self.effects()["count"], before + 2)

        self.assertEqual(self.create("lost-env", "lost-doc")[0], 0)
        self.assertEqual(self.set_fault({"drop_reply": True})["ok"], True)
        code, failed = self.call("send", "lost-env")
        self.assertNotEqual(code, 0)
        self.assertEqual(failed, {"error": "service_unavailable"})
        self.assertEqual(self.set_fault({"drop_reply": False})["ok"], True)
        code, reconciled = self.call("reconcile", "lost-env")
        self.assertEqual((code, reconciled["send"]), (0, "not_sent"))
        code, sent = self.call("send", "lost-env")
        self.assertEqual((code, sent["state"], sent["send"]), (0, "sent", "sent"))
        self.assertEqual(self.effects()["count"], before + 4)

    def test_identity_expiry_callbacks_and_unrelated_file(self):
        unrelated = self.state / "operator-notes.bin"
        unrelated.write_bytes(b"keep these exact bytes\x00\xff")
        self.assertEqual(self.create("env-a", "doc-a")[0], 0)
        self.assertEqual(self.create("env-b", "doc-a")[1], {"error": "id_in_use"})
        self.assertEqual(self.call("create-envelope", "env-c", "doc-c", "signer-1", "other@example.com", "signer-3", "three@example.com", "2000", "1000")[1], {"error": "id_in_use"})
        self.assertEqual(self.call("create-envelope", "env-c", "doc-c", "signer-3", "other@example.com", "signer-3", "three@example.com", "2000", "1000")[1], {"error": "bad_args"})
        self.assertEqual(self.call("send", "env-a")[0], 0)
        self.assertEqual(self.call("sign", "env-a", "86402001")[1], {"error": "expired"})
        callback = self.state / "callback.json"
        callback.write_text(json.dumps({"callback_id": "cb-env-a.s1", "request_id": "env-a.s1", "envelope_id": "env-a", "document_id": "doc-a", "signer_id": "signer-1", "address": "signer@example.com", "deadline_ms": 2000, "kind": "signature_request", "outcome": "rejected"}))
        before = self.call("status", "env-a")[1]
        self.assertEqual(self.call("callback", str(callback))[0], 0)
        self.assertEqual(self.call("status", "env-a")[1], before)
        self.assertEqual(unrelated.read_bytes(), b"keep these exact bytes\x00\xff")


if __name__ == "__main__":
    unittest.main()
