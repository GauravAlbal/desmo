#!/usr/bin/env python3
"""Command line envelope desk backed by the Ikaros lifecycle runtime."""
from __future__ import annotations

import json
import os
import re
import signal
import sys
from pathlib import Path
from typing import Any, Dict, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
MACHINE_V1 = ROOT / "envelope.ik.toml"
MACHINE_V2 = ROOT / "envelope_v2.ik.toml"
STATE_DIR = Path(os.environ.get("STATE_DIR", ""))
SERVICE_URL = os.environ.get("SERVICE_URL", "")
CRASH_AT = os.environ.get("CRASH_AT", "")
ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$")
DECIMAL_RE = re.compile(r"^(0|[1-9][0-9]*)$")
ERRORS = {
    "bad_args", "unknown_envelope", "id_in_use", "invalid_state", "not_sent",
    "expired", "conflict", "service_unavailable",
}


class DeskError(Exception):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


def die_at(label: str) -> None:
    if CRASH_AT == label:
        os.kill(os.getpid(), signal.SIGKILL)


def json_line(value: Dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(value, separators=(",", ":"), sort_keys=True) + "\n")
    sys.stdout.flush()


def valid_id(value: Any) -> bool:
    return isinstance(value, str) and ID_RE.fullmatch(value) is not None


def parse_decimal(value: str) -> Optional[int]:
    if not isinstance(value, str) or DECIMAL_RE.fullmatch(value) is None:
        return None
    number = int(value)
    return number if number <= 9999999999999 else None


def require_env() -> None:
    if not STATE_DIR or not SERVICE_URL or SERVICE_URL.endswith("/"):
        raise DeskError("bad_args")


def index_path() -> Path:
    return STATE_DIR / "envelopes-index.json"


def versions_path() -> Path:
    return STATE_DIR / "envelopes-v2.json"


def load_index() -> Dict[str, str]:
    path = index_path()
    if not path.exists():
        return {}
    try:
        value = json.loads(path.read_text())
    except (OSError, ValueError):
        raise DeskError("service_unavailable")
    if not isinstance(value, dict) or any(not valid_id(k) or not valid_id(v) for k, v in value.items()):
        raise DeskError("service_unavailable")
    return {str(k): str(v) for k, v in value.items()}


def save_index(index: Dict[str, str]) -> None:
    path = index_path()
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(index, sort_keys=True, separators=(",", ":")))
    os.replace(str(temporary), str(path))


def load_v2_ids() -> set[str]:
    path = versions_path()
    if not path.exists():
        return set()
    try:
        value = json.loads(path.read_text())
    except (OSError, ValueError):
        raise DeskError("service_unavailable")
    if not isinstance(value, list) or any(not valid_id(item) for item in value):
        raise DeskError("service_unavailable")
    return set(value)


def save_v2_ids(ids: set[str]) -> None:
    path = versions_path()
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(sorted(ids), separators=(",", ":")))
    os.replace(str(temporary), str(path))


def kernel() -> Any:
    binary = str(ROOT / "KIT" / "bin" / "ik")
    os.environ["IK_BINARY"] = binary
    try:
        from invariant_kernel import Kernel
    except ImportError:
        raise DeskError("service_unavailable")
    return Kernel(str(STATE_DIR / "lifecycle.sqlite"), binary=binary)


def machine_v1() -> Any:
    return kernel().machine(str(MACHINE_V1))


def machine_v2() -> Any:
    return kernel().machine(str(MACHINE_V2))


def machine_for(envelope_id: str) -> Any:
    return machine_v2() if envelope_id in load_v2_ids() else machine_v1()


def aggregate(m: Any, envelope_id: str) -> Any:
    try:
        return m.show(envelope_id)
    except Exception as exc:
        code = getattr(exc, "code", "")
        if code in ("IK_STORE_NOT_FOUND", "IK_ILLEGAL_STATE", "IK_AGGREGATE_NOT_FOUND"):
            raise DeskError("unknown_envelope")
        raise DeskError("service_unavailable")


def state_of(agg: Any) -> Dict[str, Any]:
    raw = getattr(agg, "raw", {})
    state = raw.get("state")
    return state if isinstance(state, dict) else {}


def output_status(envelope_id: str, agg: Any, now_ms: int = 0) -> Dict[str, Any]:
    values = state_of(agg)
    result: Dict[str, Any] = {
        "envelope_id": envelope_id,
        "document_id": values.get("document_id", ""),
        "signer_id": values.get("signer_id", ""),
        "address": values.get("address", ""),
        "deadline_ms": values.get("deadline_ms", 0),
        "state": agg.state,
        "send": values.get("send_status", "none"),
        "request_id": values.get("request_id") or None,
        "now_ms": now_ms,
    }
    if "signer2_id" in values:
        result.update({
            "signer2_id": values.get("signer2_id", ""),
            "address2": values.get("address2", ""),
            "request_ids": [
                values.get("request1_id") or None,
                values.get("request2_id") or None,
            ],
        })
        if values.get("send1_status") == "sent" and values.get("send2_status") == "sent":
            result["send"] = "sent"
        elif values.get("send1_status") == "attempt_saved" or values.get("send2_status") == "attempt_saved":
            result["send"] = "attempt_saved"
        else:
            result["send"] = "none"
        result["request_id"] = values.get("request1_id") or None
    return result


def command(agg: Any, name: str, **args: Any) -> Any:
    try:
        return agg.command(name, **args)
    except Exception as exc:
        code = getattr(exc, "code", "")
        if code in ("IK_CAPABILITY_STALE", "IK_ILLEGAL_STATE", "IK_INVARIANT_FAILED", "IK_COMMAND_INVALID"):
            raise DeskError("invalid_state")
        raise DeskError("service_unavailable")


def http_json(method: str, url: str, body: Optional[Dict[str, Any]] = None) -> Tuple[int, Optional[Dict[str, Any]]]:
    data = None if body is None else json.dumps(body, separators=(",", ":")).encode()
    request = Request(url, data=data, method=method, headers={"content-type": "application/json"})
    try:
        with urlopen(request, timeout=5) as response:
            status = int(response.status)
            raw = response.read()
    except HTTPError as exc:
        try:
            raw = exc.read()
        except Exception:
            raw = b""
        try:
            parsed = json.loads(raw.decode())
        except (ValueError, UnicodeDecodeError):
            parsed = None
        return int(exc.code), parsed if isinstance(parsed, dict) else None
    except (URLError, OSError, TimeoutError):
        raise DeskError("service_unavailable")
    try:
        parsed = json.loads(raw.decode())
    except (ValueError, UnicodeDecodeError):
        parsed = None
    return status, parsed if isinstance(parsed, dict) else None


def expected_payload(envelope_id: str, values: Dict[str, Any], request_id: Optional[str] = None,
                     signer_id: Optional[str] = None, address: Optional[str] = None) -> Dict[str, Any]:
    return {
        "request_id": request_id or envelope_id,
        "envelope_id": envelope_id,
        "document_id": values.get("document_id"),
        "signer_id": signer_id or values.get("signer_id"),
        "address": address or values.get("address"),
        "deadline_ms": values.get("deadline_ms"),
        "kind": values.get("kind") or "signature_request",
    }


def response_matches(payload: Optional[Dict[str, Any]], expected: Dict[str, Any]) -> bool:
    if not isinstance(payload, dict) or payload.get("outcome") != "accepted":
        return False
    return all(payload.get(key) == value for key, value in expected.items())


def mark_sent(agg: Any) -> Any:
    return command(agg, "mark_sent", send_status="sent")


def request_result(request_id: str, expected: Dict[str, Any], allow_post: bool) -> Tuple[bool, bool]:
    status, found = http_json("GET", SERVICE_URL + "/v1/requests/" + quote(request_id, safe=""))
    if status == 200:
        if not response_matches(found, expected):
            raise DeskError("conflict")
        return True, False
    if status != 404 or not allow_post:
        if status == 404:
            return False, False
        raise DeskError("service_unavailable")
    status, accepted = http_json("POST", SERVICE_URL + "/v1/envelopes", expected)
    if status == 409:
        raise DeskError("conflict")
    if status != 200:
        raise DeskError("service_unavailable")
    if not response_matches(accepted, expected):
        raise DeskError("conflict")
    return True, True


def send_v1(envelope_id: str) -> Dict[str, Any]:
    agg = aggregate(machine_v1(), envelope_id)
    values = state_of(agg)
    if agg.state != "draft":
        if agg.state == "sent":
            return output_status(envelope_id, agg)
        raise DeskError("invalid_state")
    send_status = values.get("send_status", "none")
    if send_status == "none":
        agg = command(agg, "save_attempt", request_id=envelope_id, kind="signature_request", send_status="attempt_saved")
        values = state_of(agg)
        die_at("after-attempt-saved-before-request")
    elif send_status != "attempt_saved":
        raise DeskError("invalid_state")
    expected = expected_payload(envelope_id, values)
    found, _ = request_result(envelope_id, expected, True)
    if not found:
        raise DeskError("service_unavailable")
    agg = mark_sent(agg)
    die_at("after-record-before-exit")
    return output_status(envelope_id, agg)


def send_v2(envelope_id: str) -> Dict[str, Any]:
    agg = aggregate(machine_v2(), envelope_id)
    values = state_of(agg)
    if agg.state != "draft":
        if agg.state == "sent":
            return output_status(envelope_id, agg)
        raise DeskError("invalid_state")
    saved_now = False
    if values.get("send1_status") == "none":
        agg = command(
            agg, "save_attempt1", request_id=envelope_id + ".s1",
            kind="signature_request", send_status="attempt_saved"
        )
        saved_now = True
    if values.get("send2_status") == "none":
        agg = command(
            agg, "save_attempt2", request_id=envelope_id + ".s2",
            kind="signature_request", send_status="attempt_saved"
        )
        saved_now = True
    values = state_of(agg)
    if saved_now:
        die_at("after-attempt-saved-before-request")

    posted = False
    if values.get("send1_status") == "attempt_saved":
        expected1 = expected_payload(
            envelope_id, values, values.get("request1_id"), values.get("signer_id"), values.get("address")
        )
        found, did_post = request_result(values["request1_id"], expected1, True)
        if not found:
            raise DeskError("service_unavailable")
        posted = posted or did_post
        agg = command(agg, "mark_sent1", send_status="sent")
        values = state_of(agg)
    if values.get("send2_status") == "attempt_saved":
        expected2 = expected_payload(
            envelope_id, values, values.get("request2_id"), values.get("signer2_id"), values.get("address2")
        )
        found, did_post = request_result(values["request2_id"], expected2, True)
        if not found:
            raise DeskError("service_unavailable")
        posted = posted or did_post
        if posted:
            die_at("after-accept-before-record")
        agg = command(agg, "mark_sent2", send_status="sent")
    elif posted:
        die_at("after-accept-before-record")
        raise DeskError("service_unavailable")
    die_at("after-record-before-exit")
    return output_status(envelope_id, agg)


def send(envelope_id: str) -> Dict[str, Any]:
    return send_v2(envelope_id) if envelope_id in load_v2_ids() else send_v1(envelope_id)


def reconcile_v1(envelope_id: str) -> Dict[str, Any]:
    agg = aggregate(machine_v1(), envelope_id)
    values = state_of(agg)
    send_status = values.get("send_status", "none")
    if agg.state == "sent" or send_status == "sent":
        return output_status(envelope_id, agg)
    if send_status == "none":
        return {"envelope_id": envelope_id, "send": "none", "request_id": None}
    if send_status != "attempt_saved":
        raise DeskError("invalid_state")
    expected = expected_payload(envelope_id, values)
    found, _ = request_result(envelope_id, expected, False)
    if not found:
        return {"envelope_id": envelope_id, "send": "not_sent", "request_id": envelope_id}
    agg = mark_sent(agg)
    return output_status(envelope_id, agg)


def reconcile_v2(envelope_id: str) -> Dict[str, Any]:
    agg = aggregate(machine_v2(), envelope_id)
    values = state_of(agg)
    if agg.state == "sent":
        return output_status(envelope_id, agg)
    if values.get("send1_status") == "none" and values.get("send2_status") == "none":
        return {"envelope_id": envelope_id, "send": "none", "request_id": None}
    found1 = found2 = True
    if values.get("send1_status") == "attempt_saved":
        expected1 = expected_payload(
            envelope_id, values, values.get("request1_id"), values.get("signer_id"), values.get("address")
        )
        found1, _ = request_result(values["request1_id"], expected1, False)
        if found1:
            agg = command(agg, "mark_sent1", send_status="sent")
            values = state_of(agg)
    if values.get("send2_status") == "attempt_saved":
        expected2 = expected_payload(
            envelope_id, values, values.get("request2_id"), values.get("signer2_id"), values.get("address2")
        )
        found2, _ = request_result(values["request2_id"], expected2, False)
        if found2 and values.get("send1_status") == "sent":
            agg = command(agg, "mark_sent2", send_status="sent")
    if found1 and found2 and state_of(agg).get("send2_status") == "sent":
        return output_status(envelope_id, agg)
    values = state_of(agg)
    return {
        "envelope_id": envelope_id,
        "send": "not_sent",
        "request_id": values.get("request1_id") or None,
        "request_ids": [values.get("request1_id") or None, values.get("request2_id") or None],
    }


def reconcile(envelope_id: str) -> Dict[str, Any]:
    return reconcile_v2(envelope_id) if envelope_id in load_v2_ids() else reconcile_v1(envelope_id)


def parse_callback(path: str) -> Dict[str, Any]:
    try:
        value = json.loads(Path(path).read_text())
    except (OSError, ValueError, UnicodeDecodeError):
        raise DeskError("bad_args")
    if not isinstance(value, dict):
        raise DeskError("bad_args")
    fields = ("callback_id", "request_id", "envelope_id", "document_id", "signer_id", "address", "deadline_ms", "kind", "outcome")
    if any(field not in value for field in fields):
        raise DeskError("bad_args")
    if not all(valid_id(value[field]) for field in ("callback_id", "request_id", "envelope_id", "document_id", "signer_id")):
        raise DeskError("bad_args")
    if not isinstance(value["address"], str) or EMAIL_RE.fullmatch(value["address"]) is None:
        raise DeskError("bad_args")
    if isinstance(value["deadline_ms"], bool) or not isinstance(value["deadline_ms"], int) or value["deadline_ms"] < 0 or value["deadline_ms"] > 9999999999999:
        raise DeskError("bad_args")
    if value["kind"] != "signature_request" or value["outcome"] not in ("accepted", "rejected"):
        raise DeskError("bad_args")
    return value


def known_signers(index: Dict[str, str], v2_ids: set[str]) -> set[str]:
    result: set[str] = set()
    for envelope_id in v2_ids:
        try:
            values = state_of(aggregate(machine_v2(), envelope_id))
        except DeskError:
            continue
        for key in ("signer_id", "signer2_id"):
            if valid_id(values.get(key)):
                result.add(values[key])
    for envelope_id in index:
        if envelope_id in v2_ids:
            continue
        try:
            values = state_of(aggregate(machine_v1(), envelope_id))
        except DeskError:
            continue
        if valid_id(values.get("signer_id")):
            result.add(values["signer_id"])
    return result


def create_envelope(argv: list[str]) -> Dict[str, Any]:
    if len(argv) != 9:
        raise DeskError("bad_args")
    envelope_id, document_id, signer1, address1, signer2, address2 = argv[1:7]
    deadline = parse_decimal(argv[7])
    now = parse_decimal(argv[8])
    if not (
        valid_id(envelope_id) and valid_id(document_id) and valid_id(signer1)
        and valid_id(signer2) and signer1 != signer2
        and EMAIL_RE.fullmatch(address1 or "") and EMAIL_RE.fullmatch(address2 or "")
        and deadline is not None and now is not None and deadline >= now
    ):
        raise DeskError("bad_args")
    index = load_index()
    v2_ids = load_v2_ids()
    signers = known_signers(index, v2_ids)
    if (
        envelope_id in index or envelope_id in index.values() or document_id in index
        or document_id in index.values() or document_id in signers
        or signer1 in index or signer2 in index
        or signer1 in index.values() or signer2 in index.values()
        or signer1 in signers or signer2 in signers
    ):
        raise DeskError("id_in_use")
    try:
        agg = machine_v2().create_with(
            envelope_id,
            {
                "name": "initialize",
                "args": {
                    "document_id": document_id,
                    "signer_id": signer1,
                    "address": address1,
                    "signer2_id": signer2,
                    "address2": address2,
                    "deadline_ms": deadline,
                },
            },
        )
    except Exception as exc:
        if getattr(exc, "code", "") in ("IK_ILLEGAL_STATE", "IK_OPERATION_CONFLICT"):
            raise DeskError("id_in_use")
        raise DeskError("service_unavailable")
    index[envelope_id] = document_id
    save_index(index)
    v2_ids.add(envelope_id)
    save_v2_ids(v2_ids)
    return output_status(envelope_id, agg, now)


def handle(argv: list[str]) -> Dict[str, Any]:
    require_env()
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    if not argv:
        raise DeskError("bad_args")
    name = argv[0]
    if name == "create-envelope":
        return create_envelope(argv)
    if name in ("send", "reconcile", "status") and len(argv) == 2 and valid_id(argv[1]):
        if name == "send":
            return send(argv[1])
        if name == "reconcile":
            return reconcile(argv[1])
        return output_status(argv[1], aggregate(machine_for(argv[1]), argv[1]))
    if name == "extend-deadline" and len(argv) == 4 and valid_id(argv[1]):
        new_deadline = parse_decimal(argv[2])
        now = parse_decimal(argv[3])
        if new_deadline is None or now is None or new_deadline < now:
            raise DeskError("bad_args")
        envelope_id = argv[1]
        agg = aggregate(machine_for(envelope_id), envelope_id)
        if agg.state not in ("draft", "sent"):
            raise DeskError("invalid_state")
        old_deadline = state_of(agg).get("deadline_ms")
        if not isinstance(old_deadline, int) or new_deadline <= old_deadline:
            raise DeskError("bad_args")
        if envelope_id not in load_v2_ids():
            if agg.state != "draft":
                raise DeskError("invalid_state")
            values = state_of(agg)
            agg = command(
                agg, "initialize", document_id=values["document_id"],
                signer_id=values["signer_id"], address=values["address"],
                deadline_ms=new_deadline,
            )
        else:
            command_name = "extend_deadline_draft" if agg.state == "draft" else "extend_deadline_sent"
            agg = command(agg, command_name, new_deadline_ms=new_deadline)
        return {"envelope_id": envelope_id, "deadline_ms": new_deadline, "state": agg.state, "now_ms": now}
    if name in ("sign", "decline", "archive") and len(argv) == 3 and valid_id(argv[1]):
        envelope_id = argv[1]
        now = parse_decimal(argv[2])
        if now is None:
            raise DeskError("bad_args")
        agg = aggregate(machine_for(envelope_id), envelope_id)
        if name == "archive":
            if agg.state not in ("signed", "declined"):
                raise DeskError("invalid_state")
            agg = command(agg, "archive")
        else:
            if agg.state == "draft":
                raise DeskError("not_sent")
            if agg.state != "sent":
                raise DeskError("invalid_state")
            values = state_of(agg)
            deadline = values.get("deadline_ms")
            cutoff = deadline + (86400000 if "signer2_id" in values else 0)
            if isinstance(deadline, int) and now > cutoff:
                raise DeskError("expired")
            agg = command(agg, name, now_ms=now)
        return {"envelope_id": envelope_id, "state": agg.state, "now_ms": now}
    if name == "callback" and len(argv) == 2:
        value = parse_callback(argv[1])
        return {"callback_id": value["callback_id"], "ignored": True}
    raise DeskError("bad_args")


def main() -> int:
    try:
        result = handle(sys.argv[1:])
        json_line(result)
        return 0
    except DeskError as exc:
        json_line({"error": exc.code if exc.code in ERRORS else "service_unavailable"})
        return 1
    except Exception:
        json_line({"error": "service_unavailable"})
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
