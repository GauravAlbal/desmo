# E-signature envelope desk

This is a Python 3.9-compatible CLI backed by the supplied Ikaros runtime. It
stores canonical lifecycle state in `STATE_DIR/lifecycle.sqlite`, plus owned
indexes in `STATE_DIR/envelopes-index.json` and `STATE_DIR/envelopes-v2.json`;
other files in the state directory are not touched.
New envelopes use `envelope_v2.ik.toml`; pre-change one-signer aggregates are
read with the unchanged `envelope.ik.toml` definition and remain readable.

## Setup

From this directory, with the packed artifacts present:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
```

No npm package is required. `run` locates the local interpreter and packed
`KIT/bin/ik` relative to itself, so an activated environment is not needed.

## Running

Set `STATE_DIR` and `SERVICE_URL` (the latter has no trailing slash):

```sh
STATE_DIR=/tmp/envelope-state SERVICE_URL=http://127.0.0.1:PORT ./run \
  create-envelope env-1 doc-1 signer-1 signer@example.com signer-2 signer2@example.com 2000 1000
STATE_DIR=/tmp/envelope-state SERVICE_URL=http://127.0.0.1:PORT ./run send env-1
STATE_DIR=/tmp/envelope-state SERVICE_URL=http://127.0.0.1:PORT ./run status env-1
```

`CRASH_AT` is optional and accepts the three labels in `BRIEF.md`. A two-signer
send uses request ids `env-1.s1` and `env-1.s2`; a killed send is recovered
with `send` or lookup-only `reconcile`. Neither path invents another request
id. The fake service can be started with `node stub/server.mjs`.

## Tests

The deterministic standard-library test suite starts the supplied fake service,
exercises restart, all crash boundaries, lost replies, decisions, callbacks,
and preservation of unrelated state:

```sh
.venv/bin/python -m unittest -v tests/test_app.py
```
