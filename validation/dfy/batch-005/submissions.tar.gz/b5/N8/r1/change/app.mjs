#!/usr/bin/env node
import { mkdir, readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import process from "node:process";
import { Kernel, StoreNotFoundError, HistoricalResult } from "@ikaros/runtime";

const MACHINE = resolve(new URL("./subscription.ik.toml", import.meta.url).pathname);
const AGGREGATE_ID = "ledger";
const CYCLE_MS = 30n * 24n * 60n * 60n * 1000n;
const PRICES = { basic: 1000n, pro: 3000n, team: 6000n };
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;

function output(value, code = 0) {
  process.stdout.write(JSON.stringify(value, (_, x) => typeof x === "bigint" ? Number(x) : x) + "\n");
  process.exitCode = code;
}
function fail(error, code = 1) { output({ error }, code); }
function requiredEnv() {
  if (!process.env.SERVICE_URL) throw new UserError("missing_service_url");
  if (process.env.NOW_MS === undefined || !/^\d+$/.test(process.env.NOW_MS)) throw new UserError("missing_now_ms");
  return BigInt(process.env.NOW_MS);
}
class UserError extends Error { constructor(code) { super(code); this.code = code; } }
function intArg(s) { return /^\d+$/.test(s ?? "") ? BigInt(s) : null; }
function idArg(s) { return typeof s === "string" && ID_RE.test(s); }
function planArg(s) { return Object.hasOwn(PRICES, s); }
function crash(label) { if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL"); }
function factsOf(aggregate) {
  if (aggregate && aggregate.state && typeof aggregate.state === "object") return aggregate.state;
  const raw = aggregate?.raw ?? {};
  return raw.facts ?? raw;
}
function scalar(v) { return v === undefined ? null : v; }
function asOutput(v) { return typeof v === "bigint" ? Number(v) : v; }
function stateOf(a) { return a.namedState(); }
function statusObject(a) {
  const f = factsOf(a);
  const failure = f.first_failure_ms === undefined || f.first_failure_ms === null || BigInt(f.first_failure_ms) < 0n
    ? null : asOutput(f.first_failure_ms);
  return {
    customer_id: scalar(f.customer_id), subscription_id: scalar(f.subscription_id), plan: scalar(f.plan),
    last_plan: scalar(f.last_plan), renewal_ms: scalar(asOutput(f.renewal_ms)), grace_ms: scalar(asOutput(f.grace_ms)), retry_limit: scalar(asOutput(f.retry_limit)),
    attempts: asOutput(f.attempts ?? 0n), first_failure_ms: failure,
    credit_cents: asOutput(f.credit_cents ?? 0n), proration_cents: asOutput(f.proration_cents ?? f.credit_cents ?? 0n), status: stateOf(a), payment: scalar(f.payment),
    charge_id: scalar(f.charge_id), amount_cents: scalar(asOutput(f.amount_cents)),
  };
}
function successObject(a, extra = {}) {
  const f = factsOf(a);
  return { subscription_id: f.subscription_id, status: stateOf(a), payment: f.payment, charge_id: f.charge_id ?? null, amount_cents: asOutput(f.amount_cents), ...extra };
}
function deadlineFor(f) {
  const failure = f.first_failure_ms;
  return (failure !== undefined && failure !== null && BigInt(failure) >= 0n ? BigInt(failure) : BigInt(f.renewal_ms)) + BigInt(f.grace_ms);
}
function downgradeObject(a) {
  const f = factsOf(a);
  return {
    subscription_id: f.subscription_id, plan: f.plan, last_plan: f.last_plan ?? null,
    proration_cents: asOutput(f.proration_cents ?? f.credit_cents ?? 0n),
    status: stateOf(a), payment: f.payment, charge_id: f.charge_id ?? null,
  };
}
async function context() {
  const now = requiredEnv();
  const stateDir = process.env.STATE_DIR;
  if (!stateDir) throw new UserError("missing_state_dir");
  await mkdir(stateDir, { recursive: true });
  const kernel = new Kernel(resolve(stateDir, "ledger.sqlite"));
  const machine = await kernel.machine(MACHINE);
  let aggregate;
  try { aggregate = await machine.show(AGGREGATE_ID); } catch (e) {
    if (!(e instanceof StoreNotFoundError) && e?.code !== "IK_STORE_NOT_FOUND") throw e;
  }
  return { now, stateDir, kernel, machine, aggregate };
}
function argsOf(command, args) { return { name: command, args }; }
async function invoke(c, command, args) {
  const result = await c.aggregate.execute(argsOf(command, args));
  if (result instanceof HistoricalResult) return c.machine.show(AGGREGATE_ID);
  return result;
}
function providerUrl(path) { return new URL(path, process.env.SERVICE_URL.endsWith("/") ? process.env.SERVICE_URL : process.env.SERVICE_URL + "/").toString(); }
async function request(method, path, body) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 4000);
  try {
    const response = await fetch(providerUrl(path), {
      method, signal: controller.signal,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body, (_, x) => typeof x === "bigint" ? Number(x) : x) : undefined,
    });
    let parsed;
    try { parsed = await response.json(); } catch { throw new UserError("service_unavailable"); }
    return { status: response.status, body: parsed };
  } catch (e) {
    if (e instanceof UserError) throw e;
    throw new UserError("service_unavailable");
  } finally { clearTimeout(timer); }
}
function matchingCharge(body, f) {
  return body && body.charge_id === f.charge_id && body.subscription_id === f.charge_subscription_id &&
    body.plan === f.charge_plan && BigInt(body.renewal_ms) === BigInt(f.charge_renewal_ms) &&
    BigInt(body.amount_cents) === BigInt(f.amount_cents) && body.outcome === "charged";
}
async function saveAccepted(c, body) {
  const f = factsOf(c.aggregate);
  if (!matchingCharge(body, f)) throw new UserError("lookup_conflict");
  if (c.aggregate.pendingIntent) {
    const observed = await c.aggregate.recordEffectOutcome(`${body.charge_id}:${body.renewal_ms}:${body.amount_cents}`, { intent: c.aggregate.pendingIntent });
    c.aggregate = observed instanceof HistoricalResult ? await c.machine.show(AGGREGATE_ID) : observed;
  }
  c.aggregate = await invoke(c, "accept", {
    response_charge_id: body.charge_id, response_subscription_id: body.subscription_id, response_plan: body.plan,
    response_renewal_ms: BigInt(body.renewal_ms), response_amount_cents: BigInt(body.amount_cents),
    new_renewal_ms: BigInt(body.renewal_ms) + CYCLE_MS, payment: "paid",
  });
  return c.aggregate;
}
async function postSaved(c) {
  const f = factsOf(c.aggregate);
  const response = await request("POST", "/v1/charges", {
    charge_id: f.charge_id, subscription_id: f.charge_subscription_id, plan: f.charge_plan,
    renewal_ms: f.charge_renewal_ms, amount_cents: f.amount_cents,
  });
  if (response.status >= 500) throw new UserError("service_unavailable");
  if (response.status !== 200) throw new UserError(response.status === 409 ? "lookup_conflict" : "service_unavailable");
  if (!matchingCharge(response.body, f)) throw new UserError("lookup_conflict");
  crash("after-accept-before-record");
  c.aggregate = await saveAccepted(c, response.body);
  crash("after-record-before-exit");
  return c.aggregate;
}
async function lookupSaved(c, id) {
  const response = await request("GET", `/v1/charges/${encodeURIComponent(id)}`);
  if (response.status === 404) return null;
  if (response.status !== 200) throw new UserError("service_unavailable");
  return response.body;
}
async function markFailed(c) {
  const f = factsOf(c.aggregate);
  if (f.first_failure_ms === undefined || f.first_failure_ms === null || BigInt(f.first_failure_ms) < 0n) {
    c.aggregate = await invoke(c, "mark_failure", { now_ms: c.now });
  }
}
async function postAndRecord(c) {
  try {
    c.aggregate = await postSaved(c);
    return c.aggregate;
  } catch (e) {
    if (e instanceof UserError && e.code === "service_unavailable") await markFailed(c);
    throw e;
  }
}
async function renew(c) {
  if (!c.aggregate) throw new UserError("not_open");
  const f = factsOf(c.aggregate), state = stateOf(c.aggregate);
  if (state === "cancelled") throw new UserError("cancelled");
  if (state === "expired") throw new UserError("expired");
  const renewal = BigInt(f.renewal_ms), deadline = deadlineFor(f);
  if (c.now < renewal) throw new UserError("not_due");
  if (c.now > deadline) {
    c.aggregate = await invoke(c, "expire", { now_ms: c.now, deadline_ms: deadline, payment: "expired" });
    throw new UserError("grace_elapsed");
  }
  if (state === "active" && f.charge_id) return successObject(c.aggregate);
  if (f.charge_id) {
    const found = await lookupSaved(c, f.charge_id);
    if (found) {
      c.aggregate = await saveAccepted(c, found);
      crash("after-record-before-exit");
      return successObject(c.aggregate);
    }
    if (BigInt(f.attempts) >= BigInt(f.retry_limit)) throw new UserError("retry_exhausted");
    c.aggregate = await invoke(c, "bump_attempt", { now_ms: c.now, deadline_ms: deadline });
    try { c.aggregate = await postAndRecord(c); return successObject(c.aggregate); }
    catch (e) { if (e instanceof UserError) throw e; throw new UserError("service_unavailable"); }
  }
  const chargeId = `${f.subscription_id}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`.slice(0, 64);
  const amount = PRICES[f.plan] - BigInt(f.credit_cents ?? f.proration_cents ?? 0n);
  c.aggregate = await invoke(c, "prepare_attempt", {
    charge_id: chargeId, now_ms: c.now, deadline_ms: deadline,
    request_subscription_id: f.subscription_id, request_plan: f.plan, request_renewal_ms: renewal,
    amount_cents: amount > 0n ? amount : 1n, payment: "attempt_saved",
  });
  crash("after-charge-saved-before-request");
  try { c.aggregate = await postAndRecord(c); return successObject(c.aggregate); }
  catch (e) { if (e instanceof UserError) throw e; throw new UserError("service_unavailable"); }
}
async function open(c, argv) {
  if (c.aggregate) throw new UserError("already_open");
  if (argv.length !== 6) throw new UserError("bad_args");
  const [customer_id, subscription_id, plan, renewal_s, grace_s, retry_s] = argv;
  const renewal_ms = intArg(renewal_s), grace_ms = intArg(grace_s), retry_limit = intArg(retry_s);
  if (!idArg(customer_id) || !idArg(subscription_id)) throw new UserError("bad_args");
  if (!planArg(plan)) throw new UserError("bad_plan");
  if (renewal_ms === null || grace_ms === null) throw new UserError("bad_time");
  if (retry_limit === null || retry_limit < 1n || retry_limit > 10n) throw new UserError("bad_retry");
  c.aggregate = await c.machine.createWith({ aggregateId: AGGREGATE_ID, command: argsOf("open", { customer_id, subscription_id, plan, renewal_ms, grace_ms, retry_limit, payment: "none" }) });
  if (c.aggregate instanceof HistoricalResult) c.aggregate = await c.machine.show(AGGREGATE_ID);
  return { customer_id, subscription_id, plan, renewal_ms: asOutput(renewal_ms), grace_ms: asOutput(grace_ms), retry_limit: asOutput(retry_limit), status: "active", payment: "none", charge_id: null };
}
async function downgrade(c, argv) {
  if (argv.length !== 2 || !idArg(argv[0])) throw new UserError("bad_args");
  const [subscription_id, new_plan] = argv;
  if (!planArg(new_plan)) throw new UserError("bad_plan");
  if (!c.aggregate) throw new UserError("not_open");
  const f = factsOf(c.aggregate), state = stateOf(c.aggregate);
  if (subscription_id !== f.subscription_id) throw new UserError("subscription_mismatch");
  if (state !== "active" || f.charge_id) throw new UserError("invalid_status");
  if (new_plan === f.plan) return downgradeObject(c.aggregate);
  if (PRICES[new_plan] >= PRICES[f.plan]) throw new UserError("upgrade_not_allowed");
  const remaining = BigInt(f.renewal_ms) > c.now ? BigInt(f.renewal_ms) - c.now : 0n;
  const credit = (PRICES[f.plan] - PRICES[new_plan]) * remaining / CYCLE_MS;
  c.aggregate = await invoke(c, "downgrade", {
    subscription_id, new_plan, old_plan: f.plan, proration_cents: credit, credit_cents: credit,
  });
  return downgradeObject(c.aggregate);
}
async function cancel(c) {
  if (!c.aggregate) throw new UserError("not_open");
  const f = factsOf(c.aggregate), state = stateOf(c.aggregate);
  if (state === "cancelled") throw new UserError("already_cancelled");
  if (state === "expired") throw new UserError("expired");
  if (f.charge_id || state === "past_due") throw new UserError("charge_started");
  c.aggregate = await invoke(c, "cancel", { payment: "none" });
  return { subscription_id: f.subscription_id, status: "cancelled", payment: "none" };
}
async function reconcile(c, id) {
  if (!idArg(id)) throw new UserError("bad_args");
  if (!c.aggregate) throw new UserError("not_open");
  const f = factsOf(c.aggregate);
  if (!f.charge_id) throw new UserError("no_charge");
  if (id !== f.charge_id) throw new UserError("charge_mismatch");
  const found = await lookupSaved(c, id);
  if (!found) return { lookup: "not_sent", subscription_id: f.subscription_id, charge_id: id, payment: "attempt_saved", status: "past_due" };
  if (!matchingCharge(found, f)) throw new UserError("lookup_conflict");
  if (stateOf(c.aggregate) === "active") return successObject(c.aggregate, { lookup: "paid" });
  c.aggregate = await saveAccepted(c, found);
  crash("after-record-before-exit");
  return successObject(c.aggregate, { lookup: "paid" });
}
async function callback(c, path) {
  if (!path) throw new UserError("bad_callback");
  try { const parsed = JSON.parse(await readFile(resolve(path), "utf8")); if (!parsed || typeof parsed !== "object") throw new Error(); }
  catch { throw new UserError("bad_callback"); }
  return { callback: "ignored" };
}
async function main() {
  try {
    const command = process.argv[2];
    const c = await context();
    let result;
    if (command === "open") result = await open(c, process.argv.slice(3));
    else if (command === "renew") result = await renew(c);
    else if (command === "downgrade") result = await downgrade(c, process.argv.slice(3));
    else if (command === "cancel") result = await cancel(c);
    else if (command === "reconcile") result = await reconcile(c, process.argv[3]);
    else if (command === "status") result = c.aggregate ? statusObject(c.aggregate) : { customer_id: null, subscription_id: null, plan: null, last_plan: null, renewal_ms: null, grace_ms: null, retry_limit: null, attempts: 0, first_failure_ms: null, credit_cents: 0, proration_cents: 0, status: "none", payment: "none", charge_id: null, amount_cents: null };
    else if (command === "callback") result = await callback(c, process.argv[3]);
    else throw new UserError("bad_args");
    output(result);
  } catch (e) {
    if (e instanceof UserError) fail(e.code);
    else if (e?.code === "IK_COMMAND_REFUSED") fail("refused");
    else fail("corrupt_state");
  }
}
await main();
