#!/usr/bin/env node
import { createHash, randomUUID } from 'node:crypto';
import { access, mkdir, readFile, stat } from 'node:fs/promises';
import { dirname, isAbsolute, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Kernel, HistoricalResult, StoreNotFoundError } from '@ikaros/runtime';

const ROOT_ID = 'subscription';
const CYCLE_MS = 2_592_000_000n;
const PRICES = Object.freeze({ basic: 1000n, pro: 3000n, team: 6000n });
const HERE = dirname(fileURLToPath(import.meta.url));
const MACHINE = join(HERE, 'subscription.ik.toml');

class Refusal extends Error {
  constructor(code) { super(code); this.code = code; }
}

function canonical(value) {
  if (typeof value === 'bigint') return value.toString();
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && typeof value === 'object') {
    return '{' + Object.keys(value).sort().map((key) => JSON.stringify(key) + ':' + canonical(value[key])).join(',') + '}';
  }
  return JSON.stringify(value);
}

function jsonValue(value) {
  if (typeof value === 'bigint') {
    if (value <= BigInt(Number.MAX_SAFE_INTEGER) && value >= BigInt(Number.MIN_SAFE_INTEGER)) return Number(value);
    return value.toString();
  }
  if (Array.isArray(value)) return value.map(jsonValue);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, jsonValue(v)]));
  return value;
}

function emit(value) {
  process.stdout.write(JSON.stringify(jsonValue(value)) + '\n');
}

function fail(code) { throw new Refusal(code); }

function requireEnvironment() {
  const stateDir = process.env.STATE_DIR;
  if (!stateDir) fail('bad_args');
  if (!process.env.SERVICE_URL) fail('missing_service_url');
  if (process.env.NOW_MS === undefined) fail('missing_now');
  if (!/^\d+$/.test(process.env.NOW_MS)) fail('bad_time');
  return { stateDir, now: BigInt(process.env.NOW_MS) };
}

function identifier(value) { return typeof value === 'string' && /^[A-Za-z0-9._-]{1,64}$/.test(value); }
function decimal(value) { return typeof value === 'string' && /^(0|[1-9][0-9]*)$/.test(value); }
function parseId(value) { if (!identifier(value)) fail('bad_args'); return value; }
function parseTime(value) { if (!decimal(value)) fail('bad_time'); return BigInt(value); }
function parseRetry(value) {
  if (!decimal(value)) fail('bad_retry');
  const retry = BigInt(value);
  if (retry < 1n || retry > 10n) fail('bad_retry');
  return retry;
}
function parsePlan(value) { if (!(value in PRICES)) fail('bad_plan'); return value; }

async function exists(path) {
  try { await access(path); return true; } catch { return false; }
}

async function context(env) {
  await mkdir(env.stateDir, { recursive: true });
  const store = join(env.stateDir, 'ledger.sqlite');
  const kernel = new Kernel(store);
  const machine = await kernel.machine(MACHINE);
  return { ...env, store, kernel, machine };
}

function stateOf(aggregate) { return aggregate.raw?.state ?? {}; }
function fact(aggregate, name) { return stateOf(aggregate)[name]; }
function bigint(value) { return typeof value === 'bigint' ? value : BigInt(value); }
function stateName(aggregate) { return aggregate.namedState(); }
function paymentOf(aggregate) { return aggregate.effect.status === 'pending' ? 'attempt_saved' : 'none'; }

async function load(ctx) {
  try {
    return await ctx.machine.show(ROOT_ID);
  } catch (error) {
    if (error instanceof StoreNotFoundError || error?.code === 'IK_STORE_NOT_FOUND') {
      if (!(await exists(ctx.store))) return null;
    }
    if (error?.code === 'IK_ILLEGAL_STATE' && !(await exists(ctx.store))) return null;
    throw new Refusal('corrupt_state');
  }
}

function chargeBody(aggregate) {
  return {
    charge_id: fact(aggregate, 'charge_id'),
    subscription_id: fact(aggregate, 'charge_subscription_id'),
    plan: fact(aggregate, 'charge_plan'),
    renewal_ms: bigint(fact(aggregate, 'charge_renewal_ms')),
    amount_cents: bigint(fact(aggregate, 'charge_amount_cents')),
  };
}

function chargeDigest(body) { return createHash('sha256').update(canonical(body)).digest('hex'); }

function successObject(aggregate) {
  return {
    subscription_id: fact(aggregate, 'subscription_id'),
    status: 'active',
    payment: 'none',
    charge_id: fact(aggregate, 'charge_id') ?? null,
    amount_cents: fact(aggregate, 'charge_amount_cents') ?? null,
    renewal_ms: fact(aggregate, 'renewal_ms'),
  };
}

function statusObject(aggregate) {
  if (!aggregate) return { customer_id: null, subscription_id: null, plan: null, last_plan: null, renewal_ms: null, grace_ms: null, retry_limit: null, attempts: 0, first_failure_ms: null, credit_cents: 0, proration_cents: 0, status: 'none', payment: 'none', charge_id: null, amount_cents: null };
  const failureRecorded = fact(aggregate, 'failure_recorded') === true;
  const credit = fact(aggregate, 'credit_cents') ?? 0;
  return {
    customer_id: fact(aggregate, 'customer_id') ?? null,
    subscription_id: fact(aggregate, 'subscription_id') ?? null,
    plan: fact(aggregate, 'plan') ?? null,
    last_plan: fact(aggregate, 'last_plan') ?? null,
    renewal_ms: fact(aggregate, 'renewal_ms') ?? null,
    grace_ms: fact(aggregate, 'grace_ms') ?? null,
    retry_limit: fact(aggregate, 'retry_limit') ?? null,
    attempts: fact(aggregate, 'attempts') ?? 0,
    first_failure_ms: failureRecorded ? fact(aggregate, 'first_failure_ms') : null,
    credit_cents: credit,
    proration_cents: credit,
    status: stateName(aggregate),
    payment: paymentOf(aggregate),
    charge_id: fact(aggregate, 'charge_id') ?? null,
    amount_cents: fact(aggregate, 'charge_amount_cents') ?? null,
  };
}

function requestUrl(path) {
  try { return new URL(path, process.env.SERVICE_URL).toString(); } catch { fail('bad_args'); }
}

async function provider(method, path, body) {
  let response;
  try {
    response = await fetch(requestUrl(path), {
      method,
      headers: body ? { 'content-type': 'application/json' } : undefined,
      body: body ? canonical(body) : undefined,
      signal: AbortSignal.timeout(5000),
    });
  } catch { throw new Refusal('service_unavailable'); }
  let text;
  try { text = await response.text(); } catch { throw new Refusal('service_unavailable'); }
  let data;
  try { data = JSON.parse(text); } catch { throw new Refusal('service_unavailable'); }
  if (response.status === 404 && method === 'GET') return { kind: 'not_found', data };
  if (response.status >= 500) throw new Refusal('service_unavailable');
  if (response.status !== 200) return { kind: 'conflict', data };
  return { kind: 'ok', data };
}

function matchingResponse(aggregate, response) {
  if (!response || response.outcome !== 'charged') return false;
  const body = chargeBody(aggregate);
  return response.charge_id === body.charge_id && response.subscription_id === body.subscription_id && response.plan === body.plan && bigint(response.renewal_ms) === body.renewal_ms && bigint(response.amount_cents) === body.amount_cents;
}

function crashAt(label) { if (process.env.CRASH_AT === label) process.kill(process.pid, 'SIGKILL'); }

function graceDeadline(aggregate) {
  const renewal = bigint(fact(aggregate, 'renewal_ms'));
  const grace = bigint(fact(aggregate, 'grace_ms'));
  if (fact(aggregate, 'failure_recorded') === true) return bigint(fact(aggregate, 'first_failure_ms')) + grace;
  return renewal + grace;
}

async function markFailure(aggregate, now) {
  if (fact(aggregate, 'failure_recorded') === true) return aggregate;
  return aggregate.command('mark_failure', { failure_ms: now });
}

function chargeAmount(aggregate) {
  const price = PRICES[fact(aggregate, 'plan')];
  const credit = bigint(fact(aggregate, 'credit_cents') ?? 0n);
  const discounted = price - credit;
  return discounted > 0n ? discounted : 1n;
}

async function recordAndRenew(ctx, aggregate, response) {
  if (!matchingResponse(aggregate, response)) fail('lookup_conflict');
  crashAt('after-accept-before-record');
  const digest = createHash('sha256').update(canonical(response)).digest('hex');
  const recorded = await aggregate.recordEffectOutcome(digest, { intent: aggregate.pendingIntent });
  const current = recorded instanceof HistoricalResult ? await ctx.machine.show(ROOT_ID) : recorded;
  const renewed = await current.command('renew_success', { new_renewal_ms: bigint(fact(current, 'charge_renewal_ms')) + CYCLE_MS, credit_cents: 0n, zero_attempts: 0n });
  crashAt('after-record-before-exit');
  return renewed;
}

async function postSaved(ctx, aggregate, now) {
  const body = chargeBody(aggregate);
  crashAt('after-charge-saved-before-request');
  let result;
  try {
    result = await provider('POST', '/v1/charges', body);
  } catch (error) {
    if (error instanceof Refusal && error.code === 'service_unavailable') await markFailure(aggregate, now);
    throw error;
  }
  if (result.kind === 'conflict') fail('lookup_conflict');
  if (result.kind !== 'ok') fail('service_unavailable');
  return recordAndRenew(ctx, aggregate, result.data);
}

async function expire(ctx, aggregate) {
  await aggregate.command('expire');
  throw new Refusal('grace_elapsed');
}

async function renew(ctx) {
  const aggregate = await load(ctx);
  if (!aggregate) fail('not_open');
  const status = stateName(aggregate);
  if (status === 'cancelled') fail('cancelled');
  if (status === 'expired') fail('expired');
  const now = ctx.now;
  const renewal = bigint(fact(aggregate, 'renewal_ms'));
  const deadline = graceDeadline(aggregate);
  if (status === 'active') {
    if (now < renewal) fail('not_due');
    if (now > deadline) return expire(ctx, aggregate);
    const body = { charge_id: randomUUID(), subscription_id: fact(aggregate, 'subscription_id'), plan: fact(aggregate, 'plan'), renewal_ms: renewal, amount_cents: chargeAmount(aggregate) };
    const saved = await aggregate.command('save_attempt', {
      charge_id: body.charge_id,
      charge_subscription_id: body.subscription_id,
      charge_plan: body.plan,
      charge_renewal_ms: body.renewal_ms,
      charge_amount_cents: body.amount_cents,
      payload_digest: chargeDigest(body),
    });
    return successObject(await postSaved(ctx, saved, now));
  }
  if (status !== 'past_due') fail('bad_state');
  if (now > deadline) return expire(ctx, aggregate);
  const attempts = bigint(fact(aggregate, 'attempts'));
  const limit = bigint(fact(aggregate, 'retry_limit'));
  if (attempts >= limit) fail('retry_exhausted');
  const chargeId = fact(aggregate, 'charge_id');
  if (!chargeId || aggregate.effect.status !== 'pending') fail('corrupt_state');
  const lookup = await provider('GET', '/v1/charges/' + encodeURIComponent(chargeId));
  if (lookup.kind === 'ok') return successObject(await recordAndRenew(ctx, aggregate, lookup.data));
  if (lookup.kind === 'conflict') fail('lookup_conflict');
  const retried = await aggregate.command('retry_attempt', { failure_ms: now });
  return successObject(await postSaved(ctx, retried, now));
}

async function downgrade(ctx, args) {
  if (args.length !== 2 || !identifier(args[0])) fail('bad_args');
  const subscriptionId = args[0];
  const newPlan = parsePlan(args[1]);
  const aggregate = await load(ctx);
  if (!aggregate) fail('not_open');
  if (subscriptionId !== fact(aggregate, 'subscription_id')) fail('subscription_mismatch');
  const status = stateName(aggregate);
  if (status === 'cancelled') fail('cancelled');
  if (status === 'expired') fail('expired');
  if (status !== 'active') fail('charge_started');
  if (aggregate.effect.status === 'pending') fail('charge_started');
  const oldPlan = fact(aggregate, 'plan');
  if (newPlan === oldPlan) return statusObject(aggregate);
  if (PRICES[newPlan] >= PRICES[oldPlan]) fail('plan_not_cheaper');
  const renewal = bigint(fact(aggregate, 'renewal_ms'));
  const remaining = renewal > ctx.now ? renewal - ctx.now : 0n;
  const credit = ((PRICES[oldPlan] - PRICES[newPlan]) * remaining) / CYCLE_MS;
  const updated = await aggregate.command('downgrade', {
    new_plan: newPlan,
    old_plan: oldPlan,
    credit_cents: credit,
  });
  return statusObject(updated);
}

async function reconcile(ctx, args) {
  if (args.length !== 1 || !identifier(args[0])) fail('bad_args');
  const aggregate = await load(ctx);
  if (!aggregate || !fact(aggregate, 'charge_id')) fail('no_charge');
  if (args[0] !== fact(aggregate, 'charge_id')) fail('charge_mismatch');
  if (aggregate.effect.status !== 'pending') fail('no_charge');
  const lookup = await provider('GET', '/v1/charges/' + encodeURIComponent(args[0]));
  if (lookup.kind === 'not_found') return { lookup: 'not_sent', subscription_id: fact(aggregate, 'subscription_id'), charge_id: args[0], payment: 'attempt_saved', status: 'past_due' };
  if (lookup.kind === 'conflict') fail('lookup_conflict');
  const renewed = await recordAndRenew(ctx, aggregate, lookup.data);
  return { ...successObject(renewed), lookup: 'paid' };
}

async function open(ctx, args) {
  if (args.length !== 6) fail('bad_args');
  const customer = parseId(args[0]);
  const subscription = parseId(args[1]);
  const plan = parsePlan(args[2]);
  const renewal = parseTime(args[3]);
  const grace = parseTime(args[4]);
  const retry = parseRetry(args[5]);
  if (await load(ctx)) fail('already_open');
  let aggregate;
  try {
    aggregate = await ctx.machine.createWith({ aggregateId: ROOT_ID, command: { name: 'open', args: { customer_id: customer, subscription_id: subscription, plan, renewal_ms: renewal, grace_ms: grace, retry_limit: retry } } });
  } catch (error) {
    if (error?.code === 'IK_AGGREGATE_EXISTS') fail('already_open');
    throw error;
  }
  if (aggregate instanceof HistoricalResult) fail('already_open');
  return { customer_id: customer, subscription_id: subscription, plan, renewal_ms: renewal, grace_ms: grace, retry_limit: retry, status: 'active', payment: 'none', charge_id: null };
}

async function cancel(ctx) {
  const aggregate = await load(ctx);
  if (!aggregate) fail('not_open');
  const status = stateName(aggregate);
  if (status === 'past_due' && aggregate.effect.status === 'pending') fail('charge_started');
  if (status === 'cancelled') fail('already_cancelled');
  if (status === 'expired') fail('expired');
  if (status !== 'active') fail('bad_state');
  const cancelled = await aggregate.command('cancel');
  return { subscription_id: fact(cancelled, 'subscription_id'), status: 'cancelled', payment: 'none' };
}

async function callback(args) {
  if (args.length !== 1) fail('bad_args');
  const path = isAbsolute(args[0]) ? args[0] : join(process.cwd(), args[0]);
  let parsed;
  try { parsed = JSON.parse(await readFile(path, 'utf8')); } catch { fail('bad_callback'); }
  if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') fail('bad_callback');
  return { callback: 'ignored' };
}

async function main() {
  const command = process.argv[2];
  const args = process.argv.slice(3);
  let ctx;
  try {
    const env = requireEnvironment();
    ctx = await context(env);
    let result;
    if (command === 'open') result = await open(ctx, args);
    else if (command === 'renew' && args.length === 0) result = await renew(ctx);
    else if (command === 'cancel' && args.length === 0) result = await cancel(ctx);
    else if (command === 'downgrade') result = await downgrade(ctx, args);
    else if (command === 'reconcile') result = await reconcile(ctx, args);
    else if (command === 'status' && args.length === 0) result = statusObject(await load(ctx));
    else if (command === 'callback') result = await callback(args);
    else fail('bad_args');
    emit(result);
  } catch (error) {
    const code = error instanceof Refusal ? error.code : (error?.code === 'IK_STORE_NOT_FOUND' ? 'corrupt_state' : 'corrupt_state');
    emit({ error: code });
    process.exitCode = code === 'not_sent' ? 0 : 1;
  }
}

main();
