#!/usr/bin/env node
import assert from 'node:assert/strict';
import { execFileSync, spawn } from 'node:child_process';
import { mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';

const node = '<home>/.nvm/versions/node/v22.17.1/bin/node';
const run = join(process.cwd(), 'run');
const stub = join(process.cwd(), 'stub/server.mjs');
const serviceProcess = spawn(node, [stub], { stdio: ['ignore', 'pipe', 'inherit'] });
let service;
try {
  let line = '';
  for await (const chunk of serviceProcess.stdout) {
    line += chunk;
    const end = line.indexOf('\n');
    if (end >= 0) { service = JSON.parse(line.slice(0, end)); break; }
  }
  assert.ok(service?.service_url);

  const control = async (body) => {
    const response = await fetch(service.control_url + '/fault', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    assert.equal(response.status, 200);
  };
  const effects = async () => (await (await fetch(service.control_url + '/effects')).json()).count;
  const effectRows = async () => (await (await fetch(service.control_url + '/effects')).json()).effects;
  const invoke = (state, now, command, args = [], extra = {}) => {
    const env = { ...process.env, STATE_DIR: state, SERVICE_URL: service.service_url, NOW_MS: String(now), ...extra };
    try {
      const stdout = execFileSync(run, [command, ...args], { env, encoding: 'utf8' });
      return { code: 0, value: JSON.parse(stdout) };
    } catch (error) {
      const stdout = error.stdout?.toString() ?? '';
      return { code: error.status ?? 1, value: stdout.trim() ? JSON.parse(stdout) : null };
    }
  };

  const state = await mkdtemp(join(tmpdir(), 'subscription-ledger-'));
  const unrelated = join(state, 'unrelated.bin');
  await writeFile(unrelated, Buffer.from([0, 1, 2, 3, 255]));
  const before = await readFile(unrelated);
  assert.deepEqual(invoke(state, 0, 'status').value, { customer_id: null, subscription_id: null, plan: null, last_plan: null, renewal_ms: null, grace_ms: null, retry_limit: null, attempts: 0, first_failure_ms: null, credit_cents: 0, proration_cents: 0, status: 'none', payment: 'none', charge_id: null, amount_cents: null });
  assert.equal(invoke(state, 0, 'open', ['cust', 'sub-a', 'basic', '1000', '500', '2']).value.status, 'active');
  assert.equal(invoke(state, 999, 'renew').value.error, 'not_due');
  assert.deepEqual(await readFile(unrelated), before);

  // Process death after the durable attempt record: one saved id, no provider call yet.
  assert.notEqual(invoke(state, 1000, 'renew', [], { CRASH_AT: 'after-charge-saved-before-request' }).code, 0);
  const pending = invoke(state, 1000, 'status').value;
  assert.equal(pending.status, 'past_due');
  assert.equal(pending.payment, 'attempt_saved');
  assert.equal(invoke(state, 1000, 'renew').value.status, 'active');

  // Process death after provider acceptance: lookup adopts the same effect.
  const state2 = await mkdtemp(join(tmpdir(), 'subscription-ledger-'));
  assert.equal(invoke(state2, 0, 'open', ['cust', 'sub-b', 'pro', '1000', '500', '2']).code, 0);
  assert.notEqual(invoke(state2, 1000, 'renew', [], { CRASH_AT: 'after-accept-before-record' }).code, 0);
  assert.equal(invoke(state2, 1000, 'status').value.payment, 'attempt_saved');
  assert.equal(invoke(state2, 1000, 'renew').value.status, 'active');

  // Process death after the durable active record leaves a no-op-safe active record.
  const state3 = await mkdtemp(join(tmpdir(), 'subscription-ledger-'));
  assert.equal(invoke(state3, 0, 'open', ['cust', 'sub-c', 'team', '1000', '500', '2']).code, 0);
  assert.notEqual(invoke(state3, 1000, 'renew', [], { CRASH_AT: 'after-record-before-exit' }).code, 0);
  assert.equal(invoke(state3, 1000, 'status').value.status, 'active');

  // A lost POST reply is recovered by GET and never POSTed again.
  const state4 = await mkdtemp(join(tmpdir(), 'subscription-ledger-'));
  assert.equal(invoke(state4, 0, 'open', ['cust', 'sub-d', 'basic', '1000', '500', '2']).code, 0);
  await control({ drop_reply: true });
  assert.equal(invoke(state4, 1000, 'renew').value.error, 'service_unavailable');
  const lost = invoke(state4, 1000, 'status').value;
  const effectCount = await effects();
  await control({});
  assert.equal(invoke(state4, 1000, 'reconcile', [lost.charge_id]).value.lookup, 'paid');
  assert.equal(await effects(), effectCount);
  assert.deepEqual(await readFile(unrelated), before);

  // Downgrade persists, is idempotent, and applies its credit exactly once.
  const state5 = await mkdtemp(join(tmpdir(), 'subscription-ledger-'));
  assert.equal(invoke(state5, 0, 'open', ['cust', 'sub-e', 'pro', '2592000000', '1000', '2']).code, 0);
  const downgraded = invoke(state5, 0, 'downgrade', ['sub-e', 'basic']);
  assert.equal(downgraded.value.plan, 'basic');
  assert.equal(downgraded.value.last_plan, 'pro');
  assert.equal(downgraded.value.proration_cents, 2000);
  const beforeRepeat = await effects();
  assert.equal(invoke(state5, 0, 'downgrade', ['sub-e', 'basic']).value.proration_cents, 2000);
  assert.equal(await effects(), beforeRepeat);
  assert.equal(invoke(state5, 0, 'downgrade', ['sub-e', 'team']).value.error, 'plan_not_cheaper');
  assert.equal(invoke(state5, 0, 'downgrade', ['other-sub', 'basic']).value.error, 'subscription_mismatch');
  assert.equal(invoke(state5, 2592000000, 'renew').value.status, 'active');
  const charged = invoke(state5, 2592000000, 'status').value;
  assert.equal(charged.amount_cents, 1);
  assert.equal(charged.credit_cents, 0);
  assert.equal(charged.proration_cents, 0);
  assert.equal(charged.last_plan, 'pro');
  assert.equal((await effectRows()).at(-1).amount_cents, 1);

  // A first failure starts grace at the failure clock, extending the retry window.
  const state6 = await mkdtemp(join(tmpdir(), 'subscription-ledger-'));
  assert.equal(invoke(state6, 0, 'open', ['cust', 'sub-f', 'basic', '1000', '500', '2']).code, 0);
  await control({ error_status: 503 });
  assert.equal(invoke(state6, 1400, 'renew').value.error, 'service_unavailable');
  assert.equal(invoke(state6, 1400, 'status').value.first_failure_ms, 1400);
  await control({});
  assert.equal(invoke(state6, 1600, 'renew').value.status, 'active');
  assert.equal(invoke(state6, 1600, 'status').value.first_failure_ms, null);

  // A saved attempt without a request has no failure marker and blocks downgrade.
  const state7 = await mkdtemp(join(tmpdir(), 'subscription-ledger-'));
  assert.equal(invoke(state7, 0, 'open', ['cust', 'sub-g', 'pro', '1000', '500', '2']).code, 0);
  assert.notEqual(invoke(state7, 1000, 'renew', [], { CRASH_AT: 'after-charge-saved-before-request' }).code, 0);
  assert.equal(invoke(state7, 1000, 'status').value.first_failure_ms, null);
  assert.equal(invoke(state7, 1000, 'downgrade', ['sub-g', 'basic']).value.error, 'charge_started');

  console.log('subscription ledger tests: ok');
} finally {
  serviceProcess.kill('SIGTERM');
  await delay(50);
}
