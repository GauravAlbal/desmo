# Change: 24-hour hold cap and rush pickup

R1–R14 remain in force. `status` continues to report `rush_ms` (null until a rush). `intake` on the changed program returns `edition:"v2"` for newly bound prescriptions. This change adds a rush command and changes how a new prescription’s pickup deadline is computed.

The new command is:

`rush <rx_id>`

It is valid only for a `v2` prescription whose phase is `held`. It never contacts the provider. It sets

`pickup_deadline_ms = min(pickup_deadline_ms, NOW_MS + 3600000)`

and records `rush_ms` as that resulting deadline. Repeating `rush` when the deadline would not change returns the current result without another mutation. A `v1` prescription is refused `legacy_rx` and nothing mutates. A different `rx_id` is `rx_mismatch`. Phase not `held` on a `v2` prescription is `not_held`. Success returns `{rx_id,phase:"held",pickup_deadline_ms,rush_ms,claim}`.

Pickup-deadline computation is revised only for new (`v2`) fills. For a `v2` fill,

`pickup_deadline_ms = NOW_MS + min(hold_ms, 86400000)`.

`v1` fills keep `NOW_MS + hold_ms` with no cap. Existing persisted `v1` prescriptions acquire no new required field; `rush_ms` stays null. Rush never extends a deadline and never waives the unpaid-claim rule for pickup.

## Old-instance policy

- Hold cap: old instances continue under the original uncapped `hold_ms` (observable: a `v1` lot with `hold_ms` 172800000 remains pickupable at `NOW_MS = 86400001` after a fill at 0).
- `rush`: the new command on an old instance is refused `legacy_rx` and nothing mutates.

## Refusal precedence additions

24. `legacy_rx` on `rush` for `edition:"v1"` (after `rx_mismatch`, before `not_held`).
25. `not_held` on `rush` for `edition:"v2"` when phase is not `held`.

## C1–C5

C1. `rush` on a `v2` held lot shortens `pickup_deadline_ms` to `min(current, NOW_MS + 3600000)`, persists `rush_ms`, and creates no provider effect.

C2. Rush state survives a new process. Repeating the same rush is idempotent and does not move the deadline later. A `v1` instance or unrelated `rx_id` is refused without mutation (`legacy_rx` or `rx_mismatch`).

C3. A first `v2` fill caps the hold at 86400000 milliseconds: a clock past 24 hours but before a larger original `hold_ms` returns `pickup_lapsed` without a provider call. A `v1` instance with the same `hold_ms` remains pickupable at that clock under the original uncapped deadline.

C4. Rush does not waive payment: pickup before the rushed deadline still requires `accepted` or `cash`. After an accepted claim, pickup before the rushed deadline succeeds and updates `remaining_qty`.

C5. Rush records respect the saved-claim crash boundaries: after a saved-attempt crash or dropped reply, the same claim id and amount are recovered by lookup/retry, rush cannot erase them, and no second provider effect is created.
