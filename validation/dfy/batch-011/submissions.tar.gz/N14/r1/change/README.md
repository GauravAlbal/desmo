# Pharmacy prescription refill desk

Durable one-prescription desk using the shipped Ikaros runtime.

## Setup

```bash
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
chmod +x run
```

Node 22 is only needed for the fake claims stub: `node stub/server.mjs` (prints `{service_url, control_url}`).

## Run

```bash
export STATE_DIR=/tmp/rx-desk
export SERVICE_URL=http://127.0.0.1:PORT
export NOW_MS=0
./run intake rx1 pat1 12345-1234-12 30 1 3600000
./run verify rx1
./run fill rx1 30
./run rush rx1
./run claim
./run pickup
./run status
```

Optional: `CRASH_AT=after-claim-saved-before-request|after-accept-before-record|after-record-before-exit`

## Tests

```bash
IK_BINARY="$PWD/KIT/bin/ik" .venv/bin/python tests/test_desk.py
```
