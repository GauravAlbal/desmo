#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import tempfile
import time
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NODE = os.environ.get("NODE", "<home>/.nvm/versions/node/v22.17.1/bin/node")
RUN = str(ROOT / "run")


def start_stub():
    proc = subprocess.Popen(
        [NODE, str(ROOT / "stub" / "server.mjs")],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    line = proc.stdout.readline()
    info = json.loads(line)
    return proc, info["service_url"], info["control_url"]


def http_json(method, url, payload=None):
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["content-type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode("utf-8"))


class DeskTest(unittest.TestCase):
    def setUp(self):
        self.td = tempfile.mkdtemp()
        self.state = os.path.join(self.td, "state")
        os.makedirs(self.state)
        self.stub, self.service, self.control = start_stub()
        self.env = os.environ.copy()
        self.env["STATE_DIR"] = self.state
        self.env["SERVICE_URL"] = self.service
        self.env["NOW_MS"] = "1000"
        self.env["IK_BINARY"] = str(ROOT / "KIT" / "bin" / "ik")
        foreign = os.path.join(self.state, "keep_me.txt")
        with open(foreign, "wb") as fh:
            fh.write(b"foreign-bytes-v1")
        self.foreign = foreign
        self.foreign_bytes = b"foreign-bytes-v1"

    def tearDown(self):
        self.stub.send_signal(signal.SIGTERM)
        try:
            self.stub.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.stub.kill()
        shutil.rmtree(self.td, ignore_errors=True)

    def run_cmd(self, *args, crash=None, now=None, expect_signal=False):
        env = self.env.copy()
        if crash:
            env["CRASH_AT"] = crash
        if now is not None:
            env["NOW_MS"] = str(now)
        proc = subprocess.run(
            [RUN, *args],
            env=env,
            capture_output=True,
            text=True,
        )
        if expect_signal:
            self.assertNotEqual(proc.returncode, 0)
            return proc
        self.assertTrue(proc.stdout.endswith("\n") or proc.stdout == "")
        lines = [ln for ln in proc.stdout.splitlines() if ln.strip()]
        self.assertEqual(len(lines), 1, proc.stdout + proc.stderr)
        body = json.loads(lines[0])
        return proc.returncode, body

    def ok(self, *args, **kw):
        code, body = self.run_cmd(*args, **kw)
        self.assertEqual(code, 0, body)
        return body

    def refuse(self, error, *args, **kw):
        code, body = self.run_cmd(*args, **kw)
        self.assertNotEqual(code, 0)
        self.assertEqual(body, {"error": error})
        return body

    def effects(self):
        return http_json("GET", self.control + "/effects")["count"]

    def posts(self):
        return http_json("GET", self.control + "/posts")["count"]

    def fault(self, **kw):
        http_json("POST", self.control + "/fault", kw)

    def test_empty_status_and_foreign_file(self):
        body = self.ok("status")
        self.assertEqual(body["phase"], "none")
        self.assertEqual(body["edition"], None)
        self.refuse("not_open", "verify", "rx1")
        with open(self.foreign, "rb") as fh:
            self.assertEqual(fh.read(), self.foreign_bytes)

    def test_bad_env_precedence(self):
        env = self.env.copy()
        env.pop("NOW_MS", None)
        env.pop("SERVICE_URL", None)
        proc = subprocess.run([RUN, "status"], env=env, capture_output=True, text=True)
        self.assertNotEqual(proc.returncode, 0)
        self.assertEqual(json.loads(proc.stdout), {"error": "bad_time"})

    def test_intake_verify_fill_claim_pickup_restart(self):
        body = self.ok("intake", "rx1", "pat1", "11111-2222-33", "10", "1", "5000")
        self.assertEqual(body["phase"], "intake")
        self.assertEqual(body["remaining_qty"], 10)
        self.refuse("already_bound", "intake", "x", "y", "z", "1", "0", "0")
        self.ok("verify", "rx1")
        self.ok("verify", "rx1")
        fill = self.ok("fill", "rx1", "4")
        self.assertEqual(fill["remaining_qty"], 6)
        self.assertEqual(fill["phase"], "held")
        claimed = self.ok("claim")
        self.assertEqual(claimed["claim"], "accepted")
        self.assertEqual(self.effects(), 1)
        again = self.ok("claim")
        self.assertEqual(again["claim_id"], claimed["claim_id"])
        self.assertEqual(self.effects(), 1)
        picked = self.ok("pickup")
        self.assertEqual(picked["remaining_qty"], 6)
        self.assertEqual(picked["phase"], "verified")
        st = self.ok("status")
        self.assertEqual(st["phase"], "verified")
        self.assertEqual(st["remaining_qty"], 6)
        with open(self.foreign, "rb") as fh:
            self.assertEqual(fh.read(), self.foreign_bytes)

    def test_fill_refusals(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "5", "0", "1000")
        self.refuse("not_verified", "fill", "rx1", "1")
        self.ok("verify", "rx1")
        self.refuse("bad_units", "fill", "rx1", "9")
        self.ok("fill", "rx1", "5")
        self.refuse("already_held", "fill", "rx1", "1")
        self.ok("claim")
        self.ok("pickup")
        self.refuse("rx_complete", "fill", "rx1", "1")

    def test_unpaid_and_lapse(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "8", "0", "10")
        self.ok("verify", "rx1")
        self.ok("fill", "rx1", "3")
        self.refuse("unpaid", "pickup")
        self.refuse("pickup_lapsed", "pickup", now=20000)
        st = self.ok("status")
        self.assertEqual(st["phase"], "verified")
        self.assertEqual(st["remaining_qty"], 8)

    def test_cash_pay_and_deny(self):
        self.ok("intake", "rx1", "pat1", "DENYALL", "2", "0", "5000")
        self.ok("verify", "rx1")
        self.ok("fill", "rx1", "2")
        self.refuse("not_rejected", "cash-pay")
        denied = self.ok("claim")
        self.assertEqual(denied["claim"], "rejected")
        self.assertEqual(self.effects(), 0)
        cash = self.ok("cash-pay")
        self.assertEqual(cash["claim"], "cash")
        self.assertEqual(cash["payor"], "cash")
        self.assertEqual(self.effects(), 1)
        self.refuse("cash_used", "cash-pay")
        picked = self.ok("pickup")
        self.assertEqual(picked["phase"], "dispensed")

    def test_notice_ignored(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "2", "0", "5000")
        self.ok("verify", "rx1")
        self.ok("fill", "rx1", "2")
        npath = os.path.join(self.td, "n.json")
        with open(npath, "w") as fh:
            json.dump({"notice_id": "n1", "kind": "cancel"}, fh)
        self.ok("notice", npath)
        st = self.ok("status")
        self.assertEqual(st["phase"], "held")
        self.assertEqual(self.effects(), 0)
        with open(npath, "w") as fh:
            fh.write("{")
        self.refuse("bad_notice", "notice", npath)

    def test_crash_before_request(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "2", "0", "5000")
        self.ok("verify", "rx1")
        self.ok("fill", "rx1", "2")
        crashed = self.run_cmd("claim", crash="after-claim-saved-before-request", expect_signal=True)
        self.assertTrue(crashed.returncode < 0 or crashed.returncode == 137)
        st = self.ok("status")
        self.assertEqual(st["claim"], "saved")
        self.assertEqual(self.effects(), 0)
        cid = st["claim_id"]
        claimed = self.ok("claim")
        self.assertEqual(claimed["claim"], "accepted")
        self.assertEqual(claimed["claim_id"], cid)
        self.assertEqual(self.effects(), 1)

    def test_crash_after_accept_before_record(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "2", "0", "5000")
        self.ok("verify", "rx1")
        self.ok("fill", "rx1", "2")
        self.run_cmd("claim", crash="after-accept-before-record", expect_signal=True)
        st = self.ok("status")
        self.assertEqual(st["claim"], "saved")
        self.assertEqual(self.effects(), 1)
        claimed = self.ok("claim")
        self.assertEqual(claimed["claim"], "accepted")
        self.assertEqual(self.effects(), 1)

    def test_crash_after_record(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "2", "0", "5000")
        self.ok("verify", "rx1")
        self.ok("fill", "rx1", "2")
        self.run_cmd("claim", crash="after-record-before-exit", expect_signal=True)
        st = self.ok("status")
        self.assertEqual(st["claim"], "accepted")
        again = self.ok("claim")
        self.assertEqual(again["claim"], "accepted")
        rec = self.ok("reconcile", st["claim_id"])
        self.assertEqual(rec["lookup"], "accepted")

    def test_dropped_reply_then_reconcile(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "2", "0", "5000")
        self.ok("verify", "rx1")
        self.ok("fill", "rx1", "2")
        self.fault(drop_reply=True)
        code, body = self.run_cmd("claim")
        self.assertNotEqual(code, 0)
        self.assertEqual(body["error"], "service_unavailable")
        st = self.ok("status")
        self.assertEqual(st["claim"], "saved")
        self.assertEqual(self.effects(), 1)
        self.fault(drop_reply=False)
        rec = self.ok("reconcile", st["claim_id"])
        self.assertEqual(rec["lookup"], "accepted")
        self.assertEqual(rec["claim"], "accepted")
        self.assertEqual(self.effects(), 1)
        self.refuse("claim_mismatch", "reconcile", "nope")

    def test_reconcile_not_sent(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "2", "0", "5000")
        self.ok("verify", "rx1")
        self.ok("fill", "rx1", "2")
        self.run_cmd("claim", crash="after-claim-saved-before-request", expect_signal=True)
        st = self.ok("status")
        rec = self.ok("reconcile", st["claim_id"])
        self.assertEqual(rec["lookup"], "not_sent")
        self.assertEqual(self.posts(), 0)

    def test_corrupt_state(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "2", "0", "5000")
        store = os.path.join(self.state, "ikaros.sqlite")
        with open(store, "wb") as fh:
            fh.write(b"not-a-store")
        self.refuse("corrupt_state", "status")

    def test_intake_is_v2(self):
        body = self.ok("intake", "rx1", "pat1", "11111-2222-33", "10", "1", "5000")
        self.assertEqual(body["edition"], "v2")
        st = self.ok("status")
        self.assertEqual(st["edition"], "v2")
        self.assertIsNone(st["rush_ms"])

    def test_v2_hold_cap_and_rush(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "8", "0", "172800000")
        self.ok("verify", "rx1")
        self.refuse("not_held", "rush", "rx1", now=0)
        fill = self.ok("fill", "rx1", "3", now=0)
        self.assertEqual(fill["pickup_deadline_ms"], 86400000)
        self.refuse("unpaid", "pickup", now=1000)
        rushed = self.ok("rush", "rx1", now=1000)
        self.assertEqual(rushed["phase"], "held")
        self.assertEqual(rushed["pickup_deadline_ms"], 3601000)
        self.assertEqual(rushed["rush_ms"], 3601000)
        self.assertEqual(self.effects(), 0)
        again = self.ok("rush", "rx1", now=1000)
        self.assertEqual(again["pickup_deadline_ms"], 3601000)
        later = self.ok("rush", "rx1", now=2000)
        self.assertEqual(later["pickup_deadline_ms"], 3601000)
        self.refuse("rx_mismatch", "rush", "other", now=1000)
        st = self.ok("status", now=1000)
        self.assertEqual(st["rush_ms"], 3601000)
        self.refuse("pickup_lapsed", "pickup", now=86400001)
        st2 = self.ok("status", now=86400001)
        self.assertEqual(st2["phase"], "verified")
        self.assertEqual(st2["remaining_qty"], 8)

    def test_rush_does_not_waive_payment(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "4", "0", "86400000")
        self.ok("verify", "rx1")
        self.ok("fill", "rx1", "2", now=0)
        self.ok("rush", "rx1", now=0)
        self.refuse("unpaid", "pickup", now=1000)
        claimed = self.ok("claim")
        self.assertEqual(claimed["claim"], "accepted")
        picked = self.ok("pickup", now=1000)
        self.assertEqual(picked["remaining_qty"], 2)
        self.assertEqual(picked["phase"], "verified")

    def test_rush_survives_claim_crash(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "2", "0", "86400000")
        self.ok("verify", "rx1")
        self.ok("fill", "rx1", "2", now=0)
        self.ok("rush", "rx1", now=0)
        self.run_cmd("claim", crash="after-claim-saved-before-request", expect_signal=True)
        st = self.ok("status")
        self.assertEqual(st["claim"], "saved")
        self.assertEqual(st["rush_ms"], 3600000)
        cid = st["claim_id"]
        claimed = self.ok("claim")
        self.assertEqual(claimed["claim_id"], cid)
        self.assertEqual(self.effects(), 1)
        st2 = self.ok("status")
        self.assertEqual(st2["rush_ms"], 3600000)

    def test_legacy_v1_continuity(self):
        old_run = "/tmp/rx_desk_prechange_N14r1/run"
        env = self.env.copy()
        env["NOW_MS"] = "0"
        subprocess.run(
            [old_run, "intake", "rx1", "pat1", "11111-2222-33", "8", "0", "172800000"],
            env=env,
            check=True,
            capture_output=True,
            text=True,
        )
        subprocess.run([old_run, "verify", "rx1"], env=env, check=True, capture_output=True, text=True)
        subprocess.run([old_run, "fill", "rx1", "3"], env=env, check=True, capture_output=True, text=True)
        st = self.ok("status", now=0)
        self.assertEqual(st["edition"], "v1")
        self.assertIsNone(st["rush_ms"])
        self.assertEqual(st["pickup_deadline_ms"], 172800000)
        self.refuse("legacy_rx", "rush", "rx1", now=1000)
        st2 = self.ok("status", now=1000)
        self.assertEqual(st2["pickup_deadline_ms"], 172800000)
        self.ok("claim", now=1000)
        picked = self.ok("pickup", now=86400001)
        self.assertEqual(picked["phase"], "verified")

    def test_refill_cycle(self):
        self.ok("intake", "rx1", "pat1", "11111-2222-33", "2", "1", "5000")
        self.ok("verify", "rx1")
        self.ok("fill", "rx1", "2")
        self.ok("claim")
        picked = self.ok("pickup")
        self.assertEqual(picked["remaining_qty"], 2)
        self.assertEqual(picked["refills"], 0)
        self.assertEqual(picked["phase"], "verified")


if __name__ == "__main__":
    unittest.main()
