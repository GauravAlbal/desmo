# Pharmacy prescription refill desk

The program behind `./run` is a durable local desk for one prescription. It records an intake, pharmacist verification, a fill lot (full or partial), an insurer claim against an external claims API, an optional one-time cash-pay after a rejected claim, and a pickup whose deadline is driven by `NOW_MS`. A claim has an application-created id saved before the request; recovery looks up that id before any retry.

## Scope and invocation

One machine and one process at a time. One prescription is bound to a state directory. An unrelated writer may create or modify other files in `STATE_DIR`; those files must survive byte-for-byte. The tool may keep its durable files in `STATE_DIR` under any names. It must use `STATE_DIR`, `SERVICE_URL`, `NOW_MS`, and optional `CRASH_AT`. `SERVICE_URL` is required for every command, including status (status never contacts it). `NOW_MS` is a required non-negative integer epoch-millisecond clock for every command.

`./run <command> [args]` prints exactly one JSON object and nothing else (one trailing newline is allowed). Exit 0 is success. Refusals are nonzero and print `{ "error": "<code>" }`. Identifiers (`rx_id`, `patient_id`, `ndc`, `claim_id`, `notice_id`) are 1–64 characters matching `A-Za-z0-9._-`. `qty` is an integer from 1 through 999. `refills` is an integer from 0 through 11. `hold_ms` is an integer from 0 through 2592000000. `units` is an integer from 1 through 999. Amounts are canonical non-negative decimal integers in cents: `amount_cents` for a lot is exactly `units * 175`. `CRASH_AT` labels are:

* `after-claim-saved-before-request`: after saving a claim id and claim snapshot, before sending a request;
* `after-accept-before-record`: after reading a complete successful provider response with `outcome:"accepted"`, before saving the accepted record;
* `after-record-before-exit`: after saving the accepted or cash record, before success JSON is written.

A process must kill itself with SIGKILL at a reached label. Durable commits are flushed before the command treats them as committed. A malformed owned state file is `corrupt_state` and is not rewritten. Refusals do not modify state except that a held unpaid lot whose `NOW_MS` is strictly greater than `pickup_deadline_ms` is durably returned to remaining quantity when `pickup` runs.

Missing or non-integer `NOW_MS` is `bad_time`. Missing `SERVICE_URL` is `bad_args`. `bad_time` wins if both are missing.

## Commands

Any command other than `intake` or `status` on an empty store is `not_open`.

`intake <rx_id> <patient_id> <ndc> <qty> <refills> <hold_ms>` binds the empty store. It returns `{rx_id,patient_id,ndc,qty,remaining_qty,refills,hold_ms,phase:"intake",claim:"none",claim_id:null,edition:"v1"}`. `remaining_qty` equals `qty`. A second intake is `already_bound`. Malformed identifiers are `bad_args`; malformed `qty` is `bad_qty`; malformed `refills` is `bad_refills`; malformed `hold_ms` is `bad_hold`. Intake never contacts the provider.

`verify <rx_id>` is allowed in `intake` or `verified`. It returns `{rx_id,phase:"verified"}` and never contacts the provider. Repeating verify in `verified` is a success no-op. A different `rx_id` is `rx_mismatch`. Any later phase is `already_moved`.

`fill <rx_id> <units>` is allowed in `verified` with `remaining_qty > 0`. `units` must be an integer from 1 through `remaining_qty`. It deducts `units` from `remaining_qty`, sets `held_units` to `units`, sets `pickup_deadline_ms` to `NOW_MS + hold_ms`, sets `phase` to `held`, and returns `{rx_id,units,remaining_qty,held_units,phase:"held",pickup_deadline_ms,claim:"none"}`. It never contacts the provider. A different `rx_id` is `rx_mismatch`. Phase `intake` is `not_verified`. Phase `held` is `already_held`. `remaining_qty == 0` is `rx_complete`. Out-of-range `units` is `bad_units`.

`claim` submits an insurer claim for the current held lot. Before a saved id exists it generates a claim id, saves the exact snapshot `{claim_id,rx_id,ndc,units:held_units,amount_cents:held_units*175,payor:"insurer"}`, sets `claim:"saved"`, then posts once. A matching `outcome:"accepted"` response returns `{rx_id,claim_id,units,amount_cents,payor:"insurer",claim:"accepted",phase:"held"}`. A matching `outcome:"rejected"` response (including NDC `DENYALL`) returns `{rx_id,claim_id,units,amount_cents,payor:"insurer",claim:"rejected",phase:"held"}` with exit 0 and does not count as an accepted provider effect. Repeating `claim` after `accepted` or `rejected` or `cash` is a success no-op without a provider call. Phase not `held` is `not_held` without a provider call.

If a saved attempt exists, `claim` first `GET /v1/claims/<claim_id>`: a matching 200 with `outcome:"accepted"` or `outcome:"rejected"` is adopted without POST; a 404 causes one POST with the saved id only. Never allocate a replacement id. A mismatching success is `lookup_conflict` and changes nothing. An incomplete response, connection failure, or HTTP 5xx leaves `claim:"saved"` and returns `service_unavailable`.

`cash-pay` is allowed only when `claim` is `rejected` and phase is `held`. It generates a new claim id, saves a snapshot with `payor:"cash"` and the same units and amount, then posts once using the same crash labels. Success returns `{rx_id,claim_id,units,amount_cents,payor:"cash",claim:"cash",phase:"held"}`. A second cash-pay is `cash_used`. Any other claim state is `not_rejected`. Phase not `held` is `not_held`. Cash-pay never reuses the insurer claim id.

`pickup` is allowed in `held`. If `NOW_MS > pickup_deadline_ms` and `claim` is not `accepted` and not `cash`, it durably adds `held_units` back to `remaining_qty`, clears the lot (`held_units:0`, `pickup_deadline_ms:null`, `phase:"verified"`), and returns `pickup_lapsed`. If the deadline has passed and `claim` is `accepted` or `cash`, it durably sets `phase:"lapsed"` without restoring quantity and returns `pickup_lapsed`. If the lot is on time and `claim` is not `accepted` and not `cash`, it returns `unpaid` and changes nothing. An on-time paid or cash lot clears the lot and returns `{rx_id,units,remaining_qty,refills,phase}` where `units` is the picked `held_units`. After a successful pickup: if `remaining_qty > 0`, `phase` is `verified`; if `remaining_qty == 0` and `refills > 0`, `refills` decreases by one, `remaining_qty` becomes `qty`, and `phase` is `verified`; if `remaining_qty == 0` and `refills == 0`, `phase` is `dispensed`. Pickup never contacts the provider. Phase not `held` is `not_held`.

`reconcile <claim_id>` never POSTs or allocates. No saved claim is `no_claim`; another id is `claim_mismatch`. Lookup 200 with matching ids, ndc, units, amount, and `outcome:"accepted"` commits accepted state and returns the accepted success object plus `lookup:"accepted"`; matching `outcome:"rejected"` commits rejected state and returns the rejected success object plus `lookup:"rejected"`; 404 returns exit 0 `{lookup:"not_sent",rx_id,claim_id,claim:"saved",phase:"held"}`; a mismatch is `lookup_conflict`; transport failure is `service_unavailable`.

`status` never contacts the provider and returns `{rx_id,patient_id,ndc,qty,remaining_qty,refills,hold_ms,held_units,pickup_deadline_ms,phase,claim,claim_id,amount_cents,payor,units,edition,rush_ms}`. Empty fields are null, with `remaining_qty:0`, `refills:0`, `held_units:0`, `phase:"none"`, `claim:"none"`, `edition:null`, `rush_ms:null`.

`notice <path>` reads one JSON notice `{notice_id,kind}` with both fields strings. It must not POST or allocate. A malformed notice is `bad_notice`; a well-formed notice may be ignored. It must never overwrite `held`, `dispensed`, or `lapsed` state.

## Refusal precedence

When more than one refusal applies, the first matching row wins. Environment codes are decided before command codes.

1. `corrupt_state` if an owned state file exists and is not valid JSON object state.
2. `bad_time` if `NOW_MS` is missing or not a canonical non-negative integer.
3. `bad_args` if `SERVICE_URL` is missing.
4. `bad_args` if the command name is unknown or required arguments are missing.
5. `already_bound` on a second `intake` (arguments of the second call are not re-validated).
6. `not_open` on any command other than `intake` or `status` when no prescription is bound. Status on an empty store is the null success object, not `not_open`.
7. `rx_mismatch` when a command carries `rx_id` and it does not equal the bound id.
8. `not_verified` on `fill` from `intake`.
9. `already_held` on `fill` from `held`.
10. `already_moved` on `verify` from `held`, `dispensed`, or `lapsed`.
11. `rx_complete` on `fill` when `remaining_qty == 0`.
12. `bad_units` on `fill` when `units` is malformed or outside `1..remaining_qty`.
13. `not_held` on `claim`, `cash-pay`, or `pickup` when phase is not `held`.
14. `pickup_lapsed` on `pickup` when `NOW_MS > pickup_deadline_ms` (checked before `unpaid`).
15. `unpaid` on `pickup` when the lot is on time and `claim` is not `accepted` and not `cash`.
16. `not_rejected` on `cash-pay` when `claim` is not `rejected`.
17. `cash_used` on `cash-pay` when `claim` is already `cash`.
18. `no_claim` on `reconcile` when no claim id is saved.
19. `claim_mismatch` on `reconcile` when the argument is not the saved id.
20. `lookup_conflict` on a mismatching provider success body.
21. `service_unavailable` on transport failure, incomplete response, or HTTP 5xx.
22. `bad_notice` on a malformed notice file.
23. `bad_qty`, `bad_refills`, `bad_hold`, `bad_args` on a first `intake` with malformed fields, in that order after identifier `bad_args`.

## Provider

The supplied service has `POST /v1/claims` and `GET /v1/claims/<claim_id>`. POST requires JSON with `claim_id`, `rx_id`, `ndc`, integer `units`, integer `amount_cents`, and `payor` exactly `insurer` or `cash`. A first valid claim id records one accepted effect when the outcome is accepted and returns HTTP 200 with those fields plus `outcome:"accepted"`. NDC `DENYALL` with `payor:"insurer"` returns HTTP 200 with `outcome:"rejected"` and does not record an accepted effect; GET still finds that rejected body. Repeating the same claim id and identical fields returns the same object without another accepted effect; any differing field is HTTP 409. Unknown lookup is 404. The provider may drop a reply after accepting, hold a reply, or return 5xx without storing. Control endpoints are not part of this contract.

## Requirements

R1. Intake and every later committed record survive new processes, including a claim attempt killed at `after-claim-saved-before-request`.

R2. Intake validates `rx_id`, `patient_id`, `ndc`, `qty`, `refills`, and `hold_ms`, binds one prescription, and does not contact the provider.

R3. A verified prescription makes legitimate fill progress: a partial fill deducts `units` from `remaining_qty` and leaves phase `held`; fill before verify is `not_verified` without mutation.

R4. Pickup of an on-time lot requires `claim` `accepted` or `cash`. An unpaid lot past `pickup_deadline_ms` returns `pickup_lapsed` and restores `remaining_qty`. After a successful full-cycle pickup with remaining refills, `remaining_qty` returns to `qty` and `refills` decreases by one. A dispensed prescription cannot be filled (`rx_complete`).

R5. A healthy provider permits an insurer claim and exactly one accepted external effect; repeating `claim` is a no-op and does not add an effect. `cash-pay` before a rejected claim is `not_rejected` and adds no effect.

R6. Notice files never overwrite local `held`/`dispensed`/`lapsed` outcomes and never cause provider effects.

R7. Fill above remaining quantity, pickup while unpaid and on time, or `claim` while not `held` is refused without contacting the provider.

R8. A crash before POST leaves one saved claim id and zero accepted effects; a later `claim` POSTs that same id and ends `accepted` exactly once.

R9. A crash after provider acceptance leaves `claim:"saved"` locally and one provider effect; later `claim` adopts by lookup without a second effect.

R10. A crash after the durable accepted record leaves accepted state and later `claim` is a no-op; reconcile can likewise survive its record-before-exit crash.

R11. A dropped accepted reply yields `service_unavailable` and `claim:"saved"`; following reconcile adopts `accepted` by lookup, never reports `not_sent`, and never posts again.

R12. Reconcile never POSTs: a saved-but-unaccepted id returns `not_sent` with `claim:"saved"`; a wrong id is `claim_mismatch` and leaves state unchanged.

R13. Unrelated files in STATE_DIR retain identical bytes through commits and refusals.

R14. Every invocation emits one JSON object; status on empty is the null shape; missing `SERVICE_URL` or `NOW_MS` is a refusal; the first intake binds the only prescription and no command can fill another.
