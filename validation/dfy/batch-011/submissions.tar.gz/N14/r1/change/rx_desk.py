from __future__ import annotations

import hashlib
import json
import os
import re
import signal
import sys
import uuid
from typing import Any, Dict, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from invariant_kernel import (
    HistoricalResult,
    Kernel,
    StoreNotFoundError,
    classify,
)

AGG = "desk"
ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
TIME_RE = re.compile(r"^(0|[1-9][0-9]*)$")
HOLD_MAX = 2592000000
HOLD_CAP_MS = 86400000
RUSH_WINDOW_MS = 3600000
STORE_NAME = "ikaros.sqlite"


def _root() -> str:
    return os.path.dirname(os.path.abspath(__file__))


def _machine_path_v1() -> str:
    return os.path.join(_root(), "machines", "rx_desk.ik.toml")


def _machine_path_v2() -> str:
    return os.path.join(_root(), "machines", "rx_desk_v2.ik.toml")


def _store_path() -> str:
    return os.path.join(os.environ["STATE_DIR"], STORE_NAME)


def emit(obj: Any, code: int = 0) -> int:
    sys.stdout.write(json.dumps(obj, separators=(",", ":")) + "\n")
    return code


def err(code: str) -> int:
    return emit({"error": code}, 1)


def crash_if(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


def canon_nn_int(raw: Optional[str]) -> Optional[int]:
    if raw is None or not TIME_RE.fullmatch(raw):
        return None
    return int(raw)


def parse_range(raw: Optional[str], lo: int, hi: int) -> Optional[int]:
    n = canon_nn_int(raw)
    if n is None or n < lo or n > hi:
        return None
    return n


def ident(raw: Optional[str]) -> bool:
    return bool(raw and ID_RE.fullmatch(raw))


def empty_status() -> Dict[str, Any]:
    return {
        "rx_id": None,
        "patient_id": None,
        "ndc": None,
        "qty": None,
        "remaining_qty": 0,
        "refills": 0,
        "hold_ms": None,
        "held_units": 0,
        "pickup_deadline_ms": None,
        "phase": "none",
        "claim": "none",
        "claim_id": None,
        "amount_cents": None,
        "payor": None,
        "units": None,
        "edition": None,
        "rush_ms": None,
    }


def fact(agg: Any, name: str, default: Any = None) -> Any:
    facts = agg.facts or {}
    if name not in facts:
        return default
    val = facts[name]
    if isinstance(val, dict) and "value" in val:
        return val["value"]
    return val


def snap_from(agg: Any) -> Dict[str, Any]:
    claim_id = fact(agg, "claim_id")
    payor = fact(agg, "payor", "none")
    amount = fact(agg, "amount_cents", 0)
    units = fact(agg, "lot_units", 0)
    deadline = fact(agg, "pickup_deadline_ms", 0)
    return {
        "rx_id": fact(agg, "rx_id"),
        "patient_id": fact(agg, "patient_id"),
        "ndc": fact(agg, "ndc"),
        "qty": fact(agg, "qty"),
        "remaining_qty": fact(agg, "remaining_qty", 0),
        "refills": fact(agg, "refills", 0),
        "hold_ms": fact(agg, "hold_ms"),
        "held_units": fact(agg, "held_units", 0),
        "pickup_deadline_ms": None if not deadline else deadline,
        "phase": agg.state,
        "claim": fact(agg, "claim", "none"),
        "claim_id": claim_id or None,
        "amount_cents": None if fact(agg, "claim", "none") == "none" and not units else amount,
        "payor": None if not payor or payor == "none" else payor,
        "units": None if not units else units,
        "edition": fact(agg, "edition", "v1"),
        "rush_ms": None if not fact(agg, "rush_ms", 0) else fact(agg, "rush_ms"),
    }


def payload_digest(body: Dict[str, Any]) -> str:
    blob = json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def outcome_digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def current_snapshot(agg: Any) -> Dict[str, Any]:
    units = int(fact(agg, "held_units") or 0)
    return {
        "claim_id": fact(agg, "claim_id"),
        "rx_id": fact(agg, "rx_id"),
        "ndc": fact(agg, "ndc"),
        "units": units,
        "amount_cents": units * 175,
        "payor": fact(agg, "payor"),
    }


def bodies_match(body: Any, snap: Dict[str, Any]) -> bool:
    if not isinstance(body, dict):
        return False
    try:
        units = int(body.get("units"))
        amount = int(body.get("amount_cents"))
    except (TypeError, ValueError):
        return False
    return (
        body.get("claim_id") == snap["claim_id"]
        and body.get("rx_id") == snap["rx_id"]
        and body.get("ndc") == snap["ndc"]
        and units == snap["units"]
        and amount == snap["amount_cents"]
        and body.get("payor") == snap["payor"]
        and body.get("outcome") in ("accepted", "rejected")
    )


def http_json(method: str, url: str, payload: Optional[Dict[str, Any]] = None) -> Tuple[str, int, Optional[bytes], Any]:
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["content-type"] = "application/json"
    req = Request(url, data=data, method=method, headers=headers)
    try:
        with urlopen(req, timeout=8) as resp:
            raw = resp.read()
            status = getattr(resp, "status", 200)
            if not raw:
                return ("incomplete", status, raw, None)
            try:
                parsed = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, ValueError):
                return ("incomplete", status, raw, None)
            return ("ok", status, raw, parsed)
    except HTTPError as exc:
        raw = exc.read() if exc.fp is not None else b""
        parsed = None
        if raw:
            try:
                parsed = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, ValueError):
                parsed = None
        if exc.code >= 500:
            return ("unavailable", exc.code, raw, parsed)
        return ("http", exc.code, raw, parsed)
    except (URLError, TimeoutError, ValueError, OSError):
        return ("unavailable", 0, None, None)


def open_kernel(create: bool = False):
    store = _store_path()
    if not os.path.isfile(store):
        if not create:
            return None, None, None
        os.makedirs(os.environ["STATE_DIR"], exist_ok=True)
    try:
        kernel = Kernel(store)
        machines = {
            1: kernel.machine(_machine_path_v1()),
            2: kernel.machine(_machine_path_v2()),
        }
        return kernel, machines, None
    except StoreNotFoundError:
        if create:
            raise
        return None, None, None
    except Exception as exc:
        cls = classify(exc)
        if cls == "corrupt":
            return None, None, "corrupt_state"
        if isinstance(exc, StoreNotFoundError) or cls == "not_found":
            return None, None, None
        return None, None, "corrupt_state"


def _route_machine(machines, probe):
    owner = probe.owner
    for machine in machines.values():
        if machine.identity == owner:
            return machine
    return machines[2]


def load_agg(create: bool = False):
    kernel, machines, problem = open_kernel(create=create)
    if problem:
        return None, None, None, problem
    if machines is None:
        return None, None, None, None
    try:
        try:
            probe = kernel.show(AGG, machine=machines[2])
        except Exception:
            probe = kernel.show(AGG, machine=machines[1])
        machine = _route_machine(machines, probe)
        agg = machine.show(AGG)
        return kernel, machine, agg, None
    except Exception as exc:
        cls = classify(exc)
        if cls == "corrupt":
            return None, None, None, "corrupt_state"
        if cls in ("not_found",) or isinstance(exc, StoreNotFoundError):
            return kernel, machines[2], None, None
        msg = str(exc)
        if "not_found" in msg or "aggregate" in msg.lower():
            return kernel, machines[2], None, None
        return None, None, None, "corrupt_state"


def as_agg(result: Any):
    if isinstance(result, HistoricalResult):
        _k, _m, agg, problem = load_agg()
        if problem:
            raise RuntimeError(problem)
        return agg
    return result


def env_preflight(argv) -> Optional[int]:
    now_raw = os.environ.get("NOW_MS")
    svc = os.environ.get("SERVICE_URL")
    if canon_nn_int(now_raw) is None:
        return err("bad_time")
    if not svc:
        return err("bad_args")
    if not argv:
        return err("bad_args")
    return None


def cmd_intake(args):
    _k, _m, agg, problem = load_agg()
    if problem:
        return err(problem)
    if len(args) < 6:
        return err("bad_args")
    if agg is not None:
        return err("already_bound")
    rx_id, patient_id, ndc, qty_s, refills_s, hold_s = args[:6]
    if not ident(rx_id) or not ident(patient_id) or not ident(ndc):
        return err("bad_args")
    qty = parse_range(qty_s, 1, 999)
    if qty is None:
        return err("bad_qty")
    refills = parse_range(refills_s, 0, 11)
    if refills is None:
        return err("bad_refills")
    hold_ms = parse_range(hold_s, 0, HOLD_MAX)
    if hold_ms is None:
        return err("bad_hold")
    kernel, machine, _agg, problem = load_agg(create=True)
    if problem:
        return err(problem)
    created = machine.create_with(
        AGG,
        {
            "name": "bind",
            "args": {
                "rx_id": rx_id,
                "patient_id": patient_id,
                "ndc": ndc,
                "qty": qty,
                "refills": refills,
                "hold_ms": hold_ms,
                "claim": "none",
                "payor": "none",
                "edition": "v2",
            },
        },
    )
    created = as_agg(created)
    return emit(
        {
            "rx_id": rx_id,
            "patient_id": patient_id,
            "ndc": ndc,
            "qty": qty,
            "remaining_qty": qty,
            "refills": refills,
            "hold_ms": hold_ms,
            "phase": "intake",
            "claim": "none",
            "claim_id": None,
            "edition": "v2",
        }
    )


def cmd_status(_args):
    _k, _m, agg, problem = load_agg()
    if problem:
        return err(problem)
    if agg is None:
        return emit(empty_status())
    return emit(snap_from(agg))


def cmd_verify(args):
    if not args:
        return err("bad_args")
    _k, _m, agg, problem = load_agg()
    if problem:
        return err(problem)
    if agg is None:
        return err("not_open")
    rx_id = args[0]
    if rx_id != fact(agg, "rx_id"):
        return err("rx_mismatch")
    if agg.state in ("held", "dispensed", "lapsed"):
        return err("already_moved")
    if agg.state != "verified":
        agg = as_agg(agg.command("verify", rx_id=rx_id))
    return emit({"rx_id": rx_id, "phase": "verified"})


def cmd_fill(args):
    if len(args) < 2:
        return err("bad_args")
    _k, _m, agg, problem = load_agg()
    if problem:
        return err(problem)
    if agg is None:
        return err("not_open")
    rx_id, units_s = args[0], args[1]
    if rx_id != fact(agg, "rx_id"):
        return err("rx_mismatch")
    if agg.state == "intake":
        return err("not_verified")
    if agg.state == "held":
        return err("already_held")
    remaining = int(fact(agg, "remaining_qty") or 0)
    if remaining == 0:
        return err("rx_complete")
    units = parse_range(units_s, 1, 999)
    if units is None or units < 1 or units > remaining:
        return err("bad_units")
    if agg.state != "verified":
        return err("already_moved")
    now = int(os.environ["NOW_MS"])
    hold_ms = int(fact(agg, "hold_ms") or 0)
    if fact(agg, "edition", "v1") == "v2":
        deadline = now + min(hold_ms, HOLD_CAP_MS)
    else:
        deadline = now + hold_ms
    new_rem = remaining - units
    agg = as_agg(
        agg.command(
            "fill",
            rx_id=rx_id,
            units=units,
            remaining_qty=new_rem,
            pickup_deadline_ms=deadline,
            amount_cents=units * 175,
            claim="none",
            payor="none",
        )
    )
    return emit(
        {
            "rx_id": rx_id,
            "units": units,
            "remaining_qty": new_rem,
            "held_units": units,
            "phase": "held",
            "pickup_deadline_ms": deadline,
            "claim": "none",
        }
    )


def record_and_mark(agg: Any, raw: bytes, outcome: str) -> Any:
    intent = agg.pending_intent
    if intent is not None:
        agg = as_agg(
            agg.record_effect_outcome(outcome_digest(raw), intent=intent)
        )
    if outcome == "accepted":
        return as_agg(agg.command("mark_accepted", claim="accepted"))
    if outcome == "cash":
        return as_agg(agg.command("mark_cash", claim="cash"))
    return as_agg(agg.command("mark_rejected", claim="rejected"))


def claim_success(agg: Any) -> Dict[str, Any]:
    units = int(fact(agg, "lot_units") or fact(agg, "held_units") or 0)
    payor = fact(agg, "payor")
    claim = fact(agg, "claim")
    return {
        "rx_id": fact(agg, "rx_id"),
        "claim_id": fact(agg, "claim_id"),
        "units": units,
        "amount_cents": units * 175,
        "payor": "cash" if claim == "cash" else payor,
        "claim": claim,
        "phase": "held",
    }


def post_claim(agg: Any, snap: Dict[str, Any], cash: bool) -> int:
    crash_if("after-claim-saved-before-request")
    base = os.environ["SERVICE_URL"].rstrip("/")
    kind, status, raw, parsed = http_json("POST", base + "/v1/claims", snap)
    if kind == "unavailable" or (kind == "http" and status >= 500):
        return err("service_unavailable")
    if kind == "incomplete":
        return err("service_unavailable")
    if kind == "http":
        if status == 409:
            return err("lookup_conflict")
        return err("service_unavailable")
    if not bodies_match(parsed, snap):
        return err("lookup_conflict")
    outcome = parsed.get("outcome")
    if outcome == "accepted":
        crash_if("after-accept-before-record")
        agg = record_and_mark(agg, raw, "cash" if cash else "accepted")
        crash_if("after-record-before-exit")
        return emit(claim_success(agg))
    if outcome == "rejected":
        if cash:
            return err("lookup_conflict")
        agg = record_and_mark(agg, raw, "rejected")
        return emit(claim_success(agg))
    return err("lookup_conflict")


def adopt_lookup(agg: Any, parsed: Any, raw: bytes, snap: Dict[str, Any], cash: bool) -> int:
    if not bodies_match(parsed, snap):
        return err("lookup_conflict")
    outcome = parsed.get("outcome")
    if outcome == "accepted":
        crash_if("after-accept-before-record")
        agg = record_and_mark(agg, raw, "cash" if cash else "accepted")
        crash_if("after-record-before-exit")
        return emit(claim_success(agg))
    if outcome == "rejected":
        if cash:
            return err("lookup_conflict")
        agg = record_and_mark(agg, raw, "rejected")
        return emit(claim_success(agg))
    return err("lookup_conflict")


def cmd_claim(args):
    _k, _m, agg, problem = load_agg()
    if problem:
        return err(problem)
    if agg is None:
        return err("not_open")
    if agg.state != "held":
        return err("not_held")
    claim = fact(agg, "claim", "none")
    payor = fact(agg, "payor", "none")
    if claim in ("accepted", "rejected", "cash"):
        as_agg(agg.command("claim_idle"))
        return emit(claim_success(agg))
    if claim == "saved" and payor == "cash":
        return resume_saved(agg, cash=True)
    if claim == "none":
        units = int(fact(agg, "held_units") or 0)
        claim_id = "c" + uuid.uuid4().hex
        snap = {
            "claim_id": claim_id,
            "rx_id": fact(agg, "rx_id"),
            "ndc": fact(agg, "ndc"),
            "units": units,
            "amount_cents": units * 175,
            "payor": "insurer",
        }
        agg = as_agg(
            agg.command(
                "save_insurer",
                claim_id=claim_id,
                payload_digest=payload_digest(snap),
                units=units,
                amount_cents=units * 175,
                claim="saved",
                payor="insurer",
            )
        )
        return post_claim(agg, snap, cash=False)
    return resume_saved(agg, cash=False)


def resume_saved(agg: Any, cash: bool) -> int:
    snap = current_snapshot(agg)
    base = os.environ["SERVICE_URL"].rstrip("/")
    kind, status, raw, parsed = http_json(
        "GET", base + "/v1/claims/" + snap["claim_id"]
    )
    if kind == "unavailable":
        return err("service_unavailable")
    if kind == "incomplete":
        return err("service_unavailable")
    if kind == "ok" and status == 200:
        return adopt_lookup(agg, parsed, raw, snap, cash)
    if kind == "http" and status == 404:
        return post_claim(agg, snap, cash)
    if kind == "ok":
        return adopt_lookup(agg, parsed, raw, snap, cash)
    if status >= 500:
        return err("service_unavailable")
    return err("service_unavailable")


def cmd_cash_pay(args):
    _k, _m, agg, problem = load_agg()
    if problem:
        return err(problem)
    if agg is None:
        return err("not_open")
    if agg.state != "held":
        return err("not_held")
    claim = fact(agg, "claim", "none")
    if claim == "cash":
        return err("cash_used")
    if claim == "saved" and fact(agg, "payor") == "cash":
        return resume_saved(agg, cash=True)
    if claim != "rejected":
        return err("not_rejected")
    units = int(fact(agg, "held_units") or 0)
    claim_id = "c" + uuid.uuid4().hex
    snap = {
        "claim_id": claim_id,
        "rx_id": fact(agg, "rx_id"),
        "ndc": fact(agg, "ndc"),
        "units": units,
        "amount_cents": units * 175,
        "payor": "cash",
    }
    agg = as_agg(
        agg.command(
            "save_cash",
            claim_id=claim_id,
            payload_digest=payload_digest(snap),
            units=units,
            amount_cents=units * 175,
            claim="saved",
            payor="cash",
        )
    )
    return post_claim(agg, snap, cash=True)


def cmd_pickup(args):
    _k, _m, agg, problem = load_agg()
    if problem:
        return err(problem)
    if agg is None:
        return err("not_open")
    if agg.state != "held":
        return err("not_held")
    now = int(os.environ["NOW_MS"])
    deadline = int(fact(agg, "pickup_deadline_ms") or 0)
    claim = fact(agg, "claim", "none")
    paid = claim in ("accepted", "cash")
    held = int(fact(agg, "held_units") or 0)
    if now > deadline:
        if not paid:
            new_rem = int(fact(agg, "remaining_qty") or 0) + held
            as_agg(
                agg.command(
                    "lapse_unpaid",
                    remaining_qty=new_rem,
                    claim="none",
                    payor="none",
                )
            )
            return err("pickup_lapsed")
        as_agg(agg.command("lapse_paid"))
        return err("pickup_lapsed")
    if not paid:
        return err("unpaid")
    remaining = int(fact(agg, "remaining_qty") or 0)
    refills = int(fact(agg, "refills") or 0)
    qty = int(fact(agg, "qty") or 0)
    picked = held
    if remaining == 0 and refills == 0:
        agg = as_agg(agg.command("pickup_dispensed"))
        phase = "dispensed"
        out_rem = 0
        out_ref = 0
    elif remaining == 0 and refills > 0:
        agg = as_agg(
            agg.command(
                "pickup_ok",
                remaining_qty=qty,
                refills=refills - 1,
                claim="none",
                payor="none",
            )
        )
        phase = "verified"
        out_rem = qty
        out_ref = refills - 1
    else:
        agg = as_agg(
            agg.command(
                "pickup_ok",
                remaining_qty=remaining,
                refills=refills,
                claim="none",
                payor="none",
            )
        )
        phase = "verified"
        out_rem = remaining
        out_ref = refills
    return emit(
        {
            "rx_id": fact(agg, "rx_id"),
            "units": picked,
            "remaining_qty": out_rem,
            "refills": out_ref,
            "phase": phase,
        }
    )


def cmd_reconcile(args):
    if not args:
        return err("bad_args")
    _k, _m, agg, problem = load_agg()
    if problem:
        return err(problem)
    if agg is None:
        return err("not_open")
    want = args[0]
    saved = fact(agg, "claim_id")
    claim = fact(agg, "claim", "none")
    if not saved or claim == "none":
        return err("no_claim")
    if want != saved:
        return err("claim_mismatch")
    if claim in ("accepted", "rejected", "cash"):
        body = claim_success(agg)
        body["lookup"] = "accepted" if claim == "accepted" else ("rejected" if claim == "rejected" else "accepted")
        if claim == "cash":
            body["lookup"] = "accepted"
        return emit(body)
    snap = current_snapshot(agg)
    base = os.environ["SERVICE_URL"].rstrip("/")
    kind, status, raw, parsed = http_json("GET", base + "/v1/claims/" + saved)
    if kind == "unavailable" or kind == "incomplete":
        return err("service_unavailable")
    if kind == "http" and status == 404:
        return emit(
            {
                "lookup": "not_sent",
                "rx_id": fact(agg, "rx_id"),
                "claim_id": saved,
                "claim": "saved",
                "phase": "held",
            }
        )
    if kind != "ok":
        if status >= 500:
            return err("service_unavailable")
        return err("service_unavailable")
    if not bodies_match(parsed, snap):
        return err("lookup_conflict")
    outcome = parsed.get("outcome")
    cash = fact(agg, "payor") == "cash"
    if outcome == "accepted":
        crash_if("after-accept-before-record")
        agg = record_and_mark(agg, raw, "cash" if cash else "accepted")
        crash_if("after-record-before-exit")
        body = claim_success(agg)
        body["lookup"] = "accepted"
        return emit(body)
    if outcome == "rejected":
        agg = record_and_mark(agg, raw, "rejected")
        body = claim_success(agg)
        body["lookup"] = "rejected"
        return emit(body)
    return err("lookup_conflict")


def cmd_notice(args):
    if not args:
        return err("bad_args")
    _k, _m, agg, problem = load_agg()
    if problem:
        return err(problem)
    if agg is None:
        return err("not_open")
    path = args[0]
    try:
        with open(path, "r", encoding="utf-8") as fh:
            raw = fh.read()
        data = json.loads(raw)
    except (OSError, ValueError):
        return err("bad_notice")
    if not isinstance(data, dict):
        return err("bad_notice")
    nid = data.get("notice_id")
    kind = data.get("kind")
    if not isinstance(nid, str) or not isinstance(kind, str):
        return err("bad_notice")
    if not ident(nid):
        return err("bad_notice")
    return emit({"notice_id": nid, "kind": kind, "ignored": True})


def cmd_rush(args):
    if not args:
        return err("bad_args")
    _k, machine, agg, problem = load_agg()
    if problem:
        return err(problem)
    if agg is None:
        return err("not_open")
    rx_id = args[0]
    if rx_id != fact(agg, "rx_id"):
        return err("rx_mismatch")
    if fact(agg, "edition", "v1") != "v2" or getattr(machine.identity, "version", 1) == 1:
        return err("legacy_rx")
    if agg.state != "held":
        return err("not_held")
    now = int(os.environ["NOW_MS"])
    current = int(fact(agg, "pickup_deadline_ms") or 0)
    target = min(current, now + RUSH_WINDOW_MS)
    recorded = fact(agg, "rush_ms", 0)
    recorded_n = int(recorded or 0)
    if recorded_n == target and current == target:
        return emit(
            {
                "rx_id": rx_id,
                "phase": "held",
                "pickup_deadline_ms": current,
                "rush_ms": recorded_n,
                "claim": fact(agg, "claim", "none"),
            }
        )
    agg = as_agg(agg.command("rush", pickup_deadline_ms=target, rush_ms=target))
    return emit(
        {
            "rx_id": rx_id,
            "phase": "held",
            "pickup_deadline_ms": target,
            "rush_ms": target,
            "claim": fact(agg, "claim", "none"),
        }
    )


def main(argv) -> int:
    pre = env_preflight(argv)
    if pre is not None:
        return pre
    cmd = argv[0]
    rest = argv[1:]
    if cmd == "intake":
        return cmd_intake(rest)
    if cmd == "status":
        return cmd_status(rest)
    if cmd == "verify":
        return cmd_verify(rest)
    if cmd == "fill":
        return cmd_fill(rest)
    if cmd == "claim":
        return cmd_claim(rest)
    if cmd == "cash-pay":
        return cmd_cash_pay(rest)
    if cmd == "pickup":
        return cmd_pickup(rest)
    if cmd == "reconcile":
        return cmd_reconcile(rest)
    if cmd == "notice":
        return cmd_notice(rest)
    if cmd == "rush":
        return cmd_rush(rest)
    return err("bad_args")


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
