from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NODE = os.environ.get("NODE", "node")
RUN = str(ROOT / "run")


def _start_stub():
    proc = subprocess.Popen(
        [NODE, str(ROOT / "stub" / "server.mjs")],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    line = proc.stdout.readline()
    info = json.loads(line)
    return proc, info["service_url"], info["control_url"]


def _http_json(method, url, body=None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={"Content-Type": "application/json"} if body is not None else {},
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _run(state, service, now, args, crash=None, extra=None):
    env = os.environ.copy()
    env["STATE_DIR"] = state
    env["SERVICE_URL"] = service
    env["NOW_MS"] = str(now)
    env["IK_BINARY"] = str(ROOT / "KIT" / "bin" / "ik")
    if crash:
        env["CRASH_AT"] = crash
    elif "CRASH_AT" in env:
        del env["CRASH_AT"]
    if extra:
        env.update(extra)
    proc = subprocess.run(
        [RUN] + args,
        cwd=str(ROOT),
        env=env,
        capture_output=True,
        text=True,
    )
    out = proc.stdout.strip()
    obj = json.loads(out) if out else None
    return proc.returncode, obj


class DeskTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.stub, cls.service, cls.control = _start_stub()
        time.sleep(0.05)

    @classmethod
    def tearDownClass(cls):
        cls.stub.kill()
        cls.stub.wait()

    def setUp(self):
        self.td = tempfile.mkdtemp(prefix="rxdesk-")
        _http_json("POST", self.control + "/fault", {"drop_reply": False, "delay_ms": 0, "error_status": 0})

    def tearDown(self):
        shutil.rmtree(self.td, ignore_errors=True)

    def run_cmd(self, *args, now=0, crash=None):
        return _run(self.td, self.service, now, list(args), crash=crash)

    def test_status_empty_and_intake(self):
        code, obj = self.run_cmd("status")
        self.assertEqual(code, 0)
        self.assertEqual(obj["phase"], "none")
        self.assertEqual(obj["claim"], "none")
        self.assertIsNone(obj["edition"])
        code, obj = self.run_cmd("intake", "RX1", "PAT1", "00000000001", "30", "1", "1000")
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["phase"], "intake")
        self.assertEqual(obj["remaining_qty"], 30)
        self.assertEqual(obj["edition"], "v2")
        code, obj = self.run_cmd("intake", "RX2", "PAT2", "00000000002", "10", "0", "1")
        self.assertEqual(code, 1)
        self.assertEqual(obj["error"], "already_bound")

    def test_bad_time_wins(self):
        env = os.environ.copy()
        env["STATE_DIR"] = self.td
        env["IK_BINARY"] = str(ROOT / "KIT" / "bin" / "ik")
        env.pop("NOW_MS", None)
        env.pop("SERVICE_URL", None)
        p = subprocess.run([RUN, "status"], cwd=str(ROOT), env=env, capture_output=True, text=True)
        self.assertEqual(json.loads(p.stdout)["error"], "bad_time")
        self.assertNotEqual(p.returncode, 0)

    def test_verify_fill_unpaid_pickup(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "10", "0", "5000")
        code, obj = self.run_cmd("fill", "RX1", "2")
        self.assertEqual(obj["error"], "not_verified")
        self.run_cmd("verify", "RX1")
        code, obj = self.run_cmd("fill", "RX1", "4")
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["phase"], "held")
        self.assertEqual(obj["remaining_qty"], 6)
        self.assertEqual(obj["held_units"], 4)
        code, obj = self.run_cmd("pickup", now=0)
        self.assertEqual(obj["error"], "unpaid")
        code, obj = self.run_cmd("pickup", now=5001)
        self.assertEqual(obj["error"], "pickup_lapsed")
        code, obj = self.run_cmd("status")
        self.assertEqual(obj["phase"], "verified")
        self.assertEqual(obj["remaining_qty"], 10)
        self.assertEqual(obj["held_units"], 0)

    def test_claim_accept_and_pickup_refill(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "10", "1", "10000")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "10")
        before = _http_json("GET", self.control + "/effects")["count"]
        code, obj = self.run_cmd("claim")
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["claim"], "accepted")
        self.assertEqual(obj["amount_cents"], 1750)
        code, obj = self.run_cmd("claim")
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["claim"], "accepted")
        code, obj = self.run_cmd("claim")
        self.assertEqual(code, 0)
        self.assertEqual(obj["claim"], "accepted")
        effects = _http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], before + 1)
        code, obj = self.run_cmd("pickup", now=0)
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["phase"], "verified")
        self.assertEqual(obj["remaining_qty"], 10)
        self.assertEqual(obj["refills"], 0)

    def test_denyall_cash_pay(self):
        self.run_cmd("intake", "RX1", "PAT1", "DENYALL", "5", "0", "10000")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "5")
        code, obj = self.run_cmd("cash-pay")
        self.assertEqual(obj["error"], "not_rejected")
        code, obj = self.run_cmd("claim")
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["claim"], "rejected")
        effects = _http_json("GET", self.control + "/effects")
        before = effects["count"]
        code, obj = self.run_cmd("cash-pay")
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["claim"], "cash")
        self.assertEqual(obj["payor"], "cash")
        effects = _http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], before + 1)
        code, obj = self.run_cmd("cash-pay")
        self.assertEqual(obj["error"], "cash_used")
        code, obj = self.run_cmd("pickup", now=0)
        self.assertEqual(code, 0)
        self.assertEqual(obj["phase"], "dispensed")

    def test_unrelated_file_survives(self):
        other = Path(self.td) / "other.bin"
        other.write_bytes(b"hello-bytes")
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "2", "0", "1")
        self.assertEqual(other.read_bytes(), b"hello-bytes")
        self.run_cmd("verify", "RX1")
        self.assertEqual(other.read_bytes(), b"hello-bytes")

    def test_corrupt_state(self):
        p = Path(self.td) / "desk.sqlite"
        p.write_text("not-a-store")
        code, obj = self.run_cmd("status")
        self.assertEqual(obj["error"], "corrupt_state")

    def test_crash_before_request(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "3", "0", "10000")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "3")
        code, obj = self.run_cmd("claim", crash="after-claim-saved-before-request")
        self.assertNotEqual(code, 0)
        st = self.run_cmd("status")[1]
        self.assertEqual(st["claim"], "saved")
        cid = st["claim_id"]
        self.assertTrue(cid)
        before = _http_json("GET", self.control + "/effects")["count"]
        code, obj = self.run_cmd("claim")
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["claim"], "accepted")
        self.assertEqual(obj["claim_id"], cid)
        effects = _http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], before + 1)

    def test_crash_after_accept_before_record(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "3", "0", "10000")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "3")
        code, obj = self.run_cmd("claim", crash="after-accept-before-record")
        self.assertNotEqual(code, 0)
        st = self.run_cmd("status")[1]
        self.assertEqual(st["claim"], "saved")
        before = _http_json("GET", self.control + "/effects")["count"]
        self.assertGreaterEqual(before, 1)
        code, obj = self.run_cmd("claim")
        self.assertEqual(obj["claim"], "accepted")
        effects = _http_json("GET", self.control + "/effects")
        self.assertEqual(effects["count"], before)

    def test_crash_after_record_before_exit(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "3", "0", "10000")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "3")
        code, obj = self.run_cmd("claim", crash="after-record-before-exit")
        self.assertNotEqual(code, 0)
        st = self.run_cmd("status")[1]
        self.assertEqual(st["claim"], "accepted")
        code, obj = self.run_cmd("claim")
        self.assertEqual(code, 0)
        self.assertEqual(obj["claim"], "accepted")

    def test_lost_reply_then_reconcile(self):
        _http_json("POST", self.control + "/fault", {"drop_reply": True, "delay_ms": 0, "error_status": 0})
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "3", "0", "10000")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "3")
        code, obj = self.run_cmd("claim")
        self.assertEqual(obj["error"], "service_unavailable")
        st = self.run_cmd("status")[1]
        self.assertEqual(st["claim"], "saved")
        before_e = _http_json("GET", self.control + "/effects")["count"]
        before_p = _http_json("GET", self.control + "/posts")["count"]
        _http_json("POST", self.control + "/fault", {"drop_reply": False, "delay_ms": 0, "error_status": 0})
        code, obj = self.run_cmd("reconcile", st["claim_id"])
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["lookup"], "accepted")
        self.assertEqual(obj["claim"], "accepted")
        self.assertEqual(_http_json("GET", self.control + "/effects")["count"], before_e)
        self.assertEqual(_http_json("GET", self.control + "/posts")["count"], before_p)

    def test_reconcile_not_sent(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "3", "0", "10000")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "3")
        self.run_cmd("claim", crash="after-claim-saved-before-request")
        st = self.run_cmd("status")[1]
        code, obj = self.run_cmd("reconcile", st["claim_id"])
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["lookup"], "not_sent")
        self.assertEqual(obj["claim"], "saved")
        code, obj = self.run_cmd("reconcile", "other-id")
        self.assertEqual(obj["error"], "claim_mismatch")

    def test_notice_ignored(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "3", "0", "10000")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "3")
        npath = Path(self.td) / "n.json"
        npath.write_text(json.dumps({"notice_id": "N1", "kind": "rush"}))
        code, obj = self.run_cmd("notice", str(npath))
        self.assertEqual(code, 0, obj)
        st = self.run_cmd("status")[1]
        self.assertEqual(st["phase"], "held")
        npath.write_text("not json")
        code, obj = self.run_cmd("notice", str(npath))
        self.assertEqual(obj["error"], "bad_notice")

    def test_process_restart_persists(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "8", "0", "9")
        code, obj = self.run_cmd("status")
        self.assertEqual(obj["rx_id"], "RX1")
        self.assertEqual(obj["phase"], "intake")

    def test_claim_not_held(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "8", "0", "9")
        before = _http_json("GET", self.control + "/posts")["count"]
        code, obj = self.run_cmd("claim")
        self.assertEqual(obj["error"], "not_held")
        posts = _http_json("GET", self.control + "/posts")
        self.assertEqual(posts["count"], before)

    def test_paid_lapse(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "4", "0", "10")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "2")
        self.run_cmd("claim")
        code, obj = self.run_cmd("pickup", now=11)
        self.assertEqual(obj["error"], "pickup_lapsed")
        st = self.run_cmd("status")[1]
        self.assertEqual(st["phase"], "lapsed")
        self.assertEqual(st["remaining_qty"], 2)

    def _bind_v1(self, rx="RX1", patient="PAT1", ndc="00000000001", qty=10, refills=0, hold_ms=172800000):
        sys.path.insert(0, str(next((ROOT / ".venv").glob("lib/python*/site-packages"))))
        os.environ.setdefault("IK_BINARY", str(ROOT / "KIT" / "bin" / "ik"))
        from invariant_kernel import Kernel

        store = Path(self.td) / "desk.sqlite"
        k = Kernel(store=str(store), binary=str(ROOT / "KIT" / "bin" / "ik"), timeout=60.0)
        m = k.machine(str(ROOT / "machines" / "rx_desk.ik.toml"))
        m.create_with(
            "prescription",
            {
                "name": "intake",
                "args": {
                    "rx_id": rx,
                    "patient_id": patient,
                    "ndc": ndc,
                    "qty": qty,
                    "refills": refills,
                    "hold_ms": hold_ms,
                    "edition": "v1",
                },
            },
        )

    def test_rush_v2_shortens_and_idempotent(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "10", "0", "7200000")
        self.run_cmd("verify", "RX1")
        code, obj = self.run_cmd("fill", "RX1", "4", now=0)
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["pickup_deadline_ms"], 7200000)
        before = _http_json("GET", self.control + "/posts")["count"]
        code, obj = self.run_cmd("rush", "RX1", now=1000)
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["phase"], "held")
        self.assertEqual(obj["pickup_deadline_ms"], 1000 + 3600000)
        self.assertEqual(obj["rush_ms"], 1000 + 3600000)
        posts = _http_json("GET", self.control + "/posts")
        self.assertEqual(posts["count"], before)
        code, obj = self.run_cmd("status")
        self.assertEqual(obj["rush_ms"], 1000 + 3600000)
        code, obj = self.run_cmd("rush", "RX1", now=1000)
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["pickup_deadline_ms"], 1000 + 3600000)
        code, obj = self.run_cmd("rush", "OTHER")
        self.assertEqual(obj["error"], "rx_mismatch")
        st = self.run_cmd("status")[1]
        self.assertEqual(st["rush_ms"], 1000 + 3600000)

    def test_rush_not_held_and_unpaid(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "10", "0", "7200000")
        code, obj = self.run_cmd("rush", "RX1")
        self.assertEqual(obj["error"], "not_held")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "4", now=0)
        self.run_cmd("rush", "RX1", now=0)
        code, obj = self.run_cmd("pickup", now=0)
        self.assertEqual(obj["error"], "unpaid")
        self.run_cmd("claim")
        code, obj = self.run_cmd("pickup", now=1000)
        self.assertEqual(code, 0, obj)
        self.assertEqual(obj["remaining_qty"], 6)

    def test_v2_hold_cap_vs_v1_uncapped(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "10", "0", "172800000")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "2", now=0)
        code, obj = self.run_cmd("pickup", now=86400001)
        self.assertEqual(obj["error"], "pickup_lapsed")
        st = self.run_cmd("status")[1]
        self.assertEqual(st["phase"], "verified")

        self.tearDown()
        self.setUp()
        self._bind_v1()
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "2", now=0)
        st = self.run_cmd("status")[1]
        self.assertEqual(st["edition"], "v1")
        self.assertIsNone(st["rush_ms"])
        code, obj = self.run_cmd("pickup", now=86400001)
        self.assertEqual(obj["error"], "unpaid")
        code, obj = self.run_cmd("rush", "RX1")
        self.assertEqual(obj["error"], "legacy_rx")
        st = self.run_cmd("status")[1]
        self.assertIsNone(st["rush_ms"])
        self.assertEqual(st["phase"], "held")

    def test_rush_survives_saved_claim_crash(self):
        self.run_cmd("intake", "RX1", "PAT1", "00000000001", "3", "0", "7200000")
        self.run_cmd("verify", "RX1")
        self.run_cmd("fill", "RX1", "3", now=0)
        self.run_cmd("rush", "RX1", now=0)
        code, obj = self.run_cmd("claim", crash="after-claim-saved-before-request")
        self.assertNotEqual(code, 0)
        st = self.run_cmd("status")[1]
        self.assertEqual(st["claim"], "saved")
        self.assertEqual(st["rush_ms"], 3600000)
        cid = st["claim_id"]
        before = _http_json("GET", self.control + "/effects")["count"]
        code, obj = self.run_cmd("claim")
        self.assertEqual(obj["claim"], "accepted")
        self.assertEqual(obj["claim_id"], cid)
        self.assertEqual(_http_json("GET", self.control + "/effects")["count"], before + 1)
        st = self.run_cmd("status")[1]
        self.assertEqual(st["rush_ms"], 3600000)


if __name__ == "__main__":
    unittest.main()
