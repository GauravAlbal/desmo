# Pharmacy prescription refill desk

Durable one-prescription desk using Ikaros for lifecycle state.

## Setup

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
chmod +x run
```

Node is only needed for the fake claims stub:

```sh
# from this directory
node stub/server.mjs
# prints {"service_url":"http://127.0.0.1:<port>","control_url":"..."}
```

## Run

`STATE_DIR`, `SERVICE_URL`, and `NOW_MS` are required on every invocation.
Optional: `CRASH_AT`, `IK_BINARY` (defaults to `KIT/bin/ik`).

```sh
export STATE_DIR=/tmp/rx-desk
export SERVICE_URL=http://127.0.0.1:PORT
export NOW_MS=0
mkdir -p "$STATE_DIR"
./run intake RX1 PAT1 00000000001 30 1 3600000
./run verify RX1
./run fill RX1 30
./run claim
./run pickup
./run status
./run rush RX1
```

## Tests

```sh
.venv/bin/python tests/test_desk.py
```
