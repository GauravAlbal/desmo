from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import signal
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

ROOT = Path(__file__).resolve().parent
for _p in (ROOT / ".venv").glob("lib/python*/site-packages"):
    sys.path.insert(0, str(_p))
os.environ.setdefault("IK_BINARY", str(ROOT / "KIT" / "bin" / "ik"))

from invariant_kernel import (  # noqa: E402
    Aggregate,
    HistoricalResult,
    Kernel,
    classify,
)

MACHINE_V1 = ROOT / "machines" / "rx_desk.ik.toml"
MACHINE_V2 = ROOT / "machines" / "rx_desk_v2.ik.toml"
HOLD_CAP_MS = 86400000
RUSH_WINDOW_MS = 3600000
STORE_NAME = "desk.sqlite"
AGGREGATE_ID = "prescription"
ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
CANON_INT = re.compile(r"^(0|[1-9][0-9]*)$")


def _die(code: str, n: int = 1) -> None:
    sys.stdout.write(json.dumps({"error": code}) + "\n")
    raise SystemExit(n)


def _ok(obj: Dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(obj) + "\n")
    raise SystemExit(0)


def _canon_int(raw: Optional[str]) -> Optional[int]:
    if raw is None or not CANON_INT.fullmatch(raw):
        return None
    return int(raw)


def _id_ok(s: str) -> bool:
    return bool(ID_RE.fullmatch(s))


def _now() -> Optional[int]:
    return _canon_int(os.environ.get("NOW_MS"))


def _service() -> Optional[str]:
    u = os.environ.get("SERVICE_URL")
    if u is None or u == "":
        return None
    return u


def _crash(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


def _store_path() -> Path:
    state = os.environ.get("STATE_DIR")
    if not state:
        _die("bad_args")
    return Path(state) / STORE_NAME


def _open_kernel(create: bool) -> Tuple[Kernel, Any]:
    path = _store_path()
    binary = os.environ.get("IK_BINARY") or str(ROOT / "KIT" / "bin" / "ik")
    if path.exists():
        try:
            k = Kernel(store=str(path), binary=binary, timeout=60.0)
            m1 = k.machine(str(MACHINE_V1))
            m2 = k.machine(str(MACHINE_V2))
            return k, m1, m2
        except Exception as exc:
            kind = classify(exc)
            if kind == "corrupt":
                _die("corrupt_state")
            raise
    if not create:
        return None, None, None  # type: ignore
    k = Kernel(store=str(path), binary=binary, timeout=60.0)
    m1 = k.machine(str(MACHINE_V1))
    m2 = k.machine(str(MACHINE_V2))
    return k, m1, m2


def _route(m1, m2, agg: Optional[Aggregate]):
    if agg is None:
        return m2
    owner = agg.owner
    for m in (m1, m2):
        if m.identity == owner:
            return m
    return m2


def _show(machine) -> Optional[Aggregate]:
    if machine is None:
        return None
    try:
        return machine.show(AGGREGATE_ID)
    except Exception as exc:
        kind = classify(exc)
        if kind == "not_found":
            return None
        if kind == "corrupt":
            _die("corrupt_state")
        raise


def _f(agg: Aggregate) -> Dict[str, Any]:
    facts = dict(agg.facts)
    facts["phase"] = agg.state
    return facts


def _null_status() -> Dict[str, Any]:
    return {
        "rx_id": None,
        "patient_id": None,
        "ndc": None,
        "qty": None,
        "remaining_qty": 0,
        "refills": 0,
        "hold_ms": None,
        "held_units": 0,
        "pickup_deadline_ms": None,
        "phase": "none",
        "claim": "none",
        "claim_id": None,
        "amount_cents": None,
        "payor": None,
        "units": None,
        "edition": None,
        "rush_ms": None,
    }


def _empty_str(v: Any) -> bool:
    return v is None or v == ""


def _status_from(facts: Dict[str, Any]) -> Dict[str, Any]:
    phase = facts.get("phase") or "none"
    claim = facts.get("claim") or "none"
    deadline = facts.get("pickup_deadline_ms", -1)
    rush = facts.get("rush_ms", -1)
    cid = facts.get("claim_id")
    payor = facts.get("payor")
    edition = facts.get("edition")
    units = facts.get("units", 0)
    amount = facts.get("amount_cents", 0)
    held = facts.get("held_units", 0)
    show_units = None
    show_amount = None
    show_payor = None if _empty_str(payor) else payor
    if phase == "held" or claim in ("saved", "accepted", "rejected", "cash"):
        if units:
            show_units = units
        elif held:
            show_units = held
        if amount or (show_units is not None):
            show_amount = amount if amount else (show_units or 0) * 175
    if phase == "held" and held and show_units is None:
        show_units = held
        show_amount = held * 175
    return {
        "rx_id": facts.get("rx_id") or None,
        "patient_id": facts.get("patient_id") or None,
        "ndc": facts.get("ndc") or None,
        "qty": facts.get("qty", None),
        "remaining_qty": facts.get("remaining_qty", 0),
        "refills": facts.get("refills", 0),
        "hold_ms": facts.get("hold_ms", None),
        "held_units": facts.get("held_units", 0),
        "pickup_deadline_ms": None if deadline is None or deadline < 0 else deadline,
        "phase": phase if phase != "empty" else "none",
        "claim": claim,
        "claim_id": None if _empty_str(cid) else cid,
        "amount_cents": show_amount,
        "payor": show_payor,
        "units": show_units,
        "edition": None if _empty_str(edition) else edition,
        "rush_ms": None if rush is None or rush < 0 else rush,
    }


def _cmd(agg: Aggregate, name: str, **args: Any) -> Aggregate:
    result = agg.command(name, **args) if args else agg.command(name)
    if isinstance(result, HistoricalResult):
        return agg.show()
    return result


def _digest(obj: Dict[str, Any]) -> str:
    blob = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def _http(method: str, url: str, body: Optional[Dict[str, Any]] = None) -> Tuple[str, Optional[int], Any, Optional[bytes]]:
    data = None
    headers = {}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=3) as resp:
            raw = resp.read()
            status = resp.getcode()
    except urllib.error.HTTPError as exc:
        try:
            raw = exc.read()
        except Exception:
            return "transport", exc.code, None, None
        status = exc.code
    except Exception:
        return "transport", None, None, None
    parsed = None
    try:
        parsed = json.loads(raw.decode("utf-8"))
    except Exception:
        return "incomplete", status, None, raw
    return "ok", status, parsed, raw


def _snapshot_from(facts: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "claim_id": facts["claim_id"],
        "rx_id": facts["rx_id"],
        "ndc": facts["ndc"],
        "units": int(facts["units"] or facts["held_units"]),
        "amount_cents": int(facts["amount_cents"] or int(facts["held_units"]) * 175),
        "payor": facts["payor"],
    }


def _body_matches(body: Any, snap: Dict[str, Any]) -> bool:
    if not isinstance(body, dict):
        return False
    for k in ("claim_id", "rx_id", "ndc", "payor"):
        if body.get(k) != snap.get(k):
            return False
    try:
        if int(body.get("units")) != int(snap["units"]):
            return False
        if int(body.get("amount_cents")) != int(snap["amount_cents"]):
            return False
    except Exception:
        return False
    return True


def _complete_outcome(body: Any) -> Optional[str]:
    if not isinstance(body, dict):
        return None
    oc = body.get("outcome")
    if oc in ("accepted", "rejected"):
        return oc
    return None


def _record_if_pending(agg: Aggregate, outcome_digest: str) -> Aggregate:
    if agg.pending_intent is None:
        return agg
    result = agg.record_effect_outcome(outcome_digest)
    if isinstance(result, HistoricalResult):
        return agg.show()
    return result


def _claim_success(facts: Dict[str, Any], claim_st: str) -> Dict[str, Any]:
    units = int(facts["units"] or facts["held_units"])
    return {
        "rx_id": facts["rx_id"],
        "claim_id": facts["claim_id"],
        "units": units,
        "amount_cents": int(facts["amount_cents"] or units * 175),
        "payor": facts.get("payor") or ("cash" if claim_st == "cash" else "insurer"),
        "claim": claim_st,
        "phase": "held",
    }


def _adopt(agg: Aggregate, outcome: str, payor: str) -> Aggregate:
    if outcome == "rejected":
        return _cmd(agg, "adopt_rejected", claim_st="rejected")
    if payor == "cash" or outcome == "cash":
        return _cmd(agg, "adopt_cash", claim_st="cash")
    return _cmd(agg, "adopt_accepted", claim_st="accepted")


def do_intake(args: list) -> None:
    if len(args) < 6:
        _die("bad_args")
    rx_id, patient_id, ndc, qty_s, refills_s, hold_s = args[:6]
    k, m1, m2 = _open_kernel(create=False)
    m = m2 if m2 is not None else m1
    agg = _show(m) if m is not None else None
    if agg is not None and agg.state != "empty":
        _die("already_bound")
    if not (_id_ok(rx_id) and _id_ok(patient_id) and _id_ok(ndc)):
        _die("bad_args")
    qty = _canon_int(qty_s)
    if qty is None or qty < 1 or qty > 999:
        _die("bad_qty")
    refills = _canon_int(refills_s)
    if refills is None or refills < 0 or refills > 11:
        _die("bad_refills")
    hold = _canon_int(hold_s)
    if hold is None or hold < 0 or hold > 2592000000:
        _die("bad_hold")
    cmd = {
        "name": "intake",
        "args": {
            "rx_id": rx_id,
            "patient_id": patient_id,
            "ndc": ndc,
            "qty": qty,
            "refills": refills,
            "hold_ms": hold,
            "edition": "v2",
        },
    }
    k, m1, m2 = _open_kernel(create=True)
    m = m2
    result = m.create_with(AGGREGATE_ID, cmd)
    if isinstance(result, HistoricalResult):
        agg = m.show(AGGREGATE_ID)
    else:
        agg = result
    facts = _f(agg)
    _ok(
        {
            "rx_id": facts["rx_id"],
            "patient_id": facts["patient_id"],
            "ndc": facts["ndc"],
            "qty": facts["qty"],
            "remaining_qty": facts["remaining_qty"],
            "refills": facts["refills"],
            "hold_ms": facts["hold_ms"],
            "phase": "intake",
            "claim": "none",
            "claim_id": None,
            "edition": "v2",
        }
    )


def do_verify(args: list, agg: Aggregate) -> None:
    if len(args) < 1:
        _die("bad_args")
    rx_id = args[0]
    facts = _f(agg)
    if rx_id != facts.get("rx_id"):
        _die("rx_mismatch")
    phase = facts["phase"]
    if phase in ("held", "dispensed", "lapsed"):
        _die("already_moved")
    if phase not in ("intake", "verified"):
        _die("already_moved")
    agg = _cmd(agg, "verify")
    _ok({"rx_id": facts["rx_id"], "phase": "verified"})


def do_fill(args: list, agg: Aggregate, now: int) -> None:
    if len(args) < 2:
        _die("bad_args")
    rx_id, units_s = args[0], args[1]
    facts = _f(agg)
    if rx_id != facts.get("rx_id"):
        _die("rx_mismatch")
    phase = facts["phase"]
    if phase == "intake":
        _die("not_verified")
    if phase == "held":
        _die("already_held")
    remaining = int(facts.get("remaining_qty") or 0)
    if remaining == 0:
        _die("rx_complete")
    units = _canon_int(units_s)
    if units is None or units < 1 or units > remaining:
        _die("bad_units")
    if phase != "verified":
        _die("already_moved")
    hold = int(facts["hold_ms"])
    edition = facts.get("edition") or "v1"
    if edition == "v2":
        hold = min(hold, HOLD_CAP_MS)
    deadline = now + hold
    amount = units * 175
    fill_kwargs = {
        "units": units,
        "remain_after": remaining - units,
        "deadline": deadline,
        "amount_cents": amount,
    }
    if edition == "v2":
        fill_kwargs["rush_clear"] = -1
    agg = _cmd(agg, "fill", **fill_kwargs)
    facts = _f(agg)
    _ok(
        {
            "rx_id": facts["rx_id"],
            "units": units,
            "remaining_qty": facts["remaining_qty"],
            "held_units": facts["held_units"],
            "phase": "held",
            "pickup_deadline_ms": facts["pickup_deadline_ms"],
            "claim": "none",
        }
    )


def do_rush(args: list, agg: Aggregate, now: int) -> None:
    if len(args) < 1:
        _die("bad_args")
    rx_id = args[0]
    facts = _f(agg)
    if rx_id != facts.get("rx_id"):
        _die("rx_mismatch")
    edition = facts.get("edition") or "v1"
    if edition != "v2":
        _die("legacy_rx")
    if facts["phase"] != "held":
        _die("not_held")
    current = int(facts["pickup_deadline_ms"])
    new_deadline = min(current, now + RUSH_WINDOW_MS)
    rush_now = facts.get("rush_ms", -1)
    if rush_now is None:
        rush_now = -1
    if int(rush_now) == new_deadline and current == new_deadline:
        _ok(
            {
                "rx_id": facts["rx_id"],
                "phase": "held",
                "pickup_deadline_ms": current,
                "rush_ms": new_deadline,
                "claim": facts.get("claim") or "none",
            }
        )
    agg = _cmd(agg, "rush", deadline=new_deadline, rush_at=new_deadline)
    facts = _f(agg)
    _ok(
        {
            "rx_id": facts["rx_id"],
            "phase": "held",
            "pickup_deadline_ms": facts["pickup_deadline_ms"],
            "rush_ms": facts["rush_ms"],
            "claim": facts.get("claim") or "none",
        }
    )


def _submit_saved(agg: Aggregate, service: str, payor_expected: Optional[str], crash: bool) -> None:
    facts = _f(agg)
    snap = _snapshot_from(facts)
    get_url = service.rstrip("/") + "/v1/claims/" + snap["claim_id"]
    kind, status, body, raw = _http("GET", get_url)
    if kind == "transport":
        _die("service_unavailable")
    if kind == "incomplete" and status is not None and status >= 500:
        _die("service_unavailable")
    adopted = None
    if kind == "ok" and status == 200:
        if not _body_matches(body, snap):
            _die("lookup_conflict")
        oc = _complete_outcome(body)
        if oc is None:
            _die("service_unavailable")
        adopted = oc
        digest = hashlib.sha256(raw or b"").hexdigest()
        if crash:
            _crash("after-accept-before-record")
        agg = _record_if_pending(agg, digest)
        agg = _adopt(agg, oc, snap["payor"])
        facts = _f(agg)
        if oc == "rejected":
            _crash("after-record-before-exit")
            _ok(_claim_success(facts, "rejected"))
        st = "cash" if snap["payor"] == "cash" else "accepted"
        _crash("after-record-before-exit")
        _ok(_claim_success(facts, st))
    if kind == "ok" and status == 404:
        pass
    elif kind == "ok" and status is not None and status >= 500:
        _die("service_unavailable")
    elif kind == "incomplete":
        _die("service_unavailable")
    elif status not in (None, 404):
        if status >= 500:
            _die("service_unavailable")
        if status == 409:
            _die("lookup_conflict")
        _die("service_unavailable")

    if crash:
        _crash("after-claim-saved-before-request")
    post_url = service.rstrip("/") + "/v1/claims"
    kind, status, body, raw = _http("POST", post_url, snap)
    if kind == "transport":
        _die("service_unavailable")
    if kind == "incomplete":
        _die("service_unavailable")
    if status is not None and status >= 500:
        _die("service_unavailable")
    if status == 409:
        _die("lookup_conflict")
    if status != 200:
        _die("service_unavailable")
    if not _body_matches(body, snap):
        _die("lookup_conflict")
    oc = _complete_outcome(body)
    if oc is None:
        _die("service_unavailable")
    if oc == "accepted" or oc == "rejected":
        _crash("after-accept-before-record")
    digest = hashlib.sha256(raw or b"").hexdigest()
    agg = _record_if_pending(agg, digest)
    agg = _adopt(agg, oc, snap["payor"])
    facts = _f(agg)
    if oc == "rejected":
        _crash("after-record-before-exit")
        _ok(_claim_success(facts, "rejected"))
    st = "cash" if snap["payor"] == "cash" else "accepted"
    _crash("after-record-before-exit")
    _ok(_claim_success(facts, st))


def do_claim(agg: Aggregate, service: str) -> None:
    facts = _f(agg)
    if facts["phase"] != "held":
        _die("not_held")
    claim = facts.get("claim") or "none"
    if claim in ("accepted", "rejected", "cash"):
        _ok(_claim_success(facts, claim if claim != "cash" else "cash"))
    if claim == "saved":
        _submit_saved(agg, service, facts.get("payor"), crash=True)
        return
    units = int(facts["held_units"])
    amount = units * 175
    cid = secrets.token_hex(16)
    snap = {
        "claim_id": cid,
        "rx_id": facts["rx_id"],
        "ndc": facts["ndc"],
        "units": units,
        "amount_cents": amount,
        "payor": "insurer",
    }
    agg = _cmd(
        agg,
        "save_insurer",
        claim_id=cid,
        units=units,
        amount_cents=amount,
        payor="insurer",
        claim_st="saved",
        effect_id=cid,
        payload_digest=_digest(snap),
        idempotency_key=cid,
    )
    _submit_saved(agg, service, "insurer", crash=True)


def do_cash(agg: Aggregate, service: str) -> None:
    facts = _f(agg)
    if facts["phase"] != "held":
        _die("not_held")
    claim = facts.get("claim") or "none"
    if claim == "cash":
        _die("cash_used")
    if claim == "saved" and facts.get("payor") == "cash":
        _submit_saved(agg, service, "cash", crash=True)
        return
    if claim != "rejected":
        _die("not_rejected")
    units = int(facts["held_units"] or facts["units"])
    amount = units * 175
    cid = secrets.token_hex(16)
    snap = {
        "claim_id": cid,
        "rx_id": facts["rx_id"],
        "ndc": facts["ndc"],
        "units": units,
        "amount_cents": amount,
        "payor": "cash",
    }
    agg = _cmd(
        agg,
        "save_cash",
        claim_id=cid,
        units=units,
        amount_cents=amount,
        payor="cash",
        claim_st="saved",
        effect_id=cid,
        payload_digest=_digest(snap),
        idempotency_key=cid,
    )
    _submit_saved(agg, service, "cash", crash=True)


def do_pickup(agg: Aggregate, now: int) -> None:
    facts = _f(agg)
    if facts["phase"] != "held":
        _die("not_held")
    deadline = int(facts["pickup_deadline_ms"])
    claim = facts.get("claim") or "none"
    paid = claim in ("accepted", "cash")
    if now > deadline:
        remain_after = int(facts["remaining_qty"]) + int(facts["held_units"])
        if paid:
            remain_after = int(facts["remaining_qty"])
        picked = int(facts["held_units"])
        agg = _cmd(
            agg,
            "pickup",
            now_ms=now,
            remain_after=remain_after,
            refills_after=max(int(facts["refills"]) - 1, 0),
            qty_restore=int(facts["qty"]),
            claim_reset="none",
            empty="",
            zero=0,
            neg=-1,
        )
        _die("pickup_lapsed")
    if not paid:
        _die("unpaid")
    picked = int(facts["held_units"])
    remain_after = int(facts["remaining_qty"])
    agg = _cmd(
        agg,
        "pickup",
        now_ms=now,
        remain_after=remain_after,
        refills_after=max(int(facts["refills"]) - 1, 0),
        qty_restore=int(facts["qty"]),
        claim_reset="none",
        empty="",
        zero=0,
        neg=-1,
    )
    facts = _f(agg)
    _ok(
        {
            "rx_id": facts["rx_id"],
            "units": picked,
            "remaining_qty": facts["remaining_qty"],
            "refills": facts["refills"],
            "phase": facts["phase"],
        }
    )


def do_reconcile(args: list, agg: Aggregate, service: str) -> None:
    if len(args) < 1:
        _die("bad_args")
    cid = args[0]
    facts = _f(agg)
    saved = facts.get("claim_id")
    if _empty_str(saved):
        _die("no_claim")
    if cid != saved:
        _die("claim_mismatch")
    snap = _snapshot_from(facts)
    get_url = service.rstrip("/") + "/v1/claims/" + saved
    kind, status, body, raw = _http("GET", get_url)
    if kind == "transport":
        _die("service_unavailable")
    if kind == "incomplete":
        _die("service_unavailable")
    if status is not None and status >= 500:
        _die("service_unavailable")
    if status == 404:
        _ok(
            {
                "lookup": "not_sent",
                "rx_id": facts["rx_id"],
                "claim_id": saved,
                "claim": "saved",
                "phase": facts["phase"],
            }
        )
    if status != 200:
        if status == 409:
            _die("lookup_conflict")
        _die("service_unavailable")
    if not _body_matches(body, snap):
        _die("lookup_conflict")
    oc = _complete_outcome(body)
    if oc is None:
        _die("service_unavailable")
    digest = hashlib.sha256(raw or b"").hexdigest()
    _crash("after-accept-before-record")
    agg = _record_if_pending(agg, digest)
    agg = _adopt(agg, oc, snap["payor"])
    facts = _f(agg)
    st = facts["claim"]
    if oc == "rejected":
        st = "rejected"
    elif snap["payor"] == "cash":
        st = "cash"
    else:
        st = "accepted"
    out = _claim_success(facts, st)
    out["lookup"] = oc
    _crash("after-record-before-exit")
    _ok(out)


def do_notice(args: list, agg: Optional[Aggregate]) -> None:
    if len(args) < 1:
        _die("bad_args")
    if agg is None:
        _die("not_open")
    path = args[0]
    try:
        raw = Path(path).read_text(encoding="utf-8")
        data = json.loads(raw)
    except Exception:
        _die("bad_notice")
    if not isinstance(data, dict):
        _die("bad_notice")
    nid = data.get("notice_id")
    kind = data.get("kind")
    if not isinstance(nid, str) or not isinstance(kind, str):
        _die("bad_notice")
    if not _id_ok(nid):
        _die("bad_notice")
    facts = _f(agg)
    _ok(_status_from(facts))


def main() -> None:
    argv = sys.argv[1:]
    if not argv:
        now = _now()
        if now is None:
            _die("bad_time")
        if _service() is None:
            _die("bad_args")
        _die("bad_args")

    cmd = argv[0]
    rest = argv[1:]

    store = _store_path()
    if store.exists():
        k, m1, m2 = _open_kernel(create=False)
        m = m2 if m2 is not None else m1
        if m is None:
            _die("corrupt_state")
        try:
            _ = m.show(AGGREGATE_ID)
        except Exception as exc:
            kind = classify(exc)
            if kind == "corrupt":
                _die("corrupt_state")
            if kind != "not_found":
                # still allow not_found
                pass

    now = _now()
    if now is None:
        _die("bad_time")
    service = _service()
    if service is None:
        _die("bad_args")

    if cmd not in (
        "intake",
        "verify",
        "fill",
        "claim",
        "cash-pay",
        "pickup",
        "reconcile",
        "status",
        "notice",
        "rush",
    ):
        _die("bad_args")

    k, m1, m2 = _open_kernel(create=False)
    probe = m2 if m2 is not None else m1
    agg = _show(probe) if probe is not None else None
    if agg is not None and m1 is not None and m2 is not None:
        routed = _route(m1, m2, agg)
        if routed is not probe:
            shown = _show(routed)
            if shown is not None:
                agg = shown
    bound = agg is not None and agg.state != "empty"

    if cmd == "status":
        if not bound:
            _ok(_null_status())
        _ok(_status_from(_f(agg)))

    if cmd == "intake":
        do_intake(rest)
        return

    if not bound:
        _die("not_open")

    if cmd == "verify":
        do_verify(rest, agg)
    elif cmd == "fill":
        do_fill(rest, agg, now)
    elif cmd == "claim":
        do_claim(agg, service)
    elif cmd == "cash-pay":
        do_cash(agg, service)
    elif cmd == "pickup":
        do_pickup(agg, now)
    elif cmd == "reconcile":
        do_reconcile(rest, agg, service)
    elif cmd == "notice":
        do_notice(rest, agg)
    elif cmd == "rush":
        do_rush(rest, agg, now)
    else:
        _die("bad_args")


if __name__ == "__main__":
    main()
