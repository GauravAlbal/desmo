# Change: recall-gated overdue return and seven-day loan

R1–R14 remain in force except where this file supersedes R3's 14-day span and the initial-contract rule that `checkin` is allowed when overdue. Those two rules continue to apply to pre-change instances; they do not apply to requests filed after this change. `status` still reports `recall_placed` as `0` or `1`. This change adds a recall command and changes checkout span and overdue `checkin` for new requests.

The new command is:

`place-recall`

It is valid only for an `out` request whose owning machine is the post-change definition. It records `recall_placed` as `1` and returns `{req_id,status:"out",recall_placed:1,loan_until_ms,overdue}`. Repeating `place-recall` after `recall_placed:1` is a success no-op without another mutation. A request filed under the original program is `legacy_request` even if it is not `out` (`legacy_request` wins `not_out`). A post-change request that is not `out` is `not_out`. The command never contacts the provider.

`checkout` is revised only for requests filed under the new definition. It records a loan span of `604800000` milliseconds (7 days). `loan_until_ms` is `checkout_ms + 604800000`. The success object shape is unchanged.

`checkin` is revised only for requests filed under the new definition. If `NOW_MS > loan_until_ms` and `recall_placed` is not `1`, `checkin` returns `recall_required` and changes nothing. After a successful `place-recall`, `checkin` succeeds even when overdue. `checkin` while not overdue still succeeds without a recall.

## Old-instance policy

For every changed or new behavior:

* `place-recall` on a request filed under the original program is `legacy_request` and nothing mutates. Observable: `status.recall_placed` stays `0` and `status` is unchanged.
* `checkout` on a request filed under the original program keeps the original 14-day span (`loan_until_ms = checkout_ms + 1209600000`). Observable: that sum after a post-change `checkout` of a pre-change `received` request.
* `checkin` on a request filed under the original program stays allowed when overdue, with no recall. Observable: `checkin` after `NOW_MS > loan_until_ms` returns `status:"returned"` and is not `recall_required`.
* Pre-change `returned`, `lost`, and `cancelled` requests remain terminal under the original rules. `place-recall` on them is `legacy_request`.
* Saved lender-request attempts keep the same `loan_req_id`, snapshot, and R8–R12 recovery rules. `place-recall` does not allocate or POST. Cancel while `lender:"attempt_saved"` remains `loan_started`.

Old instances remain fully usable to completion under the original rules. The changed program must not require a new field, command, or rule of them.

## C1–C5

C1. `place-recall` on a new `out` request persists `recall_placed:1`, returns that object, and creates no provider effect.

C2. Recall state survives a new process. Repeating `place-recall` is idempotent without another mutation. A request created by the pre-change program (`OLD_PROJECT_DIR`) refuses `place-recall` with `legacy_request` without mutation.

C3. On a new request, `checkin` when overdue without a recall is `recall_required` and leaves `status:"out"`. After `place-recall`, overdue `checkin` returns `status:"returned"`.

C4. `checkout` of a new request uses the 7-day span. `checkout` of a pre-change request (filed with `OLD_PROJECT_DIR`, then received and checked out under the changed program) uses the 14-day span. Overdue `checkin` of that pre-change request succeeds without `place-recall`.

C5. After `place-recall` (or on a new request awaiting it), a saved-attempt crash or dropped reply still recovers the same `loan_req_id` by lookup/retry, cancellation cannot erase a saved attempt, and no second provider effect is created. After that recovery, a new request still uses the 7-day span and accepts `place-recall`.
