import {spawn, spawnSync} from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import {fileURLToPath} from "node:url";
import assert from "node:assert/strict";
import test from "node:test";

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const NODE = process.execPath;
const RUN = path.join(ROOT, "run");
const STUB = path.join(ROOT, "stub", "server.mjs");

function tmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), "ill-desk-"));
}

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [STUB], {stdio: ["ignore", "pipe", "pipe"]});
    let buf = "";
    child.stdout.on("data", (c) => {
      buf += c;
      const nl = buf.indexOf("\n");
      if (nl >= 0) {
        try {
          const info = JSON.parse(buf.slice(0, nl));
          resolve({child, ...info});
        } catch (e) {
          reject(e);
        }
      }
    });
    child.on("error", reject);
  });
}

function runDesk(env, args, extra = {}) {
  return spawnSync(NODE, [RUN, ...args], {
    encoding: "utf8",
    env: {...process.env, ...env},
    ...extra,
  });
}

function parseOut(r) {
  const line = (r.stdout || "").trim();
  try {
    return JSON.parse(line);
  } catch {
    return {raw: r.stdout, err: r.stderr, status: r.status, signal: r.signal};
  }
}

function envFor(state, service, now = "1000") {
  return {STATE_DIR: state, SERVICE_URL: service, NOW_MS: now};
}

test("empty status and bad_time precedence", async () => {
  const state = tmpDir();
  const {child, service_url} = await startStub();
  try {
    const missingTime = runDesk({STATE_DIR: state, SERVICE_URL: service_url}, ["status"]);
    assert.equal(parseOut(missingTime).error, "bad_time");
    assert.notEqual(missingTime.status, 0);
    const r = runDesk(envFor(state, service_url), ["status"]);
    assert.equal(r.status, 0);
    assert.deepEqual(parseOut(r), {
      req_id: null, patron_id: null, oclc: null, lender_id: null,
      status: "none", lender: "none", loan_req_id: null,
      checkout_ms: null, loan_until_ms: null, overdue: 0, recall_placed: 0,
    });
    const unknown = runDesk(envFor(state, service_url), ["nope"]);
    assert.equal(parseOut(unknown).error, "bad_args");
  } finally {
    child.kill("SIGKILL");
  }
});

test("already_filed locate and loan_started", async () => {
  const state = tmpDir();
  const {child, service_url} = await startStub();
  const e = envFor(state, service_url);
  try {
    const filed = parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    assert.equal(filed.status, "filed");
    assert.equal(filed.loan_req_id, null);
    assert.equal(parseOut(runDesk(e, ["file", "ILL-O", "PAT-O", "OCLC-O"])).error, "already_filed");
    const loc = parseOut(runDesk(e, ["locate", "LEND-A"]));
    assert.equal(loc.status, "located");
    assert.equal(parseOut(runDesk(e, ["locate", "LEND-N"])).error, "already_located");
    const killed = runDesk({...e, CRASH_AT: "after-request-saved-before-request"}, ["transmit"]);
    assert.equal(killed.signal, "SIGKILL");
    assert.equal(parseOut(runDesk(e, ["cancel"])).error, "loan_started");
    assert.equal(parseOut(runDesk(e, ["receive"])).error, "loan_pending");
  } finally {
    child.kill("SIGKILL");
  }
});

test("happy loan and overdue", async () => {
  const state = tmpDir();
  const {child, service_url, control_url} = await startStub();
  const e = envFor(state, service_url, "1000");
  try {
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    parseOut(runDesk(e, ["locate", "LEND-A"]));
    const tx = parseOut(runDesk(e, ["transmit"]));
    assert.equal(tx.status, "requested");
    const rec = parseOut(runDesk(e, ["receive"]));
    assert.equal(rec.status, "received");
    const co = parseOut(runDesk(e, ["checkout"]));
    assert.equal(co.status, "out");
    assert.equal(co.checkout_ms, 1000);
    assert.equal(co.loan_until_ms, 1000 + 604800000);
    assert.equal(co.overdue, 0);
    const stLate = parseOut(runDesk(envFor(state, service_url, String(co.loan_until_ms + 1)), ["status"]));
    assert.equal(stLate.overdue, 1);
    const ci = parseOut(runDesk(e, ["checkin"]));
    assert.equal(ci.status, "returned");
    assert.equal(ci.overdue, 0);
    assert.equal(parseOut(runDesk(e, ["checkin"])).error, "already_returned");
    const effects = await (await fetch(`${control_url}/effects`)).json();
    assert.equal(effects.count, 1);
    parseOut(runDesk(e, ["transmit"]));
    const effects2 = await (await fetch(`${control_url}/effects`)).json();
    assert.equal(effects2.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("cancel filed and declare-lost", async () => {
  const a = tmpDir();
  const {child, service_url} = await startStub();
  try {
    const e = envFor(a, service_url);
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    const c = parseOut(runDesk(e, ["cancel"]));
    assert.equal(c.status, "cancelled");
    assert.equal(parseOut(runDesk(e, ["locate", "LEND-A"])).error, "bad_status");
    const b = tmpDir();
    const e2 = envFor(b, service_url, "1000");
    parseOut(runDesk(e2, ["file", "ILL-N", "PAT-N", "OCLC-N"]));
    parseOut(runDesk(e2, ["locate", "LEND-N"]));
    parseOut(runDesk(e2, ["transmit"]));
    parseOut(runDesk(e2, ["receive"]));
    parseOut(runDesk(e2, ["checkout"]));
    const lost = parseOut(runDesk(envFor(b, service_url, String(1000 + 1209600000 + 5)), ["declare-lost"]));
    assert.equal(lost.status, "lost");
  } finally {
    child.kill("SIGKILL");
  }
});

test("callback does not overwrite", async () => {
  const state = tmpDir();
  const {child, service_url} = await startStub();
  const e = envFor(state, service_url);
  try {
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    const cb = path.join(state, "cb.json");
    fs.writeFileSync(cb, JSON.stringify({hello: 1}));
    const ok = parseOut(runDesk(e, ["callback", cb]));
    assert.equal(ok.ok, true);
    const st = parseOut(runDesk(e, ["status"]));
    assert.equal(st.status, "filed");
    const bad = parseOut(runDesk(e, ["callback", path.join(state, "missing.json")]));
    assert.equal(bad.error, "bad_callback");
  } finally {
    child.kill("SIGKILL");
  }
});

test("unrelated files survive", async () => {
  const state = tmpDir();
  const {child, service_url} = await startStub();
  try {
    const other = path.join(state, "keep.bin");
    fs.writeFileSync(other, Buffer.from([1, 2, 3, 4]));
    parseOut(runDesk(envFor(state, service_url), ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    assert.deepEqual(fs.readFileSync(other), Buffer.from([1, 2, 3, 4]));
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash after-request-saved-before-request then recover", async () => {
  const state = tmpDir();
  const {child, service_url, control_url} = await startStub();
  const e = envFor(state, service_url);
  try {
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    parseOut(runDesk(e, ["locate", "LEND-A"]));
    const killed = runDesk({...e, CRASH_AT: "after-request-saved-before-request"}, ["transmit"]);
    assert.equal(killed.signal, "SIGKILL");
    const st = parseOut(runDesk(e, ["status"]));
    assert.equal(st.lender, "attempt_saved");
    assert.equal(st.status, "located");
    assert.ok(st.loan_req_id);
    const rec = parseOut(runDesk(e, ["reconcile", st.loan_req_id]));
    assert.equal(rec.lookup, "not_sent");
    const posts = await (await fetch(`${control_url}/posts`)).json();
    assert.equal(posts.count, 0);
    const tx = parseOut(runDesk(e, ["transmit"]));
    assert.equal(tx.status, "requested");
    assert.equal(tx.loan_req_id, st.loan_req_id);
    const effects = await (await fetch(`${control_url}/effects`)).json();
    assert.equal(effects.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash after-accept-before-record recovered by transmit", async () => {
  const state = tmpDir();
  const {child, service_url, control_url} = await startStub();
  const e = envFor(state, service_url);
  try {
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    parseOut(runDesk(e, ["locate", "LEND-A"]));
    const killed = runDesk({...e, CRASH_AT: "after-accept-before-record"}, ["transmit"]);
    assert.equal(killed.signal, "SIGKILL");
    const st = parseOut(runDesk(e, ["status"]));
    assert.equal(st.lender, "attempt_saved");
    const tx = parseOut(runDesk(e, ["transmit"]));
    assert.equal(tx.status, "requested");
    const effects = await (await fetch(`${control_url}/effects`)).json();
    assert.equal(effects.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash after-record-before-exit leaves accepted", async () => {
  const state = tmpDir();
  const {child, service_url} = await startStub();
  const e = envFor(state, service_url);
  try {
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    parseOut(runDesk(e, ["locate", "LEND-A"]));
    const killed = runDesk({...e, CRASH_AT: "after-record-before-exit"}, ["transmit"]);
    assert.equal(killed.signal, "SIGKILL");
    const st = parseOut(runDesk(e, ["status"]));
    assert.equal(st.status, "requested");
    assert.equal(st.lender, "accepted");
  } finally {
    child.kill("SIGKILL");
  }
});

test("dropped reply then reconcile", async () => {
  const state = tmpDir();
  const {child, service_url, control_url} = await startStub();
  const e = envFor(state, service_url);
  try {
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    parseOut(runDesk(e, ["locate", "LEND-A"]));
    await (await fetch(`${control_url}/fault`, {
      method: "POST",
      headers: {"content-type": "application/json"},
      body: JSON.stringify({drop_reply: true}),
    })).json();
    const r = parseOut(runDesk(e, ["transmit"]));
    assert.equal(r.error, "service_unavailable");
    const st = parseOut(runDesk(e, ["status"]));
    assert.equal(st.lender, "attempt_saved");
    await (await fetch(`${control_url}/fault`, {
      method: "POST",
      headers: {"content-type": "application/json"},
      body: JSON.stringify({drop_reply: false}),
    })).json();
    const rec = parseOut(runDesk(e, ["reconcile", st.loan_req_id]));
    assert.equal(rec.lookup, "accepted");
    assert.equal(rec.status, "requested");
    const effects = await (await fetch(`${control_url}/effects`)).json();
    assert.equal(effects.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("5xx leaves attempt_saved without lookup", async () => {
  const state = tmpDir();
  const {child, service_url, control_url} = await startStub();
  const e = envFor(state, service_url);
  try {
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    parseOut(runDesk(e, ["locate", "LEND-A"]));
    await (await fetch(`${control_url}/fault`, {
      method: "POST",
      headers: {"content-type": "application/json"},
      body: JSON.stringify({error_status: 503}),
    })).json();
    const r = parseOut(runDesk(e, ["transmit"]));
    assert.equal(r.error, "service_unavailable");
    const st = parseOut(runDesk(e, ["status"]));
    assert.equal(st.lender, "attempt_saved");
    const posts = await (await fetch(`${control_url}/posts`)).json();
    assert.equal(posts.count, 1);
    const effects = await (await fetch(`${control_url}/effects`)).json();
    assert.equal(effects.count, 0);
  } finally {
    child.kill("SIGKILL");
  }
});

test("bad identifier wins status and corrupt_state", async () => {
  const state = tmpDir();
  const {child, service_url} = await startStub();
  const e = envFor(state, service_url);
  try {
    assert.equal(parseOut(runDesk(e, ["locate", "bad id"])).error, "bad_args");
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    fs.writeFileSync(path.join(state, "ill-desk.sqlite"), "not a database");
    assert.equal(parseOut(runDesk(e, ["status"])).error, "corrupt_state");
  } finally {
    child.kill("SIGKILL");
  }
});

test("status gated commands", async () => {
  const state = tmpDir();
  const {child, service_url} = await startStub();
  const e = envFor(state, service_url);
  try {
    assert.equal(parseOut(runDesk(e, ["locate", "LEND-A"])).error, "bad_status");
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    assert.equal(parseOut(runDesk(e, ["receive"])).error, "bad_status");
    assert.equal(parseOut(runDesk(e, ["transmit"])).error, "bad_status");
    parseOut(runDesk(e, ["locate", "LEND-A"]));
    assert.equal(parseOut(runDesk(e, ["checkout"])).error, "bad_status");
    parseOut(runDesk(e, ["transmit"]));
    parseOut(runDesk(e, ["receive"]));
    assert.equal(parseOut(runDesk(e, ["checkin"])).error, "bad_status");
  } finally {
    child.kill("SIGKILL");
  }
});

function oldRun() {
  const dir = process.env.OLD_PROJECT_DIR || "/tmp/ill-desk-old-N13r1";
  return path.join(dir, "run");
}

function runOld(env, args) {
  return spawnSync(NODE, [oldRun(), ...args], {
    encoding: "utf8",
    env: {...process.env, ...env},
  });
}

test("C1 C3 place-recall and recall_required on new requests", async () => {
  const state = tmpDir();
  const {child, service_url, control_url} = await startStub();
  const e = envFor(state, service_url, "1000");
  try {
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    assert.equal(parseOut(runDesk(e, ["place-recall"])).error, "not_out");
    parseOut(runDesk(e, ["locate", "LEND-A"]));
    parseOut(runDesk(e, ["transmit"]));
    parseOut(runDesk(e, ["receive"]));
    const co = parseOut(runDesk(e, ["checkout"]));
    assert.equal(co.loan_until_ms, 1000 + 604800000);
    const late = String(co.loan_until_ms + 1);
    const blocked = parseOut(runDesk(envFor(state, service_url, late), ["checkin"]));
    assert.equal(blocked.error, "recall_required");
    const stillOut = parseOut(runDesk(envFor(state, service_url, late), ["status"]));
    assert.equal(stillOut.status, "out");
    assert.equal(stillOut.recall_placed, 0);
    const rec = parseOut(runDesk(envFor(state, service_url, late), ["place-recall"]));
    assert.equal(rec.recall_placed, 1);
    assert.equal(rec.status, "out");
    const again = parseOut(runDesk(envFor(state, service_url, late), ["place-recall"]));
    assert.equal(again.recall_placed, 1);
    const afterRestart = parseOut(runDesk(envFor(state, service_url, late), ["status"]));
    assert.equal(afterRestart.recall_placed, 1);
    const ci = parseOut(runDesk(envFor(state, service_url, late), ["checkin"]));
    assert.equal(ci.status, "returned");
    const effects = await (await fetch(`${control_url}/effects`)).json();
    assert.equal(effects.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("C2 C4 legacy_request and 14-day span", async () => {
  const state = tmpDir();
  const {child, service_url} = await startStub();
  try {
    const e = envFor(state, service_url, "1000");
    parseOut(runOld(e, ["file", "ILL-O", "PAT-O", "OCLC-O"]));
    assert.equal(parseOut(runDesk(e, ["place-recall"])).error, "legacy_request");
    parseOut(runDesk(e, ["locate", "LEND-O"]));
    parseOut(runDesk(e, ["transmit"]));
    parseOut(runDesk(e, ["receive"]));
    const co = parseOut(runDesk(e, ["checkout"]));
    assert.equal(co.loan_until_ms, 1000 + 1209600000);
    const late = String(co.loan_until_ms + 1);
    assert.equal(parseOut(runDesk(envFor(state, service_url, late), ["place-recall"])).error, "legacy_request");
    const st = parseOut(runDesk(envFor(state, service_url, late), ["status"]));
    assert.equal(st.recall_placed, 0);
    assert.equal(st.status, "out");
    const ci = parseOut(runDesk(envFor(state, service_url, late), ["checkin"]));
    assert.equal(ci.status, "returned");
    assert.notEqual(ci.error, "recall_required");
  } finally {
    child.kill("SIGKILL");
  }
});

test("C5 recovery still holds after place-recall path on a sibling new request", async () => {
  const state = tmpDir();
  const {child, service_url, control_url} = await startStub();
  const e = envFor(state, service_url);
  try {
    parseOut(runDesk(e, ["file", "ILL-1", "PAT-9", "OCLC-42"]));
    parseOut(runDesk(e, ["locate", "LEND-A"]));
    const killed = runDesk({...e, CRASH_AT: "after-request-saved-before-request"}, ["transmit"]);
    assert.equal(killed.signal, "SIGKILL");
    const st = parseOut(runDesk(e, ["status"]));
    assert.equal(parseOut(runDesk(e, ["cancel"])).error, "loan_started");
    const tx = parseOut(runDesk(e, ["transmit"]));
    assert.equal(tx.status, "requested");
    assert.equal(tx.loan_req_id, st.loan_req_id);
    const effects = await (await fetch(`${control_url}/effects`)).json();
    assert.equal(effects.count, 1);
    parseOut(runDesk(e, ["receive"]));
    const co = parseOut(runDesk(e, ["checkout"]));
    assert.equal(co.loan_until_ms, 1000 + 604800000);
    parseOut(runDesk(e, ["place-recall"]));
    const st2 = parseOut(runDesk(e, ["status"]));
    assert.equal(st2.recall_placed, 1);
  } finally {
    child.kill("SIGKILL");
  }
});
