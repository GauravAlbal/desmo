# Interlibrary loan request desk

Durable local desk for one ILL request. Lifecycle lives in Ikaros (`machines/ill_desk.ik.toml`); HTTP and the CLI are the host.

## Setup

Node 22 is required (`<home>/.nvm/versions/node/v22.17.1/bin/node` on this machine).

```bash
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

## Run

Start the fake lender (prints `service_url`):

```bash
node stub/server.mjs
```

```bash
export STATE_DIR=/tmp/ill-desk
export SERVICE_URL='http://127.0.0.1:<port>'
export NOW_MS=1000
./run status
./run file ILL-1 PAT-9 OCLC-42
./run locate LEND-A
./run transmit
./run receive
./run checkout
./run checkin
```

`./run` prints one JSON object. Optional `CRASH_AT` labels: `after-request-saved-before-request`, `after-accept-before-record`, `after-record-before-exit`.

## Tests

```bash
node --test tests/ill.test.mjs
```
