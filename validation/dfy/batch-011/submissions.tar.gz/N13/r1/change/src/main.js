import {runCommand, AppError} from "./desk.js";

function fail(code) {
  process.stdout.write(JSON.stringify({error: code}) + "\n");
  process.exit(1);
}

try {
  const out = await runCommand(process.env, process.argv.slice(2));
  process.stdout.write(JSON.stringify(out) + "\n");
} catch (err) {
  if (err instanceof AppError) fail(err.code);
  const msg = String(err && err.message ? err.message : err);
  if (msg.includes("corrupt") || (err && err.code === "IK_STORE_CORRUPT")) fail("corrupt_state");
  fail("bad_args");
}
