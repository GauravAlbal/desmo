import {createHash, randomBytes} from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";
import {
  Kernel,
  StoreNotFoundError,
  classify,
  HistoricalResult,
} from "@ikaros/runtime";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
export const MACHINE_V1_PATH = path.join(ROOT, "..", "machines", "ill_desk.ik.toml");
export const MACHINE_V2_PATH = path.join(ROOT, "..", "machines", "ill_desk_v2.ik.toml");
export const MACHINE_PATH = MACHINE_V2_PATH;
const AGG = "desk";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const LOAN_SPAN_LEGACY = 1209600000n;
const LOAN_SPAN_NEW = 604800000n;
const MAX_NOW = 9007199254740991n;

export class AppError extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
}

export function parseNowMs(raw) {
  if (raw === undefined || raw === null || raw === "") throw new AppError("bad_time");
  if (!/^[0-9]+$/.test(raw)) throw new AppError("bad_time");
  const v = BigInt(raw);
  if (v < 0n || v > MAX_NOW) throw new AppError("bad_time");
  return v;
}

export function requireId(v) {
  if (typeof v !== "string" || !ID_RE.test(v)) throw new AppError("bad_args");
  return v;
}

function storePath(stateDir) {
  return path.join(stateDir, "ill-desk.sqlite");
}

function crash(label) {
  if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL");
}

function factsOf(agg) {
  const st = agg.state && typeof agg.state === "object" ? agg.state : {};
  const facts = st.facts && typeof st.facts === "object" ? st.facts : st;
  return facts || {};
}

function named(agg) {
  if (typeof agg.namedState === "function") {
    const n = agg.namedState();
    if (n) return n;
  }
  const st = agg.state;
  if (typeof st === "string") return st;
  if (st && typeof st.name === "string") return st.name;
  if (st && typeof st.state === "string") return st.state;
  return "idle";
}

function strFact(facts, key) {
  const v = facts[key];
  if (v === undefined || v === null || v === "") return null;
  return String(v);
}

function intFact(facts, key) {
  const v = facts[key];
  if (v === undefined || v === null || v === "") return null;
  return Number(v);
}

export function statusPayload(agg, nowMs) {
  if (!agg) {
    return {
      req_id: null,
      patron_id: null,
      oclc: null,
      lender_id: null,
      status: "none",
      lender: "none",
      loan_req_id: null,
      checkout_ms: null,
      loan_until_ms: null,
      overdue: 0,
      recall_placed: 0,
    };
  }
  const facts = factsOf(agg);
  let status = named(agg);
  if (status === "idle") status = "none";
  const loanUntil = intFact(facts, "loan_until_ms");
  const overdue = status === "out" && loanUntil !== null && nowMs > BigInt(loanUntil) ? 1 : 0;
  return {
    req_id: strFact(facts, "req_id"),
    patron_id: strFact(facts, "patron_id"),
    oclc: strFact(facts, "oclc"),
    lender_id: strFact(facts, "lender_id"),
    status,
    lender: strFact(facts, "lender") || "none",
    loan_req_id: strFact(facts, "loan_req_id"),
    checkout_ms: intFact(facts, "checkout_ms"),
    loan_until_ms: loanUntil,
    overdue,
    recall_placed: intFact(facts, "recall_placed") === 1 ? 1 : 0,
  };
}

function isLegacy(agg) {
  if (!agg || !agg.owner) return false;
  return Number(agg.owner.version) === 1;
}

function loanSpan(agg) {
  return isLegacy(agg) ? LOAN_SPAN_LEGACY : LOAN_SPAN_NEW;
}

function mapKernel(err) {
  if (err instanceof AppError) throw err;
  const cls = classify(err);
  if (cls === "corrupt") throw new AppError("corrupt_state");
  throw err;
}

async function openMachines(stateDir) {
  const kernel = new Kernel(storePath(stateDir));
  const v1 = await kernel.machine(MACHINE_V1_PATH);
  const v2 = await kernel.machine(MACHINE_V2_PATH);
  return {kernel, v1, v2};
}

function owningMachine(agg, v1, v2) {
  if (!agg) return v2;
  if (agg.owner.equals(v1.identity)) return v1;
  if (agg.owner.equals(v2.identity)) return v2;
  throw new AppError("corrupt_state");
}

async function showDesk(stateDir) {
  try {
    if (!fs.existsSync(storePath(stateDir))) return null;
    const {v1, v2} = await openMachines(stateDir);
    try {
      const probe = await v2.show(AGG);
      const machine = owningMachine(probe, v1, v2);
      if (machine === v2) return probe;
      return await machine.show(AGG);
    } catch (err) {
      const cls = classify(err);
      if (err instanceof StoreNotFoundError || cls === "not_found") return null;
      if (cls === "corrupt") throw new AppError("corrupt_state");
      throw err;
    }
  } catch (err) {
    mapKernel(err);
  }
}

async function apply(agg, name, args) {
  try {
    const result = await agg.command(name, args);
    if (result instanceof HistoricalResult) {
      return await agg.machine.show(AGG);
    }
    return result;
  } catch (err) {
    const cls = classify(err);
    if (cls === "corrupt") throw new AppError("corrupt_state");
    throw err;
  }
}

function digestSnapshot(loanReqId, reqId, lenderId, oclc) {
  return createHash("sha256")
    .update(JSON.stringify({loan_req_id: loanReqId, req_id: reqId, lender_id: lenderId, oclc}))
    .digest("hex");
}

function newLoanId() {
  return `LR-${randomBytes(12).toString("hex")}`;
}

async function httpCall(serviceUrl, method, pathname, body) {
  const url = `${serviceUrl.replace(/\/$/, "")}${pathname}`;
  try {
    const res = await fetch(url, {
      method,
      headers: body ? {"content-type": "application/json"} : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      throw new AppError("service_unavailable");
    }
    return {status: res.status, json};
  } catch (err) {
    if (err instanceof AppError) throw err;
    throw new AppError("service_unavailable");
  }
}

function matchingLoan(json, snap) {
  return json
    && json.loan_req_id === snap.loan_req_id
    && json.req_id === snap.req_id
    && json.lender_id === snap.lender_id
    && json.oclc === snap.oclc;
}

function transmitSuccess(snap) {
  return {
    req_id: snap.req_id,
    loan_req_id: snap.loan_req_id,
    lender_id: snap.lender_id,
    oclc: snap.oclc,
    status: "requested",
    lender: "accepted",
  };
}

async function recordIfPending(agg, outcomeDigest) {
  if (!agg.pendingIntent) return agg;
  const result = await agg.recordEffectOutcome(outcomeDigest);
  if (result instanceof HistoricalResult) return await agg.machine.show(AGG);
  return result;
}

async function acceptLoan(agg) {
  let cur = agg;
  if (cur.pendingIntent) {
    cur = await recordIfPending(cur, cur.pendingIntent.payloadDigest);
  }
  return apply(cur, "accept", {lender: "accepted"});
}

export async function runCommand(env, argv) {
  const nowMs = parseNowMs(env.NOW_MS);
  const stateDir = env.STATE_DIR;
  const serviceUrl = env.SERVICE_URL;
  if (!stateDir || !serviceUrl) throw new AppError("bad_args");
  const cmd = argv[0];
  if (!cmd) throw new AppError("bad_args");

  const known = new Set([
    "file", "locate", "transmit", "receive", "checkout", "checkin",
    "declare-lost", "cancel", "reconcile", "status", "callback", "place-recall",
  ]);
  if (!known.has(cmd)) throw new AppError("bad_args");

  if (cmd === "callback") {
    const p = argv[1];
    if (!p) throw new AppError("bad_args");
    let raw;
    try {
      raw = fs.readFileSync(p, "utf8");
    } catch {
      throw new AppError("bad_callback");
    }
    try {
      JSON.parse(raw);
    } catch {
      throw new AppError("bad_callback");
    }
    return {ok: true};
  }

  if (cmd === "file") {
    const reqId = requireId(argv[1]);
    const patronId = requireId(argv[2]);
    const oclc = requireId(argv[3]);
    const existing = await showDesk(stateDir);
    if (existing && named(existing) !== "idle") throw new AppError("already_filed");
    fs.mkdirSync(stateDir, {recursive: true});
    const {kernel, v2} = await openMachines(stateDir);
    try {
      const created = await v2.createWith({
        aggregateId: AGG,
        command: {name: "file", args: {req_id: reqId, patron_id: patronId, oclc}},
        operationId: kernel.newOperationId(),
      });
      const agg = created instanceof HistoricalResult ? await machine.show(AGG) : created;
      return {req_id: reqId, patron_id: patronId, oclc, status: "filed", lender: "none", loan_req_id: null};
    } catch (err) {
      if (classify(err) === "corrupt") throw new AppError("corrupt_state");
      const again = await showDesk(stateDir);
      if (again && named(again) !== "idle") throw new AppError("already_filed");
      throw err;
    }
  }

  if (cmd === "status") {
    const agg = await showDesk(stateDir);
    return statusPayload(agg, nowMs);
  }

  const desk = await showDesk(stateDir);
  const st = statusPayload(desk, nowMs);

  if (cmd === "place-recall") {
    if (desk && isLegacy(desk)) throw new AppError("legacy_request");
    if (!desk || st.status !== "out") throw new AppError("not_out");
    if (st.recall_placed === 1) {
      return {
        req_id: st.req_id,
        status: "out",
        recall_placed: 1,
        loan_until_ms: st.loan_until_ms,
        overdue: st.overdue,
      };
    }
    const next = await apply(desk, "place_recall", {recall_placed: 1});
    const after = statusPayload(next, nowMs);
    return {
      req_id: after.req_id,
      status: "out",
      recall_placed: 1,
      loan_until_ms: after.loan_until_ms,
      overdue: after.overdue,
    };
  }

  if (cmd === "locate") {
    const lenderId = requireId(argv[1]);
    if (!desk || st.status === "none") throw new AppError("bad_status");
    if (st.status === "located") throw new AppError("already_located");
    if (st.status !== "filed") throw new AppError("bad_status");
    await apply(desk, "locate", {lender_id: lenderId});
    return {req_id: st.req_id, lender_id: lenderId, status: "located"};
  }

  if (cmd === "receive") {
    if (!desk) throw new AppError("bad_status");
    if (st.lender === "attempt_saved") throw new AppError("loan_pending");
    if (st.status === "received") throw new AppError("already_received");
    if (st.status !== "requested" || st.lender !== "accepted") throw new AppError("bad_status");
    await apply(desk, "receive", {});
    return {req_id: st.req_id, status: "received"};
  }

  if (cmd === "checkout") {
    if (!desk) throw new AppError("bad_status");
    if (st.status === "out") throw new AppError("already_out");
    if (st.status !== "received") throw new AppError("bad_status");
    const checkoutMs = Number(nowMs);
    const loanUntil = Number(nowMs + loanSpan(desk));
    await apply(desk, "checkout", {checkout_ms: checkoutMs, loan_until_ms: loanUntil});
    return {req_id: st.req_id, status: "out", checkout_ms: checkoutMs, loan_until_ms: loanUntil, overdue: 0};
  }

  if (cmd === "checkin") {
    if (!desk) throw new AppError("bad_status");
    if (st.status === "returned") throw new AppError("already_returned");
    if (st.status !== "out") throw new AppError("bad_status");
    const overdue = st.loan_until_ms !== null && nowMs > BigInt(st.loan_until_ms) ? 1 : 0;
    if (!isLegacy(desk) && overdue === 1 && st.recall_placed !== 1) {
      throw new AppError("recall_required");
    }
    await apply(desk, "checkin", {});
    return {req_id: st.req_id, status: "returned", overdue};
  }

  if (cmd === "declare-lost") {
    if (!desk) throw new AppError("bad_status");
    if (st.status === "lost") throw new AppError("already_lost");
    if (st.status === "returned") throw new AppError("already_returned");
    if (st.status !== "out") throw new AppError("bad_status");
    await apply(desk, "declare_lost", {});
    return {req_id: st.req_id, status: "lost"};
  }

  if (cmd === "cancel") {
    if (!desk) throw new AppError("bad_status");
    if (st.status === "cancelled") throw new AppError("already_cancelled");
    if (st.lender === "accepted" || st.status === "requested") throw new AppError("already_requested");
    if (st.lender === "attempt_saved") throw new AppError("loan_started");
    if (st.status !== "filed" && st.status !== "located") throw new AppError("bad_status");
    await apply(desk, "cancel", {});
    return {req_id: st.req_id, status: "cancelled"};
  }

  if (cmd === "reconcile") {
    const loanReqId = requireId(argv[1]);
    if (!desk || !st.loan_req_id) throw new AppError("no_loan");
    if (st.loan_req_id !== loanReqId) throw new AppError("loan_mismatch");
    if (st.lender === "accepted" && st.status === "requested") {
      return {...transmitSuccess({
        req_id: st.req_id, loan_req_id: st.loan_req_id, lender_id: st.lender_id, oclc: st.oclc,
      }), lookup: "accepted"};
    }
    const got = await httpCall(serviceUrl, "GET", `/v1/ill-loans/${encodeURIComponent(loanReqId)}`);
    if (got.status === 404) {
      return {lookup: "not_sent", req_id: st.req_id, loan_req_id: loanReqId, lender: "attempt_saved", status: "located"};
    }
    if (got.status !== 200) throw new AppError("service_unavailable");
    const snap = {loan_req_id: st.loan_req_id, req_id: st.req_id, lender_id: st.lender_id, oclc: st.oclc};
    if (!matchingLoan(got.json, snap)) throw new AppError("lookup_conflict");
    if (st.status === "located" && st.lender === "attempt_saved") {
      await acceptLoan(desk);
    }
    return {...transmitSuccess(snap), lookup: "accepted"};
  }

  if (cmd === "transmit") {
    if (!desk) throw new AppError("bad_status");
    if (st.status === "filed" || st.status === "none") throw new AppError("bad_status");
    if (["received", "out", "returned", "lost", "cancelled"].includes(st.status)) {
      throw new AppError("bad_status");
    }
    if (st.lender === "accepted" && st.status === "requested") {
      return transmitSuccess({
        req_id: st.req_id, loan_req_id: st.loan_req_id, lender_id: st.lender_id, oclc: st.oclc,
      });
    }
    if (st.status !== "located") throw new AppError("bad_status");

    let agg = desk;
    let loanReqId = st.loan_req_id;
    let saved = st.lender === "attempt_saved";
    const snapBase = () => ({
      loan_req_id: loanReqId,
      req_id: st.req_id,
      lender_id: st.lender_id,
      oclc: st.oclc,
    });

    if (saved) {
      const got = await httpCall(serviceUrl, "GET", `/v1/ill-loans/${encodeURIComponent(loanReqId)}`);
      if (got.status === 200) {
        if (!matchingLoan(got.json, snapBase())) throw new AppError("lookup_conflict");
        crash("after-accept-before-record");
        agg = await acceptLoan(agg);
        crash("after-record-before-exit");
        return transmitSuccess(snapBase());
      }
      if (got.status !== 404) throw new AppError("service_unavailable");
      const post = await httpCall(serviceUrl, "POST", "/v1/ill-loans", snapBase());
      if (post.status >= 500 || post.status === 0) throw new AppError("service_unavailable");
      if (post.status === 409) throw new AppError("lookup_conflict");
      if (post.status !== 200 || !matchingLoan(post.json, snapBase())) {
        if (post.status !== 200) throw new AppError("service_unavailable");
        throw new AppError("lookup_conflict");
      }
      crash("after-accept-before-record");
      agg = await acceptLoan(agg);
      crash("after-record-before-exit");
      return transmitSuccess(snapBase());
    }

    loanReqId = newLoanId();
    const payloadDigest = digestSnapshot(loanReqId, st.req_id, st.lender_id, st.oclc);
    agg = await apply(agg, "save_attempt", {
      loan_req_id: loanReqId,
      payload_digest: payloadDigest,
      lender: "attempt_saved",
    });
    crash("after-request-saved-before-request");
    const body = snapBase();
    let post;
    try {
      post = await httpCall(serviceUrl, "POST", "/v1/ill-loans", body);
    } catch (err) {
      if (err instanceof AppError && err.code === "service_unavailable") throw err;
      throw new AppError("service_unavailable");
    }
    if (post.status >= 500) throw new AppError("service_unavailable");
    if (post.status !== 200) {
      if (post.status === 409) throw new AppError("lookup_conflict");
      throw new AppError("service_unavailable");
    }
    if (!matchingLoan(post.json, body)) throw new AppError("lookup_conflict");
    crash("after-accept-before-record");
    agg = await acceptLoan(agg);
    crash("after-record-before-exit");
    return transmitSuccess(body);
  }

  throw new AppError("bad_args");
}
