# Interlibrary loan request desk

The program behind `./run` is a durable local desk for one interlibrary loan request. A patron request is filed, a lender library is located, the request is sent to that lender through one external lender API, the lender ships, the desk records receipt, the patron checks the item out, and the item is returned or declared lost. Loan periods and the overdue flag are computed from `NOW_MS`. A lender request has an application-created id saved before the HTTP request; recovery looks up that id before any retry.

## Scope and invocation

One machine and one process at a time. At most one request is bound to a state directory. An unrelated writer may create or modify other files in `STATE_DIR`; those files must survive byte-for-byte. The tool may keep its durable files in `STATE_DIR` under any names. It must use `STATE_DIR`, `SERVICE_URL`, `NOW_MS`, and optional `CRASH_AT`. `SERVICE_URL` is required for every command, including status (status never contacts it). `NOW_MS` is a required non-negative integer epoch-millisecond clock for every command.

`./run <command> [args]` prints exactly one JSON object and nothing else (one trailing newline is allowed). Exit 0 is success. Refusals are nonzero and print `{ "error": "<code>" }`. Identifiers (`req_id`, `patron_id`, `oclc`, `lender_id`, `loan_req_id`) are 1–64 characters matching `A-Za-z0-9._-`. `CRASH_AT` labels are:

* `after-request-saved-before-request`: after saving a loan request id and its snapshot, before sending a request;
* `after-accept-before-record`: after reading a complete successful provider response, before saving the accepted-lender record;
* `after-record-before-exit`: after saving the accepted-lender record, before success JSON is written.

A process must kill itself with SIGKILL at a reached label. Durable commits are flushed before the command treats them as committed. A malformed owned state file is `corrupt_state` and is not rewritten. Refusals do not modify state except that a transmit path named below may durably record a saved lender-request attempt.

## Clock, environment, and precedence

Missing or non-canonical `NOW_MS` (not a decimal integer in `0` through `9007199254740991`) is `bad_time` and wins every other refusal. Missing `STATE_DIR` or missing `SERVICE_URL` is `bad_args`. An unknown command is `bad_args`. Identifier parse failures are `bad_args` and win status-gated codes on the same invocation. When two domain refusals could apply, the code named first in that command's paragraph wins.

## Commands

`file <req_id> <patron_id> <oclc>` binds the empty-or-idle desk to one request and returns `{req_id,patron_id,oclc,status:"filed",lender:"none",loan_req_id:null}`. A second file is `already_filed`. It never contacts the provider.

`locate <lender_id>` is valid only for `filed`. It records the lender and returns `{req_id,lender_id,status:"located"}`. A second locate on an already `located` request is `already_located`. Any other status is `bad_status`. It never contacts the provider.

`transmit` is valid for `located` when no lender request is accepted yet. Before a saved attempt, it increments nothing locally except a generated `loan_req_id` and its exact snapshot (`req_id`, `lender_id`, `oclc`), then posts once. A matching successful response sets `lender:"accepted"` and `status:"requested"` and returns `{req_id,loan_req_id,lender_id,oclc,status:"requested",lender:"accepted"}`. Repeating `transmit` after `lender:"accepted"` is a success no-op without a provider call. Connection failure, an incomplete response, or HTTP 5xx leaves `lender:"attempt_saved"`, keeps `status:"located"`, and returns `service_unavailable`; that invocation does not lookup. `filed` or `none` is `bad_status`. `received`, `out`, `returned`, `lost`, or `cancelled` is `bad_status`.

If a saved attempt exists, `transmit` first `GET /v1/ill-loans/<loan_req_id>`: a matching 200 is adopted without POST; a 404 causes one POST with the saved id only. Never allocate a replacement id. A mismatching success is `lookup_conflict` and changes nothing.

`receive` is valid only for `requested` with `lender:"accepted"`. It returns `{req_id,status:"received"}`. `lender:"attempt_saved"` is `loan_pending`. A second receive is `already_received`. Any other status is `bad_status`. It never contacts the provider.

`checkout` is valid only for `received`. It records `checkout_ms` as the current `NOW_MS` and a loan span of `1209600000` milliseconds (14 days). `loan_until_ms` is `checkout_ms + 1209600000`. It returns `{req_id,status:"out",checkout_ms,loan_until_ms,overdue:0}`. A second checkout is `already_out`. Any other status is `bad_status`. It never contacts the provider.

`checkin` is valid only for `out`. In this initial contract it succeeds even when `NOW_MS > loan_until_ms`. It returns `{req_id,status:"returned",overdue}` where `overdue` is `1` if `NOW_MS > loan_until_ms` else `0`. A second checkin is `already_returned`. Any other status is `bad_status`. It never contacts the provider.

`declare-lost` is valid only for `out`, including when overdue. It returns `{req_id,status:"lost"}`. A second call is `already_lost`. `returned` is `already_returned`. Any other status is `bad_status`. It never contacts the provider.

`cancel` is allowed for `filed` or `located` when `lender` is not `attempt_saved`. It returns `{req_id,status:"cancelled"}` and never contacts the provider. An in-flight lender request is `loan_started` and preserves the id and snapshot. `lender:"accepted"` (status `requested`) is `already_requested`. `cancelled` is `already_cancelled`. `received`, `out`, `returned`, or `lost` is `bad_status`.

`reconcile <loan_req_id>` never POSTs or allocates. No saved lender request is `no_loan`; another id is `loan_mismatch`. Lookup 200 with matching ids, `req_id`, `lender_id`, and `oclc` commits the accepted-lender state and returns the transmit success object plus `lookup:"accepted"`; 404 returns exit 0 `{lookup:"not_sent",req_id,loan_req_id,lender:"attempt_saved",status:"located"}`; a mismatch is `lookup_conflict`; transport failure is `service_unavailable`.

`status` never contacts the provider and returns `{req_id,patron_id,oclc,lender_id,status,lender,loan_req_id,checkout_ms,loan_until_ms,overdue,recall_placed}`. Empty fields are null, with `status:"none"`, `lender:"none"`, `overdue:0`, `recall_placed:0`. `overdue` is `1` only when `status` is `out` and `NOW_MS > loan_until_ms`; otherwise `0`. `recall_placed` is `0` in this initial contract. `loan_until_ms` is null until checkout.

Example identifiers used in this contract: `req_id` values `ILL-1`, `ILL-O`, `ILL-N`; `patron_id` values `PAT-9`, `PAT-O`, `PAT-N`; `oclc` values `OCLC-42`, `OCLC-O`, `OCLC-N`; `lender_id` values `LEND-A`, `LEND-O`, `LEND-N`. A checkout issued at `NOW_MS` 1000 records `checkout_ms` 1000.

`callback <path>` reads one JSON callback. It must not POST or allocate. A malformed callback is `bad_callback`. A well-formed callback is ignored and returns `{ok:true}`. It must never overwrite filed, located, requested, received, out, returned, lost, or cancelled state.

## Provider

The supplied service has `POST /v1/ill-loans` and `GET /v1/ill-loans/<loan_req_id>`. POST requires JSON with `loan_req_id`, `req_id`, `lender_id`, and `oclc`. A first valid id records one effect and returns those fields plus `outcome:"accepted"`. Repeating the same id with identical fields returns the same object without another effect; any differing field is HTTP 409. Unknown lookup is 404 `{error:"not_found"}`. Invalid bodies are 400. A configured 5xx stores nothing. The provider may drop a successful reply after storing it or delay a reply. Control endpoints are not part of this contract.

## Requirements

R1. File and every later committed record survive new processes, including a lender-request attempt killed at `after-request-saved-before-request`.

R2. `file` validates identifiers, persists the triple, and refuses a second bind with `already_filed`. `locate` records `lender_id` only from `filed`.

R3. `checkout` records `checkout_ms = NOW_MS` and `loan_until_ms > NOW_MS` with `overdue:0`. Advancing `NOW_MS` past `loan_until_ms` while still `out` makes `status.overdue` equal `1`. `checkin` at checkout time (not overdue) returns `status:"returned"`.

R4. `cancel` from `filed` is terminal (`cancelled`); later `locate` is `bad_status`. `declare-lost` from `out` is terminal (`lost`), including when overdue. A second `checkin` after a successful return is `already_returned`.

R5. A successful `transmit` records exactly one provider effect. Repeating `transmit` after `lender:"accepted"` does not add an effect.

R6. A well-formed `callback` does not overwrite requested/accepted (or any other) desk state.

R7. Status-gated commands (`locate` on `none`, `receive` on `filed`, `checkout` on `located`, `checkin` on `received`, `transmit` on `filed`) return `bad_status` and do not contact the provider.

R8. A kill at `after-request-saved-before-request` leaves `lender:"attempt_saved"` and the saved `loan_req_id`. A later `transmit` recovers that same id; provider effect count is 1.

R9. A kill at `after-accept-before-record` is recovered by a later `transmit` or `reconcile` using the saved id; provider effect count is 1.

R10. A kill at `after-record-before-exit` leaves `status:"requested"` and `lender:"accepted"` for a new process.

R11. A dropped successful reply returns `service_unavailable` with `lender:"attempt_saved"`. Later `reconcile` of the saved id returns `lookup:"accepted"` and does not create a second effect.

R12. `reconcile` never POSTs. After a pre-request crash, `reconcile` of the saved id returns `lookup:"not_sent"` with zero POSTs in that invocation.

R13. Unrelated files in `STATE_DIR` survive byte-for-byte.

R14. The program prints one JSON object, requires `NOW_MS` (`bad_time` when missing) and `SERVICE_URL`, and binds at most one request (`already_filed`). `status` on an empty desk is `{req_id:null,patron_id:null,oclc:null,lender_id:null,status:"none",lender:"none",loan_req_id:null,checkout_ms:null,loan_until_ms:null,overdue:0,recall_placed:0}`.
