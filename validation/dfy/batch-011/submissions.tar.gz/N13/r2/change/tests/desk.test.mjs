import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import {
  mkdirSync,
  mkdtempSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node";
const RUN = join(ROOT, "run");
const OLD_RUN = join("/tmp/ill-desk-old-N13r2", "run");
const STUB = join(ROOT, "stub", "server.mjs");
const SPAN_V2 = 604800000;
const SPAN_V1 = 1209600000;

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [STUB], { cwd: ROOT, stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    child.stdout.on("data", (c) => {
      buf += c;
      const line = buf.split("\n").find(Boolean);
      if (line) {
        try {
          resolve({ child, ...JSON.parse(line) });
        } catch (e) {
          reject(e);
        }
      }
    });
    child.on("error", reject);
  });
}

async function stopStub(s) {
  s.child.kill("SIGKILL");
}

function runWith(bin, env, args) {
  const r = spawnSync(bin, args, {
    env: { ...process.env, ...env },
    encoding: "utf8",
    cwd: ROOT,
  });
  let json = null;
  try {
    json = JSON.parse((r.stdout || "").trim());
  } catch {
    json = null;
  }
  return { status: r.status, signal: r.signal, stdout: r.stdout, stderr: r.stderr, json };
}

function run(env, args) {
  return runWith(RUN, env, args);
}

function runOld(env, args) {
  return runWith(OLD_RUN, env, args);
}

function deskEnv(stateDir, serviceUrl, now, extra = {}) {
  return {
    STATE_DIR: stateDir,
    SERVICE_URL: serviceUrl,
    NOW_MS: String(now),
    ...extra,
  };
}

async function withStub(fn) {
  const s = await startStub();
  try {
    return await fn(s);
  } finally {
    await stopStub(s);
  }
}

function tmpState() {
  const d = mkdtempSync(join(tmpdir(), "ill-"));
  writeFileSync(join(d, "unrelated.txt"), "keep-me-byte-for-byte");
  return d;
}

async function fault(controlUrl, body) {
  await fetch(`${controlUrl}/fault`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function effects(controlUrl) {
  const r = await fetch(`${controlUrl}/effects`);
  return r.json();
}

async function posts(controlUrl) {
  const r = await fetch(`${controlUrl}/posts`);
  return r.json();
}

test("bad_time wins", () => {
  const r = run({ STATE_DIR: "/tmp", SERVICE_URL: "http://127.0.0.1:1" }, ["status"]);
  assert.equal(r.json.error, "bad_time");
  assert.notEqual(r.status, 0);
});

test("empty status", () => {
  const d = tmpState();
  const r = run(deskEnv(d, "http://127.0.0.1:1", 0), ["status"]);
  assert.equal(r.status, 0);
  assert.deepEqual(r.json, {
    req_id: null,
    patron_id: null,
    oclc: null,
    lender_id: null,
    status: "none",
    lender: "none",
    loan_req_id: null,
    checkout_ms: null,
    loan_until_ms: null,
    overdue: 0,
    recall_placed: 0,
  });
});

test("file locate checkout checkin overdue cancel lost restart", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = (n) => deskEnv(d, s.service_url, n);
    const f = run(env(0), ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    assert.equal(f.json.status, "filed");
    const again = run(env(0), ["file", "ILL-O", "PAT-O", "OCLC-O"]);
    assert.equal(again.json.error, "already_filed");
    assert.equal(run(env(0), ["locate", "LEND-A"]).json.status, "located");
    assert.equal(run(env(0), ["locate", "LEND-N"]).json.error, "already_located");
    const tx = run(env(0), ["transmit"]);
    assert.equal(tx.json.status, "requested");
    assert.equal(tx.json.lender, "accepted");
    const tx2 = run(env(0), ["transmit"]);
    assert.equal(tx2.json.status, "requested");
    assert.equal((await effects(s.control_url)).count, 1);
    assert.equal(run(env(0), ["receive"]).json.status, "received");
    const co = run(env(1000), ["checkout"]);
    assert.equal(co.json.checkout_ms, 1000);
    assert.equal(co.json.loan_until_ms, 1000 + SPAN_V2);
    assert.equal(co.json.overdue, 0);
    const stOut = run(env(1000 + SPAN_V2 + 1), ["status"]);
    assert.equal(stOut.json.overdue, 1);
    assert.equal(stOut.json.status, "out");
    const d2 = tmpState();
    // process restart on same dir
    const st2 = run(env(1000), ["status"]);
    assert.equal(st2.json.status, "out");
    const ci = run(env(1000), ["checkin"]);
    assert.equal(ci.json.status, "returned");
    assert.equal(ci.json.overdue, 0);
    assert.equal(run(env(1000), ["checkin"]).json.error, "already_returned");

    const dLost = tmpState();
    run(deskEnv(dLost, s.service_url, 0), ["file", "ILL-N", "PAT-N", "OCLC-N"]);
    run(deskEnv(dLost, s.service_url, 0), ["locate", "LEND-N"]);
    run(deskEnv(dLost, s.service_url, 0), ["transmit"]);
    run(deskEnv(dLost, s.service_url, 0), ["receive"]);
    run(deskEnv(dLost, s.service_url, 5), ["checkout"]);
    assert.equal(run(deskEnv(dLost, s.service_url, 9e15), ["declare-lost"]).json.status, "lost");

    const dC = tmpState();
    run(deskEnv(dC, s.service_url, 0), ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    assert.equal(run(deskEnv(dC, s.service_url, 0), ["cancel"]).json.status, "cancelled");
    assert.equal(run(deskEnv(dC, s.service_url, 0), ["locate", "LEND-A"]).json.error, "bad_status");
  });
});

test("status-gated commands do not contact provider", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = deskEnv(d, s.service_url, 0);
    assert.equal(run(env, ["locate", "LEND-A"]).json.error, "bad_status");
    run(env, ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    assert.equal(run(env, ["receive"]).json.error, "bad_status");
    assert.equal(run(env, ["transmit"]).json.error, "bad_status");
    run(env, ["locate", "LEND-A"]);
    assert.equal(run(env, ["checkout"]).json.error, "bad_status");
    run(env, ["transmit"]);
    run(env, ["receive"]);
    assert.equal(run(env, ["checkin"]).json.error, "bad_status");
    const p = await posts(s.control_url);
    assert.equal(p.count, 1);
  });
});

test("callback does not overwrite", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = deskEnv(d, s.service_url, 0);
    run(env, ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    run(env, ["locate", "LEND-A"]);
    run(env, ["transmit"]);
    const cb = join(d, "cb.json");
    writeFileSync(cb, JSON.stringify({ hello: true }));
    const r = run(env, ["callback", cb]);
    assert.equal(r.json.ok, true);
    assert.equal(run(env, ["status"]).json.status, "requested");
    writeFileSync(cb, "not-json");
    assert.equal(run(env, ["callback", cb]).json.error, "bad_callback");
  });
});

test("unrelated files survive", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const marker = join(d, "unrelated.txt");
    const before = readFileSync(marker);
    run(deskEnv(d, s.service_url, 0), ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    assert.deepEqual(readFileSync(marker), before);
  });
});

test("crash after-request-saved-before-request then recover", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = deskEnv(d, s.service_url, 0);
    run(env, ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    run(env, ["locate", "LEND-A"]);
    const crashed = run({ ...env, CRASH_AT: "after-request-saved-before-request" }, ["transmit"]);
    assert.equal(crashed.status, null);
    assert.equal(crashed.signal, "SIGKILL");
    const st = run(env, ["status"]);
    assert.equal(st.json.lender, "attempt_saved");
    assert.equal(st.json.status, "located");
    assert.ok(st.json.loan_req_id);
    const rec = run(env, ["reconcile", st.json.loan_req_id]);
    assert.equal(rec.json.lookup, "not_sent");
    assert.equal((await posts(s.control_url)).count, 0);
    const tx = run(env, ["transmit"]);
    assert.equal(tx.json.status, "requested");
    assert.equal(tx.json.loan_req_id, st.json.loan_req_id);
    assert.equal((await effects(s.control_url)).count, 1);
  });
});

test("crash after-accept-before-record recovered by transmit", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = deskEnv(d, s.service_url, 0);
    run(env, ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    run(env, ["locate", "LEND-A"]);
    const crashed = run({ ...env, CRASH_AT: "after-accept-before-record" }, ["transmit"]);
    assert.equal(crashed.signal, "SIGKILL");
    assert.equal((await effects(s.control_url)).count, 1);
    const st = run(env, ["status"]);
    assert.equal(st.json.lender, "attempt_saved");
    const tx = run(env, ["transmit"]);
    assert.equal(tx.json.status, "requested");
    assert.equal((await effects(s.control_url)).count, 1);
  });
});

test("crash after-record-before-exit leaves accepted", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = deskEnv(d, s.service_url, 0);
    run(env, ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    run(env, ["locate", "LEND-A"]);
    const crashed = run({ ...env, CRASH_AT: "after-record-before-exit" }, ["transmit"]);
    assert.equal(crashed.signal, "SIGKILL");
    const st = run(env, ["status"]);
    assert.equal(st.json.status, "requested");
    assert.equal(st.json.lender, "accepted");
  });
});

test("dropped reply then reconcile", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = deskEnv(d, s.service_url, 0);
    run(env, ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    run(env, ["locate", "LEND-A"]);
    await fault(s.control_url, { drop_reply: true });
    const tx = run(env, ["transmit"]);
    assert.equal(tx.json.error, "service_unavailable");
    const st = run(env, ["status"]);
    assert.equal(st.json.lender, "attempt_saved");
    await fault(s.control_url, { drop_reply: false });
    const rec = run(env, ["reconcile", st.json.loan_req_id]);
    assert.equal(rec.json.lookup, "accepted");
    assert.equal(rec.json.status, "requested");
    assert.equal((await effects(s.control_url)).count, 1);
  });
});

test("5xx leaves attempt_saved", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = deskEnv(d, s.service_url, 0);
    run(env, ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    run(env, ["locate", "LEND-A"]);
    await fault(s.control_url, { error_status: 503 });
    const tx = run(env, ["transmit"]);
    assert.equal(tx.json.error, "service_unavailable");
    assert.equal(run(env, ["status"]).json.lender, "attempt_saved");
    assert.equal(run(env, ["receive"]).json.error, "loan_pending");
    assert.equal(run(env, ["cancel"]).json.error, "loan_started");
  });
});

async function toReceived(env) {
  run(env, ["file", "ILL-1", "PAT-9", "OCLC-42"]);
  run(env, ["locate", "LEND-A"]);
  run(env, ["transmit"]);
  run(env, ["receive"]);
}

test("place-recall on new out persists and is idempotent", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = (n) => deskEnv(d, s.service_url, n);
    await toReceived(env(0));
    const co = run(env(1000), ["checkout"]);
    assert.equal(co.json.loan_until_ms, 1000 + SPAN_V2);
    const pr = run(env(1000), ["place-recall"]);
    assert.equal(pr.status, 0);
    assert.equal(pr.json.recall_placed, 1);
    assert.equal(pr.json.status, "out");
    assert.equal((await effects(s.control_url)).count, 1);
    const st = run(env(1000), ["status"]);
    assert.equal(st.json.recall_placed, 1);
    const pr2 = run(env(1000), ["place-recall"]);
    assert.equal(pr2.json.recall_placed, 1);
    assert.equal(run(env(0), ["place-recall"]).json.status, "out");
    assert.equal(run(env(1000 + SPAN_V2 + 1), ["checkin"]).json.status, "returned");
  });
});

test("new overdue checkin requires recall", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = (n) => deskEnv(d, s.service_url, n);
    await toReceived(env(0));
    run(env(1000), ["checkout"]);
    const late = run(env(1000 + SPAN_V2 + 1), ["checkin"]);
    assert.equal(late.json.error, "recall_required");
    assert.equal(run(env(1000 + SPAN_V2 + 1), ["status"]).json.status, "out");
    assert.equal(run(env(1000), ["place-recall"]).json.recall_placed, 1);
    assert.equal(run(env(1000 + SPAN_V2 + 1), ["checkin"]).json.status, "returned");
  });
});

test("place-recall on filed new request is not_out; on legacy is legacy_request", async () => {
  await withStub(async (s) => {
    const dNew = tmpState();
    run(deskEnv(dNew, s.service_url, 0), ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    assert.equal(run(deskEnv(dNew, s.service_url, 0), ["place-recall"]).json.error, "not_out");

    const dOld = tmpState();
    runOld(deskEnv(dOld, s.service_url, 0), ["file", "ILL-O", "PAT-O", "OCLC-O"]);
    const before = run(deskEnv(dOld, s.service_url, 0), ["status"]).json;
    assert.equal(run(deskEnv(dOld, s.service_url, 0), ["place-recall"]).json.error, "legacy_request");
    assert.deepEqual(run(deskEnv(dOld, s.service_url, 0), ["status"]).json, before);
  });
});

test("legacy checkout keeps 14-day span and overdue checkin without recall", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = (n) => deskEnv(d, s.service_url, n);
    runOld(env(0), ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    run(env(0), ["locate", "LEND-A"]);
    run(env(0), ["transmit"]);
    run(env(0), ["receive"]);
    const co = run(env(1000), ["checkout"]);
    assert.equal(co.json.loan_until_ms, 1000 + SPAN_V1);
    const late = run(env(1000 + SPAN_V1 + 1), ["checkin"]);
    assert.equal(late.json.status, "returned");
    assert.equal(late.json.overdue, 1);
  });
});

test("new request recover after pre-request crash still 7-day and recall", async () => {
  await withStub(async (s) => {
    const d = tmpState();
    const env = (n) => deskEnv(d, s.service_url, n);
    run(env(0), ["file", "ILL-1", "PAT-9", "OCLC-42"]);
    run(env(0), ["locate", "LEND-A"]);
    const crashed = run({ ...env(0), CRASH_AT: "after-request-saved-before-request" }, ["transmit"]);
    assert.equal(crashed.signal, "SIGKILL");
    assert.equal(run(env(0), ["cancel"]).json.error, "loan_started");
    const st = run(env(0), ["status"]);
    const tx = run(env(0), ["transmit"]);
    assert.equal(tx.json.loan_req_id, st.json.loan_req_id);
    assert.equal((await effects(s.control_url)).count, 1);
    run(env(0), ["receive"]);
    const co = run(env(50), ["checkout"]);
    assert.equal(co.json.loan_until_ms, 50 + SPAN_V2);
    assert.equal(run(env(50), ["place-recall"]).json.recall_placed, 1);
  });
});

