import { main } from "./desk.mjs";
await main();
