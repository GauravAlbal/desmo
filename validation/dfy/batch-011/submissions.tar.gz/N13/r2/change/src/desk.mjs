import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import {
  HistoricalResult,
  Kernel,
  StoreNotFoundError,
  classify,
} from "@ikaros/runtime";

const AGG = "desk";
const STORE_NAME = "ill-desk.sqlite";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const LOAN_SPAN_V1 = 1209600000;
const LOAN_SPAN_V2 = 604800000;
const MAX_NOW = 9007199254740991;
const MACHINE_V1 = new URL("../desk.ik.toml", import.meta.url).pathname;
const MACHINE_V2 = new URL("../desk_v2.ik.toml", import.meta.url).pathname;

export function crashIf(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

export function parseNow(raw) {
  if (raw === undefined || raw === null || raw === "") return { error: "bad_time" };
  if (!/^(0|[1-9][0-9]*)$/.test(raw)) return { error: "bad_time" };
  const n = Number(raw);
  if (!Number.isInteger(n) || n < 0 || n > MAX_NOW) return { error: "bad_time" };
  return { now: n };
}

export function validId(s) {
  return typeof s === "string" && ID_RE.test(s);
}

function storePath(stateDir) {
  return join(stateDir, STORE_NAME);
}

function factsOf(agg) {
  const s = agg.state;
  if (s && typeof s === "object" && !Array.isArray(s)) return s;
  return {};
}

function num(v) {
  if (v === undefined || v === null) return null;
  if (typeof v === "bigint") return Number(v);
  if (typeof v === "number") return v;
  if (typeof v === "string" && /^-?\d+$/.test(v)) return Number(v);
  return null;
}

function str(v) {
  if (v === undefined || v === null || v === "") return null;
  return String(v);
}

export function publicStatus(agg, nowMs) {
  if (!agg) {
    return {
      req_id: null,
      patron_id: null,
      oclc: null,
      lender_id: null,
      status: "none",
      lender: "none",
      loan_req_id: null,
      checkout_ms: null,
      loan_until_ms: null,
      overdue: 0,
      recall_placed: 0,
    };
  }
  const f = factsOf(agg);
  const status = agg.namedState();
  const loanUntil = num(f.loan_until_ms);
  const overdue = status === "out" && loanUntil !== null && nowMs > loanUntil ? 1 : 0;
  return {
    req_id: str(f.req_id),
    patron_id: str(f.patron_id),
    oclc: str(f.oclc),
    lender_id: str(f.lender_id),
    status,
    lender: str(f.lender) ?? "none",
    loan_req_id: str(f.loan_req_id),
    checkout_ms: num(f.checkout_ms),
    loan_until_ms: loanUntil,
    overdue,
    recall_placed: num(f.recall_placed) ?? 0,
  };
}

function payloadDigest(body) {
  const canonical = JSON.stringify({
    loan_req_id: body.loan_req_id,
    req_id: body.req_id,
    lender_id: body.lender_id,
    oclc: body.oclc,
  });
  return createHash("sha256").update(canonical).digest("hex");
}

function bodyDigest(text) {
  return createHash("sha256").update(text).digest("hex");
}

async function pair(kernel) {
  const v1 = await kernel.machine(MACHINE_V1);
  const v2 = await kernel.machine(MACHINE_V2);
  return { v1, v2 };
}

function route(v1, v2, agg) {
  if (!agg) return v2;
  if (v1.identity.equals(agg.owner)) return v1;
  if (v2.identity.equals(agg.owner)) return v2;
  throw Object.assign(new Error("corrupt_state"), { code: "corrupt_state" });
}

function isLegacy(v1, agg) {
  return Boolean(agg && v1.identity.equals(agg.owner));
}

function loanSpan(legacy) {
  return legacy ? LOAN_SPAN_V1 : LOAN_SPAN_V2;
}

async function openPair(stateDir) {
  mkdirSync(stateDir, { recursive: true });
  const kernel = new Kernel(storePath(stateDir));
  return pair(kernel);
}

async function loadDesk(stateDir) {
  const path = storePath(stateDir);
  if (!existsSync(path)) return { machine: null, agg: null, empty: true, v1: null, v2: null };
  try {
    const kernel = new Kernel(path);
    const { v1, v2 } = await pair(kernel);
    try {
      const probe = await v2.show(AGG);
      const machine = route(v1, v2, probe);
      const agg = machine === v2 ? probe : await machine.show(AGG);
      return { machine, agg, empty: false, v1, v2 };
    } catch (err) {
      if (err instanceof StoreNotFoundError) return { machine: v2, agg: null, empty: true, v1, v2 };
      const cls = classify(err);
      if (cls === "not_found") return { machine: v2, agg: null, empty: true, v1, v2 };
      if (cls === "corrupt") throw Object.assign(new Error("corrupt_state"), { code: "corrupt_state" });
      throw err;
    }
  } catch (err) {
    if (err?.code === "corrupt_state") throw err;
    if (err instanceof StoreNotFoundError) return { machine: null, agg: null, empty: true, v1: null, v2: null };
    const cls = typeof err?.code === "string" ? classify(err) : null;
    if (cls === "corrupt") throw Object.assign(new Error("corrupt_state"), { code: "corrupt_state" });
    throw err;
  }
}

async function asAgg(result, machine) {
  if (result instanceof HistoricalResult) {
    return machine.show(AGG);
  }
  return result;
}

function refuse(code) {
  const e = new Error(code);
  e.code = code;
  return e;
}

function mapIllegal(cmd, pub) {
  const st = pub.status;
  const lender = pub.lender;
  if (cmd === "file") return "already_filed";
  if (cmd === "locate") {
    if (st === "located") return "already_located";
    return "bad_status";
  }
  if (cmd === "transmit") return "bad_status";
  if (cmd === "receive") {
    if (lender === "attempt_saved") return "loan_pending";
    if (st === "received") return "already_received";
    return "bad_status";
  }
  if (cmd === "checkout") {
    if (st === "out") return "already_out";
    return "bad_status";
  }
  if (cmd === "checkin") {
    if (st === "returned") return "already_returned";
    return "bad_status";
  }
  if (cmd === "declare-lost") {
    if (st === "lost") return "already_lost";
    if (st === "returned") return "already_returned";
    return "bad_status";
  }
  if (cmd === "cancel") {
    if (lender === "attempt_saved") return "loan_started";
    if (st === "requested" || lender === "accepted") return "already_requested";
    if (st === "cancelled") return "already_cancelled";
    return "bad_status";
  }
  if (cmd === "reconcile") {
    if (!pub.loan_req_id) return "no_loan";
    return "loan_mismatch";
  }
  if (cmd === "place-recall") return "not_out";
  return "bad_status";
}

async function httpJson(method, url, body) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await fetch(url, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      signal: ctrl.signal,
    });
    const text = await res.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }
    return { ok: true, status: res.status, text, json, complete: true };
  } catch {
    return { ok: false, status: 0, text: "", json: null, complete: false };
  } finally {
    clearTimeout(t);
  }
}

function snapshotMatch(json, snap) {
  if (!json || typeof json !== "object") return false;
  return (
    json.loan_req_id === snap.loan_req_id &&
    json.req_id === snap.req_id &&
    json.lender_id === snap.lender_id &&
    json.oclc === snap.oclc
  );
}

function loanBody(pub) {
  return {
    loan_req_id: pub.loan_req_id,
    req_id: pub.req_id,
    lender_id: pub.lender_id,
    oclc: pub.oclc,
  };
}

async function postLoan(serviceUrl, body) {
  return httpJson("POST", `${serviceUrl.replace(/\/$/, "")}/v1/ill-loans`, body);
}

async function getLoan(serviceUrl, id) {
  const enc = encodeURIComponent(id);
  return httpJson("GET", `${serviceUrl.replace(/\/$/, "")}/v1/ill-loans/${enc}`);
}

async function adoptAccepted(machine, agg, body, outcomeText) {
  let cur = agg;
  if (cur.pendingIntent) {
    const rec = await cur.recordEffectOutcome(bodyDigest(outcomeText), {
      intent: cur.pendingIntent,
    });
    cur = await asAgg(rec, machine);
  }
  const committed = await cur.execute({
    name: "commit_accepted",
    args: { loan_req_id: body.loan_req_id, lender: "accepted" },
  });
  return asAgg(committed, machine);
}

async function firstTransmit(machine, agg, serviceUrl) {
  const f = factsOf(agg);
  const body = {
    loan_req_id: `L.${f.req_id}`,
    req_id: f.req_id,
    lender_id: f.lender_id,
    oclc: f.oclc,
  };
  const saved = await agg.execute({
    name: "save_attempt",
    args: {
      ...body,
      payload_digest: payloadDigest(body),
      lender: "attempt_saved",
    },
  });
  const afterSave = await asAgg(saved, machine);
  crashIf("after-request-saved-before-request");
  const posted = await postLoan(serviceUrl, body);
  if (!posted.complete || posted.status >= 500 || posted.status === 0) {
    throw refuse("service_unavailable");
  }
  if (posted.status !== 200 || !snapshotMatch(posted.json, body)) {
    if (posted.status === 409) throw refuse("lookup_conflict");
    throw refuse("service_unavailable");
  }
  crashIf("after-accept-before-record");
  const done = await adoptAccepted(machine, afterSave, body, posted.text);
  crashIf("after-record-before-exit");
  return done;
}

async function recoverTransmit(machine, agg, serviceUrl, doLookup) {
  const body = loanBody(publicStatus(agg, 0));
  if (doLookup) {
    const looked = await getLoan(serviceUrl, body.loan_req_id);
    if (!looked.complete || looked.status >= 500 || looked.status === 0) {
      throw refuse("service_unavailable");
    }
    if (looked.status === 200) {
      if (!snapshotMatch(looked.json, body)) throw refuse("lookup_conflict");
      crashIf("after-accept-before-record");
      const done = await adoptAccepted(machine, agg, body, looked.text);
      crashIf("after-record-before-exit");
      return done;
    }
    if (looked.status !== 404) throw refuse("service_unavailable");
  }
  const posted = await postLoan(serviceUrl, body);
  if (!posted.complete || posted.status >= 500 || posted.status === 0) {
    throw refuse("service_unavailable");
  }
  if (posted.status !== 200 || !snapshotMatch(posted.json, body)) {
    if (posted.status === 409) throw refuse("lookup_conflict");
    throw refuse("service_unavailable");
  }
  crashIf("after-accept-before-record");
  const done = await adoptAccepted(machine, agg, body, posted.text);
  crashIf("after-record-before-exit");
  return done;
}

function transmitSuccess(agg) {
  const pub = publicStatus(agg, 0);
  return {
    req_id: pub.req_id,
    loan_req_id: pub.loan_req_id,
    lender_id: pub.lender_id,
    oclc: pub.oclc,
    status: "requested",
    lender: "accepted",
  };
}

function recallSuccess(pub) {
  return {
    req_id: pub.req_id,
    status: "out",
    recall_placed: 1,
    loan_until_ms: pub.loan_until_ms,
    overdue: pub.overdue,
  };
}

export async function dispatch(env, argv) {
  const nowParsed = parseNow(env.NOW_MS);
  if (nowParsed.error) throw refuse("bad_time");
  const now = nowParsed.now;
  const stateDir = env.STATE_DIR;
  const serviceUrl = env.SERVICE_URL;
  if (!stateDir || !serviceUrl) throw refuse("bad_args");
  const cmd = argv[0];
  if (!cmd) throw refuse("bad_args");

  const needIds = {
    file: [1, 2, 3],
    locate: [1],
    reconcile: [1],
  };
  if (needIds[cmd]) {
    for (const i of needIds[cmd]) {
      if (!validId(argv[i])) throw refuse("bad_args");
    }
  }

  if (cmd === "callback") {
    if (!argv[1]) throw refuse("bad_args");
    let raw;
    try {
      raw = readFileSync(argv[1], "utf8");
    } catch {
      throw refuse("bad_callback");
    }
    try {
      JSON.parse(raw);
    } catch {
      throw refuse("bad_callback");
    }
    const loaded = await loadDesk(stateDir);
    if (loaded.empty || !loaded.agg) return { ok: true };
    try {
      await loaded.agg.execute({ name: "ignore_callback", args: {} });
    } catch {
      /* still ignore */
    }
    return { ok: true };
  }

  if (cmd === "status") {
    const loaded = await loadDesk(stateDir);
    return publicStatus(loaded.agg, now);
  }

  const loaded = await loadDesk(stateDir);
  const pub = publicStatus(loaded.agg, now);
  const legacy = isLegacy(loaded.v1, loaded.agg);

  if (cmd === "file") {
    if (!loaded.empty && loaded.agg) throw refuse("already_filed");
    const { v2 } = loaded.v2 ? loaded : await openPair(stateDir);
    const created = await v2.createWith({
      aggregateId: AGG,
      command: {
        name: "file",
        args: { req_id: argv[1], patron_id: argv[2], oclc: argv[3], lender: "none" },
      },
    });
    await asAgg(created, v2);
    return {
      req_id: argv[1],
      patron_id: argv[2],
      oclc: argv[3],
      status: "filed",
      lender: "none",
      loan_req_id: null,
    };
  }

  if (!loaded.agg || !loaded.machine) {
    if (cmd === "reconcile") throw refuse("no_loan");
    if (cmd === "place-recall") throw refuse("not_out");
    throw refuse("bad_status");
  }

  const { machine, agg } = loaded;

  if (cmd === "place-recall") {
    if (legacy) throw refuse("legacy_request");
    if (pub.status !== "out") throw refuse("not_out");
    if (pub.recall_placed === 1) return recallSuccess(pub);
    try {
      const done = await asAgg(
        await agg.execute({ name: "place_recall", args: { recall_placed: 1 } }),
        machine,
      );
      return recallSuccess(publicStatus(done, now));
    } catch {
      throw refuse(mapIllegal(cmd, pub));
    }
  }

  if (cmd === "locate") {
    if (pub.status === "located") throw refuse("already_located");
    try {
      await agg.execute({ name: "locate", args: { lender_id: argv[1] } });
    } catch (err) {
      if (err.code && String(err.code).startsWith("IK_")) throw refuse(mapIllegal(cmd, pub));
      throw err;
    }
    return { req_id: pub.req_id, lender_id: argv[1], status: "located" };
  }

  if (cmd === "transmit") {
    if (pub.status === "requested" && pub.lender === "accepted") {
      await agg.execute({ name: "ack_transmit", args: {} });
      return transmitSuccess(agg);
    }
    if (pub.status === "located" && pub.lender === "none") {
      const done = await firstTransmit(machine, agg, serviceUrl);
      return transmitSuccess(done);
    }
    if (pub.status === "located" && pub.lender === "attempt_saved") {
      const done = await recoverTransmit(machine, agg, serviceUrl, true);
      return transmitSuccess(done);
    }
    throw refuse("bad_status");
  }

  if (cmd === "receive") {
    if (pub.lender === "attempt_saved") throw refuse("loan_pending");
    if (pub.status === "received") throw refuse("already_received");
    try {
      await agg.execute({ name: "receive", args: {} });
    } catch {
      throw refuse(mapIllegal(cmd, pub));
    }
    return { req_id: pub.req_id, status: "received" };
  }

  if (cmd === "checkout") {
    if (pub.status === "out") throw refuse("already_out");
    const span = loanSpan(legacy);
    try {
      await agg.execute({
        name: "checkout",
        args: { checkout_ms: now, loan_until_ms: now + span },
      });
    } catch {
      throw refuse(mapIllegal(cmd, pub));
    }
    return {
      req_id: pub.req_id,
      status: "out",
      checkout_ms: now,
      loan_until_ms: now + span,
      overdue: 0,
    };
  }

  if (cmd === "checkin") {
    if (pub.status === "returned") throw refuse("already_returned");
    const overdue = pub.status === "out" && pub.loan_until_ms !== null && now > pub.loan_until_ms ? 1 : 0;
    if (!legacy && pub.status === "out" && overdue === 1 && pub.recall_placed !== 1) {
      throw refuse("recall_required");
    }
    try {
      await agg.execute({ name: "checkin", args: {} });
    } catch {
      throw refuse(mapIllegal(cmd, pub));
    }
    return { req_id: pub.req_id, status: "returned", overdue };
  }

  if (cmd === "declare-lost") {
    if (pub.status === "lost") throw refuse("already_lost");
    if (pub.status === "returned") throw refuse("already_returned");
    try {
      await agg.execute({ name: "declare_lost", args: {} });
    } catch {
      throw refuse(mapIllegal(cmd, pub));
    }
    return { req_id: pub.req_id, status: "lost" };
  }

  if (cmd === "cancel") {
    if (pub.lender === "attempt_saved") throw refuse("loan_started");
    if (pub.status === "requested" || pub.lender === "accepted") throw refuse("already_requested");
    if (pub.status === "cancelled") throw refuse("already_cancelled");
    try {
      await agg.execute({ name: "cancel", args: {} });
    } catch {
      throw refuse(mapIllegal(cmd, pub));
    }
    return { req_id: pub.req_id, status: "cancelled" };
  }

  if (cmd === "reconcile") {
    const id = argv[1];
    if (!pub.loan_req_id) throw refuse("no_loan");
    if (id !== pub.loan_req_id) throw refuse("loan_mismatch");
    const looked = await getLoan(serviceUrl, id);
    if (!looked.complete || looked.status >= 500 || looked.status === 0) {
      throw refuse("service_unavailable");
    }
    if (looked.status === 404) {
      return {
        lookup: "not_sent",
        req_id: pub.req_id,
        loan_req_id: pub.loan_req_id,
        lender: "attempt_saved",
        status: "located",
      };
    }
    if (looked.status !== 200) throw refuse("service_unavailable");
    const body = loanBody(pub);
    if (!snapshotMatch(looked.json, body)) throw refuse("lookup_conflict");
    if (pub.status === "requested" && pub.lender === "accepted") {
      return { ...transmitSuccess(agg), lookup: "accepted" };
    }
    const done = await adoptAccepted(machine, agg, body, looked.text);
    return { ...transmitSuccess(done), lookup: "accepted" };
  }

  throw refuse("bad_args");
}

export async function main(env = process.env, argv = process.argv.slice(2)) {
  try {
    const out = await dispatch(env, argv);
    process.stdout.write(JSON.stringify(out) + "\n");
    process.exitCode = 0;
  } catch (err) {
    const known = new Set([
      "bad_time", "bad_args", "bad_status", "already_filed", "already_located",
      "already_received", "already_out", "already_returned", "already_lost", "already_cancelled",
      "already_requested", "loan_pending", "loan_started", "loan_mismatch", "no_loan",
      "lookup_conflict", "service_unavailable", "bad_callback", "corrupt_state",
      "legacy_request", "not_out", "recall_required",
    ]);
    const mapped = known.has(err?.code)
      ? err.code
      : classify(err) === "corrupt"
        ? "corrupt_state"
        : "bad_args";
    process.stdout.write(JSON.stringify({ error: mapped }) + "\n");
    process.exitCode = 1;
  }
}
