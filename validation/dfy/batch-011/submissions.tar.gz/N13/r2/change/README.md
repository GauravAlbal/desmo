# Interlibrary loan request desk

Durable one-request ILL desk. Lifecycle authority is Ikaros (`desk.ik.toml`); HTTP and CLI live in `src/`.

## Setup

Node 22 (`<home>/.nvm/versions/node/v22.17.1/bin/node`). Offline install of the kit tarballs:

```bash
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x run
```

Fake lender:

```bash
node stub/server.mjs
# prints {"service_url":"http://127.0.0.1:<port>","control_url":"..."}
```

## Run

Every command needs `STATE_DIR`, `SERVICE_URL`, and `NOW_MS` (epoch ms integer).

```bash
export STATE_DIR=/tmp/ill-desk SERVICE_URL=http://127.0.0.1:PORT NOW_MS=1000
./run file ILL-1 PAT-9 OCLC-42
./run locate LEND-A
./run transmit
./run receive
./run checkout
./run checkin
./run status
```

Optional `CRASH_AT` labels: `after-request-saved-before-request`, `after-accept-before-record`, `after-record-before-exit`.

## Tests

```bash
npm test
```
