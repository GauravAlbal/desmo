import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const NODE = process.env.NODE_BIN || "<home>/.nvm/versions/node/v22.17.1/bin/node";
const RUN = join(ROOT, "run");

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [join(ROOT, "stub/server.mjs")], { cwd: ROOT });
    let buf = "";
    child.stdout.on("data", (c) => {
      buf += c.toString();
      const nl = buf.indexOf("\n");
      if (nl >= 0) {
        try {
          resolve({ child, ...JSON.parse(buf.slice(0, nl)) });
        } catch (e) {
          reject(e);
        }
      }
    });
    child.stderr.on("data", () => {});
    child.on("error", reject);
  });
}

function runDesk(env, args) {
  const r = spawnSync(RUN, args, {
    env: { ...process.env, ...env },
    encoding: "utf8",
  });
  let json = null;
  try {
    json = JSON.parse((r.stdout || "").trim());
  } catch {
    json = r.stdout;
  }
  return { code: r.status, json, stderr: r.stderr, signal: r.signal };
}

function freshEnv(serviceUrl, now = "0") {
  const dir = mkdtempSync(join(tmpdir(), "desk-"));
  return { STATE_DIR: dir, SERVICE_URL: serviceUrl, NOW_MS: String(now) };
}

test("status empty and open bind survive restart", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "0");
    const empty = runDesk(env, ["status"]);
    assert.equal(empty.code, 0);
    assert.equal(empty.json.phase, "none");
    assert.equal(empty.json.listing_id, null);
    assert.equal(empty.json.edition, null);
    const opened = runDesk(env, ["open", "L1", "S1", "10000", "100000", "5000"]);
    assert.equal(opened.code, 0);
    assert.equal(opened.json.phase, "listed");
    const again = runDesk({ ...env, NOW_MS: "5" }, ["status"]);
    assert.equal(again.code, 0);
    assert.equal(again.json.listing_id, "L1");
    assert.equal(again.json.ask_cents, 10000);
    assert.equal(again.json.edition, "revised");
    const dup = runDesk(env, ["open", "L2", "S1", "10000", "100000", "5000"]);
    assert.equal(dup.code, 1);
    assert.equal(dup.json.error, "already_open");
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("happy path counter backup deposit fallthrough", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "10");
    writeFileSync(join(env.STATE_DIR, "unrelated.txt"), "keep-me");
    assert.equal(runDesk(env, ["open", "L1", "S1", "10000", "100000", "5000"]).code, 0);
    const bid = runDesk(env, ["bid", "L1", "O1", "B1", "10000"]);
    assert.equal(bid.json.phase, "offered");
    assert.equal(bid.json.primary.countered, false);
    const bak = runDesk(env, ["bid", "L1", "O2", "B2", "9000"]);
    assert.equal(bak.json.backup.amount_cents, 9000);
    const third = runDesk(env, ["bid", "L1", "O3", "B3", "8000"]);
    assert.equal(third.json.error, "desk_full");
    const counter = runDesk(env, ["counter", "L1", "O1", "11000"]);
    assert.equal(counter.json.phase, "countered");
    assert.equal(counter.json.primary.amount_cents, 11000);
    const acc = runDesk(env, ["accept", "L1", "O1"]);
    assert.equal(acc.json.deposit_cents, 220);
    assert.equal(acc.json.deposit_deadline_ms, 10 + 5000);
    const dep = runDesk(env, ["deposit", "L1"]);
    assert.equal(dep.code, 0);
    assert.equal(dep.json.phase, "under_contract");
    const dep2 = runDesk(env, ["deposit", "L1"]);
    assert.equal(dep2.json.phase, "under_contract");
    const effects = await fetch(`${stub.control_url}/effects`).then((r) => r.json());
    assert.equal(effects.count, 1);
    const fall = runDesk(env, ["fallthrough", "L1"]);
    assert.equal(fall.json.phase, "fallen");
    const fall2 = runDesk(env, ["fallthrough", "L1"]);
    assert.equal(fall2.json.error, "already_fallen");
    assert.equal(readFileSync(join(env.STATE_DIR, "unrelated.txt"), "utf8"), "keep-me");
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("window elapsed durably expires", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "0");
    runDesk(env, ["open", "L1", "S1", "10000", "50", "5"]);
    runDesk({ ...env, NOW_MS: "10" }, ["bid", "L1", "O1", "B1", "10000"]);
    const late = runDesk({ ...env, NOW_MS: "51" }, ["bid", "L1", "O9", "B9", "10000"]);
    assert.equal(late.json.error, "window_elapsed");
    const st = runDesk({ ...env, NOW_MS: "51" }, ["status"]);
    assert.equal(st.json.phase, "expired");
    const acc = runDesk({ ...env, NOW_MS: "51" }, ["accept", "L1", "O1"]);
    assert.equal(acc.json.error, "window_elapsed");
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("crash after save before request then recover same id", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "10");
    runDesk(env, ["open", "L1", "S1", "10000", "100000", "5000"]);
    runDesk(env, ["bid", "L1", "O1", "B1", "10000"]);
    runDesk(env, ["accept", "L1", "O1"]);
    const crashed = runDesk({ ...env, CRASH_AT: "after-deposit-saved-before-request" }, ["deposit", "L1"]);
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const st = runDesk(env, ["status"]);
    assert.equal(st.json.phase, "accepted");
    assert.equal(st.json.escrow, "attempt_saved");
    const id = st.json.deposit_id;
    assert.ok(id);
    const posts1 = await fetch(`${stub.control_url}/posts`).then((r) => r.json());
    assert.equal(posts1.count, 0);
    const dep = runDesk(env, ["deposit", "L1"]);
    assert.equal(dep.json.phase, "under_contract");
    assert.equal(dep.json.deposit_id, id);
    const effects = await fetch(`${stub.control_url}/effects`).then((r) => r.json());
    assert.equal(effects.count, 1);
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("crash after accept before record then adopt by lookup", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "10");
    runDesk(env, ["open", "L1", "S1", "10000", "100000", "5000"]);
    runDesk(env, ["bid", "L1", "O1", "B1", "10000"]);
    runDesk(env, ["accept", "L1", "O1"]);
    const crashed = runDesk({ ...env, CRASH_AT: "after-accept-before-record" }, ["deposit", "L1"]);
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const st = runDesk(env, ["status"]);
    assert.equal(st.json.escrow, "attempt_saved");
    const effects1 = await fetch(`${stub.control_url}/effects`).then((r) => r.json());
    assert.equal(effects1.count, 1);
    const dep = runDesk(env, ["deposit", "L1"]);
    assert.equal(dep.json.phase, "under_contract");
    const effects2 = await fetch(`${stub.control_url}/effects`).then((r) => r.json());
    assert.equal(effects2.count, 1);
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("crash after under-contract record then deposit no-op", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "10");
    runDesk(env, ["open", "L1", "S1", "10000", "100000", "5000"]);
    runDesk(env, ["bid", "L1", "O1", "B1", "10000"]);
    runDesk(env, ["accept", "L1", "O1"]);
    const crashed = runDesk({ ...env, CRASH_AT: "after-record-before-exit" }, ["deposit", "L1"]);
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const st = runDesk(env, ["status"]);
    assert.equal(st.json.phase, "under_contract");
    const dep = runDesk(env, ["deposit", "L1"]);
    assert.equal(dep.json.phase, "under_contract");
    const effects = await fetch(`${stub.control_url}/effects`).then((r) => r.json());
    assert.equal(effects.count, 1);
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("dropped deposit reply then reconcile adopts", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "10");
    runDesk(env, ["open", "L1", "S1", "10000", "100000", "5000"]);
    runDesk(env, ["bid", "L1", "O1", "B1", "10000"]);
    runDesk(env, ["accept", "L1", "O1"]);
    await fetch(`${stub.control_url}/fault`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ drop_reply: true }),
    });
    const dep = runDesk(env, ["deposit", "L1"]);
    assert.equal(dep.json.error, "service_unavailable");
    const st = runDesk(env, ["status"]);
    assert.equal(st.json.escrow, "attempt_saved");
    await fetch(`${stub.control_url}/fault`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ drop_reply: false }),
    });
    const rec = runDesk(env, ["reconcile", "L1", st.json.deposit_id]);
    assert.equal(rec.json.lookup, "funded");
    assert.equal(rec.json.phase, "under_contract");
    const rec2 = runDesk(env, ["reconcile", "L1", "nope-id"]);
    assert.equal(rec2.json.error, "deposit_mismatch");
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("reconcile not_sent when never posted", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "10");
    runDesk(env, ["open", "L1", "S1", "10000", "100000", "5000"]);
    runDesk(env, ["bid", "L1", "O1", "B1", "10000"]);
    runDesk(env, ["accept", "L1", "O1"]);
    runDesk({ ...env, CRASH_AT: "after-deposit-saved-before-request" }, ["deposit", "L1"]);
    const st = runDesk(env, ["status"]);
    const rec = runDesk(env, ["reconcile", "L1", st.json.deposit_id]);
    assert.equal(rec.code, 0);
    assert.equal(rec.json.lookup, "not_sent");
    assert.equal(rec.json.escrow, "attempt_saved");
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("refusals and callback", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "10");
    assert.equal(runDesk({ ...env, NOW_MS: "x" }, ["status"]).json.error, "bad_time");
    const nosvc = { ...env };
    delete nosvc.SERVICE_URL;
    assert.equal(runDesk(nosvc, ["status"]).json.error, "bad_args");
    runDesk(env, ["open", "L1", "S1", "10000", "100000", "5000"]);
    assert.equal(runDesk(env, ["bid", "L9", "O1", "B1", "10000"]).json.error, "listing_mismatch");
    assert.equal(runDesk(env, ["counter", "L1", "O1", "11000"]).json.error, "no_offer");
    runDesk(env, ["bid", "L1", "O1", "B1", "10000"]);
    assert.equal(runDesk(env, ["counter", "L1", "O2", "11000"]).json.error, "not_primary");
    const cbPath = join(env.STATE_DIR, "cb.json");
    writeFileSync(cbPath, "{not json");
    assert.equal(runDesk(env, ["callback", cbPath]).json.error, "bad_callback");
    writeFileSync(cbPath, JSON.stringify({ hello: true }));
    const cb = runDesk(env, ["callback", cbPath]);
    assert.equal(cb.code, 0);
    runDesk(env, ["accept", "L1", "O1"]);
    runDesk(env, ["deposit", "L1"]);
    const cb2 = runDesk(env, ["callback", cbPath]);
    assert.equal(cb2.code, 0);
    const st = runDesk(env, ["status"]);
    assert.equal(st.json.phase, "under_contract");
    assert.equal(runDesk(env, ["deposit", "L1"]).json.phase, "under_contract");
    const unfunded = freshEnv(stub.service_url, "10");
    runDesk(unfunded, ["open", "L2", "S1", "10000", "100000", "5000"]);
    assert.equal(runDesk(unfunded, ["fallthrough", "L2"]).json.error, "not_funded");
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("missing env precedence and unknown command", async () => {
  const env = { STATE_DIR: mkdtempSync(join(tmpdir(), "desk-")), PATH: process.env.PATH };
  const r = spawnSync(RUN, ["nope"], { env, encoding: "utf8" });
  assert.equal(JSON.parse(r.stdout).error, "bad_time");
});

test("revised deposit deadline and promote backup", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "1000");
    runDesk(env, ["open", "L1", "S1", "10000", "2000", "5000"]);
    runDesk(env, ["bid", "L1", "O1", "B1", "10000"]);
    runDesk(env, ["bid", "L1", "O2", "B2", "9000"]);
    const acc = runDesk(env, ["accept", "L1", "O1"]);
    assert.equal(acc.json.accepted_ms, 1000);
    assert.equal(acc.json.deposit_cents, 200);
    assert.equal(acc.json.deposit_deadline_ms, 6000);
    const lateAcceptWindow = runDesk({ ...env, NOW_MS: "3000" }, ["deposit", "L1"]);
    assert.equal(lateAcceptWindow.code, 0);
    assert.equal(lateAcceptWindow.json.phase, "under_contract");
    const fall = runDesk({ ...env, NOW_MS: "3000" }, ["fallthrough", "L1"]);
    assert.equal(fall.json.phase, "fallen");
    const effects1 = await fetch(`${stub.control_url}/effects`).then((r) => r.json());
    const promo = runDesk({ ...env, NOW_MS: "3000" }, ["promote", "L1"]);
    assert.equal(promo.code, 0);
    assert.equal(promo.json.phase, "offered");
    assert.equal(promo.json.primary.offer_id, "O2");
    assert.equal(promo.json.primary.countered, false);
    assert.equal(promo.json.backup, null);
    assert.equal(promo.json.deposit_id, null);
    assert.equal(promo.json.edition, "revised");
    const effects2 = await fetch(`${stub.control_url}/effects`).then((r) => r.json());
    assert.equal(effects2.count, effects1.count);
    const st = runDesk({ ...env, NOW_MS: "50" }, ["status"]);
    assert.equal(st.json.phase, "offered");
    assert.equal(st.json.primary.offer_id, "O2");
    const acc2 = runDesk({ ...env, NOW_MS: "1000" }, ["accept", "L1", "O2"]);
    assert.equal(acc2.json.deposit_deadline_ms, 6000);
    const crashed = runDesk(
      { ...env, NOW_MS: "1000", CRASH_AT: "after-deposit-saved-before-request" },
      ["deposit", "L1"],
    );
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const st2 = runDesk({ ...env, NOW_MS: "1000" }, ["status"]);
    const id = st2.json.deposit_id;
    const posts = await fetch(`${stub.control_url}/posts`).then((r) => r.json());
    const dep = runDesk({ ...env, NOW_MS: "1000" }, ["deposit", "L1"]);
    assert.equal(dep.json.phase, "under_contract");
    assert.equal(dep.json.deposit_id, id);
    const effects3 = await fetch(`${stub.control_url}/effects`).then((r) => r.json());
    assert.equal(effects3.count, effects1.count + 1);
    assert.ok(posts.count === 0 || posts.count >= 0);
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("revised deposit_elapsed after window", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "1000");
    runDesk(env, ["open", "L1", "S1", "10000", "2000", "5000"]);
    runDesk(env, ["bid", "L1", "O1", "B1", "10000"]);
    runDesk(env, ["accept", "L1", "O1"]);
    const late = runDesk({ ...env, NOW_MS: "6001" }, ["deposit", "L1"]);
    assert.equal(late.json.error, "deposit_elapsed");
    const posts = await fetch(`${stub.control_url}/posts`).then((r) => r.json());
    assert.equal(posts.count, 0);
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("promote refusals", async () => {
  const stub = await startStub();
  try {
    const env = freshEnv(stub.service_url, "10");
    runDesk(env, ["open", "L1", "S1", "10000", "100000", "5000"]);
    assert.equal(runDesk(env, ["promote", "L1"]).json.error, "not_fallen");
    runDesk(env, ["bid", "L1", "O1", "B1", "10000"]);
    runDesk(env, ["accept", "L1", "O1"]);
    runDesk(env, ["deposit", "L1"]);
    runDesk(env, ["fallthrough", "L1"]);
    assert.equal(runDesk(env, ["promote", "L1"]).json.error, "no_backup");
  } finally {
    stub.child.kill("SIGKILL");
  }
});

test("original listing continuity store", async () => {
  const stub = await startStub();
  try {
    const env = {
      STATE_DIR: "/tmp/desk-continuity-r2",
      SERVICE_URL: stub.service_url,
      NOW_MS: "10",
    };
    const st = runDesk(env, ["status"]);
    assert.equal(st.json.edition, "original");
    assert.equal(st.json.phase, "offered");
    const promo = runDesk(env, ["promote", "L1"]);
    assert.equal(promo.json.error, "legacy_listing");
    const acc = runDesk(env, ["accept", "L1", "O1"]);
    assert.equal(acc.code, 0);
    assert.equal(acc.json.deposit_deadline_ms, 2000);
    const late = runDesk({ ...env, NOW_MS: "3000" }, ["deposit", "L1"]);
    assert.equal(late.json.error, "deposit_elapsed");
    const posts = await fetch(`${stub.control_url}/posts`).then((r) => r.json());
    assert.equal(posts.count, 0);
  } finally {
    stub.child.kill("SIGKILL");
  }
});
