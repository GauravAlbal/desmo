import { createHash, randomBytes } from "node:crypto";
import { readFileSync, existsSync, statSync } from "node:fs";
import { dirname, isAbsolute, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Kernel,
  HistoricalResult,
  StoreNotFoundError,
  classify,
} from "@ikaros/runtime";

const DESK = "desk";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const CANON_INT = /^(0|[1-9][0-9]*)$/;
const ROOT = dirname(fileURLToPath(import.meta.url));
const MACHINE_V1 = join(ROOT, "listing.ik.toml");
const MACHINE_V2 = join(ROOT, "listing_v2.ik.toml");

function out(obj, code) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(code);
}
function ok(obj) {
  out(obj, 0);
}
function fail(code) {
  out({ error: code }, 1);
}

function crash(label) {
  if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL");
}

function nowMs() {
  const raw = process.env.NOW_MS;
  if (raw === undefined || raw === "") fail("bad_time");
  if (!CANON_INT.test(raw)) fail("bad_time");
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0) fail("bad_time");
  return n;
}

function serviceUrl() {
  const u = process.env.SERVICE_URL;
  if (u === undefined || u === "") fail("bad_args");
  return u.replace(/\/$/, "");
}

function stateDir() {
  const d = process.env.STATE_DIR;
  if (d === undefined || d === "") fail("bad_args");
  return d;
}

function storePath() {
  return join(stateDir(), "desk.sqlite");
}

function isId(s) {
  return typeof s === "string" && ID_RE.test(s);
}

function parseMoney(s) {
  if (s === undefined || !CANON_INT.test(s)) return { error: "bad_money" };
  const n = Number(s);
  if (!Number.isSafeInteger(n) || n < 0) return { error: "bad_money" };
  return { n };
}

function parsePositiveMoney(s) {
  const r = parseMoney(s);
  if (r.error) return r;
  if (r.n < 1) return { error: "bad_money" };
  return r;
}

function parseTimeArg(s) {
  if (s === undefined || !CANON_INT.test(s)) return { error: "bad_time" };
  const n = Number(s);
  if (!Number.isSafeInteger(n) || n < 0) return { error: "bad_time" };
  return { n };
}

function mapKernel(err) {
  if (err instanceof StoreNotFoundError) return "not_found";
  const c = classify(err);
  if (c === "corrupt") fail("corrupt_state");
  if (c === "not_found") return "not_found";
  return "refused";
}

async function openKernel() {
  return new Kernel(storePath());
}

async function openMachines() {
  const kernel = await openKernel();
  const v1 = await kernel.machine(MACHINE_V1);
  const v2 = await kernel.machine(MACHINE_V2);
  return { kernel, v1, v2 };
}

function editionOf(agg, v1, v2) {
  if (!agg || phaseOf(agg) === "unbound") return null;
  if (agg.owner.equals(v1.identity)) return "original";
  if (agg.owner.equals(v2.identity)) return "revised";
  return null;
}

function machineFor(agg, v1, v2) {
  if (!agg) return v2;
  if (agg.owner.equals(v1.identity)) return v1;
  if (agg.owner.equals(v2.identity)) return v2;
  fail("corrupt_state");
}

async function loadDesk(v1, v2) {
  try {
    const probe = await v2.show(DESK);
    const machine = machineFor(probe, v1, v2);
    if (machine === v2) return { agg: probe, machine };
    return { agg: await v1.show(DESK), machine: v1 };
  } catch (err) {
    const m = mapKernel(err);
    if (m === "not_found") return { agg: null, machine: v2 };
    fail("corrupt_state");
  }
}

function phaseOf(agg) {
  if (!agg) return "none";
  return agg.namedState();
}

function escrowOf(agg) {
  const st = phaseOf(agg);
  if (st === "under_contract") return "funded";
  if (st === "fallen") return "released";
  if (st === "accepted" && Number(agg.state.has_deposit || 0) === 1 && agg.state.deposit_id) {
    return "attempt_saved";
  }
  return "none";
}

function primaryOf(agg) {
  if (!agg || Number(agg.state.has_primary || 0) !== 1) return null;
  return {
    offer_id: agg.state.primary_offer_id,
    buyer_id: agg.state.primary_buyer_id,
    amount_cents: Number(agg.state.primary_amount_cents),
    countered: Number(agg.state.primary_countered || 0) === 1,
  };
}

function backupOf(agg) {
  if (!agg || Number(agg.state.has_backup || 0) !== 1) return null;
  return {
    offer_id: agg.state.backup_offer_id,
    buyer_id: agg.state.backup_buyer_id,
    amount_cents: Number(agg.state.backup_amount_cents),
  };
}

function nOrNull(v) {
  if (v === undefined || v === null) return null;
  return Number(v);
}

function liveDepositId(agg) {
  if (!agg) return null;
  const phase = phaseOf(agg);
  if (Number(agg.state.has_deposit || 0) !== 1) return null;
  if (phase !== "accepted" && phase !== "under_contract" && phase !== "fallen") return null;
  return agg.state.deposit_id ?? null;
}

function statusBody(agg, v1, v2) {
  if (!agg || phaseOf(agg) === "unbound") {
    return {
      listing_id: null,
      seller_id: null,
      ask_cents: null,
      accept_by_ms: null,
      deposit_window_ms: null,
      deposit_deadline_ms: null,
      accepted_ms: null,
      phase: "none",
      escrow: "none",
      primary: null,
      backup: null,
      deposit_id: null,
      deposit_cents: null,
      edition: null,
    };
  }
  const st = agg.state;
  const phase = phaseOf(agg);
  const accepted = phase === "accepted" || phase === "under_contract" || phase === "fallen";
  return {
    listing_id: st.listing_id ?? null,
    seller_id: st.seller_id ?? null,
    ask_cents: nOrNull(st.ask_cents),
    accept_by_ms: nOrNull(st.accept_by_ms),
    deposit_window_ms: nOrNull(st.deposit_window_ms),
    deposit_deadline_ms: accepted ? nOrNull(st.deposit_deadline_ms) : null,
    accepted_ms: accepted ? nOrNull(st.accepted_ms) : null,
    phase,
    escrow: escrowOf(agg),
    primary: primaryOf(agg),
    backup: backupOf(agg),
    deposit_id: liveDepositId(agg),
    deposit_cents: accepted ? nOrNull(st.deposit_cents) : null,
    edition: editionOf(agg, v1, v2),
  };
}

function openBody(agg) {
  const st = agg.state;
  return {
    listing_id: st.listing_id,
    seller_id: st.seller_id,
    ask_cents: Number(st.ask_cents),
    accept_by_ms: Number(st.accept_by_ms),
    deposit_window_ms: Number(st.deposit_window_ms),
    phase: "listed",
    escrow: "none",
    primary: null,
    backup: null,
    deposit_id: null,
    deposit_cents: null,
  };
}

function bidBody(agg) {
  return {
    listing_id: agg.state.listing_id,
    phase: phaseOf(agg),
    escrow: "none",
    primary: primaryOf(agg),
    backup: backupOf(agg),
  };
}

function fundedBody(agg) {
  return {
    listing_id: agg.state.listing_id,
    deposit_id: agg.state.deposit_id,
    deposit_cents: Number(agg.state.deposit_cents),
    phase: "under_contract",
    escrow: "funded",
  };
}

async function asCurrent(machine, result) {
  if (result instanceof HistoricalResult) return machine.show(result.aggregateId);
  return result;
}

function requireBound(agg, listingArg) {
  if (!agg || phaseOf(agg) === "unbound") fail("not_open");
  if (listingArg !== undefined && listingArg !== agg.state.listing_id) fail("listing_mismatch");
}

function digestOf(obj) {
  return createHash("sha256").update(JSON.stringify(obj)).digest("hex");
}

function newId(prefix) {
  return `${prefix}${randomBytes(12).toString("hex")}`.slice(0, 64);
}

function snapshotFrom(agg) {
  return {
    deposit_id: agg.state.deposit_id,
    listing_id: agg.state.listing_id,
    offer_id: agg.state.primary_offer_id,
    buyer_id: agg.state.primary_buyer_id,
    amount_cents: Number(agg.state.deposit_cents),
  };
}

function heldMatch(json, snap) {
  return (
    json &&
    json.outcome === "held" &&
    json.deposit_id === snap.deposit_id &&
    json.listing_id === snap.listing_id &&
    json.offer_id === snap.offer_id &&
    json.buyer_id === snap.buyer_id &&
    Number(json.amount_cents) === snap.amount_cents
  );
}

function releasedMatch(json, depositId, listingId) {
  return (
    json &&
    json.outcome === "released" &&
    json.deposit_id === depositId &&
    json.listing_id === listingId
  );
}

async function httpJson(method, url, body) {
  try {
    const res = await fetch(url, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    if (text === "") return { kind: "incomplete", status: res.status };
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      return { kind: "incomplete", status: res.status };
    }
    return { kind: "ok", status: res.status, json };
  } catch {
    return { kind: "transport" };
  }
}

async function commitFund(machine, agg, outcomeDigest) {
  let cur = agg;
  if (cur.pendingIntent) {
    const rec = await cur.recordEffectOutcome(outcomeDigest, { intent: cur.pendingIntent });
    cur = await asCurrent(machine, rec);
  }
  if (phaseOf(cur) === "accepted") {
    const funded = await cur.command("fund");
    cur = await asCurrent(machine, funded);
  }
  return cur;
}

async function cmdOpen(args) {
  if (args.length !== 5) fail("bad_args");
  const [listing_id, seller_id, askRaw, acceptRaw, windowRaw] = args;
  if (!isId(listing_id) || !isId(seller_id)) fail("bad_args");
  const ask = parsePositiveMoney(askRaw);
  if (ask.error) fail("bad_money");
  const accept = parseTimeArg(acceptRaw);
  if (accept.error) fail("bad_time");
  const win = parseTimeArg(windowRaw);
  if (win.error) fail("bad_time");
  const { v1, v2 } = await openMachines();
  const { agg: existing } = await loadDesk(v1, v2);
  if (existing && phaseOf(existing) !== "unbound") fail("already_open");
  try {
    const created = await v2.createWith({
      aggregateId: DESK,
      command: {
        name: "open",
        args: {
          listing_id,
          seller_id,
          ask_cents: ask.n,
          accept_by_ms: accept.n,
          deposit_window_ms: win.n,
        },
      },
    });
    const agg = await asCurrent(v2, created);
    ok(openBody(agg));
  } catch (err) {
    const m = mapKernel(err);
    if (m === "refused") fail("already_open");
    fail("corrupt_state");
  }
}

async function cmdBid(args, now) {
  if (args.length !== 4) fail("bad_args");
  const [listing_id, offer_id, buyer_id, amountRaw] = args;
  if (!isId(listing_id) || !isId(offer_id) || !isId(buyer_id)) fail("bad_args");
  const amount = parsePositiveMoney(amountRaw);
  if (amount.error) fail("bad_money");
  const { v1, v2 } = await openMachines();
  const loaded = await loadDesk(v1, v2);
  const agg = loaded.agg;
  const machine = loaded.machine;
  requireBound(agg, listing_id);
  const phase = phaseOf(agg);
  if (phase === "under_contract" || phase === "fallen") fail("listed_busy");
  if (phase === "expired") fail("window_elapsed");
  const p = primaryOf(agg);
  const b = backupOf(agg);
  if (phase !== "accepted" && now > Number(agg.state.accept_by_ms)) {
    try {
      const next = await asCurrent(
        machine,
        await agg.execute({
          name: "bid",
          args: {
            offer_id,
            buyer_id,
            amount_cents: amount.n,
            now_ms: now,
          },
        }),
      );
      if (phaseOf(next) === "expired") fail("window_elapsed");
    } catch (err) {
      mapKernel(err);
      fail("window_elapsed");
    }
    fail("window_elapsed");
  }
  if ((p && p.offer_id === offer_id) || (b && b.offer_id === offer_id)) fail("already_offered");
  if (b) fail("desk_full");
  try {
    const next = await asCurrent(
      machine,
      await agg.execute({
        name: "bid",
        args: {
          offer_id,
          buyer_id,
          amount_cents: amount.n,
          now_ms: now,
        },
      }),
    );
    if (phaseOf(next) === "expired") fail("window_elapsed");
    ok(bidBody(next));
  } catch (err) {
    mapKernel(err);
    fail("desk_full");
  }
}

async function cmdCounter(args, now) {
  if (args.length !== 3) fail("bad_args");
  const [listing_id, offer_id, amountRaw] = args;
  if (!isId(listing_id) || !isId(offer_id)) fail("bad_args");
  const amount = parsePositiveMoney(amountRaw);
  if (amount.error) fail("bad_money");
  const { v1, v2 } = await openMachines();
  const loaded = await loadDesk(v1, v2);
  const agg = loaded.agg;
  const machine = loaded.machine;
  requireBound(agg, listing_id);
  const phase = phaseOf(agg);
  const p = primaryOf(agg);
  if (!p) fail("no_offer");
  if (p.offer_id !== offer_id) fail("not_primary");
  if (p.countered) fail("already_countered");
  if (phase !== "offered") fail("not_offered");
  if (phase === "expired") fail("window_elapsed");
  try {
    const next = await asCurrent(
      machine,
      await agg.execute({
        name: "counter",
        args: { offer_id, amount_cents: amount.n, now_ms: now },
      }),
    );
    if (phaseOf(next) === "expired") fail("window_elapsed");
    ok({
      listing_id: next.state.listing_id,
      phase: "countered",
      primary: primaryOf(next),
      backup: backupOf(next),
    });
  } catch (err) {
    mapKernel(err);
    fail("not_offered");
  }
}

async function cmdAccept(args, now) {
  if (args.length !== 2) fail("bad_args");
  const [listing_id, offer_id] = args;
  if (!isId(listing_id) || !isId(offer_id)) fail("bad_args");
  const { v1, v2 } = await openMachines();
  const loaded = await loadDesk(v1, v2);
  const agg = loaded.agg;
  const machine = loaded.machine;
  requireBound(agg, listing_id);
  const phase = phaseOf(agg);
  const p = primaryOf(agg);
  if (!p) fail("no_offer");
  if (p.offer_id !== offer_id) fail("not_primary");
  if (phase === "accepted" || phase === "under_contract" || escrowOf(agg) === "attempt_saved") {
    fail("already_accepted");
  }
  if (phase === "fallen") fail("already_fallen");
  if (phase === "expired") fail("window_elapsed");
  const deposit_cents = Math.floor(p.amount_cents / 50);
  const revised = editionOf(agg, v1, v2) === "revised";
  const deposit_deadline_ms = revised
    ? now + Number(agg.state.deposit_window_ms)
    : Number(agg.state.accept_by_ms);
  try {
    const next = await asCurrent(
      machine,
      await agg.execute({
        name: "accept",
        args: {
          offer_id,
          now_ms: now,
          deposit_cents,
          deposit_deadline_ms,
        },
      }),
    );
    if (phaseOf(next) === "expired") fail("window_elapsed");
    ok({
      listing_id: next.state.listing_id,
      phase: "accepted",
      escrow: "none",
      primary: primaryOf(next),
      backup: backupOf(next),
      accepted_ms: Number(next.state.accepted_ms),
      deposit_deadline_ms: Number(next.state.deposit_deadline_ms),
      deposit_cents: Number(next.state.deposit_cents),
    });
  } catch (err) {
    mapKernel(err);
    fail("window_elapsed");
  }
}

async function cmdDeposit(args, now, base) {
  if (args.length !== 1) fail("bad_args");
  const [listing_id] = args;
  if (!isId(listing_id)) fail("bad_args");
  const { v1, v2 } = await openMachines();
  const loaded = await loadDesk(v1, v2);
  let agg = loaded.agg;
  const machine = loaded.machine;
  requireBound(agg, listing_id);
  if (phaseOf(agg) === "under_contract" && escrowOf(agg) === "funded") {
    ok(fundedBody(agg));
  }
  if (phaseOf(agg) !== "accepted") fail("not_accepted");
  const gated = await asCurrent(machine, await agg.execute({ name: "deposit_gate", args: { now_ms: now } }));
  if (phaseOf(gated) === "expired") fail("deposit_elapsed");
  agg = gated;
  const snap = Number(agg.state.has_deposit || 0) === 1 && agg.state.deposit_id ? snapshotFrom(agg) : null;
  if (!snap) {
    const deposit_id = newId("d");
    const payload = {
      deposit_id,
      listing_id: agg.state.listing_id,
      offer_id: agg.state.primary_offer_id,
      buyer_id: agg.state.primary_buyer_id,
      amount_cents: Number(agg.state.deposit_cents),
    };
    const payload_digest = digestOf(payload);
    agg = await asCurrent(
      machine,
      await agg.execute({
        name: "save_deposit",
        args: { deposit_id, payload_digest, idempotency_key: deposit_id },
      }),
    );
    crash("after-deposit-saved-before-request");
    const posted = await httpJson("POST", `${base}/v1/deposits`, payload);
    if (posted.kind !== "ok" || posted.status >= 500) fail("service_unavailable");
    if (posted.status === 409 || (posted.status === 200 && !heldMatch(posted.json, payload))) {
      fail("lookup_conflict");
    }
    if (posted.status !== 200 || !heldMatch(posted.json, payload)) fail("service_unavailable");
    crash("after-accept-before-record");
    agg = await commitFund(machine, agg, digestOf(posted.json));
    crash("after-record-before-exit");
    ok(fundedBody(agg));
  }
  const saved = snapshotFrom(agg);
  const looked = await httpJson("GET", `${base}/v1/deposits/${encodeURIComponent(saved.deposit_id)}`);
  if (looked.kind !== "ok") fail("service_unavailable");
  if (looked.status === 200) {
    if (!heldMatch(looked.json, saved)) fail("lookup_conflict");
    crash("after-accept-before-record");
    agg = await commitFund(machine, agg, digestOf(looked.json));
    crash("after-record-before-exit");
    ok(fundedBody(agg));
  }
  if (looked.status === 404) {
    const payload = saved;
    const posted = await httpJson("POST", `${base}/v1/deposits`, payload);
    if (posted.kind !== "ok" || posted.status >= 500) fail("service_unavailable");
    if (posted.status === 409 || (posted.status === 200 && !heldMatch(posted.json, payload))) {
      fail("lookup_conflict");
    }
    if (posted.status !== 200 || !heldMatch(posted.json, payload)) fail("service_unavailable");
    crash("after-accept-before-record");
    agg = await commitFund(machine, agg, digestOf(posted.json));
    crash("after-record-before-exit");
    ok(fundedBody(agg));
  }
  fail("service_unavailable");
}

async function cmdReconcile(args, now, base) {
  if (args.length !== 2) fail("bad_args");
  const [listing_id, deposit_id] = args;
  if (!isId(listing_id) || !isId(deposit_id)) fail("bad_args");
  const { v1, v2 } = await openMachines();
  const loaded = await loadDesk(v1, v2);
  let agg = loaded.agg;
  const machine = loaded.machine;
  requireBound(agg, listing_id);
  if (Number(agg.state.has_deposit || 0) !== 1 || !agg.state.deposit_id) fail("no_deposit");
  if (agg.state.deposit_id !== deposit_id) fail("deposit_mismatch");
  if (phaseOf(agg) === "under_contract") {
    ok({ ...fundedBody(agg), lookup: "funded" });
  }
  if (phaseOf(agg) !== "accepted") fail("no_deposit");
  const looked = await httpJson("GET", `${base}/v1/deposits/${encodeURIComponent(deposit_id)}`);
  if (looked.kind !== "ok") fail("service_unavailable");
  if (looked.status === 404) {
    ok({
      lookup: "not_sent",
      listing_id: agg.state.listing_id,
      deposit_id,
      phase: "accepted",
      escrow: "attempt_saved",
    });
  }
  if (looked.status === 200) {
    const snap = snapshotFrom(agg);
    if (!heldMatch(looked.json, snap)) fail("lookup_conflict");
    crash("after-accept-before-record");
    agg = await commitFund(machine, agg, digestOf(looked.json));
    crash("after-record-before-exit");
    ok({ ...fundedBody(agg), lookup: "funded" });
  }
  fail("service_unavailable");
}

async function cmdFallthrough(args, base) {
  if (args.length !== 1) fail("bad_args");
  const [listing_id] = args;
  if (!isId(listing_id)) fail("bad_args");
  const { v1, v2 } = await openMachines();
  const loaded = await loadDesk(v1, v2);
  let agg = loaded.agg;
  const machine = loaded.machine;
  requireBound(agg, listing_id);
  if (phaseOf(agg) === "fallen") fail("already_fallen");
  if (phaseOf(agg) !== "under_contract") fail("not_funded");
  const deposit_id = agg.state.deposit_id;
  if (!agg.pendingIntent || agg.pendingIntent.effectKind !== "escrow.release") {
    const rel_key = `r-${deposit_id}`.slice(0, 64);
    const rel_digest = digestOf({ deposit_id, listing_id: agg.state.listing_id });
    agg = await asCurrent(
      machine,
      await agg.execute({
        name: "start_release",
        args: { deposit_id, rel_digest, rel_key },
      }),
    );
  }
  const body = { deposit_id, listing_id: agg.state.listing_id };
  const posted = await httpJson(
    "POST",
    `${base}/v1/deposits/${encodeURIComponent(deposit_id)}/release`,
    body,
  );
  if (posted.kind !== "ok" || posted.status >= 500) fail("service_unavailable");
  if (posted.status !== 200 || !releasedMatch(posted.json, deposit_id, body.listing_id)) {
    fail("service_unavailable");
  }
  if (agg.pendingIntent) {
    const rec = await agg.recordEffectOutcome(digestOf(posted.json), { intent: agg.pendingIntent });
    agg = await asCurrent(machine, rec);
  }
  agg = await asCurrent(machine, await agg.command("mark_fallen"));
  ok({
    listing_id: agg.state.listing_id,
    phase: "fallen",
    escrow: "released",
    deposit_id: agg.state.deposit_id,
    primary: primaryOf(agg),
    backup: backupOf(agg),
  });
}

async function cmdPromote(args) {
  if (args.length !== 1) fail("bad_args");
  const [listing_id] = args;
  if (!isId(listing_id)) fail("bad_args");
  const { v1, v2 } = await openMachines();
  const loaded = await loadDesk(v1, v2);
  const agg = loaded.agg;
  const machine = loaded.machine;
  requireBound(agg, listing_id);
  if (editionOf(agg, v1, v2) !== "revised") fail("legacy_listing");
  if (phaseOf(agg) !== "fallen") fail("not_fallen");
  const b = backupOf(agg);
  if (!b) fail("no_backup");
  try {
    const next = await asCurrent(
      machine,
      await agg.execute({
        name: "promote",
        args: { offer_id: b.offer_id, buyer_id: b.buyer_id, amount_cents: b.amount_cents },
      }),
    );
    ok({
      listing_id: next.state.listing_id,
      phase: "offered",
      escrow: "none",
      primary: primaryOf(next),
      backup: null,
      deposit_id: null,
      deposit_cents: null,
      edition: "revised",
    });
  } catch (err) {
    mapKernel(err);
    fail("no_backup");
  }
}

async function cmdStatus() {
  const { v1, v2 } = await openMachines();
  const { agg } = await loadDesk(v1, v2);
  ok(statusBody(agg, v1, v2));
}

async function cmdCallback(args) {
  if (args.length !== 1) fail("bad_args");
  const p = args[0];
  if (p === undefined || p === "") fail("bad_args");
  const path = isAbsolute(p) ? p : join(process.cwd(), p);
  let raw;
  try {
    raw = readFileSync(path, "utf8");
  } catch {
    fail("bad_callback");
  }
  let json;
  try {
    json = JSON.parse(raw);
  } catch {
    fail("bad_callback");
  }
  if (json === null || typeof json !== "object" || Array.isArray(json)) fail("bad_callback");
  const { v1, v2 } = await openMachines();
  const loaded = await loadDesk(v1, v2);
  const agg = loaded.agg;
  requireBound(agg);
  const phase = phaseOf(agg);
  if (phase === "under_contract" || phase === "fallen" || phase === "expired") ok({ ignored: true, phase });
  try {
    await agg.command("ignore_callback");
  } catch (err) {
    mapKernel(err);
  }
  ok({ ignored: true, phase });
}

function ownedLooksCorrupt() {
  const p = storePath();
  if (!existsSync(p)) return false;
  try {
    const st = statSync(p);
    if (!st.isFile()) return true;
  } catch {
    return true;
  }
  return false;
}

async function main() {
  const argv = process.argv.slice(2);
  nowMs();
  serviceUrl();
  stateDir();
  if (ownedLooksCorrupt()) fail("corrupt_state");
  const cmd = argv[0];
  if (!cmd) fail("unknown_command");
  const rest = argv.slice(1);
  const now = nowMs();
  const base = serviceUrl();
  switch (cmd) {
    case "open":
      return cmdOpen(rest);
    case "bid":
      return cmdBid(rest, now);
    case "counter":
      return cmdCounter(rest, now);
    case "accept":
      return cmdAccept(rest, now);
    case "deposit":
      return cmdDeposit(rest, now, base);
    case "reconcile":
      return cmdReconcile(rest, now, base);
    case "fallthrough":
      return cmdFallthrough(rest, base);
    case "promote":
      return cmdPromote(rest);
    case "status":
      if (rest.length !== 0) fail("bad_args");
      return cmdStatus();
    case "callback":
      return cmdCallback(rest);
    default:
      fail("unknown_command");
  }
}

main().catch((err) => {
  try {
    mapKernel(err);
  } catch {
    /* already exited */
  }
  fail("corrupt_state");
});
