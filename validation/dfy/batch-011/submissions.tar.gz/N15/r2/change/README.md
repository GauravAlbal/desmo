# Property offer and escrow desk

Durable local desk for one residential listing. Lifecycle authority is the Ikaros machine `listing.ik.toml`; `desk.mjs` owns CLI, HTTP, and crash labels.

## Setup

Node 22 (`<home>/.nvm/versions/node/v22.17.1/bin/node` or any Node 22 on `PATH`). No npm registry.

```sh
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x ./run
```

## Run

Start the fake escrow service from `stub/server.mjs` (prints `service_url`). Then:

```sh
export STATE_DIR=/tmp/desk-state
export SERVICE_URL=http://127.0.0.1:<port>
export NOW_MS=0
mkdir -p "$STATE_DIR"
./run open L1 S1 10000 100000 5000
./run bid L1 O1 B1 10000
./run status
```

Commands: `open`, `bid`, `counter`, `accept`, `deposit`, `reconcile`, `fallthrough`, `status`, `callback`. Optional `CRASH_AT` is one of `after-deposit-saved-before-request`, `after-accept-before-record`, `after-record-before-exit`.

## Tests

```sh
NODE_BIN=<home>/.nvm/versions/node/v22.17.1/bin/node "$NODE_BIN" --test test/desk.test.mjs
```
