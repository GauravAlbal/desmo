# Property offer and escrow desk

Durable local desk for one listing. Lifecycle authority is an Ikaros machine (`machines/desk.ik.toml`). The host CLI talks to the supplied escrow stub and never invents a second store for phase.

## Setup

Node 22. Offline install of the shipped tarballs:

```bash
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x run
```

Start the fake escrow service from this directory (`node stub/server.mjs`). It prints `{service_url, control_url}`.

## Run

Environment (required on every command, including `status`):

- `STATE_DIR` — directory for the Ikaros sqlite file (`desk.sqlite`) plus any unrelated files
- `SERVICE_URL` — stub `service_url` (status never contacts it)
- `NOW_MS` — non-negative epoch-ms integer
- `CRASH_AT` — optional crash label

```bash
export STATE_DIR=/tmp/desk1 SERVICE_URL=http://127.0.0.1:PORT NOW_MS=100
./run open L1 S1 10000 5000 1000
./run bid L1 O1 B1 10000
./run counter L1 O1 11000
./run bid L1 O2 B2 9000
NOW_MS=200 ./run accept L1 O1
NOW_MS=300 ./run deposit L1
./run status
./run fallthrough L1
```

`./run` prints one JSON object.

## Tests

```bash
node --test test/desk.test.mjs
```

Covers process restart, `CRASH_AT` labels, dropped replies, reconcile `not_sent`, unrelated file bytes, and common refusals.
