import { createHash, randomBytes } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Kernel,
  StoreNotFoundError,
  HistoricalResult,
  classify,
} from "@ikaros/runtime";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const MACHINE_V1 = join(ROOT, "machines", "desk.ik.toml");
const MACHINE_V2 = join(ROOT, "machines", "desk_v2.ik.toml");
const AGG = "desk";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;

function out(obj, code = 0) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(code);
}
function fail(code) {
  out({ error: code }, 1);
}
function crash(label) {
  if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL");
}

function parseNow() {
  const raw = process.env.NOW_MS;
  if (raw === undefined || raw === "") fail("bad_time");
  if (!/^(0|[1-9][0-9]*)$/.test(raw)) fail("bad_time");
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0) fail("bad_time");
  return n;
}
function requireService() {
  const u = process.env.SERVICE_URL;
  if (!u) fail("bad_args");
  return u.replace(/\/$/, "");
}
function stateDir() {
  const d = process.env.STATE_DIR;
  if (!d) fail("bad_args");
  return d;
}
function storePath() {
  return join(stateDir(), "desk.sqlite");
}
function isId(s) {
  return typeof s === "string" && ID_RE.test(s);
}
function parseMoney(s) {
  if (s === undefined || !/^(0|[1-9][0-9]*)$/.test(s)) return null;
  const n = Number(s);
  if (!Number.isSafeInteger(n) || n < 0) return null;
  return n;
}
function parseTimeArg(s) {
  if (s === undefined || !/^(0|[1-9][0-9]*)$/.test(s)) return null;
  const n = Number(s);
  if (!Number.isSafeInteger(n) || n < 0) return null;
  return n;
}

function factsOf(agg) {
  const st = agg.state;
  if (st && typeof st === "object" && st.facts && typeof st.facts === "object") return st.facts;
  if (st && typeof st === "object") return st;
  return {};
}
function num(facts, k) {
  const v = facts[k];
  if (v === undefined || v === null) return null;
  const n = typeof v === "bigint" ? Number(v) : Number(v);
  return Number.isFinite(n) ? n : null;
}
function str(facts, k) {
  const v = facts[k];
  if (v === undefined || v === null || v === "") return null;
  return String(v);
}
function rawPhase(agg) {
  return agg.namedState();
}
function phaseOf(agg) {
  const n = rawPhase(agg);
  if (n === "unbound") return "none";
  if (n === "fallen_open") return "fallen";
  return n;
}
function isFallen(agg) {
  const n = rawPhase(agg);
  return n === "fallen" || n === "fallen_open";
}
function editionOf(agg) {
  if (!agg || rawPhase(agg) === "unbound") return null;
  const v = Number(agg.owner.version);
  if (v === 1) return "original";
  if (v === 2) return "revised";
  return null;
}
function isOriginal(agg) {
  return editionOf(agg) === "original";
}
function escrowOf(facts) {
  const c = num(facts, "escrow_code") ?? 0;
  if (c === 1) return "attempt_saved";
  if (c === 2) return "funded";
  if (c === 3) return "released";
  return "none";
}
function primaryOf(facts) {
  if ((num(facts, "has_primary") ?? 0) !== 1) return null;
  return {
    offer_id: str(facts, "primary_offer_id"),
    buyer_id: str(facts, "primary_buyer_id"),
    amount_cents: num(facts, "primary_amount_cents"),
    countered: (num(facts, "primary_countered") ?? 0) === 1,
  };
}
function backupOf(facts) {
  if ((num(facts, "has_backup") ?? 0) !== 1) return null;
  return {
    offer_id: str(facts, "backup_offer_id"),
    buyer_id: str(facts, "backup_buyer_id"),
    amount_cents: num(facts, "backup_amount_cents"),
  };
}

function depositFieldsForStatus(agg, f) {
  const phase = phaseOf(agg);
  if (phase === "listed" || phase === "offered" || phase === "countered" || phase === "none") {
    return { deposit_deadline_ms: null, accepted_ms: null, deposit_id: null, deposit_cents: null };
  }
  return {
    deposit_deadline_ms: num(f, "deposit_deadline_ms"),
    accepted_ms: num(f, "accepted_ms"),
    deposit_id: str(f, "deposit_id"),
    deposit_cents: num(f, "deposit_cents"),
  };
}

function statusBody(agg) {
  if (!agg || rawPhase(agg) === "unbound") {
    return {
      listing_id: null,
      seller_id: null,
      ask_cents: null,
      accept_by_ms: null,
      deposit_window_ms: null,
      deposit_deadline_ms: null,
      accepted_ms: null,
      phase: "none",
      escrow: "none",
      primary: null,
      backup: null,
      deposit_id: null,
      deposit_cents: null,
      edition: null,
    };
  }
  const f = factsOf(agg);
  const dep = depositFieldsForStatus(agg, f);
  return {
    listing_id: str(f, "listing_id"),
    seller_id: str(f, "seller_id"),
    ask_cents: num(f, "ask_cents"),
    accept_by_ms: num(f, "accept_by_ms"),
    deposit_window_ms: num(f, "deposit_window_ms"),
    deposit_deadline_ms: dep.deposit_deadline_ms,
    accepted_ms: dep.accepted_ms,
    phase: phaseOf(agg),
    escrow: escrowOf(f),
    primary: primaryOf(f),
    backup: backupOf(f),
    deposit_id: dep.deposit_id,
    deposit_cents: dep.deposit_cents,
    edition: editionOf(agg),
  };
}

function emptyStatus() {
  return statusBody(null);
}

function mapKernel(err) {
  if (err instanceof StoreNotFoundError) return "not_open";
  try {
    const c = classify(err);
    if (c === "corrupt") return "corrupt_state";
    if (c === "not_found") return "not_open";
  } catch {
    /* ignore */
  }
  if (err && err.code === "IK_STORE_CORRUPT") return "corrupt_state";
  return null;
}

async function machines() {
  const kernel = new Kernel(storePath());
  const v1 = await kernel.machine(MACHINE_V1);
  const v2 = await kernel.machine(MACHINE_V2);
  return { kernel, v1, v2 };
}

function routeMachine(bundle, owner) {
  if (owner.equals(bundle.v1.identity)) return bundle.v1;
  if (owner.equals(bundle.v2.identity)) return bundle.v2;
  fail("corrupt_state");
}

async function load() {
  if (!existsSync(storePath())) return { missing: true, machine: null, agg: null, bundle: null };
  try {
    const bundle = await machines();
    let probe;
    try {
      probe = await bundle.v2.show(AGG);
    } catch {
      probe = await bundle.v1.show(AGG);
    }
    const m = routeMachine(bundle, probe.owner);
    const agg = m === probe.machine ? probe : await m.show(AGG);
    return { missing: false, machine: m, agg, bundle };
  } catch (err) {
    const mapped = mapKernel(err);
    if (mapped === "corrupt_state") fail("corrupt_state");
    if (err instanceof StoreNotFoundError) return { missing: true, machine: null, agg: null, bundle: null };
    fail(mapped || "corrupt_state");
  }
}

async function exec(agg, name, args) {
  const r = await agg.command(name, args);
  if (r instanceof HistoricalResult) {
    return agg.machine.show(AGG);
  }
  return r;
}

function boundListing(agg) {
  return str(factsOf(agg), "listing_id");
}

function needListing(agg, listingId) {
  if (!agg || rawPhase(agg) === "unbound") fail("not_open");
  if (listingId !== boundListing(agg)) fail("listing_mismatch");
}

function digest(obj) {
  return createHash("sha256").update(JSON.stringify(obj)).digest("hex");
}

async function httpJson(method, url, body) {
  try {
    const res = await fetch(url, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    if (!text) return { kind: "incomplete", status: res.status };
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      return { kind: "incomplete", status: res.status };
    }
    return { kind: "ok", status: res.status, json };
  } catch {
    return { kind: "transport" };
  }
}

function matchingHeld(json, snap) {
  return (
    json &&
    json.outcome === "held" &&
    json.deposit_id === snap.deposit_id &&
    json.listing_id === snap.listing_id &&
    json.offer_id === snap.offer_id &&
    json.buyer_id === snap.buyer_id &&
    json.amount_cents === snap.amount_cents
  );
}

function fundedObj(agg) {
  const f = factsOf(agg);
  return {
    listing_id: str(f, "listing_id"),
    deposit_id: str(f, "deposit_id"),
    deposit_cents: num(f, "deposit_cents"),
    phase: "under_contract",
    escrow: "funded",
  };
}

function snapshotFrom(agg) {
  const f = factsOf(agg);
  return {
    deposit_id: str(f, "deposit_id"),
    listing_id: str(f, "listing_id"),
    offer_id: str(f, "deposit_offer_id") || str(f, "primary_offer_id"),
    buyer_id: str(f, "deposit_buyer_id") || str(f, "primary_buyer_id"),
    amount_cents: num(f, "deposit_cents"),
  };
}

async function recordAndCompleteHold(agg, responseJson) {
  crash("after-accept-before-record");
  const intent = agg.pendingIntent;
  if (intent) {
    const rec = await agg.recordEffectOutcome(digest(responseJson), { intent });
    agg = rec instanceof HistoricalResult ? await agg.machine.show(AGG) : rec;
  }
  agg = await exec(agg, "complete_hold");
  crash("after-record-before-exit");
  return agg;
}

function depositDeadline(agg, now) {
  const f = factsOf(agg);
  if (isOriginal(agg)) return num(f, "accept_by_ms");
  return now + (num(f, "deposit_window_ms") ?? 0);
}

async function cmdOpen(args) {
  const listingId = args[0];
  const sellerId = args[1];
  const ask = parseMoney(args[2]);
  const acceptBy = parseTimeArg(args[3]);
  const depWin = parseTimeArg(args[4]);
  if (args.length !== 5) fail("bad_args");
  if (!isId(listingId) || !isId(sellerId)) fail("bad_args");
  if (ask === null || ask < 1) fail("bad_money");
  if (acceptBy === null || depWin === null) fail("bad_time");
  const loaded = await load();
  if (!loaded.missing && loaded.agg && rawPhase(loaded.agg) !== "unbound") fail("already_open");
  const bundle = loaded.bundle || (await machines());
  const m = bundle.v2;
  let agg;
  try {
    const created = await m.createWith({
      aggregateId: AGG,
      command: {
        name: "open",
        args: {
          listing_id: listingId,
          seller_id: sellerId,
          ask_cents: ask,
          accept_by_ms: acceptBy,
          deposit_window_ms: depWin,
        },
      },
    });
    agg = created instanceof HistoricalResult ? await m.show(AGG) : created;
  } catch (err) {
    const mapped = mapKernel(err);
    if (mapped === "corrupt_state") fail("corrupt_state");
    fail("already_open");
  }
  const f = factsOf(agg);
  out({
    listing_id: str(f, "listing_id"),
    seller_id: str(f, "seller_id"),
    ask_cents: num(f, "ask_cents"),
    accept_by_ms: num(f, "accept_by_ms"),
    deposit_window_ms: num(f, "deposit_window_ms"),
    phase: "listed",
    escrow: "none",
    primary: null,
    backup: null,
    deposit_id: null,
    deposit_cents: null,
  });
}

async function cmdBid(args, now) {
  if (args.length !== 4) fail("bad_args");
  const [listingId, offerId, buyerId, amountRaw] = args;
  if (!isId(listingId) || !isId(offerId) || !isId(buyerId)) fail("bad_args");
  const amount = parseMoney(amountRaw);
  if (amount === null || amount < 1) fail("bad_money");
  const loaded = await load();
  if (loaded.missing) fail("not_open");
  let agg = loaded.agg;
  needListing(agg, listingId);
  const st = phaseOf(agg);
  const f = factsOf(agg);
  if (st === "under_contract" || st === "fallen") fail("listed_busy");
  if (st === "expired" || (st !== "accepted" && now > (num(f, "accept_by_ms") ?? 0))) {
    if (st !== "expired") {
      try {
        agg = await exec(agg, "expire_window", { now_ms: now });
      } catch {
        /* already expired or refused */
      }
    }
    fail("window_elapsed");
  }
  const primaryId = str(f, "primary_offer_id");
  const backupId = str(f, "backup_offer_id");
  if (offerId === primaryId || ((num(f, "has_backup") ?? 0) === 1 && offerId === backupId)) {
    fail("already_offered");
  }
  if ((num(f, "has_backup") ?? 0) === 1) fail("desk_full");
  const bidArgs = { offer_id: offerId, buyer_id: buyerId, amount_cents: amount, now_ms: now };
  try {
    if (st === "listed") agg = await exec(agg, "bid_primary", bidArgs);
    else if (st === "offered") agg = await exec(agg, "bid_backup", bidArgs);
    else if (st === "countered") agg = await exec(agg, "bid_backup_keep_countered", bidArgs);
    else if (st === "accepted") agg = await exec(agg, "bid_backup_accepted", bidArgs);
    else fail("listed_busy");
  } catch (err) {
    fail(mapKernel(err) || "bad_args");
  }
  const nf = factsOf(agg);
  out({
    listing_id: str(nf, "listing_id"),
    phase: phaseOf(agg),
    escrow: "none",
    primary: primaryOf(nf),
    backup: backupOf(nf),
  });
}

async function cmdCounter(args, now) {
  if (args.length !== 3) fail("bad_args");
  const [listingId, offerId, amountRaw] = args;
  if (!isId(listingId) || !isId(offerId)) fail("bad_args");
  const amount = parseMoney(amountRaw);
  if (amount === null || amount < 1) fail("bad_money");
  const loaded = await load();
  if (loaded.missing) fail("not_open");
  let agg = loaded.agg;
  needListing(agg, listingId);
  const st = phaseOf(agg);
  const f = factsOf(agg);
  if ((num(f, "has_primary") ?? 0) !== 1) fail("no_offer");
  if (offerId !== str(f, "primary_offer_id")) fail("not_primary");
  if ((num(f, "primary_countered") ?? 0) === 1) fail("already_countered");
  if (st !== "offered") fail("not_offered");
  if (now > (num(f, "accept_by_ms") ?? 0)) {
    try {
      await exec(agg, "expire_window", { now_ms: now });
    } catch {
      /* ignore */
    }
    fail("window_elapsed");
  }
  try {
    agg = await exec(agg, "counter", { offer_id: offerId, amount_cents: amount });
  } catch (err) {
    fail(mapKernel(err) || "not_offered");
  }
  const nf = factsOf(agg);
  out({
    listing_id: str(nf, "listing_id"),
    phase: "countered",
    primary: primaryOf(nf),
    backup: backupOf(nf),
  });
}

async function cmdAccept(args, now) {
  if (args.length !== 2) fail("bad_args");
  const [listingId, offerId] = args;
  if (!isId(listingId) || !isId(offerId)) fail("bad_args");
  const loaded = await load();
  if (loaded.missing) fail("not_open");
  let agg = loaded.agg;
  needListing(agg, listingId);
  const st = phaseOf(agg);
  const f = factsOf(agg);
  const esc = escrowOf(f);
  if ((num(f, "has_primary") ?? 0) !== 1) fail("no_offer");
  if (offerId !== str(f, "primary_offer_id")) fail("not_primary");
  if (st === "accepted" || st === "under_contract" || esc === "attempt_saved") fail("already_accepted");
  if (st === "fallen") fail("already_fallen");
  if (st === "expired" || now > (num(f, "accept_by_ms") ?? 0)) {
    if (st !== "expired" && st !== "accepted" && st !== "under_contract") {
      try {
        await exec(agg, "expire_window", { now_ms: now });
      } catch {
        /* ignore */
      }
    }
    fail("window_elapsed");
  }
  const amount = num(f, "primary_amount_cents") ?? 0;
  const depositCents = Math.floor(amount / 50);
  try {
    agg = await exec(agg, "accept", {
      offer_id: offerId,
      now_ms: now,
      deposit_cents: depositCents,
      deposit_deadline_ms: depositDeadline(agg, now),
      deposit_offer_id: str(f, "primary_offer_id"),
      deposit_buyer_id: str(f, "primary_buyer_id"),
    });
  } catch (err) {
    fail(mapKernel(err) || "not_offered");
  }
  const nf = factsOf(agg);
  out({
    listing_id: str(nf, "listing_id"),
    phase: "accepted",
    escrow: "none",
    primary: primaryOf(nf),
    backup: backupOf(nf),
    accepted_ms: num(nf, "accepted_ms"),
    deposit_deadline_ms: num(nf, "deposit_deadline_ms"),
    deposit_cents: num(nf, "deposit_cents"),
  });
}

async function adoptFunded(agg, json, serviceUrl) {
  void serviceUrl;
  agg = await recordAndCompleteHold(agg, json);
  out(fundedObj(agg));
}

async function postDeposit(agg, serviceUrl, snap) {
  crash("after-deposit-saved-before-request");
  const res = await httpJson("POST", `${serviceUrl}/v1/deposits`, snap);
  if (res.kind !== "ok") fail("service_unavailable");
  if (res.status === 409) fail("lookup_conflict");
  if (res.status !== 200 || !matchingHeld(res.json, snap)) {
    if (res.status >= 500) fail("service_unavailable");
    fail("lookup_conflict");
  }
  await adoptFunded(agg, res.json, serviceUrl);
}

async function cmdDeposit(args, now, serviceUrl) {
  if (args.length !== 1) fail("bad_args");
  const listingId = args[0];
  if (!isId(listingId)) fail("bad_args");
  const loaded = await load();
  if (loaded.missing) fail("not_open");
  let agg = loaded.agg;
  needListing(agg, listingId);
  let st = phaseOf(agg);
  let f = factsOf(agg);
  let esc = escrowOf(f);
  if (st === "under_contract" && esc === "funded") {
    try {
      agg = await exec(agg, "deposit_funded_noop");
    } catch {
      /* still funded */
    }
    out(fundedObj(agg));
  }
  if (st !== "accepted") fail("not_accepted");
  const deadline = num(f, "deposit_deadline_ms");
  if (deadline !== null && now > deadline) {
    try {
      await exec(agg, "expire_deposit", { now_ms: now });
    } catch {
      /* ignore */
    }
    fail("deposit_elapsed");
  }
  if (esc === "none") {
    const snapBase = snapshotFrom(agg);
    const depositId = "d" + randomBytes(16).toString("hex");
    const payload = digest({ ...snapBase, deposit_id: depositId });
    agg = await exec(agg, "plan_deposit", {
      deposit_id: depositId,
      effect_id: depositId,
      payload_digest: payload,
      idempotency_key: depositId,
      now_ms: now,
    });
    const snap = snapshotFrom(agg);
    await postDeposit(agg, serviceUrl, snap);
  }
  const snap = snapshotFrom(agg);
  const got = await httpJson("GET", `${serviceUrl}/v1/deposits/${encodeURIComponent(snap.deposit_id)}`);
  if (got.kind !== "ok") fail("service_unavailable");
  if (got.status === 200) {
    if (!matchingHeld(got.json, snap)) fail("lookup_conflict");
    await adoptFunded(agg, got.json, serviceUrl);
  }
  if (got.status === 404) {
    await postDeposit(agg, serviceUrl, snap);
  }
  fail("service_unavailable");
}

async function cmdReconcile(args, serviceUrl) {
  if (args.length !== 2) fail("bad_args");
  const [listingId, depositId] = args;
  if (!isId(listingId) || !isId(depositId)) fail("bad_args");
  const loaded = await load();
  if (loaded.missing) fail("not_open");
  let agg = loaded.agg;
  needListing(agg, listingId);
  const f = factsOf(agg);
  const saved = str(f, "deposit_id");
  if (!saved) fail("no_deposit");
  if (saved !== depositId) fail("deposit_mismatch");
  if (phaseOf(agg) === "under_contract" && escrowOf(f) === "funded") {
    out({ ...fundedObj(agg), lookup: "funded" });
  }
  const snap = snapshotFrom(agg);
  const got = await httpJson("GET", `${serviceUrl}/v1/deposits/${encodeURIComponent(depositId)}`);
  if (got.kind !== "ok") fail("service_unavailable");
  if (got.status === 404) {
    out({
      lookup: "not_sent",
      listing_id: listingId,
      deposit_id: depositId,
      phase: "accepted",
      escrow: "attempt_saved",
    });
  }
  if (got.status === 200) {
    if (!matchingHeld(got.json, snap)) fail("lookup_conflict");
    if (phaseOf(agg) !== "under_contract") {
      agg = await recordAndCompleteHold(agg, got.json);
    }
    out({ ...fundedObj(agg), lookup: "funded" });
  }
  fail("service_unavailable");
}

async function cmdFallthrough(args, serviceUrl) {
  if (args.length !== 1) fail("bad_args");
  const listingId = args[0];
  if (!isId(listingId)) fail("bad_args");
  const loaded = await load();
  if (loaded.missing) fail("not_open");
  let agg = loaded.agg;
  needListing(agg, listingId);
  const st = phaseOf(agg);
  if (st === "fallen") fail("already_fallen");
  if (st !== "under_contract" || escrowOf(factsOf(agg)) !== "funded") fail("not_funded");
  const f = factsOf(agg);
  const depositId = str(f, "deposit_id");
  const body = { deposit_id: depositId, listing_id: listingId };
  const payload = digest(body);
  const effectId = "r" + depositId;
  if (!agg.pendingIntent) {
    agg = await exec(agg, "plan_release", {
      effect_id: effectId,
      payload_digest: payload,
      idempotency_key: effectId,
    });
  }
  const res = await httpJson("POST", `${serviceUrl}/v1/deposits/${encodeURIComponent(depositId)}/release`, body);
  if (res.kind !== "ok" || res.status >= 500) fail("service_unavailable");
  if (res.status !== 200 || !res.json || res.json.outcome !== "released" || res.json.deposit_id !== depositId || res.json.listing_id !== listingId) {
    fail("service_unavailable");
  }
  const intent = agg.pendingIntent;
  if (intent) {
    const rec = await agg.recordEffectOutcome(digest(res.json), { intent });
    agg = rec instanceof HistoricalResult ? await agg.machine.show(AGG) : rec;
  }
  const releaseCmd = !isOriginal(agg) && (num(factsOf(agg), "has_backup") ?? 0) === 1 ? "complete_release_open" : "complete_release";
  agg = await exec(agg, releaseCmd);
  const nf = factsOf(agg);
  out({
    listing_id: str(nf, "listing_id"),
    phase: "fallen",
    escrow: "released",
    deposit_id: str(nf, "deposit_id"),
    primary: primaryOf(nf),
    backup: backupOf(nf),
  });
}

async function cmdPromote(args) {
  if (args.length !== 1) fail("bad_args");
  const listingId = args[0];
  if (!isId(listingId)) fail("bad_args");
  const loaded = await load();
  if (loaded.missing) fail("not_open");
  let agg = loaded.agg;
  needListing(agg, listingId);
  if (isOriginal(agg)) fail("legacy_listing");
  if (!isFallen(agg)) fail("not_fallen");
  const f = factsOf(agg);
  const backup = backupOf(f);
  if (!backup) fail("no_backup");
  try {
    agg = await exec(agg, "promote", {
      offer_id: backup.offer_id,
      buyer_id: backup.buyer_id,
      amount_cents: backup.amount_cents,
    });
  } catch (err) {
    fail(mapKernel(err) || "not_fallen");
  }
  const nf = factsOf(agg);
  out({
    listing_id: str(nf, "listing_id"),
    phase: "offered",
    escrow: "none",
    primary: primaryOf(nf),
    backup: null,
    deposit_id: null,
    deposit_cents: null,
    edition: "revised",
  });
}

async function cmdStatus() {
  const loaded = await load();
  if (loaded.missing) out(emptyStatus());
  out(statusBody(loaded.agg));
}

async function cmdCallback(args) {
  if (args.length !== 1) fail("bad_args");
  const p = args[0];
  let raw;
  try {
    raw = readFileSync(p, "utf8");
  } catch {
    fail("bad_callback");
  }
  let json;
  try {
    json = JSON.parse(raw);
  } catch {
    fail("bad_callback");
  }
  if (!json || typeof json !== "object" || Array.isArray(json)) fail("bad_callback");
  const loaded = await load();
  if (loaded.missing) out(emptyStatus());
  out(statusBody(loaded.agg));
}

const argv = process.argv.slice(2);
const cmd = argv[0];
const rest = argv.slice(1);

const now = parseNow();
const serviceUrl = requireService();

if (!cmd) fail("unknown_command");

const table = {
  open: () => cmdOpen(rest),
  bid: () => cmdBid(rest, now),
  counter: () => cmdCounter(rest, now),
  accept: () => cmdAccept(rest, now),
  deposit: () => cmdDeposit(rest, now, serviceUrl),
  reconcile: () => cmdReconcile(rest, serviceUrl),
  fallthrough: () => cmdFallthrough(rest, serviceUrl),
  promote: () => cmdPromote(rest),
  status: () => {
    if (rest.length !== 0) fail("bad_args");
    return cmdStatus();
  },
  callback: () => cmdCallback(rest),
};

if (!table[cmd]) fail("unknown_command");

table[cmd]().catch((err) => {
  const mapped = mapKernel(err);
  fail(mapped || "corrupt_state");
});
