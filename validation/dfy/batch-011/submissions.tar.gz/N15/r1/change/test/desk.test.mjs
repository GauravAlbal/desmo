import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { mkdtempSync, writeFileSync, readFileSync, chmodSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { test } from "node:test";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node";
const RUN = join(ROOT, "run");

function tmp() {
  return mkdtempSync(join(tmpdir(), "desk-"));
}

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [join(ROOT, "stub", "server.mjs")], { cwd: ROOT, stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    child.stdout.on("data", (c) => {
      buf += c.toString();
      const line = buf.split("\n").find((l) => l.trim().startsWith("{"));
      if (line) {
        const meta = JSON.parse(line);
        resolve({ child, ...meta });
      }
    });
    child.on("error", reject);
  });
}

function run(env, args) {
  const r = spawnSync(RUN, args, {
    env: { ...process.env, ...env },
    encoding: "utf8",
    cwd: ROOT,
  });
  let json = null;
  try {
    json = JSON.parse((r.stdout || "").trim());
  } catch {
    json = { raw: r.stdout, err: r.stderr };
  }
  return { code: r.status, signal: r.signal, json, stdout: r.stdout, stderr: r.stderr };
}

async function withStub(fn) {
  const stub = await startStub();
  try {
    return await fn(stub);
  } finally {
    stub.child.kill("SIGKILL");
  }
}

function fault(control, body) {
  return fetch(`${control}/fault`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
}

test("status empty, open, bid, counter, backup, accept, deposit, restart", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    writeFileSync(join(dir, "keep.txt"), "abc");
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    let r = run(env, ["status"]);
    assert.equal(r.code, 0);
    assert.equal(r.json.phase, "none");
    r = run(env, ["open", "L1", "S1", "10000", "5000", "1000"]);
    assert.equal(r.code, 0);
    assert.equal(r.json.phase, "listed");
    r = run(env, ["bid", "L1", "O1", "B1", "10000"]);
    assert.equal(r.code, 0);
    assert.equal(r.json.phase, "offered");
    assert.equal(r.json.primary.amount_cents, 10000);
    r = run(env, ["counter", "L1", "O1", "11000"]);
    assert.equal(r.code, 0);
    assert.equal(r.json.phase, "countered");
    assert.equal(r.json.primary.amount_cents, 11000);
    r = run(env, ["bid", "L1", "O2", "B2", "9000"]);
    assert.equal(r.code, 0);
    assert.equal(r.json.backup.amount_cents, 9000);
    r = run({ ...env, NOW_MS: "200" }, ["accept", "L1", "O1"]);
    assert.equal(r.code, 0, JSON.stringify(r.json));
    assert.equal(r.json.deposit_cents, 220);
    r = run({ ...env, NOW_MS: "300" }, ["deposit", "L1"]);
    assert.equal(r.code, 0, JSON.stringify(r.json));
    assert.equal(r.json.phase, "under_contract");
    r = run(env, ["status"]);
    assert.equal(r.json.phase, "under_contract");
    assert.equal(readFileSync(join(dir, "keep.txt"), "utf8"), "abc");
    const fx = await (await fetch(`${stub.control_url}/effects`)).json();
    assert.equal(fx.count, 1);
    r = run(env, ["deposit", "L1"]);
    assert.equal(r.code, 0);
    const fx2 = await (await fetch(`${stub.control_url}/effects`)).json();
    assert.equal(fx2.count, 1);
  });
});

test("window elapsed bid expires durably", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "5000", "1000"]);
    const r = run({ ...env, NOW_MS: "6000" }, ["bid", "L1", "O1", "B1", "10000"]);
    assert.equal(r.code, 1);
    assert.equal(r.json.error, "window_elapsed");
    const s = run(env, ["status"]);
    assert.equal(s.json.phase, "expired");
  });
});

test("crash after-deposit-saved-before-request then recover", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "5000", "1000"]);
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    run({ ...env, NOW_MS: "200" }, ["accept", "L1", "O1"]);
    const crashed = run({ ...env, NOW_MS: "300", CRASH_AT: "after-deposit-saved-before-request" }, ["deposit", "L1"]);
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const fx = await (await fetch(`${stub.control_url}/effects`)).json();
    assert.equal(fx.count, 0);
    const st = run(env, ["status"]);
    assert.equal(st.json.phase, "accepted");
    assert.equal(st.json.escrow, "attempt_saved");
    assert.ok(st.json.deposit_id);
    const again = run({ ...env, NOW_MS: "300" }, ["deposit", "L1"]);
    assert.equal(again.code, 0, JSON.stringify(again.json));
    assert.equal(again.json.phase, "under_contract");
    assert.equal(again.json.deposit_id, st.json.deposit_id);
    const fx2 = await (await fetch(`${stub.control_url}/effects`)).json();
    assert.equal(fx2.count, 1);
  });
});

test("crash after-accept-before-record then deposit adopts without second effect", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "5000", "1000"]);
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    run({ ...env, NOW_MS: "200" }, ["accept", "L1", "O1"]);
    const crashed = run({ ...env, NOW_MS: "300", CRASH_AT: "after-accept-before-record" }, ["deposit", "L1"]);
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const fx = await (await fetch(`${stub.control_url}/effects`)).json();
    assert.equal(fx.count, 1);
    const st = run(env, ["status"]);
    assert.equal(st.json.escrow, "attempt_saved");
    const again = run({ ...env, NOW_MS: "300" }, ["deposit", "L1"]);
    assert.equal(again.code, 0, JSON.stringify(again.json));
    assert.equal(again.json.phase, "under_contract");
    const fx2 = await (await fetch(`${stub.control_url}/effects`)).json();
    assert.equal(fx2.count, 1);
  });
});

test("crash after-record-before-exit leaves under_contract", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "5000", "1000"]);
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    run({ ...env, NOW_MS: "200" }, ["accept", "L1", "O1"]);
    const crashed = run({ ...env, NOW_MS: "300", CRASH_AT: "after-record-before-exit" }, ["deposit", "L1"]);
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const st = run(env, ["status"]);
    assert.equal(st.json.phase, "under_contract");
    const again = run(env, ["deposit", "L1"]);
    assert.equal(again.code, 0);
    assert.equal(again.json.phase, "under_contract");
  });
});

test("dropped reply then reconcile adopts", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "5000", "1000"]);
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    run({ ...env, NOW_MS: "200" }, ["accept", "L1", "O1"]);
    await fault(stub.control_url, { drop_reply: true });
    const dropped = run({ ...env, NOW_MS: "300" }, ["deposit", "L1"]);
    assert.equal(dropped.code, 1);
    assert.equal(dropped.json.error, "service_unavailable");
    await fault(stub.control_url, { drop_reply: false });
    const st = run(env, ["status"]);
    assert.equal(st.json.escrow, "attempt_saved");
    const rec = run({ ...env, NOW_MS: "300" }, ["reconcile", "L1", st.json.deposit_id]);
    assert.equal(rec.code, 0, JSON.stringify(rec.json));
    assert.equal(rec.json.lookup, "funded");
    assert.equal(rec.json.phase, "under_contract");
    const fx = await (await fetch(`${stub.control_url}/effects`)).json();
    assert.equal(fx.count, 1);
  });
});

test("reconcile not_sent and mismatch", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "5000", "1000"]);
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    run({ ...env, NOW_MS: "200" }, ["accept", "L1", "O1"]);
    run({ ...env, NOW_MS: "300", CRASH_AT: "after-deposit-saved-before-request" }, ["deposit", "L1"]);
    const st = run(env, ["status"]);
    const rec = run(env, ["reconcile", "L1", st.json.deposit_id]);
    assert.equal(rec.code, 0);
    assert.equal(rec.json.lookup, "not_sent");
    const bad = run(env, ["reconcile", "L1", "other-id"]);
    assert.equal(bad.json.error, "deposit_mismatch");
  });
});

test("fallthrough and refusals", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "5000", "1000"]);
    let r = run(env, ["fallthrough", "L1"]);
    assert.equal(r.json.error, "not_funded");
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    run({ ...env, NOW_MS: "200" }, ["accept", "L1", "O1"]);
    run({ ...env, NOW_MS: "300" }, ["deposit", "L1"]);
    r = run(env, ["fallthrough", "L1"]);
    assert.equal(r.code, 0, JSON.stringify(r.json));
    assert.equal(r.json.phase, "fallen");
    r = run(env, ["fallthrough", "L1"]);
    assert.equal(r.json.error, "already_fallen");
    r = run({ ...env, NOW_MS: "300" }, ["deposit", "L1"]);
    assert.equal(r.json.error, "not_accepted");
    const rel = await (await fetch(`${stub.control_url}/releases`)).json();
    assert.equal(rel.count, 1);
  });
});

test("callback ignore and env refusals", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "5000", "1000"]);
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    run({ ...env, NOW_MS: "200" }, ["accept", "L1", "O1"]);
    run({ ...env, NOW_MS: "300" }, ["deposit", "L1"]);
    const cb = join(dir, "cb.json");
    writeFileSync(cb, JSON.stringify({ phase: "fallen" }));
    const r = run(env, ["callback", cb]);
    assert.equal(r.code, 0);
    assert.equal(r.json.phase, "under_contract");
    writeFileSync(cb, "not-json");
    const bad = run(env, ["callback", cb]);
    assert.equal(bad.json.error, "bad_callback");
    const noNow = run({ STATE_DIR: dir, SERVICE_URL: stub.service_url }, ["status"]);
    assert.equal(noNow.json.error, "bad_time");
    const noUrl = run({ STATE_DIR: dir, NOW_MS: "1" }, ["status"]);
    assert.equal(noUrl.json.error, "bad_args");
  });
});

test("desk_full already_offered listing_mismatch", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "5000", "1000"]);
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    let r = run(env, ["bid", "L1", "O1", "B1", "10000"]);
    assert.equal(r.json.error, "already_offered");
    run(env, ["bid", "L1", "O2", "B2", "9000"]);
    r = run(env, ["bid", "L1", "O3", "B3", "8000"]);
    assert.equal(r.json.error, "desk_full");
    r = run(env, ["bid", "OTHER", "O4", "B4", "8000"]);
    assert.equal(r.json.error, "listing_mismatch");
    r = run(env, ["counter", "L1", "O2", "11000"]);
    assert.equal(r.json.error, "not_primary");
  });
});

test("status edition revised and revised deposit deadline", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    let r = run(env, ["status"]);
    assert.equal(r.json.edition, null);
    r = run(env, ["open", "L1", "S1", "10000", "2000", "5000"]);
    assert.equal(r.code, 0);
    r = run(env, ["status"]);
    assert.equal(r.json.edition, "revised");
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    r = run({ ...env, NOW_MS: "1000" }, ["accept", "L1", "O1"]);
    assert.equal(r.code, 0, JSON.stringify(r.json));
    assert.equal(r.json.accepted_ms, 1000);
    assert.equal(r.json.deposit_cents, 200);
    assert.equal(r.json.deposit_deadline_ms, 6000);
    r = run({ ...env, NOW_MS: "3000" }, ["deposit", "L1"]);
    assert.equal(r.code, 0, JSON.stringify(r.json));
    assert.equal(r.json.phase, "under_contract");
  });
});

test("revised deposit_elapsed after accepted_ms + deposit_window_ms", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "2000", "5000"]);
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    run({ ...env, NOW_MS: "1000" }, ["accept", "L1", "O1"]);
    const r = run({ ...env, NOW_MS: "6001" }, ["deposit", "L1"]);
    assert.equal(r.code, 1);
    assert.equal(r.json.error, "deposit_elapsed");
    const fx = await (await fetch(`${stub.control_url}/effects`)).json();
    assert.equal(fx.count, 0);
  });
});

test("promote fallen revised listing with backup", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "2000", "5000"]);
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    run(env, ["bid", "L1", "O2", "B2", "9000"]);
    let r = run(env, ["promote", "L1"]);
    assert.equal(r.json.error, "not_fallen");
    run({ ...env, NOW_MS: "1000" }, ["accept", "L1", "O1"]);
    run({ ...env, NOW_MS: "1100" }, ["deposit", "L1"]);
    const before = await (await fetch(`${stub.control_url}/effects`)).json();
    run({ ...env, NOW_MS: "1100" }, ["fallthrough", "L1"]);
    r = run(env, ["promote", "L1"]);
    assert.equal(r.code, 0, JSON.stringify(r.json));
    assert.equal(r.json.phase, "offered");
    assert.equal(r.json.escrow, "none");
    assert.equal(r.json.primary.offer_id, "O2");
    assert.equal(r.json.primary.countered, false);
    assert.equal(r.json.backup, null);
    assert.equal(r.json.deposit_id, null);
    assert.equal(r.json.deposit_cents, null);
    assert.equal(r.json.edition, "revised");
    const after = await (await fetch(`${stub.control_url}/effects`)).json();
    assert.equal(after.count, before.count);
    const st = run(env, ["status"]);
    assert.equal(st.json.phase, "offered");
    assert.equal(st.json.deposit_id, null);
    const dir2 = tmp();
    const env2 = { STATE_DIR: dir2, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env2, ["open", "L1", "S1", "10000", "2000", "5000"]);
    run(env2, ["bid", "L1", "O1", "B1", "10000"]);
    run({ ...env2, NOW_MS: "1000" }, ["accept", "L1", "O1"]);
    run({ ...env2, NOW_MS: "1100" }, ["deposit", "L1"]);
    run({ ...env2, NOW_MS: "1100" }, ["fallthrough", "L1"]);
    r = run(env2, ["promote", "L1"]);
    assert.equal(r.json.error, "no_backup");
  });
});

test("promote survives new process then accept and deposit crash recover", async () => {
  await withStub(async (stub) => {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "100" };
    run(env, ["open", "L1", "S1", "10000", "2000", "5000"]);
    run(env, ["bid", "L1", "O1", "B1", "10000"]);
    run(env, ["bid", "L1", "O2", "B2", "9000"]);
    run({ ...env, NOW_MS: "1000" }, ["accept", "L1", "O1"]);
    run({ ...env, NOW_MS: "1100" }, ["deposit", "L1"]);
    run({ ...env, NOW_MS: "1100" }, ["fallthrough", "L1"]);
    run(env, ["promote", "L1"]);
    const st = run(env, ["status"]);
    assert.equal(st.json.phase, "offered");
    assert.equal(st.json.primary.offer_id, "O2");
    const acc = run({ ...env, NOW_MS: "1000" }, ["accept", "L1", "O2"]);
    assert.equal(acc.code, 0, JSON.stringify(acc.json));
    assert.equal(acc.json.deposit_deadline_ms, 6000);
    const crashed = run({ ...env, NOW_MS: "1100", CRASH_AT: "after-deposit-saved-before-request" }, ["deposit", "L1"]);
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const fx = await (await fetch(`${stub.control_url}/effects`)).json();
    const saved = run(env, ["status"]);
    const again = run({ ...env, NOW_MS: "1100" }, ["deposit", "L1"]);
    assert.equal(again.code, 0, JSON.stringify(again.json));
    assert.equal(again.json.phase, "under_contract");
    assert.equal(again.json.deposit_id, saved.json.deposit_id);
    const fx2 = await (await fetch(`${stub.control_url}/effects`)).json();
    assert.equal(fx2.count, fx.count + 1);
  });
});

test("original listing keeps accept_by deadline and refuses promote", async () => {
  await withStub(async (stub) => {
    const orig = "/tmp/desk-orig-N15r1/accepted";
    const origFallen = "/tmp/desk-orig-N15r1/fallen";
    const origMid = "/tmp/desk-orig-N15r1/mid";
    const env = { STATE_DIR: orig, SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    let r = run(env, ["status"]);
    assert.equal(r.json.edition, "original");
    assert.equal(r.json.phase, "accepted");
    assert.equal(r.json.deposit_deadline_ms, 2000);
    r = run({ ...env, NOW_MS: "3000" }, ["deposit", "L1"]);
    assert.equal(r.json.error, "deposit_elapsed");
    const fx = await (await fetch(`${stub.control_url}/effects`)).json();
    assert.equal(fx.count, 0);
    r = run({ STATE_DIR: origFallen, SERVICE_URL: stub.service_url, NOW_MS: "1100" }, ["promote", "L1"]);
    assert.equal(r.json.error, "legacy_listing");
    const st = run({ STATE_DIR: origFallen, SERVICE_URL: stub.service_url, NOW_MS: "1100" }, ["status"]);
    assert.equal(st.json.phase, "fallen");
    assert.equal(st.json.edition, "original");
    const mid = run({ STATE_DIR: origMid, SERVICE_URL: stub.service_url, NOW_MS: "100" }, ["status"]);
    assert.equal(mid.json.edition, "original");
    assert.equal(mid.json.phase, "offered");
    const nxt = run({ STATE_DIR: origMid, SERVICE_URL: stub.service_url, NOW_MS: "1000" }, ["accept", "L1", "O1"]);
    assert.equal(nxt.code, 0, JSON.stringify(nxt.json));
    assert.equal(nxt.json.deposit_deadline_ms, 2000);
  });
});

