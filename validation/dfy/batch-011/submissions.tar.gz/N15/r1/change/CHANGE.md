# Change: backup promotion and revised deposit deadline

R1–R14 remain in force. `status` additionally reports `edition`, which is `null` on an empty store, `"original"` on a listing opened by the pre-change program, and `"revised"` on a listing opened by the changed program. This change adds a backup-promotion command and changes how a new listing measures its deposit deadline.

The new command is:

`promote <listing_id>`

It is valid only for a `fallen` listing that has a backup offer and whose `edition` is `"revised"`. It records the backup as the new primary with `countered:false`, clears backup, deposit id, deposit cents, accepted_ms, and deposit_deadline_ms, sets `phase:"offered"` and `escrow:"none"`, and returns `{listing_id,phase:"offered",escrow:"none",primary,backup:null,deposit_id:null,deposit_cents:null,edition:"revised"}`. Promote never contacts the provider. A listing with no backup is `no_backup`. A listing that is not `fallen` is `not_fallen`. An `edition:"original"` listing is `legacy_listing` and nothing mutates.

Deposit deadline is revised only for new listings. On `accept`, a revised listing sets `deposit_deadline_ms = accepted_ms + deposit_window_ms`. An original listing keeps `deposit_deadline_ms = accept_by_ms`. Existing persisted listings with `edition` absent or `"original"` keep the original deadline rule. A successful deposit does not rewrite the deadline. The seller may still accept only at or before `accept_by_ms` on both editions. Worked clocks: open with `ask_cents` 10000, `accept_by_ms` 2000, `deposit_window_ms` 5000; accept a 10000 primary at `NOW_MS` 1000 (`accepted_ms` 1000, `deposit_cents` 200). A revised listing records `deposit_deadline_ms` 6000; an original listing records `deposit_deadline_ms` 2000. A clock of 3000 is past `accept_by_ms` and before the revised deadline; a clock of 6001 is past the revised deadline.

Old-instance policy: (a) original listings continue under the original deadline `accept_by_ms` (observable: `deposit` at a clock greater than `accept_by_ms` but less than `accepted_ms + deposit_window_ms` returns `deposit_elapsed` and does not POST); (b) `promote` on an original listing is refused `legacy_listing` and nothing mutates. Original listings remain fully usable to completion under the original rules (`bid`, `counter`, `accept`, `deposit`, `reconcile`, `fallthrough`, `status`, `callback`).

## C1–C5

C1. `promote` accepts a fallen revised listing that has a backup, moves that backup to primary, clears deposit fields, returns `phase:"offered"`, and creates no provider effect.

C2. Promote state survives a new process. An original listing refuses `promote` with `legacy_listing` and does not mutate. `no_backup` and `not_fallen` refuse without mutation.

C3. A revised listing records `deposit_deadline_ms = accepted_ms + deposit_window_ms`. A clock beyond `accept_by_ms` but before that revised deadline may still deposit; a clock beyond the revised deadline returns `deposit_elapsed` without a POST.

C4. An original listing created by the pre-change program keeps `deposit_deadline_ms = accept_by_ms` when the changed program runs against that same store: a clock beyond `accept_by_ms` but before `accepted_ms + deposit_window_ms` returns `deposit_elapsed` without a POST, and `status` reports `edition:"original"`.

C5. After promote on a revised listing, the next accept and deposit respect the saved-deposit crash boundaries: after a saved-attempt crash or dropped reply, the same deposit id is recovered by lookup/retry, and no second provider hold effect is created for that id.
