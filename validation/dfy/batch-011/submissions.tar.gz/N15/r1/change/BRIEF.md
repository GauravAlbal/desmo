# Property offer and escrow desk

The program behind `./run` is a durable local desk for one residential listing. Buyers submit offers; the seller may counter the primary offer once; an accepted offer must place an earnest-money deposit with an external escrow service before the listing is `under_contract`. A second live offer is the backup. An acceptance window and a deposit deadline are evaluated from `NOW_MS`. Fall-through releases a funded deposit.

## Scope and invocation

One machine and one process at a time. One listing is bound to a state directory. An unrelated writer may create or modify other files in `STATE_DIR`; those files must survive byte-for-byte. The tool may keep its durable files in `STATE_DIR` under any names. It must use `STATE_DIR`, `SERVICE_URL`, `NOW_MS`, and optional `CRASH_AT`. `SERVICE_URL` is required for every command, including status (status never contacts it). `NOW_MS` is a required non-negative integer epoch-millisecond clock for every command.

`./run <command> [args]` prints exactly one JSON object and nothing else (one trailing newline is allowed). Exit 0 is success. Refusals are nonzero and print `{ "error": "<code>" }`. Identifiers are 1–64 characters matching `A-Za-z0-9._-`. Money values (`ask_cents`, offer `amount_cents`, `deposit_cents`) are canonical non-negative decimal integers; `ask_cents` and offer amounts must be at least 1. Time values (`accept_by_ms`, `deposit_window_ms`, `accepted_ms`, `deposit_deadline_ms`) are canonical non-negative decimal integers. `CRASH_AT` labels are:

* `after-deposit-saved-before-request`: after saving a deposit id and deposit snapshot, before sending a request;
* `after-accept-before-record`: after reading a complete successful provider response, before saving the under-contract record;
* `after-record-before-exit`: after saving the under-contract record, before success JSON is written.

A process must kill itself with SIGKILL at a reached label. Durable commits are flushed before the command treats them as committed. A malformed owned state file is `corrupt_state` and is not rewritten. Refusals do not modify state except that a clock past the acceptance window may durably become `expired`, and a clock past the deposit deadline on an accepted-but-unfunded listing may durably become `expired`.

## Commands

`open <listing_id> <seller_id> <ask_cents> <accept_by_ms> <deposit_window_ms>` binds the empty store. It returns `{listing_id,seller_id,ask_cents,accept_by_ms,deposit_window_ms,phase:"listed",escrow:"none",primary:null,backup:null,deposit_id:null,deposit_cents:null}`. A second open is `already_open`; malformed identifiers are `bad_args`; malformed or non-positive money is `bad_money`; malformed time is `bad_time`. Open never contacts the provider. `deposit_window_ms` is recorded and is unused for the deposit deadline in this version.

`bid <listing_id> <offer_id> <buyer_id> <amount_cents>` records a buyer offer and never contacts the provider. The first accepted bid becomes `primary` with `countered:false` and `phase:"offered"`. A second distinct offer becomes `backup` (`{offer_id,buyer_id,amount_cents}`). A third live offer is `desk_full`. Repeating an existing `offer_id` is `already_offered`. After `accept` and before funding, a bid still fills an empty backup slot. `under_contract` or `fallen` is `listed_busy`. If `NOW_MS` is greater than `accept_by_ms` and the listing is not yet accepted, the listing durably becomes `expired` and the command returns `window_elapsed`. A listing that is already `expired` also returns `window_elapsed`. Success is `{listing_id,phase,escrow:"none",primary,backup}` where `backup` is `null` when empty.

`counter <listing_id> <offer_id> <amount_cents>` lets the seller replace the primary amount exactly once. It never contacts the provider. The offer must be the primary; any other id is `not_primary`. A second counter is `already_countered`. If there is no primary, `no_offer`. If the phase is not `offered`, `not_offered` (except `already_countered` when the primary was already countered). Success sets `phase:"countered"`, `primary.countered:true`, `primary.amount_cents` to the new amount, and returns `{listing_id,phase:"countered",primary,backup}`.

`accept <listing_id> <offer_id>` accepts the primary offer only (`not_primary` otherwise; `no_offer` if none). It never contacts the provider. `NOW_MS` must be less than or equal to `accept_by_ms`; otherwise the listing durably becomes `expired` and the command returns `window_elapsed`. Phase `accepted`, `under_contract`, or escrow `attempt_saved` is `already_accepted`. `fallen` is `already_fallen`. `expired` is `window_elapsed`. Success sets `phase:"accepted"`, `accepted_ms` to `NOW_MS`, `deposit_cents` to `floor(primary.amount_cents / 50)`, and `deposit_deadline_ms` to `accept_by_ms`. It returns `{listing_id,phase:"accepted",escrow:"none",primary,backup,accepted_ms,deposit_deadline_ms,deposit_cents}`. An existing backup remains backup.

`deposit <listing_id>` places earnest money. A funded listing (`phase:"under_contract"`, `escrow:"funded"`) returns the funded success object as a no-op and does not contact the provider, even after the deadline. Otherwise the listing must be `accepted` (escrow `none` or `attempt_saved`); any other phase is `not_accepted`. If `NOW_MS` is greater than `deposit_deadline_ms`, the listing durably becomes `expired` and the command returns `deposit_elapsed` without a provider request. A first attempt generates a deposit id, saves `{deposit_id,listing_id,offer_id,amount_cents,buyer_id}` with `amount_cents` equal to `deposit_cents`, sets `escrow:"attempt_saved"`, then posts once. If a saved attempt exists, `deposit` first `GET /v1/deposits/<deposit_id>`: a matching 200 is adopted without POST; a 404 causes one POST with the saved id only while the deadline still holds. Never allocate a replacement id. A mismatching success is `lookup_conflict` and changes nothing. Transport failure, incomplete response, or HTTP 5xx leaves `escrow:"attempt_saved"`, `phase:"accepted"`, and returns `service_unavailable`. A matching funded response returns `{listing_id,deposit_id,deposit_cents,phase:"under_contract",escrow:"funded"}`.

`reconcile <listing_id> <deposit_id>` never POSTs or allocates. No saved deposit is `no_deposit`; another id is `deposit_mismatch`. Lookup 200 with matching ids, listing, offer, buyer, and amount commits under-contract state and returns the funded object plus `lookup:"funded"`; 404 returns exit 0 `{lookup:"not_sent",listing_id,deposit_id,phase:"accepted",escrow:"attempt_saved"}`; a mismatch is `lookup_conflict`; transport failure is `service_unavailable`.

`fallthrough <listing_id>` releases a funded deposit and never allocates a new id. It is valid only for `phase:"under_contract"` and `escrow:"funded"`; otherwise `not_funded` (already `fallen` is `already_fallen`). It `POST /v1/deposits/<deposit_id>/release` with `{deposit_id,listing_id}`. A matching 200 sets `phase:"fallen"`, `escrow:"released"`, keeps primary, backup, and deposit id, and returns `{listing_id,phase:"fallen",escrow:"released",deposit_id,primary,backup}`. Transport failure or HTTP 5xx is `service_unavailable` and leaves under-contract state. Repeat after `fallen` is `already_fallen` and does not contact the provider.

`status` never contacts the provider and returns `{listing_id,seller_id,ask_cents,accept_by_ms,deposit_window_ms,deposit_deadline_ms,accepted_ms,phase,escrow,primary,backup,deposit_id,deposit_cents}`. Empty fields are null, with `phase:"none"` and `escrow:"none"`.

`callback <path>` reads one JSON callback. It must not POST or allocate. A malformed callback is `bad_callback`; a well-formed callback may be ignored. It must never overwrite `under_contract`, `fallen`, or `expired` state.

## Provider

The supplied service has `POST /v1/deposits`, `GET /v1/deposits/<deposit_id>`, `GET /public/deposits/<deposit_id>` (the public lookup route; same body as the v1 GET), and `POST /v1/deposits/<deposit_id>/release`. A first valid deposit id records one effect and returns the body with `outcome:"held"`; repeating the same id and identical fields returns the same object without another effect; any differing field is HTTP 409. Unknown lookup is 404. A first valid release records one release effect and returns `{deposit_id,listing_id,outcome:"released"}`; repeating the same release is idempotent and adds no release effect. The provider may drop a reply after accepting, hold a reply, or return 5xx without storing. Control endpoints are not part of this contract.

POST deposit JSON is `{deposit_id,listing_id,offer_id,buyer_id,amount_cents}` with positive integer `amount_cents`. Matching means those five fields plus `outcome:"held"`.

## Refusal precedence

When more than one refusal condition holds, the first matching code in this list wins.

1. Missing or malformed `NOW_MS` → `bad_time`.
2. Missing `SERVICE_URL` → `bad_args`.
3. Malformed owned state → `corrupt_state`.
4. Unknown command name → `unknown_command`.
5. Wrong arity or malformed identifier → `bad_args`.
6. Malformed or non-positive money where a money argument is present → `bad_money`.
7. Malformed time argument on `open` → `bad_time`.
8. No bound listing (except `open` and `status`) → `not_open`.
9. `open` on a bound listing → `already_open`.
10. `listing_id` argument that is not the bound listing → `listing_mismatch`.
11. Command-specific, in the order written below.

`bid`: `listed_busy` (`under_contract` or `fallen`); `window_elapsed` (expired, or `NOW_MS > accept_by_ms` while not yet accepted); `already_offered`; `desk_full`.

`counter`: `no_offer`; `not_primary`; `already_countered`; `not_offered`; `window_elapsed`.

`accept`: `no_offer`; `not_primary`; `already_accepted`; `already_fallen`; `window_elapsed`.

`deposit`: funded no-op (success, not a refusal); `not_accepted`; `deposit_elapsed`.

`reconcile`: `no_deposit`; `deposit_mismatch`; then provider codes `lookup_conflict` or `service_unavailable`.

`fallthrough`: `already_fallen`; `not_funded`.

`callback`: `bad_callback` only for a malformed file; a well-formed callback is success.

## Requirements

R1. Open and every later committed record survive new processes, including a deposit attempt killed at `after-deposit-saved-before-request`.

R2. Opening validates listing, seller, ask, accept-by, and deposit-window fields, binds one listing, and does not contact the provider.

R3. A live listing makes legitimate progress: a first bid is primary, a second bid is backup, a third live offer is `desk_full`, a healthy provider funds an accepted offer with `deposit_cents = floor(amount_cents / 50)`, and a bid after `accept_by_ms` on an unaccepted listing is `window_elapsed` without mutation beyond durable expiration. Worked amounts: ask and first bid `10000`, seller counter `11000` (`deposit_cents` `220`), backup bid `9000`.

R4. Expiration after the acceptance window is terminal and cannot be accepted. Fall-through of a funded listing is durable, posts exactly one release, and cannot be deposited again. An unfunded listing cannot fall through (`not_funded`).

R5. A healthy provider permits deposit and exactly one external hold effect; repeating deposit after funding is a no-op and does not add an effect.

R6. Callback files never overwrite local terminal outcomes (`under_contract`, `fallen`, `expired`) and never cause provider effects.

R7. Bidding after the window, depositing after the deadline, countering a non-primary, or operating on a missing listing is refused without contacting the provider (except the durable expiration writes named above).

R8. A crash before POST leaves one saved deposit id and zero effects; a later deposit POSTs that same id and ends `under_contract` exactly once.

R9. A crash after provider acceptance leaves `attempt_saved` locally and one provider effect; later deposit adopts by lookup without a second effect.

R10. A crash after the durable under-contract record leaves `under_contract` and later deposit is a no-op; reconcile can likewise survive its record-before-exit crash.

R11. A dropped deposit reply yields `service_unavailable` and `attempt_saved`; following reconcile adopts funded by lookup, never reports `not_sent`, and never posts again.

R12. Reconcile never POSTs: a saved-but-unaccepted id returns `not_sent` with `attempt_saved`; a wrong id is `deposit_mismatch` and leaves state unchanged.

R13. Unrelated files in STATE_DIR retain identical bytes through commits and refusals.

R14. Every invocation emits one JSON object; status on empty is the null shape; missing `SERVICE_URL` or `NOW_MS` is a refusal; the first open binds the only listing and no command can accept another listing's id.
