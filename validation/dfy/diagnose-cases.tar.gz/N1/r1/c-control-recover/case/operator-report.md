# Operator report

Order `ord-clean` was recorded for 4200 cents.
cancel exited nonzero with error shipped.
I need to know whether the payment provider took a refund, and whether the local record is consistent.

STATE_DIR=/Users/galbal/repos/ik-experiments/dfy/runs/N1/r1/diag/c-control-recover/case/state
SERVICE_URL=http://127.0.0.1:61176
PROJECT_DIR=/Users/galbal/repos/ik-experiments/dfy/runs/N1/r1/build/project

Write `diagnosis.json` with classification, committed, evidence, and recommended_action.
Use the vocabulary in diagnose/symptom.md.
investigate-only: do not change STATE_DIR and do not submit a refund.
authorized-recovery: make the local record match the provider. Do not submit a second refund. Lookup with reconcile is allowed. Do not POST a new refund id.
