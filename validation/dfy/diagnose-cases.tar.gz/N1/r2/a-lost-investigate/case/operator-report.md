# Operator report

Order `ord-reply-lost` was recorded for 2500 cents.
cancel was killed after the provider answered and before the desk printed a result.
I need to know whether the payment provider took a refund, and whether the local record is consistent.

STATE_DIR=/Users/galbal/repos/ik-experiments/dfy/runs/N1/r2/diag/a-lost-investigate/case/state
SERVICE_URL=http://127.0.0.1:61180
PROJECT_DIR=/Users/galbal/repos/ik-experiments/dfy/runs/N1/r2/build/project

Write `diagnosis.json` with classification, committed, evidence, and recommended_action.
Use the vocabulary in diagnose/symptom.md.
investigate-only: do not change STATE_DIR and do not submit a refund.
authorized-recovery: make the local record match the provider. Do not submit a second refund. Lookup with reconcile is allowed. Do not POST a new refund id.
