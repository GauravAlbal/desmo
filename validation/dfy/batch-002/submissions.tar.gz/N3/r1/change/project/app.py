#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import re
import signal
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from invariant_kernel import Aggregate, Kernel, KernelError

ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
ADDR_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$")
TIME_RE = re.compile(r"^(0|[1-9][0-9]*)$")
MAX_TIME = 9_999_999_999
MAX_HOLD = 2_592_000


class DeskError(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


def valid_id(value: str) -> bool:
    return isinstance(value, str) and bool(ID_RE.fullmatch(value))


def parse_time(value: str) -> Optional[int]:
    if not isinstance(value, str) or not TIME_RE.fullmatch(value):
        return None
    number = int(value)
    return number if number <= MAX_TIME else None


def parse_hold(value: str) -> Optional[int]:
    number = parse_time(value)
    return number if number is not None and 1 <= number <= MAX_HOLD else None


def valid_address(value: str) -> bool:
    return isinstance(value, str) and bool(ADDR_RE.fullmatch(value))


def crash_at(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


class Desk:
    def __init__(self) -> None:
        state_dir = os.environ.get("STATE_DIR")
        service_url = os.environ.get("SERVICE_URL")
        if not state_dir or not service_url or service_url.endswith("/"):
            raise DeskError("bad_args")
        self.root = Path(state_dir)
        self.root.mkdir(parents=True, exist_ok=True)
        self.service_url = service_url
        binary = os.environ.get("IK_BINARY")
        machine_path = Path(__file__).with_name("equipment.ik.toml")
        self.kernel = Kernel(self.root / "equipment.ik.db", binary=binary)
        self.machine = self.kernel.machine(machine_path)
        self.meta_path = self.root / "equipment.index.json"
        self.meta = self._load_meta()

    def close(self) -> None:
        self.kernel.close()

    def _load_meta(self) -> Dict[str, Any]:
        if not self.meta_path.exists():
            return {"items": [], "ids": {}, "expired_reservations": {}}
        try:
            data = json.loads(self.meta_path.read_text())
            if not isinstance(data, dict) or not isinstance(data.get("items"), list) or not isinstance(data.get("ids"), dict):
                raise ValueError
            if not isinstance(data.get("expired_reservations", {}), dict):
                raise ValueError
            data.setdefault("expired_reservations", {})
            return data
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            raise DeskError("service_unavailable")

    def _save_meta(self) -> None:
        payload = json.dumps(self.meta, sort_keys=True, separators=(",", ":"))
        fd, name = tempfile.mkstemp(prefix=".equipment-index.", dir=str(self.root))
        try:
            with os.fdopen(fd, "w") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(name, self.meta_path)
            directory_fd = os.open(self.root, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        finally:
            if os.path.exists(name):
                os.unlink(name)

    def _id_in_use(self, value: str) -> bool:
        return value in self.meta["ids"]

    def _remember_item(self, item_id: str) -> None:
        if item_id not in self.meta["items"]:
            self.meta["items"].append(item_id)
        self.meta["ids"][item_id] = "item"
        self._save_meta()

    def _remember_loan(self, loan_id: str, item_id: str) -> None:
        self.meta["ids"][loan_id] = "loan:" + item_id
        self._save_meta()

    def _remember_reservation(self, reservation_id: str, item_id: str) -> None:
        self.meta["ids"][reservation_id] = "reservation:" + item_id
        self._save_meta()

    def _remember_wait(self, wait_id: str, item_id: str) -> None:
        self.meta["ids"][wait_id] = "wait:" + item_id
        self._save_meta()

    def _mark_expired(self, reservation_id: Optional[str], item_id: str) -> None:
        if reservation_id:
            self.meta["expired_reservations"][reservation_id] = item_id
            self._save_meta()

    def _expired_for(self, reservation_id: str, item_id: str) -> bool:
        return self.meta["expired_reservations"].get(reservation_id) == item_id

    def _item(self, item_id: str) -> Aggregate:
        if item_id not in self.meta["items"]:
            raise DeskError("unknown_item")
        try:
            return self.machine.show(item_id)
        except KernelError:
            raise DeskError("unknown_item")

    @staticmethod
    def _facts(a: Aggregate) -> Dict[str, Any]:
        return dict(a.facts)

    @staticmethod
    def _waiters(facts: Dict[str, Any]) -> List[Dict[str, Any]]:
        raw = facts.get("waitlist", "[]")
        try:
            value = json.loads(raw)
        except (TypeError, ValueError, json.JSONDecodeError):
            raise DeskError("service_unavailable")
        if not isinstance(value, list):
            raise DeskError("service_unavailable")
        result: List[Dict[str, Any]] = []
        for entry in value:
            if not isinstance(entry, dict) or not all(key in entry for key in ("wait_id", "borrower_id", "address", "hold_seconds")):
                raise DeskError("service_unavailable")
            result.append(dict(entry))
        return result

    @staticmethod
    def _waitlist_text(waiters: List[Dict[str, Any]]) -> str:
        return json.dumps(waiters, separators=(",", ":"), sort_keys=True)

    @staticmethod
    def _clean(value: Any) -> Any:
        return None if value in (None, "") else value

    def _result_status(self, item_id: str, a: Aggregate, now: int) -> Dict[str, Any]:
        facts = self._facts(a)
        reservation_state = facts.get("reservation_state", "none")
        collect_by = facts.get("collect_by")
        past = reservation_state == "expired" or (
            reservation_state == "active" and collect_by is not None and now >= int(collect_by)
        )
        promotion_request = self._clean(facts.get("promotion_request_id"))
        promotion_wait = self._clean(facts.get("promotion_wait_id"))
        return {
            "item_id": item_id,
            "availability": a.state,
            "reservation_id": self._clean(facts.get("reservation_id")),
            "borrower_id": self._clean(facts.get("borrower_id")),
            "address": self._clean(facts.get("address")),
            "collect_by": collect_by,
            "reservation_state": reservation_state,
            "past_deadline": past,
            "loan_id": self._clean(facts.get("loan_id")),
            "loan_state": facts.get("loan_state", "none"),
            "notify": facts.get("notify", "none"),
            "waitlist": self._waiters(facts),
            "promotion": {"request_id": promotion_request, "notify": facts.get("promotion_notify", "none"), "wait_id": promotion_wait},
            "now": now,
        }

    def add_item(self, item_id: str) -> Dict[str, Any]:
        if not valid_id(item_id):
            raise DeskError("bad_args")
        if self._id_in_use(item_id):
            raise DeskError("id_in_use")
        try:
            self.machine.create(item_id)
        except KernelError:
            raise DeskError("id_in_use")
        self._remember_item(item_id)
        return {"item_id": item_id, "availability": "available", "reservation_id": None, "loan_id": None}

    def _reserve_new(self, a: Aggregate, reservation_id: str, borrower_id: str, address: str, collect_by: int) -> None:
        try:
            a.command(
                "reserve",
                reservation_id=reservation_id,
                borrower_id=borrower_id,
                address=address,
                collect_by=collect_by,
                reservation_state="active",
                loan_id="",
                loan_state="none",
                notify="none",
                waitlist="[]",
                promotion_request_id="",
                promotion_wait_id="",
                promotion_notify="none",
            )
        except KernelError:
            raise DeskError("not_available")

    def _promote(self, item_id: str, a: Aggregate, now: int, from_return: bool) -> Aggregate:
        facts = self._facts(a)
        waiters = self._waiters(facts)
        if not waiters:
            raise DeskError("not_available")
        waiter = waiters[0]
        remaining = self._waitlist_text(waiters[1:])
        args = {
            "reservation_id": waiter["wait_id"],
            "borrower_id": waiter["borrower_id"],
            "address": waiter["address"],
            "collect_by": now + int(waiter["hold_seconds"]),
            "reservation_state": "active",
            "loan_state": "returned" if from_return else facts.get("loan_state", "none"),
            "waitlist": remaining,
            "promotion_request_id": waiter["wait_id"],
            "promotion_wait_id": waiter["wait_id"],
            "promotion_notify": "attempt_saved",
        }
        if from_return:
            args["loan_state"] = "returned"
            command = "promote_return"
        else:
            command = "promote_expiry"
        try:
            a.command(command, **args)
        except KernelError:
            raise DeskError("service_unavailable")
        self._mark_expired(facts.get("reservation_id"), item_id)
        crash_at("after-attempt-saved-before-request")
        return self.machine.show(item_id)

    def _same_promotion(self, message: Any, item_id: str, facts: Dict[str, Any], request_id: str) -> bool:
        return isinstance(message, dict) and message.get("request_id") == request_id and message.get("item_id") == item_id and message.get("borrower_id") == facts.get("borrower_id") and message.get("address") == facts.get("address") and message.get("kind") == "waitlist_ready" and message.get("outcome") == "accepted"

    def _finish_promotion(self, item_id: str, a: Aggregate, *, crash: bool = True) -> Aggregate:
        facts = self._facts(a)
        request_id = facts.get("promotion_request_id")
        if not request_id or facts.get("promotion_notify") == "sent":
            return a
        try:
            a.command("promotion_mark_sent", promotion_request_id=request_id, promotion_notify="sent")
        except KernelError:
            raise DeskError("conflict")
        if crash:
            crash_at("after-record-before-exit")
        return self.machine.show(item_id)

    def _send_promotion(self, item_id: str, a: Aggregate, *, crash: bool = True) -> Aggregate:
        facts = self._facts(a)
        request_id = facts.get("promotion_request_id")
        if not request_id:
            return a
        if facts.get("promotion_notify") == "sent":
            return a
        status, message = self._request("GET", "/v1/requests/" + request_id)
        if status == 200:
            if not self._same_promotion(message, item_id, facts, request_id):
                raise DeskError("conflict")
            return self._finish_promotion(item_id, a, crash=crash)
        if status != 404:
            raise DeskError("service_unavailable")
        payload = {"request_id": request_id, "item_id": item_id, "borrower_id": facts["borrower_id"], "address": facts["address"], "kind": "waitlist_ready"}
        post_status, post_message = self._request("POST", "/v1/messages", payload)
        if post_status == 409:
            raise DeskError("conflict")
        if post_status != 200 or not self._same_promotion(post_message, item_id, facts, request_id):
            raise DeskError("service_unavailable" if post_status != 200 else "conflict")
        crash_at("after-accept-before-record")
        return self._finish_promotion(item_id, a, crash=crash)

    def reserve(self, item_id: str, reservation_id: str, borrower_id: str, address: str, collect_by_s: str, now_s: str) -> Dict[str, Any]:
        now = parse_time(now_s)
        collect_by = parse_time(collect_by_s)
        if not valid_id(item_id) or not valid_id(reservation_id) or not valid_id(borrower_id) or not valid_address(address) or now is None or collect_by is None or collect_by <= now:
            raise DeskError("bad_args")
        a = self._item(item_id)
        if self._id_in_use(reservation_id):
            raise DeskError("id_in_use")
        facts = self._facts(a)
        if a.state == "reserved" and facts.get("reservation_state") == "active":
            if now < int(facts["collect_by"]):
                raise DeskError("not_available")
            if facts.get("promotion_notify") == "attempt_saved":
                self._send_promotion(item_id, a)
                raise DeskError("not_available")
            waiters = self._waiters(facts)
            if waiters:
                promoted = self._promote(item_id, a, now, False)
                self._send_promotion(item_id, promoted)
                raise DeskError("not_available")
            try:
                a.command("expire", now=now, reservation_state="expired")
            except KernelError:
                raise DeskError("not_available")
            self._mark_expired(facts.get("reservation_id"), item_id)
            a = self.machine.show(item_id)
        elif a.state != "available":
            raise DeskError("not_available")
        self._reserve_new(a, reservation_id, borrower_id, address, collect_by)
        self._remember_reservation(reservation_id, item_id)
        return {"item_id": item_id, "reservation_id": reservation_id, "borrower_id": borrower_id, "address": address, "collect_by": collect_by, "availability": "reserved", "now": now}

    def expire(self, item_id: str, now_s: str) -> Dict[str, Any]:
        now = parse_time(now_s)
        if not valid_id(item_id) or now is None:
            raise DeskError("bad_args")
        a = self._item(item_id)
        facts = self._facts(a)
        if a.state == "reserved" and facts.get("promotion_notify") == "attempt_saved":
            done = self._send_promotion(item_id, a)
            done_facts = self._facts(done)
            return {"item_id": item_id, "availability": done.state, "expired": False, "reservation_id": done_facts.get("reservation_id"), "promoted_wait_id": done_facts.get("promotion_wait_id"), "notify": done_facts.get("promotion_notify", "none"), "now": now}
        expired = False
        promoted_wait_id = None
        notify = "none"
        reservation_id = facts.get("reservation_id")
        if a.state == "reserved" and facts.get("reservation_state") == "active" and now >= int(facts["collect_by"]):
            waiters = self._waiters(facts)
            if waiters:
                a = self._promote(item_id, a, now, False)
                a = self._send_promotion(item_id, a)
                done_facts = self._facts(a)
                expired = True
                reservation_id = done_facts.get("reservation_id")
                promoted_wait_id = done_facts.get("promotion_wait_id")
                notify = done_facts.get("promotion_notify", "none")
            else:
                try:
                    a.command("expire", now=now, reservation_state="expired")
                    expired = True
                except KernelError:
                    raise DeskError("service_unavailable")
                self._mark_expired(reservation_id, item_id)
        return {"item_id": item_id, "availability": a.state if expired and promoted_wait_id else ("available" if expired else a.state), "expired": expired, "reservation_id": reservation_id, "promoted_wait_id": promoted_wait_id, "notify": notify, "now": now}

    def _request(self, method: str, path: str, body: Optional[Dict[str, Any]] = None) -> Tuple[Optional[int], Optional[Dict[str, Any]]]:
        url = self.service_url + path
        data = None if body is None else json.dumps(body, separators=(",", ":")).encode()
        request = Request(url, data=data, method=method, headers={"Content-Type": "application/json"} if data is not None else {})
        try:
            with urlopen(request, timeout=5) as response:
                raw = response.read()
                return response.status, json.loads(raw.decode())
        except HTTPError as exc:
            try:
                raw = exc.read()
                return exc.code, json.loads(raw.decode())
            except Exception:
                return None, None
        except (OSError, URLError, TimeoutError, ValueError, json.JSONDecodeError):
            return None, None

    @staticmethod
    def _same_message(message: Any, item_id: str, facts: Dict[str, Any], loan_id: str) -> bool:
        return isinstance(message, dict) and message.get("request_id") == loan_id and message.get("item_id") == item_id and message.get("borrower_id") == facts.get("borrower_id") and message.get("address") == facts.get("address") and message.get("kind") == "checkout" and message.get("outcome") == "accepted"

    def _finish_checkout(self, item_id: str, reservation_id: str, loan_id: str, now: int, a: Aggregate, *, crash: bool = True) -> Dict[str, Any]:
        try:
            a.command("mark_sent", loan_id=loan_id, reservation_id=reservation_id, reservation_state="collected", loan_state="checked_out", notify="sent")
        except KernelError:
            raise DeskError("conflict")
        if crash:
            crash_at("after-record-before-exit")
        facts = self._facts(self.machine.show(item_id))
        return {"item_id": item_id, "reservation_id": reservation_id, "loan_id": loan_id, "borrower_id": facts["borrower_id"], "address": facts["address"], "availability": "checked_out", "notify": "sent", "request_id": loan_id, "now": now}

    def checkout(self, item_id: str, reservation_id: str, loan_id: str, now_s: str) -> Dict[str, Any]:
        now = parse_time(now_s)
        if not valid_id(item_id) or not valid_id(reservation_id) or not valid_id(loan_id) or now is None:
            raise DeskError("bad_args")
        a = self._item(item_id)
        facts = self._facts(a)
        if a.state == "checked_out":
            raise DeskError("already_checked_out")
        if a.state == "reserved" and self._expired_for(reservation_id, item_id) and facts.get("promotion_notify") == "attempt_saved":
            self._send_promotion(item_id, a)
            raise DeskError("expired")
        if a.state == "reserved" and facts.get("reservation_state") == "active" and now >= int(facts["collect_by"]):
            if facts.get("promotion_notify") == "attempt_saved" and reservation_id == facts.get("reservation_id"):
                a = self._send_promotion(item_id, a)
                facts = self._facts(a)
            if reservation_id != facts.get("reservation_id") and self._expired_for(reservation_id, item_id):
                raise DeskError("expired")
            waiters = self._waiters(facts)
            if waiters:
                a = self._promote(item_id, a, now, False)
                self._send_promotion(item_id, a)
                raise DeskError("expired" if reservation_id == facts.get("reservation_id") else "not_reserved")
            try:
                a.command("expire", now=now, reservation_state="expired")
            except KernelError:
                raise DeskError("service_unavailable")
            self._mark_expired(facts.get("reservation_id"), item_id)
            if reservation_id == facts.get("reservation_id") or self._expired_for(reservation_id, item_id):
                raise DeskError("expired")
            raise DeskError("not_reserved")
        if a.state != "reserved" or facts.get("reservation_state") != "active":
            raise DeskError("expired" if self._expired_for(reservation_id, item_id) or facts.get("reservation_state") == "expired" else "not_reserved")
        if reservation_id != facts.get("reservation_id"):
            raise DeskError("expired" if self._expired_for(reservation_id, item_id) else "reservation_mismatch")
        existing_loan = facts.get("loan_id")
        existing_state = facts.get("loan_state", "none")
        if existing_state == "attempt_saved":
            if existing_loan != loan_id:
                raise DeskError("checkout_in_progress")
        elif existing_loan not in (None, "") or existing_state != "none":
            raise DeskError("checkout_in_progress")
        elif self._id_in_use(loan_id):
            raise DeskError("id_in_use")
        if existing_state == "none":
            try:
                a = a.command("save_attempt", loan_id=loan_id, reservation_id=reservation_id, now=now, loan_state="attempt_saved", notify="attempt_saved")
            except KernelError:
                raise DeskError("conflict")
            self._remember_loan(loan_id, item_id)
            crash_at("after-attempt-saved-before-request")
        status, message = self._request("GET", "/v1/requests/" + loan_id)
        if status == 200:
            if not self._same_message(message, item_id, facts, loan_id):
                raise DeskError("conflict")
            return self._finish_checkout(item_id, reservation_id, loan_id, now, a)
        if status != 404:
            raise DeskError("service_unavailable")
        payload = {"request_id": loan_id, "item_id": item_id, "borrower_id": facts["borrower_id"], "address": facts["address"], "kind": "checkout"}
        post_status, post_message = self._request("POST", "/v1/messages", payload)
        if post_status == 409:
            raise DeskError("conflict")
        if post_status != 200 or not self._same_message(post_message, item_id, facts, loan_id):
            raise DeskError("service_unavailable" if post_status != 200 else "conflict")
        crash_at("after-accept-before-record")
        return self._finish_checkout(item_id, reservation_id, loan_id, now, a)

    def return_item(self, item_id: str, loan_id: str, now_s: str) -> Dict[str, Any]:
        now = parse_time(now_s)
        if not valid_id(item_id) or not valid_id(loan_id) or now is None:
            raise DeskError("bad_args")
        a = self._item(item_id)
        facts = self._facts(a)
        if a.state == "reserved" and facts.get("promotion_notify") == "attempt_saved":
            if facts.get("loan_id") != loan_id or facts.get("loan_state") != "returned":
                raise DeskError("not_checked_out")
            a = self._send_promotion(item_id, a)
            done = self._facts(a)
            return {"item_id": item_id, "loan_id": self._clean(done.get("loan_id")), "availability": "reserved", "loan_state": done.get("loan_state", "returned"), "promoted_wait_id": done.get("promotion_wait_id"), "notify": done.get("promotion_notify", "none"), "now": now}
        if a.state != "checked_out":
            raise DeskError("not_checked_out")
        if facts.get("loan_id") != loan_id:
            raise DeskError("loan_mismatch")
        waiters = self._waiters(facts)
        if waiters:
            a = self._promote(item_id, a, now, True)
            a = self._send_promotion(item_id, a)
            done = self._facts(a)
            return {"item_id": item_id, "loan_id": self._clean(done.get("loan_id")), "availability": "reserved", "loan_state": done.get("loan_state", "returned"), "promoted_wait_id": done.get("promotion_wait_id"), "notify": done.get("promotion_notify", "none"), "now": now}
        try:
            a.command("return_item", loan_id=loan_id, loan_state="returned")
        except KernelError:
            raise DeskError("conflict")
        return {"item_id": item_id, "loan_id": loan_id, "availability": "available", "loan_state": "returned", "promoted_wait_id": None, "now": now}

    def wait(self, item_id: str, wait_id: str, borrower_id: str, address: str, hold_seconds_s: str, now_s: str) -> Dict[str, Any]:
        now = parse_time(now_s)
        hold_seconds = parse_hold(hold_seconds_s)
        if not valid_id(item_id) or not valid_id(wait_id) or not valid_id(borrower_id) or not valid_address(address) or now is None or hold_seconds is None:
            raise DeskError("bad_args")
        a = self._item(item_id)
        if a.state == "available":
            raise DeskError("not_needed")
        if a.state not in ("reserved", "checked_out"):
            raise DeskError("not_needed")
        facts = self._facts(a)
        waiters = self._waiters(facts)
        if any(entry.get("borrower_id") == borrower_id for entry in waiters) or facts.get("borrower_id") == borrower_id:
            raise DeskError("already_waiting")
        if self._id_in_use(wait_id):
            raise DeskError("id_in_use")
        waiters.append({"wait_id": wait_id, "borrower_id": borrower_id, "address": address, "hold_seconds": hold_seconds})
        command = "append_wait_reserved" if a.state == "reserved" else "append_wait_checked_out"
        try:
            a.command(command, waitlist=self._waitlist_text(waiters))
        except KernelError:
            raise DeskError("conflict")
        self._remember_wait(wait_id, item_id)
        return {"item_id": item_id, "wait_id": wait_id, "borrower_id": borrower_id, "address": address, "hold_seconds": hold_seconds, "position": len(waiters), "availability": a.state, "now": now}

    def status(self, item_id: str, now_s: str) -> Dict[str, Any]:
        now = parse_time(now_s)
        if not valid_id(item_id) or now is None:
            raise DeskError("bad_args")
        return self._result_status(item_id, self._item(item_id), now)

    def _find_request(self, request_id: str) -> Tuple[Optional[str], Optional[str], Optional[Aggregate]]:
        for candidate in self.meta["items"]:
            try:
                a = self.machine.show(candidate)
            except KernelError:
                continue
            facts = self._facts(a)
            if facts.get("promotion_request_id") == request_id:
                return candidate, "promotion", a
            if facts.get("loan_id") == request_id:
                return candidate, "checkout", a
        return None, None, None

    def reconcile(self, request_id: str) -> Dict[str, Any]:
        if not valid_id(request_id):
            raise DeskError("bad_args")
        item_id, kind, a = self._find_request(request_id)
        if item_id is None or a is None or kind is None:
            return {"request_id": None, "loan_id": None, "item_id": None, "kind": None, "notify": "none", "availability": None, "loan_state": "none"}
        facts = self._facts(a)
        if kind == "promotion":
            if facts.get("promotion_notify") == "sent":
                return {"request_id": request_id, "loan_id": self._clean(facts.get("loan_id")), "item_id": item_id, "kind": "waitlist_ready", "notify": "sent", "availability": a.state, "loan_state": facts.get("loan_state", "none")}
            status, message = self._request("GET", "/v1/requests/" + request_id)
            if status == 404:
                return {"request_id": request_id, "loan_id": self._clean(facts.get("loan_id")), "item_id": item_id, "kind": "waitlist_ready", "notify": "not_sent", "availability": a.state, "loan_state": facts.get("loan_state", "none")}
            if status != 200 or message is None:
                raise DeskError("service_unavailable")
            if not self._same_promotion(message, item_id, facts, request_id):
                raise DeskError("conflict")
            done = self._finish_promotion(item_id, a, crash=False)
            done_facts = self._facts(done)
            return {"request_id": request_id, "loan_id": self._clean(done_facts.get("loan_id")), "item_id": item_id, "kind": "waitlist_ready", "notify": "sent", "availability": done.state, "loan_state": done_facts.get("loan_state", "none")}
        if facts.get("notify") == "sent" and facts.get("loan_state") in ("checked_out", "returned"):
            return {"request_id": request_id, "loan_id": request_id, "item_id": item_id, "kind": "checkout", "notify": "sent", "availability": a.state, "loan_state": facts["loan_state"]}
        status, message = self._request("GET", "/v1/requests/" + request_id)
        if status == 404:
            return {"request_id": request_id, "loan_id": request_id, "item_id": item_id, "kind": "checkout", "notify": "not_sent", "availability": a.state, "loan_state": facts.get("loan_state", "none")}
        if status != 200 or message is None:
            raise DeskError("service_unavailable")
        if not self._same_message(message, item_id, facts, request_id):
            raise DeskError("conflict")
        self._finish_checkout(item_id, facts["reservation_id"], request_id, 0, a)
        done = self.machine.show(item_id)
        done_facts = self._facts(done)
        return {"request_id": request_id, "loan_id": request_id, "item_id": item_id, "kind": "checkout", "notify": "sent", "availability": done.state, "loan_state": done_facts["loan_state"]}

    def callback(self, callback_path: str) -> Dict[str, Any]:
        try:
            data = json.loads(Path(callback_path).read_text())
        except Exception:
            raise DeskError("bad_args")
        required = ("callback_id", "request_id", "item_id", "borrower_id", "address", "kind", "outcome")
        if not isinstance(data, dict) or any(key not in data for key in required) or not all(valid_id(data[key]) for key in ("callback_id", "request_id", "item_id", "borrower_id")) or not valid_address(data["address"]) or data["kind"] not in ("checkout", "waitlist_ready") or data["outcome"] not in ("accepted", "rejected"):
            raise DeskError("bad_args")
        return {"ok": True}


def main(argv: List[str]) -> int:
    desk: Optional[Desk] = None
    try:
        if not argv:
            raise DeskError("bad_args")
        desk = Desk()
        command = argv[0]
        args = argv[1:]
        if command == "add-item" and len(args) == 1:
            result = desk.add_item(args[0])
        elif command == "reserve" and len(args) == 6:
            result = desk.reserve(*args)
        elif command == "wait" and len(args) == 6:
            result = desk.wait(*args)
        elif command == "expire" and len(args) == 2:
            result = desk.expire(*args)
        elif command == "checkout" and len(args) == 4:
            result = desk.checkout(*args)
        elif command == "return" and len(args) == 3:
            result = desk.return_item(*args)
        elif command == "status" and len(args) == 2:
            result = desk.status(*args)
        elif command == "reconcile" and len(args) == 1:
            result = desk.reconcile(args[0])
        elif command == "callback" and len(args) == 1:
            result = desk.callback(args[0])
        else:
            raise DeskError("bad_args")
        print(json.dumps(result, separators=(",", ":"), sort_keys=False))
        return 0
    except DeskError as exc:
        print(json.dumps({"error": exc.code}, separators=(",", ":")))
        return 1
    except Exception:
        print(json.dumps({"error": "service_unavailable"}, separators=(",", ":")))
        return 1
    finally:
        if desk is not None:
            desk.close()


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
