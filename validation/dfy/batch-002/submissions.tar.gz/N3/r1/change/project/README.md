# Equipment loan desk

The executable `./run` implements the lifecycle in `BRIEF.md`. State is kept in
`STATE_DIR` using the supplied Ikaros runtime; unrelated files in that directory
are not read or replaced. `SERVICE_URL` is the mail stub base URL and
`CRASH_AT` is optional.

## Setup

No npm package or network access is required. The first invocation creates the
local virtual environment and installs the supplied wheel from `KIT/python`:

```sh
STATE_DIR=/tmp/equipment-state SERVICE_URL=http://127.0.0.1:48500 ./run add-item camera-1
```

To set it up explicitly instead:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
```

The entrypoint sets `IK_BINARY` to the packed `KIT/bin/ik` automatically.

## Example

Start `stub/server.mjs` with Node 22 on a port in 48500-48509, use its printed
`service_url`, then invoke `./run add-item`, `reserve`, `wait`, `checkout`,
`status`, `return`, and `reconcile`. Every invocation prints one JSON object;
refusal exits nonzero.

The machine definition is `equipment.ik.toml`. `app.py` owns HTTP I/O and
format validation while Ikaros owns durable aggregate transitions and guards.
Checkout first commits an attempt and then reconciles the mail request by its
loan id, so retries never allocate another request id.
