#!/usr/bin/env python3
import json
import os
import signal
import subprocess
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PORT = 48501
EFFECTS = {}
DROP = False

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass
    def do_GET(self):
        key = self.path.rsplit("/", 1)[-1]
        if self.path.startswith("/v1/requests/") and key in EFFECTS:
            self._json(200, EFFECTS[key])
        elif self.path.startswith("/v1/requests/"):
            self._json(404, {"error": "not_found"})
        else:
            self._json(404, {"error": "not_found"})
    def do_POST(self):
        size = int(self.headers.get("content-length", "0"))
        body = json.loads(self.rfile.read(size))
        EFFECTS.setdefault(body["request_id"], dict(body, outcome="accepted"))
        if DROP:
            self.connection.shutdown(2)
            self.connection.close()
            return
        self._json(200, EFFECTS[body["request_id"]])
    def _json(self, code, body):
        raw = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


def invoke(state, *args, crash=None):
    env = dict(os.environ, STATE_DIR=str(state), SERVICE_URL=f"http://127.0.0.1:{PORT}")
    if crash is None:
        env.pop("CRASH_AT", None)
    else:
        env["CRASH_AT"] = crash
    proc = subprocess.run([str(ROOT / "run"), *args], env=env, text=True, capture_output=True)
    obj = json.loads(proc.stdout) if proc.stdout else None
    return proc.returncode, obj


class EquipmentTests(unittest.TestCase):
    def setUp(self):
        EFFECTS.clear()
        global DROP
        DROP = False
        self.state = Path(tempfile.mkdtemp(prefix="equipment-test-"))
    def test_restart_and_crash_boundaries(self):
        self.assertEqual(invoke(self.state, "add-item", "item1")[0], 0)
        self.assertEqual(invoke(self.state, "reserve", "item1", "res1", "bob", "bob@example.com", "10", "1")[0], 0)
        code, obj = invoke(self.state, "checkout", "item1", "res1", "loan1", "1", crash="after-attempt-saved-before-request")
        self.assertNotEqual(code, 0)
        self.assertIsNone(obj)
        self.assertEqual(invoke(self.state, "checkout", "item1", "res1", "loan2", "1")[1]["error"], "checkout_in_progress")
        self.assertEqual(invoke(self.state, "checkout", "item1", "res1", "loan1", "1")[0], 0)
        self.assertEqual(len(EFFECTS), 1)
        self.assertEqual(invoke(self.state, "status", "item1", "1")[1]["notify"], "sent")
        self.assertEqual(invoke(self.state, "return", "item1", "loan1", "2")[0], 0)
        self.assertEqual(invoke(self.state, "reserve", "item1", "res1b", "carol", "carol@example.com", "10", "2")[0], 0)
        self.assertEqual(invoke(self.state, "add-item", "item4")[0], 0)
        self.assertEqual(invoke(self.state, "reserve", "item4", "res4", "bob", "bob@example.com", "10", "1")[0], 0)
        code, obj = invoke(self.state, "checkout", "item4", "res4", "loan4", "1", crash="after-record-before-exit")
        self.assertNotEqual(code, 0)
        self.assertIsNone(obj)
        self.assertEqual(invoke(self.state, "status", "item4", "1")[1]["notify"], "sent")
        self.assertEqual(len(EFFECTS), 2)

    def test_crash_after_accept_and_lost_reply_reconcile(self):
        self.assertEqual(invoke(self.state, "add-item", "item2")[0], 0)
        self.assertEqual(invoke(self.state, "reserve", "item2", "res2", "bob", "bob@example.com", "10", "1")[0], 0)
        code, obj = invoke(self.state, "checkout", "item2", "res2", "loan2", "1", crash="after-accept-before-record")
        self.assertNotEqual(code, 0)
        self.assertEqual(len(EFFECTS), 1)
        self.assertEqual(invoke(self.state, "checkout", "item2", "res2", "loan2", "1")[0], 0)
        self.assertEqual(len(EFFECTS), 1)
        callback = self.state / "late-callback.json"
        callback.write_text(json.dumps({"callback_id": "cb-loan2", "request_id": "loan2", "item_id": "item2", "borrower_id": "bob", "address": "other@example.com", "kind": "checkout", "outcome": "accepted"}))
        self.assertEqual(invoke(self.state, "callback", str(callback))[0], 0)
        self.assertEqual(invoke(self.state, "callback", str(callback))[0], 0)
        self.assertEqual(invoke(self.state, "status", "item2", "1")[1]["address"], "bob@example.com")

        self.assertEqual(invoke(self.state, "add-item", "item3")[0], 0)
        self.assertEqual(invoke(self.state, "reserve", "item3", "res3", "bob", "bob@example.com", "10", "1")[0], 0)
        global DROP
        DROP = True
        code, _ = invoke(self.state, "checkout", "item3", "res3", "loan3", "1")
        self.assertNotEqual(code, 0)
        DROP = False
        code, result = invoke(self.state, "reconcile", "loan3")
        self.assertEqual(code, 0)
        self.assertEqual(result["notify"], "sent")
        self.assertEqual(len(EFFECTS), 2)


    def test_waitlist_return_and_expiry_promotion(self):
        self.assertEqual(invoke(self.state, "add-item", "itemw")[0], 0)
        self.assertEqual(invoke(self.state, "reserve", "itemw", "resw", "bob", "bob@example.com", "5", "1")[0], 0)
        self.assertEqual(invoke(self.state, "checkout", "itemw", "resw", "loanw", "1")[0], 0)
        self.assertEqual(invoke(self.state, "wait", "itemw", "wait1", "alice", "alice@example.com", "3", "2")[0], 0)
        self.assertEqual(invoke(self.state, "wait", "itemw", "wait2", "carol", "carol@example.com", "4", "2")[0], 0)
        code, result = invoke(self.state, "return", "itemw", "loanw", "4")
        self.assertEqual(code, 0)
        self.assertEqual(result["availability"], "reserved")
        self.assertEqual(result["promoted_wait_id"], "wait1")
        self.assertEqual(len(EFFECTS), 2)
        status = invoke(self.state, "status", "itemw", "4")[1]
        self.assertEqual(status["reservation_id"], "wait1")
        self.assertEqual([entry["wait_id"] for entry in status["waitlist"]], ["wait2"])
        self.assertEqual(status["promotion"]["notify"], "sent")
        expired = invoke(self.state, "expire", "itemw", "7")[1]
        self.assertTrue(expired["expired"])
        self.assertEqual(expired["promoted_wait_id"], "wait2")
        self.assertEqual(len(EFFECTS), 3)
        self.assertEqual(invoke(self.state, "checkout", "itemw", "resw", "newloan", "7")[1]["error"], "expired")

    def test_waitlist_promotion_crash_recovery(self):
        self.assertEqual(invoke(self.state, "add-item", "itemp")[0], 0)
        self.assertEqual(invoke(self.state, "reserve", "itemp", "resp", "bob", "bob@example.com", "5", "1")[0], 0)
        self.assertEqual(invoke(self.state, "checkout", "itemp", "resp", "loanp", "1")[0], 0)
        self.assertEqual(invoke(self.state, "wait", "itemp", "waitp", "alice", "alice@example.com", "3", "2")[0], 0)
        code, result = invoke(self.state, "return", "itemp", "loanp", "4", crash="after-attempt-saved-before-request")
        self.assertNotEqual(code, 0)
        self.assertIsNone(result)
        self.assertEqual(len(EFFECTS), 1)
        code, result = invoke(self.state, "return", "itemp", "loanp", "4")
        self.assertEqual(code, 0)
        self.assertEqual(result["promoted_wait_id"], "waitp")
        self.assertEqual(len(EFFECTS), 2)

    def test_uncertain_and_checkout_expiry_promotions(self):
        self.assertEqual(invoke(self.state, "add-item", "itemu")[0], 0)
        self.assertEqual(invoke(self.state, "reserve", "itemu", "resu", "bob", "bob@example.com", "5", "1")[0], 0)
        self.assertEqual(invoke(self.state, "checkout", "itemu", "resu", "loanu", "1")[0], 0)
        self.assertEqual(invoke(self.state, "wait", "itemu", "waitu", "alice", "alice@example.com", "3", "2")[0], 0)
        global DROP
        DROP = True
        code, _ = invoke(self.state, "return", "itemu", "loanu", "4")
        self.assertNotEqual(code, 0)
        self.assertEqual(len(EFFECTS), 2)
        DROP = False
        result = invoke(self.state, "reconcile", "waitu")[1]
        self.assertEqual(result["notify"], "sent")
        self.assertEqual(len(EFFECTS), 2)

        self.assertEqual(invoke(self.state, "add-item", "iteme")[0], 0)
        self.assertEqual(invoke(self.state, "reserve", "iteme", "rese", "bob", "bob@example.com", "5", "1")[0], 0)
        self.assertEqual(invoke(self.state, "wait", "iteme", "waite", "alice", "alice@example.com", "3", "2")[0], 0)
        code, result = invoke(self.state, "checkout", "iteme", "rese", "loane", "5")
        self.assertNotEqual(code, 0)
        self.assertEqual(result["error"], "expired")
        self.assertEqual(len(EFFECTS), 3)
        self.assertEqual(invoke(self.state, "status", "iteme", "5")[1]["reservation_id"], "waite")

    def test_expiry_and_callback_are_local(self):
        self.assertEqual(invoke(self.state, "add-item", "item5")[0], 0)
        marker = self.state / "unrelated.bin"
        marker.write_bytes(b"keep-me")
        self.assertEqual(invoke(self.state, "reserve", "item5", "res5", "bob", "bob@example.com", "5", "1")[0], 0)
        self.assertEqual(invoke(self.state, "expire", "item5", "4")[1]["expired"], False)
        expired = invoke(self.state, "expire", "item5", "5")[1]
        self.assertTrue(expired["expired"])
        self.assertEqual(invoke(self.state, "checkout", "item5", "res5", "loan5", "5")[1]["error"], "expired")
        self.assertEqual(invoke(self.state, "reserve", "item5", "res6", "bob", "bob@example.com", "8", "5")[0], 0)
        callback = self.state / "callback.json"
        callback.write_text(json.dumps({"callback_id": "cb-loan6", "request_id": "loan6", "item_id": "item5", "borrower_id": "bob", "address": "bob@example.com", "kind": "checkout", "outcome": "accepted"}))
        self.assertEqual(invoke(self.state, "callback", str(callback))[0], 0)
        self.assertEqual(marker.read_bytes(), b"keep-me")

if __name__ == "__main__":
    server = HTTPServer(("127.0.0.1", PORT), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        unittest.main()
    finally:
        server.shutdown()
        server.server_close()
