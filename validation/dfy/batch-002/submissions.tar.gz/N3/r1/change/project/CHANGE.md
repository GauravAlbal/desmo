# Change: waitlist promotion

The desk you are maintaining already implements the equipment loan brief. Requirements R1 through R14 stay in force except where this change explicitly revises R3 and R7. It adds the `wait` command, extends `reconcile`, extends the crash boundaries to promotion sends, and adds requirements C1 through C5.

Staff can join a waitlist when an item is reserved or checked out. When that item is returned, or when its active reservation expires, the head of the waitlist is promoted into a new reservation and notified exactly once. Promotion does not check the item out. The promoted borrower must still pass `checkout` before the new deadline. If that new reservation expires, the next head is promoted and notified once. The previous head is not notified again.

This is a rule interaction, not a new field on an old record. Expiry still refuses a late checkout and still must not send a checkout confirmation. The same expiry, when the waitlist is non-empty, must send the promotion notice. A return that used to only mark the item available must, when someone is waiting, reserve it for the head and send that notice instead. Both paths share the exactly-once rule: a lost reply is resolved by lookup and is never submitted again.

## Revised R3

When the waitlist for the item is empty, R3 is unchanged: expiry sends no mail, and `checkout` at or after `collect_by` refuses `expired` and does not contact the service.

When the waitlist is non-empty, committing that expiry also promotes the head, as specified below. `checkout` of the expired reservation still refuses `expired` and still must not send a `kind` `checkout` message. The only mail that expiry may send is the one `waitlist_ready` notice for the promoted head. A second expiry that does not promote a new head must not send again.

## Revised R7

When the waitlist is empty, R7 is unchanged: `return` of the active loan leaves the item `available` and does not contact the service. Refusals for an item that is not checked out, and `loan_mismatch`, are unchanged.

When the waitlist is non-empty, `return` of the active loan still closes that loan (`loan_state` `returned`, checkout `notify` stays `sent`) and then promotes the head instead of leaving the item `available`. The success object uses `availability` `reserved` and includes `promoted_wait_id`. A second `return`, once that promotion is `sent` or there was nothing to promote, is still `not_checked_out` and must not contact the service.

## Command

### `./run wait <item_id> <wait_id> <borrower_id> <address> <hold_seconds> <now>`

Append a waiter. Do not contact the service. Do not commit expiry.

`hold_seconds` is a canonical decimal integer from 1 through 2592000. On promotion, `collect_by` for the new reservation is the `now` of the promoting command plus `hold_seconds`.

`wait_id` joins the same namespace as item, reservation, and loan ids. A collision is `id_in_use`.

Success, exit 0, only when the item exists and `availability` is `reserved` or `checked_out`:

```json
{"item_id":"...","wait_id":"...","borrower_id":"...","address":"...","hold_seconds":1,"position":1,"availability":"reserved","now":0}
```

`position` is the 1-based index after the append. Join order is the waitlist order.

Refuse, with no store change and no mail, when:

- the item is `available`: `not_needed`
- this borrower is already on this waitlist, or is the active reservation borrower, or is the checked-out borrower: `already_waiting`
- the id collides: `id_in_use`
- the item does not exist: `unknown_item`
- an argument is malformed: `bad_args`

## Promotion

`reserve` of an item whose active reservation is already due commits that expiry before creating the new reservation. If the waitlist is empty, the new reservation is created and no mail is sent, as in the original brief. If the waitlist is non-empty, that expiry promotes the head and sends the one notice, then this `reserve` refuses `not_available` and does not store the new reservation id.

Promoting the head means, in one committed record, before any byte of the promotion HTTP request:

- remove that waiter from the waitlist
- set the item `availability` to `reserved`
- set `reservation_id` to the `wait_id`, `borrower_id` and `address` to that waiter, `reservation_state` to `active`, and `collect_by` to `now + hold_seconds`
- leave the previous reservation id in the namespace with state `expired`, so a later `checkout` of that old id is `expired`
- save a promotion attempt whose request id is the `wait_id`, `kind` is `waitlist_ready`, and `notify` is `attempt_saved`

Then send that notice with the same lookup-or-POST rules as checkout, using the saved request id. The POST body is:

```json
{"request_id":"...","item_id":"...","borrower_id":"...","address":"...","kind":"waitlist_ready"}
```

The borrower and address are the promoted waiter, not the previous holder. Do not allocate a different request id for that promotion. If lookup returns HTTP 200 for that same payload, commit `notify` `sent` and do not POST. If lookup returns HTTP 404, POST once. A dropped reply, HTTP 500, or a failed connection leaves the attempt in place and must not use a new request id.

`status` must include, on every item:

```json
"waitlist":[{"wait_id":"...","borrower_id":"...","address":"...","hold_seconds":1}],
"promotion":{"request_id":null,"notify":"none","wait_id":null}
```

`waitlist` is join order, or an empty array. `promotion.notify` is `none`, `attempt_saved`, or `sent`. After a promotion attempt exists, `request_id` and `wait_id` are that wait id.

`expire` success, when it promoted a head:

```json
{"item_id":"...","availability":"reserved","expired":true,"reservation_id":"...","promoted_wait_id":"...","notify":"sent","now":0}
```

`reservation_id` in that object is the new reservation (the wait id). `notify` here is the promotion notice. When nothing was promoted, omit no required original fields; `promoted_wait_id` is null and `notify` is `none`.

`return` success, when it promoted a head:

```json
{"item_id":"...","loan_id":"...","availability":"reserved","loan_state":"returned","promoted_wait_id":"...","notify":"sent","now":0}
```

When the waitlist was empty, `availability` is `available` and `promoted_wait_id` is null.

If a promotion attempt is still `attempt_saved`, a later `expire`, a later `return` of the loan that was closed for that promotion, or a later `checkout` of the reservation id that expired into that promotion, continues that same send. Continuation does not honor `after-attempt-saved-before-request` again, does not promote a second head, and does not POST when lookup returns HTTP 200. `reconcile` never continues by POST; it only looks up.

`checkout` of a still-active promoted reservation, with `now` less than its `collect_by`, is an ordinary checkout and sends `kind` `checkout` for a new loan id. That is a different effect from the `waitlist_ready` notice.

## Reconcile

`./run reconcile <id>` still must not POST and must not allocate a request id. `<id>` may be a loan id, as in the original brief, or a promotion request id (the wait id).

For a promotion attempt, lookup HTTP 200 with the same item, borrower, address, and `kind` `waitlist_ready` commits that promotion `notify` to `sent` and does not change who is reserved. Lookup HTTP 404 exits 0 with `notify` `not_sent` and leaves the attempt. `not_sent` is legal only for that 404. A matching adoption uses this shape, with `kind` `waitlist_ready` and `request_id` the wait id:

```json
{"request_id":"...","loan_id":"...","item_id":"...","kind":"waitlist_ready","notify":"sent","availability":"reserved","loan_state":"returned"}
```

`loan_id` and `loan_state` are the item loan fields, which may be null and `none` when promotion came from expiry rather than return. Use null for `loan_id` in that case.

## Crash boundaries

The original three labels still apply to a checkout confirmation, in the original places.

They also apply to a promotion send inside `return`, `expire`, and the expiry path of `checkout`:

- `after-attempt-saved-before-request`: after the promotion attempt record is committed, before any byte of the promotion POST. Not on a continuation that finds the attempt already saved.
- `after-accept-before-record`: after the complete promotion POST response body has been read, before `promotion.notify` `sent` is committed. Not on a lookup of an earlier acceptance.
- `after-record-before-exit`: after `promotion.notify` `sent` is committed, before this command writes its JSON. On the checkout expiry path that JSON is the `expired` refusal. Not when that promotion outcome was already committed before this invocation.

A command that does not send mail must not kill itself for these labels.

## Requirements

C1. Join and order. On a reserved item, two `wait` commands exit 0 with positions 1 and 2, and `status` lists them in that join order. `wait` on an available item is refused `not_needed` and does not append. A reused `wait_id` is refused `id_in_use`. The same borrower waiting twice is refused `already_waiting`. Joining does not contact the service.

C2. Return promotes the head once. After a successful checkout and two waits, `return` exits 0, the item is reserved for the first waiter with `collect_by` equal to that `now` plus that waiter `hold_seconds`, the second waiter is the only remaining waitlist entry, and the service has the original checkout effect plus exactly one `waitlist_ready` effect for the first wait id. A second `return` is refused `not_checked_out` and adds no effect. A return of a checked-out item with an empty waitlist leaves `availability` `available` and adds no effect.

C3. Expiry promotes and then chains. A due `reserve` with a non-empty waitlist promotes the head, refuses `not_available`, and does not store the new reservation id. `expire` at a due deadline, with two waiters and no checkout, promotes the head, sends exactly one `waitlist_ready` effect, and sends no checkout effect. A later `expire` before the new `collect_by` adds no effect. `expire` at that new deadline promotes the next head with exactly one additional `waitlist_ready` effect and does not add another effect for the first wait id. `checkout` of the original reservation id is refused `expired` and adds no checkout effect.

C4. Uncertain promotion send. After a healthy checkout and one waiter, if `return` is run while the service drops the reply after accepting the promotion, `reconcile` of that wait id records promotion `notify` `sent`, does not POST, does not report `not_sent`, and leaves exactly one `waitlist_ready` effect for that wait id. Separately, if `return` is killed at `after-attempt-saved-before-request`, the head is already reserved, promotion `notify` is `attempt_saved`, and the service has no `waitlist_ready` effect. A later `return` of that same loan, with `CRASH_AT` unset, produces exactly one `waitlist_ready` effect for that same wait id.

C5. Checkout meets expiry. `checkout` of an active reservation at or after `collect_by`, with one waiter, exits nonzero `expired`, sends no `kind` `checkout` message, and sends exactly one `waitlist_ready` effect for that waiter. The item is reserved for that waiter. A later `checkout` of the old reservation id is still `expired` and adds no effect. If the promotion reply was dropped, `reconcile` of the wait id finishes that notice with no second effect and still no checkout effect.

## Error codes added

`not_needed`, `already_waiting`.

Every original error code still means what the original brief says.
