# Loan desk incident

You are diagnosing one local equipment loan desk. You may use only `./run` in PROJECT_DIR and the mail service data plane. Do not read the control port. Do not invent a second confirmation request id.

Classification vocabulary, exactly one of:

- not_sent
- refused_by_rule
- committed_reply_lost
- uncertain_external
- corrupt_state
- no_incident

`committed` is true when the mail service has accepted the confirmation, false when it has not, or unknown if that cannot be determined.

`recommended_action` is exactly one of:

- reconcile
- stop
- retry_same_id

Write `diagnosis.json` in the case directory:

```json
{"classification":"no_incident","committed":false,"evidence":["..."],"recommended_action":"stop"}
```

`evidence` is a non-empty array of strings. Include the request id when one was named, and include either `accepted` or the refusal code you observed.

Read-only desk commands are commands the brief says do not change records. `status` is read-only. `reconcile` writes a recovered outcome and is not read-only. A mail lookup `GET /v1/requests/<id>` is not a new send. `POST /v1/messages` is a send.

## Active mode
authorized-recovery

Determine the classification and, if a safe recovery exists, perform it. A lost reply is resolved by `reconcile` of the saved id. Do not submit a new confirmation and do not repeat the external action. An expected refusal needs no repair.

## This case
The operator ran checkout for item cam-9, reservation res-9, loan loan-9, borrower riley, address riley@loan.desk, at now 1000. The process was killed at crash label `after-accept-before-record` and printed no success JSON. The operator does not know whether the checkout confirmation was accepted. The mail service base URL is http://127.0.0.1:53480. The desk state directory is /Users/galbal/repos/ik-experiments/dfy/runs-b2/N3/r1/diag/b-lost-recover/case/state. The desk executable directory is /Users/galbal/repos/ik-experiments/dfy/runs-b2/N3/r1/build/project.

PROJECT_DIR=/Users/galbal/repos/ik-experiments/dfy/runs-b2/N3/r1/build/project
STATE_DIR=/Users/galbal/repos/ik-experiments/dfy/runs-b2/N3/r1/diag/b-lost-recover/case/state
SERVICE_URL=http://127.0.0.1:53480
item_id=cam-9
reservation_id=res-9
loan_id=loan-9
mode=authorized-recovery

Write diagnosis.json in /Users/galbal/repos/ik-experiments/dfy/runs-b2/N3/r1/diag/b-lost-recover/case.
