# Equipment loan desk

A local desk lets staff register a piece of equipment, reserve it for a borrower until a collection deadline, check it out, and return it. Checkout sends one confirmation through the mail service. The desk keeps its records in a single durable store on this machine. It does not coordinate other sites, a shared inventory service, or a distributed transaction.

You own the program behind `./run`. Implement it in Python 3.9 or newer, using only the Python standard library. The mail service is supplied. Its HTTP API is specified below and, with the same rules, in `stub/CONTRACT.md`.

## Scope

- One machine, one state directory, one desk process at a time.
- Many items may exist in that directory. Each item has its own reservation and loan.
- The operator does not run two `./run` processes at once. An unrelated process may write other files in the state directory between commands, and may do so while a command runs.
- No multi-site transaction, no shared remote database, and no waitlist. A later change may add a waitlist; this brief does not.
- The desk must not read the wall clock. Every command that needs a time takes that time as an argument.

## How to run

`./run` is executable. Each invocation is one process:

```text
./run <command> [args]
```

The process prints exactly one JSON object on stdout and nothing else, except that a single trailing newline is allowed. Exit 0 means the command completed. A refusal is a nonzero exit and a JSON object whose `error` value is one of the codes in this brief. Extra JSON fields are allowed. Field names and values named below are required. stderr is ignored by acceptance checks.

Environment:

- `STATE_DIR` — directory for the durable store. The desk may create it. A new process with the same `STATE_DIR` sees every record the previous process committed. The desk chooses its own filenames inside `STATE_DIR` and must leave every other file there unchanged, including on refusal.
- `SERVICE_URL` — mail service base URL, with no trailing slash. Example: `http://127.0.0.1:9`.
- `CRASH_AT` — optional. When the running command reaches the named boundary, the process must kill itself with `SIGKILL` (`os.kill(os.getpid(), signal.SIGKILL)`). If the command never reaches that boundary, it must not kill itself.

Committed means a later process with the same `STATE_DIR` can read the record after `SIGKILL`. Flush the record to disk before treating it as committed.

### Crash boundaries

`after-attempt-saved-before-request`
On `checkout`, after the attempt record (loan id, item id, reservation id, borrower id, and address) is committed, and before any byte of the confirmation HTTP request is sent. Not on a later `checkout` that finds the attempt already saved.

`after-accept-before-record`
On `checkout`, after the service has accepted the confirmation and this process has read the complete HTTP response body of that acceptance POST, and before the durable checkout outcome is committed. Not on a lookup that only reads an acceptance performed by an earlier process.

`after-record-before-exit`
On `checkout` or `reconcile`, after a terminal confirmation outcome (`notify` `sent` and loan `checked_out`) is committed, and before the success JSON is written and the process exits. Not when that outcome was already committed before this invocation.

## Identifiers, addresses, and time

- Item id, reservation id, loan id, and borrower id: 1 to 64 characters from `A-Za-z0-9._-`.
- Item ids, reservation ids, and loan ids share one namespace. A new one of those ids that equals any existing item, reservation, or loan id is refused `id_in_use`. Expired and returned ids stay in the namespace. Borrower ids are format-checked only and may repeat across items.
- Address: `local@domain`, where `local` is 1 to 64 characters from `A-Za-z0-9._+-` and `domain` is 1 to 63 characters from `A-Za-z0-9.-`.
- `now` and `collect_by` are canonical decimal integers: `0` or digits matching `[1-9][0-9]*`, with no sign and no leading zero. `now` is from 0 through 9999999999. A non-canonical or out-of-range time is `bad_args`.
- The mail request id for a checkout confirmation is the loan id. The desk must not allocate a different request id for that loan.

Paths are used as given. Relative paths are relative to the process working directory.

## Commands

### `./run add-item <item_id>`

Register an item as available. Success, exit 0:

```json
{"item_id":"...","availability":"available","reservation_id":null,"loan_id":null}
```

Refuse `bad_args` if the id is malformed. Refuse `id_in_use` if the id is already in the namespace. Do not contact the service.

### `./run reserve <item_id> <reservation_id> <borrower_id> <address> <collect_by> <now>`

Hold an available item for the borrower until `collect_by`. `collect_by` must be greater than `now`. Do not contact the service.

If the item is reserved, `reservation_state` is `active`, and `now` is greater than or equal to the stored `collect_by`, commit that reservation as `expired` and the item as `available` before applying this reserve. That expiry sends no mail.

Success, exit 0:

```json
{"item_id":"...","reservation_id":"...","borrower_id":"...","address":"...","collect_by":0,"availability":"reserved","now":0}
```

Refuse, without changing the store, when:

- the item does not exist: `unknown_item`
- any argument is malformed, or `collect_by` is not greater than `now`: `bad_args`
- the reservation id collides with an existing item, reservation, or loan id: `id_in_use`
- the item is `checked_out`, or it is `reserved` and the current reservation is not due at `now`: `not_available`

### `./run expire <item_id> <now>`

Commit expiry when the item is `reserved`, `reservation_state` is `active`, and `now` is greater than or equal to `collect_by`. The item becomes `available`, `reservation_state` becomes `expired`, and no loan is created. Do not contact the service.

If the item exists and that condition is not met, exit 0 and leave the reservation in place. A `checked_out` item is not expired by this command.

Success, exit 0:

```json
{"item_id":"...","availability":"available","expired":true,"reservation_id":"...","now":0}
```

`expired` is `false` when nothing was committed. `reservation_id` is the stored reservation id, or `null` when the item has none. Refuse `unknown_item` or `bad_args`. A refusal must not change the store.

### `./run checkout <item_id> <reservation_id> <loan_id> <now>`

Collect a reservation and ask the mail service to confirm it.

Apply the same expiry commit as `expire` first, for this item only. If that commit expires the named reservation, refuse `expired`, do not create a loan, and do not contact the service.

Otherwise refuse, with no service contact and no store change, when:

- the item is `checked_out`: `already_checked_out`
- the item has no active reservation: `not_reserved`
- the item is reserved for a different reservation id: `reservation_mismatch`
- a checkout attempt for a different loan id is already saved on this item: `checkout_in_progress`
- the loan id collides with any id other than this saved attempt: `id_in_use`
- arguments are malformed: `bad_args`
- the item does not exist: `unknown_item`

If `loan_state` is already `checked_out` for this item, the refusal is `already_checked_out` even when `loan_id` matches. That is a double checkout. It must not contact the service.

If the named reservation is already `expired`, refuse `expired` and do not contact the service.

When the reservation is active and `now` is less than `collect_by`:

1. If no attempt is saved yet, commit an attempt (`loan_state` `attempt_saved`, `notify` `attempt_saved`, the loan id, reservation id, borrower id, and address). The item stays `reserved`. Then honor `after-attempt-saved-before-request`.
2. If an attempt is already saved for this loan id and reservation id, keep that loan id. Do not honor `after-attempt-saved-before-request` again.
3. `GET /v1/requests/<loan_id>`. If the service returns HTTP 200 for that loan id with the same item, borrower, address, and `kind` `checkout`, commit `checked_out` and `notify` `sent`. Do not POST.
4. If the lookup returns HTTP 404, `POST /v1/messages` once with that same loan id, as specified in the service section. After the complete response body is read, honor `after-accept-before-record`, then commit `checked_out` and `notify` `sent` when the response is HTTP 200 for that same payload.
5. Honor `after-record-before-exit` only if this invocation committed that terminal outcome, then print:

```json
{"item_id":"...","reservation_id":"...","loan_id":"...","borrower_id":"...","address":"...","availability":"checked_out","notify":"sent","request_id":"...","now":0}
```

`request_id` equals `loan_id`. `reservation_state` becomes `collected`.

If the connection fails, the response is incomplete, or the service returns a status other than 200 for that POST, exit nonzero `service_unavailable`. Leave the attempt record in place. Do not POST a different request id in that invocation. Do not report that the service has no record unless a lookup returned HTTP 404. The invocation may return without a lookup after a failed POST; `reconcile` will query the service.

If the lookup returns HTTP 200 whose item, borrower, address, or kind differs from the attempt, exit nonzero `conflict` and do not change the attempt.

A HTTP 409 from the POST is `conflict`. The attempt stays in place. Do not allocate another request id.

### `./run return <item_id> <loan_id> <now>`

Return a checked-out item. Do not contact the service.

Success, exit 0, only when `availability` is `checked_out` and `loan_id` is the active loan:

```json
{"item_id":"...","loan_id":"...","availability":"available","loan_state":"returned","now":0}
```

The loan stays `returned` and `notify` stays `sent`. The item is `available`.

Refuse, with no store change, when:

- the item is `available` or `reserved`: `not_checked_out`
- the item is `checked_out` under a different loan id: `loan_mismatch`
- the item does not exist: `unknown_item`
- arguments are malformed: `bad_args`

A second return of an already returned loan is `not_checked_out`.

### `./run status <item_id> <now>`

Print the committed local record. Do not contact the service. Do not commit expiry or any other change. `past_deadline` is computed only for this response: it is true when `reservation_state` is `expired`, or when `reservation_state` is `active` and `now` is greater than or equal to `collect_by`. Otherwise it is false.

Success, exit 0:

```json
{"item_id":"...","availability":"available","reservation_id":null,"borrower_id":null,"address":null,"collect_by":null,"reservation_state":"none","past_deadline":false,"loan_id":null,"loan_state":"none","notify":"none","now":0}
```

`availability` is `available`, `reserved`, or `checked_out`. `reservation_state` is `none`, `active`, `expired`, or `collected`. `loan_state` is `none`, `attempt_saved`, `checked_out`, or `returned`. `notify` is `none`, `attempt_saved`, or `sent`. After a reservation or loan exists, the stored ids and address are present instead of null. Refuse `unknown_item` or `bad_args`.

### `./run reconcile <loan_id>`

Resolve an uncertain confirmation by lookup. This command must not POST, and must not allocate a request id.

- No attempt saved for that loan id: exit 0 with `notify` `none` and `item_id` null. This is not `not_sent`.
- Lookup HTTP 404: exit 0 with `notify` `not_sent` and the saved loan id. Leave the attempt in place. `not_sent` means only that this lookup returned HTTP 404.
- Lookup HTTP 200 with the same item, borrower, address, and `kind` `checkout`: commit `checked_out` and `notify` `sent`, honor `after-record-before-exit` if this invocation committed that outcome, and exit 0. Do not POST.
- Lookup HTTP 200 that does not match the attempt: exit nonzero `conflict` and do not change the local outcome.
- The service cannot be contacted, or the response is incomplete: exit nonzero `service_unavailable`. Do not change the attempt. Do not report `not_sent`.

If `notify` is already `sent` and the loan is already `checked_out`, exit 0 and leave that outcome unchanged. Do not POST, and do not honor `after-record-before-exit`.

Success shape:

```json
{"request_id":"...","loan_id":"...","item_id":"...","kind":"checkout","notify":"sent","availability":"checked_out","loan_state":"checked_out"}
```

For `notify` `none`, `loan_id` is null when the id was never a loan attempt, `kind` is null, `availability` is null, and `loan_state` is `none`. For `not_sent`, `kind` is `checkout` and the saved item fields are present.

### `./run callback <callback_path>`

The file contains one JSON callback object (shape below). A well-formed callback exits 0 with `{"ok":true}`.

- If `notify` is already `sent`, or `loan_state` is `checked_out` or `returned`, do not change availability, loan fields, borrower, address, reservation, or `notify`, whether the callback repeats the same payload or names a different address, borrower, kind, or outcome.
- A callback must not cause a POST, and must not allocate a new request id.
- A callback for an unknown request id does not change the store.
- If `notify` is `attempt_saved` and the callback names that request id, the desk may look up that request id and commit the service result. It must not mark `sent` when the service has no matching acceptance. The callback body is not the authority for the address or borrower; the attempt record is.
- The desk may ignore a callback entirely. Ignoring a well-formed callback still exits 0.

A malformed file (not one JSON object, or missing a required callback field, or `outcome` not `accepted` or `rejected`) exits nonzero `bad_args` and does not change the store.

## Mail service

`SERVICE_URL` has no trailing slash. The desk uses these routes. The same rules are in `stub/CONTRACT.md`.

`POST /v1/messages` with `Content-Type: application/json`:

```json
{"request_id":"...","item_id":"...","borrower_id":"...","address":"...","kind":"checkout"}
```

- A missing field, a bad `kind`, or a malformed id is HTTP 400 and stores nothing. Checkout in this brief uses `kind` `checkout`.
- The first time a `request_id` is accepted, the service counts one send effect. Response HTTP 200:

```json
{"request_id":"...","item_id":"...","borrower_id":"...","address":"...","kind":"checkout","outcome":"accepted"}
```

- The same `request_id` with the same item, borrower, address, and kind returns the same result and does not count another effect.
- The same `request_id` with a different item, borrower, address, or kind returns HTTP 409 `{"error":"conflict"}` and does not change the stored effect.
- A different `request_id` is a different effect, even when the other fields match.

`GET /v1/requests/<request_id>` returns that 200 object, or HTTP 404 `{"error":"not_found"}` if that id was never accepted.

The service may drop the HTTP reply after it has accepted and counted the effect, may answer late, may return HTTP 500 without storing, and may cause the same callback to be presented twice or a later callback to name a different address. Those conditions are properties of the service. The desk does not open a listening port for callbacks. The operator delivers a callback by running `./run callback <file>`.

A dropped reply or a failed connection is not evidence that the service has no record. HTTP 500, an incomplete response, and a connection failure are `service_unavailable` on that invocation. They leave the attempt in place and must not cause a new request id.

Callback file:

```json
{"callback_id":"...","request_id":"...","item_id":"...","borrower_id":"...","address":"...","kind":"checkout","outcome":"accepted"}
```

`outcome` is `accepted` or `rejected`. `kind` is `checkout` or `waitlist_ready`. This brief sends only `checkout`. A `rejected` callback must not mark a loan `sent`.

## Requirements

R1. Persistence. After `add-item` and `reserve`, a new process with the same `STATE_DIR` sees both items and the reservation. A second item remains available when the first item changes. A checkout killed at `after-record-before-exit` is visible to a later process as `checked_out` with `notify` `sent`.

R2. Reservation record. `reserve` stores the borrower, address, reservation id, and `collect_by`. A later `status` returns those exact values and `availability` `reserved`.

R3. Expiry. With `now` less than `collect_by`, `expire` leaves the reservation active and sends no mail. With `now` greater than or equal to `collect_by`, `expire` commits `available` and `reservation_state` `expired` and sends no mail. `checkout` of that reservation is refused `expired` and does not contact the service. `checkout` with `now` already past `collect_by`, before a separate `expire`, also commits expiry, refuses `expired`, and does not contact the service. A later `reserve` of that item at that `now` succeeds for a new reservation id and sends no mail.

R4. Confirmation payload. After a successful checkout against a healthy service, `status` reports `checked_out`, the loan id, the borrower, and the address. The service has one accepted message for that loan id with the same item, borrower, address, and `kind` `checkout`.

R5. Legitimate progress. With a healthy service, `add-item`, `reserve` with `collect_by` greater than `now`, and `checkout` each exit 0, `status` then reports `checked_out`, and the service has exactly one effect. A valid sequence must not be refused.

R6. Double checkout. After a successful checkout, another `checkout` of that item, whether it repeats the loan id or uses a new one, is refused `already_checked_out`, leaves the loan id and borrower unchanged, and does not add an effect.

R7. Return. `return` of an `available` or `reserved` item is refused `not_checked_out` and does not change availability. `return` of the active loan exits 0 and leaves the item `available` with `loan_state` `returned`. `return` with a different loan id while checked out is refused `loan_mismatch` and leaves the loan in place.

R8. Crash after accept. If `checkout` is killed at `after-accept-before-record`, the service has already counted one effect for the saved loan id, and `status` still shows `attempt_saved`. A later `checkout` of that same loan, with `CRASH_AT` unset, must end with `status` `checked_out` and `notify` `sent`, must not say the request was never sent, and must not cause the service to count a second effect or a different request id.

R9. Crash before request. If `checkout` is killed at `after-attempt-saved-before-request`, the service has counted no effect and has received no confirmation POST, and `status` shows `attempt_saved` and the saved loan id. A later `checkout` of a different loan id for that item is refused `checkout_in_progress` and adds no effect. A later `checkout` of the saved loan id, with `CRASH_AT` unset, must reach `checked_out` and the service must count exactly one effect, for that same loan id.

R10. Crash after the durable record. If `checkout` is killed at `after-record-before-exit`, a later `status` shows `checked_out` and `notify` `sent`, and a further `checkout` must not add an effect.

R11. Lost reply. If the service accepts a confirmation and drops the reply, that acceptance has already counted one effect. `checkout` may exit nonzero, or it may look up the loan id and commit `sent` before returning. It must leave an attempt in place if it does not commit `sent`, and it must not POST a different request id. A following `reconcile` of that loan id must record `notify` `sent` and `checked_out`, must not report `not_sent`, must not POST, and must not add an effect. `not_sent` is legal only when the request lookup returns HTTP 404.

R12. Result protocol. A successful `add-item` exits 0 and prints one JSON object containing the item id. A refusal, such as `checkout` with no such item, exits nonzero and prints one JSON object whose `error` value is one of the codes defined in this brief.

R13. Unrelated writer. A file in `STATE_DIR` written by another process, which the desk did not create, is still present with the same bytes after later desk commands, including a refusal. Those commands still see the records owned by the desk.

R14. Late or conflicting callback. After a successful checkout, delivering a well-formed callback for that loan twice, including one whose address differs from the stored address, exits 0 both times, leaves availability, loan id, borrower, address, and `notify` unchanged, and does not add a send effect.

## Out of scope

Concurrent `./run` processes, a second confirmation for the same loan, waitlists, renewals, damage deposits, transfers of a loan to another borrower, and any multi-site or distributed transaction are outside this brief. HTTP 500 and a delayed reply are service conditions the desk must survive as specified above. They are not separate scored features beyond the lost-reply and crash rules.

## Error codes

`bad_args`, `unknown_item`, `id_in_use`, `not_available`, `not_reserved`, `reservation_mismatch`, `expired`, `already_checked_out`, `checkout_in_progress`, `not_checked_out`, `loan_mismatch`, `service_unavailable`, `conflict`.
