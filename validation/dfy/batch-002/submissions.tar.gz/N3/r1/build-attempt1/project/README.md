# Equipment loan desk

This is a one-process-at-a-time local equipment desk. Durable lifecycle state is
owned by the packaged Ikaros runtime in `KIT/bin/ik`; the Python host performs
CLI validation, mail HTTP I/O, and recovery/reconciliation.

## Setup

From this directory, with Python 3.9 or newer:

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
```

No npm package is required. Start the supplied fake mail service separately as
documented in `stub/CONTRACT.md`, using one of the allowed local ports, then
run commands with:

```sh
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:48000 ./run add-item camera-1
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:48000 ./run reserve camera-1 reservation-1 borrower-1 person@example.test 100 0
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:48000 ./run checkout camera-1 reservation-1 loan-1 1
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:48000 ./run status camera-1 1
```

`run` sets `IK_BINARY` to the packed binary automatically and preserves the
caller's working directory, so relative `STATE_DIR` and callback paths retain
their specified meaning. Set `CRASH_AT` to one of the boundaries in `BRIEF.md`
when exercising crash recovery. A later invocation with the same state directory
uses the same Ikaros store and reconciles an `attempt_saved` checkout by its
loan id; it never allocates a replacement request id.

The callback command validates the required callback shape and intentionally
ignores a well-formed callback, which is permitted by the brief:

```sh
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:48000 ./run callback callback.json
```
