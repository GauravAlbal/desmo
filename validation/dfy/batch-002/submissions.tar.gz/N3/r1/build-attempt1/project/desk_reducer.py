from __future__ import annotations

import hashlib
import re
from collections.abc import Mapping
from typing import Any, Optional

from invariant_kernel import ApplyOutcome, Decision, DomainEvent, ReducerDiagnostic, ReducerIdentity

_ID = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
_LOCAL = re.compile(r"^[A-Za-z0-9._+-]{1,64}$")
_DOMAIN = re.compile(r"^[A-Za-z0-9.-]{1,63}$")


def _digest(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _diag(code: str, message: str) -> ReducerDiagnostic:
    return ReducerDiagnostic(code, message)


def _id(value: Any) -> bool:
    return isinstance(value, str) and _ID.fullmatch(value) is not None


def _address(value: Any) -> bool:
    if not isinstance(value, str) or value.count("@") != 1:
        return False
    local, domain = value.split("@")
    return _LOCAL.fullmatch(local) is not None and _DOMAIN.fullmatch(domain) is not None


def _time(value: Any) -> bool:
    if not isinstance(value, str) or value == "":
        return False
    if value == "0":
        return True
    return value[0] != "0" and value.isdecimal() and int(value) <= 9999999999


def _args(command: Any) -> tuple[Optional[str], Mapping[str, Any] | None]:
    if not isinstance(command, Mapping):
        return None, None
    name = command.get("name")
    args = command.get("args", {})
    if not isinstance(name, str) or not isinstance(args, Mapping):
        return None, None
    return name, args


class EquipmentDeskReducer:
    identity = ReducerIdentity(
        "equipment_loan_desk",
        1,
        _digest("equipment-loan-desk-reducer-v1"),
        _digest("equipment-loan-desk-commands-v1"),
        _digest("equipment-loan-desk-state-v1"),
    )

    def initial_state(self) -> dict[str, Any]:
        return {"items": {}, "ids": []}

    def decide(
        self,
        state: Any,
        observation: Any,
        effect: Any,
        command: Any,
    ) -> Decision | ReducerDiagnostic:
        del observation, effect
        name, args = _args(command)
        if name is None or args is None:
            return _diag("bad_args", "command must contain a name and args object")
        items = state.get("items") if isinstance(state, Mapping) else None
        ids = state.get("ids") if isinstance(state, Mapping) else None
        if not isinstance(items, Mapping) or not isinstance(ids, (list, tuple)):
            return _diag("state_corrupt", "desk state has an invalid shape")
        known = set(ids)

        if name == "add_item":
            item_id = args.get("item_id")
            if not _id(item_id):
                return _diag("bad_args", "malformed item id")
            if item_id in known:
                return _diag("id_in_use", "id is already in use")
            return Decision.emit(DomainEvent("add_item", 1, {"item_id": item_id}))

        item_id = args.get("item_id")
        if not _id(item_id):
            return _diag("bad_args", "malformed item id")
        item = items.get(item_id)
        if not isinstance(item, Mapping):
            return _diag("unknown_item", "item does not exist")

        if name == "reserve":
            reservation_id = args.get("reservation_id")
            borrower_id = args.get("borrower_id")
            address = args.get("address")
            collect_by = args.get("collect_by")
            now = args.get("now")
            if not (_id(reservation_id) and _id(borrower_id) and _address(address) and _time(collect_by) and _time(now)):
                return _diag("bad_args", "malformed reservation arguments")
            if int(collect_by) <= int(now):
                return _diag("bad_args", "collect_by must be greater than now")
            if reservation_id in known:
                return _diag("id_in_use", "id is already in use")
            if item["availability"] == "checked_out":
                return _diag("not_available", "item is checked out")
            if item["availability"] == "reserved" and item.get("reservation_state") == "active":
                if int(now) < int(item["collect_by"]):
                    return _diag("not_available", "item is reserved")
            return Decision.emit(DomainEvent("reserve", 1, {
                "item_id": item_id,
                "reservation_id": reservation_id,
                "borrower_id": borrower_id,
                "address": address,
                "collect_by": collect_by,
            }))

        if name == "expire":
            now = args.get("now")
            if not _time(now):
                return _diag("bad_args", "malformed time")
            if item["availability"] == "reserved" and item.get("reservation_state") == "active" and int(now) >= int(item["collect_by"]):
                return Decision.emit(DomainEvent("expire", 1, {"item_id": item_id}))
            return Decision.noop()

        if name == "checkout_prepare":
            reservation_id = args.get("reservation_id")
            loan_id = args.get("loan_id")
            now = args.get("now")
            if not (_id(reservation_id) and _id(loan_id) and _time(now)):
                return _diag("bad_args", "malformed checkout arguments")
            if item["availability"] == "checked_out":
                return _diag("already_checked_out", "item is already checked out")
            if item["availability"] == "reserved" and item.get("reservation_state") == "active" and int(now) >= int(item["collect_by"]):
                return Decision.emit(DomainEvent("expire", 1, {"item_id": item_id}))
            if item.get("reservation_state") == "expired":
                return _diag("expired", "reservation has expired")
            if item["availability"] != "reserved" or item.get("reservation_state") != "active":
                return _diag("not_reserved", "item has no active reservation")
            if item.get("reservation_id") != reservation_id:
                return _diag("reservation_mismatch", "reservation id does not match")
            if item.get("loan_state") == "attempt_saved":
                if item.get("loan_id") != loan_id:
                    return _diag("checkout_in_progress", "another checkout attempt is saved")
                return Decision.noop()
            if loan_id in known:
                return _diag("id_in_use", "id is already in use")
            return Decision.emit(DomainEvent("checkout_attempt", 1, {
                "item_id": item_id,
                "reservation_id": reservation_id,
                "loan_id": loan_id,
            }))

        if name == "checkout_complete":
            loan_id = args.get("loan_id")
            if not _id(loan_id):
                return _diag("bad_args", "malformed loan id")
            if item.get("loan_state") == "checked_out" and item.get("loan_id") == loan_id:
                return Decision.noop()
            if item.get("loan_state") != "attempt_saved" or item.get("loan_id") != loan_id:
                return _diag("conflict", "checkout attempt does not match")
            return Decision.emit(DomainEvent("checkout_complete", 1, {"item_id": item_id, "loan_id": loan_id}))

        if name == "return":
            loan_id = args.get("loan_id")
            now = args.get("now")
            if not (_id(loan_id) and _time(now)):
                return _diag("bad_args", "malformed return arguments")
            if item["availability"] != "checked_out":
                return _diag("not_checked_out", "item is not checked out")
            if item.get("loan_id") != loan_id:
                return _diag("loan_mismatch", "loan id does not match")
            return Decision.emit(DomainEvent("return", 1, {"item_id": item_id, "now": now}))

        return _diag("bad_args", "unknown command")

    def apply(self, state: Any, event: DomainEvent) -> ApplyOutcome | ReducerDiagnostic:
        if not isinstance(state, Mapping) or not isinstance(state.get("items"), Mapping) or not isinstance(state.get("ids"), (list, tuple)):
            return _diag("state_corrupt", "desk state has an invalid shape")
        items = {str(k): dict(v) for k, v in state["items"].items()}
        ids = list(state["ids"])
        payload = event.payload
        if not isinstance(payload, Mapping):
            return _diag("state_corrupt", "event payload is invalid")
        op = event.event_type
        item_id = payload.get("item_id")
        if op == "add_item":
            items[item_id] = {
                "availability": "available", "reservation_id": None, "borrower_id": None,
                "address": None, "collect_by": None, "reservation_state": "none",
                "loan_id": None, "loan_state": "none", "notify": "none",
            }
            ids.append(item_id)
        elif op == "reserve":
            item = items[item_id]
            item.update({
                "availability": "reserved", "reservation_id": payload["reservation_id"],
                "borrower_id": payload["borrower_id"], "address": payload["address"],
                "collect_by": payload["collect_by"], "reservation_state": "active",
                "loan_id": None, "loan_state": "none", "notify": "none",
            })
            ids.append(payload["reservation_id"])
        elif op == "expire":
            item = items[item_id]
            item.update({"availability": "available", "reservation_state": "expired"})
        elif op == "checkout_attempt":
            item = items[item_id]
            item.update({"loan_id": payload["loan_id"], "loan_state": "attempt_saved", "notify": "attempt_saved"})
            ids.append(payload["loan_id"])
        elif op == "checkout_complete":
            item = items[item_id]
            item.update({"availability": "checked_out", "reservation_state": "collected", "loan_state": "checked_out", "notify": "sent"})
        elif op == "return":
            item = items[item_id]
            item.update({"availability": "available", "loan_state": "returned"})
        else:
            return _diag("state_corrupt", "unknown event")
        return ApplyOutcome.new({"items": items, "ids": ids})
