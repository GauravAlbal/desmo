import http from "node:http";

const effects = [];
const byId = new Map();
const posts = [];
const callbacks = [];
let fault = { drop_reply: false, delay_ms: 0, hold: false, next_status: 0 };
let releaseHold = null;
let holdGate = Promise.resolve();

function armHold() {
  holdGate = new Promise((resolve) => {
    releaseHold = resolve;
  });
}

function json(res, status, body) {
  const raw = JSON.stringify(body);
  res.writeHead(status, { "content-type": "application/json", "content-length": Buffer.byteLength(raw) });
  res.end(raw);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (chunk) => chunks.push(chunk));
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function validId(value) {
  return typeof value === "string" && /^[A-Za-z0-9._-]{1,64}$/.test(value);
}

function validAddress(value) {
  return typeof value === "string" && /^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$/.test(value);
}

function samePayload(stored, body) {
  return stored.item_id === body.item_id && stored.borrower_id === body.borrower_id && stored.address === body.address && stored.kind === body.kind;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function applyFaultWait() {
  if (fault.hold) await holdGate;
  if (fault.delay_ms > 0) await sleep(fault.delay_ms);
}

async function handleMessage(req, res) {
  let body;
  try {
    body = JSON.parse(await readBody(req));
  } catch {
    posts.push({ request_id: null, kind: null, stored: false });
    json(res, 400, { error: "bad_request" });
    return;
  }
  const kindOk = body.kind === "checkout" || body.kind === "waitlist_ready";
  if (!validId(body.request_id) || !validId(body.item_id) || !validId(body.borrower_id) || !validAddress(body.address) || !kindOk) {
    posts.push({ request_id: body.request_id || null, kind: body.kind || null, stored: false });
    json(res, 400, { error: "bad_request" });
    return;
  }
  if (fault.next_status >= 400 && fault.next_status <= 599) {
    const status = fault.next_status;
    fault.next_status = 0;
    posts.push({ request_id: body.request_id, kind: body.kind, stored: false });
    await applyFaultWait();
    json(res, status, { error: "unavailable" });
    return;
  }
  const existing = byId.get(body.request_id);
  if (existing) {
    posts.push({ request_id: body.request_id, kind: body.kind, stored: true });
    if (!samePayload(existing, body)) {
      json(res, 409, { error: "conflict" });
      return;
    }
    await applyFaultWait();
    if (fault.drop_reply) {
      res.destroy();
      return;
    }
    json(res, 200, existing);
    return;
  }
  const stored = {
    request_id: body.request_id,
    item_id: body.item_id,
    borrower_id: body.borrower_id,
    address: body.address,
    kind: body.kind,
    outcome: "accepted",
  };
  byId.set(body.request_id, stored);
  effects.push({
    request_id: stored.request_id,
    item_id: stored.item_id,
    borrower_id: stored.borrower_id,
    address: stored.address,
    kind: stored.kind,
  });
  callbacks.push({
    callback_id: "cb-" + stored.request_id,
    request_id: stored.request_id,
    item_id: stored.item_id,
    borrower_id: stored.borrower_id,
    address: stored.address,
    kind: stored.kind,
    outcome: "accepted",
  });
  posts.push({ request_id: body.request_id, kind: body.kind, stored: true });
  await applyFaultWait();
  if (fault.drop_reply) {
    res.destroy();
    return;
  }
  json(res, 200, stored);
}

function dataHandler(req, res) {
  const url = new URL(req.url, "http://127.0.0.1");
  if (req.method === "GET" && url.pathname === "/health") {
    json(res, 200, { ok: true });
    return;
  }
  if (req.method === "POST" && url.pathname === "/v1/messages") {
    handleMessage(req, res).catch(() => {
      if (!res.headersSent) json(res, 500, { error: "unavailable" });
    });
    return;
  }
  if (req.method === "GET" && url.pathname.startsWith("/v1/requests/")) {
    const id = decodeURIComponent(url.pathname.slice("/v1/requests/".length));
    const stored = byId.get(id);
    if (!stored) {
      json(res, 404, { error: "not_found" });
      return;
    }
    json(res, 200, stored);
    return;
  }
  json(res, 404, { error: "not_found" });
}

function controlHandler(req, res) {
  const url = new URL(req.url, "http://127.0.0.1");
  if (req.method === "GET" && url.pathname === "/health") {
    json(res, 200, { ok: true });
    return;
  }
  if (req.method === "GET" && url.pathname === "/effects") {
    json(res, 200, { count: effects.length, effects, posts });
    return;
  }
  if (req.method === "GET" && url.pathname === "/callbacks") {
    json(res, 200, { callbacks });
    return;
  }
  if (req.method === "POST" && url.pathname === "/release") {
    if (releaseHold) {
      const done = releaseHold;
      releaseHold = null;
      armHold();
      done();
    }
    json(res, 200, { ok: true });
    return;
  }
  if (req.method === "POST" && url.pathname === "/fault") {
    readBody(req).then((raw) => {
      const body = raw ? JSON.parse(raw) : {};
      if (typeof body.drop_reply === "boolean") fault.drop_reply = body.drop_reply;
      if (typeof body.delay_ms === "number" && body.delay_ms >= 0) fault.delay_ms = body.delay_ms;
      if (typeof body.hold === "boolean") {
        fault.hold = body.hold;
        if (body.hold && !releaseHold) armHold();
        if (!body.hold && releaseHold) {
          const done = releaseHold;
          releaseHold = null;
          done();
        }
      }
      if (typeof body.next_status === "number") fault.next_status = body.next_status;
      json(res, 200, { ok: true, fault });
    }).catch(() => json(res, 400, { error: "bad_request" }));
    return;
  }
  json(res, 404, { error: "not_found" });
}

armHold();
const data = http.createServer(dataHandler);
const control = http.createServer(controlHandler);
data.listen(0, "127.0.0.1", () => {
  const dataPort = data.address().port;
  control.listen(0, "127.0.0.1", () => {
    const controlPort = control.address().port;
    process.stdout.write(JSON.stringify({
      service_url: "http://127.0.0.1:" + dataPort,
      control_url: "http://127.0.0.1:" + controlPort,
    }) + "\n");
  });
});
