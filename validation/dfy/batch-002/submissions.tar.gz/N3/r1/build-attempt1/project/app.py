from __future__ import annotations

import http.client
import json
import os
import signal
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from invariant_kernel import HistoricalResult, Kernel, KernelError

from desk_reducer import EquipmentDeskReducer

AGGREGATE_ID = "desk"
STORE_NAME = "equipment-desk.kernel.db"

_ID_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._-")
_LOCAL_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._+-")
_DOMAIN_CHARS = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.-")


class DeskError(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


class ServiceError(Exception):
    pass


class ServiceConflict(ServiceError):
    pass


def _valid_id(value: Any) -> bool:
    return isinstance(value, str) and 1 <= len(value) <= 64 and all(c in _ID_CHARS for c in value)


def _valid_address(value: Any) -> bool:
    if not isinstance(value, str) or value.count("@") != 1:
        return False
    local, domain = value.split("@")
    return 1 <= len(local) <= 64 and len(domain) <= 63 and len(domain) >= 1 and all(c in _LOCAL_CHARS for c in local) and all(c in _DOMAIN_CHARS for c in domain)


def _valid_time(value: Any) -> bool:
    if not isinstance(value, str) or not value:
        return False
    if value == "0":
        return True
    return value[0] != "0" and value.isdecimal() and int(value) <= 9999999999


def _time_arg(value: str) -> int:
    if not _valid_time(value):
        raise DeskError("bad_args")
    return int(value)


def _json(value: Any) -> None:
    sys.stdout.write(json.dumps(value, separators=(",", ":"), ensure_ascii=False) + "\n")


def _crash(boundary: str) -> None:
    if os.environ.get("CRASH_AT") == boundary:
        os.kill(os.getpid(), signal.SIGKILL)


def _service_url() -> tuple[str, int, bool, str]:
    raw = os.environ.get("SERVICE_URL")
    if not raw:
        raise ServiceError("missing SERVICE_URL")
    parsed = urlsplit(raw)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
        raise ServiceError("invalid SERVICE_URL")
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    return parsed.hostname, port, parsed.scheme == "https", parsed.path.rstrip("/")


def _http(method: str, path: str, payload: dict[str, Any] | None = None) -> tuple[int, Any]:
    host, port, secure, base = _service_url()
    connection: http.client.HTTPConnection
    connection = http.client.HTTPSConnection(host, port, timeout=10) if secure else http.client.HTTPConnection(host, port, timeout=10)
    body = None
    headers = {}
    if payload is not None:
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        headers = {"Content-Type": "application/json", "Content-Length": str(len(body))}
    try:
        connection.request(method, base + path, body=body, headers=headers)
        response = connection.getresponse()
        raw = response.read()
    except (OSError, http.client.HTTPException, TimeoutError) as exc:
        raise ServiceError(str(exc)) from exc
    finally:
        connection.close()
    if response.status == 404:
        return response.status, None
    try:
        decoded = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ServiceError("incomplete or malformed service response") from exc
    if not isinstance(decoded, dict):
        raise ServiceError("malformed service response")
    return response.status, decoded


def _new_kernel() -> tuple[Kernel, Any, Any]:
    state_raw = os.environ.get("STATE_DIR")
    if not state_raw:
        raise DeskError("bad_args")
    state_dir = Path(state_raw)
    state_dir.mkdir(parents=True, exist_ok=True)
    kernel = Kernel(state_dir / STORE_NAME, binary=os.environ.get("IK_BINARY"))
    machine = kernel.reducer("desk_reducer:EquipmentDeskReducer", python=sys.executable)
    try:
        aggregate = machine.show(AGGREGATE_ID)
    except KernelError as exc:
        if exc.code == "IK_STORE_NOT_FOUND" or exc.rule == "aggregate.not_found":
            aggregate = machine.create(AGGREGATE_ID)
        else:
            raise
    return kernel, machine, aggregate


def _execute(aggregate: Any, name: str, args: dict[str, Any]) -> Any:
    result = aggregate.execute({"name": name, "args": args})
    if isinstance(result, HistoricalResult):
        raise DeskError("service_unavailable")
    return result


def _item(aggregate: Any, item_id: str) -> dict[str, Any]:
    items = aggregate.state.get("items", {})
    value = items.get(item_id)
    if not isinstance(value, dict):
        raise DeskError("unknown_item")
    return dict(value)


def _status_value(item_id: str, item: dict[str, Any], now: int) -> dict[str, Any]:
    state = item.get("reservation_state")
    collect_by = item.get("collect_by")
    past = state == "expired" or (state == "active" and collect_by is not None and now >= int(collect_by))
    return {
        "item_id": item_id,
        "availability": item["availability"],
        "reservation_id": item.get("reservation_id"),
        "borrower_id": item.get("borrower_id"),
        "address": item.get("address"),
        "collect_by": int(collect_by) if collect_by is not None else None,
        "reservation_state": state,
        "past_deadline": past,
        "loan_id": item.get("loan_id"),
        "loan_state": item.get("loan_state"),
        "notify": item.get("notify"),
        "now": now,
    }


def _check_payload(payload: Any, item: dict[str, Any], loan_id: str) -> bool:
    return isinstance(payload, dict) and payload.get("request_id") == loan_id and payload.get("item_id") == item.get("_item_id") and payload.get("borrower_id") == item.get("borrower_id") and payload.get("address") == item.get("address") and payload.get("kind") == "checkout" and payload.get("outcome") == "accepted"


def _find_loan(aggregate: Any, loan_id: str) -> tuple[str | None, dict[str, Any] | None]:
    items = aggregate.state.get("items", {})
    for item_id, raw in items.items():
        if isinstance(raw, dict) and raw.get("loan_id") == loan_id:
            item = dict(raw)
            item["_item_id"] = item_id
            return item_id, item
    return None, None


def _checkout(aggregate: Any, item_id: str, reservation_id: str, loan_id: str, now: int) -> dict[str, Any]:
    result = _execute(aggregate, "checkout_prepare", {"item_id": item_id, "reservation_id": reservation_id, "loan_id": loan_id, "now": str(now)})
    item = _item(result, item_id)
    if item["reservation_state"] == "expired" and item["availability"] == "available":
        raise DeskError("expired")
    newly_saved = bool(result.mutation and item.get("loan_state") == "attempt_saved")
    if newly_saved:
        _crash("after-attempt-saved-before-request")
    item["_item_id"] = item_id
    status, payload = _http("GET", "/v1/requests/" + loan_id)
    if status == 200:
        if not _check_payload(payload, item, loan_id):
            raise ServiceConflict("lookup payload conflicts with attempt")
    elif status == 404:
        post_payload = {"request_id": loan_id, "item_id": item_id, "borrower_id": item["borrower_id"], "address": item["address"], "kind": "checkout"}
        post_status, post_body = _http("POST", "/v1/messages", post_payload)
        if post_status == 409:
            raise ServiceConflict("request id conflicts")
        if post_status != 200 or not _check_payload(post_body, item, loan_id):
            raise ServiceError("service rejected checkout")
        _crash("after-accept-before-record")
    else:
        raise ServiceError("service lookup failed")
    completed = _execute(result, "checkout_complete", {"item_id": item_id, "loan_id": loan_id})
    if completed.mutation:
        _crash("after-record-before-exit")
    return _checkout_result(item_id, completed.state["items"][item_id], now)


def _checkout_result(item_id: str, item: dict[str, Any], now: int) -> dict[str, Any]:
    return {"item_id": item_id, "reservation_id": item.get("reservation_id"), "loan_id": item.get("loan_id"), "borrower_id": item.get("borrower_id"), "address": item.get("address"), "availability": item.get("availability"), "notify": item.get("notify"), "request_id": item.get("loan_id"), "now": now}


def _reconcile(aggregate: Any, loan_id: str) -> dict[str, Any]:
    item_id, item = _find_loan(aggregate, loan_id)
    if item is None:
        return {"request_id": None, "loan_id": None, "item_id": None, "kind": None, "notify": "none", "availability": None, "loan_state": "none"}
    if item.get("notify") == "sent" and item.get("loan_state") in {"checked_out", "returned"}:
        return {"request_id": loan_id, "loan_id": loan_id, "item_id": item_id, "kind": "checkout", "notify": "sent", "availability": item["availability"], "loan_state": item["loan_state"]}
    item["_item_id"] = item_id
    status, payload = _http("GET", "/v1/requests/" + loan_id)
    if status == 404:
        return {"request_id": loan_id, "loan_id": loan_id, "item_id": item_id, "kind": "checkout", "notify": "not_sent", "availability": item["availability"], "loan_state": item["loan_state"]}
    if status != 200:
        raise ServiceError("service lookup failed")
    if not _check_payload(payload, item, loan_id):
        raise ServiceConflict("lookup payload conflicts with attempt")
    completed = _execute(aggregate, "checkout_complete", {"item_id": item_id, "loan_id": loan_id})
    if completed.mutation:
        _crash("after-record-before-exit")
    final_item = completed.state["items"][item_id]
    return {"request_id": loan_id, "loan_id": loan_id, "item_id": item_id, "kind": "checkout", "notify": final_item["notify"], "availability": final_item["availability"], "loan_state": final_item["loan_state"]}


def _callback(path: str) -> dict[str, Any]:
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        raise DeskError("bad_args")
    if not isinstance(value, dict):
        raise DeskError("bad_args")
    required = {"callback_id", "request_id", "item_id", "borrower_id", "address", "kind", "outcome"}
    if not required.issubset(value) or not all(isinstance(value[k], str) for k in required):
        raise DeskError("bad_args")
    if not (_valid_id(value["request_id"]) and _valid_id(value["item_id"]) and _valid_id(value["borrower_id"]) and _valid_address(value["address"])):
        raise DeskError("bad_args")
    if value["kind"] not in {"checkout", "waitlist_ready"} or value["outcome"] not in {"accepted", "rejected"}:
        raise DeskError("bad_args")
    return {"ok": True}


def main(argv: list[str]) -> dict[str, Any]:
    if not argv:
        raise DeskError("bad_args")
    command = argv[0]
    if command == "callback":
        if len(argv) != 2:
            raise DeskError("bad_args")
        return _callback(argv[1])
    kernel, machine, aggregate = _new_kernel()
    try:
        if command == "add-item" and len(argv) == 2:
            result = _execute(aggregate, "add_item", {"item_id": argv[1]})
            item = _item(result, argv[1])
            return {"item_id": argv[1], "availability": item["availability"], "reservation_id": None, "loan_id": None}
        if command == "reserve" and len(argv) == 7:
            item_id, reservation_id, borrower_id, address, collect_by, now = argv[1:]
            result = _execute(aggregate, "reserve", {"item_id": item_id, "reservation_id": reservation_id, "borrower_id": borrower_id, "address": address, "collect_by": collect_by, "now": now})
            item = _item(result, item_id)
            return {"item_id": item_id, "reservation_id": reservation_id, "borrower_id": borrower_id, "address": address, "collect_by": int(collect_by), "availability": item["availability"], "now": int(now)}
        if command == "expire" and len(argv) == 3:
            item_id = argv[1]
            now = _time_arg(argv[2])
            result = _execute(aggregate, "expire", {"item_id": item_id, "now": str(now)})
            item = _item(result, item_id)
            return {"item_id": item_id, "availability": item["availability"], "expired": bool(result.mutation), "reservation_id": item.get("reservation_id"), "now": now}
        if command == "checkout" and len(argv) == 5:
            item_id, reservation_id, loan_id = argv[1:4]
            now = _time_arg(argv[4])
            return _checkout(aggregate, item_id, reservation_id, loan_id, now)
        if command == "return" and len(argv) == 4:
            item_id, loan_id = argv[1:3]
            now = _time_arg(argv[3])
            result = _execute(aggregate, "return", {"item_id": item_id, "loan_id": loan_id, "now": str(now)})
            item = _item(result, item_id)
            return {"item_id": item_id, "loan_id": item["loan_id"], "availability": item["availability"], "loan_state": item["loan_state"], "now": now}
        if command == "status" and len(argv) == 3:
            item_id = argv[1]
            now = _time_arg(argv[2])
            item = _item(aggregate, item_id)
            return _status_value(item_id, item, now)
        if command == "reconcile" and len(argv) == 2:
            loan_id = argv[1]
            if not _valid_id(loan_id):
                raise DeskError("bad_args")
            return _reconcile(aggregate, loan_id)
        raise DeskError("bad_args")
    finally:
        kernel.close()


def run() -> None:
    try:
        _json(main(sys.argv[1:]))
    except DeskError as exc:
        _json({"error": exc.code})
        raise SystemExit(1)
    except ServiceConflict:
        _json({"error": "conflict"})
        raise SystemExit(1)
    except ServiceError:
        _json({"error": "service_unavailable"})
        raise SystemExit(1)
    except KernelError as exc:
        code = exc.code if exc.code in {"bad_args", "unknown_item", "id_in_use", "not_available", "not_reserved", "reservation_mismatch", "expired", "already_checked_out", "checkout_in_progress", "not_checked_out", "loan_mismatch", "service_unavailable", "conflict"} else "service_unavailable"
        _json({"error": code})
        raise SystemExit(1)
    except (OSError, ValueError):
        _json({"error": "bad_args"})
        raise SystemExit(1)


if __name__ == "__main__":
    run()
