"""Ikaros reducer for the equipment-loan desk aggregate."""
from __future__ import annotations

import re
from typing import Any, Mapping

from invariant_kernel import ApplyOutcome, Decision, DomainEvent, ReducerDiagnostic, ReducerIdentity

_ID = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
_LOCAL = re.compile(r"^[A-Za-z0-9._+\-]{1,64}$")
_DOMAIN = re.compile(r"^[A-Za-z0-9.-]{1,63}$")
_DECIMAL = re.compile(r"^(0|[1-9][0-9]*)$")


def _diag(code: str, message: str = "command refused") -> ReducerDiagnostic:
    return ReducerDiagnostic(code, message, "desk." + code)


def _copy(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _copy(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_copy(v) for v in value]
    return value


def _valid_id(value: Any) -> bool:
    return isinstance(value, str) and _ID.fullmatch(value) is not None


def _valid_address(value: Any) -> bool:
    if not isinstance(value, str) or value.count("@") != 1:
        return False
    local, domain = value.split("@")
    return _LOCAL.fullmatch(local) is not None and _DOMAIN.fullmatch(domain) is not None


def _valid_time(value: Any) -> bool:
    return (
        isinstance(value, str)
        and _DECIMAL.fullmatch(value) is not None
        and len(value) <= 10
        and int(value) <= 9999999999
    )


def _valid_hold(value: Any) -> bool:
    return isinstance(value, str) and _DECIMAL.fullmatch(value) is not None and 1 <= int(value) <= 2592000


def _args(command: Mapping[str, Any]) -> Mapping[str, Any]:
    value = command.get("args", {})
    return value if isinstance(value, Mapping) else {}


def _ids(state: Mapping[str, Any]) -> set[str]:
    result = {value for value in state.get("used_ids", []) if isinstance(value, str)}
    for item_id, item in state.get("items", {}).items():
        result.add(item_id)
        for key in ("reservation_id", "loan_id"):
            value = item.get(key)
            if value is not None:
                result.add(value)
        for value in item.get("expired_reservations", []):
            if value is not None:
                result.add(value)
        for waiter in item.get("waitlist", []):
            value = waiter.get("wait_id")
            if value is not None:
                result.add(value)
        promotion = item.get("promotion", {})
        if promotion.get("wait_id") is not None:
            result.add(promotion["wait_id"])
    return result


def _empty_item() -> dict[str, Any]:
    return {
        "availability": "available",
        "reservation_id": None,
        "borrower_id": None,
        "address": None,
        "collect_by": None,
        "reservation_state": "none",
        "loan_id": None,
        "loan_state": "none",
        "notify": "none",
        "loan_borrower_id": None,
        "loan_address": None,
        "waitlist": [],
        "promotion": {"request_id": None, "notify": "none", "wait_id": None},
        "expired_reservations": [],
        "promotion_from_loan_id": None,
    }


def _normalize_item(item: Mapping[str, Any]) -> dict[str, Any]:
    value = _copy(item)
    defaults = _empty_item()
    for key, default in defaults.items():
        if key not in value:
            value[key] = _copy(default)
    if not isinstance(value.get("waitlist"), list):
        value["waitlist"] = []
    if not isinstance(value.get("expired_reservations"), list):
        value["expired_reservations"] = []
    if not isinstance(value.get("promotion"), Mapping):
        value["promotion"] = _copy(defaults["promotion"])
    else:
        promotion = _copy(value["promotion"])
        for key, default in defaults["promotion"].items():
            promotion.setdefault(key, default)
        value["promotion"] = promotion
    return value


def _new_state(state: Mapping[str, Any]) -> dict[str, Any]:
    value = _copy(state)
    value.setdefault("items", {})
    value.setdefault("used_ids", [])
    value["used_ids"] = list(value["used_ids"])
    value["items"] = {str(item_id): _normalize_item(item) for item_id, item in value["items"].items()}
    return value


def _remember(state: dict[str, Any], value: str) -> None:
    if value not in state["used_ids"]:
        state["used_ids"].append(value)


def _event(action: str, state: Mapping[str, Any], **meta: Any) -> Decision:
    payload = {"action": action, "state": _copy(state)}
    payload.update(meta)
    return Decision.emit(DomainEvent("desk." + action, 2, payload))


def _expire_and_promote(item: dict[str, Any], now_i: int) -> bool:
    old_reservation = item.get("reservation_id")
    if old_reservation is not None and old_reservation not in item["expired_reservations"]:
        item["expired_reservations"].append(old_reservation)
    waitlist = item["waitlist"]
    if waitlist:
        waiter = waitlist.pop(0)
        wait_id = waiter["wait_id"]
        item.update({
            "availability": "reserved",
            "reservation_id": wait_id,
            "borrower_id": waiter["borrower_id"],
            "address": waiter["address"],
            "collect_by": now_i + waiter["hold_seconds"],
            "reservation_state": "active",
            "promotion": {"request_id": wait_id, "notify": "attempt_saved", "wait_id": wait_id},
            "promotion_from_loan_id": item.get("loan_id") if item.get("loan_state") == "returned" else None,
        })
        return True
    item.update({"availability": "available", "reservation_state": "expired"})
    return False




class DeskReducer:
    identity = ReducerIdentity(
        "equipment_loan_desk", 2, "0" * 64, "0" * 64, "0" * 64
    )

    def initial_state(self) -> Any:
        return {"items": {}, "used_ids": []}

    def decide(self, state: Any, observation: Any, effect: Any, command: Any) -> Any:
        del observation, effect
        if not isinstance(command, Mapping):
            return _diag("bad_args")
        name = command.get("name")
        args = _args(command)
        current = _new_state(state)
        items = current["items"]

        if name == "add_item":
            item_id = args.get("item_id")
            if not _valid_id(item_id):
                return _diag("bad_args")
            if item_id in _ids(current):
                return _diag("id_in_use")
            items[item_id] = _empty_item()
            _remember(current, item_id)
            return _event("add_item", current)

        item_id = args.get("item_id")
        if name in {"wait", "reserve", "expire", "checkout", "return", "promotion_commit"} and not _valid_id(item_id):
            return _diag("bad_args")
        if name in {"wait", "reserve", "expire", "checkout", "return", "promotion_commit"} and item_id not in items:
            return _diag("unknown_item")

        if name == "wait":
            wait_id = args.get("wait_id")
            borrower_id = args.get("borrower_id")
            address = args.get("address")
            hold_seconds = args.get("hold_seconds")
            now = args.get("now")
            if not (_valid_id(wait_id) and _valid_id(borrower_id) and _valid_address(address) and _valid_hold(hold_seconds) and _valid_time(now)):
                return _diag("bad_args")
            item = items[item_id]
            if item["availability"] == "available":
                return _diag("not_needed")
            if wait_id in _ids(current):
                return _diag("id_in_use")
            if borrower_id == item.get("borrower_id") or any(w.get("borrower_id") == borrower_id for w in item["waitlist"]):
                return _diag("already_waiting")
            item["waitlist"].append({
                "wait_id": wait_id,
                "borrower_id": borrower_id,
                "address": address,
                "hold_seconds": int(hold_seconds),
            })
            _remember(current, wait_id)
            return _event("wait", current)

        if name == "reserve":
            reservation_id = args.get("reservation_id")
            borrower_id = args.get("borrower_id")
            address = args.get("address")
            collect_by = args.get("collect_by")
            now = args.get("now")
            if not all((_valid_id(reservation_id), _valid_id(borrower_id), _valid_address(address), _valid_time(collect_by), _valid_time(now))):
                return _diag("bad_args")
            now_i, collect_i = int(now), int(collect_by)
            if collect_i <= now_i:
                return _diag("bad_args")
            if reservation_id in _ids(current):
                return _diag("id_in_use")
            item = items[item_id]
            if item["availability"] == "checked_out" or (item["availability"] == "reserved" and item["reservation_state"] == "active" and now_i < item["collect_by"]):
                return _diag("not_available")
            if item["availability"] == "reserved" and item["reservation_state"] == "active" and now_i >= item["collect_by"]:
                if item["promotion"]["notify"] == "attempt_saved":
                    return _diag("not_available")
                promoted = _expire_and_promote(item, now_i)
                if promoted:
                    return _event("reserve_expire_promote", current, error="not_available")
            if item["availability"] != "available":
                return _diag("not_available")
            item.update({
                "availability": "reserved",
                "reservation_id": reservation_id,
                "borrower_id": borrower_id,
                "address": address,
                "collect_by": collect_i,
                "reservation_state": "active",
                "promotion_from_loan_id": None,
            })
            _remember(current, reservation_id)
            return _event("reserve", current)

        if name == "expire":
            now = args.get("now")
            if not _valid_time(now):
                return _diag("bad_args")
            now_i = int(now)
            item = items[item_id]
            if item["promotion"]["notify"] == "attempt_saved" and item["availability"] == "reserved":
                return Decision.noop()
            if item["availability"] == "reserved" and item["reservation_state"] == "active" and now_i >= item["collect_by"]:
                promoted = _expire_and_promote(item, now_i)
                return _event("expire_promote" if promoted else "expire", current)
            return Decision.noop()

        if name == "checkout":
            reservation_id = args.get("reservation_id")
            loan_id = args.get("loan_id")
            now = args.get("now")
            if not (_valid_id(reservation_id) and _valid_id(loan_id) and _valid_time(now)):
                return _diag("bad_args")
            now_i = int(now)
            item = items[item_id]
            if item["availability"] == "checked_out":
                return _diag("already_checked_out")
            if item["availability"] == "reserved" and item["reservation_state"] == "active" and now_i >= item["collect_by"]:
                if item["promotion"]["notify"] == "attempt_saved":
                    return Decision.noop()
                promoted = _expire_and_promote(item, now_i)
                return _event("checkout_expire_promote" if promoted else "checkout_expire", current, error="expired")
            if item["reservation_state"] == "expired" or reservation_id in item["expired_reservations"]:
                return Decision.noop() if reservation_id in item["expired_reservations"] else _diag("expired")
            if item["reservation_state"] != "active":
                return _diag("not_reserved")
            if item["reservation_id"] != reservation_id:
                return _diag("reservation_mismatch")
            existing_loan = item["loan_id"]
            if item["loan_state"] == "attempt_saved":
                if existing_loan != loan_id:
                    return _diag("checkout_in_progress")
                return Decision.noop()
            if existing_loan is not None and existing_loan != loan_id:
                return _diag("checkout_in_progress")
            if loan_id in _ids(current) and loan_id != existing_loan:
                return _diag("id_in_use")
            item.update({
                "loan_id": loan_id,
                "loan_state": "attempt_saved",
                "notify": "attempt_saved",
                "loan_borrower_id": item["borrower_id"],
                "loan_address": item["address"],
            })
            _remember(current, loan_id)
            return _event("checkout_attempt", current, attempt=True)

        if name == "checkout_commit":
            loan_id = args.get("loan_id")
            if not _valid_id(item_id) or not _valid_id(loan_id):
                return _diag("bad_args")
            item = items[item_id]
            if item["loan_id"] != loan_id or item["loan_state"] != "attempt_saved":
                return _diag("not_reserved")
            item.update({"availability": "checked_out", "reservation_state": "collected", "loan_state": "checked_out", "notify": "sent"})
            return _event("checkout_commit", current)

        if name == "promotion_commit":
            request_id = args.get("request_id")
            if not _valid_id(request_id):
                return _diag("bad_args")
            item = items[item_id]
            if item["promotion"].get("request_id") != request_id or item["promotion"].get("notify") != "attempt_saved":
                return _diag("conflict")
            item["promotion"]["notify"] = "sent"
            return _event("promotion_commit", current)

        if name == "return":
            loan_id = args.get("loan_id")
            now = args.get("now")
            if not (_valid_id(loan_id) and _valid_time(now)):
                return _diag("bad_args")
            item = items[item_id]
            if item["availability"] != "checked_out":
                if item["promotion"]["notify"] == "attempt_saved" and item.get("promotion_from_loan_id") == loan_id and item["loan_state"] == "returned":
                    return Decision.noop()
                return _diag("not_checked_out")
            if item["loan_id"] != loan_id:
                return _diag("loan_mismatch")
            item.update({"availability": "available", "loan_state": "returned"})
            if item["waitlist"]:
                _expire_and_promote(item, int(now))
            return _event("return_promote" if item["promotion"]["notify"] == "attempt_saved" else "return", current)

        return _diag("bad_args")

    def apply(self, state: Any, event: DomainEvent) -> Any:
        del state
        payload = _copy(event.payload)
        return ApplyOutcome.new(payload["state"])
