# Equipment loan desk

The desk uses the supplied Ikaros runtime for its durable aggregate and lifecycle
transitions. The aggregate is stored as `desk.sqlite` inside `STATE_DIR`; other
files in that directory are not touched.

## Setup

From this directory (with the supplied `KIT/` intact):

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
chmod +x run
```

No npm package or network access is required. `run` locates the local virtual
environment and `KIT/bin/ik` by project-relative paths. Set `IK_BINARY` only if
you need to override that binary.
Waiters are stored in join order. Returning a checked-out item or expiring a
reservation promotes the head and sends one `waitlist_ready` notification; the
request id is the wait id, and `reconcile <wait_id>` resolves an uncertain send.

## Running

Set `STATE_DIR` and `SERVICE_URL` for every invocation. `CRASH_AT` is optional.
The commands and JSON result shapes are specified in `BRIEF.md`.

```sh
export STATE_DIR="$PWD/.state"
export SERVICE_URL="http://127.0.0.1:48600"
./run add-item camera-1
./run reserve camera-1 reservation-1 borrower-1 borrower@example.com 100 10
./run checkout camera-1 reservation-1 loan-1 20
./run status camera-1 20
./run return camera-1 loan-1 21
./run wait camera-1 wait-1 next-borrower next@example.com 3600 21

```
`SERVICE_URL` is the base URL without a trailing slash. The desk does not read
the wall clock. A checkout attempt is persisted before its HTTP request, and
`reconcile` resolves a lost reply by lookup without posting again.

## Scoped tests

After setup, run the deterministic local test program:

```sh
.venv/bin/python tests/test_desk.py
```

The test service binds only to `127.0.0.1:48601`.
