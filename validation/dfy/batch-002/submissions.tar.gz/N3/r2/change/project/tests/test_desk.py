#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PORT = 48601


class MailState:
    def __init__(self):
        self.messages = {}
        self.posts = []
        self.drop_next = False
        self.lock = threading.Lock()


class MailHandler(BaseHTTPRequestHandler):
    state = None

    def _send(self, status, body):
        raw = json.dumps(body, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        prefix = "/v1/requests/"
        if not self.path.startswith(prefix):
            self._send(404, {"error": "not_found"})
            return
        with self.state.lock:
            body = self.state.messages.get(self.path[len(prefix):])
        self._send(200, body) if body else self._send(404, {"error": "not_found"})

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(length))
        with self.state.lock:
            self.state.posts.append(body["request_id"])
            old = self.state.messages.get(body["request_id"])
            accepted = dict(body, outcome="accepted")
            if old and old != accepted:
                self._send(409, {"error": "conflict"})
                return
            self.state.messages[body["request_id"]] = accepted
            drop = self.state.drop_next
            self.state.drop_next = False
        if drop:
            self.connection.shutdown(1)
            self.connection.close()
            return
        self._send(200, accepted)

    def log_message(self, *args):
        return


class DeskTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mail = MailState()
        MailHandler.state = cls.mail
        cls.server = ThreadingHTTPServer(("127.0.0.1", PORT), MailHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def setUp(self):
        self.state = Path(tempfile.mkdtemp(prefix="desk-test-"))
        self.env = os.environ.copy()
        self.env.update({"STATE_DIR": str(self.state), "SERVICE_URL": f"http://127.0.0.1:{PORT}", "CRASH_AT": ""})

    def tearDown(self):
        shutil.rmtree(self.state, ignore_errors=True)

    def call(self, *args, crash=""):
        env = dict(self.env, CRASH_AT=crash)
        return subprocess.run([str(ROOT / "run"), *args], env=env, text=True, capture_output=True)

    def ok(self, *args, crash=""):
        result = self.call(*args, crash=crash)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        return json.loads(result.stdout)

    def refused(self, *args, crash=""):
        result = self.call(*args, crash=crash)
        self.assertNotEqual(result.returncode, 0)
        return json.loads(result.stdout)

    def test_restart_expiry_and_checkout(self):
        self.ok("add-item", "item-a")
        self.ok("add-item", "item-b")
        self.ok("reserve", "item-a", "res-a", "borrower-a", "a@example.com", "20", "10")
        self.assertEqual(self.ok("status", "item-a", "10")["reservation_state"], "active")
        self.assertEqual(self.ok("status", "item-b", "10")["availability"], "available")
        self.assertTrue(self.ok("expire", "item-a", "20")["expired"])
        self.assertEqual(self.refused("checkout", "item-a", "res-a", "loan-a", "20")["error"], "expired")
        self.ok("reserve", "item-a", "res-b", "borrower-b", "b@example.com", "40", "20")
        self.ok("checkout", "item-a", "res-b", "loan-b", "21")
        with self.mail.lock:
            self.assertEqual(self.mail.posts.count("loan-b"), 1)

    def test_crash_labels_and_recovery(self):
        self.ok("add-item", "item-c")
        self.ok("reserve", "item-c", "res-c", "borrower-c", "c@example.com", "100", "1")
        result = self.call("checkout", "item-c", "res-c", "loan-c", "2", crash="after-attempt-saved-before-request")
        self.assertEqual(result.returncode, -signal.SIGKILL)
        self.assertEqual(self.ok("status", "item-c", "2")["loan_state"], "attempt_saved")
        self.assertEqual(self.refused("checkout", "item-c", "res-c", "loan-other", "2")["error"], "checkout_in_progress")
        self.ok("checkout", "item-c", "res-c", "loan-c", "2")

        self.ok("add-item", "item-d")
        self.ok("reserve", "item-d", "res-d", "borrower-d", "d@example.com", "100", "1")
        result = self.call("checkout", "item-d", "res-d", "loan-d", "2", crash="after-record-before-exit")
        self.assertEqual(result.returncode, -signal.SIGKILL)
        self.assertEqual(self.ok("status", "item-d", "2")["notify"], "sent")

    def test_lost_reply_reconcile(self):
        self.ok("add-item", "item-e")
        self.ok("reserve", "item-e", "res-e", "borrower-e", "e@example.com", "100", "1")
        with self.mail.lock:
            self.mail.drop_next = True
        result = self.call("checkout", "item-e", "res-e", "loan-e", "2")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(json.loads(result.stdout)["error"], "service_unavailable")
        self.assertEqual(self.ok("status", "item-e", "2")["loan_state"], "attempt_saved")
        self.assertEqual(self.ok("reconcile", "loan-e")["notify"], "sent")
        with self.mail.lock:
            self.assertEqual(self.mail.posts.count("loan-e"), 1)
    def test_return_promotes_head_once(self):
        self.ok("add-item", "item-w")
        self.ok("reserve", "item-w", "res-w", "borrower-w", "w@example.com", "100", "1")
        self.ok("checkout", "item-w", "res-w", "loan-w", "2")
        self.ok("wait", "item-w", "wait-w1", "borrower-w1", "w1@example.com", "5", "2")
        self.ok("wait", "item-w", "wait-w2", "borrower-w2", "w2@example.com", "7", "2")
        result = self.ok("return", "item-w", "loan-w", "30")
        self.assertEqual(result["availability"], "reserved")
        self.assertEqual(result["promoted_wait_id"], "wait-w1")
        status = self.ok("status", "item-w", "30")
        self.assertEqual(status["reservation_id"], "wait-w1")
        self.assertEqual(status["collect_by"], 35)
        self.assertEqual([entry["wait_id"] for entry in status["waitlist"]], ["wait-w2"])
        with self.mail.lock:
            self.assertEqual(self.mail.posts.count("wait-w1"), 1)
        self.assertEqual(self.refused("return", "item-w", "loan-w", "31")["error"], "not_checked_out")

    def test_expiry_promotes_and_chains(self):
        self.ok("add-item", "item-x")
        self.ok("reserve", "item-x", "res-x", "borrower-x", "x@example.com", "10", "1")
        self.ok("wait", "item-x", "wait-x1", "borrower-x1", "x1@example.com", "5", "1")
        self.ok("wait", "item-x", "wait-x2", "borrower-x2", "x2@example.com", "6", "1")
        first = self.ok("expire", "item-x", "10")
        self.assertEqual(first["promoted_wait_id"], "wait-x1")
        self.assertEqual(self.ok("status", "item-x", "10")["collect_by"], 15)
        self.assertEqual(self.ok("expire", "item-x", "14")["expired"], False)
        second = self.ok("expire", "item-x", "15")
        self.assertEqual(second["promoted_wait_id"], "wait-x2")
        with self.mail.lock:
            self.assertEqual(self.mail.posts.count("wait-x1"), 1)
            self.assertEqual(self.mail.posts.count("wait-x2"), 1)

    def test_promotion_lost_reply_reconciles(self):
        self.ok("add-item", "item-y")
        self.ok("reserve", "item-y", "res-y", "borrower-y", "y@example.com", "100", "1")
        self.ok("checkout", "item-y", "res-y", "loan-y", "2")
        self.ok("wait", "item-y", "wait-y", "borrower-y2", "y2@example.com", "5", "2")
        with self.mail.lock:
            self.mail.drop_next = True
        result = self.call("return", "item-y", "loan-y", "3")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(json.loads(result.stdout)["error"], "service_unavailable")
        self.assertEqual(self.ok("status", "item-y", "3")["promotion"]["notify"], "attempt_saved")
        self.assertEqual(self.ok("reconcile", "wait-y")["notify"], "sent")
        with self.mail.lock:
            self.assertEqual(self.mail.posts.count("wait-y"), 1)


    def test_promotion_crash_before_request_recovers_on_return(self):
        self.ok("add-item", "item-z1")
        self.ok("reserve", "item-z1", "res-z1", "borrower-z1", "z1@example.com", "100", "1")
        self.ok("checkout", "item-z1", "res-z1", "loan-z1", "2")
        self.ok("wait", "item-z1", "wait-z1", "borrower-z2", "z2@example.com", "5", "2")
        result = self.call("return", "item-z1", "loan-z1", "3", crash="after-attempt-saved-before-request")
        self.assertEqual(result.returncode, -signal.SIGKILL)
        self.assertEqual(self.ok("status", "item-z1", "3")["promotion"]["notify"], "attempt_saved")
        with self.mail.lock:
            self.assertEqual(self.mail.posts.count("wait-z1"), 0)
        self.ok("return", "item-z1", "loan-z1", "4")
        with self.mail.lock:
            self.assertEqual(self.mail.posts.count("wait-z1"), 1)

    def test_promotion_crash_after_accept_reconciles(self):
        self.ok("add-item", "item-z3")
        self.ok("reserve", "item-z3", "res-z3", "borrower-z3", "z3@example.com", "100", "1")
        self.ok("checkout", "item-z3", "res-z3", "loan-z3", "2")
        self.ok("wait", "item-z3", "wait-z3", "borrower-z4", "z4@example.com", "5", "2")
        result = self.call("return", "item-z3", "loan-z3", "3", crash="after-accept-before-record")
        self.assertEqual(result.returncode, -signal.SIGKILL)
        self.assertEqual(self.ok("reconcile", "wait-z3")["notify"], "sent")
        with self.mail.lock:
            self.assertEqual(self.mail.posts.count("wait-z3"), 1)

    def test_promotion_crash_after_record_is_idempotent(self):
        self.ok("add-item", "item-z5")
        self.ok("reserve", "item-z5", "res-z5", "borrower-z5", "z5@example.com", "100", "1")
        self.ok("checkout", "item-z5", "res-z5", "loan-z5", "2")
        self.ok("wait", "item-z5", "wait-z5", "borrower-z6", "z6@example.com", "5", "2")
        result = self.call("return", "item-z5", "loan-z5", "3", crash="after-record-before-exit")
        self.assertEqual(result.returncode, -signal.SIGKILL)
        self.assertEqual(self.ok("status", "item-z5", "3")["promotion"]["notify"], "sent")
        self.assertEqual(self.refused("return", "item-z5", "loan-z5", "4")["error"], "not_checked_out")
        with self.mail.lock:
            self.assertEqual(self.mail.posts.count("wait-z5"), 1)
    def test_checkout_due_promotes_without_checkout_mail(self):
        self.ok("add-item", "item-q")
        self.ok("reserve", "item-q", "res-q", "borrower-q", "q@example.com", "10", "1")
        self.ok("wait", "item-q", "wait-q", "borrower-q2", "q2@example.com", "5", "1")
        self.assertEqual(self.refused("checkout", "item-q", "res-q", "loan-q", "10")["error"], "expired")
        status = self.ok("status", "item-q", "10")
        self.assertEqual(status["reservation_id"], "wait-q")
        with self.mail.lock:
            self.assertEqual(self.mail.posts.count("wait-q"), 1)
            self.assertEqual(self.mail.posts.count("loan-q"), 0)


if __name__ == "__main__":
    unittest.main()
