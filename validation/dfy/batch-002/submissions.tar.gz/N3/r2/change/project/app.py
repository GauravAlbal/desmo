#!/usr/bin/env python3
"""Equipment loan desk command line application."""
from __future__ import annotations

import http.client
import json
import os
import signal
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Mapping, Optional

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
os.environ["PYTHONPATH"] = str(ROOT) + os.pathsep + os.environ.get("PYTHONPATH", "")

from desk_reducer import _valid_address, _valid_hold, _valid_id, _valid_time  # noqa: E402
from invariant_kernel import Kernel, KernelError  # noqa: E402


class DeskError(Exception):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


class ServiceResult:
    def __init__(self, status: int, body: Any) -> None:
        self.status = status
        self.body = body


def _binary() -> str:
    configured = os.environ.get("IK_BINARY")
    return configured if configured else str(ROOT / "KIT" / "bin" / "ik")


def _python() -> str:
    candidate = ROOT / ".venv" / "bin" / "python"
    return str(candidate if candidate.exists() else Path(sys.executable))


def _store_path() -> Path:
    state_dir = os.environ.get("STATE_DIR")
    if not state_dir:
        raise DeskError("bad_args")
    path = Path(state_dir)
    path.mkdir(parents=True, exist_ok=True)
    return path / "desk.sqlite"


def _machine(store: Path):
    kernel = Kernel(str(store), binary=_binary())
    return kernel, kernel.reducer("desk_reducer:DeskReducer", python=_python())


def _load() -> tuple[Any, Any, Any]:
    store = _store_path()
    if not store.exists():
        return None, None, None
    kernel, machine = _machine(store)
    try:
        return kernel, machine, machine.show("desk")
    except KernelError as exc:
        if exc.code in {"IK_ILLEGAL_STATE", "aggregate.not_found", "not_found"}:
            return kernel, machine, None
        raise


def _ensure() -> tuple[Any, Any, Any]:
    store = _store_path()
    kernel, machine, aggregate = _load()
    if aggregate is None:
        if kernel is None:
            kernel, machine = _machine(store)
        aggregate = machine.create("desk")
    return kernel, machine, aggregate


_ERRORS = {
    "bad_args", "unknown_item", "id_in_use", "not_available", "not_reserved",
    "reservation_mismatch", "expired", "already_checked_out", "checkout_in_progress",
    "not_checked_out", "loan_mismatch", "service_unavailable", "conflict",
    "not_needed", "already_waiting",
}


def _execute(machine: Any, aggregate: Any, name: str, args: Mapping[str, Any]) -> Any:
    try:
        return aggregate.execute({"name": name, "args": dict(args)})
    except KernelError as exc:
        code = getattr(exc, "diagnostic", None)
        if isinstance(code, Mapping):
            code = code.get("code")
        if isinstance(code, str) and code in _ERRORS:
            raise DeskError(code)
        if exc.code in _ERRORS:
            raise DeskError(exc.code)
        raise


def _item(aggregate: Any, item_id: str) -> Mapping[str, Any]:
    item = aggregate.state.get("items", {}).get(item_id)
    if item is None:
        raise DeskError("unknown_item")
    return item


def _crash(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


def _json_body(data: bytes) -> Any:
    try:
        return json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None


def _request(method: str, url: str, payload: Optional[Mapping[str, Any]] = None) -> ServiceResult:
    body = None
    headers = {}
    if payload is not None:
        body = json.dumps(dict(payload), separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            raw = response.read()
            return ServiceResult(response.status, _json_body(raw))
    except urllib.error.HTTPError as exc:
        try:
            raw = exc.read()
        except Exception:
            raw = b""
        return ServiceResult(exc.code, _json_body(raw))
    except (http.client.HTTPException, OSError, TimeoutError, ValueError):
        raise DeskError("service_unavailable")


def _service_url() -> str:
    value = os.environ.get("SERVICE_URL")
    if not value or value.endswith("/"):
        raise DeskError("service_unavailable")
    return value


def _checkout_payload(item_id: str, item: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "request_id": item["loan_id"],
        "item_id": item_id,
        "borrower_id": item.get("loan_borrower_id") or item["borrower_id"],
        "address": item.get("loan_address") or item["address"],
        "kind": "checkout",
    }


def _promotion_payload(item_id: str, item: Mapping[str, Any]) -> dict[str, Any]:
    promotion = item.get("promotion", {})
    return {
        "request_id": promotion.get("request_id"),
        "item_id": item_id,
        "borrower_id": item["borrower_id"],
        "address": item["address"],
        "kind": "waitlist_ready",
    }


def _matches(payload: Mapping[str, Any], body: Any) -> bool:
    return isinstance(body, Mapping) and body.get("outcome") == "accepted" and all(body.get(k) == v for k, v in payload.items())


def _send_promotion(item_id: str, aggregate: Any, machine: Any, first_attempt: bool = False) -> tuple[Any, bool]:
    item = _item(aggregate, item_id)
    promotion = item.get("promotion", {})
    if promotion.get("notify") == "sent":
        return aggregate, False
    if promotion.get("notify") != "attempt_saved":
        return aggregate, False
    if first_attempt:
        _crash("after-attempt-saved-before-request")
    payload = _promotion_payload(item_id, item)
    base = _service_url()
    lookup = _request("GET", base + "/v1/requests/" + str(payload["request_id"]))
    if lookup.status == 200:
        if not _matches(payload, lookup.body):
            raise DeskError("conflict")
    elif lookup.status == 404:
        post = _request("POST", base + "/v1/messages", payload)
        if post.status == 409:
            raise DeskError("conflict")
        if post.status != 200 or not _matches(payload, post.body) or not isinstance(post.body, Mapping) or post.body.get("outcome") != "accepted":
            raise DeskError("service_unavailable")
        _crash("after-accept-before-record")
    else:
        raise DeskError("service_unavailable")
    current = _execute(machine, aggregate, "promotion_commit", {"item_id": item_id, "request_id": payload["request_id"]})
    _crash("after-record-before-exit")
    return current, True


def _checkout(item_id: str, reservation_id: str, loan_id: str, now: str) -> dict[str, Any]:
    if not (_valid_id(item_id) and _valid_id(reservation_id) and _valid_id(loan_id) and _valid_time(now)):
        raise DeskError("bad_args")
    _, machine, aggregate = _load()
    if aggregate is None:
        raise DeskError("unknown_item")
    before = _item(aggregate, item_id)
    now_i = int(now)
    expired_path = (
        reservation_id in before.get("expired_reservations", [])
        or before.get("reservation_state") == "expired"
        or (before.get("availability") == "reserved" and before.get("reservation_state") == "active" and now_i >= before.get("collect_by"))
    )
    first_promotion = before.get("promotion", {}).get("notify") != "attempt_saved"
    result = _execute(machine, aggregate, "checkout", {"item_id": item_id, "reservation_id": reservation_id, "loan_id": loan_id, "now": now})
    current_item = _item(result, item_id)
    if expired_path:
        if current_item.get("promotion", {}).get("notify") == "attempt_saved":
            _send_promotion(item_id, result, machine, first_attempt=first_promotion)
        raise DeskError("expired")
    if before.get("loan_state") != "attempt_saved" and current_item.get("loan_state") == "attempt_saved":
        _crash("after-attempt-saved-before-request")
    if current_item.get("loan_state") == "checked_out" and current_item.get("notify") == "sent":
        raise DeskError("already_checked_out")
    payload = _checkout_payload(item_id, current_item)
    lookup = _request("GET", _service_url() + "/v1/requests/" + str(payload["request_id"]))
    if lookup.status == 200:
        if not _matches(payload, lookup.body):
            raise DeskError("conflict")
    elif lookup.status == 404:
        post = _request("POST", _service_url() + "/v1/messages", payload)
        if post.status == 409:
            raise DeskError("conflict")
        if post.status != 200 or not _matches(payload, post.body) or not isinstance(post.body, Mapping) or post.body.get("outcome") != "accepted":
            raise DeskError("service_unavailable")
        _crash("after-accept-before-record")
    else:
        raise DeskError("service_unavailable")
    committed = _execute(machine, result, "checkout_commit", {"item_id": item_id, "loan_id": current_item["loan_id"]})
    outcome = _item(committed, item_id)
    _crash("after-record-before-exit")
    return {
        "item_id": item_id, "reservation_id": outcome["reservation_id"], "loan_id": outcome["loan_id"],
        "borrower_id": outcome["borrower_id"], "address": outcome["address"],
        "availability": outcome["availability"], "notify": outcome["notify"],
        "request_id": outcome["loan_id"], "now": now_i,
    }


def _wait(item_id: str, wait_id: str, borrower_id: str, address: str, hold_seconds: str, now: str) -> dict[str, Any]:
    if not (_valid_id(item_id) and _valid_id(wait_id) and _valid_id(borrower_id) and _valid_address(address) and _valid_hold(hold_seconds) and _valid_time(now)):
        raise DeskError("bad_args")
    _, machine, aggregate = _load()
    if aggregate is None:
        raise DeskError("unknown_item")
    result = _execute(machine, aggregate, "wait", {"item_id": item_id, "wait_id": wait_id, "borrower_id": borrower_id, "address": address, "hold_seconds": hold_seconds, "now": now})
    item = _item(result, item_id)
    return {"item_id": item_id, "wait_id": wait_id, "borrower_id": borrower_id, "address": address, "hold_seconds": int(hold_seconds), "position": len(item.get("waitlist", [])), "availability": item["availability"], "now": int(now)}


def _reserve(item_id: str, reservation_id: str, borrower_id: str, address: str, collect_by: str, now: str) -> dict[str, Any]:
    if not (_valid_id(item_id) and _valid_id(reservation_id) and _valid_id(borrower_id) and _valid_address(address) and _valid_time(collect_by) and _valid_time(now) and int(collect_by) > int(now)):
        raise DeskError("bad_args")
    _, machine, aggregate = _load()
    if aggregate is None:
        raise DeskError("unknown_item")
    before = _item(aggregate, item_id)
    due_with_waiters = before.get("availability") == "reserved" and before.get("reservation_state") == "active" and int(now) >= before.get("collect_by") and bool(before.get("waitlist"))
    first_promotion = before.get("promotion", {}).get("notify") != "attempt_saved"
    result = _execute(machine, aggregate, "reserve", {"item_id": item_id, "reservation_id": reservation_id, "borrower_id": borrower_id, "address": address, "collect_by": collect_by, "now": now})
    item = _item(result, item_id)
    if due_with_waiters and item.get("promotion", {}).get("notify") == "attempt_saved":
        _send_promotion(item_id, result, machine, first_attempt=first_promotion)
        raise DeskError("not_available")
    return {"item_id": item_id, "reservation_id": item["reservation_id"], "borrower_id": item["borrower_id"], "address": item["address"], "collect_by": item["collect_by"], "availability": item["availability"], "now": int(now)}


def _expire(item_id: str, now: str) -> dict[str, Any]:
    if not (_valid_id(item_id) and _valid_time(now)):
        raise DeskError("bad_args")
    _, machine, aggregate = _load()
    if aggregate is None:
        raise DeskError("unknown_item")
    before = _item(aggregate, item_id)
    due = before.get("availability") == "reserved" and before.get("reservation_state") == "active" and int(now) >= before.get("collect_by")
    first_promotion = before.get("promotion", {}).get("notify") != "attempt_saved"
    result = _execute(machine, aggregate, "expire", {"item_id": item_id, "now": now})
    item = _item(result, item_id)
    promoted = item.get("promotion", {}).get("notify") == "attempt_saved" and (due or before.get("promotion", {}).get("notify") == "attempt_saved")
    committed = False
    if promoted:
        result, committed = _send_promotion(item_id, result, machine, first_attempt=first_promotion)
        item = _item(result, item_id)
    return {
        "item_id": item_id, "availability": item["availability"], "expired": bool(due),
        "reservation_id": item["reservation_id"], "promoted_wait_id": item.get("promotion", {}).get("wait_id") if promoted else None,
        "notify": "sent" if committed or (promoted and item.get("promotion", {}).get("notify") == "sent") else "none", "now": int(now),
    }


def _return(item_id: str, loan_id: str, now: str) -> dict[str, Any]:
    if not (_valid_id(item_id) and _valid_id(loan_id) and _valid_time(now)):
        raise DeskError("bad_args")
    _, machine, aggregate = _load()
    if aggregate is None:
        raise DeskError("unknown_item")
    before = _item(aggregate, item_id)
    was_checked_out = before.get("availability") == "checked_out"
    continuation = before.get("promotion", {}).get("notify") == "attempt_saved" and before.get("promotion_from_loan_id") == loan_id
    first_promotion = before.get("promotion", {}).get("notify") != "attempt_saved"
    result = _execute(machine, aggregate, "return", {"item_id": item_id, "loan_id": loan_id, "now": now})
    item = _item(result, item_id)
    promoted = item.get("promotion", {}).get("notify") == "attempt_saved" and (was_checked_out or continuation)
    committed = False
    if promoted:
        result, committed = _send_promotion(item_id, result, machine, first_attempt=first_promotion)
        item = _item(result, item_id)
    return {
        "item_id": item_id, "loan_id": item["loan_id"], "availability": item["availability"], "loan_state": item["loan_state"],
        "promoted_wait_id": item.get("promotion", {}).get("wait_id") if promoted else None,
        "notify": "sent" if committed or (promoted and item.get("promotion", {}).get("notify") == "sent") else None,
        "now": int(now),
    } if promoted else {
        "item_id": item_id, "loan_id": item["loan_id"], "availability": item["availability"], "loan_state": item["loan_state"],
        "promoted_wait_id": None, "now": int(now),
    }


def _status(item_id: str, now: str) -> dict[str, Any]:
    if not (_valid_id(item_id) and _valid_time(now)):
        raise DeskError("bad_args")
    _, _, aggregate = _load()
    if aggregate is None:
        raise DeskError("unknown_item")
    item = _item(aggregate, item_id)
    now_i = int(now)
    past = item.get("reservation_state") == "expired" or (item.get("reservation_state") == "active" and now_i >= item.get("collect_by"))
    promotion = item.get("promotion", {})
    return {
        "item_id": item_id, "availability": item["availability"], "reservation_id": item.get("reservation_id"),
        "borrower_id": item.get("borrower_id"), "address": item.get("address"), "collect_by": item.get("collect_by"),
        "reservation_state": item.get("reservation_state"), "past_deadline": past, "loan_id": item.get("loan_id"),
        "loan_state": item.get("loan_state"), "notify": item.get("notify"), "now": now_i,
        "waitlist": list(item.get("waitlist", [])),
        "promotion": {"request_id": promotion.get("request_id"), "notify": promotion.get("notify", "none"), "wait_id": promotion.get("wait_id")},
    }


def _reconcile(request_id: str) -> dict[str, Any]:
    _, machine, aggregate = _load()
    if aggregate is None:
        return {"request_id": request_id, "loan_id": None, "item_id": None, "kind": None, "notify": "none", "availability": None, "loan_state": "none"}
    for candidate_id, candidate in aggregate.state.get("items", {}).items():
        promotion = candidate.get("promotion", {})
        if promotion.get("request_id") != request_id:
            continue
        if promotion.get("notify") == "sent":
            return {"request_id": request_id, "loan_id": candidate.get("loan_id") if candidate.get("loan_state") == "returned" else None, "item_id": candidate_id, "kind": "waitlist_ready", "notify": "sent", "availability": candidate.get("availability"), "loan_state": candidate.get("loan_state")}
        payload = _promotion_payload(candidate_id, candidate)
        lookup = _request("GET", _service_url() + "/v1/requests/" + request_id)
        if lookup.status == 404:
            return {"request_id": request_id, "loan_id": candidate.get("loan_id") if candidate.get("loan_state") == "returned" else None, "item_id": candidate_id, "kind": "waitlist_ready", "notify": "not_sent", "availability": candidate.get("availability"), "loan_state": candidate.get("loan_state")}
        if lookup.status != 200:
            raise DeskError("service_unavailable")
        if not _matches(payload, lookup.body):
            raise DeskError("conflict")
        committed = _execute(machine, aggregate, "promotion_commit", {"item_id": candidate_id, "request_id": request_id})
        _crash("after-record-before-exit")
        outcome = _item(committed, candidate_id)
        return {"request_id": request_id, "loan_id": outcome.get("loan_id") if outcome.get("loan_state") == "returned" else None, "item_id": candidate_id, "kind": "waitlist_ready", "notify": "sent", "availability": outcome.get("availability"), "loan_state": outcome.get("loan_state")}

    found_id = None
    found = None
    for candidate_id, candidate in aggregate.state.get("items", {}).items():
        if candidate.get("loan_id") == request_id:
            found_id, found = candidate_id, candidate
            break
    if found is None:
        return {"request_id": request_id, "loan_id": None, "item_id": None, "kind": None, "notify": "none", "availability": None, "loan_state": "none"}
    if found.get("notify") == "sent" and found.get("loan_state") in {"checked_out", "returned"}:
        return {"request_id": request_id, "loan_id": request_id, "item_id": found_id, "kind": "checkout", "notify": "sent", "availability": found.get("availability"), "loan_state": found.get("loan_state")}
    payload = _checkout_payload(found_id, found)
    lookup = _request("GET", _service_url() + "/v1/requests/" + request_id)
    if lookup.status == 404:
        return {"request_id": request_id, "loan_id": request_id, "item_id": found_id, "kind": "checkout", "notify": "not_sent", "availability": found.get("availability"), "loan_state": found.get("loan_state")}
    if lookup.status != 200:
        raise DeskError("service_unavailable")
    if not _matches(payload, lookup.body):
        raise DeskError("conflict")
    committed = _execute(machine, aggregate, "checkout_commit", {"item_id": found_id, "loan_id": request_id})
    outcome = _item(committed, found_id)
    _crash("after-record-before-exit")
    return {"request_id": request_id, "loan_id": request_id, "item_id": found_id, "kind": "checkout", "notify": outcome["notify"], "availability": outcome["availability"], "loan_state": outcome["loan_state"]}


def _callback(path: str) -> dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            value = json.load(handle)
    except (OSError, ValueError, TypeError):
        raise DeskError("bad_args")
    required = {"callback_id", "request_id", "item_id", "borrower_id", "address", "kind", "outcome"}
    valid = (
        isinstance(value, Mapping) and required.issubset(value)
        and _valid_id(value.get("callback_id")) and _valid_id(value.get("request_id"))
        and _valid_id(value.get("item_id")) and _valid_id(value.get("borrower_id"))
        and _valid_address(value.get("address")) and value.get("kind") in {"checkout", "waitlist_ready"}
        and value.get("outcome") in {"accepted", "rejected"}
    )
    if not valid:
        raise DeskError("bad_args")
    return {"ok": True}


def _run(argv: list[str]) -> dict[str, Any]:
    if not argv:
        raise DeskError("bad_args")
    command = argv[0]
    if command == "add-item" and len(argv) == 2:
        item_id = argv[1]
        if not _valid_id(item_id):
            raise DeskError("bad_args")
        _, machine, aggregate = _ensure()
        result = _execute(machine, aggregate, "add_item", {"item_id": item_id})
        return {"item_id": item_id, "availability": _item(result, item_id)["availability"], "reservation_id": None, "loan_id": None}
    if command == "reserve" and len(argv) == 7:
        return _reserve(*argv[1:])
    if command == "wait" and len(argv) == 7:
        return _wait(*argv[1:])
    if command == "expire" and len(argv) == 3:
        return _expire(argv[1], argv[2])
    if command == "checkout" and len(argv) == 5:
        return _checkout(*argv[1:])
    if command == "return" and len(argv) == 4:
        return _return(*argv[1:])
    if command == "status" and len(argv) == 3:
        return _status(argv[1], argv[2])
    if command == "reconcile" and len(argv) == 2:
        if not _valid_id(argv[1]):
            raise DeskError("bad_args")
        return _reconcile(argv[1])
    if command == "callback" and len(argv) == 2:
        return _callback(argv[1])
    raise DeskError("bad_args")


def main() -> int:
    try:
        value = _run(sys.argv[1:])
        sys.stdout.write(json.dumps(value, separators=(",", ":")) + "\n")
        return 0
    except DeskError as exc:
        sys.stdout.write(json.dumps({"error": exc.code}, separators=(",", ":")) + "\n")
        return 1
    except (KernelError, OSError, ValueError, TypeError):
        sys.stdout.write(json.dumps({"error": "service_unavailable"}, separators=(",", ":")) + "\n")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
