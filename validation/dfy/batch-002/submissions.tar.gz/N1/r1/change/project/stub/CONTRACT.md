# Payment provider contract

The desk calls this service at `SERVICE_URL` (no trailing slash). The runnable server is `stub/server.mjs`:

```text
node server.mjs
```

It listens on `127.0.0.1` and prints one JSON line on stdout, then serves until killed:

```json
{"service_url":"http://127.0.0.1:PORT","control_url":"http://127.0.0.1:CPORT"}
```

State is in memory for that process only. Restarting the server drops every refund.

## Data plane

### `POST /v1/refunds`

`Content-Type: application/json`

```json
{"refund_id":"...","order_id":"...","amount_cents":1000,"currency":"USD"}
```

`refund_id` and `order_id` match `^[A-Za-z0-9._-]{1,64}$`. `amount_cents` is an integer from 1 to 100000000. `currency` is `USD`.

Responses:

- HTTP 400 `{"error":"bad_request"}` if the body is not JSON or a required field is missing or invalid. Nothing is stored.
- HTTP 500 `{"error":"unavailable"}` when the evaluator has asked for a provider failure. Nothing is stored. This is not a normal response. The running server returns it only under fault injection, described at the end of this file.
- HTTP 200 if this `refund_id` is new, or if it was already accepted with the same order id, amount, and currency:

```json
{"refund_id":"...","order_id":"...","amount_cents":1000,"currency":"USD","outcome":"refunded"}
```

The first acceptance stores the refund and counts one refund effect. A repeat of the same id and the same body returns the stored result and does not count another effect.

- HTTP 409 `{"error":"conflict"}` if this `refund_id` was already accepted with a different order id, amount, or currency. The stored effect is unchanged.

A different `refund_id` always counts as another effect, even if the order id and amount are identical.

### `GET /v1/refunds/<refund_id>`

HTTP 200 with the stored refund object, or HTTP 404 `{"error":"not_found"}` if that id was never accepted.

### `GET /v1/orders/<order_id>/refunds`

HTTP 200:

```json
{"order_id":"...","refunds":[]}
```

`refunds` lists every accepted refund for that order, in acceptance order. An order with none has an empty array, not HTTP 404.

Ids in paths are from `A-Za-z0-9._-`, so they need no extra encoding. Other characters are not part of the desk contract.

## Idempotency and lookup

Identity of an effect is `refund_id`. Lookup by refund id returns the acceptance even when the HTTP client never saw the response. Lookup by order id returns every acceptance for that order, so a second refund id is visible there as a second array entry. `reconcile` is required to lookup the saved refund id and is required not to POST.

A duplicate or conflicting callback does not change a stored refund. The desk has no callback receiver. Callback bodies exist only for the evaluator, on the control port.

