# Paid-order cancellation desk

`./run` is the complete command-line desk. It stores Ikaros' durable SQLite
store at `$STATE_DIR/desk.db`; files already present in `$STATE_DIR` are not
managed or removed. One invocation is one process.

## Setup

This checkout includes the two Ikaros 0.5.0 npm tarballs. With Node 22:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x run
```

The wrapper uses `node` from `PATH` (Node 22 is required). The native Ikaros
binary is provided by the installed platform package. No network access is
needed after the tarballs are available.

## Running

Set `STATE_DIR` for the durable state. Set `SERVICE_URL` for `cancel` and
`reconcile`; local commands do not contact it.

```sh
STATE_DIR=/var/tmp/desk SERVICE_URL=http://127.0.0.1:46500 ./run record order-1 1000
STATE_DIR=/var/tmp/desk SERVICE_URL=http://127.0.0.1:46500 ./run cancel order-1
STATE_DIR=/var/tmp/desk ./run status order-1
STATE_DIR=/var/tmp/desk SERVICE_URL=http://127.0.0.1:46500 ./run reconcile order-1
```

For partial refunds, create a JSON attachment such as
`{"cap_cents":800,"lines":[{"line_id":"sku-a","price_cents":300},{"line_id":"sku-b","price_cents":500}]}`
and run:

```sh
STATE_DIR=/var/tmp/desk ./run attach order-1 lines.json
STATE_DIR=/var/tmp/desk SERVICE_URL=http://127.0.0.1:46500 ./run refund order-1 sku-a
```

`status` includes `cap_cents` and the attached `lines`; line refunds are
submitted as one provider effect per selected line set. An open or uncertain
submission blocks another selection until `reconcile` or a retry resolves it.

Every invocation prints exactly one JSON object. Refusals print `{"error":...}`
and exit nonzero. The supported crash labels are the three labels described in
`BRIEF.md`; they are controlled with `CRASH_AT` and intentionally terminate
with `SIGKILL` at the specified durable boundary.

The lifecycle authority is `order_refund.ik.toml`; `app.mjs` owns argument
validation, HTTP transport, and provider reconciliation but does not replace
the machine transitions.

## Behavior assumptions and limits

* A refund attempt is persisted before a POST and its saved refund id is reused
  for every later lookup or POST.
* A complete accepted response or an accepted lookup is recorded through
  Ikaros before the local command reports `refunded`.
* Provider 404 is the only `not_sent` result. Other transport/status failures
  are `unavailable`; mismatched accepted objects are `conflict`.
* The desk is intentionally single-process as required by the brief; concurrent
  desk invocations are out of scope. It does not use wall-clock timestamps.

The machine's advisory `ik check` is corpus-relative and is not a proof of all
possible HTTP behavior. External provider execution is exercised separately.
