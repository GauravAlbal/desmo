# Change: partial refunds under a per-order cap

The desk you are maintaining already implements the paid-order cancellation brief. Requirements R1 through R14 stay in force for an order that has no line attachment. This change adds line attachments, a per-order refund cap, and a line refund command. It revises `cancel` only for an order that has lines attached.

An open or lost refund submission still counts as the one in-flight submission for that order. It counts against the cap. Another line selection must not be sent until that submission is resolved by lookup. Shipping still blocks a new refund, even when the cap would cover the line. A completed refund still blocks shipping.

## Commands

### `./run attach <order_id> <lines_path>`

Allowed only when the order exists, `shipment` is `open`, `refund` is `none`, and no attempt is saved.

The file is one JSON object:

```json
{"cap_cents":4000,"lines":[{"line_id":"sku-a","price_cents":3000},{"line_id":"sku-b","price_cents":5000}]}
```

`cap_cents` is an integer from 1 to the order amount inclusive. `lines` has 1 to 20 objects. Each `line_id` is 1 to 32 characters from `A-Za-z0-9._-` and is unique in the file. Each `price_cents` is an integer from 1 to 100000000. The sum of `price_cents` must equal the order amount.

Do not contact the provider.

A missing file, a file that is not one JSON object, or a file that breaks those rules is refused with `bad_lines`. The stored order is unchanged.

The first valid attachment is stored. `cap_cents` on the order becomes the file's cap. Each line is stored with `refund` `none`. An identical attachment again (same cap and the same line ids and prices) exits 0 and changes nothing. A different attachment is refused with `conflict` and leaves the stored lines and cap unchanged.

Refuse with `shipped` if the order is shipped. Refuse with `refund_open` if a refund attempt is saved or any refund has been committed. Refuse with `unknown_order` if the order was not recorded.

Success, exit 0:

```json
{"order_id":"...","cap_cents":4000,"lines":[{"line_id":"sku-a","price_cents":3000,"refund":"none"},{"line_id":"sku-b","price_cents":5000,"refund":"none"}]}
```

Changing or deleting the source file after `attach` returns must not change the stored lines or cap.

After this change, `status` always includes `cap_cents` and `lines`. Before attachment, `cap_cents` equals the order amount and `lines` is an empty array. After attachment, `lines` are the stored lines. A line's `refund` is `none`, `pending`, or `refunded`. `pending` means the line is part of the open attempt and has not been adopted. Extra fields already required by the original brief stay required.

### `./run refund <order_id> <line_id> [line_id...]`

Refund the named lines as one provider submission. The amount is the sum of their stored prices. One refund id covers the whole selection.

Refuse, and do not contact the provider, and do not replace a saved attempt, when:

- the order was not recorded: `unknown_order`
- no lines are attached: `not_attached`
- a named line is not on the order, or a line id is repeated in the argument list: `unknown_line`
- the order is shipped and no attempt is saved: `shipped`
- any named line is already `refunded`: `already_refunded`
- an attempt is saved for a different line set: `refund_open`
- no attempt is saved, and `refunded_cents` plus the selection sum is greater than `cap_cents`: `over_cap`

`refund_open` applies even when the new selection would fit under the cap beside the open amount. The open attempt, including one whose reply was lost, is the in-flight submission. It reserves its amount until lookup resolves it. Do not allocate a second refund id while it is open.

If an attempt is already saved for the same line set, keep that refund id and follow the original `cancel` retry rules: lookup, adopt a matching acceptance without POSTing, or POST the saved id only when lookup returns HTTP 404. Do not honor `after-attempt-saved-before-request` on that retry.

If no attempt is saved and the selection is allowed:

1. Commit an attempt with a new refund id, the selection's line ids, and the selection sum. Mark those lines `pending`. Set the order `refund` to `attempt_saved`. Honor `after-attempt-saved-before-request`.
2. POST that refund id and that amount, using the same provider rules as `cancel`. Honor `after-accept-before-record` after the complete response body is read.
3. On a matching HTTP 200, mark those lines `refunded`, add the amount to `refunded_cents`, clear the attempt, and set order `refund` to `refunded`. Honor `after-record-before-exit`.

`refunded` on the order means a submission has been adopted and no attempt is open. It does not mean every line was refunded. `refunded_cents` is the sum of the prices of lines whose `refund` is `refunded`. For an order with no lines, the original meaning of `refunded_cents` is unchanged.

Success, exit 0, uses the same object shape as a successful `cancel`, with `refunded_cents` equal to the adopted total and `refund_id` equal to the id used for this selection.

A lost reply or a kill at `after-accept-before-record` is recovered by `reconcile` or by `refund` of the same line set. Both must reuse the saved refund id. `reconcile` still must not POST.

Crash boundaries from the original brief also apply to `refund`: `after-attempt-saved-before-request` only on the invocation that first commits that attempt, `after-accept-before-record` after a complete refund response body and before the durable outcome, and `after-record-before-exit` after this invocation commits `refunded`.

### Revised `cancel` when lines are attached

R4's full-amount rule applies only when the order has no line attachment. When lines are attached, `cancel` no longer refunds the original order amount blindly.

- If an attempt is open, `cancel` continues that saved attempt (lookup, then POST only on HTTP 404). It does not add lines that are not in the saved attempt, and it does not allocate a new refund id.
- If no attempt is open and every line is `refunded`, `cancel` exits 0, does not contact the provider, and does not add an effect. `refund_id` and `refunded_cents` stay as they were.
- If no attempt is open and some lines are not `refunded`, and the order is shipped, `cancel` is refused with `shipped`. It does not contact the provider.
- If no attempt is open and the sum of the not-yet-refunded lines plus `refunded_cents` is greater than `cap_cents`, `cancel` is refused with `over_cap`. It does not submit a subset of those lines, and it does not contact the provider.
- Otherwise `cancel` submits one refund for every not-yet-refunded line, under the same crash boundaries and exactly-once rules as `refund`.

`ship` is still refused with `refund_open` when an attempt is open or `refunded_cents` is greater than 0. A shipped order with no attempt still refuses a new `refund` or `cancel` with `shipped`, even when `cap_cents` minus `refunded_cents` would cover the line.

## Requirements

C1. Attach lines. After `record`, `attach` of a valid file exits 0. A later `status` shows that cap and those lines with `refund` `none`. Changing the source file afterward does not change the stored lines. A different file is refused with `conflict` and leaves the stored lines. `attach` does not contact the provider.

C2. A line refund stays inside the cap and happens once. A line whose price is greater than `cap_cents` is refused with `over_cap`, saves no attempt, and adds no effect. A line whose price fits exits 0 against a healthy provider. The provider effect amount equals that line price, and `status` shows that line `refunded` and `refunded_cents` equal to that price. A second `refund` of that same line is refused with `already_refunded` and does not add an effect.

C3. An open submission blocks every other selection and counts against the cap. After `refund` of one line is killed at `after-attempt-saved-before-request`, `refund` of a different line that would fit under the cap is refused with `refund_open`, does not POST, and does not replace the saved refund id. `refund` of the same line then completes with that same refund id and exactly one effect. Separately, if the provider accepts a line refund and drops the reply, `refund` of a different line is refused with `refund_open` and does not POST. `reconcile` records the dropped line as refunded, does not POST, and leaves the effect count at 1. A further line whose price plus that adopted amount exceeds `cap_cents` is refused with `over_cap` and does not add an effect.

C4. Shipping still wins over a remaining cap. After `ship`, `refund` of a line that would fit under the cap is refused with `shipped`, does not contact the provider, and saves no attempt. After a line has been refunded, `ship` is refused with `refund_open`, leaves `shipment` `open`, and does not add an effect.

C5. Cancel the remainder once, or not at all. With two lines and a cap equal to the order amount, after the first line is refunded, `cancel` refunds only the second line's price as one new effect and does not change the first effect's amount. A following `cancel` exits 0 and does not add an effect. On another order, after a line refund leaves a remainder that would exceed the cap, `cancel` is refused with `over_cap`, does not POST, and leaves the remainder unrefunded.
