import { randomBytes, createHash } from "node:crypto";
import { mkdir, readFile } from "node:fs/promises";
import { Kernel, HistoricalResult } from "@ikaros/runtime";

const MACHINE_PATH = new URL("./order_refund.ik.toml", import.meta.url).pathname;
const CRASH_AFTER_ATTEMPT = "after-attempt-saved-before-request";
const CRASH_AFTER_ACCEPT = "after-accept-before-record";
const CRASH_AFTER_RECORD = "after-record-before-exit";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const LINE_ID_RE = /^[A-Za-z0-9._-]{1,32}$/;
const AMOUNT_RE = /^(?:[1-9][0-9]{0,7}|100000000)$/;

class DeskError extends Error {
  constructor(code) { super(code); this.code = code; }
}

function fail(code) { throw new DeskError(code); }
function digest(text) { return createHash("sha256").update(text).digest("hex"); }
function jsonOut(value) { process.stdout.write(JSON.stringify(value) + "\n"); }
function crashIf(boundary) {
  if (process.env.CRASH_AT === boundary) process.kill(process.pid, "SIGKILL");
}
function checkId(value) {
  if (!ID_RE.test(value)) fail("bad_id");
}
function parseAmount(value) {
  if (!AMOUNT_RE.test(value)) fail("bad_amount");
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n < 1 || n > 100000000) fail("bad_amount");
  return n;
}
function requireService() {
  const url = process.env.SERVICE_URL;
  if (!url) fail("unavailable");
  return url.replace(/\/$/, "");
}
function ensureAggregate(value) {
  if (value instanceof HistoricalResult) fail("unavailable");
  return value;
}
function numberFact(value, fallback = 0) {
  return value === undefined || value === null ? fallback : Number(value);
}
function linesOf(a) {
  const raw = a.state.lines_json;
  if (!raw) return [];
  try {
    const lines = JSON.parse(raw);
    if (!Array.isArray(lines)) fail("unavailable");
    return lines;
  } catch {
    fail("unavailable");
  }
}
function attemptIdsOf(a) {
  const raw = a.state.attempt_lines_json;
  if (!raw) return [];
  try {
    const ids = JSON.parse(raw);
    if (!Array.isArray(ids)) fail("unavailable");
    return ids;
  } catch {
    fail("unavailable");
  }
}
function hasAttachment(a) { return Boolean(a.state.lines_json); }
function sortIds(ids) { return [...ids].sort(); }
function sameIds(left, right) {
  return JSON.stringify(sortIds(left)) === JSON.stringify(sortIds(right));
}
function recordView(a) {
  const state = a.state ?? {};
  const named = a.namedState();
  const amount = numberFact(state.amount_cents);
  return {
    order_id: a.id,
    amount_cents: amount,
    currency: "USD",
    shipment: named === "shipped" ? "shipped" : "open",
    refund: named === "attempted" ? "attempt_saved" : (named === "open" || named === "shipped" ? "none" : "refunded"),
    refund_id: state.refund_id ?? null,
    refunded_cents: numberFact(state.refunded_cents),
    cap_cents: numberFact(state.cap_cents, amount),
    lines: linesOf(a),
  };
}
function success(a) { return recordView(a); }
function attemptView(a, outcome) {
  const v = recordView(a);
  return {
    order_id: a.id,
    refund: v.refund,
    refund_id: v.refund_id,
    outcome,
    amount_cents: v.amount_cents,
    refunded_cents: v.refunded_cents,
  };
}
async function openMachine() {
  const root = process.env.STATE_DIR;
  if (!root) fail("unavailable");
  await mkdir(root, { recursive: true });
  const kernel = new Kernel(`${root}/desk.db`);
  return { kernel, machine: await kernel.machine(MACHINE_PATH) };
}
async function show(machine, id) {
  try {
    return await machine.show(id);
  } catch {
    fail("unknown_order");
  }
}
async function httpRequest(method, path, body) {
  let response;
  try {
    response = await fetch(`${requireService()}${path}`, {
      method,
      headers: body === undefined ? undefined : { "content-type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(10000),
    });
  } catch {
    fail("unavailable");
  }
  let text;
  try {
    text = await response.text();
  } catch {
    fail("unavailable");
  }
  let value = null;
  if (text.length > 0) {
    try {
      value = JSON.parse(text);
    } catch {
      fail("unavailable");
    }
  }
  return { status: response.status, text, value };
}
function accepted(value, refundId, orderId, amount) {
  return value && value.refund_id === refundId && value.order_id === orderId &&
    value.amount_cents === amount && value.currency === "USD" && value.outcome === "refunded";
}
async function lookupProvider(refundId, orderId, amount) {
  const result = await httpRequest("GET", `/v1/refunds/${encodeURIComponent(refundId)}`);
  if (result.status === 404) return { kind: "not_sent" };
  if (result.status !== 200) return { kind: "unavailable" };
  if (!accepted(result.value, refundId, orderId, amount)) return { kind: "conflict" };
  return { kind: "accepted", digest: digest(result.text) };
}
async function postProvider(refundId, orderId, amount) {
  const result = await httpRequest("POST", "/v1/refunds", {
    refund_id: refundId,
    order_id: orderId,
    amount_cents: amount,
    currency: "USD",
  });
  if (result.status === 409) return { kind: "conflict" };
  if (result.status !== 200) return { kind: "unavailable" };
  if (!accepted(result.value, refundId, orderId, amount)) return { kind: "conflict" };
  return { kind: "accepted", digest: digest(result.text), fromPost: true };
}
function nextLines(a, ids) {
  const selected = new Set(ids);
  return linesOf(a).map((line) => selected.has(line.line_id)
    ? { ...line, refund: "refunded" }
    : line);
}
async function recordAccepted(a, outcomeDigest, fromPost, ids) {
  if (fromPost) crashIf(CRASH_AFTER_ACCEPT);
  if (a.effect?.status !== "recorded") {
    a = ensureAggregate(await a.recordEffectOutcome(outcomeDigest));
  }
  const selected = ids ?? attemptIdsOf(a);
  const amount = numberFact(a.state.attempt_amount_cents);
  const refunded = numberFact(a.state.refunded_cents) + amount;
  const marked = ensureAggregate(await a.command("mark_refunded", {
    refund_id: a.state.refund_id,
    amount_cents: amount,
    lines_json: JSON.stringify(nextLines(a, selected)),
    refunded_cents: refunded,
    clear_lines: "",
  }));
  if (marked.mutation !== false) crashIf(CRASH_AFTER_RECORD);
  return marked;
}
async function continueAttempt(a) {
  const refundId = a.state.refund_id;
  const amount = numberFact(a.state.attempt_amount_cents);
  const ids = attemptIdsOf(a);
  let providerResult = await lookupProvider(refundId, a.id, amount);
  if (providerResult.kind === "not_sent") {
    providerResult = await postProvider(refundId, a.id, amount);
  }
  if (providerResult.kind === "unavailable") fail("unavailable");
  if (providerResult.kind === "conflict") fail("conflict");
  a = await recordAccepted(a, providerResult.digest, providerResult.fromPost === true, ids);
  return success(a);
}
async function submitSelection(a, ids) {
  const amount = ids.length === 0 && !hasAttachment(a)
    ? numberFact(a.state.amount_cents)
    : linesOf(a).filter((line) => ids.includes(line.line_id))
      .reduce((sum, line) => sum + Number(line.price_cents), 0);
  const refundId = `r-${randomBytes(16).toString("hex")}`;
  const attemptLines = JSON.stringify(ids);
  const pendingLines = JSON.stringify(linesOf(a).map((line) => ids.includes(line.line_id)
    ? { ...line, refund: "pending" }
    : line));
  a = ensureAggregate(await a.command("save_attempt", {
    refund_id: refundId,
    amount_cents: amount,
    lines_json: attemptLines,
    pending_lines_json: pendingLines,
  }));
  crashIf(CRASH_AFTER_ATTEMPT);
  const providerResult = await postProvider(refundId, a.id, amount);
  if (providerResult.kind === "unavailable") fail("unavailable");
  if (providerResult.kind === "conflict") fail("conflict");
  a = await recordAccepted(a, providerResult.digest, true, ids);
  return success(a);
}
function validateLineFile(value, amount) {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail("bad_lines");
  const cap = value.cap_cents;
  if (!Number.isSafeInteger(cap) || cap < 1 || cap > amount) fail("bad_lines");
  if (!Array.isArray(value.lines) || value.lines.length < 1 || value.lines.length > 20) fail("bad_lines");
  const seen = new Set();
  let total = 0;
  const lines = value.lines.map((line) => {
    if (!line || typeof line !== "object" || Array.isArray(line) ||
      typeof line.line_id !== "string" || !LINE_ID_RE.test(line.line_id) ||
      seen.has(line.line_id) || !Number.isSafeInteger(line.price_cents) ||
      line.price_cents < 1 || line.price_cents > 100000000) {
      fail("bad_lines");
    }
    seen.add(line.line_id);
    total += line.price_cents;
    return { line_id: line.line_id, price_cents: line.price_cents, refund: "none" };
  });
  if (total !== amount) fail("bad_lines");
  return { cap_cents: cap, lines };
}
async function readAttachment(path, amount) {
  let text;
  try {
    text = await readFile(path, "utf8");
  } catch {
    fail("bad_lines");
  }
  try {
    return validateLineFile(JSON.parse(text), amount);
  } catch (error) {
    if (error instanceof DeskError) throw error;
    fail("bad_lines");
  }
}
function attachmentMatches(a, attachment) {
  const comparable = (lines) => lines.map(({ line_id, price_cents }) => ({ line_id, price_cents }))
    .sort((left, right) => left.line_id.localeCompare(right.line_id));
  return numberFact(a.state.cap_cents) === attachment.cap_cents &&
    JSON.stringify(comparable(linesOf(a))) === JSON.stringify(comparable(attachment.lines));
}
async function attach(machine, id, path) {
  const a = await show(machine, id);
  const state = a.namedState();
  if (state === "shipped") fail("shipped");
  if (state === "attempted" || state === "refunded") fail("refund_open");
  if (hasAttachment(a)) {
    const attachment = await readAttachment(path, numberFact(a.state.amount_cents));
    if (!attachmentMatches(a, attachment)) fail("conflict");
    return { order_id: id, cap_cents: numberFact(a.state.cap_cents), lines: linesOf(a) };
  }
  const attachment = await readAttachment(path, numberFact(a.state.amount_cents));
  const attached = ensureAggregate(await a.command("attach", {
    cap_cents: attachment.cap_cents,
    lines_json: JSON.stringify(attachment.lines),
  }));
  return { order_id: id, cap_cents: attachment.cap_cents, lines: linesOf(attached) };
}
async function cancel(machine, id) {
  let a = await show(machine, id);
  const state = a.namedState();
  if (state === "shipped") fail("shipped");
  if (state === "attempted") return continueAttempt(a);
  if (!hasAttachment(a)) {
    if (state === "refunded") return success(a);
    return submitSelection(a, []);
  }
  const remaining = linesOf(a).filter((line) => line.refund !== "refunded").map((line) => line.line_id);
  if (remaining.length === 0) return success(a);
  const amount = linesOf(a).filter((line) => remaining.includes(line.line_id))
    .reduce((sum, line) => sum + Number(line.price_cents), 0);
  if (numberFact(a.state.refunded_cents) + amount > numberFact(a.state.cap_cents)) fail("over_cap");
  return submitSelection(a, remaining);
}
async function refund(machine, id, lineIds) {
  let a = await show(machine, id);
  if (!hasAttachment(a)) fail("not_attached");
  const lines = linesOf(a);
  if (new Set(lineIds).size !== lineIds.length ||
    lineIds.some((lineId) => !lines.some((line) => line.line_id === lineId))) {
    fail("unknown_line");
  }
  const state = a.namedState();
  if (state === "shipped") fail("shipped");
  if (state === "attempted") {
    if (!sameIds(lineIds, attemptIdsOf(a))) fail("refund_open");
    return continueAttempt(a);
  }
  if (lineIds.some((lineId) => lines.find((line) => line.line_id === lineId).refund === "refunded")) {
    fail("already_refunded");
  }
  const amount = lines.filter((line) => lineIds.includes(line.line_id))
    .reduce((sum, line) => sum + Number(line.price_cents), 0);
  if (numberFact(a.state.refunded_cents) + amount > numberFact(a.state.cap_cents)) fail("over_cap");
  return submitSelection(a, lineIds);
}
async function reconcile(machine, id) {
  let a = await show(machine, id);
  const state = a.namedState();
  if (state === "open" || state === "shipped") return attemptView(a, "not_applicable");
  if (state === "refunded") return { ...attemptView(a, "refunded"), refund: "refunded" };
  const found = await lookupProvider(a.state.refund_id, id, numberFact(a.state.attempt_amount_cents));
  if (found.kind === "unavailable") fail("unavailable");
  if (found.kind === "conflict") fail("conflict");
  if (found.kind === "not_sent") return attemptView(a, "not_sent");
  a = await recordAccepted(a, found.digest, false, attemptIdsOf(a));
  return { ...attemptView(a, "refunded"), refund: "refunded", refunded_cents: numberFact(a.state.refunded_cents) };
}
async function main(args) {
  const command = args[0];
  const known = ["record", "ship", "cancel", "status", "reconcile", "attach", "refund"];
  if (!known.includes(command)) fail("bad_args");
  const exact = { record: 3, ship: 2, cancel: 2, status: 2, reconcile: 2, attach: 3 };
  if (command === "refund" ? args.length < 3 : args.length !== exact[command]) fail("bad_args");
  const id = args[1];
  checkId(id);
  let amount;
  if (command === "record") amount = parseAmount(args[2]);
  const { machine } = await openMachine();
  if (command === "record") {
    let existing;
    try { existing = await machine.show(id); } catch { existing = null; }
    if (existing) {
      if (numberFact(existing.state.amount_cents) !== amount) fail("conflict");
      return success(existing);
    }
    return success(ensureAggregate(await machine.createWith({
      aggregateId: id,
      command: { name: "record", args: { amount_cents: amount } },
    })));
  }
  if (command === "status") return success(await show(machine, id));
  if (command === "attach") return attach(machine, id, args[2]);
  if (command === "ship") {
    const a = await show(machine, id);
    const state = a.namedState();
    if (state === "attempted" || state === "refunded") fail("refund_open");
    if (state === "shipped") return success(a);
    return success(ensureAggregate(await a.command("ship")));
  }
  if (command === "cancel") return cancel(machine, id);
  if (command === "refund") return refund(machine, id, args.slice(2));
  return reconcile(machine, id);
}

try {
  jsonOut(await main(process.argv.slice(2)));
} catch (error) {
  const code = error instanceof DeskError ? error.code : "unavailable";
  jsonOut({ error: code });
  process.exitCode = 1;
}
