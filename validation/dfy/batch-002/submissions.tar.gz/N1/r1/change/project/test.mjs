import assert from "node:assert/strict";
import { createServer } from "node:http";
import { spawn } from "node:child_process";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";

const root = mkdtempSync(`${tmpdir()}/desk-test-`);
const state = `${root}/state`;
const rows = new Map();
let posts = 0;
let drop = false;
const server = createServer(async (req, res) => {
  const url = new URL(req.url, "http://127.0.0.1");
  if (req.method === "POST" && url.pathname === "/v1/refunds") {
    posts += 1;
    let body = "";
    for await (const chunk of req) body += chunk;
    const value = JSON.parse(body);
    let row = rows.get(value.refund_id);
    if (row && (row.order_id !== value.order_id || row.amount_cents !== value.amount_cents)) {
      res.writeHead(409); res.end(JSON.stringify({ error: "conflict" })); return;
    }
    if (!row) { row = { ...value, outcome: "refunded" }; rows.set(value.refund_id, row); }
    if (drop) { res.destroy(); return; }
    res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify(row)); return;
  }
  if (req.method === "GET" && url.pathname.startsWith("/v1/refunds/")) {
    const row = rows.get(decodeURIComponent(url.pathname.slice("/v1/refunds/".length)));
    if (!row) { res.writeHead(404); res.end(JSON.stringify({ error: "not_found" })); return; }
    res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify(row)); return;
  }
  res.writeHead(404); res.end();
});
await new Promise((resolve) => server.listen(46500, "127.0.0.1", resolve));
const env = (extra = {}) => ({ ...process.env, STATE_DIR: state, SERVICE_URL: "http://127.0.0.1:46500", ...extra });
const run = (args, extra = {}) => new Promise((resolve) => {
  const child = spawn("./run", args, { cwd: process.cwd(), env: env(extra) });
  let stdout = "", stderr = "";
  child.stdout.on("data", (chunk) => { stdout += chunk; });
  child.stderr.on("data", (chunk) => { stderr += chunk; });
  child.on("close", (status, signal) => resolve({ status, signal, stdout, stderr }));
});
const ok = async (args, extra = {}) => { const r = await run(args, extra); assert.equal(r.status, 0, `${args}: ${r.stderr} stdout=${r.stdout}`); return JSON.parse(r.stdout); };
const bad = async (args, extra = {}) => { const r = await run(args, extra); assert.notEqual(r.status, 0); return JSON.parse(r.stdout); };

await ok(["record", "restart", "1200"]);
assert.equal((await ok(["status", "restart"])).amount_cents, 1200);

await ok(["record", "before", "100"]);
const killedBefore = await run(["cancel", "before"], { CRASH_AT: "after-attempt-saved-before-request" });
assert.equal(killedBefore.signal, "SIGKILL");
assert.equal((await ok(["reconcile", "before"])).outcome, "not_sent");
assert.equal(posts, 0);
assert.equal((await ok(["cancel", "before"])).refund, "refunded");
assert.equal(posts, 1);

await ok(["record", "after", "200"]);
const killedAfter = await run(["cancel", "after"], { CRASH_AT: "after-accept-before-record" });
assert.equal(killedAfter.signal, "SIGKILL");
const postsAfterCrash = posts;
assert.equal((await ok(["cancel", "after"])).refund, "refunded");
assert.equal(posts, postsAfterCrash);

await ok(["record", "lost", "300"]);
drop = true;
assert.equal((await bad(["cancel", "lost"])).error, "unavailable");
drop = false;
assert.equal((await ok(["reconcile", "lost"])).outcome, "refunded");
assert.equal(posts, 3);
assert.equal((await ok(["status", "lost"])).refunded_cents, 300);

await ok(["record", "durable", "400"]);
const killedRecord = await run(["cancel", "durable"], { CRASH_AT: "after-record-before-exit" });
assert.equal(killedRecord.signal, "SIGKILL");
assert.equal((await ok(["status", "durable"])).refund, "refunded");
const durablePosts = posts;
assert.equal((await ok(["cancel", "durable"])).refund, "refunded");
assert.equal(posts, durablePosts);

await ok(["record", "shipped", "500"]);
assert.equal((await ok(["ship", "shipped"])).shipment, "shipped");
assert.equal((await bad(["cancel", "shipped"])).error, "shipped");
assert.equal((await ok(["ship", "shipped"])).shipment, "shipped");
assert.equal((await bad(["record", "shipped", "501"])).error, "conflict");

const attachedPath = `${root}/attached.json`;
writeFileSync(attachedPath, JSON.stringify({
  cap_cents: 5000,
  lines: [
    { line_id: "sku-a", price_cents: 3000 },
    { line_id: "sku-b", price_cents: 5000 },
  ],
}));
await ok(["record", "attached", "8000"]);
const attached = await ok(["attach", "attached", attachedPath]);
assert.equal(attached.cap_cents, 5000);
assert.deepEqual(attached.lines.map((line) => line.refund), ["none", "none"]);
writeFileSync(attachedPath, JSON.stringify({ cap_cents: 8000, lines: [] }));
assert.equal((await ok(["status", "attached"])).lines[0].price_cents, 3000);
assert.equal((await ok(["refund", "attached", "sku-a"])).refunded_cents, 3000);
assert.equal((await bad(["cancel", "attached"])).error, "over_cap");

const crashPath = `${root}/crash-lines.json`;
writeFileSync(crashPath, JSON.stringify({
  cap_cents: 8000,
  lines: [
    { line_id: "first", price_cents: 3000 },
    { line_id: "second", price_cents: 5000 },
  ],
}));
await ok(["record", "line-crash", "8000"]);
await ok(["attach", "line-crash", crashPath]);
const killedLine = await run(["refund", "line-crash", "first"], { CRASH_AT: "after-attempt-saved-before-request" });
assert.equal(killedLine.signal, "SIGKILL");
const pendingStatus = await ok(["status", "line-crash"]);
assert.deepEqual(pendingStatus.lines.map((line) => line.refund), ["pending", "none"]);
assert.equal((await bad(["refund", "line-crash", "second"])).error, "refund_open");
const lineRefund = await ok(["refund", "line-crash", "first"]);
assert.equal(lineRefund.refunded_cents, 3000);
assert.equal((await ok(["cancel", "line-crash"])).refunded_cents, 8000);
assert.equal((await ok(["cancel", "line-crash"])).refunded_cents, 8000);

await ok(["record", "not-attached", "100"]);
assert.equal((await bad(["refund", "not-attached", "sku-a"])).error, "not_attached");

server.close();
rmSync(root, { recursive: true, force: true });
console.log("lifecycle tests passed");
