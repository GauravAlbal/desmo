import http from "node:http";

const effects = [];
const byRefund = new Map();
const byOrder = new Map();
const callbacks = [];
const traffic = [];
let posts = 0;
const fault = {
  drop_reply: false,
  delay_ms: 0,
  status_5xx: false,
  callback: null,
};

function send(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    "content-type": "application/json",
    "content-length": Buffer.byteLength(body),
  });
  res.end(body);
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error("too_large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function publicRefund(row) {
  return {
    refund_id: row.refund_id,
    order_id: row.order_id,
    amount_cents: row.amount_cents,
    currency: row.currency,
    outcome: "refunded",
  };
}

function validId(value) {
  return typeof value === "string" && /^[A-Za-z0-9._-]{1,64}$/.test(value);
}

function rememberCallback(row, kind) {
  if (kind === "duplicate") {
    callbacks.push({
      callback_id: "cb-" + row.refund_id,
      refund_id: row.refund_id,
      order_id: row.order_id,
      amount_cents: row.amount_cents,
      currency: row.currency,
      outcome: "refunded",
    });
    return;
  }
  if (kind === "conflict") {
    callbacks.push({
      callback_id: "cb-conflict-" + row.refund_id,
      refund_id: row.refund_id,
      order_id: row.order_id,
      amount_cents: row.amount_cents === 1 ? 2 : 1,
      currency: row.currency,
      outcome: "disputed",
    });
  }
}

async function finishRefund(res, row, storedNew) {
  const delay = Number(fault.delay_ms) || 0;
  if (delay > 0) {
    await new Promise((resolve) => setTimeout(resolve, delay));
  }
  if (storedNew && fault.callback === "duplicate") rememberCallback(row, "duplicate");
  if (storedNew && fault.callback === "conflict") rememberCallback(row, "conflict");
  if (fault.drop_reply) {
    res.destroy();
    return;
  }
  send(res, 200, publicRefund(row));
}

async function onRefund(req, res) {
  posts += 1;
  traffic.push({ method: "POST", path: "/v1/refunds" });
  let body;
  try {
    body = JSON.parse((await readBody(req, 65536)).toString("utf8"));
  } catch {
    send(res, 400, { error: "bad_request" });
    return;
  }
  const refundId = body.refund_id;
  const orderId = body.order_id;
  const amount = body.amount_cents;
  const currency = body.currency;
  if (!validId(refundId) || !validId(orderId) ||
      !Number.isInteger(amount) || amount < 1 || amount > 100000000 ||
      currency !== "USD") {
    send(res, 400, { error: "bad_request" });
    return;
  }
  if (fault.status_5xx) {
    const delay = Number(fault.delay_ms) || 0;
    if (delay > 0) await new Promise((resolve) => setTimeout(resolve, delay));
    send(res, 500, { error: "unavailable" });
    return;
  }
  const prior = byRefund.get(refundId);
  if (prior) {
    if (prior.order_id !== orderId || prior.amount_cents !== amount || prior.currency !== currency) {
      send(res, 409, { error: "conflict" });
      return;
    }
    await finishRefund(res, prior, false);
    return;
  }
  const row = {
    refund_id: refundId,
    order_id: orderId,
    amount_cents: amount,
    currency,
  };
  byRefund.set(refundId, row);
  if (!byOrder.has(orderId)) byOrder.set(orderId, []);
  byOrder.get(orderId).push(row);
  effects.push(row);
  await finishRefund(res, row, true);
}

function onService(req, res) {
  const url = new URL(req.url, "http://127.0.0.1");
  if (req.method === "POST" && url.pathname === "/v1/refunds") {
    onRefund(req, res).catch(() => {
      if (!res.headersSent) send(res, 400, { error: "bad_request" });
    });
    return;
  }
  if (req.method === "GET" && url.pathname.startsWith("/v1/refunds/")) {
    traffic.push({ method: "GET", path: url.pathname });
    const refundId = decodeURIComponent(url.pathname.slice("/v1/refunds/".length));
    const row = byRefund.get(refundId);
    if (!row) {
      send(res, 404, { error: "not_found" });
      return;
    }
    send(res, 200, publicRefund(row));
    return;
  }
  if (req.method === "GET" && url.pathname.startsWith("/v1/orders/") && url.pathname.endsWith("/refunds")) {
    traffic.push({ method: "GET", path: url.pathname });
    const orderId = decodeURIComponent(url.pathname.slice("/v1/orders/".length, -"/refunds".length));
    const rows = byOrder.get(orderId) || [];
    send(res, 200, {
      order_id: orderId,
      refunds: rows.map(publicRefund),
    });
    return;
  }
  send(res, 404, { error: "not_found" });
}

function onControl(req, res) {
  const url = new URL(req.url, "http://127.0.0.1");
  if (req.method === "GET" && url.pathname === "/health") {
    send(res, 200, { ok: true });
    return;
  }
  if (req.method === "GET" && url.pathname === "/effects") {
    send(res, 200, {
      count: effects.length,
      posts,
      effects: effects.map(publicRefund),
    });
    return;
  }
  if (req.method === "GET" && url.pathname === "/traffic") {
    send(res, 200, { requests: traffic });
    return;
  }
  if (req.method === "GET" && url.pathname === "/callbacks") {
    send(res, 200, { callbacks });
    return;
  }
  if (req.method === "POST" && url.pathname === "/fault") {
    readBody(req, 65536).then((buf) => {
      let body;
      try {
        body = JSON.parse(buf.toString("utf8"));
      } catch {
        send(res, 400, { error: "bad_request" });
        return;
      }
      fault.drop_reply = Boolean(body.drop_reply);
      fault.delay_ms = Number.isInteger(body.delay_ms) && body.delay_ms > 0 ? body.delay_ms : 0;
      fault.status_5xx = Boolean(body.status_5xx);
      fault.callback = body.callback === "duplicate" || body.callback === "conflict" ? body.callback : null;
      if (fault.callback && effects.length > 0) {
        rememberCallback(effects[effects.length - 1], fault.callback);
      }
      send(res, 200, { ok: true });
    }).catch(() => {
      if (!res.headersSent) send(res, 400, { error: "bad_request" });
    });
    return;
  }
  send(res, 404, { error: "not_found" });
}

const service = http.createServer(onService);
const control = http.createServer(onControl);
service.on("clientError", (_err, socket) => socket.destroy());
control.on("clientError", (_err, socket) => socket.destroy());
process.on("SIGTERM", () => process.exit(0));

service.listen(0, "127.0.0.1", () => {
  control.listen(0, "127.0.0.1", () => {
    const sport = service.address().port;
    const cport = control.address().port;
    process.stdout.write(JSON.stringify({
      service_url: "http://127.0.0.1:" + sport,
      control_url: "http://127.0.0.1:" + cport,
    }) + "\n");
  });
});
