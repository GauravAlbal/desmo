# Paid-order cancellation desk

A local desk records that an order was already paid, and on request cancels that order by asking a payment provider to refund it. A shipped order must not be refunded. A refund for an order must be submitted at most once, including when the provider's reply is lost or the desk process is killed. Cancelling an order that is already refunded does nothing further. An uncertain submission is resolved by lookup, not by sending the refund again.

You own the program behind `./run`. The payment provider is supplied. Its HTTP API is specified below and, with the same rules, in `stub/CONTRACT.md`.

Implement `./run` in TypeScript on Node. The acceptance harness executes only the `./run` file. A shell wrapper that starts Node is fine.

## Scope

- One machine, one state directory, one desk process at a time.
- Many orders may be recorded in the same state directory. Orders do not share a refund.
- The operator does not run two `./run` processes at once. An unrelated process may write other files in the state directory between commands, and may do so while a command runs.
- No second machine, no distributed transaction, and no second payment provider.
- Clocks are not part of the contract. Do not depend on the wall clock.
- The desk does not listen for provider callbacks. Uncertain submissions are resolved only by lookup.

## How to run

`./run` is executable. Each invocation is one process:

```text
./run <command> [args]
```

The process prints exactly one JSON object on stdout and nothing else. Exit 0 means the command completed. A refusal is a nonzero exit and a JSON object whose `error` value is the code named for that refusal. Extra JSON fields are allowed. Field names and values named below are required. stderr is ignored by acceptance checks.

Environment:

- `STATE_DIR` — directory for the durable store. The desk may create it. A new process with the same `STATE_DIR` sees every record the previous process committed. The desk chooses its own filenames inside `STATE_DIR` and must leave every other file there unchanged.
- `SERVICE_URL` — payment provider base URL, with no trailing slash. Example: `http://127.0.0.1:9`.
- `CRASH_AT` — optional. When the running command reaches the named boundary, the process must kill itself with `SIGKILL` (`process.kill(process.pid, "SIGKILL")` or the equivalent uncatchable kill). If the command never reaches that boundary, it must not kill itself.

Committed means a later process with the same `STATE_DIR` can read the record after `SIGKILL`. Flush the record to disk before treating it as committed.

### Crash boundaries

`after-attempt-saved-before-request`
On `cancel`, after the refund attempt (refund id, order id, and amount) is committed, and before any byte of the refund HTTP request is sent. Not on a later `cancel` that finds the attempt already saved. Not on a lookup.

`after-accept-before-record`
On `cancel`, after the provider has accepted the refund and this process has read the complete HTTP response body, and before the durable refunded outcome is committed. Not on a lookup of an acceptance performed by an earlier process.

`after-record-before-exit`
On `cancel` or `reconcile`, after this invocation commits the terminal outcome `refunded`, and before the success JSON is written and the process exits. Do not honor this boundary when this invocation did not commit that outcome.

## Identifiers and amounts

- Order id: 1 to 64 characters from `A-Za-z0-9._-`.
- Refund id: 1 to 64 characters from `A-Za-z0-9._-`, chosen by the desk. The operator does not supply it.
- Amount: an integer number of cents from 1 to 100000000 inclusive. The command argument is a decimal integer without a sign and without leading zeros.
- Currency is always `USD`. It is not a command argument. Every provider request uses `USD`.

A command argument that is not a valid order id is refused with `bad_id`. An amount argument that is not a valid amount is refused with `bad_amount`. Too few arguments is refused with `bad_args`. Those refusals must not contact the provider and must not change stored orders.

## Commands

### `./run record <order_id> <amount_cents>`

Record a paid order. Do not contact the provider.

Success, exit 0:

```json
{"order_id":"...","amount_cents":1000,"currency":"USD","shipment":"open","refund":"none","refund_id":null,"refunded_cents":0}
```

The same order id and the same amount again exits 0 and leaves the stored order unchanged. The same order id with a different amount is refused with `conflict` and leaves the original amount unchanged.

### `./run ship <order_id>`

Mark the order shipped. Do not contact the provider.

Refuse with `unknown_order` if the order was not recorded.

Refuse with `refund_open` if a refund attempt is saved or the order is already refunded. Do not change shipment in that case.

If the order is already shipped and no refund attempt or refunded outcome is stored, exit 0 and leave it shipped.

Success, exit 0:

```json
{"order_id":"...","amount_cents":1000,"currency":"USD","shipment":"shipped","refund":"none","refund_id":null,"refunded_cents":0}
```

### `./run cancel <order_id>`

Cancel an unshipped order by refunding its full amount once.

Refuse with `unknown_order` if the order was not recorded. Do not contact the provider.

Refuse with `shipped` if the order is shipped and no refund attempt is saved. Do not contact the provider. Do not save an attempt. Shipment and refund stay as they were.

If `refund` is already `refunded`, exit 0 with the success object below. Do not contact the provider. Do not change `refund_id` or `refunded_cents`.

Otherwise:

1. If no attempt is saved yet, allocate a refund id, commit an attempt (`refund` = `attempt_saved`, plus refund id, order id, and the order amount), then honor `after-attempt-saved-before-request`.
2. If an attempt is already saved, keep that refund id. Do not honor `after-attempt-saved-before-request`. Query `GET /v1/refunds/<refund_id>`. If the provider has accepted that id for this order and this amount, commit `refunded` and do not POST. If the provider answers HTTP 404, POST the saved refund id and the saved amount. If the provider answers HTTP 200 with a different amount or a different order id, exit nonzero with `conflict`, leave the attempt in place, and do not allocate a new refund id.
3. POST once, as specified in the provider section. After the complete response body is read, honor `after-accept-before-record`. If the response is HTTP 200 with `outcome` `refunded` and the saved amount, commit `refunded` and `refunded_cents` equal to the order amount.
4. Honor `after-record-before-exit`, then print the success object.

Success, exit 0:

```json
{"order_id":"...","amount_cents":1000,"currency":"USD","shipment":"open","refund":"refunded","refund_id":"...","refunded_cents":1000}
```

`refund_id` is the id that was saved on the attempt, not a newly allocated id.

If the connection fails or closes before a complete response, or the provider returns HTTP 500, `cancel` must exit nonzero with `unavailable`. It must leave the attempt record in place and must not POST a different refund id in that invocation. It may return without a lookup; `reconcile` will query the provider. It must not report `refund` as `refunded` unless an acceptance was read from a complete HTTP 200 body or from a lookup HTTP 200. It must not report that the provider has no record unless a lookup returned HTTP 404.

A delayed but complete response belongs to this submission. Do not start a second refund id while waiting for it.

If `refund` is already `refunded`, a later `cancel` is not a new submission. It must not be overwritten by a late or conflicting observation the desk did not itself adopt from a lookup or a complete acceptance of this refund id.

### `./run status <order_id>`

Print the committed local record. Do not contact the provider.

Refuse with `unknown_order` if the order was not recorded.

Success, exit 0:

```json
{"order_id":"...","amount_cents":1000,"currency":"USD","shipment":"open","refund":"none","refund_id":null,"refunded_cents":0}
```

`shipment` is `open` or `shipped`. `refund` is `none`, `attempt_saved`, or `refunded`. `refund_id` is the saved attempt id, or the id of the committed refund, or `null` when neither exists. `refunded_cents` is `0` unless `refund` is `refunded`, in which case it is the order amount.

### `./run reconcile <order_id>`

Resolve an uncertain refund by lookup. This command must never POST, and must never allocate a refund id.

Refuse with `unknown_order` if the order was not recorded. Do not contact the provider.

- No attempt saved and `refund` is not `refunded`: exit 0 with `"outcome":"not_applicable"`, `"refund":"none"`, and `"refund_id":null`. Do not contact the provider.
- `refund` is already `refunded` and no attempt is open: exit 0 with `"outcome":"refunded"` and the stored refund id. Do not POST. Leave `refunded_cents` unchanged.
- Attempt saved: `GET /v1/refunds/<refund_id>` and do not POST.
  - HTTP 200 with `outcome` `refunded`, this order id, and the saved amount: commit `refunded`, set `refunded_cents` to the order amount, honor `after-record-before-exit` because this invocation committed that outcome, and exit 0 with `"outcome":"refunded"`.
  - HTTP 404: exit 0 with `"outcome":"not_sent"` and the saved refund id. Leave `refund` as `attempt_saved`. `not_sent` means only that this lookup returned HTTP 404.
  - HTTP 200 whose amount or order id differs from the saved attempt: do not change the local outcome; exit nonzero with `conflict`.
  - The provider cannot be contacted, or the lookup is not HTTP 200 or HTTP 404: exit nonzero with `unavailable`. Do not change the attempt. Do not report `not_sent`.

Success shapes:

```json
{"order_id":"...","refund":"attempt_saved","refund_id":"...","outcome":"not_sent","amount_cents":1000,"refunded_cents":0}
```

```json
{"order_id":"...","refund":"refunded","refund_id":"...","outcome":"refunded","amount_cents":1000,"refunded_cents":1000}
```

```json
{"order_id":"...","refund":"none","refund_id":null,"outcome":"not_applicable","amount_cents":1000,"refunded_cents":0}
```

## Payment provider

`SERVICE_URL` has no trailing slash. The desk uses these routes. The same rules are in `stub/CONTRACT.md`.

`POST /v1/refunds` with `Content-Type: application/json`:

```json
{"refund_id":"...","order_id":"...","amount_cents":1000,"currency":"USD"}
```

- A body that is not that shape, or whose ids, amount, or currency are not valid, returns HTTP 400 `{"error":"bad_request"}` and stores nothing.
- The first time a `refund_id` is accepted, the provider stores one refund effect for that order and amount. Response HTTP 200:

```json
{"refund_id":"...","order_id":"...","amount_cents":1000,"currency":"USD","outcome":"refunded"}
```

- The same `refund_id` with the same order id, amount, and currency returns the stored result and does not count another effect.
- The same `refund_id` with a different order id, amount, or currency returns HTTP 409 `{"error":"conflict"}` and does not change the stored effect.
- A different `refund_id` is a different effect, even when the order id and amount match.

`GET /v1/refunds/<refund_id>` returns that 200 object, or HTTP 404 `{"error":"not_found"}` if that id was never accepted.

`GET /v1/orders/<order_id>/refunds` returns HTTP 200 `{"order_id":"...","refunds":[...]}`. `refunds` is every accepted refund for that order, in acceptance order, or an empty array. This route is a lookup. `reconcile` must use `GET /v1/refunds/<refund_id>` for the saved id. It must not POST because an order list is empty or nonempty.

The provider may drop the HTTP reply after it has accepted and counted the effect, may answer late, may return HTTP 500 without storing an effect, and may record a duplicate or conflicting callback for an accepted refund. The desk does not receive those callbacks. Recovery is `reconcile` or a later `cancel` that reuses the saved refund id.

## Requirements

R1. Persistence. After `record` or `ship`, a new process with the same `STATE_DIR` sees the same order id, amount, shipment, and refund fields. A later process sees an attempt or a refunded outcome that a previous process committed, including a record that was committed and then followed by `SIGKILL`.

R2. Record is local and stable. `record` stores the amount and does not contact the provider. Recording the same id and amount again exits 0 and does not change the amount. Recording the same id with a different amount is refused with `conflict` and leaves the original amount. `status` shows the stored amount and does not contact the provider.

R3. Shipment blocks a new refund. After `ship`, `cancel` exits nonzero with `shipped`, does not contact the provider, does not save a refund attempt, and leaves `shipment` `shipped` and `refund` `none`. A second `ship` of that order exits 0. `ship` itself does not contact the provider.

R4. One full refund. After `record` of an unshipped order, `cancel` against a healthy provider exits 0. `status` then shows `refund` `refunded` and `refunded_cents` equal to the recorded amount. The provider has exactly one effect for that order, and that effect's amount is the recorded amount.

R5. Legitimate progress. With a healthy provider, `record` and `cancel` of an unshipped order each exit 0, and `status` then shows `refunded`. A valid sequence must not be refused.

R6. Cancel after refund is idempotent. A second `cancel` after `refund` is `refunded` exits 0, leaves `refund`, `refund_id`, and `refunded_cents` unchanged, and does not add an effect.

R7. Reconcile does not send. If `cancel` is killed at `after-attempt-saved-before-request`, the provider has counted no effect, and `status` shows `attempt_saved` and a refund id. A following `reconcile` exits 0 with `outcome` `not_sent`, leaves the attempt in place, and does not POST. The provider effect count stays 0.

R8. Crash after accept. If `cancel` is killed at `after-accept-before-record`, the provider has already counted one effect for the saved refund id. A later `cancel`, with `CRASH_AT` unset, must end with `status` `refunded` for that same refund id and the recorded amount. It must not say the refund was never sent, and it must not cause the provider to count a second effect or a different refund id.

R9. Crash before the request. If `cancel` is killed at `after-attempt-saved-before-request`, a later `cancel`, with `CRASH_AT` unset, must reach `refunded` with the same refund id, and the provider must count exactly one effect.

R10. Crash after the durable record. If `cancel` is killed at `after-record-before-exit`, a later `status` shows `refunded` and the recorded amount. A further `cancel` must not add an effect and must leave `refund` `refunded`.

R11. Orders are independent. Recording and shipping one order does not change another order. Cancelling the second order refunds only that order. The first order stays shipped with `refund` `none`. The provider's effects are only for the cancelled order.

R12. Result protocol. A successful `record` exits 0 and prints one JSON object. A refusal, such as `cancel` of an order that was not recorded, exits nonzero and prints one JSON object whose `error` value is `unknown_order`.

R13. Unrelated writer. A file in `STATE_DIR` written by another process, which the desk did not create, is still present with the same bytes after later desk commands. Those commands still see the records owned by the desk.

R14. Lost reply. If the provider accepts a refund and drops the reply, that acceptance has already counted one effect. `cancel` may exit nonzero. It must leave a way to resolve that refund id and must not POST a different refund id. A following `reconcile` must record `refunded` for the saved amount, must not report `not_sent`, and must not add an effect. `not_sent` is legal only when the refund lookup returns HTTP 404.

## Out of scope

Concurrent `./run` processes, a second currency, refunding a shipped order by override, deleting an order, and any cross-order transaction are outside this brief. Partial refunds of line items are not part of this brief.
