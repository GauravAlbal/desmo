# Paid-order cancellation desk

The executable `./run` records paid orders, stores optional line attachments with a
per-order refund cap, submits full or selected-line refunds, and reconciles an
uncertain provider submission by refund id. Lifecycle state is persisted by the
installed Ikaros runtime in `STATE_DIR/desk.sqlite`.

## Setup

Use Node 22 or newer. From this directory, with the supplied offline tarballs:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

The command uses `STATE_DIR` for its durable state (default: `.state`) and
`SERVICE_URL` for the payment service. `SERVICE_URL` must not have a trailing
slash. The optional `CRASH_AT` values are:

- `after-attempt-saved-before-request`
- `after-accept-before-record`
- `after-record-before-exit`

## Commands

```sh
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:46600 ./run record order-1 1000
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:46600 ./run attach order-1 /path/to/lines.json
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:46600 ./run refund order-1 sku-a sku-b
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:46600 ./run ship order-1
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:46600 ./run cancel order-1
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:46600 ./run reconcile order-1
STATE_DIR=/path/to/state SERVICE_URL=http://127.0.0.1:46600 ./run status order-1
```

An attachment file has the shape
`{"cap_cents":4000,"lines":[{"line_id":"sku-a","price_cents":3000}]}`;
its line prices must sum to the recorded order amount. `refund` submits all
named lines as one provider effect. `cancel` submits the full amount for an
unattached order, or all remaining lines for an attached order when the cap
allows it.

Each invocation prints one JSON object. A refusal prints `{"error":"..."}`
and exits nonzero. Provider interaction is limited to the refund-id GET and
POST routes in `stub/CONTRACT.md`; `reconcile` never POSTs.

## Tests

`node test.mjs` starts a deterministic local provider on `127.0.0.1:46604` and
covers process restart, all three crash labels for full and line refunds, lost
provider replies, idempotence, attachments, cap enforcement, line-selection
conflicts, record conflicts, and shipped-order refusal. It leaves only temporary
test state directories under the operating system temporary directory.
