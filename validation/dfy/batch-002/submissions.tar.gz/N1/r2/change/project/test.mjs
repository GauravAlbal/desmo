#!/usr/bin/env node
import assert from "node:assert/strict";
import { mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawn } from "node:child_process";
import http from "node:http";

const project = new URL(".", import.meta.url).pathname;
const run = join(project, "run");
const states = new Map();
let dropReply = false;
let effects = 0;

const service = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://127.0.0.1");
  if (req.method === "POST" && url.pathname === "/v1/refunds") {
    let text = "";
    for await (const chunk of req) text += chunk;
    const body = JSON.parse(text);
    const existing = states.get(body.refund_id);
    if (existing && (existing.order_id !== body.order_id || existing.amount_cents !== body.amount_cents)) {
      res.writeHead(409); res.end(JSON.stringify({ error: "conflict" })); return;
    }
    if (!existing) { states.set(body.refund_id, body); effects += 1; }
    if (dropReply) { res.destroy(); return; }
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ ...body, outcome: "refunded" }));
    return;
  }
  if (req.method === "GET" && url.pathname.startsWith("/v1/refunds/")) {
    const id = decodeURIComponent(url.pathname.slice("/v1/refunds/".length));
    const body = states.get(id);
    res.writeHead(body ? 200 : 404, { "content-type": "application/json" });
    res.end(JSON.stringify(body ? { ...body, outcome: "refunded" } : { error: "not_found" }));
    return;
  }
  res.writeHead(404); res.end();
});

await new Promise((resolve) => service.listen(46604, "127.0.0.1", resolve));
const serviceUrl = "http://127.0.0.1:46604";
function invoke(stateDir, args, extra = {}) {
  return new Promise((resolve) => {
    const child = spawn(run, args, {
      cwd: project,
      env: { ...process.env, STATE_DIR: stateDir, SERVICE_URL: serviceUrl, ...extra },
    });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk) => { stdout += chunk; });
    child.stderr.on("data", (chunk) => { stderr += chunk; });
    child.on("close", (status, signal) => resolve({ status, signal, stdout, stderr }));
  });
}
function json(result) { return JSON.parse(result.stdout); }
async function ok(stateDir, args, extra) {
  const result = await invoke(stateDir, args, extra);
  assert.equal(result.status, 0, `${args.join(" ")} failed: ${result.stdout}${result.stderr}`);
  return json(result);
}
async function refused(stateDir, args, code, extra) {
  const result = await invoke(stateDir, args, extra);
  assert.notEqual(result.status, 0, `${args.join(" ")} unexpectedly succeeded`);
  assert.equal(json(result).error, code, `${args.join(" ")} returned ${result.stdout}${result.stderr}`);
}
function linesFile(name, value) {
  const path = join(mkdtempSync(join(tmpdir(), `paid-order-lines-${name}-`)), "lines.json");
  writeFileSync(path, JSON.stringify(value));
  return path;
}

try {
  const beforeDir = mkdtempSync(join(tmpdir(), "paid-order-before-"));
  await ok(beforeDir, ["record", "before", "1100"]);
  const crashBefore = await invoke(beforeDir, ["cancel", "before"], { CRASH_AT: "after-attempt-saved-before-request" });
  assert.equal(crashBefore.signal, "SIGKILL");
  assert.equal((await ok(beforeDir, ["status", "before"])).refund, "attempt_saved");
  assert.equal((await ok(beforeDir, ["reconcile", "before"])).outcome, "not_sent");
  await ok(beforeDir, ["cancel", "before"]);
  assert.equal((await ok(beforeDir, ["status", "before"])).refunded_cents, 1100);

  const afterDir = mkdtempSync(join(tmpdir(), "paid-order-after-"));
  await ok(afterDir, ["record", "after", "1200"]);
  const crashAfter = await invoke(afterDir, ["cancel", "after"], { CRASH_AT: "after-accept-before-record" });
  assert.equal(crashAfter.signal, "SIGKILL");
  await ok(afterDir, ["cancel", "after"]);
  assert.equal((await ok(afterDir, ["status", "after"])).refund, "refunded");

  const afterRecordDir = mkdtempSync(join(tmpdir(), "paid-order-record-"));
  await ok(afterRecordDir, ["record", "after-record", "1250"]);
  const crashAfterRecord = await invoke(afterRecordDir, ["cancel", "after-record"], { CRASH_AT: "after-record-before-exit" });
  assert.equal(crashAfterRecord.signal, "SIGKILL");
  assert.equal((await ok(afterRecordDir, ["status", "after-record"])).refund, "refunded");
  await ok(afterRecordDir, ["cancel", "after-record"]);

  const lostDir = mkdtempSync(join(tmpdir(), "paid-order-lost-"));
  await ok(lostDir, ["record", "lost", "1300"]);
  dropReply = true;
  await refused(lostDir, ["cancel", "lost"], "unavailable");
  dropReply = false;
  assert.equal((await ok(lostDir, ["reconcile", "lost"])).outcome, "refunded");
  assert.equal(effects, 4);

  const stableDir = mkdtempSync(join(tmpdir(), "paid-order-stable-"));
  await ok(stableDir, ["record", "stable", "900"]);
  assert.equal((await ok(stableDir, ["record", "stable", "900"])).amount_cents, 900);
  await refused(stableDir, ["record", "stable", "901"], "conflict");
  await ok(stableDir, ["ship", "stable"]);
  await refused(stableDir, ["cancel", "stable"], "shipped");
  assert.equal(effects, 4);

  const attachDir = mkdtempSync(join(tmpdir(), "paid-order-attach-"));
  const attachPath = linesFile("attach", { cap_cents: 4000, lines: [
    { line_id: "sku-a", price_cents: 3000 },
    { line_id: "sku-b", price_cents: 5000 },
  ] });
  await ok(attachDir, ["record", "attach", "8000"]);
  const attached = await ok(attachDir, ["attach", "attach", attachPath]);
  assert.deepEqual(attached.lines, [
    { line_id: "sku-a", price_cents: 3000, refund: "none" },
    { line_id: "sku-b", price_cents: 5000, refund: "none" },
  ]);
  writeFileSync(attachPath, JSON.stringify({ cap_cents: 1, lines: [] }));
  assert.equal((await ok(attachDir, ["status", "attach"])).cap_cents, 4000);
  await refused(attachDir, ["refund", "attach", "sku-b"], "over_cap");
  await ok(attachDir, ["refund", "attach", "sku-a"]);
  await refused(attachDir, ["refund", "attach", "sku-a"], "already_refunded");
  assert.equal((await ok(attachDir, ["status", "attach"])).refunded_cents, 3000);
  assert.equal(effects, 5);

  const openDir = mkdtempSync(join(tmpdir(), "paid-order-open-"));
  const openPath = linesFile("open", { cap_cents: 3000, lines: [
    { line_id: "one", price_cents: 1500 },
    { line_id: "two", price_cents: 2000 },
  ] });
  await ok(openDir, ["record", "open", "3500"]);
  await ok(openDir, ["attach", "open", openPath]);
  const openCrash = await invoke(openDir, ["refund", "open", "one"], { CRASH_AT: "after-attempt-saved-before-request" });
  assert.equal(openCrash.signal, "SIGKILL");
  await refused(openDir, ["refund", "open", "two"], "refund_open");
  await ok(openDir, ["refund", "open", "one"]);
  await refused(openDir, ["refund", "open", "two"], "over_cap");
  assert.equal(effects, 6);

  const lostLineDir = mkdtempSync(join(tmpdir(), "paid-order-lost-line-"));
  const lostLinePath = linesFile("lost-line", { cap_cents: 3000, lines: [
    { line_id: "left", price_cents: 1500 },
    { line_id: "right", price_cents: 2000 },
  ] });
  await ok(lostLineDir, ["record", "lost-line", "3500"]);
  await ok(lostLineDir, ["attach", "lost-line", lostLinePath]);
  dropReply = true;
  await refused(lostLineDir, ["refund", "lost-line", "left"], "unavailable");
  dropReply = false;
  await refused(lostLineDir, ["refund", "lost-line", "right"], "refund_open");
  assert.equal((await ok(lostLineDir, ["reconcile", "lost-line"])).outcome, "refunded");
  await refused(lostLineDir, ["refund", "lost-line", "right"], "over_cap");
  assert.equal(effects, 7);

  const shipLineDir = mkdtempSync(join(tmpdir(), "paid-order-ship-line-"));
  const shipLinePath = linesFile("ship-line", { cap_cents: 2000, lines: [{ line_id: "ship-me", price_cents: 2000 }] });
  await ok(shipLineDir, ["record", "ship-line", "2000"]);
  await ok(shipLineDir, ["attach", "ship-line", shipLinePath]);
  await ok(shipLineDir, ["ship", "ship-line"]);
  await refused(shipLineDir, ["refund", "ship-line", "ship-me"], "shipped");
  await ok(shipLineDir, ["ship", "ship-line"]);

  const remainderDir = mkdtempSync(join(tmpdir(), "paid-order-remainder-"));
  const remainderPath = linesFile("remainder", { cap_cents: 3000, lines: [
    { line_id: "first", price_cents: 1000 },
    { line_id: "last", price_cents: 2000 },
  ] });
  await ok(remainderDir, ["record", "remainder", "3000"]);
  await ok(remainderDir, ["attach", "remainder", remainderPath]);
  const remainderCrash = await invoke(remainderDir, ["refund", "remainder", "first"], { CRASH_AT: "after-record-before-exit" });
  assert.equal(remainderCrash.signal, "SIGKILL");
  assert.equal((await ok(remainderDir, ["status", "remainder"])).refunded_cents, 1000);
  await refused(remainderDir, ["ship", "remainder"], "refund_open");
  await ok(remainderDir, ["cancel", "remainder"]);
  await ok(remainderDir, ["cancel", "remainder"]);
  assert.equal(effects, 9);

  const overCancelDir = mkdtempSync(join(tmpdir(), "paid-order-over-cancel-"));
  const overCancelPath = linesFile("over-cancel", { cap_cents: 2500, lines: [
    { line_id: "small", price_cents: 1000 },
    { line_id: "large", price_cents: 2000 },
  ] });
  await ok(overCancelDir, ["record", "over-cancel", "3000"]);
  await ok(overCancelDir, ["attach", "over-cancel", overCancelPath]);
  await ok(overCancelDir, ["refund", "over-cancel", "small"]);
  await refused(overCancelDir, ["cancel", "over-cancel"], "over_cap");
  assert.equal((await ok(overCancelDir, ["status", "over-cancel"])).refunded_cents, 1000);

  console.log("lifecycle tests passed");
} finally {
  service.closeAllConnections();
  service.close();
}
