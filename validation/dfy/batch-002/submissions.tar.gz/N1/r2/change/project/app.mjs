#!/usr/bin/env node
import { mkdir, readFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { Kernel, HistoricalResult } from "@ikaros/runtime";

const HERE = dirname(fileURLToPath(import.meta.url));
const MACHINE = join(HERE, "order_desk.ik.toml");
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const LINE_ID_RE = /^[A-Za-z0-9._-]{1,32}$/;
const AMOUNT_RE = /^[0-9]+$/;

class DeskError extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
}

function fail(code) {
  throw new DeskError(code);
}

function validId(value) {
  return typeof value === "string" && ID_RE.test(value);
}

function validLineId(value) {
  return typeof value === "string" && LINE_ID_RE.test(value);
}

function parseAmount(value) {
  if (typeof value !== "string" || !AMOUNT_RE.test(value) || (value.length > 1 && value[0] === "0")) {
    return null;
  }
  const amount = Number(value);
  return Number.isSafeInteger(amount) && amount >= 1 && amount <= 100000000 ? amount : null;
}

function parseStoredLines(value) {
  if (typeof value !== "string") return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function stateOf(aggregate) {
  const state = aggregate.state && typeof aggregate.state === "object" ? aggregate.state : {};
  const amount = Number(state.amount_cents ?? 0);
  const refundedCents = Number(state.refunded_cents ?? 0);
  const attemptAmount = Number(state.attempt_amount_cents ?? 0);
  const stateName = String(state.state ?? aggregate.namedState());
  let refund = "none";
  if (stateName === "attempt_saved" || attemptAmount > 0) refund = "attempt_saved";
  else if (refundedCents > 0) refund = "refunded";
  return {
    state: stateName,
    amount,
    cap: Number(state.cap_cents ?? amount),
    refundId: typeof state.refund_id === "string" && state.refund_id.length > 0 ? state.refund_id : null,
    refundedCents,
    lines: parseStoredLines(state.lines_json),
    attemptLines: parseStoredLines(state.attempt_lines_json),
    attemptAmount,
    refund,
  };
}

function outputRecord(orderId, aggregate) {
  const s = stateOf(aggregate);
  return {
    order_id: orderId,
    amount_cents: s.amount,
    currency: "USD",
    shipment: s.state === "shipped" ? "shipped" : "open",
    refund: s.refund,
    refund_id: s.refundId,
    refunded_cents: s.refundedCents,
    cap_cents: s.cap,
    lines: s.lines.map((line) => ({
      line_id: line.line_id,
      price_cents: line.price_cents,
      refund: line.refund,
    })),
  };
}

function outputReconcile(orderId, aggregate, outcome) {
  const s = stateOf(aggregate);
  return {
    order_id: orderId,
    refund: s.refund,
    refund_id: s.refundId,
    outcome,
    amount_cents: s.amount,
    refunded_cents: s.refundedCents,
    cap_cents: s.cap,
    lines: s.lines.map((line) => ({
      line_id: line.line_id,
      price_cents: line.price_cents,
      refund: line.refund,
    })),
  };
}

async function openDesk() {
  const stateDir = process.env.STATE_DIR || join(HERE, ".state");
  await mkdir(stateDir, { recursive: true });
  const kernel = new Kernel(join(stateDir, "desk.sqlite"), {
    binary: process.env.IK_BINARY || join(HERE, "node_modules/@ikaros/darwin-arm64/bin/ik"),
  });
  return { kernel, machine: await kernel.machine(MACHINE) };
}

async function showOrder(machine, orderId) {
  try {
    return await machine.show(orderId);
  } catch (error) {
    if (error?.rule === "aggregate.not_found" || error?.rule === "store.missing") fail("unknown_order");
    throw error;
  }
}

function crashAt(label) {
  if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL");
}

function serviceUrl() {
  const base = process.env.SERVICE_URL;
  if (!base || base.endsWith("/")) fail("unavailable");
  return base;
}

async function providerRequest(method, path, body) {
  let response;
  try {
    response = await fetch(serviceUrl() + path, {
      method,
      headers: body === undefined ? undefined : { "content-type": "application/json" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const text = await response.text();
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch {
      fail("unavailable");
    }
    return { status: response.status, body: parsed };
  } catch (error) {
    if (error instanceof DeskError) throw error;
    fail("unavailable");
  }
}

function acceptedFor(body, orderId, amount, refundId) {
  return body && typeof body === "object" && body.refund_id === refundId &&
    body.order_id === orderId && body.amount_cents === amount &&
    body.currency === "USD" && body.outcome === "refunded";
}

async function lookupRefund(orderId, amount, refundId) {
  const result = await providerRequest("GET", "/v1/refunds/" + encodeURIComponent(refundId));
  if (result.status === 404) return { kind: "not_found" };
  if (result.status !== 200) fail("unavailable");
  if (!acceptedFor(result.body, orderId, amount, refundId)) return { kind: "conflict" };
  return { kind: "accepted" };
}

async function postRefund(orderId, amount, refundId) {
  const result = await providerRequest("POST", "/v1/refunds", {
    refund_id: refundId,
    order_id: orderId,
    amount_cents: amount,
    currency: "USD",
  });
  if (result.status === 409) return { kind: "conflict" };
  if (result.status !== 200) fail("unavailable");
  if (!acceptedFor(result.body, orderId, amount, refundId)) return { kind: "conflict" };
  return { kind: "accepted" };
}

function canonicalAttachment(cap, lines) {
  return JSON.stringify({
    cap_cents: cap,
    lines: lines
      .map((line) => ({ line_id: line.line_id, price_cents: line.price_cents }))
      .sort((a, b) => a.line_id.localeCompare(b.line_id)),
  });
}

function attachmentMatches(state, cap, lines) {
  return canonicalAttachment(state.cap, state.lines) === canonicalAttachment(cap, lines);
}

function validateAttachment(value, amount) {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail("bad_lines");
  const cap = value.cap_cents;
  if (!Number.isSafeInteger(cap) || cap < 1 || cap > amount) fail("bad_lines");
  if (!Array.isArray(value.lines) || value.lines.length < 1 || value.lines.length > 20) fail("bad_lines");
  const seen = new Set();
  let total = 0;
  const lines = value.lines.map((line) => {
    if (!line || typeof line !== "object" || Array.isArray(line) || !validLineId(line.line_id)) fail("bad_lines");
    if (seen.has(line.line_id)) fail("bad_lines");
    seen.add(line.line_id);
    if (!Number.isSafeInteger(line.price_cents) || line.price_cents < 1 || line.price_cents > 100000000) fail("bad_lines");
    total += line.price_cents;
    return { line_id: line.line_id, price_cents: line.price_cents, refund: "none" };
  });
  if (total !== amount) fail("bad_lines");
  return { cap, lines };
}

function selectedLines(state, ids) {
  const byId = new Map(state.lines.map((line) => [line.line_id, line]));
  const selected = [];
  const seen = new Set();
  for (const id of ids) {
    if (!validLineId(id) || seen.has(id) || !byId.has(id)) fail("unknown_line");
    seen.add(id);
    selected.push(byId.get(id));
  }
  return selected.sort((a, b) => a.line_id.localeCompare(b.line_id));
}

function lineIds(lines) {
  return lines.map((line) => line.line_id).sort();
}

function sameIdSet(left, right) {
  const a = [...left].sort();
  const b = [...right].sort();
  return a.length === b.length && a.every((id, index) => id === b[index]);
}

function withPending(lines, ids) {
  const selected = new Set(ids);
  return lines.map((line) => selected.has(line.line_id) ? { ...line, refund: "pending" } : line);
}

function withRefunded(lines, ids) {
  const selected = new Set(ids);
  return lines.map((line) => selected.has(line.line_id) ? { ...line, refund: "refunded" } : line);
}

async function beginAttempt(machine, aggregate, state, ids, amount) {
  const pendingLines = state.lines.length === 0 ? [] : withPending(state.lines, ids);
  const refundId = "rf_" + randomUUID();
  const saved = await aggregate.command("begin_refund", {
    refund_id: refundId,
    attempt_lines_json: JSON.stringify(ids),
    attempt_amount_cents: amount,
    lines_json: JSON.stringify(pendingLines),
  });
  const current = saved instanceof HistoricalResult ? await machine.show(aggregate.id) : saved;
  crashAt("after-attempt-saved-before-request");
  return current;
}

async function markRefunded(machine, aggregate, state) {
  const ids = state.attemptLines;
  const lines = state.lines.length === 0 ? [] : withRefunded(state.lines, ids);
  const result = await aggregate.command("mark_refunded", {
    refunded_cents: state.refundedCents + state.attemptAmount,
    lines_json: JSON.stringify(lines),
    attempt_lines_json: "[]",
    attempt_amount_cents: 0,
  });
  return result instanceof HistoricalResult ? await machine.show(aggregate.id) : result;
}

async function completeAttempt(machine, aggregate, orderId, fresh) {
  const state = stateOf(aggregate);
  if (!fresh) {
    const lookup = await lookupRefund(orderId, state.attemptAmount, state.refundId);
    if (lookup.kind === "conflict") fail("conflict");
    if (lookup.kind === "accepted") return markRefunded(machine, aggregate, state);
  }
  const posted = await postRefund(orderId, state.attemptAmount, state.refundId);
  if (posted.kind === "conflict") fail("conflict");
  crashAt("after-accept-before-record");
  return markRefunded(machine, aggregate, state);
}

async function commandRecord(machine, orderId, amount) {
  let aggregate;
  try {
    aggregate = await machine.show(orderId);
  } catch (error) {
    if (error?.rule !== "aggregate.not_found" && error?.rule !== "store.missing") throw error;
  }
  if (aggregate) {
    const state = stateOf(aggregate);
    if (state.amount !== amount) fail("conflict");
    return outputRecord(orderId, aggregate);
  }
  const created = await machine.createWith({
    aggregateId: orderId,
    command: {
      name: "record",
      args: {
        amount_cents: amount,
        lines_json: "[]",
        attempt_lines_json: "[]",
        attempt_amount_cents: 0,
      },
    },
  });
  aggregate = created instanceof HistoricalResult ? await machine.show(orderId) : created;
  return outputRecord(orderId, aggregate);
}

async function commandAttach(machine, orderId, path) {
  const aggregate = await showOrder(machine, orderId);
  const state = stateOf(aggregate);
  if (state.state === "shipped") fail("shipped");
  if (state.state === "attempt_saved" || state.refundedCents > 0) fail("refund_open");
  let parsed;
  try {
    parsed = JSON.parse(await readFile(path, "utf8"));
  } catch {
    fail("bad_lines");
  }
  const attachment = validateAttachment(parsed, state.amount);
  if (state.lines.length > 0) {
    if (attachmentMatches(state, attachment.cap, attachment.lines)) {
      return {
        order_id: orderId,
        cap_cents: state.cap,
        lines: state.lines.map(({ line_id, price_cents, refund }) => ({ line_id, price_cents, refund })),
      };
    }
    fail("conflict");
  }
  const saved = await aggregate.command("attach", {
    cap_cents: attachment.cap,
    lines_json: JSON.stringify(attachment.lines),
  });
  const current = saved instanceof HistoricalResult ? await machine.show(orderId) : saved;
  const next = stateOf(current);
  return {
    order_id: orderId,
    cap_cents: next.cap,
    lines: next.lines.map(({ line_id, price_cents, refund }) => ({ line_id, price_cents, refund })),
  };
}

async function commandShip(machine, orderId) {
  const aggregate = await showOrder(machine, orderId);
  const state = stateOf(aggregate);
  if (state.state === "shipped") return outputRecord(orderId, aggregate);
  if (state.state === "attempt_saved" || state.refundedCents > 0) fail("refund_open");
  try {
    const shipped = await aggregate.command("ship");
    return outputRecord(orderId, shipped instanceof HistoricalResult ? await machine.show(orderId) : shipped);
  } catch (error) {
    if (error?.rule === "command.not_allowed" || error?.rule === "command.from") fail("refund_open");
    throw error;
  }
}

async function commandStatus(machine, orderId) {
  return outputRecord(orderId, await showOrder(machine, orderId));
}

async function commandRefund(machine, orderId, ids) {
  let aggregate = await showOrder(machine, orderId);
  let state = stateOf(aggregate);
  if (state.lines.length === 0) fail("not_attached");
  const selected = selectedLines(state, ids);
  if (state.state === "attempt_saved") {
    if (!sameIdSet(state.attemptLines, lineIds(selected))) fail("refund_open");
    aggregate = await completeAttempt(machine, aggregate, orderId, false);
    crashAt("after-record-before-exit");
    return outputRecord(orderId, aggregate);
  }
  if (state.state === "shipped") fail("shipped");
  if (selected.some((line) => line.refund === "refunded")) fail("already_refunded");
  const amount = selected.reduce((sum, line) => sum + line.price_cents, 0);
  if (state.refundedCents + amount > state.cap) fail("over_cap");
  aggregate = await beginAttempt(machine, aggregate, state, lineIds(selected), amount);
  state = stateOf(aggregate);
  aggregate = await completeAttempt(machine, aggregate, orderId, true);
  crashAt("after-record-before-exit");
  return outputRecord(orderId, aggregate);
}

async function commandCancel(machine, orderId) {
  let aggregate = await showOrder(machine, orderId);
  let state = stateOf(aggregate);
  if (state.state === "shipped") fail("shipped");
  if (state.state === "attempt_saved") {
    aggregate = await completeAttempt(machine, aggregate, orderId, false);
    crashAt("after-record-before-exit");
    return outputRecord(orderId, aggregate);
  }
  if (state.lines.length === 0) {
    if (state.refundedCents > 0) return outputRecord(orderId, aggregate);
    aggregate = await beginAttempt(machine, aggregate, state, [], state.amount);
    aggregate = await completeAttempt(machine, aggregate, orderId, true);
    crashAt("after-record-before-exit");
    return outputRecord(orderId, aggregate);
  }
  const remaining = state.lines.filter((line) => line.refund !== "refunded");
  if (remaining.length === 0) return outputRecord(orderId, aggregate);
  const amount = remaining.reduce((sum, line) => sum + line.price_cents, 0);
  if (state.refundedCents + amount > state.cap) fail("over_cap");
  aggregate = await beginAttempt(machine, aggregate, state, lineIds(remaining), amount);
  aggregate = await completeAttempt(machine, aggregate, orderId, true);
  crashAt("after-record-before-exit");
  return outputRecord(orderId, aggregate);
}

async function commandReconcile(machine, orderId) {
  let aggregate = await showOrder(machine, orderId);
  const state = stateOf(aggregate);
  if (state.state !== "attempt_saved") {
    return outputReconcile(orderId, aggregate, state.refundedCents > 0 ? "refunded" : "not_applicable");
  }
  const lookup = await lookupRefund(orderId, state.attemptAmount, state.refundId);
  if (lookup.kind === "conflict") fail("conflict");
  if (lookup.kind === "not_found") return outputReconcile(orderId, aggregate, "not_sent");
  aggregate = await markRefunded(machine, aggregate, state);
  crashAt("after-record-before-exit");
  return outputReconcile(orderId, aggregate, "refunded");
}

function mapRuntimeError(error) {
  if (error instanceof DeskError) return error.code;
  if (error?.rule === "aggregate.not_found") return "unknown_order";
  if (error?.code === "IK_OPERATION_CONFLICT") return "conflict";
  if (error?.outcome === "submission-unknown" || error?.outcome === "not-sent") return "unavailable";
  return "unavailable";
}

async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  const exact = { record: 3, ship: 2, cancel: 2, status: 2, reconcile: 2, attach: 3 };
  if (command === "refund") {
    if (args.length < 3) fail("bad_args");
  } else if (!exact[command] || args.length !== exact[command]) {
    fail("bad_args");
  }
  const orderId = args[1];
  if (!validId(orderId)) fail("bad_id");
  const { machine } = await openDesk();
  if (command === "record") {
    const amount = parseAmount(args[2]);
    if (amount === null) fail("bad_amount");
    return await commandRecord(machine, orderId, amount);
  }
  if (command === "attach") return await commandAttach(machine, orderId, args[2]);
  if (command === "ship") return await commandShip(machine, orderId);
  if (command === "cancel") return await commandCancel(machine, orderId);
  if (command === "status") return await commandStatus(machine, orderId);
  if (command === "refund") return await commandRefund(machine, orderId, args.slice(2));
  return await commandReconcile(machine, orderId);
}

main().then((result) => {
  process.stdout.write(JSON.stringify(result) + "\n");
}).catch((error) => {
  process.stdout.write(JSON.stringify({ error: mapRuntimeError(error) }) + "\n");
  process.exitCode = 1;
});
