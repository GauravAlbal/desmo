import assert from "node:assert/strict";
import { createServer } from "node:http";
import { spawn } from "node:child_process";
import { rmSync } from "node:fs";

const root = process.cwd();
const stateDir = "/tmp/plan-scheduler-tests";
const changeStateDir = "/tmp/plan-scheduler-change-tests";
const serviceUrl = "http://127.0.0.1:47500";
const baseEnv = { ...process.env, STATE_DIR: stateDir, SERVICE_URL: serviceUrl };
const accepted = new Map();
let effects = 0;
let dropReply = false;

function send(res, status, value) {
  const text = JSON.stringify(value);
  res.writeHead(status, { "content-type": "application/json", "content-length": Buffer.byteLength(text) });
  res.end(text);
}
async function body(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}
const server = createServer(async (req, res) => {
  const url = new URL(req.url, serviceUrl);
  if (req.method === "POST" && url.pathname === "/v1/plan-changes") {
    let value;
    try { value = await body(req); } catch { send(res, 400, { error: "bad_request" }); return; }
    const old = accepted.get(value.submission_id);
    if (old && JSON.stringify(old) !== JSON.stringify(value)) { send(res, 409, { error: "conflict" }); return; }
    if (!old) { accepted.set(value.submission_id, value); effects += 1; }
    if (dropReply) { dropReply = false; req.socket.destroy(); return; }
    send(res, 200, { ...(old ?? value), outcome: "applied" });
    return;
  }
  if (req.method === "GET" && url.pathname.startsWith("/v1/submissions/")) {
    const value = accepted.get(url.pathname.split("/").pop());
    if (!value) send(res, 404, { error: "not_found" });
    else send(res, 200, { ...value, outcome: "applied" });
    return;
  }
  send(res, 404, { error: "not_found" });
});
await new Promise((resolve) => server.listen(47500, "127.0.0.1", resolve));

function run(command, args, env = {}) {
  return new Promise((resolve) => {
    const crash = typeof env.CRASH_AT === "string";
    const child = spawn("./run", [command, ...args], {
      cwd: root,
      env: { ...baseEnv, ...env },
      stdio: crash ? "ignore" : ["ignore", "pipe", "pipe"],
    });
    let stdout = "";
    let stderr = "";
    if (!crash) {
      child.stdout.on("data", (chunk) => { stdout += chunk; });
      child.stderr.on("data", (chunk) => { stderr += chunk; });
    }
    child.on("close", (status, signal) => {
      let json;
      if (stdout.trim()) json = JSON.parse(stdout);
      resolve({ status, signal, stdout, stderr, json });
    });
  });
}
async function ok(command, args, env) {
  const result = await run(command, args, env);
  assert.equal(result.status, 0, `${command}: ${result.stderr}`);
  assert.ok(result.json);
  return result.json;
}
async function refused(command, args, code, env) {
  const result = await run(command, args, env);
  assert.notEqual(result.status, 0);
  assert.equal(result.json.error, code);
  return result;
}

try {
  rmSync(stateDir, { recursive: true, force: true });
  const empty = await ok("status", [], { NOW_MS: "0" });
  assert.equal(empty.invoice_id, null);
  assert.equal(empty.invoice, "none");
  assert.equal(empty.amount_cents, null);
  await ok("open", ["test-account", "basic", "0"], { NOW_MS: "0" });
  const scheduled = await ok("schedule", ["plus"], { NOW_MS: "0" });
  assert.equal((await ok("status", [], { NOW_MS: "0" })).change_id, scheduled.change_id);
  await refused("apply", [], "not_due", { NOW_MS: "1" });

  const before = await run("apply", [], { NOW_MS: String(scheduled.effective_at_ms), CRASH_AT: "after-attempt-saved-before-request" });
  assert.equal(before.signal, "SIGKILL");
  let state = await ok("status", [], { NOW_MS: String(scheduled.effective_at_ms) });
  assert.equal(state.submission, "attempt_saved");
  assert.equal(effects, 0);
  await ok("apply", [], { NOW_MS: String(scheduled.effective_at_ms) });
  assert.equal(effects, 1);

  const second = await ok("schedule", ["pro"], { NOW_MS: String(scheduled.effective_at_ms) });
  const afterAccept = await run("apply", [], { NOW_MS: String(second.effective_at_ms), CRASH_AT: "after-accept-before-record" });
  assert.equal(afterAccept.signal, "SIGKILL");
  state = await ok("status", [], { NOW_MS: String(second.effective_at_ms) });
  assert.equal(state.submission, "attempt_saved");
  assert.equal(effects, 2);
  await ok("apply", [], { NOW_MS: String(second.effective_at_ms) });
  assert.equal(effects, 2);

  const third = await ok("schedule", ["basic"], { NOW_MS: String(second.effective_at_ms) });
  dropReply = true;
  const lost = await run("apply", [], { NOW_MS: String(third.effective_at_ms) });
  assert.notEqual(lost.status, 0);
  assert.equal(lost.json.error, "service_unavailable");
  state = await ok("status", [], { NOW_MS: String(third.effective_at_ms) });
  assert.equal(state.submission, "attempt_saved");
  assert.equal(effects, 3);
  const reconciliationCrash = await run("reconcile", [state.submission_id], { NOW_MS: String(third.effective_at_ms), CRASH_AT: "after-record-before-exit" });
  assert.equal(reconciliationCrash.signal, "SIGKILL");
  state = await ok("status", [], { NOW_MS: String(third.effective_at_ms) });
  assert.equal(state.submission, "applied");
  assert.equal(effects, 3);
  const reconciled = await ok("reconcile", [state.submission_id], { NOW_MS: String(third.effective_at_ms) });
  assert.equal(reconciled.lookup, "applied");
  assert.equal(effects, 3);

  const fourth = await ok("schedule", ["plus"], { NOW_MS: String(third.effective_at_ms) });
  const afterRecord = await run("apply", [], { NOW_MS: String(fourth.effective_at_ms), CRASH_AT: "after-record-before-exit" });
  assert.equal(afterRecord.signal, "SIGKILL");
  state = await ok("status", [], { NOW_MS: String(fourth.effective_at_ms) });
  assert.equal(state.submission, "applied");
  assert.equal(effects, 4);
  await ok("apply", [], { NOW_MS: String(fourth.effective_at_ms) });
  assert.equal(effects, 4);
  rmSync(changeStateDir, { recursive: true, force: true });
  const changeEnv = { STATE_DIR: changeStateDir };
  await ok("open", ["change-account", "plus", "0"], { ...changeEnv, NOW_MS: "0" });
  const unpaid = await ok("invoice", ["inv-1", "2500"], { ...changeEnv, NOW_MS: "0" });
  await refused("invoice", ["inv-2", "3000"], "invoice_exists", { ...changeEnv, NOW_MS: "0" });
  assert.deepEqual(unpaid, { invoice_id: "inv-1", amount_cents: 2500, invoice: "unpaid" });
  let changeStatus = await ok("status", [], { ...changeEnv, NOW_MS: "0" });
  assert.equal(changeStatus.invoice, "unpaid");
  assert.equal(changeStatus.amount_cents, 2500);
  await refused("schedule", ["basic"], "unpaid_downgrade", { ...changeEnv, NOW_MS: "0" });
  const higher = await ok("schedule", ["pro"], { ...changeEnv, NOW_MS: "0" });
  await refused("replace", ["basic"], "unpaid_downgrade", { ...changeEnv, NOW_MS: "0" });
  changeStatus = await ok("status", [], { ...changeEnv, NOW_MS: "0" });
  assert.equal(changeStatus.change_id, higher.change_id);
  assert.equal(changeStatus.to_plan, "pro");
  await ok("cancel", [higher.change_id], { ...changeEnv, NOW_MS: "0" });

  rmSync(changeStateDir, { recursive: true, force: true });
  await ok("open", ["replace-account", "plus", "0"], { ...changeEnv, NOW_MS: "0" });
  const lower = await ok("schedule", ["basic"], { ...changeEnv, NOW_MS: "0" });
  await ok("invoice", ["inv-2", "500"], { ...changeEnv, NOW_MS: "0" });
  const replaced = await ok("replace", ["pro"], { ...changeEnv, NOW_MS: "0" });
  assert.notEqual(replaced.change_id, lower.change_id);
  assert.equal(replaced.to_plan, "pro");
  assert.equal(replaced.effective_at_ms, lower.effective_at_ms);
  await refused("cancel", [lower.change_id], "change_mismatch", { ...changeEnv, NOW_MS: "0" });
  changeStatus = await ok("status", [], { ...changeEnv, NOW_MS: "0" });
  assert.equal(changeStatus.change_id, replaced.change_id);
  assert.equal(changeStatus.to_plan, "pro");

  rmSync(changeStateDir, { recursive: true, force: true });
  await ok("open", ["apply-account", "plus", "0"], { ...changeEnv, NOW_MS: "0" });
  const downgrade = await ok("schedule", ["basic"], { ...changeEnv, NOW_MS: "0" });
  await ok("invoice", ["inv-3", "1000"], { ...changeEnv, NOW_MS: "0" });
  const beforeBlockedApply = effects;
  await refused("apply", [], "unpaid_downgrade", { ...changeEnv, NOW_MS: String(downgrade.effective_at_ms) });
  changeStatus = await ok("status", [], { ...changeEnv, NOW_MS: String(downgrade.effective_at_ms) });
  assert.equal(changeStatus.submission, "none");
  assert.equal(changeStatus.to_plan, "basic");
  assert.equal(effects, beforeBlockedApply);
  await ok("pay", ["inv-3"], { ...changeEnv, NOW_MS: String(downgrade.effective_at_ms) });
  await ok("apply", [], { ...changeEnv, NOW_MS: String(downgrade.effective_at_ms) });
  assert.equal(effects, beforeBlockedApply + 1);
  await ok("apply", [], { ...changeEnv, NOW_MS: String(downgrade.effective_at_ms) });
  assert.equal(effects, beforeBlockedApply + 1);
  await ok("pay", ["inv-3"], { ...changeEnv, NOW_MS: String(downgrade.effective_at_ms) });
  await ok("invoice", ["inv-4", "2000"], { ...changeEnv, NOW_MS: String(downgrade.effective_at_ms) });
  console.log("scheduler lifecycle and invoice tests passed");
} finally {
  server.closeAllConnections();
  await new Promise((resolve) => server.close(resolve));
}
