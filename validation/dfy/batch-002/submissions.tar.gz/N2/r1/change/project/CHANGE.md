# Change: unpaid invoice blocks a lower plan

The scheduler you are maintaining already implements the plan-change brief. Requirements R1 through R14 stay when no unpaid invoice is recorded. This change adds two commands and requirements C1, C2, and C3. It revises R2, R3, and the due apply path in R5 only while an invoice is unpaid, and only as stated here. It does not rename fields.

An unpaid invoice is a local record. It is not sent to the billing provider. Paying it marks the local record paid. It does not capture a card and does not call the provider.

Plan rank is fixed: basic 1, plus 2, pro 3. A lower-plan target has a smaller rank than the current plan. A higher-plan target has a larger rank. The same plan is still same_plan.

While invoice is unpaid, the tool must refuse a lower-plan target at three doors, and a refusal at any door must not throw away a pending change that was already legal:

- schedule of a lower plan is refused. No pending change is created. The provider is not contacted.
- replace whose new target is a lower plan is refused. The existing pending change id, to_plan, and effective_at_ms stay as they were. The provider is not contacted. A pending higher plan must survive this refusal. Replacing a pending lower plan with a higher plan remains allowed.
- apply of a pending lower plan is refused when no attempt has been saved. The attempt is not saved. The provider is not contacted. The pending lower plan remains, so it can be applied after the invoice is paid or replaced by a higher plan before that.

If apply is not yet due, the refusal is still not_due. The unpaid gate on apply is checked only when the change is due and no attempt has been saved. The gate does not apply when invoice is none or paid. It does not apply to apply or reconcile once submission is attempt_saved or applied: an effect the provider already accepted is still adopted by lookup, and a saved submission id is not replaced. cancel is unchanged.

A downgrade is a target whose rank is lower than the current plan. The refusal code is unpaid_downgrade.

`status` gains three fields, present even when no invoice is recorded:

```json
{"invoice_id":null,"invoice":"none","amount_cents":null}
```

`invoice` is `none`, `unpaid`, or `paid`.

## Commands

### `./run invoice <invoice_id> <amount_cents>`

Record one unpaid invoice on the open account. `amount_cents` is a canonical integer from `1` through `100000000`. Do not contact the provider.

Success, exit 0:

```json
{"invoice_id":"...","amount_cents":2500,"invoice":"unpaid"}
```

Refuse `not_open` if the store is not open, `bad_amount` if the amount is not in range, and `invoice_exists` if an unpaid invoice is already recorded. A refusal does not change the store and does not contact the provider. A paid invoice may be replaced by a new `invoice` command; the new record is unpaid.

### `./run pay <invoice_id>`

Mark the recorded invoice paid. Do not contact the provider.

Success, exit 0:

```json
{"invoice_id":"...","amount_cents":2500,"invoice":"paid"}
```

Refuse `no_invoice` if none is recorded, and `invoice_mismatch` if the id differs. A second `pay` of the same paid id exits 0 and leaves the record paid.

## Requirements

C1. An unpaid invoice blocks a new downgrade and does not block an upgrade. After `open` on `plus` and `invoice` of a positive amount, `schedule basic` exits nonzero `unpaid_downgrade`, leaves `pending` `none` and the current plan `plus`, and does not send a plan-change request. `schedule pro` then exits 0, with `to_plan` `pro` and `pending` `scheduled`, and still does not send a plan-change request.

C2. Replacement interacts with the unpaid rule. After `open` on `plus`, `schedule pro`, and `invoice`, `replace basic` exits nonzero `unpaid_downgrade`. The pending change id, `to_plan` `pro`, and `effective_at_ms` are unchanged, and the provider is not contacted. Separately, after `open` on `plus`, `schedule basic` while no invoice exists, and then `invoice`, `replace pro` exits 0. The new change id differs from the earlier change id, `to_plan` is `pro`, `effective_at_ms` is unchanged, cancelling the old change id does not remove the new pending change, and the provider is not contacted.

C3. Apply interacts with the unpaid rule. After a downgrade is scheduled while no invoice exists, an unpaid invoice is recorded, and `NOW_MS` is the effective time, `apply` exits nonzero `unpaid_downgrade`, leaves `submission` `none` and the pending downgrade in place, and does not send a plan-change request. `pay` of that invoice does not send a plan-change request. A following `apply` against a healthy provider exits 0, `current_plan` is the downgrade target, and the provider counts exactly one effect. A second `apply` does not add an effect.
