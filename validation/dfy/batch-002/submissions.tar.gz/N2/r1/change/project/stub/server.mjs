import { createServer } from "node:http";

const PLANS = new Set(["basic", "plus", "pro"]);
const submissions = new Map();
const latest = new Map();
const effects = [];
const posts = [];
const callbacks = [];
let fault = {
  drop_reply: false,
  delay_ms: 0,
  error_status: 0,
  duplicate_callback: false,
  conflict_plan: null,
};

function send(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    "content-type": "application/json",
    "content-length": Buffer.byteLength(body),
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let n = 0;
    req.on("data", (chunk) => {
      n += chunk.length;
      if (n > 1_000_000) {
        reject(new Error("too_big"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function samePayload(stored, body) {
  return stored.account_id === body.account_id
    && stored.from_plan === body.from_plan
    && stored.to_plan === body.to_plan
    && stored.effective_at_ms === body.effective_at_ms;
}

function validBody(body) {
  if (!body || typeof body !== "object") return false;
  if (typeof body.submission_id !== "string" || body.submission_id.length === 0) return false;
  if (typeof body.account_id !== "string" || body.account_id.length === 0) return false;
  if (!PLANS.has(body.from_plan) || !PLANS.has(body.to_plan)) return false;
  if (body.from_plan === body.to_plan) return false;
  if (!Number.isSafeInteger(body.effective_at_ms)) return false;
  return true;
}

function callbackFor(stored) {
  return {
    callback_id: "cb-" + stored.submission_id,
    submission_id: stored.submission_id,
    account_id: stored.account_id,
    to_plan: stored.to_plan,
    effective_at_ms: stored.effective_at_ms,
    outcome: "applied",
  };
}

async function finishPost(res, status, obj, dropped) {
  await wait(fault.delay_ms);
  if (dropped || (fault.drop_reply && status === 200)) {
    res.socket.destroy();
    return;
  }
  send(res, status, obj);
}

async function handlePlanChange(req, res) {
  const type = String(req.headers["content-type"] || "");
  let parsed = null;
  let text = "";
  try {
    text = await readBody(req);
    parsed = JSON.parse(text);
  } catch {
    parsed = null;
  }
  if (!type.includes("application/json") || !validBody(parsed)) {
    posts.push({
      submission_id: parsed && parsed.submission_id || null,
      account_id: parsed && parsed.account_id || null,
      from_plan: parsed && parsed.from_plan || null,
      to_plan: parsed && parsed.to_plan || null,
      effective_at_ms: parsed && parsed.effective_at_ms || null,
      http_status: 400,
      dropped: false,
    });
    send(res, 400, { error: "bad_request" });
    return;
  }
  if (fault.error_status >= 500) {
    posts.push({
      submission_id: parsed.submission_id,
      account_id: parsed.account_id,
      from_plan: parsed.from_plan,
      to_plan: parsed.to_plan,
      effective_at_ms: parsed.effective_at_ms,
      http_status: fault.error_status,
      dropped: fault.drop_reply === true,
    });
    await finishPost(res, fault.error_status, { error: "unavailable" }, fault.drop_reply);
    return;
  }
  const existing = submissions.get(parsed.submission_id);
  if (existing) {
    if (!samePayload(existing, parsed)) {
      posts.push({
        submission_id: parsed.submission_id,
        account_id: parsed.account_id,
        from_plan: parsed.from_plan,
        to_plan: parsed.to_plan,
        effective_at_ms: parsed.effective_at_ms,
        http_status: 409,
        dropped: false,
      });
      send(res, 409, { error: "conflict" });
      return;
    }
    const dropped = fault.drop_reply === true;
    posts.push({
      submission_id: existing.submission_id,
      account_id: existing.account_id,
      from_plan: existing.from_plan,
      to_plan: existing.to_plan,
      effective_at_ms: existing.effective_at_ms,
      http_status: 200,
      dropped,
    });
    await finishPost(res, 200, existing, dropped);
    return;
  }
  const stored = {
    submission_id: parsed.submission_id,
    account_id: parsed.account_id,
    from_plan: parsed.from_plan,
    to_plan: parsed.to_plan,
    effective_at_ms: parsed.effective_at_ms,
    outcome: "applied",
  };
  submissions.set(stored.submission_id, stored);
  latest.set(stored.account_id, stored);
  effects.push(stored);
  callbacks.push(callbackFor(stored));
  const dropped = fault.drop_reply === true;
  posts.push({
    submission_id: stored.submission_id,
    account_id: stored.account_id,
    from_plan: stored.from_plan,
    to_plan: stored.to_plan,
    effective_at_ms: stored.effective_at_ms,
    http_status: 200,
    dropped,
  });
  await finishPost(res, 200, stored, dropped);
}

function handleData(req, res) {
  const url = new URL(req.url, "http://127.0.0.1");
  if (req.method === "POST" && url.pathname === "/v1/plan-changes") {
    handlePlanChange(req, res).catch(() => {
      if (!res.headersSent) send(res, 400, { error: "bad_request" });
    });
    return;
  }
  if (req.method === "GET" && url.pathname.startsWith("/v1/submissions/")) {
    const id = decodeURIComponent(url.pathname.slice("/v1/submissions/".length));
    const stored = submissions.get(id);
    if (!stored) send(res, 404, { error: "not_found" });
    else send(res, 200, stored);
    return;
  }
  if (req.method === "GET" && url.pathname.startsWith("/v1/accounts/")) {
    const id = decodeURIComponent(url.pathname.slice("/v1/accounts/".length));
    const stored = latest.get(id);
    if (!stored) send(res, 404, { error: "not_found" });
    else send(res, 200, stored);
    return;
  }
  send(res, 404, { error: "not_found" });
}

function callbackList() {
  const list = callbacks.slice();
  if (fault.duplicate_callback) list.push(...callbacks);
  if (fault.conflict_plan) {
    list.push({
      callback_id: "cb-conflict",
      submission_id: "conflict",
      account_id: "conflict",
      to_plan: fault.conflict_plan,
      effective_at_ms: 0,
      outcome: "applied",
    });
  }
  return list;
}

async function handleControl(req, res) {
  const url = new URL(req.url, "http://127.0.0.1");
  if (req.method === "POST" && url.pathname === "/fault") {
    let body = {};
    try { body = JSON.parse(await readBody(req) || "{}"); } catch { body = {}; }
    fault = {
      drop_reply: body.drop_reply === true,
      delay_ms: Number.isInteger(body.delay_ms) && body.delay_ms >= 0 ? body.delay_ms : 0,
      error_status: Number.isInteger(body.error_status) ? body.error_status : 0,
      duplicate_callback: body.duplicate_callback === true,
      conflict_plan: typeof body.conflict_plan === "string" ? body.conflict_plan : null,
    };
    send(res, 200, fault);
    return;
  }
  if (req.method === "GET" && url.pathname === "/effects") {
    send(res, 200, { count: effects.length, effects });
    return;
  }
  if (req.method === "GET" && url.pathname === "/posts") {
    send(res, 200, { count: posts.length, posts });
    return;
  }
  if (req.method === "GET" && url.pathname === "/callbacks") {
    const list = callbackList();
    send(res, 200, { callbacks: list });
    return;
  }
  if (req.method === "GET" && url.pathname === "/health") {
    send(res, 200, { ok: true });
    return;
  }
  send(res, 404, { error: "not_found" });
}

const data = createServer(handleData);
const control = createServer((req, res) => {
  handleControl(req, res).catch(() => {
    if (!res.headersSent) send(res, 400, { error: "bad_request" });
  });
});

data.listen(0, "127.0.0.1", () => {
  control.listen(0, "127.0.0.1", () => {
    const line = {
      service_url: "http://127.0.0.1:" + data.address().port,
      control_url: "http://127.0.0.1:" + control.address().port,
    };
    process.stdout.write(JSON.stringify(line) + "\n");
  });
});
