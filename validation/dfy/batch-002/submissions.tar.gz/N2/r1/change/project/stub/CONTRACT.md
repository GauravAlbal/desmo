# Billing provider contract

The scheduler calls this provider at `SERVICE_URL` (no trailing slash). The runnable server is `stub/server.mjs`:

```text
node server.mjs
```

It listens on `127.0.0.1` and prints one JSON line on stdout, then serves until killed:

```json
{"service_url":"http://127.0.0.1:PORT","control_url":"http://127.0.0.1:CPORT"}
```

State is in memory for that process only. Restarting the server drops every plan change.

## Data plane

### `POST /v1/plan-changes`

`Content-Type: application/json`

```json
{"submission_id":"...","account_id":"...","from_plan":"basic","to_plan":"plus","effective_at_ms":2592000000}
```

`submission_id` and `account_id` are non-empty strings. `from_plan` and `to_plan` are `basic`, `plus`, or `pro`. `effective_at_ms` is a JSON integer in the safe integer range. `from_plan` and `to_plan` must differ.

Responses:

- HTTP 400 `{"error":"bad_request"}` if a required field is missing, a plan is unknown, the effective time is not an integer, the content type is not JSON, or `from_plan` equals `to_plan`. Nothing is stored.
- HTTP 200 if this `submission_id` is new, or if it was already accepted with the same account, plans, and effective time:

```json
{"submission_id":"...","account_id":"...","from_plan":"basic","to_plan":"plus","effective_at_ms":2592000000,"outcome":"applied"}
```

The first acceptance stores the change as the latest plan change for that account and counts one plan-change effect. A repeat of the same id and the same fields returns the stored result and does not count another effect.

- HTTP 409 `{"error":"conflict"}` if this `submission_id` was already accepted with a different account, plan, or effective time. The stored effect is unchanged.

A different `submission_id` always counts as another effect, even if the plans are identical, and becomes the latest plan change for that account.

### `GET /v1/submissions/<submission_id>`

HTTP 200 with the stored plan-change object, or HTTP 404 `{"error":"not_found"}` if that id was never accepted.

### `GET /v1/accounts/<account_id>`

HTTP 200 with the latest accepted plan change for that account, or HTTP 404 `{"error":"not_found"}` if none.

Ids in paths are from `A-Za-z0-9._-`, so they need no extra encoding. Other characters are not part of the scheduler contract.

## Callback shape

The provider does not call the scheduler. An operator (or an acceptance harness) delivers this JSON in a file:

```json
{"callback_id":"...","submission_id":"...","account_id":"...","to_plan":"plus","effective_at_ms":2592000000,"outcome":"applied"}
```

`outcome` is `applied` or `rejected`. `effective_at_ms` is a JSON number. The same object may be delivered more than once. A later object may name a different `to_plan` or `outcome` for a submission the provider already accepted.

On each new effect the server keeps one callback body, available from the control port, with `callback_id` set to `cb-` plus the submission id and `outcome` `applied`. That list is a convenience for the harness. The scheduler never reads the control port.

## Idempotency and lookup

Identity of an effect is `submission_id`. Lookup by submission id returns the acceptance even when the HTTP client never saw the response. Lookup by account id returns only the latest acceptance, so it is the wrong check for whether a second effect happened.

