# Plan-change scheduler

A local tool records one customer's subscription plan and the plan change that should take effect at the next billing-cycle boundary. The operator can schedule that change, replace it with a newer target before it is sent, cancel it before it is sent, and apply it by asking a billing provider to record the change. The provider must be asked at most once for a given submission. A reply can be lost. A later lookup adopts the provider's record and does not send the change again.

You own the program behind `./run`. The billing provider is supplied. Its HTTP API is specified below and, with the same rules, in `stub/CONTRACT.md`.

## Scope

- One machine, one state directory, one tool process at a time.
- One account id for the life of that state directory. A second account id is refused.
- The operator does not run two `./run` processes at once. An unrelated process may write other files in the state directory between commands, and may do so while a command runs.
- No distributed transaction, no payment capture, no proration, no tax, and no second billing provider.
- The tool does not read the wall clock. The only clock is the supplied `NOW_MS` value for that invocation. It does not advance during the invocation.
- Choosing an effective time other than the next cycle boundary is out of scope.
- A well-formed plan-change request is accepted by the supplied provider. Coping with a dropped reply, a held reply, an HTTP 5xx that stores nothing, and a callback delivered twice or in conflict with a recorded outcome is in scope. Those conditions are properties of the provider, described in the service section.

## How to run

`./run` is executable. Each invocation is one process:

```text
./run <command> [args]
```

The process prints exactly one JSON object on stdout and nothing else. A single trailing newline is allowed. Exit 0 means the command completed. A refusal is a nonzero exit and a JSON object whose `error` value is one of the codes in this brief. Extra JSON fields are allowed. Field names and values named below are required. stderr is ignored by acceptance checks.

Environment:

- `STATE_DIR` — directory for the durable store. The tool may create it. A new process with the same `STATE_DIR` sees every record the previous process committed. The tool chooses its own filenames inside `STATE_DIR` and must leave every other file there unchanged. It must not remove, truncate, or replace a file it did not create.
- `SERVICE_URL` — billing provider base URL, with no trailing slash. Example: `http://127.0.0.1:9`. Required for every command. `status` still must not contact the provider.
- `NOW_MS` — the clock. A canonical integer in the range `0` through `9007199254740991`: either `0` or decimal digits with no leading zero. Missing is `missing_clock`. Anything else is `bad_clock`.
- `CRASH_AT` — optional. When the running command reaches the named boundary, the process must kill itself with `SIGKILL` so it cannot catch the signal and continue. If the command never reaches that boundary, it must not kill itself.

Committed means a later process with the same `STATE_DIR` can read the record after `SIGKILL`. Flush the record to disk before treating it as committed. A refusal must not change the durable store, except `service_unavailable` after an attempt has already been committed, which leaves that attempt in place.

If the store file exists but is not readable as one JSON object, the command exits nonzero with `corrupt_state` and does not rewrite the file. That case is not separately scored.

### Crash boundaries

`after-attempt-saved-before-request`
On `apply`, after the attempt record (submission id, account id, change id, from-plan, to-plan, and effective time) is committed, and before any byte of the plan-change HTTP request is sent. Not on a later `apply` that finds the attempt already saved.

`after-accept-before-record`
On `apply`, after the provider has accepted the plan change and this process has read the complete HTTP response body, and before the durable applied outcome is committed. Not on a lookup that only reads an acceptance performed by an earlier process.

`after-record-before-exit`
On `apply` or `reconcile`, after this invocation commits the applied outcome, and before the success JSON is written and the process exits. Not on a command that found the outcome already committed.

## Identifiers, plans, and the cycle

- Account id, change id, submission id, invoice id, and callback id: 1 to 64 characters from `A-Za-z0-9._-`. The tool chooses change ids and submission ids. The operator chooses account ids.
- Plans are exactly `basic`, `plus`, and `pro`. Any other plan string is `unknown_plan`.
- Cycle length is `2592000000` milliseconds. The operator supplies the cycle anchor at `open`. It is a canonical integer in the same range as `NOW_MS`.

The next cycle boundary is computed only at `schedule`:

- If `NOW_MS < cycle_anchor_ms`, `effective_at_ms` is `cycle_anchor_ms`.
- Otherwise `effective_at_ms` is `cycle_anchor_ms + 2592000000 * (floor((NOW_MS - cycle_anchor_ms) / 2592000000) + 1)`.

That value is always strictly greater than `NOW_MS`. If it is not a safe integer, `schedule` refuses with `bad_clock` and writes nothing. `replace` does not recompute it.

Examples:

- Anchor `0`, `NOW_MS` `0`, schedule: `effective_at_ms` is `2592000000`. Apply becomes due when `NOW_MS` is `2592000000`.
- Anchor `100`, `NOW_MS` `50`, schedule: `effective_at_ms` is `100`.
- Anchor `0`, `NOW_MS` `2592000000`, schedule: `effective_at_ms` is `5184000000`.

Paths are used as given. Relative paths are relative to the process working directory.

## Commands

### `./run open <account_id> <plan> <cycle_anchor_ms>`

Bind the store to `account_id`, set the current plan, and record the cycle anchor. There is no pending change and no submission.

Success, exit 0:

```json
{"account_id":"...","current_plan":"basic","cycle_anchor_ms":0,"pending":"none","submission":"none"}
```

Refuse `already_open` if the store is already bound, including a repeat of the same account id. Refuse `unknown_plan` or `bad_args` without binding. A refusal leaves the store unbound, or leaves the existing binding unchanged.

### `./run schedule <plan>`

Require an open store and no pending change. Refuse `same_plan` if `plan` is the current plan. Refuse `pending_exists` if a change is already pending; the operator must `replace` or `cancel`. Allocate a new change id. Set `from_plan` to the current plan, `to_plan` to `plan`, and `effective_at_ms` to the next cycle boundary. `submission` stays `none` and `submission_id` stays null. Do not contact the provider.

Success, exit 0:

```json
{"change_id":"...","account_id":"...","from_plan":"basic","to_plan":"plus","effective_at_ms":2592000000,"pending":"scheduled","submission":"none","submission_id":null}
```

### `./run replace <plan>`

Allowed only when a change is pending, `submission` is `none`, and `NOW_MS < effective_at_ms`.

Keep the same `effective_at_ms`, `account_id`, and `from_plan`. Allocate a new change id, different from the previous change id. Set `to_plan` to `plan`. Forget the previous change id; it must not remain as a hidden pending change. Do not contact the provider.

Success uses the same JSON shape as `schedule`.

Refuse, without changing the pending change:

- `no_pending` if nothing is pending.
- `attempt_saved` if a submission attempt has been saved. After a successful apply, nothing is pending, so `replace` is `no_pending`.
- `already_due` if `NOW_MS >= effective_at_ms`, even when the attempt has not been saved. Cancel or apply; do not replace a due change.
- `unknown_plan`, `same_plan` (the target is the current plan), or `same_target` (the target is already the pending `to_plan`).

### `./run cancel <change_id>`

Allowed when that change id is the pending change and `submission` is `none`, including when `NOW_MS >= effective_at_ms` but the change has not been sent. Clear the pending change. Keep the current plan. Do not contact the provider. The cancelled change id must not remain pending.

Success, exit 0:

```json
{"account_id":"...","change_id":"...","current_plan":"basic","pending":"none","submission":"none"}
```

`change_id` in that object is the id that was cancelled.

Refuse `no_pending`, `attempt_saved`, or `change_mismatch` without changing the store. A mismatched id leaves the pending change in place.

### `./run apply`

Ask the provider to apply the pending change, at most once.

If `submission` is `applied` and nothing is pending, exit 0 with the applied object below and do not contact the provider.

If an attempt is already saved, keep that submission id. Do not re-check `not_due`. Query `GET /v1/submissions/<submission_id>`. If the provider has accepted it, commit the applied outcome and do not POST. If the provider answers HTTP 404, POST the saved submission id. Do not allocate a different submission id.

If no attempt is saved:

- Refuse `no_pending` if nothing is pending. Do not contact the provider.
- Refuse `not_due` if `NOW_MS < effective_at_ms`. Do not contact the provider. Leave the pending change in place.
- Otherwise allocate a submission id, commit the attempt (`submission` `attempt_saved` plus the ids and plan fields), then honor `after-attempt-saved-before-request`, then POST once.

POST body, `Content-Type: application/json`:

```json
{"submission_id":"...","account_id":"...","from_plan":"basic","to_plan":"plus","effective_at_ms":2592000000}
```

The fields are the saved attempt, not a fresh reading of a file. After the complete response body is read, honor `after-accept-before-record`. If the response names the same submission id, account id, to-plan, and effective time, with `outcome` `applied`, commit the applied outcome: `current_plan` becomes `to_plan`, `pending` becomes `none`, `submission` becomes `applied`, and `applied_plan` is `to_plan`. Then honor `after-record-before-exit` and print:

```json
{"account_id":"...","change_id":"...","submission_id":"...","from_plan":"basic","to_plan":"plus","effective_at_ms":2592000000,"current_plan":"plus","pending":"none","submission":"applied","applied_plan":"plus"}
```

If the connection fails or closes before a complete response, `apply` must exit nonzero with `service_unavailable`, must leave the attempt record in place, and must not mark `applied` in that invocation. It must not POST a different submission id. It must not look up the submission and adopt an outcome in that same invocation. `reconcile` is the command that adopts a lost acceptance.

If the provider returns HTTP 5xx, it has not applied the change. `apply` exits nonzero with `service_unavailable`, leaves the attempt in place, and does not allocate a new submission id. A held response is still the in-flight submission: this invocation must not start a second submission while it waits. HTTP 5xx and hold are not separately scored.

A response that does not match the saved attempt is `lookup_conflict` or `service_unavailable`, does not change the attempt, and does not allocate a new submission id.

### `./run reconcile <submission_id>`

Resolve an uncertain submission by lookup. This command must not POST, must not allocate a submission id, and must not send the plan change again.

- No saved submission id: exit nonzero `no_attempt`. Do not contact the provider.
- `submission_id` is not the saved id: exit nonzero `submission_mismatch`. Do not contact the provider. Do not change the store.
- Already `applied` for that id: exit 0 with `"lookup":"applied"` and the applied fields. Do not POST. Do not change the plan.
- Lookup HTTP 200 with the same submission id, account id, to-plan, and effective time, and `outcome` `applied`: commit the applied outcome if it is not already committed, honor `after-record-before-exit` if this invocation committed it, and exit 0 with `"lookup":"applied"`. Do not POST.
- Lookup HTTP 404: exit 0 with `"lookup":"not_sent"`, the saved `submission_id`, and `"submission":"attempt_saved"`. Leave the attempt record in place. Do not mark `applied`. `not_sent` means only that this lookup returned HTTP 404.
- Lookup HTTP 200 whose account, to-plan, effective time, or submission id differs from the saved attempt: do not change the local outcome; exit nonzero `lookup_conflict`. Do not POST.
- The provider cannot be contacted: exit nonzero `service_unavailable`. Do not change the attempt. Do not report `not_sent`.

### `./run status`

Print the committed local record. Do not contact the provider. Do not modify an existing store. On an empty store, exit 0:

```json
{"account_id":null,"current_plan":null,"cycle_anchor_ms":null,"change_id":null,"from_plan":null,"to_plan":null,"effective_at_ms":null,"pending":"none","submission":"none","submission_id":null,"applied_plan":null}
```

After work exists, the same fields are present. `pending` is `none` or `scheduled`. `submission` is `none`, `attempt_saved`, or `applied`. `applied_plan` is the plan recorded as applied, or null when `submission` is not `applied`. Integer fields are JSON numbers, not strings. Null fields are JSON null.

### `./run callback <callback_path>`

The file contains one JSON callback object (shape below). A well-formed callback exits 0:

```json
{"callback":"accepted"}
```

- If `submission` is `applied`, do not change `current_plan`, `applied_plan`, `pending`, or `submission`, whether the callback repeats the same plan or names a different `to_plan` or `outcome`.
- A callback must not cause a POST and must not allocate a submission id.
- A callback for another account id, or for a submission id that is not the saved attempt, does not change the store.
- The tool may ignore a callback entirely. Ignoring a well-formed callback still exits 0.
- A callback must not by itself mark `applied`. Adopting a provider result remains the job of `apply` (when it saw the POST response) or `reconcile` (when it looked the submission up).

A malformed file (not one JSON object, or missing a required callback field, or an `outcome` other than `applied` or `rejected`) exits nonzero `bad_callback`.

## Billing provider

`SERVICE_URL` has no trailing slash. The tool uses only these routes. The same rules are in `stub/CONTRACT.md`. The tool must not depend on the evaluator control port.

`POST /v1/plan-changes` with `Content-Type: application/json` and the body shown under `apply`.

- Missing fields, an unknown plan, a non-integer `effective_at_ms`, or `from_plan` equal to `to_plan`: HTTP 400 `{"error":"bad_request"}`. Nothing is stored.
- The first time a `submission_id` is accepted, the provider records that plan change for that account and counts one plan-change effect. Response HTTP 200:

```json
{"submission_id":"...","account_id":"...","from_plan":"basic","to_plan":"plus","effective_at_ms":2592000000,"outcome":"applied"}
```

- The same `submission_id` with the same account, plans, and effective time returns the same result and does not count another effect.
- The same `submission_id` with any different field returns HTTP 409 `{"error":"conflict"}` and does not change the stored effect.
- A different `submission_id` is a different effect, even when the plans match.

`GET /v1/submissions/<submission_id>` returns that 200 object, or HTTP 404 `{"error":"not_found"}` if that id was never accepted.

`GET /v1/accounts/<account_id>` returns the latest accepted plan change for that account in the same object shape, or HTTP 404 if the account has none.

Ids in paths are from `A-Za-z0-9._-`, so they need no extra encoding.

The provider may drop the HTTP reply after it has accepted and counted the effect, may answer the POST late, may return HTTP 5xx without storing, and may cause the same callback to be presented twice or a later callback to name a different plan. The tool does not open a listening port for callbacks. The operator delivers a callback by running `./run callback <file>`.

Callback file:

```json
{"callback_id":"...","submission_id":"...","account_id":"...","to_plan":"plus","effective_at_ms":2592000000,"outcome":"applied"}
```

`outcome` is `applied` or `rejected`. `effective_at_ms` is a JSON number.

## Requirements

R1. Persistence. After `open` or any later committed record, a new process with the same `STATE_DIR` sees the same account, plan, pending change, submission id, and outcome. A committed attempt record survives `SIGKILL` at `after-attempt-saved-before-request` and is visible to a later `status`.

R2. Schedule at the next boundary. `schedule` of a different known plan sets `to_plan` and `effective_at_ms` by the rule above, and a later `status` returns that change id and those fields. A second `schedule` while one is pending is `pending_exists` and does not change the pending change. The current plan is `same_plan`. An unknown plan is `unknown_plan`. None of these refusals contact the provider.

R3. Replace supersedes the pending target. Before the effective time, `replace` of a different known plan changes `to_plan`, allocates a new change id, keeps `effective_at_ms`, and forgets the previous change id. Cancelling the previous id is `change_mismatch` and leaves the new pending change. `same_target`, `no_pending`, `already_due` at `NOW_MS >= effective_at_ms`, and `attempt_saved` after an attempt has been saved are refused and do not change the pending change or the provider.

R4. Cancel before send. `cancel` of the pending change id clears it when `submission` is `none`, including when the change is already due. A wrong id is `change_mismatch` and leaves the pending change. After a successful cancel, `apply` is `no_pending` and does not contact the provider. `cancel` after an attempt has been saved is `attempt_saved` and leaves the attempt in place.

R5. Legitimate progress. With a healthy provider, `open`, `schedule` of a different known plan, and `apply` at `NOW_MS` equal to that `effective_at_ms` each exit 0. `status` then reports `submission` `applied`, `current_plan` and `applied_plan` equal to the scheduled plan, and the provider's stored change for that account equals that plan and that submission id. A second `apply` exits 0 and does not send another plan-change request. A valid sequence must not be refused.

R6. Callbacks do not overwrite an applied plan. After a successful apply, delivering the same well-formed callback twice, and delivering a well-formed callback that names a different `to_plan`, each exit 0, leave `current_plan`, `applied_plan`, and `submission` unchanged, and do not add a plan-change effect.

R7. Not due, then due. `apply` before `effective_at_ms` exits nonzero `not_due`, does not contact the provider, and leaves the pending change. A later `apply` at the effective time against a healthy provider exits 0 and the provider counts one effect.

R8. Crash before the request. If `apply` is killed at `after-attempt-saved-before-request`, the provider has counted no effect, and `status` shows `attempt_saved` and the saved submission id. A later `apply`, with `CRASH_AT` unset, reaches `applied` for that same submission id, and the provider counts exactly one effect.

R9. Crash after accept. If `apply` is killed at `after-accept-before-record`, the provider has already counted one effect for the saved submission id. A later `apply`, with `CRASH_AT` unset, must end with `status` `applied` for that plan and that same submission id, must not say the request was never sent, and must not cause the provider to count a second effect or accept a different submission id.

R10. Crash after the durable record. If `apply` is killed at `after-record-before-exit`, a later `status` shows `applied` and the scheduled plan, and a further `apply` must not add an effect. If `reconcile` is killed at `after-record-before-exit` while committing an acceptance the local store had missed, a later `status` shows `applied` and the effect count is unchanged.

R11. Lost reply. If the provider accepts a plan change and drops the reply, that acceptance has already counted one effect. `apply` exits nonzero `service_unavailable`, leaves `attempt_saved`, does not mark `applied`, and does not POST a different submission id. A following `reconcile` of that submission id records `applied` for the scheduled plan, reports `lookup` `applied`, does not report `not_sent`, and does not add a plan-change request or a second effect.

R12. Reconcile never sends. With an attempt saved and no provider acceptance, `reconcile` of the saved id exits 0 with `lookup` `not_sent`, leaves `attempt_saved`, does not mark `applied`, and does not POST. `reconcile` of a different id exits nonzero `submission_mismatch`, does not contact the provider, and does not change the store.

R13. Unrelated writer. A file in `STATE_DIR` written by another process, which the tool did not create, is still present with the same bytes after later tool commands, including a command that commits a record. Those commands still see the records owned by the tool.

R14. Result protocol and one account. A successful `open` exits 0 and prints one JSON object. `status` on an empty store exits 0 with null ids and `pending` `none`. A refusal (a second `open`, and `NOW_MS` unset) exits nonzero and prints one JSON object whose `error` is `already_open` or `missing_clock`. The first successful `open` binds the account id. There is no command that applies a change for a different account. `status` with `CRASH_AT` set to `after-accept-before-record` exits 0 and does not kill itself, because that command never reaches the boundary.

## Out of scope

Concurrent `./run` processes, a second account in the same `STATE_DIR`, an effective time that is not the next cycle boundary, payment capture, and any distributed transaction between the tool and the provider beyond one idempotent submission are outside this brief.
