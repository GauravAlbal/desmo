# Plan-change scheduler

This is a single-process local scheduler for one account. Lifecycle authority and
its durable journal are provided by Ikaros 0.5.0; the Node host handles CLI,
clock arithmetic, and HTTP transport.

## Setup

Use Node 22 or newer. From this directory, with the bundled offline packages:

```sh
npm install --offline --no-audit --no-fund
```

The supplied `stub/server.mjs` can be used as a provider during local runs
(use a TCP port in 47500-47509 when starting it).

## Running

Every invocation requires `STATE_DIR`, `SERVICE_URL`, and canonical `NOW_MS`:

```sh
export STATE_DIR="$PWD/.state"
export SERVICE_URL=http://127.0.0.1:47500
export NOW_MS=0
./run status
./run open customer-1 basic 0
./run invoice invoice-1 2500
./run schedule plus
# use the returned effective_at_ms as NOW_MS
NOW_MS=2592000000 ./run apply
./run pay invoice-1
```

`./run` writes exactly one JSON object to stdout. `CRASH_AT` can be set to one
of the documented crash boundaries in `BRIEF.md` to exercise restart recovery.
The state directory is persistent; the scheduler owns only
`plan-scheduler.sqlite` inside it and leaves other files unchanged. An unpaid
invoice is local state: `invoice <id> <amount_cents>` records it, and
`pay <id>` marks it paid without contacting the provider. While an invoice is
unpaid, lower-plan schedule, replacement, and due apply operations are refused
with `unpaid_downgrade`.

The machine definition is `plan_scheduler.ik.toml`. Inspect it with the bundled
binary (`node_modules/@ikaros/darwin-arm64/bin/ik identity plan_scheduler.ik.toml`).

## Tests

The integration test starts an in-process provider on `127.0.0.1:47500` and
exercises process restart, all three crash labels, lost replies, reconciliation,
and provider effect idempotence:

```sh
node test.mjs
```
