import { mkdir, readFile, access } from "node:fs/promises";
import { constants as fsConstants, existsSync } from "node:fs";
import { join, resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { Kernel, HistoricalResult, classify } from "@ikaros/runtime";

const MACHINE_PATH = resolve(new URL("./plan_scheduler.ik.toml", import.meta.url).pathname);
const AGGREGATE_ID = "account";
const PLANS = new Set(["basic", "plus", "pro"]);
const PLAN_RANK = { basic: 1, plus: 2, pro: 3 };
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const CLOCK_RE = /^(0|[1-9][0-9]*)$/;
const MAX_SAFE = Number.MAX_SAFE_INTEGER;
const CYCLE_MS = 2592000000;
const AMOUNT_RE = /^(0|[1-9][0-9]*)$/;

function output(value, code = 0) {
  process.stdout.write(JSON.stringify(value) + "\n");
  process.exitCode = code;
}

function fail(error, extra = {}) {
  output({ error, ...extra }, 1);
}

function requiredEnvironment() {
  if (typeof process.env.SERVICE_URL !== "string" || process.env.SERVICE_URL.length === 0) {
    throw new AppError("missing_service_url");
  }
  if (process.env.SERVICE_URL.endsWith("/")) {
    throw new AppError("bad_service_url");
  }
  if (typeof process.env.NOW_MS !== "string") throw new AppError("missing_clock");
  if (!CLOCK_RE.test(process.env.NOW_MS)) throw new AppError("bad_clock");
  const now = Number(process.env.NOW_MS);
  if (!Number.isSafeInteger(now) || now < 0) throw new AppError("bad_clock");
  return { now, service: process.env.SERVICE_URL };
}

class AppError extends Error {
  constructor(code, extra = {}) {
    super(code);
    this.code = code;
    Object.assign(this, extra);
  }
}

function checkPlan(plan) {
  if (!PLANS.has(plan)) throw new AppError("unknown_plan");
}

function isDowngrade(currentPlan, targetPlan) {
  return PLAN_RANK[targetPlan] < PLAN_RANK[currentPlan];
}

function checkAmount(value) {
  if (typeof value !== "string" || !AMOUNT_RE.test(value)) throw new AppError("bad_amount");
  const amount = Number(value);
  if (!Number.isSafeInteger(amount) || amount < 1 || amount > 100000000) throw new AppError("bad_amount");
  return amount;
}

function checkId(id, code = "bad_args") {
  if (typeof id !== "string" || !ID_RE.test(id)) throw new AppError(code);
}
function localRecord(aggregate) {
  const f = factsOf(aggregate);
  return {
    account_id: f.account_id || null,
    current_plan: f.current_plan || null,
    cycle_anchor_ms: Number.isInteger(f.cycle_anchor_ms) ? f.cycle_anchor_ms : null,
    change_id: f.change_id || null,
    from_plan: f.from_plan || null,
    to_plan: f.to_plan || null,
    effective_at_ms: Number.isInteger(f.effective_at_ms) && f.effective_at_ms !== 0 ? f.effective_at_ms : null,
    pending: f.pending || "none",
    submission: f.submission || "none",
    submission_id: f.submission_id || null,
    applied_plan: f.applied_plan || null,
    invoice_id: f.invoice_id || null,
    invoice: f.invoice || "none",
    amount_cents: Number.isInteger(f.amount_cents) && f.amount_cents !== 0 ? f.amount_cents : null,
  };
}


function parseClock(value) {
  if (typeof value !== "string" || !CLOCK_RE.test(value)) throw new AppError("bad_clock");
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n < 0) throw new AppError("bad_clock");
  return n;
}

function newId(prefix) {
  return `${prefix}-${randomUUID().replaceAll("-", "")}`.slice(0, 64);
}

function storePaths() {
  const dir = process.env.STATE_DIR;
  if (typeof dir !== "string" || dir.length === 0) throw new AppError("missing_state_dir");
  const stateDir = resolve(dir);
  return { stateDir, store: join(stateDir, "plan-scheduler.sqlite") };
}

async function ensureStateDir() {
  const { stateDir } = storePaths();
  await mkdir(stateDir, { recursive: true });
  return stateDir;
}

function factsOf(aggregate) {
  return aggregate?.state ?? {};
}

function isAggregate(value) {
  return value && typeof value === "object" && value.capability;
}

async function machineAndAggregate({ create = false } = {}) {
  const { store } = storePaths();
  if (create) await ensureStateDir();
  const kernel = new Kernel(store);
  const machine = await kernel.machine(MACHINE_PATH);
  if (!existsSync(store)) return { kernel, machine, aggregate: null };
  try {
    return { kernel, machine, aggregate: await machine.show(AGGREGATE_ID) };
  } catch (error) {
    throw new AppError("corrupt_state", { cause: error });
  }
}


function machineError(error) {
  if (error instanceof AppError) return error;
  const diagnostic = error?.diagnostic ?? error?.raw?.diagnostic;
  const code = diagnostic?.code ?? diagnostic?.error ?? error?.code;
  if (code) return new AppError(String(code));
  return new AppError("illegal_state", { cause: error });
}

async function execute(aggregate, command, args) {
  try {
    const result = await aggregate.command(command, args);
    if (result instanceof HistoricalResult || !isAggregate(result)) throw new AppError("historical_result");
    return result;
  } catch (error) {
    throw machineError(error);
  }
}

function commonArgs(empty = "", none = "none") {
  return { empty, none };
}

function nextBoundary(anchor, now) {
  let effective;
  if (now < anchor) effective = anchor;
  else effective = anchor + CYCLE_MS * (Math.floor((now - anchor) / CYCLE_MS) + 1);
  if (!Number.isSafeInteger(effective)) throw new AppError("bad_clock");
  return effective;
}

function maybeCrash(label) {
  if (process.env.CRASH_AT === label) process.kill(process.pid, "SIGKILL");
}

async function openCommand(accountId, plan, anchor) {
  checkId(accountId);
  checkPlan(plan);
  checkClockNumber(anchor);
  const { kernel, machine, aggregate } = await machineAndAggregate({ create: true });
  if (aggregate) throw new AppError("already_open");
  const operationId = kernel.newOperationId();
  try {
    const result = await machine.createWith({
      aggregateId: AGGREGATE_ID,
      command: { name: "open", args: { account_id: accountId, plan, cycle_anchor_ms: anchor, ...commonArgs(), zero: 0 } },
      operationId,
    });
    if (!isAggregate(result)) throw new AppError("historical_result");
    const f = factsOf(result);
    return { account_id: f.account_id, current_plan: f.current_plan, cycle_anchor_ms: f.cycle_anchor_ms, pending: "none", submission: "none" };
  } catch (error) {
    throw machineError(error);
  }
}

function checkClockNumber(value) {
  if (!Number.isSafeInteger(value) || value < 0) throw new AppError("bad_clock");
}

async function scheduleCommand(plan, now) {
  checkPlan(plan);
  const { kernel, aggregate } = await machineAndAggregate();
  if (!aggregate) throw new AppError("not_open");
  const f = factsOf(aggregate);
  if (f.pending !== "none") throw new AppError("pending_exists");
  if (f.current_plan === plan) throw new AppError("same_plan");
  if (f.invoice === "unpaid" && isDowngrade(f.current_plan, plan)) throw new AppError("unpaid_downgrade");
  const effective = nextBoundary(f.cycle_anchor_ms, now);
  const changeId = newId("chg");
  const result = await execute(aggregate, "schedule", {
    expected_from_plan: f.current_plan,
    new_to_plan: plan,
    new_change_id: changeId,
    new_effective_at_ms: effective,
    none: "none",
    scheduled: "scheduled",
    empty: "",
  });
  return {
    change_id: changeId,
    account_id: f.account_id,
    from_plan: f.current_plan,
    to_plan: plan,
    effective_at_ms: effective,
    pending: "scheduled",
    submission: "none",
    submission_id: null,
  };
}

async function replaceCommand(plan, now) {
  checkPlan(plan);
  const { aggregate } = await machineAndAggregate();
  if (!aggregate) throw new AppError("not_open");
  const f = factsOf(aggregate);
  if (f.pending !== "scheduled") throw new AppError("no_pending");
  if (f.submission !== "none") throw new AppError("attempt_saved");
  if (now >= f.effective_at_ms) throw new AppError("already_due");
  if (plan === f.current_plan) throw new AppError("same_plan");
  if (f.invoice === "unpaid" && isDowngrade(f.current_plan, plan)) throw new AppError("unpaid_downgrade");
  if (plan === f.to_plan) throw new AppError("same_target");
  const changeId = newId("chg");
  await execute(aggregate, "replace", {
    expected_current_plan: f.current_plan,
    new_to_plan: plan,
    new_change_id: changeId,
    expected_effective_at_ms: f.effective_at_ms,
    now_ms: now,
  });
  return {
    change_id: changeId,
    account_id: f.account_id,
    from_plan: f.from_plan,
    to_plan: plan,
    effective_at_ms: f.effective_at_ms,
    pending: "scheduled",
    submission: "none",
    submission_id: null,
  };
}

async function cancelCommand(changeId) {
  checkId(changeId);
  const { aggregate } = await machineAndAggregate();
  if (!aggregate) throw new AppError("no_pending");
  const f = factsOf(aggregate);
  if (f.pending !== "scheduled") throw new AppError("no_pending");
  if (f.submission !== "none") throw new AppError("attempt_saved");
  if (changeId !== f.change_id) throw new AppError("change_mismatch");
  await execute(aggregate, "cancel", { expected_change_id: changeId, empty: "", none: "none", zero: 0 });
  return { account_id: f.account_id, change_id: changeId, current_plan: f.current_plan, pending: "none", submission: "none" };
}

function savedAttempt(f) {
  return {
    submission_id: f.submission_id,
    account_id: f.account_id,
    from_plan: f.from_plan,
    to_plan: f.to_plan,
    effective_at_ms: f.effective_at_ms,
  };
}

function appliedResult(f, extra = {}) {
  return {
    ...extra,
    account_id: f.account_id,
    change_id: f.change_id,
    submission_id: f.submission_id,
    from_plan: f.from_plan,
    to_plan: f.to_plan,
    effective_at_ms: f.effective_at_ms,
    current_plan: f.to_plan,
    pending: "none",
    submission: "applied",
    applied_plan: f.applied_plan || f.to_plan,
  };
}

function responseMatches(body, attempt) {
  return body && body.outcome === "applied" && body.submission_id === attempt.submission_id && body.account_id === attempt.account_id && body.to_plan === attempt.to_plan && body.effective_at_ms === attempt.effective_at_ms;
}

async function httpRequest(url, options) {
  let response;
  try {
    response = await fetch(url, options);
    const text = await response.text();
    let body;
    try { body = JSON.parse(text); } catch { throw new AppError("service_unavailable"); }
    return { status: response.status, body };
  } catch (error) {
    if (error instanceof AppError) throw error;
    throw new AppError("service_unavailable", { cause: error });
  }
}

async function lookupSubmission(attempt) {
  const result = await httpRequest(`${process.env.SERVICE_URL}/v1/submissions/${attempt.submission_id}`, { method: "GET" });
  if (result.status === 404) return { kind: "not_sent" };
  if (result.status !== 200) throw new AppError("service_unavailable");
  if (!responseMatches(result.body, attempt)) throw new AppError("lookup_conflict");
  return { kind: "applied", body: result.body };
}

async function postSubmission(attempt) {
  const result = await httpRequest(`${process.env.SERVICE_URL}/v1/plan-changes`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(attempt),
  });
  if (result.status >= 500) throw new AppError("service_unavailable");
  if (result.status !== 200) throw new AppError(result.status === 409 ? "lookup_conflict" : "service_unavailable");
  if (!responseMatches(result.body, attempt)) throw new AppError("lookup_conflict");
  return result.body;
}

async function commitApplied(aggregate, f) {
  const result = await execute(aggregate, "apply_success", {
    expected_account_id: f.account_id,
    expected_submission_id: f.submission_id,
    expected_from_plan: f.from_plan,
    expected_to_plan: f.to_plan,
    expected_effective_at_ms: f.effective_at_ms,
    applied: "applied",
    none: "none",
  });
  const next = factsOf(result);
  return { aggregate: result, facts: next };
}

async function applyCommand(now) {
  let { aggregate } = await machineAndAggregate();
  if (!aggregate) throw new AppError("no_pending");
  let f = factsOf(aggregate);
  if (f.pending !== "scheduled") {
    if (f.submission === "applied") return appliedResult(f);
    throw new AppError("no_pending");
  }
  let attempt;
  if (f.submission === "attempt_saved") {
    attempt = savedAttempt(f);
    const lookup = await lookupSubmission(attempt);
    if (lookup.kind === "applied") {
      const committed = await commitApplied(aggregate, f);
      f = committed.facts;
      maybeCrash("after-record-before-exit");
      return appliedResult(f);
    }
  } else {
    if (now < f.effective_at_ms) throw new AppError("not_due");
    if (f.invoice === "unpaid" && isDowngrade(f.current_plan, f.to_plan)) throw new AppError("unpaid_downgrade");
    const submissionId = newId("sub");
    await execute(aggregate, "save_attempt", { new_submission_id: submissionId, now_ms: now, attempt_saved: "attempt_saved" });
    maybeCrash("after-attempt-saved-before-request");
    const loaded = await machineAndAggregate();
    aggregate = loaded.aggregate;
    f = factsOf(aggregate);
    attempt = savedAttempt(f);
  }
  const body = await postSubmission(attempt);
  maybeCrash("after-accept-before-record");
  const committed = await commitApplied(aggregate, f);
  f = committed.facts;
  maybeCrash("after-record-before-exit");
  return appliedResult(f);
}

async function reconcileCommand(submissionId) {
  checkId(submissionId);
  let { aggregate } = await machineAndAggregate();
  if (!aggregate) throw new AppError("no_attempt");
  let f = factsOf(aggregate);
  if (f.submission === "applied" && f.submission_id === submissionId) return appliedResult(f, { lookup: "applied" });
  if (f.submission !== "attempt_saved") throw new AppError("no_attempt");
  if (f.submission_id !== submissionId) throw new AppError("submission_mismatch");
  const attempt = savedAttempt(f);
  const lookup = await lookupSubmission(attempt);
  if (lookup.kind === "not_sent") return { lookup: "not_sent", submission_id: f.submission_id, submission: "attempt_saved" };
  const committed = await commitApplied(aggregate, f);
  f = committed.facts;
  maybeCrash("after-record-before-exit");
  return appliedResult(f, { lookup: "applied" });
}

async function statusCommand() {
  const { aggregate } = await machineAndAggregate();
  if (!aggregate) return { account_id: null, current_plan: null, cycle_anchor_ms: null, change_id: null, from_plan: null, to_plan: null, effective_at_ms: null, pending: "none", submission: "none", submission_id: null, applied_plan: null, invoice_id: null, invoice: "none", amount_cents: null };
  return localRecord(aggregate);
}

async function invoiceCommand(invoiceId, amountValue) {
  checkId(invoiceId);
  const amount = checkAmount(amountValue);
  const { aggregate } = await machineAndAggregate();
  if (!aggregate) throw new AppError("not_open");
  const f = factsOf(aggregate);
  if (f.invoice === "unpaid") throw new AppError("invoice_exists");
  const result = await execute(aggregate, "invoice", {
    new_invoice_id: invoiceId,
    new_amount_cents: amount,
    unpaid: "unpaid",
  });
  const next = factsOf(result);
  return { invoice_id: next.invoice_id, amount_cents: next.amount_cents, invoice: next.invoice };
}

async function payCommand(invoiceId) {
  checkId(invoiceId);
  const { aggregate } = await machineAndAggregate();
  if (!aggregate) throw new AppError("no_invoice");
  const f = factsOf(aggregate);
  if (f.invoice === "none") throw new AppError("no_invoice");
  if (f.invoice_id !== invoiceId) throw new AppError("invoice_mismatch");
  if (f.invoice === "paid") return { invoice_id: f.invoice_id, amount_cents: f.amount_cents, invoice: "paid" };
  const result = await execute(aggregate, "pay", { expected_invoice_id: invoiceId, paid: "paid" });
  const next = factsOf(result);
  return { invoice_id: next.invoice_id, amount_cents: next.amount_cents, invoice: next.invoice };
}

async function callbackCommand(path) {
  if (typeof path !== "string" || path.length === 0) throw new AppError("bad_args");
  let callback;
  try {
    callback = JSON.parse(await readFile(path, "utf8"));
  } catch { throw new AppError("bad_callback"); }
  if (!callback || typeof callback !== "object" || Array.isArray(callback)) throw new AppError("bad_callback");
  if (callback.callback === "accepted") return { callback: "accepted" };
  const required = ["callback_id", "submission_id", "account_id", "to_plan", "effective_at_ms", "outcome"];
  if (!required.every((key) => Object.hasOwn(callback, key)) || !ID_RE.test(String(callback.callback_id)) || !ID_RE.test(String(callback.submission_id)) || !ID_RE.test(String(callback.account_id)) || !PLANS.has(callback.to_plan) || !Number.isSafeInteger(callback.effective_at_ms) || !["applied", "rejected"].includes(callback.outcome)) throw new AppError("bad_callback");
  return { callback: "accepted" };
}

async function main() {
  try {
    const { now } = requiredEnvironment();
    const command = process.argv[2];
    const args = process.argv.slice(3);
    let result;
    switch (command) {
      case "open":
        if (args.length !== 3) throw new AppError("bad_args");
        result = await openCommand(args[0], args[1], parseClock(args[2]));
        break;
      case "schedule":
        if (args.length !== 1) throw new AppError("bad_args");
        result = await scheduleCommand(args[0], now);
        break;
      case "replace":
        if (args.length !== 1) throw new AppError("bad_args");
        result = await replaceCommand(args[0], now);
        break;
      case "cancel":
        if (args.length !== 1) throw new AppError("bad_args");
        result = await cancelCommand(args[0]);
        break;
      case "apply":
        if (args.length !== 0) throw new AppError("bad_args");
        result = await applyCommand(now);
        break;
      case "reconcile":
        if (args.length !== 1) throw new AppError("bad_args");
        result = await reconcileCommand(args[0]);
        break;
      case "invoice":
        if (args.length !== 2) throw new AppError("bad_args");
        result = await invoiceCommand(args[0], args[1]);
        break;
      case "pay":
        if (args.length !== 1) throw new AppError("bad_args");
        result = await payCommand(args[0]);
        break;
      case "status":
        if (args.length !== 0) throw new AppError("bad_args");
        result = await statusCommand();
        break;
      case "callback":
        if (args.length !== 1) throw new AppError("bad_args");
        result = await callbackCommand(args[0]);
        break;
      default:
        throw new AppError("bad_args");
    }
    output(result);
  } catch (error) {
    const appError = error instanceof AppError ? error : machineError(error);
    fail(appError.code);
  }
}

await main();
