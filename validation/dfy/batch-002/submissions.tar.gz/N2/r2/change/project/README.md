# Plan-change scheduler

`./run` manages one account's next-cycle plan change. Durable lifecycle state is
owned by the Ikaros machine in `scheduler.ik.toml`; the Node runner owns command
line parsing, clock arithmetic, HTTP transport, and provider reconciliation.

## Setup

This checkout includes the qualified Ikaros npm tarballs. Node 22 is required;
no registry access is needed:

```sh
npm install --offline --no-audit --no-fund \
  KIT/npm/ikaros-runtime-0.5.0.tgz \
  KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
```

The provider URL has no trailing slash. Every invocation requires `SERVICE_URL`;
set `STATE_DIR` to the directory whose lifecycle should persist. Set `NOW_MS`
for commands that use the clock:

```sh
export STATE_DIR=.state
export SERVICE_URL=http://127.0.0.1:47100
export NOW_MS=0
./run open account-1 basic 0
./run schedule plus
./run status
```

At the due boundary, run `NOW_MS=2592000000 ./run apply`. If the reply may have
been lost, use `./run reconcile <submission_id>`; reconciliation only looks up
the saved submission and never sends a second request. `CRASH_AT` can be set to
one of the three documented crash labels in `BRIEF.md` for recovery testing.

## Tests

The deterministic regression test starts an in-process fake provider on
`127.0.0.1:47102` and covers process restart, both crash boundaries, and a lost
reply:

```sh
npm test
```

The supplied provider can also be run separately as documented in `stub/`.
