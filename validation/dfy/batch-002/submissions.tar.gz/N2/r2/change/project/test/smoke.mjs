import assert from "node:assert/strict";
import { createServer } from "node:http";
import { spawn } from "node:child_process";
import { mkdtempSync } from "node:fs";

const root = new URL("..", import.meta.url).pathname;
const effects = new Map();
let dropReply = false;
const provider = createServer(async (req, res) => {
  const url = new URL(req.url, "http://127.0.0.1");
  if (req.method === "GET" && url.pathname.startsWith("/v1/submissions/")) {
    const result = effects.get(url.pathname.split("/").pop());
    res.writeHead(result ? 200 : 404, { "content-type": "application/json" });
    res.end(JSON.stringify(result || { error: "not_found" }));
    return;
  }
  if (req.method === "POST" && url.pathname === "/v1/plan-changes") {
    let text = "";
    for await (const chunk of req) text += chunk;
    const result = { ...JSON.parse(text), outcome: "applied" };
    if (!effects.has(result.submission_id)) effects.set(result.submission_id, result);
    if (dropReply) { dropReply = false; req.socket.destroy(); return; }
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify(result));
    return;
  }
  res.writeHead(404); res.end();
});
await new Promise(resolve => provider.listen(47600, "127.0.0.1", resolve));

function invoke(dir, args, now, crash = "") {
  return new Promise(resolve => {
    const child = spawn("./run", args, { cwd: root, env: { ...process.env, STATE_DIR: dir, SERVICE_URL: "http://127.0.0.1:47600", NOW_MS: String(now), CRASH_AT: crash } });
    let stdout = "";
    child.stdout.on("data", chunk => { stdout += chunk; });
    child.on("close", (code, signal) => resolve({ code, signal, value: stdout.trim() ? JSON.parse(stdout) : null }));
  });
}
async function setup() {
  const dir = mkdtempSync("/tmp/plan-change-test-");
  assert.equal((await invoke(dir, ["open", "acct", "basic", "0"], 0)).code, 0);
  assert.equal((await invoke(dir, ["schedule", "plus"], 0)).code, 0);
  return dir;
}

const restart = await setup();
const restarted = await invoke(restart, ["status"], 0);
assert.equal(restarted.code, 0);
assert.equal(restarted.value.to_plan, "plus");

const before = await setup();
const beforeCrash = await invoke(before, ["apply"], 2592000000, "after-attempt-saved-before-request");
assert.equal(beforeCrash.signal, "SIGKILL");
assert.equal((await invoke(before, ["status"], 2592000000)).value.submission, "attempt_saved");
assert.equal((await invoke(before, ["apply"], 2592000000)).code, 0);
assert.equal(effects.size, 1);

const after = await setup();
const afterCrash = await invoke(after, ["apply"], 2592000000, "after-accept-before-record");
assert.equal(afterCrash.signal, "SIGKILL");
assert.equal((await invoke(after, ["apply"], 2592000000)).code, 0);
assert.equal(effects.size, 2);

const recorded = await setup();
const recordedCrash = await invoke(recorded, ["apply"], 2592000000, "after-record-before-exit");
assert.equal(recordedCrash.signal, "SIGKILL");
assert.equal((await invoke(recorded, ["status"], 2592000000)).value.submission, "applied");
assert.equal((await invoke(recorded, ["apply"], 2592000000)).code, 0);
assert.equal(effects.size, 3);

const lost = await setup();
dropReply = true;
const lostReply = await invoke(lost, ["apply"], 2592000000);
assert.equal(lostReply.value.error, "service_unavailable");
const attempt = (await invoke(lost, ["status"], 2592000000)).value;
assert.equal(attempt.submission, "attempt_saved");
const reconciled = await invoke(lost, ["reconcile", attempt.submission_id], 2592000000);
assert.equal(reconciled.code, 0);
assert.equal(reconciled.value.lookup, "applied");
assert.equal(effects.size, 4);

const blocked = mkdtempSync("/tmp/plan-change-invoice-");
assert.equal((await invoke(blocked, ["open", "acct", "plus", "0"], 0)).code, 0);
assert.equal((await invoke(blocked, ["invoice", "inv-1", "2500"], 0)).code, 0);
const blockedDowngrade = await invoke(blocked, ["schedule", "basic"], 0);
assert.equal(blockedDowngrade.value.error, "unpaid_downgrade");
const allowedUpgrade = await invoke(blocked, ["schedule", "pro"], 0);
assert.equal(allowedUpgrade.code, 0);

const replacement = mkdtempSync("/tmp/plan-change-replace-invoice-");
assert.equal((await invoke(replacement, ["open", "acct", "plus", "0"], 0)).code, 0);
const original = await invoke(replacement, ["schedule", "pro"], 0);
assert.equal((await invoke(replacement, ["invoice", "inv-2", "3000"], 0)).code, 0);
const blockedReplace = await invoke(replacement, ["replace", "basic"], 0);
assert.equal(blockedReplace.value.error, "unpaid_downgrade");
const unchanged = (await invoke(replacement, ["status"], 0)).value;
assert.equal(unchanged.change_id, original.value.change_id);
assert.equal(unchanged.to_plan, "pro");
assert.equal(unchanged.effective_at_ms, original.value.effective_at_ms);

const lifted = mkdtempSync("/tmp/plan-change-lift-invoice-");
assert.equal((await invoke(lifted, ["open", "acct", "plus", "0"], 0)).code, 0);
const oldTarget = await invoke(lifted, ["schedule", "basic"], 0);
assert.equal((await invoke(lifted, ["invoice", "inv-3", "4000"], 0)).code, 0);
const upgraded = await invoke(lifted, ["replace", "pro"], 0);
assert.equal(upgraded.code, 0);
assert.notEqual(upgraded.value.change_id, oldTarget.value.change_id);
assert.equal(upgraded.value.to_plan, "pro");
assert.equal(upgraded.value.effective_at_ms, oldTarget.value.effective_at_ms);
assert.equal((await invoke(lifted, ["cancel", oldTarget.value.change_id], 0)).value.error, "change_mismatch");

const due = mkdtempSync("/tmp/plan-change-due-invoice-");
assert.equal((await invoke(due, ["open", "acct", "plus", "0"], 0)).code, 0);
const dueTarget = await invoke(due, ["schedule", "basic"], 0);
assert.equal((await invoke(due, ["invoice", "inv-4", "5000"], 0)).code, 0);
const blockedApply = await invoke(due, ["apply"], 2592000000);
assert.equal(blockedApply.value.error, "unpaid_downgrade");
assert.equal((await invoke(due, ["status"], 2592000000)).value.submission, "none");
assert.equal((await invoke(due, ["pay", "inv-4"], 2592000000)).code, 0);
assert.equal((await invoke(due, ["apply"], 2592000000)).code, 0);
assert.equal(effects.size, 5);
assert.equal((await invoke(due, ["apply"], 2592000000)).code, 0);
assert.equal(effects.size, 5);

provider.close();
console.log(JSON.stringify({ process_restart: "ok", crash_boundaries: "ok", lost_reply: "ok", unpaid_invoice: "ok", effects: effects.size }));

