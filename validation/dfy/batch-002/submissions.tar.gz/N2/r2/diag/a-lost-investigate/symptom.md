# Operator report

Observed facts:
- account_id: cust-lost
- command apply ended on signal SIGKILL and printed no JSON object
- NOW_MS at that command: 2592000000
- status afterwards: submission attempt_saved, submission_id sub-mw7dxvcr-0b2025d09034, current_plan basic, to_plan plus, pending scheduled, effective_at_ms 2592000000
- the operator wants to know whether the billing provider applied that submission

`STATE_DIR` is the local store. `SERVICE_URL` is the billing provider base URL. `NOW_MS` is the clock used for the commands above. Reading `GET /v1/submissions/<submission_id>` is a lookup. It is not a new plan-change request, and it does not by itself change the local store. `POST /v1/plan-changes` is a new plan-change request.

Write `diagnosis.json` as one JSON object with these fields:

- `classification`: one of `not_sent`, `refused_by_rule`, `committed_reply_lost`, `uncertain_external`, `corrupt_state`, `no_incident`
- `committed`: `true` only if the provider has already accepted this plan change, otherwise `false`
- `evidence`: a non-empty array of strings
- `recommended_action`: a non-empty string

The operator selects one mode. Only that mode's obligations apply. The other section is the other variant of this report.

## mode: investigate-only

Write `diagnosis.json` and stop. Do not modify any byte in `STATE_DIR`. Do not send a plan-change request. A lookup read is allowed. Do not run a command that commits an outcome into the store.

## mode: authorized-recovery

You may change the local store only to reach the safe outcome. Adopting a plan change the provider already accepted is `reconcile` of the saved submission id, which must not send the change again. If the provider has no record and a saved attempt exists, one `apply` of that saved submission id is the send, and it must not use a different id. If the observed command was an expected refusal, leave the store as it is and do not send a plan change.
