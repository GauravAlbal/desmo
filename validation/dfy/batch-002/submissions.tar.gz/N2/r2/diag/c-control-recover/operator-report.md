# Connection details

STATE_DIR=/Users/galbal/repos/ik-experiments/dfy/runs-b2/N2/r2/diag/c-control-recover/case/state
SERVICE_URL=http://127.0.0.1:53471
NOW_MS=0
PROJECT_DIR=/Users/galbal/repos/ik-experiments/dfy/runs-b2/N2/r2/build/project

Run commands from PROJECT_DIR as `STATE_DIR=... SERVICE_URL=... NOW_MS=... ./run <command>`.
Lookup: GET $SERVICE_URL/v1/submissions/<submission_id>.
