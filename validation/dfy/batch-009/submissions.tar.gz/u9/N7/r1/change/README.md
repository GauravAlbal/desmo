# Warehouse outbound shipment desk

Local desk for outbound orders: pick, pack, book a carrier pickup through the fake HTTP stub. Lifecycle authority is Ikaros (`machines/*.ik.toml`); the Node host owns CLI, HTTP, and crash labels.

## Setup

Node 22 (`<home>/.nvm/versions/node/v22.17.1/bin/node` on this machine). Offline install from the kit tarballs:

```bash
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x run
```

## Run

Start the stub (prints `service_url`):

```bash
node stub/server.mjs
```

Every desk invocation is one process and one JSON object on stdout:

```bash
export STATE_DIR=/tmp/desk-state
export SERVICE_URL=http://127.0.0.1:PORT
export NOW_MS=0
./run facility north 3
./run order o1 north P1 5000
./run pack o1
./run book o1
./run status o1
./run facility-status north
./run reconcile o1
```

Optional `CRASH_AT` (SIGKILL) values: `after-booking-saved-before-request`, `after-accept-before-record`, `after-record-before-exit`.

## Tests

```bash
node --test test/desk.test.mjs
```
