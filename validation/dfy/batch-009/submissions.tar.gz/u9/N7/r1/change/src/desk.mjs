import { createHash, randomBytes } from "node:crypto";
import {
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
  renameSync,
  openSync,
  fsyncSync,
  closeSync,
} from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { Kernel, HistoricalResult, classify, KernelError } from "@ikaros/runtime";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const FACILITY_MACHINE = join(ROOT, "machines/facility.ik.toml");
const PARCEL_MACHINE = join(ROOT, "machines/parcel.ik.toml");
const ORDER_MACHINE_V1 = join(ROOT, "machines/order.ik.toml");
const ORDER_MACHINE_V2 = join(ROOT, "machines/order_v2.ik.toml");

const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const PARCEL_RE = /^[A-Za-z0-9._-]{1,32}$/;

export function refuse(code) {
  process.stdout.write(JSON.stringify({ error: code }) + "\n");
  process.exit(1);
}

function ok(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(0);
}

function crashIf(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

function stateDir() {
  const d = process.env.STATE_DIR;
  if (!d) refuse("bad_args");
  mkdirSync(d, { recursive: true });
  return d;
}

function nowMs() {
  const raw = process.env.NOW_MS;
  if (raw === undefined || raw === "") refuse("bad_args");
  if (!/^[0-9]+$/.test(raw)) refuse("bad_args");
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0) refuse("bad_args");
  return n;
}

function requireId(v) {
  if (typeof v !== "string" || !ID_RE.test(v)) refuse("bad_id");
  return v;
}

function requireParcel(v) {
  if (typeof v !== "string" || !PARCEL_RE.test(v)) refuse("bad_id");
  return v;
}

function requireCapacity(v) {
  if (!/^[0-9]+$/.test(v)) refuse("bad_capacity");
  const n = Number(v);
  if (!Number.isInteger(n) || n < 1 || n > 100000) refuse("bad_capacity");
  return n;
}

function requireDeadline(v) {
  if (!/^[0-9]+$/.test(v)) refuse("bad_deadline");
  const n = Number(v);
  if (!Number.isInteger(n) || n < 0 || n > 9007199254740991) refuse("bad_deadline");
  return n;
}

function facts(agg) {
  return agg.raw.state ?? {};
}

function isNotFound(err) {
  return err instanceof KernelError && classify(err) === "not_found";
}

async function asAgg(machine, id, result) {
  if (result instanceof HistoricalResult) return machine.show(id);
  return result;
}

function auxPath(dir) {
  return join(dir, "desk-aux.json");
}

function readAux(dir) {
  const p = auxPath(dir);
  if (!existsSync(p)) return { pending: null, freed: {} };
  try {
    return JSON.parse(readFileSync(p, "utf8"));
  } catch {
    return { pending: null, freed: {} };
  }
}

function writeAux(dir, aux) {
  const p = auxPath(dir);
  const tmp = p + ".tmp";
  const data = JSON.stringify(aux) + "\n";
  writeFileSync(tmp, data);
  const fd = openSync(tmp, "r+");
  try {
    fsyncSync(fd);
  } finally {
    closeSync(fd);
  }
  renameSync(tmp, p);
}

function parseParcelIds(f) {
  if (typeof f.parcel_ids === "string" && f.parcel_ids.length) {
    try {
      const parsed = JSON.parse(f.parcel_ids);
      if (Array.isArray(parsed)) return parsed;
    } catch {
      /* fall through */
    }
  }
  if (f.parcel_id) return [f.parcel_id];
  return [];
}

function sortedKey(ids) {
  return [...ids].slice().sort().join("\0");
}

function pendingParcels(p) {
  if (Array.isArray(p.parcel_ids) && p.parcel_ids.length) return p.parcel_ids;
  if (p.parcel_id) return [p.parcel_id];
  return [];
}

async function openKernel(dir) {
  const store = join(dir, "warehouse.sqlite");
  const kernel = new Kernel(store);
  const facilities = await kernel.machine(FACILITY_MACHINE);
  const parcels = await kernel.machine(PARCEL_MACHINE);
  const ordersV1 = await kernel.machine(ORDER_MACHINE_V1);
  const ordersV2 = await kernel.machine(ORDER_MACHINE_V2);
  return { kernel, facilities, parcels, ordersV1, ordersV2, dir };
}

function ordersMachine(ctx, agg) {
  if (agg && agg.owner && ctx.ordersV2.identity.equals(agg.owner)) return ctx.ordersV2;
  return ctx.ordersV1;
}

async function showOrNull(machine, id) {
  try {
    return await machine.show(id);
  } catch (err) {
    if (isNotFound(err)) return null;
    throw err;
  }
}

async function showOrder(ctx, id) {
  let agg = await showOrNull(ctx.ordersV2, id);
  if (!agg) agg = await showOrNull(ctx.ordersV1, id);
  if (!agg) return { machine: null, agg: null };
  const machine = ordersMachine(ctx, agg);
  agg = await machine.show(id);
  return { machine, agg };
}

function facilityView(agg) {
  const f = facts(agg);
  const capacity = Number(f.capacity) || 0;
  const held = Number(f.held) || 0;
  return {
    facility_id: agg.id,
    capacity,
    held,
    available: capacity - held,
  };
}

function orderView(agg) {
  const f = facts(agg);
  return {
    order_id: agg.id,
    facility_id: f.facility_id ?? null,
    parcel_ids: parseParcelIds(f),
    pickup_deadline_ms: Number(f.pickup_deadline_ms) || 0,
    state: f.state,
    request_id: f.request_id ?? null,
    booking_id: f.booking_id ?? null,
  };
}

async function recover(ctx) {
  const aux = readAux(ctx.dir);
  if (!aux.pending) return;
  const p = aux.pending;
  if (p.kind === "create_order") {
    await finishCreate(ctx, p, aux);
  } else if (p.kind === "free") {
    await finishFree(ctx, p, aux);
  }
}

async function holdOne(ctx, facilityId, orderId) {
  let fagg = await ctx.facilities.show(facilityId);
  const ff = facts(fagg);
  const inflight = ff.inflight_order;
  if (inflight === "none" || inflight === orderId) {
    const nextHeld = inflight === orderId ? Number(ff.held) : Number(ff.held) + 1;
    fagg = await asAgg(
      ctx.facilities,
      facilityId,
      await fagg.command("hold", { order_id: orderId, held: nextHeld }),
    );
  }
  fagg = await ctx.facilities.show(facilityId);
  await asAgg(
    ctx.facilities,
    facilityId,
    await fagg.command("commit_hold", { order_id: orderId, clear: "none" }),
  );
}

async function finishCreate(ctx, p, aux) {
  const fac = await showOrNull(ctx.facilities, p.facility_id);
  if (!fac) return;
  const ids = pendingParcels(p);
  if (!Array.isArray(p.held_parcels)) p.held_parcels = [];
  for (const parcelId of ids) {
    let parcel = await showOrNull(ctx.parcels, parcelId);
    if (!parcel) {
      parcel = await ctx.parcels.create(parcelId);
    }
    const pst = facts(parcel).state;
    if (pst === "vacant") {
      await asAgg(
        ctx.parcels,
        parcelId,
        await parcel.command("take", { order_id: p.order_id, facility_id: p.facility_id }),
      );
    } else if (facts(parcel).order_id === p.order_id) {
      await asAgg(ctx.parcels, parcelId, await parcel.command("keep", { order_id: p.order_id }));
    }
    if (!p.held_parcels.includes(parcelId)) {
      await holdOne(ctx, p.facility_id, p.order_id);
      p.held_parcels.push(parcelId);
      aux.pending = p;
      writeAux(ctx.dir, aux);
    }
  }
  let order = (await showOrder(ctx, p.order_id)).agg;
  if (!order) {
    const encoded = JSON.stringify(ids);
    await asAgg(
      ctx.ordersV2,
      p.order_id,
      await ctx.ordersV2.createWith({
        aggregateId: p.order_id,
        command: {
          name: "open",
          args: {
            facility_id: p.facility_id,
            parcel_ids: encoded,
            pickup_deadline_ms: p.pickup_deadline_ms,
            opened: 1,
          },
        },
      }),
    );
  }
  aux.pending = null;
  writeAux(ctx.dir, aux);
}

async function finishFree(ctx, p, aux) {
  if (aux.freed[p.order_id]) {
    aux.pending = null;
    writeAux(ctx.dir, aux);
    return;
  }
  const ids = pendingParcels(p);
  let released = 0;
  for (const parcelId of ids) {
    const parcel = await showOrNull(ctx.parcels, parcelId);
    if (parcel && facts(parcel).state === "taken" && facts(parcel).order_id === p.order_id) {
      await parcel.command("release");
      released += 1;
    } else {
      released += 1;
    }
  }
  const fac = await showOrNull(ctx.facilities, p.facility_id);
  if (fac) {
    let held = Number(facts(fac).held) || 0;
    let fagg = fac;
    for (let i = 0; i < released && held > 0; i++) {
      fagg = await asAgg(ctx.facilities, p.facility_id, await fagg.command("release", { held: held - 1 }));
      held -= 1;
    }
  }
  aux.freed[p.order_id] = true;
  aux.pending = null;
  writeAux(ctx.dir, aux);
}

async function maybeExpire(ctx, order, now) {
  const f = facts(order);
  if (f.state !== "picked" && f.state !== "packed") return order;
  if (now < Number(f.pickup_deadline_ms)) return order;
  const aux = readAux(ctx.dir);
  aux.pending = {
    kind: "free",
    order_id: order.id,
    facility_id: f.facility_id,
    parcel_ids: parseParcelIds(f),
  };
  writeAux(ctx.dir, aux);
  const machine = ordersMachine(ctx, order);
  await asAgg(machine, order.id, await order.command("expire_live"));
  await finishFree(ctx, aux.pending, readAux(ctx.dir));
  return (await showOrder(ctx, order.id)).agg;
}

function serviceUrl() {
  const u = process.env.SERVICE_URL;
  if (!u) return null;
  return u.replace(/\/$/, "");
}

async function provider(method, path, body) {
  const base = serviceUrl();
  if (!base) {
    const err = new Error("unavailable");
    err.unavailable = true;
    throw err;
  }
  try {
    const res = await fetch(base + path, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    if (res.status === 500) {
      const err = new Error("unavailable");
      err.unavailable = true;
      throw err;
    }
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      const err = new Error("unavailable");
      err.unavailable = true;
      throw err;
    }
    if (!json) {
      const err = new Error("unavailable");
      err.unavailable = true;
      throw err;
    }
    return { status: res.status, json };
  } catch (e) {
    if (e.unavailable) throw e;
    const err = new Error("unavailable");
    err.unavailable = true;
    throw err;
  }
}

function parcelsMatch(got, want) {
  if (!Array.isArray(got) || got.length !== want.length) return false;
  return want.every((x) => got.includes(x)) && got.every((x) => want.includes(x));
}

function bookingMatches(json, order) {
  const f = facts(order);
  return (
    json &&
    json.request_id === f.request_id &&
    json.order_id === order.id &&
    json.facility_id === f.facility_id &&
    parcelsMatch(json.parcel_ids, parseParcelIds(f))
  );
}

function bookingBody(order) {
  const f = facts(order);
  return {
    request_id: f.request_id,
    order_id: order.id,
    facility_id: f.facility_id,
    parcel_ids: parseParcelIds(f),
  };
}

function payloadDigest(body) {
  return createHash("sha256").update(JSON.stringify(body)).digest("hex");
}

async function adoptBooking(ctx, order, json) {
  if (!bookingMatches(json, order)) refuse("conflict");
  crashIf("after-accept-before-record");
  const digest = createHash("sha256").update(String(json.booking_id)).digest("hex");
  const machine = ordersMachine(ctx, order);
  if (order.pendingIntent) {
    const rec = await order.recordEffectOutcome(digest, { intent: order.pendingIntent });
    order = await asAgg(machine, order.id, rec);
  }
  if (facts(order).state === "attempt_saved") {
    order = await machine.show(order.id);
    order = await asAgg(machine, order.id, await order.command("confirm", { booking_id: json.booking_id }));
  }
  crashIf("after-record-before-exit");
  return order;
}

async function cmdFacility(ctx, id, capacity) {
  let agg = await showOrNull(ctx.facilities, id);
  if (!agg) {
    agg = await ctx.facilities.create(id);
    agg = await asAgg(ctx.facilities, id, await agg.command("configure", { capacity }));
    ok(facilityView(agg));
  }
  const cap = Number(facts(agg).capacity);
  if (cap === capacity) ok(facilityView(agg));
  refuse("conflict");
}

async function cmdFacilityStatus(ctx, id) {
  const agg = await showOrNull(ctx.facilities, id);
  if (!agg) refuse("unknown_facility");
  ok(facilityView(agg));
}

function sameOrderData(existing, facilityId, parcelIds, deadline) {
  const f = facts(existing);
  return (
    f.facility_id === facilityId &&
    sortedKey(parseParcelIds(f)) === sortedKey(parcelIds) &&
    Number(f.pickup_deadline_ms) === deadline
  );
}

async function cmdOrder(ctx, orderId, facilityId, parcelIds, deadline) {
  const fac = await showOrNull(ctx.facilities, facilityId);
  if (!fac) refuse("unknown_facility");
  const existing = (await showOrder(ctx, orderId)).agg;
  if (existing) {
    if (sameOrderData(existing, facilityId, parcelIds, deadline)) ok(orderView(existing));
    refuse("conflict");
  }
  const unique = new Set();
  for (const pid of parcelIds) {
    if (unique.has(pid)) refuse("bad_id");
    unique.add(pid);
  }
  let newCount = 0;
  for (const pid of parcelIds) {
    const parcel = await showOrNull(ctx.parcels, pid);
    if (parcel && facts(parcel).state === "taken" && facts(parcel).order_id !== orderId) {
      refuse("parcel_taken");
    }
    const alreadyOurs = parcel && facts(parcel).state === "taken" && facts(parcel).order_id === orderId;
    if (!alreadyOurs) newCount += 1;
  }
  const ff = facts(fac);
  if (Number(ff.held) + newCount > Number(ff.capacity)) refuse("capacity_exceeded");
  const aux = readAux(ctx.dir);
  aux.pending = {
    kind: "create_order",
    order_id: orderId,
    facility_id: facilityId,
    parcel_ids: parcelIds,
    pickup_deadline_ms: deadline,
  };
  writeAux(ctx.dir, aux);
  await finishCreate(ctx, aux.pending, readAux(ctx.dir));
  const order = (await showOrder(ctx, orderId)).agg;
  ok(orderView(order));
}

async function cmdPack(ctx, orderId, now) {
  let { machine, agg: order } = await showOrder(ctx, orderId);
  if (!order) refuse("unknown_order");
  order = await maybeExpire(ctx, order, now);
  machine = ordersMachine(ctx, order);
  const st = facts(order).state;
  if (st === "expired") refuse("expired");
  if (st === "cancelled") refuse("cancelled");
  if (st === "attempt_saved") refuse("attempt_saved");
  if (st === "booked") refuse("booked");
  if (st === "packed") ok(orderView(order));
  if (st !== "picked") refuse("conflict");
  order = await asAgg(machine, orderId, await order.command("pack"));
  ok(orderView(order));
}

async function cmdUnpack(ctx, orderId, now) {
  let { machine, agg: order } = await showOrder(ctx, orderId);
  if (!order) refuse("unknown_order");
  order = await maybeExpire(ctx, order, now);
  machine = ordersMachine(ctx, order);
  const st = facts(order).state;
  if (st === "picked") refuse("picked");
  if (st === "cancelled") refuse("cancelled");
  if (st === "expired") refuse("expired");
  if (st === "attempt_saved") refuse("attempt_saved");
  if (st === "booked") refuse("booked");
  if (st !== "packed") refuse("conflict");
  if (!machine.identity.equals(ctx.ordersV2.identity)) refuse("picked");
  order = await asAgg(machine, orderId, await order.command("unpack"));
  ok(orderView(order));
}

async function cmdCancel(ctx, orderId, now) {
  let { machine, agg: order } = await showOrder(ctx, orderId);
  if (!order) refuse("unknown_order");
  order = await maybeExpire(ctx, order, now);
  machine = ordersMachine(ctx, order);
  const st = facts(order).state;
  if (st === "cancelled" || st === "expired") ok(orderView(order));
  if (st === "attempt_saved" || st === "booked") refuse("cancel_open");
  if (st === "packed") {
    if (!machine.identity.equals(ctx.ordersV2.identity)) refuse("not_picked");
  } else if (st !== "picked") {
    refuse("conflict");
  }
  const f = facts(order);
  const aux = readAux(ctx.dir);
  aux.pending = {
    kind: "free",
    order_id: order.id,
    facility_id: f.facility_id,
    parcel_ids: parseParcelIds(f),
  };
  writeAux(ctx.dir, aux);
  const cancelName = machine.identity.equals(ctx.ordersV2.identity) ? "cancel_live" : "cancel_picked";
  await asAgg(machine, order.id, await order.command(cancelName));
  await finishFree(ctx, aux.pending, readAux(ctx.dir));
  ok(orderView((await showOrder(ctx, orderId)).agg));
}

async function cmdExpire(ctx, orderId, now) {
  let { agg: order } = await showOrder(ctx, orderId);
  if (!order) refuse("unknown_order");
  const st = facts(order).state;
  if (st === "attempt_saved" || st === "booked") refuse("cancel_open");
  if (st === "expired") ok(orderView(order));
  if (st === "cancelled") ok(orderView(order));
  if (now < Number(facts(order).pickup_deadline_ms)) refuse("not_due");
  order = await maybeExpire(ctx, order, now);
  ok(orderView(order));
}

async function cmdStatus(ctx, orderId, now) {
  let { agg: order } = await showOrder(ctx, orderId);
  if (!order) refuse("unknown_order");
  order = await maybeExpire(ctx, order, now);
  ok(orderView(order));
}

async function cmdBook(ctx, orderId, now) {
  let { machine, agg: order } = await showOrder(ctx, orderId);
  if (!order) refuse("unknown_order");
  order = await maybeExpire(ctx, order, now);
  machine = ordersMachine(ctx, order);
  let st = facts(order).state;
  if (st === "expired") refuse("expired");
  if (st === "cancelled") refuse("cancelled");
  if (st === "picked") refuse("picked");
  if (st === "booked") ok(orderView(order));
  let firstSend = false;
  if (st === "packed") {
    const requestId = "r" + randomBytes(16).toString("hex");
    const bodyPreview = {
      request_id: requestId,
      order_id: order.id,
      facility_id: facts(order).facility_id,
      parcel_ids: parseParcelIds(facts(order)),
    };
    const digest = payloadDigest(bodyPreview);
    order = await asAgg(
      machine,
      order.id,
      await order.command("save_attempt", {
        effect_id: requestId,
        payload_digest: digest,
        idempotency_key: requestId,
        request_id: requestId,
        attempt_flag: 1,
      }),
    );
    crashIf("after-booking-saved-before-request");
    firstSend = true;
    st = "attempt_saved";
  }
  if (st !== "attempt_saved") refuse("conflict");
  order = await machine.show(order.id);
  if (!firstSend) {
    let looked;
    try {
      looked = await provider("GET", "/v1/bookings/" + encodeURIComponent(facts(order).request_id));
    } catch (e) {
      if (e.unavailable) refuse("unavailable");
      throw e;
    }
    if (looked.status === 200) {
      order = await adoptBooking(ctx, order, looked.json);
      ok(orderView(order));
    }
    if (looked.status !== 404) refuse("unavailable");
  }
  let posted;
  try {
    posted = await provider("POST", "/v1/bookings", bookingBody(order));
  } catch (e) {
    if (e.unavailable) refuse("unavailable");
    throw e;
  }
  if (posted.status === 409) refuse("conflict");
  if (posted.status !== 200) refuse("unavailable");
  order = await adoptBooking(ctx, order, posted.json);
  ok(orderView(order));
}

async function cmdReconcile(ctx, orderId, now) {
  let { machine, agg: order } = await showOrder(ctx, orderId);
  if (!order) refuse("unknown_order");
  order = await maybeExpire(ctx, order, now);
  machine = ordersMachine(ctx, order);
  const st = facts(order).state;
  if (st === "booked") {
    ok({ ...orderView(order), outcome: "booked" });
  }
  if (!facts(order).request_id) {
    ok({ outcome: "not_applicable" });
  }
  let looked;
  try {
    looked = await provider("GET", "/v1/bookings/" + encodeURIComponent(facts(order).request_id));
  } catch (e) {
    if (e.unavailable) refuse("unavailable");
    throw e;
  }
  if (looked.status === 404) {
    ok({ ...orderView(order), outcome: "not_sent" });
  }
  if (looked.status !== 200) refuse("unavailable");
  if (!bookingMatches(looked.json, order)) refuse("conflict");
  order = await adoptBooking(ctx, order, looked.json);
  ok({ ...orderView(order), outcome: "booked" });
}

function parseOrderArgs(argv) {
  if (argv.length < 5) refuse("bad_args");
  const orderId = requireId(argv[1]);
  const facilityId = requireId(argv[2]);
  const deadline = requireDeadline(argv[argv.length - 1]);
  const parcelIds = argv.slice(3, -1).map(requireParcel);
  if (parcelIds.length < 1) refuse("bad_args");
  return { orderId, facilityId, parcelIds, deadline };
}

export async function main(argv) {
  const cmd = argv[0];
  if (!cmd) refuse("bad_args");
  const dir = stateDir();
  if (cmd !== "facility" && cmd !== "facility-status") nowMs();
  const ctx = await openKernel(dir);
  await recover(ctx);

  try {
    if (cmd === "facility") {
      if (argv.length !== 3) refuse("bad_args");
      await cmdFacility(ctx, requireId(argv[1]), requireCapacity(argv[2]));
    } else if (cmd === "facility-status") {
      if (argv.length !== 2) refuse("bad_args");
      await cmdFacilityStatus(ctx, requireId(argv[1]));
    } else if (cmd === "order") {
      const a = parseOrderArgs(argv);
      await cmdOrder(ctx, a.orderId, a.facilityId, a.parcelIds, a.deadline);
    } else if (cmd === "pack") {
      if (argv.length !== 2) refuse("bad_args");
      await cmdPack(ctx, requireId(argv[1]), nowMs());
    } else if (cmd === "unpack") {
      if (argv.length !== 2) refuse("bad_args");
      await cmdUnpack(ctx, requireId(argv[1]), nowMs());
    } else if (cmd === "book") {
      if (argv.length !== 2) refuse("bad_args");
      await cmdBook(ctx, requireId(argv[1]), nowMs());
    } else if (cmd === "cancel") {
      if (argv.length !== 2) refuse("bad_args");
      await cmdCancel(ctx, requireId(argv[1]), nowMs());
    } else if (cmd === "expire") {
      if (argv.length !== 2) refuse("bad_args");
      await cmdExpire(ctx, requireId(argv[1]), nowMs());
    } else if (cmd === "status") {
      if (argv.length !== 2) refuse("bad_args");
      await cmdStatus(ctx, requireId(argv[1]), nowMs());
    } else if (cmd === "reconcile") {
      if (argv.length !== 2) refuse("bad_args");
      await cmdReconcile(ctx, requireId(argv[1]), nowMs());
    } else {
      refuse("bad_args");
    }
  } catch (err) {
    if (err && err.unavailable) refuse("unavailable");
    if (err instanceof KernelError && classify(err) === "not_found") refuse("unknown_order");
    process.stderr.write(String(err && err.stack ? err.stack : err) + "\n");
    refuse("unavailable");
  }
}
