import { test } from "node:test";
import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { mkdtempSync, writeFileSync, readFileSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const RUN = join(ROOT, "run");
const NODE = process.execPath;
const STUB = join(ROOT, "stub/server.mjs");

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [STUB], { cwd: join(ROOT, "stub"), stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    child.stdout.on("data", (d) => {
      buf += d.toString();
      const nl = buf.indexOf("\n");
      if (nl >= 0) {
        try {
          resolve({ child, ...JSON.parse(buf.slice(0, nl)) });
        } catch (e) {
          reject(e);
        }
      }
    });
    child.on("error", reject);
  });
}

async function fault(control, body) {
  const res = await fetch(control + "/fault", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
  assert.equal(res.status, 200);
}

async function effects(control) {
  const res = await fetch(control + "/effects");
  return res.json();
}

function runDesk(state, args, extra = {}) {
  const env = {
    ...process.env,
    STATE_DIR: state,
    NOW_MS: extra.now ?? "0",
  };
  if (extra.service) env.SERVICE_URL = extra.service;
  if (extra.crash) env.CRASH_AT = extra.crash;
  else delete env.CRASH_AT;
  const r = spawnSync(NODE, [RUN, ...args], {
    encoding: "utf8",
    env,
  });
  let json = null;
  try {
    json = JSON.parse((r.stdout || "").trim().split("\n").filter(Boolean).at(-1) || "null");
  } catch {
    json = null;
  }
  return { status: r.status, json, stdout: r.stdout, stderr: r.stderr, signal: r.signal };
}

test("bad args and ids", () => {
  const state = mkdtempSync(join(tmpdir(), "desk-"));
  const a = runDesk(state, ["facility"]);
  assert.notEqual(a.status, 0);
  assert.equal(a.json.error, "bad_args");
  const b = runDesk(state, ["facility", "bad id", "3"]);
  assert.equal(b.json.error, "bad_id");
  const c = runDesk(state, ["facility", "north", "0"]);
  assert.equal(c.json.error, "bad_capacity");
  const d = runDesk(state, ["order", "o1", "north", "P1", "-1"], { now: "0" });
  assert.equal(d.json.error, "bad_deadline");
});

test("facility order pack book happy path and restart", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = mkdtempSync(join(tmpdir(), "desk-"));
    writeFileSync(join(state, "unrelated.txt"), "keep-me");
    const f = runDesk(state, ["facility", "north", "3"]);
    assert.equal(f.status, 0);
    assert.deepEqual(f.json, { facility_id: "north", capacity: 3, held: 0, available: 3 });
    const f2 = runDesk(state, ["facility", "north", "3"]);
    assert.equal(f2.status, 0);
    const bad = runDesk(state, ["facility", "north", "4"]);
    assert.equal(bad.json.error, "conflict");
    const o = runDesk(state, ["order", "o1", "north", "P1", "5000"], { now: "0" });
    assert.equal(o.status, 0);
    assert.equal(o.json.state, "picked");
    const same = runDesk(state, ["order", "o1", "north", "P1", "5000"], { now: "0" });
    assert.equal(same.status, 0);
    const taken = runDesk(state, ["order", "o2", "north", "P1", "5000"], { now: "0" });
    assert.equal(taken.json.error, "parcel_taken");
    const p = runDesk(state, ["pack", "o1"], { now: "0" });
    assert.equal(p.json.state, "packed");
    const b = runDesk(state, ["book", "o1"], { now: "0", service: service_url });
    assert.equal(b.status, 0, b.stderr);
    assert.equal(b.json.state, "booked");
    assert.ok(b.json.request_id);
    assert.ok(b.json.booking_id);
    const again = runDesk(state, ["book", "o1"], { now: "0", service: service_url });
    assert.equal(again.status, 0);
    assert.equal(again.json.booking_id, b.json.booking_id);
    const e = await effects(control_url);
    assert.equal(e.count, 1);
    const st = runDesk(state, ["status", "o1"], { now: "0" });
    assert.equal(st.json.state, "booked");
    assert.equal(readFileSync(join(state, "unrelated.txt"), "utf8"), "keep-me");
    const fs = runDesk(state, ["facility-status", "north"]);
    assert.equal(fs.json.held, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("capacity exceeded and independence", () => {
  const state = mkdtempSync(join(tmpdir(), "desk-"));
  runDesk(state, ["facility", "a", "1"]);
  runDesk(state, ["facility", "b", "1"]);
  const o1 = runDesk(state, ["order", "o1", "a", "P1", "9"], { now: "0" });
  assert.equal(o1.status, 0);
  const cap = runDesk(state, ["order", "o2", "a", "P2", "9"], { now: "0" });
  assert.equal(cap.json.error, "capacity_exceeded");
  const o3 = runDesk(state, ["order", "o3", "b", "P2", "9"], { now: "0" });
  assert.equal(o3.status, 0);
  const ca = runDesk(state, ["cancel", "o1"], { now: "0" });
  assert.equal(ca.json.state, "cancelled");
  const o2 = runDesk(state, ["order", "o2", "a", "P3", "9"], { now: "0" });
  assert.equal(o2.status, 0, JSON.stringify(o2.json));
});

test("expire at deadline and not_due", () => {
  const state = mkdtempSync(join(tmpdir(), "desk-"));
  runDesk(state, ["facility", "north", "2"]);
  runDesk(state, ["order", "o1", "north", "P1", "100"], { now: "0" });
  const nd = runDesk(state, ["expire", "o1"], { now: "99" });
  assert.equal(nd.json.error, "not_due");
  const ex = runDesk(state, ["expire", "o1"], { now: "100" });
  assert.equal(ex.json.state, "expired");
  const fs = runDesk(state, ["facility-status", "north"]);
  assert.equal(fs.json.held, 0);
  const o2 = runDesk(state, ["order", "o2", "north", "P1", "200"], { now: "100" });
  assert.equal(o2.status, 0);
});

test("status auto-expires past-due packed so book refuses expired", () => {
  const state = mkdtempSync(join(tmpdir(), "desk-"));
  runDesk(state, ["facility", "north", "1"]);
  runDesk(state, ["order", "o1", "north", "P1", "50"], { now: "0" });
  runDesk(state, ["pack", "o1"], { now: "0" });
  const st = runDesk(state, ["status", "o1"], { now: "50" });
  assert.equal(st.json.state, "expired");
});

test("crash after-booking-saved-before-request then reconcile not_sent and retry one effect", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = mkdtempSync(join(tmpdir(), "desk-"));
    runDesk(state, ["facility", "north", "1"]);
    runDesk(state, ["order", "o1", "north", "P1", "5000"], { now: "0" });
    runDesk(state, ["pack", "o1"], { now: "0" });
    const crashed = runDesk(state, ["book", "o1"], {
      now: "0",
      service: service_url,
      crash: "after-booking-saved-before-request",
    });
    assert.notEqual(crashed.status, 0);
    const rec = runDesk(state, ["reconcile", "o1"], { now: "0", service: service_url });
    assert.equal(rec.json.outcome, "not_sent");
    assert.equal(rec.json.state, "attempt_saved");
    let e = await effects(control_url);
    assert.equal(e.count, 0);
    const booked = runDesk(state, ["book", "o1"], { now: "0", service: service_url });
    assert.equal(booked.json.state, "booked", booked.stderr);
    e = await effects(control_url);
    assert.equal(e.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash after-accept-before-record recovered by lookup one effect", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = mkdtempSync(join(tmpdir(), "desk-"));
    runDesk(state, ["facility", "north", "1"]);
    runDesk(state, ["order", "o1", "north", "P1", "5000"], { now: "0" });
    runDesk(state, ["pack", "o1"], { now: "0" });
    const crashed = runDesk(state, ["book", "o1"], {
      now: "0",
      service: service_url,
      crash: "after-accept-before-record",
    });
    assert.notEqual(crashed.status, 0);
    let e = await effects(control_url);
    assert.equal(e.count, 1);
    const booked = runDesk(state, ["book", "o1"], { now: "0", service: service_url });
    assert.equal(booked.json.state, "booked", booked.stderr);
    e = await effects(control_url);
    assert.equal(e.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash after-record-before-exit stays booked", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = mkdtempSync(join(tmpdir(), "desk-"));
    runDesk(state, ["facility", "north", "1"]);
    runDesk(state, ["order", "o1", "north", "P1", "5000"], { now: "0" });
    runDesk(state, ["pack", "o1"], { now: "0" });
    const crashed = runDesk(state, ["book", "o1"], {
      now: "0",
      service: service_url,
      crash: "after-record-before-exit",
    });
    assert.notEqual(crashed.status, 0);
    const st = runDesk(state, ["status", "o1"], { now: "0" });
    assert.equal(st.json.state, "booked");
    const booked = runDesk(state, ["book", "o1"], { now: "0", service: service_url });
    assert.equal(booked.status, 0);
    const e = await effects(control_url);
    assert.equal(e.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("dropped reply: reconcile adopts without second effect", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = mkdtempSync(join(tmpdir(), "desk-"));
    runDesk(state, ["facility", "north", "1"]);
    runDesk(state, ["order", "o1", "north", "P1", "5000"], { now: "0" });
    runDesk(state, ["pack", "o1"], { now: "0" });
    await fault(control_url, { drop_reply: true });
    const dropped = runDesk(state, ["book", "o1"], { now: "0", service: service_url });
    assert.equal(dropped.json.error, "unavailable");
    await fault(control_url, { drop_reply: false });
    const rec = runDesk(state, ["reconcile", "o1"], { now: "0", service: service_url });
    assert.equal(rec.json.outcome, "booked", JSON.stringify(rec.json));
    const e = await effects(control_url);
    assert.equal(e.count, 1);
    const traffic = await (await fetch(control_url + "/traffic")).json();
    const posts = traffic.requests.filter((x) => x.method === "POST");
    assert.equal(posts.length, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("provider parcel mismatch is conflict without adoption", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = mkdtempSync(join(tmpdir(), "desk-"));
    runDesk(state, ["facility", "north", "2"]);
    runDesk(state, ["order", "o1", "north", "P1", "P2", "5000"], { now: "0" });
    runDesk(state, ["pack", "o1"], { now: "0" });
    await fault(control_url, { mismatch: true });
    const b = runDesk(state, ["book", "o1"], { now: "0", service: service_url });
    assert.equal(b.json.error, "conflict");
    const st = runDesk(state, ["status", "o1"], { now: "0" });
    assert.equal(st.json.state, "attempt_saved");
  } finally {
    child.kill("SIGKILL");
  }
});

test("unknown order and facility", () => {
  const state = mkdtempSync(join(tmpdir(), "desk-"));
  const u = runDesk(state, ["status", "nope"], { now: "0" });
  assert.equal(u.json.error, "unknown_order");
  const f = runDesk(state, ["facility-status", "nope"]);
  assert.equal(f.json.error, "unknown_facility");
});

test("cancel packed frees parcels; pack after cancel refuses cancelled", () => {
  const state = mkdtempSync(join(tmpdir(), "desk-"));
  runDesk(state, ["facility", "north", "1"]);
  runDesk(state, ["order", "o1", "north", "P1", "9"], { now: "0" });
  runDesk(state, ["pack", "o1"], { now: "0" });
  const c = runDesk(state, ["cancel", "o1"], { now: "0" });
  assert.equal(c.status, 0);
  assert.equal(c.json.state, "cancelled");
  const fs = runDesk(state, ["facility-status", "north"]);
  assert.equal(fs.json.held, 0);
  const o2 = runDesk(state, ["order", "o2", "north", "P1", "9"], { now: "0" });
  assert.equal(o2.status, 0);
  assert.equal(runDesk(state, ["pack", "o1"], { now: "0" }).json.error, "cancelled");
  assert.equal(runDesk(state, ["order", "o3", "south", "P9", "9"], { now: "0" }).json.error, "unknown_facility");
});

test("consolidated order is atomic and books once", async () => {
  const { child, service_url, control_url } = await startStub();
  try {
    const state = mkdtempSync(join(tmpdir(), "desk-"));
    runDesk(state, ["facility", "north", "3"]);
    const o = runDesk(state, ["order", "o1", "north", "P1", "P2", "5000"], { now: "0" });
    assert.equal(o.status, 0, JSON.stringify(o.json));
    assert.deepEqual(o.json.parcel_ids, ["P1", "P2"]);
    const same = runDesk(state, ["order", "o1", "north", "P2", "P1", "5000"], { now: "0" });
    assert.equal(same.status, 0);
    const taken = runDesk(state, ["order", "o2", "north", "P2", "P3", "5000"], { now: "0" });
    assert.equal(taken.json.error, "parcel_taken");
    const fs = runDesk(state, ["facility-status", "north"]);
    assert.equal(fs.json.held, 2);
    const cap = runDesk(state, ["order", "o3", "north", "P3", "P4", "P5", "5000"], { now: "0" });
    assert.equal(cap.json.error, "capacity_exceeded");
    runDesk(state, ["pack", "o1"], { now: "0" });
    const b = runDesk(state, ["book", "o1"], { now: "0", service: service_url });
    assert.equal(b.status, 0, b.stderr);
    assert.equal(b.json.state, "booked");
    const e = await effects(control_url);
    assert.equal(e.count, 1);
    assert.deepEqual(e.effects[0].parcel_ids.slice().sort(), ["P1", "P2"]);
    const again = runDesk(state, ["book", "o1"], { now: "0", service: service_url });
    assert.equal(again.status, 0);
    assert.equal((await effects(control_url)).count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("unpack packed to picked and refuse other states", () => {
  const state = mkdtempSync(join(tmpdir(), "desk-"));
  runDesk(state, ["facility", "north", "2"]);
  runDesk(state, ["order", "o1", "north", "P1", "P2", "9"], { now: "0" });
  assert.equal(runDesk(state, ["unpack", "o1"], { now: "0" }).json.error, "picked");
  runDesk(state, ["pack", "o1"], { now: "0" });
  const u = runDesk(state, ["unpack", "o1"], { now: "0" });
  assert.equal(u.status, 0);
  assert.equal(u.json.state, "picked");
  assert.deepEqual(u.json.parcel_ids, ["P1", "P2"]);
  assert.equal(runDesk(state, ["facility-status", "north"]).json.held, 2);
  assert.equal(runDesk(state, ["unpack", "o1"], { now: "0" }).json.error, "picked");
  runDesk(state, ["pack", "o1"], { now: "0" });
  const c = runDesk(state, ["cancel", "o1"], { now: "0" });
  assert.equal(c.json.state, "cancelled");
  assert.equal(runDesk(state, ["unpack", "o1"], { now: "0" }).json.error, "cancelled");
  assert.equal(runDesk(state, ["facility-status", "north"]).json.held, 0);
});

test("open attempt blocks unpack and cancel", async () => {
  const { child, service_url } = await startStub();
  try {
    const state = mkdtempSync(join(tmpdir(), "desk-"));
    runDesk(state, ["facility", "north", "2"]);
    runDesk(state, ["order", "o1", "north", "P1", "P2", "5000"], { now: "0" });
    runDesk(state, ["pack", "o1"], { now: "0" });
    const crashed = runDesk(state, ["book", "o1"], {
      now: "0",
      service: service_url,
      crash: "after-booking-saved-before-request",
    });
    assert.notEqual(crashed.status, 0);
    assert.equal(runDesk(state, ["cancel", "o1"], { now: "0" }).json.error, "cancel_open");
    assert.equal(runDesk(state, ["unpack", "o1"], { now: "0" }).json.error, "attempt_saved");
    const rec = runDesk(state, ["reconcile", "o1"], { now: "0", service: service_url });
    assert.equal(rec.json.outcome, "not_sent");
  } finally {
    child.kill("SIGKILL");
  }
});
