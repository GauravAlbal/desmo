import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const NODE = process.env.NODE || process.execPath;
const RUN = path.join(ROOT, "run");

function tmpDir() {
  return fs.mkdtempSync(path.join(os.tmpdir(), "wh-desk-"));
}

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [path.join(ROOT, "stub", "server.mjs")], {
      cwd: ROOT,
      stdio: ["ignore", "pipe", "pipe"],
    });
    let buf = "";
    const onData = (chunk) => {
      buf += chunk.toString();
      const nl = buf.indexOf("\n");
      if (nl === -1) return;
      child.stdout.off("data", onData);
      try {
        const info = JSON.parse(buf.slice(0, nl));
        resolve({ child, ...info });
      } catch (err) {
        reject(err);
      }
    };
    child.stdout.on("data", onData);
    child.on("error", reject);
  });
}

function desk(stateDir, extraEnv, args) {
  return spawnSync(RUN, args, {
    encoding: "utf8",
    env: {
      ...process.env,
      NODE,
      PATH: `${path.dirname(NODE)}:${process.env.PATH}`,
      STATE_DIR: stateDir,
      NOW_MS: extraEnv.NOW_MS ?? "1000",
      ...extraEnv,
    },
  });
}

function out(r) {
  const text = (r.stdout || "").trim();
  assert.ok(text, `empty stdout status=${r.status} signal=${r.signal} stderr=${r.stderr}`);
  return JSON.parse(text);
}

async function withStub(fn) {
  const stub = await startStub();
  try {
    await fn(stub);
  } finally {
    stub.child.kill("SIGKILL");
  }
}

test("bad args and ids contact no provider", async () => {
  await withStub(async (stub) => {
    const dir = tmpDir();
    const r = desk(dir, { SERVICE_URL: stub.service_url }, ["facility"]);
    assert.notEqual(r.status, 0);
    assert.equal(out(r).error, "bad_args");
    const r2 = desk(dir, { SERVICE_URL: stub.service_url }, ["order", "bad id", "n", "P", "1"]);
    assert.equal(out(r2).error, "bad_id");
    const traffic = await fetch(`${stub.control_url}/traffic`).then((x) => x.json());
    assert.equal(traffic.requests.length, 0);
  });
});

test("unrelated STATE_DIR file is preserved", () => {
  const dir = tmpDir();
  const p = path.join(dir, "keep.txt");
  fs.writeFileSync(p, "hello-bytes");
  const r = desk(dir, { NOW_MS: "1" }, ["facility", "north", "3"]);
  assert.equal(r.status, 0);
  assert.equal(fs.readFileSync(p, "utf8"), "hello-bytes");
});

test("happy path pack then book, restart, idempotent book", async () => {
  await withStub(async (stub) => {
    const dir = tmpDir();
    const env = { SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    assert.equal(desk(dir, env, ["facility", "north", "3"]).status, 0);
    const o = out(desk(dir, env, ["order", "o1", "north", "P1", "5000"]));
    assert.equal(o.state, "picked");
    assert.equal(out(desk(dir, env, ["pack", "o1"])).state, "packed");
    const booked = out(desk(dir, env, ["book", "o1"]));
    assert.equal(booked.state, "booked");
    assert.ok(booked.request_id);
    assert.ok(booked.booking_id);
    const again = out(desk(dir, env, ["status", "o1"]));
    assert.equal(again.state, "booked");
    assert.equal(again.request_id, booked.request_id);
    const effects1 = await fetch(`${stub.control_url}/effects`).then((x) => x.json());
    assert.equal(effects1.count, 1);
    const booked2 = out(desk(dir, env, ["book", "o1"]));
    assert.equal(booked2.state, "booked");
    const effects2 = await fetch(`${stub.control_url}/effects`).then((x) => x.json());
    assert.equal(effects2.count, 1);
    const posts = await fetch(`${stub.control_url}/traffic`).then((x) => x.json());
    assert.ok(posts.requests.some((x) => x.method === "POST"));
  });
});

test("capacity and parcel exclusivity", async () => {
  await withStub(async (stub) => {
    const dir = tmpDir();
    const env = { SERVICE_URL: stub.service_url, NOW_MS: "1" };
    desk(dir, env, ["facility", "north", "1"]);
    desk(dir, env, ["order", "o1", "north", "P1", "9000"]);
    const taken = out(desk(dir, env, ["order", "o2", "north", "P1", "9000"]));
    assert.equal(taken.error, "parcel_taken");
    const cap = out(desk(dir, env, ["order", "o3", "north", "P2", "9000"]));
    assert.equal(cap.error, "capacity_exceeded");
    const traffic = await fetch(`${stub.control_url}/traffic`).then((x) => x.json());
    assert.equal(traffic.requests.length, 0);
  });
});

test("expire before book and cancel packed", async () => {
  await withStub(async (stub) => {
    const dir = tmpDir();
    desk(dir, { SERVICE_URL: stub.service_url, NOW_MS: "1" }, ["facility", "north", "2"]);
    desk(dir, { SERVICE_URL: stub.service_url, NOW_MS: "1" }, ["order", "o1", "north", "P1", "50"]);
    desk(dir, { SERVICE_URL: stub.service_url, NOW_MS: "1" }, ["pack", "o1"]);
    const late = out(desk(dir, { SERVICE_URL: stub.service_url, NOW_MS: "50" }, ["book", "o1"]));
    assert.equal(late.error, "expired");
    const st = out(desk(dir, { SERVICE_URL: stub.service_url, NOW_MS: "50" }, ["facility-status", "north"]));
    assert.equal(st.held, 0);
    desk(dir, { SERVICE_URL: stub.service_url, NOW_MS: "1" }, ["order", "o2", "north", "P2", "5000"]);
    desk(dir, { SERVICE_URL: stub.service_url, NOW_MS: "1" }, ["pack", "o2"]);
    const cancelled = out(desk(dir, { SERVICE_URL: stub.service_url, NOW_MS: "1" }, ["cancel", "o2"]));
    assert.equal(cancelled.state, "cancelled");
    const st2 = out(desk(dir, { SERVICE_URL: stub.service_url, NOW_MS: "1" }, ["facility-status", "north"]));
    assert.equal(st2.held, 0);
  });
});

test("crash after booking saved before request: reconcile not_sent then book once", async () => {
  await withStub(async (stub) => {
    const dir = tmpDir();
    const env = { SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    desk(dir, env, ["facility", "north", "1"]);
    desk(dir, env, ["order", "o1", "north", "P1", "9000"]);
    desk(dir, env, ["pack", "o1"]);
    const crashed = desk(
      dir,
      { ...env, CRASH_AT: "after-booking-saved-before-request" },
      ["book", "o1"],
    );
    assert.equal(crashed.signal, "SIGKILL");
    const rec = out(desk(dir, env, ["reconcile", "o1"]));
    assert.equal(rec.outcome, "not_sent");
    const effects0 = await fetch(`${stub.control_url}/effects`).then((x) => x.json());
    assert.equal(effects0.count, 0);
    const booked = out(desk(dir, env, ["book", "o1"]));
    assert.equal(booked.state, "booked");
    const effects1 = await fetch(`${stub.control_url}/effects`).then((x) => x.json());
    assert.equal(effects1.count, 1);
  });
});

test("crash after accept before record recovers by lookup", async () => {
  await withStub(async (stub) => {
    const dir = tmpDir();
    const env = { SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    desk(dir, env, ["facility", "north", "1"]);
    desk(dir, env, ["order", "o1", "north", "P1", "9000"]);
    desk(dir, env, ["pack", "o1"]);
    const crashed = desk(dir, { ...env, CRASH_AT: "after-accept-before-record" }, ["book", "o1"]);
    assert.equal(crashed.signal, "SIGKILL");
    const effects1 = await fetch(`${stub.control_url}/effects`).then((x) => x.json());
    assert.equal(effects1.count, 1);
    const rec = out(desk(dir, env, ["reconcile", "o1"]));
    assert.equal(rec.outcome, "booked");
    const effects2 = await fetch(`${stub.control_url}/effects`).then((x) => x.json());
    assert.equal(effects2.count, 1);
  });
});

test("crash after record before exit stays booked", async () => {
  await withStub(async (stub) => {
    const dir = tmpDir();
    const env = { SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    desk(dir, env, ["facility", "north", "1"]);
    desk(dir, env, ["order", "o1", "north", "P1", "9000"]);
    desk(dir, env, ["pack", "o1"]);
    const crashed = desk(dir, { ...env, CRASH_AT: "after-record-before-exit" }, ["book", "o1"]);
    assert.equal(crashed.signal, "SIGKILL");
    const st = out(desk(dir, env, ["status", "o1"]));
    assert.equal(st.state, "booked");
    out(desk(dir, env, ["book", "o1"]));
    const effects = await fetch(`${stub.control_url}/effects`).then((x) => x.json());
    assert.equal(effects.count, 1);
  });
});

test("dropped reply: reconcile adopts without second effect", async () => {
  await withStub(async (stub) => {
    const dir = tmpDir();
    const env = { SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    desk(dir, env, ["facility", "north", "1"]);
    desk(dir, env, ["order", "o1", "north", "P1", "9000"]);
    desk(dir, env, ["pack", "o1"]);
    await fetch(`${stub.control_url}/fault`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ drop_reply: true }),
    });
    const dropped = desk(dir, env, ["book", "o1"]);
    assert.notEqual(dropped.status, 0);
    assert.equal(out(dropped).error, "unavailable");
    await fetch(`${stub.control_url}/fault`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ drop_reply: false }),
    });
    const rec = out(desk(dir, env, ["reconcile", "o1"]));
    assert.equal(rec.outcome, "booked");
    const effects = await fetch(`${stub.control_url}/effects`).then((x) => x.json());
    assert.equal(effects.count, 1);
  });
});

test("consolidated parcels, unpack, packed cancel atomic", async () => {
  await withStub(async (stub) => {
    const dir = tmpDir();
    const env = { SERVICE_URL: stub.service_url, NOW_MS: "1000" };
    desk(dir, env, ["facility", "north", "3"]);
    const created = out(desk(dir, env, ["order", "o1", "north", "P2", "P1", "5000"]));
    assert.deepEqual(created.parcel_ids, ["P1", "P2"]);
    assert.equal(created.state, "picked");
    const again = out(desk(dir, env, ["order", "o1", "north", "P1", "P2", "5000"]));
    assert.equal(again.state, "picked");
    const conflict = out(desk(dir, env, ["order", "o1", "north", "P1", "9000"]));
    assert.equal(conflict.error, "conflict");
    const taken = out(desk(dir, env, ["order", "o2", "north", "P1", "P3", "5000"]));
    assert.equal(taken.error, "parcel_taken");
    const cap = out(desk(dir, env, ["order", "o3", "north", "P3", "P4", "P5", "5000"]));
    assert.equal(cap.error, "capacity_exceeded");
    const fac = out(desk(dir, env, ["facility-status", "north"]));
    assert.equal(fac.held, 2);
    assert.equal(out(desk(dir, env, ["pack", "o1"])).state, "packed");
    const unpacked = out(desk(dir, env, ["unpack", "o1"]));
    assert.equal(unpacked.state, "picked");
    assert.deepEqual(unpacked.parcel_ids, ["P1", "P2"]);
    assert.equal(out(desk(dir, env, ["unpack", "o1"])).error, "picked");
    assert.equal(out(desk(dir, env, ["pack", "o1"])).state, "packed");
    const booked = out(desk(dir, env, ["book", "o1"]));
    assert.equal(booked.state, "booked");
    assert.deepEqual(booked.parcel_ids, ["P1", "P2"]);
    const effects = await fetch(`${stub.control_url}/effects`).then((x) => x.json());
    assert.equal(effects.count, 1);
    assert.equal(out(desk(dir, env, ["unpack", "o1"])).error, "booked");
    assert.equal(out(desk(dir, env, ["cancel", "o1"])).error, "cancel_open");
  });
});

test("independent orders", async () => {
  await withStub(async (stub) => {
    const dir = tmpDir();
    const env = { SERVICE_URL: stub.service_url, NOW_MS: "1" };
    desk(dir, env, ["facility", "north", "3"]);
    desk(dir, env, ["order", "o1", "north", "P1", "9000"]);
    desk(dir, env, ["order", "o2", "north", "P2", "9000"]);
    desk(dir, env, ["cancel", "o1"]);
    const s2 = out(desk(dir, env, ["status", "o2"]));
    assert.equal(s2.state, "picked");
  });
});
