import { createHash, randomBytes } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  HistoricalResult,
  Kernel,
  KernelError,
  StoreNotFoundError,
  classify,
} from "@ikaros/runtime";

const ROOT = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const FACILITY_MACHINE = path.join(ROOT, "machines", "facility.ik.toml");
const ORDER_V1_MACHINE = path.join(ROOT, "machines", "order.ik.toml");
const ORDER_V2_MACHINE = path.join(ROOT, "machines", "order_v2.ik.toml");
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const PARCEL_RE = /^[A-Za-z0-9._-]{1,32}$/;
const MAX_DEADLINE = 9007199254740991;

function fail(error) {
  process.stdout.write(JSON.stringify({ error }) + "\n");
  process.exit(1);
}

function ok(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(0);
}

function requireStateDir() {
  const dir = process.env.STATE_DIR;
  if (!dir) fail("bad_args");
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function parseNow() {
  const raw = process.env.NOW_MS;
  if (raw === undefined || raw === "") fail("bad_args");
  if (!/^[0-9]+$/.test(raw)) fail("bad_args");
  const n = Number(raw);
  if (!Number.isSafeInteger(n) || n < 0) fail("bad_args");
  return n;
}

function checkId(id) {
  if (!ID_RE.test(id)) fail("bad_id");
}

function checkParcel(id) {
  if (!PARCEL_RE.test(id)) fail("bad_id");
}

function parseCapacity(s) {
  if (!/^[0-9]+$/.test(s)) fail("bad_capacity");
  const n = Number(s);
  if (!Number.isInteger(n) || n < 1 || n > 100000) fail("bad_capacity");
  return n;
}

function parseDeadline(s) {
  if (!/^[0-9]+$/.test(s)) fail("bad_deadline");
  const n = Number(s);
  if (!Number.isSafeInteger(n) || n < 0 || n > MAX_DEADLINE) fail("bad_deadline");
  return n;
}

function num(v) {
  if (typeof v === "bigint") return Number(v);
  if (typeof v === "number") return v;
  if (typeof v === "string" && /^-?[0-9]+$/.test(v)) return Number(v);
  return v;
}

function strFact(state, key) {
  const v = state?.[key];
  return typeof v === "string" && v.length > 0 ? v : null;
}

function crash(boundary) {
  if (process.env.CRASH_AT === boundary) {
    process.kill(process.pid, "SIGKILL");
  }
}

function isUnknown(err) {
  if (err instanceof StoreNotFoundError) return true;
  if (err instanceof KernelError && classify(err) === "not_found") return true;
  return false;
}

function kernel(store) {
  return new Kernel(store);
}

async function settle(machine, id, result) {
  if (result instanceof HistoricalResult) return machine.show(id);
  return result;
}

async function showOrNull(machine, id) {
  try {
    return await machine.show(id);
  } catch (err) {
    if (isUnknown(err)) return null;
    throw err;
  }
}

function parseOccupancy(raw) {
  const map = new Map();
  const text = typeof raw === "string" ? raw : "";
  for (const part of text.split("|")) {
    if (!part) continue;
    const i = part.indexOf("=");
    if (i <= 0) continue;
    map.set(part.slice(0, i), part.slice(i + 1));
  }
  return map;
}

function serializeOccupancy(map) {
  if (map.size === 0) return "";
  const keys = [...map.keys()].sort();
  return "|" + keys.map((p) => `${p}=${map.get(p)}`).join("|") + "|";
}

function canonicalParcels(parcels) {
  return [...parcels].sort().join(",");
}

function parseParcelFact(st) {
  const list = strFact(st, "parcel_ids");
  if (list) return list.split(",").filter(Boolean);
  const one = strFact(st, "parcel_id");
  return one ? [one] : [];
}

function sameParcelList(a, b) {
  const as = [...a].sort();
  const bs = [...b].sort();
  return as.length === bs.length && as.every((x, i) => x === bs[i]);
}

function facilityView(id, agg) {
  const capacity = num(agg.state.capacity);
  const held = num(agg.state.held);
  return { facility_id: id, capacity, held, available: capacity - held };
}

function orderView(id, agg) {
  const st = agg.state && typeof agg.state === "object" ? agg.state : {};
  return {
    order_id: id,
    facility_id: strFact(st, "facility_id"),
    parcel_ids: parseParcelFact(st),
    pickup_deadline_ms: num(st.pickup_deadline_ms),
    state: agg.namedState(),
    request_id: strFact(st, "request_id"),
    booking_id: strFact(st, "booking_id"),
  };
}

function occupancyOf(agg) {
  return parseOccupancy(agg.state?.occupancy ?? "");
}

function isV2(agg, orderV2) {
  return orderV2.identity.equals(agg.owner);
}

async function holdParcels(facilityMachine, facility, orderId, parcels) {
  const expected = typeof facility.state.occupancy === "string" ? facility.state.occupancy : "";
  const map = occupancyOf(facility);
  let extra = 0;
  for (const parcelId of parcels) {
    if (map.has(parcelId) && map.get(parcelId) !== orderId) fail("parcel_taken");
    if (map.get(parcelId) !== orderId) extra += 1;
  }
  if (extra === 0) return facility;
  if (num(facility.state.held) + extra > num(facility.state.capacity)) fail("capacity_exceeded");
  for (const parcelId of parcels) map.set(parcelId, orderId);
  const occupancy = serializeOccupancy(map);
  const held = map.size;
  return settle(
    facilityMachine,
    facility.id,
    await facility.execute({
      name: "hold",
      args: { expected, occupancy, held },
    }),
  );
}

async function releaseParcels(facilityMachine, facilityId, orderId, parcels) {
  const facility = await showOrNull(facilityMachine, facilityId);
  if (!facility) return;
  const expected = typeof facility.state.occupancy === "string" ? facility.state.occupancy : "";
  const map = occupancyOf(facility);
  let changed = false;
  for (const parcelId of parcels) {
    if (map.get(parcelId) === orderId) {
      map.delete(parcelId);
      changed = true;
    }
  }
  if (!changed) return;
  const occupancy = serializeOccupancy(map);
  const held = map.size;
  await settle(
    facilityMachine,
    facilityId,
    await facility.execute({
      name: "release",
      args: { expected, occupancy, held },
    }),
  );
}

async function maybeExpire(orderMachine, facilityMachine, order, now) {
  const state = order.namedState();
  if (state !== "picked" && state !== "packed") return order;
  if (now < num(order.state.pickup_deadline_ms)) return order;
  const parcels = parseParcelFact(order.state);
  const expired = await settle(
    orderMachine,
    order.id,
    await order.execute({ name: "expire", args: { now_ms: now } }),
  );
  await releaseParcels(
    facilityMachine,
    strFact(expired.state, "facility_id"),
    expired.id,
    parcels,
  );
  return expired;
}

function newRequestId() {
  return "r" + randomBytes(16).toString("hex");
}

function digestText(text) {
  return createHash("sha256").update(text).digest("hex");
}

function bookingBody(requestId, order) {
  return {
    request_id: requestId,
    order_id: order.id,
    facility_id: strFact(order.state, "facility_id"),
    parcel_ids: parseParcelFact(order.state),
  };
}

function parcelsMatch(got, want) {
  if (!Array.isArray(got) || got.length !== want.length) return false;
  const a = [...got].sort();
  const b = [...want].sort();
  return a.every((x, i) => x === b[i]);
}

function matchingBooking(json, order, requestId) {
  if (!json || typeof json !== "object") return false;
  if (json.request_id !== requestId) return false;
  if (json.order_id !== order.id) return false;
  if (json.facility_id !== strFact(order.state, "facility_id")) return false;
  return parcelsMatch(json.parcel_ids, parseParcelFact(order.state));
}

async function httpJson(url, init) {
  let res;
  try {
    res = await fetch(url, init);
  } catch {
    fail("unavailable");
  }
  let text;
  try {
    text = await res.text();
  } catch {
    fail("unavailable");
  }
  if (text.length === 0 && res.status !== 404) fail("unavailable");
  let json = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    fail("unavailable");
  }
  return { res, text, json };
}

function serviceUrl() {
  const url = process.env.SERVICE_URL;
  if (!url) fail("unavailable");
  return url.replace(/\/$/, "");
}

async function lookupBooking(requestId) {
  const { res, text, json } = await httpJson(
    `${serviceUrl()}/v1/bookings/${encodeURIComponent(requestId)}`,
    { method: "GET" },
  );
  if (res.status === 404) return { kind: "missing" };
  if (res.status !== 200) fail("unavailable");
  return { kind: "found", json, text };
}

async function postBooking(body) {
  const payload = JSON.stringify(body);
  const { res, text, json } = await httpJson(`${serviceUrl()}/v1/bookings`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: payload,
  });
  if (res.status === 409) fail("conflict");
  if (res.status !== 200) fail("unavailable");
  return { json, text };
}

async function commitBooked(orderMachine, order, bookingId, outcomeText, honorAcceptCrash) {
  if (honorAcceptCrash) crash("after-accept-before-record");
  let current = order;
  if (current.pendingIntent) {
    const outcomeDigest = digestText(outcomeText);
    const recorded = await settle(
      orderMachine,
      current.id,
      await current.recordEffectOutcome(outcomeDigest),
    );
    current = recorded;
  }
  if (current.namedState() === "attempt_saved") {
    current = await settle(
      orderMachine,
      current.id,
      await current.execute({ name: "commit_booked", args: { booking_id: bookingId } }),
    );
  }
  crash("after-record-before-exit");
  return current;
}

async function cmdFacility(id, capStr) {
  checkId(id);
  const capacity = parseCapacity(capStr);
  const stateDir = requireStateDir();
  const k = kernel(path.join(stateDir, "facility.ik.sqlite"));
  const machine = await k.machine(FACILITY_MACHINE);
  const existing = await showOrNull(machine, id);
  if (existing) {
    if (num(existing.state.capacity) !== capacity) fail("conflict");
    ok(facilityView(id, existing));
  }
  const created = await settle(
    machine,
    id,
    await machine.createWith({
      aggregateId: id,
      command: { name: "open", args: { capacity } },
    }),
  );
  ok(facilityView(id, created));
}

async function cmdFacilityStatus(id) {
  checkId(id);
  const stateDir = requireStateDir();
  const k = kernel(path.join(stateDir, "facility.ik.sqlite"));
  const machine = await k.machine(FACILITY_MACHINE);
  const existing = await showOrNull(machine, id);
  if (!existing) fail("unknown_facility");
  ok(facilityView(id, existing));
}

async function openKernels() {
  const stateDir = requireStateDir();
  const facK = kernel(path.join(stateDir, "facility.ik.sqlite"));
  const ordK = kernel(path.join(stateDir, "order.ik.sqlite"));
  const facilityMachine = await facK.machine(FACILITY_MACHINE);
  const orderV1 = await ordK.machine(ORDER_V1_MACHINE);
  const orderV2 = await ordK.machine(ORDER_V2_MACHINE);
  return { facK, ordK, facilityMachine, orderV1, orderV2 };
}

async function loadOrder(orderV1, orderV2, orderId) {
  const viaV2 = await showOrNull(orderV2, orderId);
  if (viaV2) {
    if (isV2(viaV2, orderV2)) return { machine: orderV2, order: viaV2 };
    const viaV1 = await showOrNull(orderV1, orderId);
    if (viaV1) return { machine: orderV1, order: viaV1 };
    return { machine: orderV1, order: viaV2 };
  }
  const viaV1 = await showOrNull(orderV1, orderId);
  if (viaV1) return { machine: orderV1, order: viaV1 };
  return null;
}

async function cmdOrder(orderId, facilityId, parcels, deadlineStr) {
  checkId(orderId);
  checkId(facilityId);
  if (parcels.length === 0) fail("bad_args");
  const seen = new Set();
  for (const p of parcels) {
    checkParcel(p);
    if (seen.has(p)) fail("bad_id");
    seen.add(p);
  }
  const deadline = parseDeadline(deadlineStr);
  parseNow();
  const { facilityMachine, orderV1, orderV2 } = await openKernels();
  const facility = await showOrNull(facilityMachine, facilityId);
  if (!facility) fail("unknown_facility");
  const loaded = await loadOrder(orderV1, orderV2, orderId);
  if (loaded) {
    const st = loaded.order.state;
    const held = parseParcelFact(st);
    if (
      strFact(st, "facility_id") !== facilityId ||
      !sameParcelList(held, parcels) ||
      num(st.pickup_deadline_ms) !== deadline
    ) {
      fail("conflict");
    }
    ok(orderView(orderId, loaded.order));
  }
  const map = occupancyOf(facility);
  for (const p of parcels) {
    const occupant = map.get(p);
    if (occupant && occupant !== orderId) fail("parcel_taken");
  }
  let extra = 0;
  for (const p of parcels) {
    if (map.get(p) !== orderId) extra += 1;
  }
  if (extra > 0 && num(facility.state.held) + extra > num(facility.state.capacity)) {
    fail("capacity_exceeded");
  }
  let heldOk = false;
  try {
    await holdParcels(facilityMachine, facility, orderId, parcels);
    heldOk = extra > 0;
    const created = await settle(
      orderV2,
      orderId,
      await orderV2.createWith({
        aggregateId: orderId,
        command: {
          name: "admit",
          args: {
            facility_id: facilityId,
            parcel_ids: canonicalParcels(parcels),
            pickup_deadline_ms: deadline,
          },
        },
      }),
    );
    ok(orderView(orderId, created));
  } catch (err) {
    if (heldOk) {
      await releaseParcels(facilityMachine, facilityId, orderId, parcels).catch(() => {});
    }
    throw err;
  }
}

async function cmdPack(orderId) {
  checkId(orderId);
  const now = parseNow();
  const { facilityMachine, orderV1, orderV2 } = await openKernels();
  const loaded = await loadOrder(orderV1, orderV2, orderId);
  if (!loaded) fail("unknown_order");
  let order = await maybeExpire(loaded.machine, facilityMachine, loaded.order, now);
  const state = order.namedState();
  if (state === "packed") ok(orderView(orderId, order));
  if (state === "expired") fail("expired");
  if (state === "cancelled") fail("cancelled");
  if (state === "attempt_saved") fail("attempt_saved");
  if (state === "booked") fail("booked");
  if (state !== "picked") fail("expired");
  const packed = await settle(
    loaded.machine,
    orderId,
    await order.execute({ name: "pack", args: { now_ms: now } }),
  );
  ok(orderView(orderId, packed));
}

async function cmdCancel(orderId) {
  checkId(orderId);
  const now = parseNow();
  const { facilityMachine, orderV1, orderV2 } = await openKernels();
  const loaded = await loadOrder(orderV1, orderV2, orderId);
  if (!loaded) fail("unknown_order");
  let order = await maybeExpire(loaded.machine, facilityMachine, loaded.order, now);
  const state = order.namedState();
  if (state === "cancelled" || state === "expired") ok(orderView(orderId, order));
  if (state === "attempt_saved" || state === "booked") fail("cancel_open");
  if (state === "packed") {
    if (!isV2(order, orderV2)) fail("not_picked");
    const parcels = parseParcelFact(order.state);
    const cancelled = await settle(
      loaded.machine,
      orderId,
      await order.execute({ name: "cancel_packed" }),
    );
    await releaseParcels(
      facilityMachine,
      strFact(cancelled.state, "facility_id"),
      orderId,
      parcels,
    );
    ok(orderView(orderId, cancelled));
  }
  if (state !== "picked") fail("not_picked");
  const parcels = parseParcelFact(order.state);
  const cancelled = await settle(
    loaded.machine,
    orderId,
    await order.execute({ name: "cancel_picked" }),
  );
  await releaseParcels(
    facilityMachine,
    strFact(cancelled.state, "facility_id"),
    orderId,
    parcels,
  );
  ok(orderView(orderId, cancelled));
}

async function cmdUnpack(orderId) {
  checkId(orderId);
  const now = parseNow();
  const { facilityMachine, orderV1, orderV2 } = await openKernels();
  const loaded = await loadOrder(orderV1, orderV2, orderId);
  if (!loaded) fail("unknown_order");
  let order = await maybeExpire(loaded.machine, facilityMachine, loaded.order, now);
  const state = order.namedState();
  if (state === "picked") fail("picked");
  if (state === "cancelled") fail("cancelled");
  if (state === "expired") fail("expired");
  if (state === "attempt_saved") fail("attempt_saved");
  if (state === "booked") fail("booked");
  if (state !== "packed" || !isV2(order, orderV2)) fail("picked");
  const unpacked = await settle(loaded.machine, orderId, await order.execute({ name: "unpack" }));
  ok(orderView(orderId, unpacked));
}

async function cmdExpire(orderId) {
  checkId(orderId);
  const now = parseNow();
  const { facilityMachine, orderV1, orderV2 } = await openKernels();
  const loaded = await loadOrder(orderV1, orderV2, orderId);
  if (!loaded) fail("unknown_order");
  const order = loaded.order;
  const state = order.namedState();
  if (state === "attempt_saved" || state === "booked") fail("cancel_open");
  if (state === "cancelled" || state === "expired") ok(orderView(orderId, order));
  if (now < num(order.state.pickup_deadline_ms)) fail("not_due");
  const parcels = parseParcelFact(order.state);
  const expired = await settle(
    loaded.machine,
    orderId,
    await order.execute({ name: "expire", args: { now_ms: now } }),
  );
  await releaseParcels(
    facilityMachine,
    strFact(expired.state, "facility_id"),
    orderId,
    parcels,
  );
  ok(orderView(orderId, expired));
}

async function cmdStatus(orderId) {
  checkId(orderId);
  const now = parseNow();
  const { facilityMachine, orderV1, orderV2 } = await openKernels();
  const loaded = await loadOrder(orderV1, orderV2, orderId);
  if (!loaded) fail("unknown_order");
  const order = await maybeExpire(loaded.machine, facilityMachine, loaded.order, now);
  ok(orderView(orderId, order));
}

async function cmdBook(orderId) {
  checkId(orderId);
  const now = parseNow();
  const { facilityMachine, orderV1, orderV2 } = await openKernels();
  const loaded = await loadOrder(orderV1, orderV2, orderId);
  if (!loaded) fail("unknown_order");
  let order = await maybeExpire(loaded.machine, facilityMachine, loaded.order, now);
  let state = order.namedState();
  if (state === "booked") ok(orderView(orderId, order));
  if (state === "expired") fail("expired");
  if (state === "cancelled") fail("cancelled");
  if (state === "picked") fail("picked");
  if (state === "packed") {
    const requestId = newRequestId();
    const body = bookingBody(requestId, order);
    const payloadDigest = digestText(JSON.stringify(body));
    order = await settle(
      loaded.machine,
      orderId,
      await order.execute({
        name: "save_attempt",
        args: {
          request_id: requestId,
          effect_id: requestId,
          payload_digest: payloadDigest,
          idempotency_key: requestId,
        },
      }),
    );
    crash("after-booking-saved-before-request");
    const posted = await postBooking(body);
    if (!matchingBooking(posted.json, order, requestId)) fail("conflict");
    order = await commitBooked(loaded.machine, order, posted.json.booking_id, posted.text, true);
    ok(orderView(orderId, order));
  }
  if (state !== "attempt_saved") fail("unavailable");
  const requestId = strFact(order.state, "request_id");
  if (!requestId) fail("unavailable");
  const looked = await lookupBooking(requestId);
  if (looked.kind === "found") {
    if (!matchingBooking(looked.json, order, requestId)) fail("conflict");
    order = await commitBooked(loaded.machine, order, looked.json.booking_id, looked.text, true);
    ok(orderView(orderId, order));
  }
  const body = bookingBody(requestId, order);
  const posted = await postBooking(body);
  if (!matchingBooking(posted.json, order, requestId)) fail("conflict");
  order = await commitBooked(loaded.machine, order, posted.json.booking_id, posted.text, true);
  ok(orderView(orderId, order));
}

async function cmdReconcile(orderId) {
  checkId(orderId);
  const { orderV1, orderV2 } = await openKernels();
  const loaded = await loadOrder(orderV1, orderV2, orderId);
  if (!loaded) fail("unknown_order");
  const order = loaded.order;
  const state = order.namedState();
  const requestId = strFact(order.state, "request_id");
  if (state === "booked") {
    ok({ ...orderView(orderId, order), outcome: "booked" });
  }
  if (!requestId || state !== "attempt_saved") {
    ok({ outcome: "not_applicable" });
  }
  const looked = await lookupBooking(requestId);
  if (looked.kind === "missing") {
    ok({ ...orderView(orderId, order), outcome: "not_sent" });
  }
  if (!matchingBooking(looked.json, order, requestId)) fail("conflict");
  const booked = await commitBooked(
    loaded.machine,
    order,
    looked.json.booking_id,
    looked.text,
    false,
  );
  ok({ ...orderView(orderId, booked), outcome: "booked" });
}

async function main() {
  const args = process.argv.slice(2);
  const cmd = args[0];
  try {
    switch (cmd) {
      case "facility":
        if (args.length !== 3) fail("bad_args");
        await cmdFacility(args[1], args[2]);
        break;
      case "order":
        if (args.length < 5) fail("bad_args");
        await cmdOrder(args[1], args[2], args.slice(3, -1), args[args.length - 1]);
        break;
      case "pack":
        if (args.length !== 2) fail("bad_args");
        await cmdPack(args[1]);
        break;
      case "book":
        if (args.length !== 2) fail("bad_args");
        await cmdBook(args[1]);
        break;
      case "cancel":
        if (args.length !== 2) fail("bad_args");
        await cmdCancel(args[1]);
        break;
      case "unpack":
        if (args.length !== 2) fail("bad_args");
        await cmdUnpack(args[1]);
        break;
      case "expire":
        if (args.length !== 2) fail("bad_args");
        await cmdExpire(args[1]);
        break;
      case "status":
        if (args.length !== 2) fail("bad_args");
        await cmdStatus(args[1]);
        break;
      case "facility-status":
        if (args.length !== 2) fail("bad_args");
        await cmdFacilityStatus(args[1]);
        break;
      case "reconcile":
        if (args.length !== 2) fail("bad_args");
        await cmdReconcile(args[1]);
        break;
      default:
        fail("bad_args");
    }
  } catch (err) {
    if (err && err._deskFailed) throw err;
    if (isUnknown(err)) {
      const cmdName = cmd;
      if (cmdName === "facility" || cmdName === "facility-status") fail("unknown_facility");
      fail("unknown_order");
    }
    if (err instanceof KernelError) fail("unavailable");
    fail("unavailable");
  }
}

await main();
