# Warehouse outbound shipment desk

Local desk for outbound orders. Lifecycle and persistence run on Ikaros.
Carrier HTTP is a fake service (`stub/server.mjs`).

## Setup

Node 22 is required (`<home>/.nvm/versions/node/v22.17.1/bin/node`).

```sh
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x ./run
```

Start the carrier stub in another shell (ephemeral loopback port):

```sh
node stub/server.mjs
```

It prints `{"service_url":"http://127.0.0.1:PORT","control_url":"..."}`.

## Run

Every invocation prints one JSON object. Exit 0 is success.

```sh
export STATE_DIR=/tmp/warehouse-desk
export SERVICE_URL=http://127.0.0.1:PORT
export NOW_MS=1000

./run facility north 3
./run order o1 north P1 5000
./run pack o1
./run book o1
./run status o1
./run facility-status north
```

Optional: `CRASH_AT` is one of `after-booking-saved-before-request`,
`after-accept-before-record`, `after-record-before-exit`.

## Tests

```sh
NODE=<home>/.nvm/versions/node/v22.17.1/bin/node
$NODE --test tests/desk.test.mjs
```
