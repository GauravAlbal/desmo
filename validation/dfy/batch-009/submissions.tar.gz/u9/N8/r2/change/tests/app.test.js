import { spawn } from "node:child_process";
import { createServer } from "node:net";
import { mkdirSync, writeFileSync, readFileSync, rmSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { tmpdir } from "node:os";
import assert from "node:assert/strict";
import test from "node:test";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node";
const RUN = join(ROOT, "run");
const STUB = join(ROOT, "stub", "server.mjs");

function runApp(env, args, extra = {}) {
  return new Promise((resolve) => {
    const child = spawn(NODE, [RUN, ...args], {
      env: { ...process.env, ...env },
      cwd: ROOT,
      stdio: ["ignore", "pipe", "pipe"],
    });
    let out = "";
    let err = "";
    child.stdout.on("data", (d) => {
      out += d;
    });
    child.stderr.on("data", (d) => {
      err += d;
    });
    child.on("close", (code, signal) => {
      resolve({ code, signal, out, err });
    });
    if (extra.timeoutMs) {
      setTimeout(() => {
        try {
          child.kill("SIGKILL");
        } catch {
          /* gone */
        }
      }, extra.timeoutMs);
    }
  });
}

function jsonLine(out) {
  const line = out.trim();
  return JSON.parse(line);
}

async function startStub() {
  const child = spawn(NODE, [STUB], { cwd: ROOT, stdio: ["ignore", "pipe", "pipe"] });
  const urls = await new Promise((resolve, reject) => {
    let buf = "";
    const onData = (d) => {
      buf += d;
      const nl = buf.indexOf("\n");
      if (nl >= 0) {
        child.stdout.off("data", onData);
        resolve(JSON.parse(buf.slice(0, nl)));
      }
    };
    child.stdout.on("data", onData);
    child.on("error", reject);
  });
  return { child, ...urls };
}

async function control(controlUrl, method, path, body) {
  const res = await fetch(`${controlUrl}${path}`, {
    method,
    headers: body ? { "content-type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  return res.json();
}

function stateDir() {
  const dir = join(tmpdir(), `sub-ledger-${process.pid}-${Math.random().toString(16).slice(2)}`);
  mkdirSync(dir, { recursive: true });
  return dir;
}

test("empty status and open persist across processes", async () => {
  const stub = await startStub();
  const dir = stateDir();
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "0" };
    const empty = await runApp(env, ["status"]);
    assert.equal(empty.code, 0);
    assert.deepEqual(jsonLine(empty.out), {
      customer_id: null,
      subscription_id: null,
      plan: null,
      renewal_ms: null,
      grace_ms: null,
      retry_limit: null,
      attempts: 0,
      first_failure_ms: null,
      credit_cents: 0,
      status: "none",
      payment: "none",
      charge_id: null,
      amount_cents: null,
      last_plan: null,
      proration_cents: 0,
    });
    const opened = await runApp(env, ["open", "cust1", "sub1", "basic", "1000", "5000", "3"]);
    assert.equal(opened.code, 0, opened.out + opened.err);
    const body = jsonLine(opened.out);
    assert.equal(body.status, "active");
    assert.equal(body.plan, "basic");
    assert.equal(body.charge_id, null);
    const again = await runApp({ ...env, NOW_MS: "1" }, ["status"]);
    assert.equal(again.code, 0);
    const st = jsonLine(again.out);
    assert.equal(st.customer_id, "cust1");
    assert.equal(st.subscription_id, "sub1");
    assert.equal(st.status, "active");
    const dup = await runApp(env, ["open", "cust1", "sub1", "basic", "1000", "5000", "3"]);
    assert.notEqual(dup.code, 0);
    assert.equal(jsonLine(dup.out).error, "already_open");
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("not_due and healthy renew plus no-op", async () => {
  const stub = await startStub();
  const dir = stateDir();
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "0" };
    const opened = await runApp(env, ["open", "cust1", "sub1", "pro", "1000", "8000", "3"]);
    assert.equal(opened.code, 0, opened.out);
    const early = await runApp(env, ["renew"]);
    assert.notEqual(early.code, 0);
    assert.equal(jsonLine(early.out).error, "not_due");
    const paid = await runApp({ ...env, NOW_MS: "1000" }, ["renew"]);
    assert.equal(paid.code, 0, paid.out + paid.err);
    const body = jsonLine(paid.out);
    assert.equal(body.status, "active");
    assert.equal(body.payment, "paid");
    assert.equal(body.amount_cents, 3000);
    assert.equal(body.renewal_ms, 1000 + 2592000000);
    const effects = await control(stub.control_url, "GET", "/effects");
    assert.equal(effects.count, 1);
    const again = await runApp({ ...env, NOW_MS: "1000" }, ["renew"]);
    assert.equal(again.code, 0, again.out);
    assert.equal(jsonLine(again.out).payment, "paid");
    const effects2 = await control(stub.control_url, "GET", "/effects");
    assert.equal(effects2.count, 1);
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("crash after-charge-saved-before-request then recover same id", async () => {
  const stub = await startStub();
  const dir = stateDir();
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "50" };
    assert.equal((await runApp(env, ["open", "cust1", "sub1", "basic", "10", "90000", "3"])).code, 0);
    const crashed = await runApp(
      { ...env, NOW_MS: "20", CRASH_AT: "after-charge-saved-before-request" },
      ["renew"],
    );
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const st = jsonLine((await runApp({ ...env, NOW_MS: "20" }, ["status"])).out);
    assert.equal(st.payment, "attempt_saved");
    assert.ok(st.charge_id);
    const effects0 = await control(stub.control_url, "GET", "/effects");
    assert.equal(effects0.count, 0);
    const recovered = await runApp({ ...env, NOW_MS: "20" }, ["renew"]);
    assert.equal(recovered.code, 0, recovered.out + recovered.err);
    const body = jsonLine(recovered.out);
    assert.equal(body.charge_id, st.charge_id);
    assert.equal(body.status, "active");
    const effects1 = await control(stub.control_url, "GET", "/effects");
    assert.equal(effects1.count, 1);
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("crash after-accept-before-record then lookup adopt", async () => {
  const stub = await startStub();
  const dir = stateDir();
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "10" };
    assert.equal((await runApp(env, ["open", "cust1", "sub1", "basic", "10", "90000", "3"])).code, 0);
    const crashed = await runApp(
      { ...env, CRASH_AT: "after-accept-before-record" },
      ["renew"],
    );
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const st = jsonLine((await runApp(env, ["status"])).out);
    assert.equal(st.payment, "attempt_saved");
    const effects1 = await control(stub.control_url, "GET", "/effects");
    assert.equal(effects1.count, 1);
    const recovered = await runApp(env, ["renew"]);
    assert.equal(recovered.code, 0, recovered.out + recovered.err);
    assert.equal(jsonLine(recovered.out).status, "active");
    const effects2 = await control(stub.control_url, "GET", "/effects");
    assert.equal(effects2.count, 1);
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("crash after-record-before-exit leaves active no-op", async () => {
  const stub = await startStub();
  const dir = stateDir();
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "10" };
    assert.equal((await runApp(env, ["open", "cust1", "sub1", "basic", "10", "90000", "3"])).code, 0);
    const crashed = await runApp(
      { ...env, CRASH_AT: "after-record-before-exit" },
      ["renew"],
    );
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const st = jsonLine((await runApp(env, ["status"])).out);
    assert.equal(st.status, "active");
    assert.equal(st.payment, "paid");
    const again = await runApp(env, ["renew"]);
    assert.equal(again.code, 0);
    assert.equal(jsonLine(again.out).payment, "paid");
    const rec = await runApp(env, ["reconcile", st.charge_id]);
    assert.equal(rec.code, 0, rec.out);
    assert.equal(jsonLine(rec.out).lookup, "paid");
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("dropped reply then reconcile adopts without second post", async () => {
  const stub = await startStub();
  const dir = stateDir();
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "10" };
    assert.equal((await runApp(env, ["open", "cust1", "sub1", "basic", "10", "90000", "3"])).code, 0);
    await control(stub.control_url, "POST", "/fault", { drop_reply: true });
    const dropped = await runApp(env, ["renew"]);
    assert.notEqual(dropped.code, 0);
    assert.equal(jsonLine(dropped.out).error, "service_unavailable");
    const st = jsonLine((await runApp(env, ["status"])).out);
    assert.equal(st.payment, "attempt_saved");
    await control(stub.control_url, "POST", "/fault", { drop_reply: false });
    const posts1 = await control(stub.control_url, "GET", "/posts");
    const rec = await runApp(env, ["reconcile", st.charge_id]);
    assert.equal(rec.code, 0, rec.out + rec.err);
    const body = jsonLine(rec.out);
    assert.equal(body.lookup, "paid");
    assert.equal(body.status, "active");
    const posts2 = await control(stub.control_url, "GET", "/posts");
    assert.equal(posts2.count, posts1.count);
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("reconcile not_sent and charge_mismatch; unrelated files survive", async () => {
  const stub = await startStub();
  const dir = stateDir();
  const marker = join(dir, "keep-me.bin");
  writeFileSync(marker, Buffer.from([1, 2, 3, 9]));
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "10" };
    assert.equal((await runApp(env, ["open", "cust1", "sub1", "basic", "10", "90000", "2"])).code, 0);
    await control(stub.control_url, "POST", "/fault", { error_status: 503 });
    const failed = await runApp(env, ["renew"]);
    assert.equal(jsonLine(failed.out).error, "service_unavailable");
    await control(stub.control_url, "POST", "/fault", { error_status: 0 });
    const st = jsonLine((await runApp(env, ["status"])).out);
    const none = await runApp(env, ["reconcile", st.charge_id]);
    assert.equal(none.code, 0, none.out);
    assert.equal(jsonLine(none.out).lookup, "not_sent");
    const bad = await runApp(env, ["reconcile", "other-id"]);
    assert.notEqual(bad.code, 0);
    assert.equal(jsonLine(bad.out).error, "charge_mismatch");
    assert.deepEqual(readFileSync(marker), Buffer.from([1, 2, 3, 9]));
    const refused = await runApp({ ...env, NOW_MS: "0" }, ["renew"]);
    assert.equal(jsonLine(refused.out).error, "not_due");
    assert.deepEqual(readFileSync(marker), Buffer.from([1, 2, 3, 9]));
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("cancel, expire, retry_exhausted, callback ignore", async () => {
  const stub = await startStub();
  const dir = stateDir();
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "0" };
    assert.equal((await runApp(env, ["open", "custA", "subA", "team", "100", "50", "1"])).code, 0);
    const cbPath = join(dir, "cb.json");
    writeFileSync(cbPath, JSON.stringify({ type: "credit", cents: 5 }));
    const cb = await runApp(env, ["callback", cbPath]);
    assert.equal(cb.code, 0, cb.out);
    const cancelled = await runApp(env, ["cancel"]);
    assert.equal(cancelled.code, 0);
    assert.equal(jsonLine(cancelled.out).status, "cancelled");
    const renewC = await runApp({ ...env, NOW_MS: "100" }, ["renew"]);
    assert.equal(jsonLine(renewC.out).error, "cancelled");

    const dir2 = stateDir();
    const env2 = { STATE_DIR: dir2, SERVICE_URL: stub.service_url, NOW_MS: "0" };
    assert.equal((await runApp(env2, ["open", "custB", "subB", "basic", "10", "5", "1"])).code, 0);
    const late = await runApp({ ...env2, NOW_MS: "100" }, ["renew"]);
    assert.equal(jsonLine(late.out).error, "grace_elapsed");
    const st = jsonLine((await runApp(env2, ["status"])).out);
    assert.equal(st.status, "expired");

    const dir3 = stateDir();
    const env3 = { STATE_DIR: dir3, SERVICE_URL: stub.service_url, NOW_MS: "10" };
    assert.equal((await runApp(env3, ["open", "custC", "subC", "basic", "10", "90000", "1"])).code, 0);
    await control(stub.control_url, "POST", "/fault", { error_status: 500 });
    const fail1 = await runApp(env3, ["renew"]);
    assert.equal(jsonLine(fail1.out).error, "service_unavailable");
    await control(stub.control_url, "POST", "/fault", { error_status: 0 });
    const exhaust = await runApp(env3, ["renew"]);
    assert.equal(jsonLine(exhaust.out).error, "retry_exhausted");
    rmSync(dir2, { recursive: true, force: true });
    rmSync(dir3, { recursive: true, force: true });
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("downgrade proration, idempotence, and next charge amount", async () => {
  const stub = await startStub();
  const dir = stateDir();
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "0" };
    assert.equal((await runApp(env, ["open", "cust1", "sub1", "team", "2592000000", "1000", "3"])).code, 0);
    const half = "1296000000";
    const down = await runApp({ ...env, NOW_MS: half }, ["downgrade", "sub1", "basic"]);
    assert.equal(down.code, 0, down.out + down.err);
    const body = jsonLine(down.out);
    assert.equal(body.plan, "basic");
    assert.equal(body.last_plan, "team");
    assert.equal(body.proration_cents, 2500);
    const again = await runApp({ ...env, NOW_MS: half }, ["downgrade", "sub1", "basic"]);
    assert.equal(again.code, 0);
    assert.equal(jsonLine(again.out).proration_cents, 2500);
    const upgrade = await runApp({ ...env, NOW_MS: half }, ["downgrade", "sub1", "pro"]);
    assert.notEqual(upgrade.code, 0);
    assert.equal(jsonLine(upgrade.out).error, "bad_plan");
    const wrong = await runApp({ ...env, NOW_MS: half }, ["downgrade", "other", "basic"]);
    assert.notEqual(wrong.code, 0);
    const st = jsonLine((await runApp({ ...env, NOW_MS: half }, ["status"])).out);
    assert.equal(st.last_plan, "team");
    assert.equal(st.proration_cents, 2500);
    assert.equal(st.plan, "basic");
    const paid = await runApp({ ...env, NOW_MS: "2592000000" }, ["renew"]);
    assert.equal(paid.code, 0, paid.out + paid.err);
    const pb = jsonLine(paid.out);
    assert.equal(pb.amount_cents, 1);
    assert.equal(pb.status, "active");
    const st2 = jsonLine((await runApp({ ...env, NOW_MS: "2592000000" }, ["status"])).out);
    assert.equal(st2.proration_cents, 0);
    assert.equal(st2.first_failure_ms, null);
    const effects = await control(stub.control_url, "GET", "/effects");
    assert.equal(effects.count, 1);
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("revised grace uses first_failure_ms after a failed post", async () => {
  const stub = await startStub();
  const dir = stateDir();
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "0" };
    assert.equal((await runApp(env, ["open", "cust1", "sub1", "basic", "100", "20", "3"])).code, 0);
    await control(stub.control_url, "POST", "/fault", { error_status: 503 });
    const fail1 = await runApp({ ...env, NOW_MS: "115" }, ["renew"]);
    assert.equal(jsonLine(fail1.out).error, "service_unavailable");
    const st = jsonLine((await runApp({ ...env, NOW_MS: "115" }, ["status"])).out);
    assert.equal(st.first_failure_ms, 115);
    await control(stub.control_url, "POST", "/fault", { error_status: 0 });
    const still = await runApp({ ...env, NOW_MS: "125" }, ["renew"]);
    assert.equal(still.code, 0, still.out + still.err);
    assert.equal(jsonLine(still.out).status, "active");
    const dir2 = stateDir();
    const env2 = { STATE_DIR: dir2, SERVICE_URL: stub.service_url, NOW_MS: "0" };
    assert.equal((await runApp(env2, ["open", "cust2", "sub2", "basic", "100", "20", "3"])).code, 0);
    await control(stub.control_url, "POST", "/fault", { error_status: 500 });
    assert.equal(jsonLine((await runApp({ ...env2, NOW_MS: "115" }, ["renew"])).out).error, "service_unavailable");
    await control(stub.control_url, "POST", "/fault", { error_status: 0 });
    const late = await runApp({ ...env2, NOW_MS: "136" }, ["renew"]);
    assert.equal(jsonLine(late.out).error, "grace_elapsed");
    rmSync(dir2, { recursive: true, force: true });
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("downgrade then crash-saved charge recovers same amount", async () => {
  const stub = await startStub();
  const dir = stateDir();
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "0" };
    assert.equal((await runApp(env, ["open", "cust1", "sub1", "pro", "1000", "90000", "3"])).code, 0);
    const down = await runApp(env, ["downgrade", "sub1", "basic"]);
    assert.equal(down.code, 0, down.out);
    const credit = jsonLine(down.out).proration_cents;
    const expected = Math.max(1, 1000 - credit);
    const crashed = await runApp(
      { ...env, NOW_MS: "1000", CRASH_AT: "after-charge-saved-before-request" },
      ["renew"],
    );
    assert.ok(crashed.signal === "SIGKILL" || crashed.code !== 0);
    const st = jsonLine((await runApp({ ...env, NOW_MS: "1000" }, ["status"])).out);
    assert.equal(st.payment, "attempt_saved");
    assert.equal(st.amount_cents, expected);
    const cancel = await runApp({ ...env, NOW_MS: "1000" }, ["cancel"]);
    assert.equal(jsonLine(cancel.out).error, "charge_started");
    const recovered = await runApp({ ...env, NOW_MS: "1000" }, ["renew"]);
    assert.equal(recovered.code, 0, recovered.out + recovered.err);
    assert.equal(jsonLine(recovered.out).amount_cents, expected);
    const effects = await control(stub.control_url, "GET", "/effects");
    assert.equal(effects.count, 1);
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});

test("validation refusals", async () => {
  const stub = await startStub();
  const dir = stateDir();
  try {
    const env = { STATE_DIR: dir, SERVICE_URL: stub.service_url, NOW_MS: "0" };
    assert.equal(jsonLine((await runApp(env, ["open", "bad id", "sub", "basic", "0", "0", "1"])).out).error, "bad_args");
    assert.equal(jsonLine((await runApp(env, ["open", "cust", "sub", "gold", "0", "0", "1"])).out).error, "bad_plan");
    assert.equal(jsonLine((await runApp(env, ["open", "cust", "sub", "basic", "-1", "0", "1"])).out).error, "bad_time");
    assert.equal(jsonLine((await runApp(env, ["open", "cust", "sub", "basic", "0", "0", "0"])).out).error, "bad_retry");
    const missingNow = await runApp({ STATE_DIR: dir, SERVICE_URL: stub.service_url }, ["status"]);
    assert.notEqual(missingNow.code, 0);
  } finally {
    stub.child.kill("SIGKILL");
    rmSync(dir, { recursive: true, force: true });
  }
});
