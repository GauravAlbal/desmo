import { createHash, randomBytes } from "node:crypto";
import { existsSync, readFileSync, statSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  Kernel,
  StoreNotFoundError,
  classify,
} from "@ikaros/runtime";

const CYCLE_MS = 2592000000;
const AGGREGATE_ID = "ledger";
const PLANS = { basic: 1000, pro: 3000, team: 6000 };
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;

const EMPTY_STATUS = {
  customer_id: null,
  subscription_id: null,
  plan: null,
  renewal_ms: null,
  grace_ms: null,
  retry_limit: null,
  attempts: 0,
  first_failure_ms: null,
  credit_cents: 0,
  status: "none",
  payment: "none",
  charge_id: null,
  amount_cents: null,
  last_plan: null,
  proration_cents: 0,
};

function machinesDir() {
  return join(dirname(fileURLToPath(import.meta.url)), "..", "machines");
}

function machineV1Path() {
  return join(machinesDir(), "subscription_v1.ik.toml");
}

function machineV2Path() {
  return join(machinesDir(), "subscription.ik.toml");
}

function storePath(stateDir) {
  return join(stateDir, "ikaros.sqlite");
}

function fail(code) {
  process.stdout.write(JSON.stringify({ error: code }) + "\n");
  process.exit(1);
}

function ok(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(0);
}

function crashIf(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

function parseNow(raw) {
  if (raw === undefined || raw === "") return { error: "bad_args" };
  if (!/^[0-9]+$/.test(raw)) return { error: "bad_time" };
  try {
    const n = BigInt(raw);
    if (n < 0n) return { error: "bad_time" };
    return { value: n };
  } catch {
    return { error: "bad_time" };
  }
}

function parseNonNegInt(raw, err) {
  if (raw === undefined) return { error: "bad_args" };
  if (!/^[0-9]+$/.test(raw)) return { error: err };
  try {
    return { value: BigInt(raw) };
  } catch {
    return { error: err };
  }
}

function num(v) {
  if (v === undefined || v === null || v === "") return null;
  if (typeof v === "bigint") return Number(v);
  if (typeof v === "number") return v;
  if (typeof v === "string" && /^[0-9]+$/.test(v)) return Number(v);
  return v;
}

function factsOf(agg) {
  const state = agg.state && typeof agg.state === "object" ? agg.state : {};
  const facts = state.facts && typeof state.facts === "object" ? state.facts : state;
  return facts;
}

function named(agg) {
  if (typeof agg.namedState === "function") return agg.namedState();
  const s = agg.state;
  if (s && typeof s === "object" && typeof s.name === "string") return s.name;
  if (typeof s === "string") return s;
  return String(s);
}

function jsonInt(v) {
  if (typeof v === "bigint") return Number(v);
  return v;
}

function digestSnapshot(snap) {
  const canonical = JSON.stringify({
    charge_id: snap.charge_id,
    subscription_id: snap.subscription_id,
    plan: snap.plan,
    renewal_ms: snap.renewal_ms,
    amount_cents: snap.amount_cents,
  });
  return createHash("sha256").update(canonical).digest("hex");
}

function newChargeId() {
  return `chg_${randomBytes(12).toString("hex")}`;
}

function mapKernel(err) {
  if (err instanceof StoreNotFoundError) return "corrupt_state";
  const cls = classify(err);
  if (cls === "corrupt") return "corrupt_state";
  if (cls === "not_found") return "corrupt_state";
  return "corrupt_state";
}

async function openKernel(stateDir) {
  const store = storePath(stateDir);
  const kernel = new Kernel(store);
  const v1 = await kernel.machine(machineV1Path());
  const v2 = await kernel.machine(machineV2Path());
  return { kernel, v1, v2, machine: v2, store };
}

function routeMachine(agg, v1, v2) {
  if (agg && agg.owner && typeof agg.owner.equals === "function") {
    if (v1.identity.equals(agg.owner)) return v1;
    if (v2.identity.equals(agg.owner)) return v2;
  }
  return v2;
}

async function loadAgg(stateDir) {
  const store = storePath(stateDir);
  if (!existsSync(store)) return { missing: true };
  try {
    const st = statSync(store);
    if (st.size === 0) return { corrupt: true };
  } catch {
    return { corrupt: true };
  }
  try {
    const { kernel, v1, v2 } = await openKernel(stateDir);
    let agg = await v2.show(AGGREGATE_ID);
    const machine = routeMachine(agg, v1, v2);
    if (!machine.identity.equals(v2.identity)) {
      agg = await machine.show(AGGREGATE_ID);
    }
    return { kernel, machine, agg, v1, v2 };
  } catch (err) {
    if (err instanceof StoreNotFoundError) return { missing: true };
    const cls = classify(err);
    if (cls === "corrupt") return { corrupt: true };
    if (cls === "not_found") return { missing: true };
    return { corrupt: true };
  }
}

function snapshotFromFacts(f) {
  return {
    charge_id: f.charge_id,
    subscription_id: f.subscription_id,
    plan: f.charge_plan || f.plan,
    renewal_ms: num(f.charge_renewal_ms ?? f.cycle_renewal_ms),
    amount_cents: num(f.amount_cents),
  };
}

function viewStatus(agg) {
  const f = factsOf(agg);
  const status = named(agg);
  const payment = f.payment || "none";
  const first = num(f.first_failure_ms);
  const amount = num(f.amount_cents);
  const charge = f.charge_id ? f.charge_id : null;
  return {
    customer_id: f.customer_id ?? null,
    subscription_id: f.subscription_id ?? null,
    plan: f.plan ?? null,
    renewal_ms: num(f.renewal_ms),
    grace_ms: num(f.grace_ms),
    retry_limit: num(f.retry_limit),
    attempts: num(f.attempts) ?? 0,
    first_failure_ms: first === 0 ? null : first,
    credit_cents: num(f.credit_cents) ?? 0,
    status: status === "empty" ? "none" : status,
    payment,
    charge_id: charge,
    amount_cents: amount === 0 && !charge ? null : amount,
    last_plan: f.last_plan ? f.last_plan : null,
    proration_cents: num(f.credit_cents) ?? 0,
  };
}

function graceDeadlineMs(f) {
  const cycle = BigInt(f.cycle_renewal_ms);
  const grace = BigInt(f.grace_ms);
  const first = num(f.first_failure_ms);
  if (first) return BigInt(first) + grace;
  return cycle + grace;
}

function chargeAmountCents(f) {
  const price = PLANS[f.plan];
  const credit = num(f.credit_cents) ?? 0;
  return Math.max(1, price - credit);
}

function successBody(agg) {
  const f = factsOf(agg);
  return {
    subscription_id: f.subscription_id,
    charge_id: f.charge_id,
    amount_cents: num(f.amount_cents),
    status: "active",
    payment: "paid",
    renewal_ms: num(f.renewal_ms),
  };
}

function matchesProvider(body, snap) {
  if (!body || typeof body !== "object") return false;
  return (
    body.charge_id === snap.charge_id &&
    body.subscription_id === snap.subscription_id &&
    body.plan === snap.plan &&
    Number(body.renewal_ms) === Number(snap.renewal_ms) &&
    Number(body.amount_cents) === Number(snap.amount_cents) &&
    body.outcome === "charged"
  );
}

async function httpJson(method, url, body) {
  try {
    const res = await fetch(url, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    if (res.status >= 500) return { kind: "unavailable", status: res.status };
    if (!text) return { kind: "incomplete" };
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      return { kind: "incomplete" };
    }
    return { kind: "http", status: res.status, json };
  } catch {
    return { kind: "fail" };
  }
}

async function getCharge(serviceUrl, chargeId) {
  const base = serviceUrl.replace(/\/$/, "");
  return httpJson("GET", `${base}/v1/charges/${encodeURIComponent(chargeId)}`);
}

async function postCharge(serviceUrl, snap) {
  const base = serviceUrl.replace(/\/$/, "");
  return httpJson("POST", `${base}/v1/charges`, snap);
}

async function recordIfPending(agg, outcomeDigest) {
  if (!agg.pendingIntent) return agg;
  const rec = await agg.recordEffectOutcome(outcomeDigest, { intent: agg.pendingIntent });
  if (rec && typeof rec.namedState === "function") return rec;
  const shown = await agg.machine.show(AGGREGATE_ID);
  return shown;
}

async function adoptPaid(agg) {
  const f = factsOf(agg);
  const newRenewal = BigInt(f.cycle_renewal_ms) + BigInt(CYCLE_MS);
  const args = { new_renewal_ms: jsonInt(newRenewal), attempts: 0, payment: "paid" };
  if (agg.owner && Number(agg.owner.version) === 2) {
    args.first_failure_ms = 0;
    args.credit_cents = 0;
  }
  const executed = await agg.execute({
    name: "adopt",
    args,
  });
  if (executed && typeof executed.namedState === "function") return executed;
  return agg.machine.show(AGGREGATE_ID);
}

async function noteFailure(agg, nowMs) {
  const f = factsOf(agg);
  if (num(f.first_failure_ms)) return agg;
  try {
    const next = await agg.execute({
      name: "note_failure",
      args: { now_ms: jsonInt(nowMs) },
    });
    if (next && typeof next.namedState === "function") return next;
  } catch {
    /* already noted */
  }
  return agg.machine.show(AGGREGATE_ID);
}

export async function main(argv) {
  const cmd = argv[0];
  const serviceUrl = process.env.SERVICE_URL;
  const stateDir = process.env.STATE_DIR;
  if (!serviceUrl) fail("bad_args");
  if (!stateDir) fail("bad_args");
  const nowP = parseNow(process.env.NOW_MS);
  if (nowP.error) fail(nowP.error);
  const nowMs = nowP.value;

  if (!cmd) fail("bad_args");

  if (cmd === "status") {
    const loaded = await loadAgg(stateDir);
    if (loaded.corrupt) fail("corrupt_state");
    if (loaded.missing) ok(EMPTY_STATUS);
    ok(viewStatus(loaded.agg));
  }

  if (cmd === "open") {
    const customer_id = argv[1];
    const subscription_id = argv[2];
    const plan = argv[3];
    const renewalRaw = argv[4];
    const graceRaw = argv[5];
    const retryRaw = argv[6];
    if (!customer_id || !subscription_id || !plan || renewalRaw === undefined || graceRaw === undefined || retryRaw === undefined) {
      fail("bad_args");
    }
    if (!ID_RE.test(customer_id) || !ID_RE.test(subscription_id)) fail("bad_args");
    if (!Object.hasOwn(PLANS, plan)) fail("bad_plan");
    const renewal = parseNonNegInt(renewalRaw, "bad_time");
    if (renewal.error) fail(renewal.error);
    const grace = parseNonNegInt(graceRaw, "bad_time");
    if (grace.error) fail(grace.error);
    if (!/^[0-9]+$/.test(retryRaw)) fail("bad_retry");
    const retry = BigInt(retryRaw);
    if (retry < 1n || retry > 10n) fail("bad_retry");

    const existing = await loadAgg(stateDir);
    if (existing.corrupt) fail("corrupt_state");
    if (!existing.missing) fail("already_open");

    try {
      const { machine } = await openKernel(stateDir);
      const created = await machine.createWith({
        aggregateId: AGGREGATE_ID,
        command: {
          name: "open",
          args: {
            customer_id,
            subscription_id,
            plan,
            renewal_ms: jsonInt(renewal.value),
            grace_ms: jsonInt(grace.value),
            retry_limit: jsonInt(retry),
            payment: "none",
          },
        },
      });
      const agg = created && typeof created.namedState === "function" ? created : await machine.show(AGGREGATE_ID);
      const f = factsOf(agg);
      ok({
        customer_id: f.customer_id,
        subscription_id: f.subscription_id,
        plan: f.plan,
        renewal_ms: num(f.renewal_ms),
        grace_ms: num(f.grace_ms),
        retry_limit: num(f.retry_limit),
        status: "active",
        payment: "none",
        charge_id: null,
      });
    } catch (err) {
      fail(mapKernel(err));
    }
  }

  if (cmd === "downgrade") {
    const subscription_id = argv[1];
    const new_plan = argv[2];
    if (!subscription_id || !new_plan) fail("bad_args");
    if (!ID_RE.test(subscription_id)) fail("bad_args");
    if (!Object.hasOwn(PLANS, new_plan)) fail("bad_plan");
    const loaded = await loadAgg(stateDir);
    if (loaded.corrupt) fail("corrupt_state");
    if (loaded.missing) fail("bad_args");
    const status = named(loaded.agg);
    const f = factsOf(loaded.agg);
    if (f.subscription_id !== subscription_id) fail("bad_args");
    if (status === "cancelled") fail("cancelled");
    if (status === "expired") fail("grace_elapsed");
    if (status !== "active") fail("charge_started");
    if (f.payment && f.payment !== "none") fail("charge_started");
    if (f.plan === new_plan) {
      ok({
        subscription_id: f.subscription_id,
        plan: f.plan,
        last_plan: f.last_plan || null,
        proration_cents: num(f.credit_cents) ?? 0,
        status: "active",
        payment: "none",
      });
    }
    if (PLANS[new_plan] >= PLANS[f.plan]) fail("bad_plan");
    if (loaded.v1 && loaded.machine.identity.equals(loaded.v1.identity)) fail("bad_args");
    const remain = nowMs > BigInt(f.renewal_ms) ? 0n : BigInt(f.renewal_ms) - nowMs;
    const delta = BigInt(PLANS[f.plan] - PLANS[new_plan]);
    const credit = (delta * remain) / BigInt(CYCLE_MS);
    try {
      const next = await loaded.agg.execute({
        name: "downgrade",
        args: {
          new_plan,
          last_plan: f.plan,
          credit_cents: jsonInt(credit),
        },
      });
      const agg = next && typeof next.namedState === "function" ? next : await loaded.machine.show(AGGREGATE_ID);
      const nf = factsOf(agg);
      ok({
        subscription_id: nf.subscription_id,
        plan: nf.plan,
        last_plan: nf.last_plan || f.plan,
        proration_cents: num(nf.credit_cents) ?? 0,
        status: "active",
        payment: "none",
      });
    } catch (err) {
      fail(mapKernel(err));
    }
  }

  if (cmd === "cancel") {
    const loaded = await loadAgg(stateDir);
    if (loaded.corrupt) fail("corrupt_state");
    if (loaded.missing) fail("bad_args");
    const status = named(loaded.agg);
    const f = factsOf(loaded.agg);
    if (status === "cancelled" || status === "expired") fail("cancelled");
    if (f.payment && f.payment !== "none") fail("charge_started");
    try {
      const next = await loaded.agg.execute({ name: "cancel", args: {} });
      const agg = next && typeof next.namedState === "function" ? next : await loaded.machine.show(AGGREGATE_ID);
      ok({ subscription_id: factsOf(agg).subscription_id, status: "cancelled", payment: "none" });
    } catch (err) {
      fail(mapKernel(err));
    }
  }

  if (cmd === "callback") {
    const p = argv[1];
    if (!p) fail("bad_args");
    let text;
    try {
      text = readFileSync(p, "utf8");
    } catch {
      fail("bad_callback");
    }
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      fail("bad_callback");
    }
    if (json === null || typeof json !== "object" || Array.isArray(json)) fail("bad_callback");
    const loaded = await loadAgg(stateDir);
    if (loaded.corrupt) fail("corrupt_state");
    if (loaded.missing) ok({ ignored: true });
    ok({ ignored: true, status: named(loaded.agg) });
  }

  if (cmd === "reconcile") {
    const chargeId = argv[1];
    if (!chargeId || !ID_RE.test(chargeId)) fail("bad_args");
    const loaded = await loadAgg(stateDir);
    if (loaded.corrupt) fail("corrupt_state");
    if (loaded.missing) fail("no_charge");
    let agg = loaded.agg;
    const f0 = factsOf(agg);
    if (!f0.charge_id) fail("no_charge");
    if (f0.charge_id !== chargeId) fail("charge_mismatch");
    const snap = snapshotFromFacts(f0);
    const got = await getCharge(serviceUrl, chargeId);
    if (got.kind === "fail" || got.kind === "incomplete" || got.kind === "unavailable") fail("service_unavailable");
    if (got.status === 404) {
      ok({
        lookup: "not_sent",
        subscription_id: f0.subscription_id,
        charge_id: chargeId,
        payment: "attempt_saved",
        status: named(agg) === "past_due" ? "past_due" : named(agg),
      });
    }
    if (got.status !== 200) fail("service_unavailable");
    if (!matchesProvider(got.json, snap)) fail("lookup_conflict");
    const outcomeDigest = createHash("sha256").update(JSON.stringify(got.json)).digest("hex");
    if (named(agg) !== "active" || f0.payment !== "paid") {
      try {
        agg = await recordIfPending(agg, outcomeDigest);
        if (named(agg) === "past_due") agg = await adoptPaid(agg);
      } catch (err) {
        fail(mapKernel(err));
      }
    }
    crashIf("after-record-before-exit");
    ok({ ...successBody(agg), lookup: "paid" });
  }

  if (cmd === "renew") {
    const loaded = await loadAgg(stateDir);
    if (loaded.corrupt) fail("corrupt_state");
    if (loaded.missing) fail("bad_args");
    let agg = loaded.agg;
    let f = factsOf(agg);
    const status = named(agg);
    if (status === "cancelled") fail("cancelled");
    if (status === "expired") fail("grace_elapsed");
    if (status !== "active" && status !== "past_due") fail("bad_args");

    const cycle = BigInt(f.cycle_renewal_ms);
    const grace = BigInt(f.grace_ms);
    const retryLimit = BigInt(f.retry_limit);

    if (f.payment === "paid" && status === "active" && nowMs < cycle) {
      ok(successBody(agg));
    }

    const deadline = graceDeadlineMs(f);
    if (nowMs > deadline) {
      if (status !== "expired") {
        try {
          await agg.execute({ name: "expire", args: {} });
        } catch (err) {
          fail(mapKernel(err));
        }
      }
      fail("grace_elapsed");
    }

    if (nowMs < cycle) fail("not_due");

    const hasAttempt = f.payment === "attempt_saved" && f.charge_id;

    if (!hasAttempt) {
      const attempts = BigInt(f.attempts ?? 0);
      if (attempts >= retryLimit) fail("retry_exhausted");
      const amount = chargeAmountCents(f);
      const chargeId = newChargeId();
      const snap = {
        charge_id: chargeId,
        subscription_id: f.subscription_id,
        plan: f.plan,
        renewal_ms: Number(cycle),
        amount_cents: amount,
      };
      const payloadDigest = digestSnapshot(snap);
      try {
        const next = await agg.execute({
          name: "save_attempt",
          args: {
            charge_id: chargeId,
            amount_cents: amount,
            payload_digest: payloadDigest,
            charge_plan: f.plan,
            charge_renewal_ms: jsonInt(cycle),
            attempts: jsonInt(attempts + 1n),
            payment: "attempt_saved",
          },
        });
        agg = next && typeof next.namedState === "function" ? next : await loaded.machine.show(AGGREGATE_ID);
      } catch (err) {
        fail(mapKernel(err));
      }
      crashIf("after-charge-saved-before-request");
      const posted = await postCharge(serviceUrl, snap);
      return finishPost(agg, snap, posted, nowMs);
    }

    const snap = snapshotFromFacts(f);
    const looked = await getCharge(serviceUrl, f.charge_id);
    if (looked.kind === "fail" || looked.kind === "incomplete" || looked.kind === "unavailable") {
      fail("service_unavailable");
    }
    if (looked.status === 200) {
      if (!matchesProvider(looked.json, snap)) fail("lookup_conflict");
      crashIf("after-accept-before-record");
      const outcomeDigest = createHash("sha256").update(JSON.stringify(looked.json)).digest("hex");
      try {
        agg = await recordIfPending(agg, outcomeDigest);
        if (named(agg) === "past_due") agg = await adoptPaid(agg);
      } catch (err) {
        fail(mapKernel(err));
      }
      crashIf("after-record-before-exit");
      ok(successBody(agg));
    }
    if (looked.status !== 404) fail("service_unavailable");

    const attempts = BigInt(f.attempts ?? 0);
    const hadFailure = Boolean(num(f.first_failure_ms));
    if (hadFailure && attempts >= retryLimit) fail("retry_exhausted");
    if (hadFailure) {
      try {
        const next = await agg.execute({
          name: "retry_post",
          args: { attempts: jsonInt(attempts + 1n) },
        });
        agg = next && typeof next.namedState === "function" ? next : await loaded.machine.show(AGGREGATE_ID);
      } catch {
        fail("retry_exhausted");
      }
    }
    crashIf("after-charge-saved-before-request");
    const posted = await postCharge(serviceUrl, snap);
    return finishPost(agg, snap, posted, nowMs);
  }

  fail("bad_args");
}

async function finishPost(agg, snap, posted, nowMs) {
  if (posted.kind === "fail" || posted.kind === "incomplete" || posted.kind === "unavailable" || (posted.kind === "http" && posted.status >= 500)) {
    try {
      await noteFailure(agg, nowMs);
    } catch {
      /* ignore */
    }
    process.stdout.write(JSON.stringify({ error: "service_unavailable" }) + "\n");
    process.exit(1);
  }
  if (posted.status === 409) fail("lookup_conflict");
  if (posted.status !== 200 || !matchesProvider(posted.json, snap)) {
    try {
      await noteFailure(agg, nowMs);
    } catch {
      /* ignore */
    }
    process.stdout.write(JSON.stringify({ error: "service_unavailable" }) + "\n");
    process.exit(1);
  }
  crashIf("after-accept-before-record");
  const outcomeDigest = createHash("sha256").update(JSON.stringify(posted.json)).digest("hex");
  try {
    let next = await recordIfPending(agg, outcomeDigest);
    if (named(next) === "past_due") next = await adoptPaid(next);
    crashIf("after-record-before-exit");
    ok(successBody(next));
  } catch (err) {
    fail(mapKernel(err));
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main(process.argv.slice(2)).catch(() => fail("corrupt_state"));
}
