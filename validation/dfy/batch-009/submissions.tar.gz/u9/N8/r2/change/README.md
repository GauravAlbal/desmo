# Subscription renewal ledger

Durable local ledger for one customer subscription. Lifecycle authority is the Ikaros kernel; this host owns CLI, HTTP, and the clock.

## Setup

Node 22 is required (`<home>/.nvm/versions/node/v22.17.1/bin/node`).

```bash
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x run
```

Start the fake card service (prints `service_url`):

```bash
node stub/server.mjs
```

## Run

Required environment: `STATE_DIR`, `SERVICE_URL`, `NOW_MS` (non-negative integer epoch ms). Optional `CRASH_AT` labels: `after-charge-saved-before-request`, `after-accept-before-record`, `after-record-before-exit`.

```bash
STATE_DIR=/tmp/ledger SERVICE_URL=http://127.0.0.1:PORT NOW_MS=0 ./run status
STATE_DIR=/tmp/ledger SERVICE_URL=http://127.0.0.1:PORT NOW_MS=0 ./run open cust1 sub1 basic 1000 5000 3
STATE_DIR=/tmp/ledger SERVICE_URL=http://127.0.0.1:PORT NOW_MS=1000 ./run renew
STATE_DIR=/tmp/ledger SERVICE_URL=http://127.0.0.1:PORT NOW_MS=1000 ./run status
STATE_DIR=/tmp/ledger SERVICE_URL=http://127.0.0.1:PORT NOW_MS=1000 ./run reconcile <charge_id>
STATE_DIR=/tmp/ledger SERVICE_URL=http://127.0.0.1:PORT NOW_MS=0 ./run cancel
STATE_DIR=/tmp/ledger SERVICE_URL=http://127.0.0.1:PORT NOW_MS=0 ./run callback /path/to/callback.json
```

Each invocation prints one JSON object. Exit 0 is success; refusals are nonzero `{ "error": "<code>" }`.

## Tests

```bash
node --test tests/app.test.js
```
