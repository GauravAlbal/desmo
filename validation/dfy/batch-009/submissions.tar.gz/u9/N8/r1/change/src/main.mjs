import { createHash, randomBytes } from "node:crypto";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  Kernel,
  StoreNotFoundError,
  KernelError,
  classify,
  HistoricalResult,
} from "@ikaros/runtime";

const CYCLE_MS = 2592000000n;
const AGGREGATE_ID = "ledger";
const ID_RE = /^[A-Za-z0-9._-]{1,64}$/;
const INT_RE = /^(0|[1-9][0-9]*)$/;
const PLANS = { basic: 1000, pro: 3000, team: 6000 };
const ROOT = path.dirname(fileURLToPath(import.meta.url));
const MACHINE_V1 = path.join(ROOT, "..", "machines", "subscription.ik.toml");
const MACHINE_V2 = path.join(ROOT, "..", "machines", "subscription_v2.ik.toml");

function fail(code) {
  process.stdout.write(JSON.stringify({ error: code }) + "\n");
  process.exit(1);
}

function ok(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
  process.exit(0);
}

function crashIf(label) {
  if (process.env.CRASH_AT === label) {
    process.kill(process.pid, "SIGKILL");
  }
}

function asInt(v) {
  if (typeof v === "bigint") return v;
  if (typeof v === "number" && Number.isSafeInteger(v)) return BigInt(v);
  if (typeof v === "string" && /^-?\d+$/.test(v)) return BigInt(v);
  return 0n;
}

function asStr(v) {
  if (v == null) return null;
  const s = String(v);
  return s === "" ? null : s;
}

function factsOf(agg) {
  const st = agg.state && typeof agg.state === "object" ? agg.state : {};
  return st.facts && typeof st.facts === "object" ? { ...st, ...st.facts } : st;
}

function paymentOf(name, f) {
  if (name === "past_due") return "attempt_saved";
  if (name === "active_paid") return "paid";
  if (name === "expired" && asStr(f.charge_id)) return "attempt_saved";
  return "none";
}

function statusName(name) {
  if (name === "empty") return "none";
  if (name === "active_paid") return "active";
  return name;
}

function machineVersion(agg) {
  if (!agg || !agg.owner) return 2n;
  return asInt(agg.owner.version);
}

function publicStatus(agg) {
  if (!agg) {
    return {
      customer_id: null,
      subscription_id: null,
      plan: null,
      last_plan: null,
      renewal_ms: null,
      grace_ms: null,
      retry_limit: null,
      attempts: 0,
      first_failure_ms: null,
      credit_cents: 0,
      proration_cents: 0,
      status: "none",
      payment: "none",
      charge_id: null,
      amount_cents: null,
    };
  }
  const name = agg.namedState();
  const f = factsOf(agg);
  const first = asInt(f.first_failure_ms);
  const amount = asInt(f.amount_cents);
  const cid = asStr(f.charge_id);
  const proration = asInt(f.proration_cents);
  const credit = asInt(f.credit_cents);
  return {
    customer_id: asStr(f.customer_id),
    subscription_id: asStr(f.subscription_id),
    plan: asStr(f.plan),
    last_plan: asStr(f.last_plan),
    renewal_ms: Number(asInt(f.renewal_ms)),
    grace_ms: Number(asInt(f.grace_ms)),
    retry_limit: Number(asInt(f.retry_limit)),
    attempts: Number(asInt(f.attempts)),
    first_failure_ms: first === 0n ? null : Number(first),
    credit_cents: Number(credit),
    proration_cents: Number(proration !== 0n ? proration : credit),
    status: statusName(name),
    payment: paymentOf(name, f),
    charge_id: cid,
    amount_cents: cid ? Number(amount) : null,
  };
}

function successBody(agg) {
  const f = factsOf(agg);
  return {
    subscription_id: asStr(f.subscription_id),
    charge_id: asStr(f.charge_id),
    amount_cents: Number(asInt(f.amount_cents)),
    status: "active",
    payment: "paid",
    renewal_ms: Number(asInt(f.renewal_ms)),
  };
}

function downgradeBody(agg) {
  const st = publicStatus(agg);
  return {
    subscription_id: st.subscription_id,
    plan: st.plan,
    last_plan: st.last_plan,
    proration_cents: st.proration_cents,
    credit_cents: st.credit_cents,
    status: st.status,
    payment: st.payment,
  };
}

function mapKernelErr(err) {
  if (err instanceof StoreNotFoundError) return "not_open";
  const cls = classify(err);
  if (cls === "corrupt") return "corrupt_state";
  if (err && typeof err === "object") {
    const rule = err.rule || err.code || "";
    if (String(rule).includes("corrupt") || String(err.code || "").includes("CORRUPT")) {
      return "corrupt_state";
    }
  }
  return "refused";
}

function storePath() {
  const dir = process.env.STATE_DIR;
  if (!dir) fail("bad_args");
  return path.join(dir, "ikaros.sqlite");
}

function requireEnv() {
  if (!process.env.SERVICE_URL || process.env.SERVICE_URL === "") fail("bad_args");
  if (process.env.NOW_MS == null || process.env.NOW_MS === "") fail("bad_args");
  if (!INT_RE.test(process.env.NOW_MS)) fail("bad_time");
  return { now: BigInt(process.env.NOW_MS), url: process.env.SERVICE_URL.replace(/\/$/, "") };
}

function parseId(v) {
  if (typeof v !== "string" || !ID_RE.test(v)) fail("bad_args");
  return v;
}

function parsePlan(v) {
  if (!Object.prototype.hasOwnProperty.call(PLANS, v)) fail("bad_plan");
  return v;
}

function parseTime(v) {
  if (typeof v !== "string" || !INT_RE.test(v)) fail("bad_time");
  return BigInt(v);
}

function parseRetry(v) {
  if (typeof v !== "string" || !INT_RE.test(v)) fail("bad_retry");
  const n = BigInt(v);
  if (n < 1n || n > 10n) fail("bad_retry");
  return n;
}

function snapshotOf(f) {
  return {
    charge_id: asStr(f.charge_id),
    subscription_id: asStr(f.subscription_id),
    plan: asStr(f.plan),
    renewal_ms: Number(asInt(f.renewal_ms)),
    amount_cents: Number(asInt(f.amount_cents)),
  };
}

function payloadDigest(snap) {
  const canonical = JSON.stringify({
    amount_cents: snap.amount_cents,
    charge_id: snap.charge_id,
    plan: snap.plan,
    renewal_ms: snap.renewal_ms,
    subscription_id: snap.subscription_id,
  });
  return createHash("sha256").update(canonical).digest("hex");
}

function digestBody(body) {
  return createHash("sha256").update(body).digest("hex");
}

function matchCharge(body, snap) {
  if (!body || typeof body !== "object") return false;
  return (
    body.charge_id === snap.charge_id &&
    body.subscription_id === snap.subscription_id &&
    body.plan === snap.plan &&
    Number(body.renewal_ms) === snap.renewal_ms &&
    Number(body.amount_cents) === snap.amount_cents &&
    body.outcome === "charged"
  );
}

function chargeAmount(f) {
  const plan = asStr(f.plan);
  const price = PLANS[plan];
  const credit = asInt(f.proration_cents) !== 0n ? asInt(f.proration_cents) : asInt(f.credit_cents);
  const raw = BigInt(price) - credit;
  return raw < 1n ? 1n : raw;
}

function retryDeadline(f, ver) {
  const renewal = asInt(f.renewal_ms);
  const grace = asInt(f.grace_ms);
  const first = asInt(f.first_failure_ms);
  if (ver >= 2n && first > 0n) return first + grace;
  return renewal + grace;
}

async function httpJson(method, url, payload) {
  let res;
  try {
    res = await fetch(url, {
      method,
      headers: payload ? { "content-type": "application/json" } : undefined,
      body: payload ? JSON.stringify(payload) : undefined,
    });
  } catch {
    return { kind: "transport" };
  }
  let text = "";
  try {
    text = await res.text();
  } catch {
    return { kind: "incomplete", status: res.status };
  }
  if (res.status >= 500) return { kind: "unavailable", status: res.status, text };
  let json = null;
  try {
    json = text === "" ? null : JSON.parse(text);
  } catch {
    return { kind: "incomplete", status: res.status, text };
  }
  if (res.status === 404) return { kind: "not_found", status: 404, json, text };
  if (res.status === 409) return { kind: "conflict", status: 409, json, text };
  if (res.status !== 200 || json == null || typeof json !== "object") {
    return { kind: "incomplete", status: res.status, json, text };
  }
  return { kind: "ok", status: 200, json, text };
}

async function openKernel() {
  const store = storePath();
  const kernel = new Kernel(store);
  try {
    const v1 = await kernel.machine(MACHINE_V1);
    const v2 = await kernel.machine(MACHINE_V2);
    return { kernel, v1, v2, missing: false };
  } catch (err) {
    if (err instanceof StoreNotFoundError) return { kernel, v1: null, v2: null, missing: true };
    const code = mapKernelErr(err);
    fail(code);
  }
}

async function showOn(machine) {
  try {
    return await machine.show(AGGREGATE_ID);
  } catch (err) {
    if (err instanceof StoreNotFoundError) return null;
    const cls = classify(err);
    if (cls === "not_found") return null;
    fail(mapKernelErr(err));
  }
}

async function showLedger(v1, v2) {
  const probe = (await showOn(v2)) || (await showOn(v1));
  if (!probe) return null;
  if (v2 && probe.owner && probe.owner.equals(v2.identity)) return await showOn(v2);
  if (v1 && probe.owner && probe.owner.equals(v1.identity)) return await showOn(v1);
  return probe;
}

async function execCmd(agg, name, args) {
  try {
    const r = await agg.command(name, args);
    if (r instanceof HistoricalResult) return await agg.machine.show(AGGREGATE_ID);
    return r;
  } catch (err) {
    fail(mapKernelErr(err));
  }
}

function newChargeId() {
  return "c" + randomBytes(16).toString("hex");
}

async function adoptPaid(agg, text) {
  crashIf("after-accept-before-record");
  const intent = agg.pendingIntent;
  if (intent) {
    try {
      const rec = await agg.recordEffectOutcome(digestBody(text), { intent });
      if (!(rec instanceof HistoricalResult)) agg = rec;
      else agg = await agg.machine.show(AGGREGATE_ID);
    } catch (err) {
      const cls = classify(err);
      if (cls !== "historical") fail(mapKernelErr(err));
      agg = await agg.machine.show(AGGREGATE_ID);
    }
  }
  const f = factsOf(agg);
  const next = asInt(f.renewal_ms) + CYCLE_MS;
  const args =
    machineVersion(agg) >= 2n
      ? { new_renewal_ms: next, first_failure_ms: 0n, credit_cents: 0n, proration_cents: 0n }
      : { new_renewal_ms: next };
  agg = await execCmd(agg, "complete", args);
  crashIf("after-record-before-exit");
  return agg;
}

async function markFailure(agg, now) {
  const f = factsOf(agg);
  if (asInt(f.first_failure_ms) === 0n) {
    agg = await execCmd(agg, "note_failure", { now_ms: now });
  }
  return agg;
}

async function postSaved(agg, url, now) {
  const f = factsOf(agg);
  const snap = snapshotOf(f);
  crashIf("after-charge-saved-before-request");
  const posted = await httpJson("POST", url + "/v1/charges", snap);
  if (posted.kind === "ok") {
    if (!matchCharge(posted.json, snap)) fail("lookup_conflict");
    agg = await adoptPaid(agg, posted.text);
    ok(successBody(agg));
  }
  if (posted.kind === "conflict") fail("lookup_conflict");
  agg = await markFailure(agg, now);
  fail("service_unavailable");
}

async function cmdOpen(argv) {
  requireEnv();
  if (argv.length !== 6) fail("bad_args");
  const customer_id = parseId(argv[0]);
  const subscription_id = parseId(argv[1]);
  const plan = parsePlan(argv[2]);
  const renewal_ms = parseTime(argv[3]);
  const grace_ms = parseTime(argv[4]);
  const retry_limit = parseRetry(argv[5]);
  const { kernel, v1, v2, missing } = await openKernel();
  if (!missing) {
    const existing = await showLedger(v1, v2);
    if (existing && existing.namedState() !== "empty") fail("already_open");
  }
  const k = missing ? new Kernel(storePath()) : kernel;
  const m = missing ? await k.machine(MACHINE_V2) : v2;
  try {
    const created = await m.createWith({
      aggregateId: AGGREGATE_ID,
      command: {
        name: "open",
        args: {
          customer_id,
          subscription_id,
          plan,
          renewal_ms,
          grace_ms,
          retry_limit,
        },
      },
    });
    const agg = created instanceof HistoricalResult ? await m.show(AGGREGATE_ID) : created;
    const st = publicStatus(agg);
    ok({
      customer_id: st.customer_id,
      subscription_id: st.subscription_id,
      plan: st.plan,
      renewal_ms: st.renewal_ms,
      grace_ms: st.grace_ms,
      retry_limit: st.retry_limit,
      status: "active",
      payment: "none",
      charge_id: null,
    });
  } catch (err) {
    fail(mapKernelErr(err));
  }
}

async function cmdStatus() {
  requireEnv();
  const { v1, v2, missing } = await openKernel();
  if (missing) ok(publicStatus(null));
  const agg = await showLedger(v1, v2);
  ok(publicStatus(agg));
}

async function cmdCancel() {
  requireEnv();
  const { v1, v2, missing } = await openKernel();
  if (missing) fail("not_open");
  const agg = await showLedger(v1, v2);
  if (!agg) fail("not_open");
  const name = agg.namedState();
  if (name === "cancelled") fail("cancelled");
  if (name === "expired") fail("expired");
  if (name === "past_due" || name === "active_paid" || asStr(factsOf(agg).charge_id)) {
    fail("charge_started");
  }
  if (name !== "active") fail("refused");
  const next = await execCmd(agg, "cancel", {});
  ok({ subscription_id: asStr(factsOf(next).subscription_id), status: "cancelled", payment: "none" });
}

async function cmdDowngrade(argv) {
  const { now } = requireEnv();
  if (argv.length !== 2) fail("bad_args");
  const subscription_id = parseId(argv[0]);
  const new_plan = parsePlan(argv[1]);
  const { v1, v2, missing } = await openKernel();
  if (missing) fail("not_open");
  const agg = await showLedger(v1, v2);
  if (!agg) fail("not_open");
  const name = agg.namedState();
  const f = factsOf(agg);
  if (asStr(f.subscription_id) !== subscription_id) fail("refused");
  if (name === "cancelled") fail("cancelled");
  if (name === "expired") fail("expired");
  if (name === "past_due" || name === "active_paid" || asStr(f.charge_id)) fail("charge_started");
  if (name !== "active") fail("refused");
  const current = asStr(f.plan);
  if (new_plan === current) ok(downgradeBody(agg));
  if (machineVersion(agg) < 2n) fail("refused");
  if (PLANS[new_plan] >= PLANS[current]) fail("refused");
  const remaining = asInt(f.renewal_ms) - now;
  const num = BigInt(PLANS[current] - PLANS[new_plan]) * (remaining > 0n ? remaining : 0n);
  const proration = num / CYCLE_MS;
  const next = await execCmd(agg, "downgrade", {
    subscription_id,
    new_plan,
    last_plan: current,
    proration_cents: proration,
  });
  ok(downgradeBody(next));
}

async function cmdCallback(argv) {
  requireEnv();
  if (argv.length !== 1) fail("bad_args");
  const p = argv[0];
  let raw;
  try {
    raw = readFileSync(p, "utf8");
  } catch {
    fail("bad_callback");
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    fail("bad_callback");
  }
  if (parsed == null || typeof parsed !== "object" || Array.isArray(parsed)) fail("bad_callback");
  const { v1, v2, missing } = await openKernel();
  if (missing) ok({ ignored: true });
  const agg = await showLedger(v1, v2);
  ok({ ignored: true, status: agg ? statusName(agg.namedState()) : "none" });
}

async function cmdReconcile(argv) {
  const { url } = requireEnv();
  if (argv.length !== 1) fail("bad_args");
  const chargeId = parseId(argv[0]);
  const { v1, v2, missing } = await openKernel();
  if (missing) fail("no_charge");
  let agg = await showLedger(v1, v2);
  if (!agg) fail("no_charge");
  const name = agg.namedState();
  const f = factsOf(agg);
  const saved = asStr(f.charge_id);
  if (!saved) fail("no_charge");
  if (saved !== chargeId) fail("charge_mismatch");
  if (name === "active_paid") {
    ok({ ...successBody(agg), lookup: "paid" });
  }
  const looked = await httpJson("GET", url + "/v1/charges/" + encodeURIComponent(saved));
  if (looked.kind === "transport" || looked.kind === "incomplete" || looked.kind === "unavailable") {
    fail("service_unavailable");
  }
  if (looked.kind === "not_found") {
    ok({
      lookup: "not_sent",
      subscription_id: asStr(f.subscription_id),
      charge_id: saved,
      payment: "attempt_saved",
      status: "past_due",
    });
  }
  if (looked.kind !== "ok") fail("service_unavailable");
  const snap = snapshotOf(f);
  if (!matchCharge(looked.json, snap)) fail("lookup_conflict");
  if (name === "past_due") {
    agg = await adoptPaid(agg, looked.text);
    ok({ ...successBody(agg), lookup: "paid" });
  }
  fail("lookup_conflict");
}

async function cmdRenew() {
  const { now, url } = requireEnv();
  const { v1, v2, missing } = await openKernel();
  if (missing) fail("not_open");
  let agg = await showLedger(v1, v2);
  if (!agg) fail("not_open");
  const name = agg.namedState();
  const f0 = factsOf(agg);
  if (name === "cancelled") fail("cancelled");
  if (name === "expired") fail("expired");
  if (name === "empty") fail("not_open");
  if (name === "active_paid") ok(successBody(agg));

  const renewal = asInt(f0.renewal_ms);
  const limit = asInt(f0.retry_limit);
  const attempts = asInt(f0.attempts);
  const saved = asStr(f0.charge_id);
  const ver = machineVersion(agg);
  const deadline = retryDeadline(f0, ver);
  const inGrace = now >= renewal && now <= deadline;
  const pastGrace = now > deadline;

  if (saved) {
    const looked = await httpJson("GET", url + "/v1/charges/" + encodeURIComponent(saved));
    if (looked.kind === "ok") {
      const snap = snapshotOf(factsOf(agg));
      if (!matchCharge(looked.json, snap)) fail("lookup_conflict");
      agg = await adoptPaid(agg, looked.text);
      ok(successBody(agg));
    }
    if (looked.kind === "transport" || looked.kind === "incomplete" || looked.kind === "unavailable") {
      fail("service_unavailable");
    }
    if (looked.kind === "not_found") {
      if (pastGrace) {
        agg = await execCmd(agg, "expire", { now_ms: now });
        fail("grace_elapsed");
      }
      if (!inGrace) fail("not_due");
      if (attempts >= limit) fail("retry_exhausted");
      agg = await execCmd(agg, "count_retry", { now_ms: now });
      await postSaved(agg, url, now);
    }
    fail("service_unavailable");
  }

  if (pastGrace) {
    agg = await execCmd(agg, "expire", { now_ms: now });
    fail("grace_elapsed");
  }
  if (now < renewal) fail("not_due");
  if (attempts >= limit) fail("retry_exhausted");
  const amount = chargeAmount(f0);
  const chargeId = newChargeId();
  const snap = {
    charge_id: chargeId,
    subscription_id: asStr(f0.subscription_id),
    plan: asStr(f0.plan),
    renewal_ms: Number(renewal),
    amount_cents: Number(amount),
  };
  const digest = payloadDigest(snap);
  agg = await execCmd(agg, "save_charge", {
    charge_id: chargeId,
    amount_cents: amount,
    payload_digest: digest,
    now_ms: now,
  });
  await postSaved(agg, url, now);
}

async function main() {
  const argv = process.argv.slice(2);
  const cmd = argv[0];
  if (!cmd) fail("bad_args");
  try {
    if (cmd === "open") return await cmdOpen(argv.slice(1));
    if (cmd === "renew") return await cmdRenew();
    if (cmd === "cancel") return await cmdCancel();
    if (cmd === "downgrade") return await cmdDowngrade(argv.slice(1));
    if (cmd === "reconcile") return await cmdReconcile(argv.slice(1));
    if (cmd === "status") return await cmdStatus();
    if (cmd === "callback") return await cmdCallback(argv.slice(1));
    fail("bad_args");
  } catch (err) {
    if (err && err.exitCode) throw err;
    fail(mapKernelErr(err instanceof KernelError ? err : err));
  }
}

main();
