import { spawn, spawnSync } from "node:child_process";
import { createServer } from "node:http";
import { mkdtempSync, writeFileSync, readFileSync, chmodSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import assert from "node:assert/strict";

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..");
const RUN = path.join(ROOT, "run");
const NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node";
const STUB = path.join(ROOT, "stub", "server.mjs");

function tmp() {
  return mkdtempSync(path.join(tmpdir(), "sub-ledger-"));
}

function runCli(env, args) {
  const r = spawnSync(RUN, args, {
    env: { ...process.env, ...env },
    encoding: "utf8",
  });
  let json = null;
  try {
    json = JSON.parse((r.stdout || "").trim());
  } catch {
    json = { parse_error: true, stdout: r.stdout, stderr: r.stderr };
  }
  return { code: r.status, json, stderr: r.stderr, signal: r.signal };
}

function startStub() {
  return new Promise((resolve, reject) => {
    const child = spawn(NODE, [STUB], { stdio: ["ignore", "pipe", "pipe"] });
    let buf = "";
    const onData = (d) => {
      buf += d.toString();
      const nl = buf.indexOf("\n");
      if (nl !== -1) {
        child.stdout.off("data", onData);
        try {
          resolve({ child, info: JSON.parse(buf.slice(0, nl)) });
        } catch (e) {
          reject(e);
        }
      }
    };
    child.stdout.on("data", onData);
    child.on("error", reject);
  });
}

async function fault(control, body) {
  await fetch(control + "/fault", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function effects(control) {
  const r = await fetch(control + "/effects");
  return r.json();
}

test("open persists across processes and status empty shape", () => {
  const dir = tmp();
  const env = { STATE_DIR: dir, SERVICE_URL: "http://127.0.0.1:9", NOW_MS: "0" };
  const empty = runCli(env, ["status"]);
  assert.equal(empty.code, 0);
  assert.equal(empty.json.status, "none");
  assert.equal(empty.json.attempts, 0);
  assert.equal(empty.json.credit_cents, 0);
  assert.equal(empty.json.proration_cents, 0);
  assert.equal(empty.json.last_plan, null);
  assert.equal(empty.json.payment, "none");
  assert.equal(empty.json.charge_id, null);
  const opened = runCli(env, ["open", "cust1", "sub1", "basic", "10000", "5000", "3"]);
  assert.equal(opened.code, 0, JSON.stringify(opened));
  assert.equal(opened.json.status, "active");
  assert.equal(opened.json.plan, "basic");
  const again = runCli({ ...env, NOW_MS: "1" }, ["status"]);
  assert.equal(again.json.customer_id, "cust1");
  assert.equal(again.json.subscription_id, "sub1");
  const dup = runCli(env, ["open", "cust1", "sub1", "basic", "10000", "5000", "3"]);
  assert.equal(dup.code, 1);
  assert.equal(dup.json.error, "already_open");
});

test("unrelated STATE_DIR files keep bytes through open and refusal", () => {
  const dir = tmp();
  const marker = path.join(dir, "keep-me.bin");
  const bytes = Buffer.from([1, 2, 3, 9, 0, 255]);
  writeFileSync(marker, bytes);
  const env = { STATE_DIR: dir, SERVICE_URL: "http://127.0.0.1:9", NOW_MS: "0" };
  runCli(env, ["open", "cust1", "sub1", "pro", "1", "1", "1"]);
  runCli(env, ["open", "x", "y", "pro", "1", "1", "1"]);
  runCli(env, ["renew"]);
  assert.deepEqual(readFileSync(marker), bytes);
});

test("not_due cancel expire and paid path", async () => {
  const { child, info } = await startStub();
  try {
    const dir = tmp();
    const env = {
      STATE_DIR: dir,
      SERVICE_URL: info.service_url,
      NOW_MS: "100",
    };
    const opened = runCli(env, ["open", "cust1", "sub1", "team", "1000", "8000", "2"]);
    assert.equal(opened.code, 0, JSON.stringify(opened));
    const early = runCli(env, ["renew"]);
    assert.equal(early.json.error, "not_due");
    const paid = runCli({ ...env, NOW_MS: "1000" }, ["renew"]);
    assert.equal(paid.code, 0, JSON.stringify(paid));
    assert.equal(paid.json.status, "active");
    assert.equal(paid.json.payment, "paid");
    assert.equal(paid.json.amount_cents, 6000);
    assert.equal(paid.json.renewal_ms, 1000 + 2592000000);
    const again = runCli({ ...env, NOW_MS: "1000" }, ["renew"]);
    assert.equal(again.code, 0);
    assert.equal(again.json.payment, "paid");
    const fx = await effects(info.control_url);
    assert.equal(fx.count, 1);
    const dir2 = tmp();
    const env2 = { STATE_DIR: dir2, SERVICE_URL: info.service_url, NOW_MS: "5" };
    runCli(env2, ["open", "c2", "s2", "basic", "10", "5", "3"]);
    const cancelled = runCli(env2, ["cancel"]);
    assert.equal(cancelled.json.status, "cancelled");
    const nr = runCli({ ...env2, NOW_MS: "10" }, ["renew"]);
    assert.equal(nr.json.error, "cancelled");
    const dir3 = tmp();
    const env3 = { STATE_DIR: dir3, SERVICE_URL: info.service_url, NOW_MS: "100" };
    runCli(env3, ["open", "c3", "s3", "basic", "10", "5", "3"]);
    const ge = runCli({ ...env3, NOW_MS: "20" }, ["renew"]);
    assert.equal(ge.json.error, "grace_elapsed");
    const st = runCli({ ...env3, NOW_MS: "20" }, ["status"]);
    assert.equal(st.json.status, "expired");
  } finally {
    child.kill("SIGKILL");
  }
});

test("crash labels, lost reply, reconcile", async () => {
  const { child, info } = await startStub();
  try {
    const dir = tmp();
    const base = { STATE_DIR: dir, SERVICE_URL: info.service_url, NOW_MS: "50" };
    runCli(base, ["open", "cust1", "sub1", "basic", "10", "100000", "3"]);
    const crashed = runCli(
      { ...base, CRASH_AT: "after-charge-saved-before-request" },
      ["renew"],
    );
    assert.equal(crashed.code, null);
    const mid = runCli(base, ["status"]);
    assert.equal(mid.json.payment, "attempt_saved");
    assert.ok(mid.json.charge_id);
    const fx0 = await effects(info.control_url);
    assert.equal(fx0.count, 0);
    const recovered = runCli(base, ["renew"]);
    assert.equal(recovered.code, 0, JSON.stringify(recovered));
    assert.equal(recovered.json.payment, "paid");
    const fx1 = await effects(info.control_url);
    assert.equal(fx1.count, 1);

    const dirB = tmp();
    const envB = { STATE_DIR: dirB, SERVICE_URL: info.service_url, NOW_MS: "50" };
    runCli(envB, ["open", "cust1", "sub2", "pro", "10", "100000", "3"]);
    const c2 = runCli({ ...envB, CRASH_AT: "after-accept-before-record" }, ["renew"]);
    assert.equal(c2.code, null);
    const st2 = runCli(envB, ["status"]);
    assert.equal(st2.json.payment, "attempt_saved");
    const fx2 = await effects(info.control_url);
    assert.equal(fx2.count, 2);
    const rec2 = runCli(envB, ["renew"]);
    assert.equal(rec2.code, 0, JSON.stringify(rec2));
    assert.equal(rec2.json.payment, "paid");
    const fx2b = await effects(info.control_url);
    assert.equal(fx2b.count, 2);

    const dirC = tmp();
    const envC = { STATE_DIR: dirC, SERVICE_URL: info.service_url, NOW_MS: "50" };
    runCli(envC, ["open", "cust1", "sub3", "basic", "10", "100000", "3"]);
    const c3 = runCli({ ...envC, CRASH_AT: "after-record-before-exit" }, ["renew"]);
    assert.equal(c3.code, null);
    const st3 = runCli(envC, ["status"]);
    assert.equal(st3.json.status, "active");
    assert.equal(st3.json.payment, "paid");
    const nop = runCli(envC, ["renew"]);
    assert.equal(nop.json.payment, "paid");

    const dirD = tmp();
    const envD = { STATE_DIR: dirD, SERVICE_URL: info.service_url, NOW_MS: "50" };
    runCli(envD, ["open", "cust1", "sub4", "basic", "10", "100000", "3"]);
    await fault(info.control_url, { drop_reply: true });
    const drop = runCli(envD, ["renew"]);
    assert.equal(drop.json.error, "service_unavailable");
    await fault(info.control_url, { drop_reply: false });
    const stD = runCli(envD, ["status"]);
    const recD = runCli(envD, ["reconcile", stD.json.charge_id]);
    assert.equal(recD.code, 0, JSON.stringify(recD));
    assert.equal(recD.json.lookup, "paid");
    assert.equal(recD.json.payment, "paid");

    const dirE = tmp();
    const envE = { STATE_DIR: dirE, SERVICE_URL: info.service_url, NOW_MS: "50" };
    runCli(envE, ["open", "cust1", "sub5", "basic", "10", "100000", "3"]);
    runCli({ ...envE, CRASH_AT: "after-charge-saved-before-request" }, ["renew"]);
    const stE = runCli(envE, ["status"]);
    const ns = runCli(envE, ["reconcile", stE.json.charge_id]);
    assert.equal(ns.code, 0, JSON.stringify(ns));
    assert.equal(ns.json.lookup, "not_sent");
    const bad = runCli(envE, ["reconcile", "not-the-id"]);
    assert.equal(bad.json.error, "charge_mismatch");
  } finally {
    child.kill("SIGKILL");
  }
});

test("callback ignore and bad_callback", () => {
  const dir = tmp();
  const env = { STATE_DIR: dir, SERVICE_URL: "http://127.0.0.1:9", NOW_MS: "0" };
  runCli(env, ["open", "cust1", "sub1", "basic", "10", "10", "2"]);
  const good = path.join(dir, "cb.json");
  writeFileSync(good, JSON.stringify({ status: "expired", charge_id: "x" }));
  const cb = runCli(env, ["callback", good]);
  assert.equal(cb.code, 0);
  const st = runCli(env, ["status"]);
  assert.equal(st.json.status, "active");
  const badp = path.join(dir, "bad.json");
  writeFileSync(badp, "not-json");
  const b = runCli(env, ["callback", badp]);
  assert.equal(b.json.error, "bad_callback");
});

test("missing env and bad plan", () => {
  const dir = tmp();
  const r = spawnSync(RUN, ["status"], {
    env: { ...process.env, STATE_DIR: dir, NOW_MS: "0" },
    encoding: "utf8",
  });
  assert.notEqual(r.status, 0);
  const r2 = runCli(
    { STATE_DIR: dir, SERVICE_URL: "http://127.0.0.1:9", NOW_MS: "0" },
    ["open", "c", "s", "gold", "1", "1", "1"],
  );
  assert.equal(r2.json.error, "bad_plan");
});

test("downgrade proration idempotent and refuses upgrade", () => {
  const dir = tmp();
  const env = { STATE_DIR: dir, SERVICE_URL: "http://127.0.0.1:9", NOW_MS: "1000" };
  runCli(env, ["open", "cust1", "sub1", "team", "2592001000", "5000", "3"]);
  const d1 = runCli(env, ["downgrade", "sub1", "pro"]);
  assert.equal(d1.code, 0, JSON.stringify(d1));
  assert.equal(d1.json.plan, "pro");
  assert.equal(d1.json.last_plan, "team");
  assert.equal(d1.json.proration_cents, 3000);
  const again = runCli(env, ["downgrade", "sub1", "pro"]);
  assert.equal(again.code, 0);
  assert.equal(again.json.proration_cents, 3000);
  const st = runCli({ ...env, NOW_MS: "2" }, ["status"]);
  assert.equal(st.json.plan, "pro");
  assert.equal(st.json.last_plan, "team");
  assert.equal(st.json.proration_cents, 3000);
  const up = runCli(env, ["downgrade", "sub1", "team"]);
  assert.equal(up.code, 1);
  assert.equal(up.json.error, "refused");
  const wrong = runCli(env, ["downgrade", "other", "basic"]);
  assert.equal(wrong.json.error, "refused");
  const after = runCli(env, ["status"]);
  assert.equal(after.json.plan, "pro");
  assert.equal(after.json.proration_cents, 3000);
});

test("proration applied once then cleared on paid renew", async () => {
  const { child, info } = await startStub();
  try {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: info.service_url, NOW_MS: "1000" };
    runCli(env, ["open", "cust1", "sub1", "team", "2592001000", "8000", "2"]);
    const d = runCli(env, ["downgrade", "sub1", "basic"]);
    assert.equal(d.json.proration_cents, 5000);
    const paid = runCli({ ...env, NOW_MS: "2592001000" }, ["renew"]);
    assert.equal(paid.code, 0, JSON.stringify(paid));
    assert.equal(paid.json.amount_cents, 1);
    assert.equal(paid.json.payment, "paid");
    const st = runCli(env, ["status"]);
    assert.equal(st.json.proration_cents, 0);
    assert.equal(st.json.credit_cents, 0);
    assert.equal(st.json.first_failure_ms, null);
    assert.equal(st.json.last_plan, "team");
    const fx = await effects(info.control_url);
    assert.equal(fx.count, 1);
    const nop = runCli({ ...env, NOW_MS: "2592001000" }, ["renew"]);
    assert.equal(nop.json.payment, "paid");
    const fx2 = await effects(info.control_url);
    assert.equal(fx2.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

test("revised grace uses first_failure_ms", async () => {
  const { child, info } = await startStub();
  try {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: info.service_url, NOW_MS: "12" };
    runCli(env, ["open", "cust1", "sub1", "basic", "10", "20", "3"]);
    await fault(info.control_url, { error_status: 503 });
    const fail1 = runCli(env, ["renew"]);
    assert.equal(fail1.json.error, "service_unavailable");
    const st = runCli(env, ["status"]);
    assert.equal(st.json.first_failure_ms, 12);
    assert.equal(st.json.payment, "attempt_saved");
    await fault(info.control_url, { error_status: 0 });
    const mid = runCli({ ...env, NOW_MS: "31" }, ["renew"]);
    assert.equal(mid.code, 0, JSON.stringify(mid));
    assert.equal(mid.json.payment, "paid");

    const dir2 = tmp();
    const env2 = { STATE_DIR: dir2, SERVICE_URL: info.service_url, NOW_MS: "12" };
    runCli(env2, ["open", "c2", "s2", "basic", "10", "20", "3"]);
    await fault(info.control_url, { error_status: 503 });
    runCli(env2, ["renew"]);
    await fault(info.control_url, { error_status: 0 });
    const expired = runCli({ ...env2, NOW_MS: "33" }, ["renew"]);
    assert.equal(expired.json.error, "grace_elapsed");
  } finally {
    child.kill("SIGKILL");
  }
});

test("downgrade blocked after saved charge crash", async () => {
  const { child, info } = await startStub();
  try {
    const dir = tmp();
    const env = { STATE_DIR: dir, SERVICE_URL: info.service_url, NOW_MS: "50" };
    runCli(env, ["open", "cust1", "sub1", "team", "10", "100000", "3"]);
    runCli({ ...env, CRASH_AT: "after-charge-saved-before-request" }, ["renew"]);
    const dg = runCli(env, ["downgrade", "sub1", "pro"]);
    assert.equal(dg.json.error, "charge_started");
    const cancel = runCli(env, ["cancel"]);
    assert.equal(cancel.json.error, "charge_started");
    const paid = runCli(env, ["renew"]);
    assert.equal(paid.code, 0, JSON.stringify(paid));
    assert.equal(paid.json.amount_cents, 6000);
    const fx = await effects(info.control_url);
    assert.equal(fx.count, 1);
  } finally {
    child.kill("SIGKILL");
  }
});

