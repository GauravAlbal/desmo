# Subscription renewal ledger

Durable local ledger for one customer subscription. Lifecycle authority lives in Ikaros (`machines/subscription.ik.toml`). The Node host owns CLI, HTTP, and crash labels.

## Setup

Node 22 is required (`<home>/.nvm/versions/node/v22.17.1/bin/node` or another Node 22 on `PATH`).

```bash
npm install --offline --no-audit --no-fund KIT/npm/ikaros-runtime-0.5.0.tgz KIT/npm/ikaros-darwin-arm64-0.5.0.tgz
chmod +x run
```

Start the fake card service (prints `{ "service_url": "..." }`):

```bash
node stub/server.mjs
```

## Run

Every command needs `STATE_DIR`, `SERVICE_URL`, and `NOW_MS` (epoch milliseconds, canonical non-negative integer). Optional `CRASH_AT` is one of `after-charge-saved-before-request`, `after-accept-before-record`, `after-record-before-exit`.

```bash
export STATE_DIR=/tmp/sub-ledger
export SERVICE_URL=http://127.0.0.1:PORT
export NOW_MS=0
./run open cust1 sub1 basic 1000 86400000 3
./run status
./run renew
./run reconcile CHARGE_ID
./run cancel
./run callback /path/to/callback.json
```

`./run` prints one JSON object. Exit 0 is success; refusals are nonzero `{ "error": "<code>" }`.

## Tests

```bash
node --test test/ledger.test.mjs
```
