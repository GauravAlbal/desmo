#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import re
import signal
import sys
import urllib.error
import urllib.request
from typing import Any, Dict, List, Optional, Tuple

from invariant_kernel import (
    CommandInvalidError,
    HistoricalResult,
    IllegalStateError,
    Kernel,
    MachineError,
    StoreNotFoundError,
    TransportError,
    classify,
)

ROOT = os.path.dirname(os.path.abspath(__file__))
ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
EMAIL_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}@[A-Za-z0-9.-]{1,63}$")
MS_RE = re.compile(r"^(0|[1-9][0-9]{0,12})$")
MS_MAX = 9999999999999
GRACE_MS = 86400000
PLACEHOLDER = "-"

ENV_V1 = os.path.join(ROOT, "machines", "envelope.ik.toml")
ENV_V2 = os.path.join(ROOT, "machines", "envelope_v2.ik.toml")
DOC_MACHINE = os.path.join(ROOT, "machines", "document.ik.toml")


class AppError(Exception):
    def __init__(self, code: str) -> None:
        self.code = code


def fail(code: str) -> None:
    raise AppError(code)


def maybe_crash(label: str) -> None:
    if os.environ.get("CRASH_AT") == label:
        os.kill(os.getpid(), signal.SIGKILL)


def parse_ms(text: str) -> int:
    if not MS_RE.match(text):
        fail("bad_args")
    value = int(text)
    if value > MS_MAX:
        fail("bad_args")
    return value


def parse_id(text: str) -> str:
    if not ID_RE.match(text):
        fail("bad_args")
    return text


def parse_email(text: str) -> str:
    if not EMAIL_RE.match(text):
        fail("bad_args")
    return text


def state_dir() -> str:
    path = os.environ.get("STATE_DIR")
    if not path:
        fail("bad_args")
    os.makedirs(path, exist_ok=True)
    return path


def service_url() -> str:
    url = os.environ.get("SERVICE_URL")
    if not url:
        fail("bad_args")
    return url.rstrip("/")


def env_store() -> str:
    return os.path.join(state_dir(), "envelopes.sqlite")


def doc_store() -> str:
    return os.path.join(state_dir(), "documents.sqlite")


def kernel_for(store: str) -> Kernel:
    binary = os.environ.get("IK_BINARY") or os.path.join(ROOT, "KIT", "bin", "ik")
    return Kernel(store, binary=binary)


def exists_on_machine(store: str, machine_path: str, aggregate_id: str) -> bool:
    if not os.path.exists(store):
        return False
    kernel = kernel_for(store)
    try:
        kernel.machine(machine_path).show(aggregate_id)
        return True
    except StoreNotFoundError:
        return False
    except MachineError:
        return False
    except Exception as exc:
        if classify(exc) == "not_found":
            return False
        raise


def exists_envelope(aggregate_id: str) -> bool:
    return exists_on_machine(env_store(), ENV_V2, aggregate_id) or exists_on_machine(
        env_store(), ENV_V1, aggregate_id
    )


def exists_document(aggregate_id: str) -> bool:
    return exists_on_machine(doc_store(), DOC_MACHINE, aggregate_id)


def id_taken(ident: str) -> bool:
    return exists_envelope(ident) or exists_document(ident)


def load_envelope(envelope_id: str, required: bool = True):
    store = env_store()
    if not os.path.exists(store):
        if required:
            fail("unknown_envelope")
        return None, None
    kernel = kernel_for(store)
    last_not_found = False
    for path in (ENV_V2, ENV_V1):
        machine = kernel.machine(path)
        try:
            agg = machine.show(envelope_id)
        except StoreNotFoundError:
            last_not_found = True
            continue
        except MachineError:
            continue
        except Exception as exc:
            if classify(exc) == "not_found":
                last_not_found = True
                continue
            raise
        if agg.owner == machine.identity:
            return machine, agg
    if required:
        fail("unknown_envelope")
    return None, None


def is_dual(agg) -> bool:
    facts = agg.facts
    if "dual" in facts:
        return int(facts["dual"]) == 1
    signer2 = str(facts.get("signer2_id") or "")
    return signer2 not in ("", PLACEHOLDER)


def public_state(state: str) -> str:
    if state in ("attempting", "s1_recorded", "attempting_s2"):
        return "draft"
    return state


def send_status(state: str) -> str:
    if state == "draft":
        return "none"
    if state in ("attempting", "s1_recorded", "attempting_s2"):
        return "attempt_saved"
    return "sent"


def request_of(agg) -> Optional[str]:
    value = agg.facts.get("request_id")
    if value is None or value == "":
        return None
    return str(value)


def request_s2_of(agg) -> Optional[str]:
    value = agg.facts.get("request_id_s2")
    if value is None or value == "":
        return None
    return str(value)


def expiry_of(agg) -> int:
    facts = agg.facts
    if "expiry_ms" in facts:
        return int(facts["expiry_ms"])
    return int(facts["deadline_ms"])


def status_obj(envelope_id: str, agg) -> Dict[str, Any]:
    facts = agg.facts
    obj = {
        "envelope_id": envelope_id,
        "document_id": str(facts["document_id"]),
        "signer_id": str(facts["signer_id"]),
        "address": str(facts["address"]),
        "deadline_ms": int(facts["deadline_ms"]),
        "state": public_state(agg.state),
        "send": send_status(agg.state),
        "request_id": request_of(agg),
        "now_ms": int(facts["created_now_ms"]),
    }
    if is_dual(agg):
        obj["signer2_id"] = str(facts["signer2_id"])
        obj["address2"] = str(facts["address2"])
        obj["request_id_s2"] = request_s2_of(agg)
    return obj


def request_id_for(envelope_id: str, agg, slot: str) -> str:
    if slot == "s1":
        return envelope_id + ".s1"
    if slot == "s2":
        return envelope_id + ".s2"
    return envelope_id


def payload_for_slot(envelope_id: str, agg, slot: str) -> Dict[str, Any]:
    facts = agg.facts
    request_id = request_id_for(envelope_id, agg, slot)
    if slot == "s2":
        signer_id = str(facts["signer2_id"])
        address = str(facts["address2"])
    else:
        signer_id = str(facts["signer_id"])
        address = str(facts["address"])
    return {
        "request_id": request_id,
        "envelope_id": envelope_id,
        "document_id": str(facts["document_id"]),
        "signer_id": signer_id,
        "address": address,
        "deadline_ms": int(facts["deadline_ms"]),
        "kind": "signature_request",
    }


def payload_digest(payload: Dict[str, Any]) -> str:
    blob = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def digest_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def matching_record(body: Dict[str, Any], payload: Dict[str, Any]) -> bool:
    for key in (
        "request_id",
        "envelope_id",
        "document_id",
        "signer_id",
        "address",
        "deadline_ms",
        "kind",
    ):
        if body.get(key) != payload.get(key):
            return False
    return True


def http_json(method: str, url: str, payload: Optional[Dict[str, Any]] = None) -> Tuple[int, Optional[Dict[str, Any]], str]:
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            raw = resp.read().decode("utf-8")
            status = resp.getcode()
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8") if exc.fp else ""
        status = exc.code
    except Exception:
        fail("service_unavailable")
    if raw == "" and method == "POST":
        fail("service_unavailable")
    try:
        body = json.loads(raw) if raw else None
    except json.JSONDecodeError:
        fail("service_unavailable")
    if body is not None and not isinstance(body, dict):
        fail("service_unavailable")
    return status, body, raw


def lookup_request(request_id: str) -> Tuple[int, Optional[Dict[str, Any]], str]:
    url = service_url() + "/v1/requests/" + urllib.request.quote(request_id, safe="")
    return http_json("GET", url)


def post_envelope(payload: Dict[str, Any]) -> Tuple[int, Optional[Dict[str, Any]], str]:
    return http_json("POST", service_url() + "/v1/envelopes", payload)


def settle(result):
    if isinstance(result, HistoricalResult):
        return None
    return result


def claim_document(document_id: str, envelope_id: str) -> None:
    doc_k = kernel_for(doc_store())
    doc_m = doc_k.machine(DOC_MACHINE)
    claimed = doc_m.create_with(
        document_id,
        {"name": "claim", "args": {"envelope_id": envelope_id}},
        operation_id="claim:" + document_id,
    )
    if isinstance(claimed, HistoricalResult):
        fail("id_in_use")


def cmd_create(args: list) -> Dict[str, Any]:
    if len(args) == 6:
        envelope_id = parse_id(args[0])
        document_id = parse_id(args[1])
        signer_id = parse_id(args[2])
        address = parse_email(args[3])
        deadline_ms = parse_ms(args[4])
        now_ms = parse_ms(args[5])
        if deadline_ms < now_ms:
            fail("bad_args")
        for ident in {envelope_id, document_id}:
            if id_taken(ident):
                fail("id_in_use")
        env_k = kernel_for(env_store())
        env_m = env_k.machine(ENV_V2)
        created = env_m.create_with(
            envelope_id,
            {
                "name": "open",
                "args": {
                    "document_id": document_id,
                    "signer_id": signer_id,
                    "address": address,
                    "signer2_id": PLACEHOLDER,
                    "address2": PLACEHOLDER,
                    "deadline_ms": deadline_ms,
                    "created_now_ms": now_ms,
                    "expiry_ms": deadline_ms,
                    "dual": 0,
                },
            },
            operation_id="open:" + envelope_id,
        )
        if isinstance(created, HistoricalResult):
            fail("id_in_use")
        claim_document(document_id, envelope_id)
        return {
            "envelope_id": envelope_id,
            "document_id": document_id,
            "signer_id": signer_id,
            "address": address,
            "deadline_ms": deadline_ms,
            "state": "draft",
            "send": "none",
            "now_ms": now_ms,
        }
    if len(args) == 8:
        envelope_id = parse_id(args[0])
        document_id = parse_id(args[1])
        signer1_id = parse_id(args[2])
        address1 = parse_email(args[3])
        signer2_id = parse_id(args[4])
        address2 = parse_email(args[5])
        deadline_ms = parse_ms(args[6])
        now_ms = parse_ms(args[7])
        if signer1_id == signer2_id:
            fail("bad_args")
        if deadline_ms < now_ms:
            fail("bad_args")
        names = [envelope_id, document_id, signer1_id, signer2_id]
        if len(set(names)) != 4:
            fail("id_in_use")
        for ident in names:
            if id_taken(ident):
                fail("id_in_use")
        env_k = kernel_for(env_store())
        env_m = env_k.machine(ENV_V2)
        expiry_ms = deadline_ms + GRACE_MS
        created = env_m.create_with(
            envelope_id,
            {
                "name": "open_dual",
                "args": {
                    "document_id": document_id,
                    "signer_id": signer1_id,
                    "address": address1,
                    "signer2_id": signer2_id,
                    "address2": address2,
                    "deadline_ms": deadline_ms,
                    "created_now_ms": now_ms,
                    "expiry_ms": expiry_ms,
                    "dual": 1,
                },
            },
            operation_id="open:" + envelope_id,
        )
        if isinstance(created, HistoricalResult):
            fail("id_in_use")
        claim_document(document_id, envelope_id)
        claim_document(signer1_id, envelope_id)
        claim_document(signer2_id, envelope_id)
        return {
            "envelope_id": envelope_id,
            "document_id": document_id,
            "signer_id": signer1_id,
            "address": address1,
            "signer2_id": signer2_id,
            "address2": address2,
            "deadline_ms": deadline_ms,
            "state": "draft",
            "send": "none",
            "now_ms": now_ms,
        }
    fail("bad_args")
    return {}


def record_acceptance(agg, raw: str):
    pending = agg.pending_intent
    if pending is None:
        if agg.effect.status in ("recorded", "completed") or agg.effect.outcome_digest:
            return agg
        fail("service_unavailable")
    result = agg.record_effect_outcome(digest_text(raw), intent=pending)
    settled = settle(result)
    return settled if settled is not None else agg.show()


def finish_slot(agg, honor_record_crash: bool):
    if agg.state == "attempting" and is_dual(agg):
        result = agg.command("mark_s1")
        settle(result)
        return agg.show()
    if agg.state == "attempting":
        result = agg.command("mark_sent")
        committed_now = not isinstance(result, HistoricalResult)
        settled = settle(result)
        agg = settled if settled is not None else agg.show()
        if honor_record_crash and committed_now:
            maybe_crash("after-record-before-exit")
        return agg
    if agg.state == "attempting_s2":
        result = agg.command("mark_sent_dual")
        committed_now = not isinstance(result, HistoricalResult)
        settled = settle(result)
        agg = settled if settled is not None else agg.show()
        if honor_record_crash and committed_now:
            maybe_crash("after-record-before-exit")
        return agg
    return agg


def adopt_from_lookup(agg, payload: Dict[str, Any], honor_record_crash: bool):
    status, body, raw = lookup_request(payload["request_id"])
    if status == 404:
        return None
    if status != 200 or body is None:
        fail("service_unavailable")
    if not matching_record(body, payload):
        fail("conflict")
    agg = record_acceptance(agg, raw)
    return finish_slot(agg, honor_record_crash)


def effect_already_recorded(agg) -> bool:
    return agg.effect.status in ("recorded", "completed") or (
        agg.effect.outcome_digest and agg.state in ("attempting", "attempting_s2")
    )


def deliver_current(agg, payload: Dict[str, Any], honor_crashes: bool, saved_this_run: bool):
    if honor_crashes and saved_this_run:
        maybe_crash("after-attempt-saved-before-request")
    if effect_already_recorded(agg):
        return finish_slot(agg, honor_crashes)
    found = adopt_from_lookup(agg, payload, honor_record_crash=honor_crashes)
    if found is not None:
        return found
    status, body, raw = post_envelope(payload)
    if status == 409:
        fail("conflict")
    if status != 200 or body is None:
        fail("service_unavailable")
    if not matching_record(body, payload):
        fail("conflict")
    if honor_crashes:
        maybe_crash("after-accept-before-record")
    agg = record_acceptance(agg, raw)
    return finish_slot(agg, honor_crashes)


def save_s1(envelope_id: str, machine, agg):
    slot = "s1" if is_dual(agg) else "one"
    payload = payload_for_slot(envelope_id, agg, slot)
    digest = payload_digest(payload)
    rid = payload["request_id"]
    result = agg.command(
        "save_attempt",
        effect_id=rid,
        payload_digest=digest,
        idempotency_key=rid,
    )
    settled = settle(result)
    agg = settled if settled is not None else machine.show(envelope_id)
    return agg, True


def save_s2(envelope_id: str, machine, agg):
    payload = payload_for_slot(envelope_id, agg, "s2")
    digest = payload_digest(payload)
    rid = payload["request_id"]
    result = agg.command(
        "save_attempt_s2",
        effect_id=rid,
        payload_digest=digest,
        idempotency_key=rid,
    )
    settled = settle(result)
    agg = settled if settled is not None else machine.show(envelope_id)
    return agg, True


def drive_send(envelope_id: str, machine, agg, honor_crashes: bool, allow_post: bool):
    saved_this_run = False
    if agg.state == "draft":
        agg, saved_this_run = save_s1(envelope_id, machine, agg)
    if agg.state == "attempting":
        slot = "s1" if is_dual(agg) else "one"
        payload = payload_for_slot(envelope_id, agg, slot)
        if not allow_post:
            status, body, raw = lookup_request(payload["request_id"])
            if status == 404:
                return agg, "not_sent"
            if status != 200 or body is None:
                fail("service_unavailable")
            if not matching_record(body, payload):
                fail("conflict")
            if agg.effect.status == "pending":
                agg = record_acceptance(agg, raw)
            agg = finish_slot(agg, False)
        else:
            agg = deliver_current(agg, payload, honor_crashes, saved_this_run)
        saved_this_run = False
    if agg.state == "s1_recorded":
        if allow_post:
            agg, saved_this_run = save_s2(envelope_id, machine, agg)
        else:
            return agg, "partial"
    if agg.state == "attempting_s2":
        payload = payload_for_slot(envelope_id, agg, "s2")
        if not allow_post:
            status, body, raw = lookup_request(payload["request_id"])
            if status == 404:
                return agg, "not_sent"
            if status != 200 or body is None:
                fail("service_unavailable")
            if not matching_record(body, payload):
                fail("conflict")
            if agg.effect.status == "pending":
                agg = record_acceptance(agg, raw)
            agg = finish_slot(agg, False)
        else:
            agg = deliver_current(agg, payload, honor_crashes, saved_this_run)
    return agg, "ok"


def cmd_send(args: list) -> Dict[str, Any]:
    if len(args) != 1:
        fail("bad_args")
    envelope_id = parse_id(args[0])
    machine, agg = load_envelope(envelope_id)
    if agg.state in ("signed", "declined", "archived"):
        fail("invalid_state")
    if agg.state == "sent":
        return status_obj(envelope_id, agg)
    agg, _status = drive_send(envelope_id, machine, agg, honor_crashes=True, allow_post=True)
    return status_obj(envelope_id, agg)


def cmd_sign(args: list) -> Dict[str, Any]:
    if len(args) != 2:
        fail("bad_args")
    envelope_id = parse_id(args[0])
    now_ms = parse_ms(args[1])
    _machine, agg = load_envelope(envelope_id)
    if agg.state in ("draft", "attempting", "s1_recorded", "attempting_s2"):
        fail("not_sent")
    if agg.state in ("signed", "declined", "archived"):
        fail("invalid_state")
    if now_ms > expiry_of(agg):
        fail("expired")
    result = agg.command("sign", now_ms=now_ms)
    settle(result)
    return {"envelope_id": envelope_id, "state": "signed", "now_ms": now_ms}


def cmd_decline(args: list) -> Dict[str, Any]:
    if len(args) != 2:
        fail("bad_args")
    envelope_id = parse_id(args[0])
    now_ms = parse_ms(args[1])
    _machine, agg = load_envelope(envelope_id)
    if agg.state in ("draft", "attempting", "s1_recorded", "attempting_s2"):
        fail("not_sent")
    if agg.state in ("signed", "declined", "archived"):
        fail("invalid_state")
    if now_ms > expiry_of(agg):
        fail("expired")
    result = agg.command("decline", now_ms=now_ms)
    settle(result)
    return {"envelope_id": envelope_id, "state": "declined", "now_ms": now_ms}


def cmd_archive(args: list) -> Dict[str, Any]:
    if len(args) != 2:
        fail("bad_args")
    envelope_id = parse_id(args[0])
    now_ms = parse_ms(args[1])
    _machine, agg = load_envelope(envelope_id)
    if agg.state not in ("signed", "declined"):
        fail("invalid_state")
    result = agg.command("archive")
    settle(result)
    return {"envelope_id": envelope_id, "state": "archived", "now_ms": now_ms}


def cmd_reconcile(args: list) -> Dict[str, Any]:
    if len(args) != 1:
        fail("bad_args")
    envelope_id = parse_id(args[0])
    machine, agg = load_envelope(envelope_id)
    if agg.state == "draft":
        return {"envelope_id": envelope_id, "send": "none", "request_id": None}
    if agg.state == "sent" or agg.state in ("signed", "declined", "archived"):
        return status_obj(envelope_id, agg)
    agg, status = drive_send(envelope_id, machine, agg, honor_crashes=False, allow_post=False)
    if status == "not_sent":
        return {
            "envelope_id": envelope_id,
            "send": "not_sent",
            "request_id": request_of(agg),
        }
    return status_obj(envelope_id, agg)


def cmd_status(args: list) -> Dict[str, Any]:
    if len(args) != 1:
        fail("bad_args")
    envelope_id = parse_id(args[0])
    _machine, agg = load_envelope(envelope_id)
    return status_obj(envelope_id, agg)


def cmd_extend(args: list) -> Dict[str, Any]:
    if len(args) != 3:
        fail("bad_args")
    envelope_id = parse_id(args[0])
    new_deadline = parse_ms(args[1])
    now_ms = parse_ms(args[2])
    machine, agg = load_envelope(envelope_id)
    if agg.state in ("signed", "declined", "archived"):
        fail("invalid_state")
    stored = int(agg.facts["deadline_ms"])
    if new_deadline < now_ms or new_deadline <= stored:
        fail("bad_args")
    expiry_ms = new_deadline + GRACE_MS if is_dual(agg) else new_deadline
    names = {
        "draft": "extend_draft",
        "attempting": "extend_attempting",
        "s1_recorded": "extend_s1",
        "attempting_s2": "extend_s2",
        "sent": "extend_sent",
    }
    cmd = names.get(agg.state)
    if cmd is None:
        fail("invalid_state")
    result = agg.command(cmd, deadline_ms=new_deadline, now_ms=now_ms, expiry_ms=expiry_ms)
    settled = settle(result)
    agg = settled if settled is not None else machine.show(envelope_id)
    return {
        "envelope_id": envelope_id,
        "deadline_ms": int(agg.facts["deadline_ms"]),
        "state": public_state(agg.state),
        "now_ms": now_ms,
    }


def cmd_callback(args: list) -> Dict[str, Any]:
    if len(args) != 1:
        fail("bad_args")
    path = args[0]
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError, UnicodeError):
        fail("bad_args")
    if not isinstance(data, dict):
        fail("bad_args")
    needed = (
        "callback_id",
        "request_id",
        "envelope_id",
        "document_id",
        "signer_id",
        "address",
        "deadline_ms",
        "kind",
        "outcome",
    )
    for key in needed:
        if key not in data:
            fail("bad_args")
    if data["outcome"] not in ("accepted", "rejected"):
        fail("bad_args")
    for key in ("callback_id", "request_id", "envelope_id", "document_id", "signer_id", "kind"):
        if not isinstance(data[key], str) or not ID_RE.match(data[key]):
            fail("bad_args")
    if not isinstance(data["address"], str) or not EMAIL_RE.match(data["address"]):
        fail("bad_args")
    deadline = data["deadline_ms"]
    if isinstance(deadline, str):
        deadline = parse_ms(deadline)
    elif isinstance(deadline, int) and 0 <= deadline <= MS_MAX:
        pass
    else:
        fail("bad_args")
    envelope_id = data["envelope_id"]
    machine, agg = load_envelope(envelope_id, required=False)
    if agg is None:
        return {"envelope_id": envelope_id, "ignored": True}
    if agg.state in ("signed", "declined", "archived", "sent"):
        return status_obj(envelope_id, agg)
    if public_state(agg.state) != "draft" or send_status(agg.state) != "attempt_saved":
        return status_obj(envelope_id, agg)
    rid = data["request_id"]
    known = [request_of(agg), request_s2_of(agg)]
    if rid not in known:
        return status_obj(envelope_id, agg)
    agg, _status = drive_send(envelope_id, machine, agg, honor_crashes=False, allow_post=False)
    return status_obj(envelope_id, agg)


COMMANDS = {
    "create-envelope": cmd_create,
    "send": cmd_send,
    "sign": cmd_sign,
    "decline": cmd_decline,
    "archive": cmd_archive,
    "reconcile": cmd_reconcile,
    "status": cmd_status,
    "callback": cmd_callback,
    "extend-deadline": cmd_extend,
}


def main(argv: list) -> int:
    if not argv:
        sys.stdout.write(json.dumps({"error": "bad_args"}) + "\n")
        return 2
    name, rest = argv[0], argv[1:]
    handler = COMMANDS.get(name)
    if handler is None:
        sys.stdout.write(json.dumps({"error": "bad_args"}) + "\n")
        return 2
    try:
        result = handler(rest)
    except AppError as exc:
        sys.stdout.write(json.dumps({"error": exc.code}) + "\n")
        return 1
    except (IllegalStateError, CommandInvalidError):
        sys.stdout.write(json.dumps({"error": "invalid_state"}) + "\n")
        return 1
    except TransportError:
        sys.stdout.write(json.dumps({"error": "service_unavailable"}) + "\n")
        return 1
    sys.stdout.write(json.dumps(result) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
