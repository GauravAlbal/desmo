#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node"
RUN = str(ROOT / "run")


def start_stub():
    proc = subprocess.Popen(
        [NODE, str(ROOT / "stub" / "server.mjs")],
        cwd=str(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    line = proc.stdout.readline()
    info = json.loads(line)
    return proc, info["service_url"], info["control_url"]


def run_cmd(env, args, crash=None):
    e = dict(os.environ)
    e.update(env)
    e["IK_BINARY"] = str(ROOT / "KIT" / "bin" / "ik")
    if crash:
        e["CRASH_AT"] = crash
    elif "CRASH_AT" in e:
        del e["CRASH_AT"]
    completed = subprocess.run(
        [RUN] + args,
        env=e,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    return completed


def parse_out(completed):
    return json.loads(completed.stdout.strip().splitlines()[-1])


def control(url, method, path, body=None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url + path, data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode("utf-8"))


def effects_count(control_url):
    return control(control_url, "GET", "/effects")["count"]


def main():
    stub, service, ctl = start_stub()
    tmp = tempfile.mkdtemp(prefix="desk-test-")
    try:
        env = {"STATE_DIR": tmp, "SERVICE_URL": service}
        foreign = Path(tmp) / "foreign.txt"
        foreign.write_bytes(b"keep-me")

        r = run_cmd(env, ["create-envelope", "env1", "doc1", "signer1", "a@b.co", "100", "50"])
        assert r.returncode == 0, r.stderr
        body = parse_out(r)
        assert body["state"] == "draft" and body["send"] == "none"

        r = run_cmd(env, ["create-envelope", "env1", "doc2", "signer1", "a@b.co", "100", "50"])
        assert r.returncode != 0 and parse_out(r)["error"] == "id_in_use"

        r = run_cmd(env, ["create-envelope", "env2", "doc1", "signer1", "a@b.co", "100", "50"])
        assert r.returncode != 0 and parse_out(r)["error"] == "id_in_use"

        r = run_cmd(env, ["create-envelope", "bad id", "docx", "signer1", "a@b.co", "100", "50"])
        assert r.returncode != 0 and parse_out(r)["error"] == "bad_args"

        r = run_cmd(env, ["create-envelope", "envLate", "docLate", "signer1", "a@b.co", "10", "50"])
        assert r.returncode != 0 and parse_out(r)["error"] == "bad_args"

        r = run_cmd(env, ["send", "env1"], crash="after-attempt-saved-before-request")
        assert r.returncode == -signal.SIGKILL, r.returncode
        assert effects_count(ctl) == 0
        st = parse_out(run_cmd(env, ["status", "env1"]))
        assert st["send"] == "attempt_saved" and st["state"] == "draft"

        r = run_cmd(env, ["send", "env1"], crash="after-accept-before-record")
        assert r.returncode == -signal.SIGKILL, (r.returncode, r.stdout, r.stderr)
        assert effects_count(ctl) == 1
        st = parse_out(run_cmd(env, ["status", "env1"]))
        assert st["send"] == "attempt_saved"

        r = run_cmd(env, ["send", "env1"], crash="after-accept-before-record")
        assert r.returncode != -signal.SIGKILL
        assert r.returncode == 0, r.stdout + r.stderr
        st = parse_out(r)
        assert st["state"] == "sent" and st["send"] == "sent"
        assert effects_count(ctl) == 1

        r = run_cmd(env, ["send", "env1"])
        assert r.returncode == 0
        assert effects_count(ctl) == 1

        r = run_cmd(env, ["sign", "env1", "101"])
        assert r.returncode != 0 and parse_out(r)["error"] == "expired"
        r = run_cmd(env, ["sign", "env1", "100"])
        assert r.returncode == 0 and parse_out(r)["state"] == "signed"
        r = run_cmd(env, ["decline", "env1", "90"])
        assert r.returncode != 0 and parse_out(r)["error"] == "invalid_state"
        r = run_cmd(env, ["archive", "env1", "100"])
        assert r.returncode == 0 and parse_out(r)["state"] == "archived"
        r = run_cmd(env, ["send", "env1"])
        assert r.returncode != 0 and parse_out(r)["error"] == "invalid_state"

        r = run_cmd(env, ["create-envelope", "env3", "doc3", "signer1", "a@b.co", "200", "0"])
        assert r.returncode == 0
        r = run_cmd(env, ["send", "env3"], crash="after-record-before-exit")
        assert r.returncode == -signal.SIGKILL
        st = parse_out(run_cmd(env, ["status", "env3"]))
        assert st["state"] == "sent"
        r = run_cmd(env, ["send", "env3"], crash="after-record-before-exit")
        assert r.returncode == 0
        assert effects_count(ctl) == 2

        r = run_cmd(env, ["create-envelope", "env4", "doc4", "signer1", "a@b.co", "300", "0"])
        assert r.returncode == 0
        control(ctl, "POST", "/fault", {"drop_reply": True})
        r = run_cmd(env, ["send", "env4"])
        assert r.returncode != 0 and parse_out(r)["error"] == "service_unavailable"
        control(ctl, "POST", "/fault", {"drop_reply": False})
        st = parse_out(run_cmd(env, ["status", "env4"]))
        assert st["send"] == "attempt_saved"
        rec = parse_out(run_cmd(env, ["reconcile", "env4"]))
        assert rec["state"] == "sent" and rec["send"] == "sent"
        assert effects_count(ctl) == 3

        r = run_cmd(env, ["sign", "env4", "1"])
        assert parse_out(r)["state"] == "signed"
        cb = Path(tmp) / "cb.json"
        cb.write_text(
            json.dumps(
                {
                    "callback_id": "cb-env4",
                    "request_id": "env4",
                    "envelope_id": "env4",
                    "document_id": "other",
                    "signer_id": "other",
                    "address": "z@z.co",
                    "deadline_ms": 1,
                    "kind": "signature_request",
                    "outcome": "rejected",
                }
            )
        )
        r = run_cmd(env, ["callback", str(cb)])
        assert r.returncode == 0
        st = parse_out(run_cmd(env, ["status", "env4"]))
        assert st["state"] == "signed" and st["document_id"] == "doc4" and st["deadline_ms"] == 300

        r = run_cmd(env, ["sign", "missing", "1"])
        assert parse_out(r)["error"] == "unknown_envelope"

        r = run_cmd(env, ["create-envelope", "env5", "doc5", "signer1", "a@b.co", "10", "0"])
        r = run_cmd(env, ["sign", "env5", "0"])
        assert r.returncode != 0 and parse_out(r)["error"] == "not_sent"

        r = run_cmd(env, ["create-envelope", "env6", "doc6", "signer1", "a@b.co", "10", "0"])
        r = run_cmd(env, ["send", "env6"], crash="after-attempt-saved-before-request")
        assert r.returncode == -signal.SIGKILL
        r = run_cmd(env, ["send", "env6"], crash="after-attempt-saved-before-request")
        assert r.returncode == 0, (r.returncode, r.stdout, r.stderr)
        assert parse_out(r)["state"] == "sent"

        r = run_cmd(
            env,
            ["create-envelope", "envD", "docD", "sA", "a@b.co", "sA", "c@d.co", "100", "0"],
        )
        assert r.returncode != 0 and parse_out(r)["error"] == "bad_args"

        r = run_cmd(
            env,
            ["create-envelope", "envD", "docD", "sA", "a@b.co", "sB", "c@d.co", "100", "0"],
        )
        assert r.returncode == 0, r.stdout + r.stderr
        body = parse_out(r)
        assert body["signer2_id"] == "sB" and body["address2"] == "c@d.co"

        r = run_cmd(env, ["extend-deadline", "envD", "50", "0"])
        assert r.returncode != 0 and parse_out(r)["error"] == "bad_args"
        r = run_cmd(env, ["extend-deadline", "envD", "150", "0"])
        assert r.returncode == 0 and parse_out(r)["deadline_ms"] == 150

        r = run_cmd(env, ["send", "envD"], crash="after-accept-before-record")
        assert r.returncode == -signal.SIGKILL
        before = effects_count(ctl)
        rec = parse_out(run_cmd(env, ["reconcile", "envD"]))
        r = run_cmd(env, ["send", "envD"])
        assert r.returncode == 0, r.stdout + r.stderr
        st = parse_out(r)
        assert st["state"] == "sent" and st["send"] == "sent"
        assert st["signer2_id"] == "sB"
        assert effects_count(ctl) == before + 1 or effects_count(ctl) >= before
        after_dual = effects_count(ctl)

        r = run_cmd(env, ["sign", "envD", str(150 + 86400000)])
        assert r.returncode == 0 and parse_out(r)["state"] == "signed"
        r = run_cmd(env, ["archive", "envD", "1"])
        assert r.returncode == 0

        r = run_cmd(
            env,
            ["create-envelope", "envE", "docE", "sC", "a@b.co", "sD", "c@d.co", "10", "0"],
        )
        assert r.returncode == 0
        r = run_cmd(env, ["send", "envE"])
        assert r.returncode == 0
        assert effects_count(ctl) == after_dual + 2
        r = run_cmd(env, ["sign", "envE", "11"])
        assert r.returncode == 0
        r = run_cmd(
            env,
            ["create-envelope", "envF", "docF", "sE", "a@b.co", "sF", "c@d.co", "10", "0"],
        )
        assert r.returncode == 0
        r = run_cmd(env, ["send", "envF"])
        assert r.returncode == 0
        r = run_cmd(env, ["sign", "envF", str(10 + 86400000 + 1)])
        assert r.returncode != 0 and parse_out(r)["error"] == "expired"

        r = run_cmd(env, ["extend-deadline", "env1", "999", "0"])
        assert r.returncode != 0 and parse_out(r)["error"] == "invalid_state"

        assert foreign.read_bytes() == b"keep-me"
        print("ok")
    finally:
        stub.kill()
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
