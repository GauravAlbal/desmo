# E-signature envelope desk

Local envelope lifecycle over Ikaros, talking to the fake service in `stub/`.

## Setup

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
chmod +x run
```

Node 22 is used only to run `stub/server.mjs`.

## Run

```sh
node stub/server.mjs
# prints {"service_url":"http://127.0.0.1:PORT",...}

export STATE_DIR=/tmp/envelope-desk
export SERVICE_URL=http://127.0.0.1:PORT
export IK_BINARY="$(pwd)/KIT/bin/ik"
./run create-envelope env1 doc1 signer1 a@b.co 100 50
./run create-envelope env2 doc2 s1 a@b.co s2 c@d.co 100 50
./run send env2
./run extend-deadline env2 200 50
./run sign env2 90
./run archive env2 90
./run status env2
```

Optional: `CRASH_AT=after-attempt-saved-before-request` (or `after-accept-before-record`, `after-record-before-exit`) on `send`.

## Tests

```sh
.venv/bin/python tests/test_desk.py
```
