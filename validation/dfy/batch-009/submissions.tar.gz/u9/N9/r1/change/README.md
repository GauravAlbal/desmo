# E-signature envelope desk

Local desk for draft envelopes, one required signer, and an external e-signature stub.

## Setup

```sh
/usr/bin/python3 -m venv .venv
.venv/bin/pip install --no-index KIT/python/*.whl
chmod +x run
```

Node 22 is used only for the supplied stub:

```sh
<home>/.nvm/versions/node/v22.17.1/bin/node stub/server.mjs
```

## Run

The stub prints `{"service_url":"http://127.0.0.1:PORT",...}`. Then:

```sh
export STATE_DIR=/tmp/esign-desk
export SERVICE_URL=http://127.0.0.1:PORT
export IK_BINARY="$(pwd)/KIT/bin/ik"   # optional; ./run sets this
./run create-envelope env1 doc1 sig1 user@example.com 1000 100
./run send env1
./run sign env1 1000
./run archive env1 1000
./run status env1
```

Optional: `CRASH_AT=after-attempt-saved-before-request|after-accept-before-record|after-record-before-exit`

## Tests

```sh
.venv/bin/python tests/test_desk.py
```
