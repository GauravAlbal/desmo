# E-signature envelope desk. Python 3.9.
from __future__ import annotations

import json
import os
import re
import signal
import sys
import urllib.error
import urllib.request
from typing import Any, Dict, List, Mapping, Optional, Tuple

from invariant_kernel import (
    HistoricalResult,
    Kernel,
    KernelError,
    StoreNotFoundError,
    classify,
)

ID_RE = re.compile(r"^[A-Za-z0-9._-]{1,64}$")
LOCAL_RE = re.compile(r"^[A-Za-z0-9._+-]{1,64}$")
DOMAIN_RE = re.compile(r"^[A-Za-z0-9.-]{1,63}$")
MS_RE = re.compile(r"^(0|[1-9][0-9]{0,12})$")
MAX_MS = 9999999999999
GRACE_MS = 86400000

ERROR_CODES = frozenset(
    {
        "bad_args",
        "unknown_envelope",
        "id_in_use",
        "invalid_state",
        "not_sent",
        "expired",
        "conflict",
        "service_unavailable",
    }
)


class AppError(Exception):
    def __init__(self, code: str) -> None:
        if code not in ERROR_CODES:
            code = "bad_args"
        self.code = code


def fail(code: str) -> None:
    raise AppError(code)


def project_root() -> str:
    return os.path.dirname(os.path.abspath(__file__))


def store_path() -> str:
    state = os.environ.get("STATE_DIR")
    if not state:
        fail("bad_args")
    os.makedirs(state, exist_ok=True)
    return os.path.join(state, "desk.sqlite")


def service_url() -> str:
    url = os.environ.get("SERVICE_URL")
    if not url:
        fail("bad_args")
    return url.rstrip("/")


def crash_at() -> str:
    return os.environ.get("CRASH_AT") or ""


def honor_crash(label: str) -> None:
    if crash_at() == label:
        os.kill(os.getpid(), signal.SIGKILL)


def is_id(value: str) -> bool:
    return bool(ID_RE.fullmatch(value))


def is_email(value: str) -> bool:
    if value.count("@") != 1:
        return False
    local, domain = value.split("@", 1)
    return bool(LOCAL_RE.fullmatch(local) and DOMAIN_RE.fullmatch(domain))


def parse_ms(value: str) -> int:
    if not MS_RE.fullmatch(value):
        fail("bad_args")
    n = int(value)
    if n > MAX_MS:
        fail("bad_args")
    return n


def open_kernel() -> Kernel:
    binary = os.environ.get("IK_BINARY")
    if not binary:
        binary = os.path.join(project_root(), "KIT", "bin", "ik")
    return Kernel(store_path(), binary=binary)


def machines(kernel: Kernel):
    root = project_root()
    v1 = kernel.machine(os.path.join(root, "machines", "envelope.ik.toml"))
    v2 = kernel.machine(os.path.join(root, "machines", "envelope_v2.ik.toml"))
    claim_m = kernel.machine(os.path.join(root, "machines", "id_claim.ik.toml"))
    by_owner = {v1.identity: v1, v2.identity: v2}
    return v1, v2, claim_m, by_owner


def try_show(machine, aggregate_id: str):
    try:
        return machine.show(aggregate_id)
    except StoreNotFoundError:
        return None
    except KernelError as err:
        if classify(err) == "not_found":
            return None
        raise


def resolve_envelope(v1, v2, by_owner, envelope_id: str):
    shown = try_show(v2, envelope_id)
    if shown is None:
        shown = try_show(v1, envelope_id)
    if shown is None:
        return None
    owner = shown.owner
    machine = by_owner.get(owner)
    if machine is None:
        fail("service_unavailable")
    if machine is v2 or machine is v1:
        routed = try_show(machine, envelope_id)
        if routed is None:
            fail("unknown_envelope")
        return routed
    return shown


def settle(machine, result, aggregate_id: str):
    if isinstance(result, HistoricalResult):
        shown = try_show(machine, aggregate_id)
        if shown is None:
            fail("unknown_envelope")
        return shown
    return result


def apply_named(agg, name: str, operation_id: str, **args: Any):
    payload = {"name": name, "args": args} if args else {"name": name}
    try:
        result = agg.execute(payload, operation_id=operation_id)
    except KernelError as err:
        cls = classify(err)
        if cls == "not_found":
            fail("unknown_envelope")
        if cls == "refused":
            fail("invalid_state")
        fail("service_unavailable")
    return settle(agg._machine, result, agg.id)


def is_two_signer(agg) -> bool:
    facts = agg.facts
    try:
        if int(facts.get("signer_count") or 1) == 2:
            return True
    except (TypeError, ValueError):
        pass
    s2 = str(facts.get("signer2_id") or "")
    return s2 not in ("", "-")


def fact_int(facts: Mapping[str, Any], key: str, default: int = 0) -> int:
    try:
        return int(facts.get(key, default))
    except (TypeError, ValueError):
        return default


def decision_until(agg) -> int:
    facts = agg.facts
    if "decision_until_ms" in facts and facts.get("decision_until_ms") not in (None, ""):
        return fact_int(facts, "decision_until_ms", fact_int(facts, "deadline_ms", 0))
    deadline = fact_int(facts, "deadline_ms", 0)
    if is_two_signer(agg):
        return deadline + GRACE_MS
    return deadline


def payload_fields(agg) -> Dict[str, Any]:
    facts = agg.facts
    send_status = str(facts.get("send_status") or "none")
    request_id = facts.get("request_id")
    if send_status == "none" or request_id in ("", "-", None):
        rid = None
    else:
        rid = str(request_id)
    out = {
        "envelope_id": agg.id,
        "document_id": str(facts.get("document_id", "")),
        "signer_id": str(facts.get("signer_id", "")),
        "address": str(facts.get("address", "")),
        "deadline_ms": fact_int(facts, "deadline_ms", 0),
        "state": str(agg.state),
        "send": send_status,
        "request_id": rid,
        "now_ms": fact_int(facts, "created_now_ms", 0),
    }
    if is_two_signer(agg):
        out["signer2_id"] = str(facts.get("signer2_id", ""))
        out["address2"] = str(facts.get("address2", ""))
        rid2 = facts.get("request_id_s2")
        if send_status != "none" and rid2 not in ("", "-", None):
            out["request_id_s2"] = str(rid2)
        else:
            out["request_id_s2"] = None
    return out


def request_body_for(agg, signer_index: int) -> Dict[str, Any]:
    facts = agg.facts
    fields = payload_fields(agg)
    if signer_index == 2:
        request_id = str(facts.get("request_id_s2") or (agg.id + ".s2"))
        signer_id = str(facts.get("signer2_id", ""))
        address = str(facts.get("address2", ""))
    elif is_two_signer(agg):
        request_id = str(facts.get("request_id") or (agg.id + ".s1"))
        signer_id = fields["signer_id"]
        address = fields["address"]
    else:
        request_id = str(facts.get("request_id") or agg.id)
        signer_id = fields["signer_id"]
        address = fields["address"]
    return {
        "request_id": request_id,
        "envelope_id": fields["envelope_id"],
        "document_id": fields["document_id"],
        "signer_id": signer_id,
        "address": address,
        "deadline_ms": fields["deadline_ms"],
        "kind": "signature_request",
    }


def objects_match(accepted: Mapping[str, Any], expected: Mapping[str, Any]) -> bool:
    keys = (
        "request_id",
        "envelope_id",
        "document_id",
        "signer_id",
        "address",
        "deadline_ms",
        "kind",
    )
    for key in keys:
        left = accepted.get(key)
        right = expected.get(key)
        if key == "deadline_ms":
            try:
                if int(left) != int(right):
                    return False
            except (TypeError, ValueError):
                return False
        elif str(left) != str(right):
            return False
    return True


def http_call(method: str, url: str, body: Optional[dict] = None) -> Tuple[Optional[int], Optional[dict], bool]:
    data = None
    headers = {}
    if body is not None:
        data = json.dumps(body, separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15.0) as resp:
            raw = resp.read()
            code = int(resp.status)
            if not raw:
                return code, None, False
            try:
                parsed = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                return code, None, False
            if not isinstance(parsed, dict):
                return code, None, False
            return code, parsed, True
    except urllib.error.HTTPError as err:
        raw = err.read()
        parsed = None
        complete = True
        if raw:
            try:
                loaded = json.loads(raw.decode("utf-8"))
                if isinstance(loaded, dict):
                    parsed = loaded
            except (UnicodeDecodeError, json.JSONDecodeError):
                complete = False
        else:
            complete = False
        return int(err.code), parsed, complete
    except (urllib.error.URLError, TimeoutError, ConnectionError, OSError, ValueError):
        return None, None, False


def lookup_request(request_id: str) -> Tuple[str, Optional[dict]]:
    url = service_url() + "/v1/requests/" + urllib.request.quote(request_id, safe="")
    code, parsed, complete = http_call("GET", url)
    if code == 404:
        return "missing", parsed
    if code == 200 and complete and parsed is not None:
        return "found", parsed
    return "unavailable", parsed


def post_envelope(body: dict) -> Tuple[str, Optional[dict]]:
    url = service_url() + "/v1/envelopes"
    code, parsed, complete = http_call("POST", url, body)
    if code == 409:
        return "conflict", parsed
    if code == 200 and complete and parsed is not None:
        return "accepted", parsed
    return "unavailable", parsed


def require_envelope(v1, v2, by_owner, envelope_id: str):
    if not is_id(envelope_id):
        fail("bad_args")
    agg = resolve_envelope(v1, v2, by_owner, envelope_id)
    if agg is None:
        fail("unknown_envelope")
    return agg


def claim_id(claim_m, value: str) -> None:
    if try_show(claim_m, value) is not None:
        return
    try:
        claim_m.create(value)
    except KernelError:
        pass


def id_taken(env_machines, claim_m, value: str) -> bool:
    for machine in env_machines:
        if try_show(machine, value) is not None:
            return True
    if try_show(claim_m, value) is not None:
        return True
    return False


def cmd_create(args) -> dict:
    if len(args) == 6:
        two = False
        envelope_id, document_id, signer_id, address, deadline_raw, now_raw = args
        signer2_id = "-"
        address2 = "-"
    elif len(args) == 8:
        two = True
        envelope_id, document_id, signer_id, address, signer2_id, address2, deadline_raw, now_raw = args
    else:
        fail("bad_args")
    if not (is_id(envelope_id) and is_id(document_id) and is_id(signer_id) and is_email(address)):
        fail("bad_args")
    if two:
        if not (is_id(signer2_id) and is_email(address2)):
            fail("bad_args")
        if signer_id == signer2_id:
            fail("bad_args")
        if len(envelope_id) > 61:
            fail("bad_args")
    deadline_ms = parse_ms(deadline_raw)
    now_ms = parse_ms(now_raw)
    if deadline_ms < now_ms:
        fail("bad_args")
    kernel = open_kernel()
    v1, v2, claim_m, _by = machines(kernel)
    env_pair = (v1, v2)
    if id_taken(env_pair, claim_m, envelope_id):
        fail("id_in_use")
    if document_id != envelope_id and id_taken(env_pair, claim_m, document_id):
        fail("id_in_use")
    if two:
        for sid in (signer_id, signer2_id):
            if sid not in (envelope_id, document_id) and id_taken(env_pair, claim_m, sid):
                fail("id_in_use")
        rid1 = envelope_id + ".s1"
        rid2 = envelope_id + ".s2"
        for rid in (rid1, rid2):
            if rid not in (envelope_id, document_id, signer_id, signer2_id) and id_taken(env_pair, claim_m, rid):
                fail("id_in_use")
        decision = deadline_ms + GRACE_MS
        if decision > MAX_MS:
            decision = MAX_MS
        command = {
            "name": "create_envelope",
            "args": {
                "document_id": document_id,
                "signer_id": signer_id,
                "address": address,
                "signer2_id": signer2_id,
                "address2": address2,
                "deadline_ms": deadline_ms,
                "decision_until_ms": decision,
                "now_ms": now_ms,
                "send_status": "none",
                "request_id": "-",
                "request_id_s2": "-",
                "send_s1": "none",
                "send_s2": "none",
                "signer_count": 2,
            },
        }
    else:
        command = {
            "name": "create_envelope",
            "args": {
                "document_id": document_id,
                "signer_id": signer_id,
                "address": address,
                "signer2_id": "-",
                "address2": "-",
                "deadline_ms": deadline_ms,
                "decision_until_ms": deadline_ms,
                "now_ms": now_ms,
                "send_status": "none",
                "request_id": "-",
                "request_id_s2": "-",
                "send_s1": "none",
                "send_s2": "na",
                "signer_count": 1,
            },
        }
    op_id = "create:" + envelope_id
    try:
        result = v2.create_with(envelope_id, command, operation_id=op_id)
    except StoreNotFoundError:
        fail("service_unavailable")
    except KernelError as err:
        cls = classify(err)
        if cls == "not_found":
            fail("unknown_envelope")
        if cls == "refused":
            fail("id_in_use")
        fail("service_unavailable")
    agg = settle(v2, result, envelope_id)
    claim_id(claim_m, envelope_id)
    if document_id != envelope_id:
        claim_id(claim_m, document_id)
    if two:
        if signer_id not in (envelope_id, document_id):
            claim_id(claim_m, signer_id)
        if signer2_id not in (envelope_id, document_id, signer_id):
            claim_id(claim_m, signer2_id)
        claim_id(claim_m, envelope_id + ".s1")
        claim_id(claim_m, envelope_id + ".s2")
    return payload_fields(agg)


def save_attempt_if_needed(agg) -> Any:
    facts = agg.facts
    if str(facts.get("send_status") or "none") == "attempt_saved":
        return agg
    if str(facts.get("send_status") or "none") != "none":
        fail("invalid_state")
    if agg.owner.version == 1:
        return apply_named(
            agg,
            "save_attempt",
            "save-attempt:" + agg.id,
            request_id=agg.id,
            send_status="attempt_saved",
        )
    if is_two_signer(agg):
        return apply_named(
            agg,
            "save_attempt",
            "save-attempt:" + agg.id,
            request_id=agg.id + ".s1",
            request_id_s2=agg.id + ".s2",
            send_status="attempt_saved",
        )
    return apply_named(
        agg,
        "save_attempt",
        "save-attempt:" + agg.id,
        request_id=agg.id,
        request_id_s2="-",
        send_status="attempt_saved",
    )


def mark_signer_done(agg, index: int) -> Any:
    if agg.owner.version == 1:
        return agg
    key = "send_s1" if index == 1 else "send_s2"
    current = str(agg.facts.get(key) or "none")
    if current == "sent":
        return agg
    name = "mark_s1" if index == 1 else "mark_s2"
    return apply_named(agg, name, "mark-%s:%s" % (key, agg.id), **{key: "sent"})


def both_complete(agg) -> bool:
    if str(agg.state) == "sent" and str(agg.facts.get("send_status")) == "sent":
        return True
    if agg.owner.version == 1:
        return False
    s1 = str(agg.facts.get("send_s1") or "none")
    s2 = str(agg.facts.get("send_s2") or "none")
    if is_two_signer(agg):
        return s1 == "sent" and s2 == "sent"
    return s1 == "sent"


def commit_sent(agg) -> Any:
    if str(agg.state) == "sent" and str(agg.facts.get("send_status")) == "sent":
        return agg
    if agg.owner.version != 1:
        if is_two_signer(agg):
            if str(agg.facts.get("send_s1")) != "sent" or str(agg.facts.get("send_s2")) != "sent":
                return agg
        elif str(agg.facts.get("send_s1")) != "sent":
            if str(agg.facts.get("send_s2")) != "na":
                return agg
            agg = mark_signer_done(agg, 1)
    return apply_named(agg, "mark_sent", "mark-sent:" + agg.id, send_status="sent")


def signer_slots(agg) -> List[int]:
    if is_two_signer(agg):
        return [1, 2]
    return [1]


def slot_done(agg, index: int) -> bool:
    if str(agg.facts.get("send_status")) == "sent" and str(agg.state) == "sent":
        return True
    if agg.owner.version == 1:
        return False
    key = "send_s1" if index == 1 else "send_s2"
    return str(agg.facts.get(key) or "none") == "sent"


def cmd_send(args) -> dict:
    if len(args) != 1:
        fail("bad_args")
    kernel = open_kernel()
    v1, v2, _c, by_owner = machines(kernel)
    agg = require_envelope(v1, v2, by_owner, args[0])
    state = str(agg.state)
    send_status = str(agg.facts.get("send_status") or "none")
    if state in ("signed", "declined", "archived"):
        fail("invalid_state")
    if state == "sent" and send_status == "sent":
        return payload_fields(agg)
    if state != "draft":
        fail("invalid_state")
    newly_saved = send_status == "none"
    agg = save_attempt_if_needed(agg)
    if newly_saved:
        honor_crash("after-attempt-saved-before-request")
    for index in signer_slots(agg):
        if slot_done(agg, index):
            continue
        body = request_body_for(agg, index)
        status, found = lookup_request(body["request_id"])
        if status == "unavailable":
            fail("service_unavailable")
        if status == "found":
            if not objects_match(found or {}, body):
                fail("conflict")
            agg = mark_signer_done(agg, index)
            continue
        post_status, accepted = post_envelope(body)
        if post_status == "conflict":
            fail("conflict")
        if post_status != "accepted":
            fail("service_unavailable")
        if not objects_match(accepted or {}, body):
            fail("conflict")
        honor_crash("after-accept-before-record")
        agg = mark_signer_done(agg, index)
    if agg.owner.version == 1:
        agg = commit_sent(agg)
    else:
        if both_complete(agg) or (
            not is_two_signer(agg) and str(agg.facts.get("send_s1")) == "sent"
        ) or (
            is_two_signer(agg)
            and str(agg.facts.get("send_s1")) == "sent"
            and str(agg.facts.get("send_s2")) == "sent"
        ):
            if not is_two_signer(agg) and str(agg.facts.get("send_s1")) != "sent":
                agg = mark_signer_done(agg, 1)
            agg = commit_sent(agg)
        else:
            return payload_fields(agg)
    honor_crash("after-record-before-exit")
    return payload_fields(agg)


def cmd_sign(args) -> dict:
    if len(args) != 2:
        fail("bad_args")
    now_ms = parse_ms(args[1])
    kernel = open_kernel()
    v1, v2, _c, by_owner = machines(kernel)
    agg = require_envelope(v1, v2, by_owner, args[0])
    state = str(agg.state)
    if state == "draft":
        fail("not_sent")
    if state in ("signed", "declined", "archived"):
        fail("invalid_state")
    if state != "sent":
        fail("invalid_state")
    if now_ms > decision_until(agg):
        fail("expired")
    agg = apply_named(agg, "sign", "sign:%s:%s" % (agg.id, now_ms), now_ms=now_ms)
    return {"envelope_id": agg.id, "state": str(agg.state), "now_ms": now_ms}


def cmd_decline(args) -> dict:
    if len(args) != 2:
        fail("bad_args")
    now_ms = parse_ms(args[1])
    kernel = open_kernel()
    v1, v2, _c, by_owner = machines(kernel)
    agg = require_envelope(v1, v2, by_owner, args[0])
    state = str(agg.state)
    if state == "draft":
        fail("not_sent")
    if state in ("signed", "declined", "archived"):
        fail("invalid_state")
    if state != "sent":
        fail("invalid_state")
    if now_ms > decision_until(agg):
        fail("expired")
    agg = apply_named(agg, "decline", "decline:%s:%s" % (agg.id, now_ms), now_ms=now_ms)
    return {"envelope_id": agg.id, "state": str(agg.state), "now_ms": now_ms}


def cmd_archive(args) -> dict:
    if len(args) != 2:
        fail("bad_args")
    now_ms = parse_ms(args[1])
    kernel = open_kernel()
    v1, v2, _c, by_owner = machines(kernel)
    agg = require_envelope(v1, v2, by_owner, args[0])
    state = str(agg.state)
    if state not in ("signed", "declined"):
        fail("invalid_state")
    agg = apply_named(agg, "archive", "archive:%s:%s" % (agg.id, now_ms))
    return {"envelope_id": agg.id, "state": str(agg.state), "now_ms": now_ms}


def cmd_extend(args) -> dict:
    if len(args) != 3:
        fail("bad_args")
    envelope_id = args[0]
    new_deadline_ms = parse_ms(args[1])
    now_ms = parse_ms(args[2])
    kernel = open_kernel()
    v1, v2, _c, by_owner = machines(kernel)
    agg = require_envelope(v1, v2, by_owner, envelope_id)
    state = str(agg.state)
    if state in ("signed", "declined", "archived"):
        fail("invalid_state")
    if state not in ("draft", "sent"):
        fail("invalid_state")
    stored = fact_int(agg.facts, "deadline_ms", 0)
    if new_deadline_ms < now_ms or new_deadline_ms <= stored:
        fail("bad_args")
    if agg.owner.version == 1:
        fail("invalid_state")
    slack = GRACE_MS if is_two_signer(agg) else 0
    decision = new_deadline_ms + slack
    if decision > MAX_MS:
        decision = MAX_MS
    name = "extend_deadline_draft" if state == "draft" else "extend_deadline_sent"
    agg = apply_named(
        agg,
        name,
        "extend:%s:%s" % (agg.id, new_deadline_ms),
        new_deadline_ms=new_deadline_ms,
        now_ms=now_ms,
        decision_until_ms=decision,
    )
    return {
        "envelope_id": agg.id,
        "deadline_ms": fact_int(agg.facts, "deadline_ms", 0),
        "state": str(agg.state),
        "now_ms": now_ms,
    }


def cmd_reconcile(args) -> dict:
    if len(args) != 1:
        fail("bad_args")
    kernel = open_kernel()
    v1, v2, _c, by_owner = machines(kernel)
    agg = require_envelope(v1, v2, by_owner, args[0])
    fields = payload_fields(agg)
    if fields["send"] == "none":
        return {
            "envelope_id": fields["envelope_id"],
            "send": "none",
            "request_id": None,
        }
    if fields["send"] == "sent" or str(agg.state) == "sent":
        return fields
    if fields["send"] != "attempt_saved":
        return fields
    missing = False
    for index in signer_slots(agg):
        if slot_done(agg, index):
            continue
        body = request_body_for(agg, index)
        status, found = lookup_request(body["request_id"])
        if status == "unavailable":
            fail("service_unavailable")
        if status == "missing":
            missing = True
            continue
        if not objects_match(found or {}, body):
            fail("conflict")
        agg = mark_signer_done(agg, index)
    if missing:
        out = payload_fields(agg)
        out["send"] = "not_sent"
        return out
    if agg.owner.version == 1:
        agg = commit_sent(agg)
        return payload_fields(agg)
    s1 = str(agg.facts.get("send_s1") or "none")
    s2 = str(agg.facts.get("send_s2") or "none")
    if is_two_signer(agg):
        if s1 == "sent" and s2 == "sent":
            agg = commit_sent(agg)
            return payload_fields(agg)
        out = payload_fields(agg)
        out["send"] = "not_sent"
        return out
    if s1 == "sent" or agg.owner.version == 1:
        if s1 != "sent" and agg.owner.version != 1:
            agg = mark_signer_done(agg, 1)
        agg = commit_sent(agg)
        return payload_fields(agg)
    out = payload_fields(agg)
    out["send"] = "not_sent"
    return out


def cmd_status(args) -> dict:
    if len(args) != 1:
        fail("bad_args")
    kernel = open_kernel()
    v1, v2, _c, by_owner = machines(kernel)
    agg = require_envelope(v1, v2, by_owner, args[0])
    return payload_fields(agg)


def cmd_callback(args) -> dict:
    if len(args) != 1:
        fail("bad_args")
    path = args[0]
    try:
        with open(path, "r", encoding="utf-8") as handle:
            raw = handle.read()
        data = json.loads(raw)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        fail("bad_args")
    if not isinstance(data, dict):
        fail("bad_args")
    required = (
        "callback_id",
        "request_id",
        "envelope_id",
        "document_id",
        "signer_id",
        "address",
        "deadline_ms",
        "kind",
        "outcome",
    )
    for key in required:
        if key not in data:
            fail("bad_args")
    if data.get("outcome") not in ("accepted", "rejected"):
        fail("bad_args")
    request_id = str(data["request_id"])
    envelope_id = str(data["envelope_id"])
    if not (is_id(request_id) and is_id(envelope_id)):
        fail("bad_args")
    kernel = open_kernel()
    v1, v2, _c, by_owner = machines(kernel)
    agg = resolve_envelope(v1, v2, by_owner, envelope_id)
    if agg is None:
        agg = resolve_envelope(v1, v2, by_owner, request_id)
    if agg is None:
        return {"envelope_id": envelope_id, "applied": False}
    state = str(agg.state)
    if state in ("signed", "declined", "archived", "sent"):
        return payload_fields(agg)
    if str(agg.facts.get("send_status") or "none") != "attempt_saved":
        return payload_fields(agg)
    matched_index = None
    for index in signer_slots(agg):
        body = request_body_for(agg, index)
        if str(body["request_id"]) == request_id:
            matched_index = index
            break
    if matched_index is None:
        return payload_fields(agg)
    body = request_body_for(agg, matched_index)
    status, found = lookup_request(request_id)
    if status == "found" and objects_match(found or {}, body):
        agg = mark_signer_done(agg, matched_index)
        if agg.owner.version == 1:
            agg = commit_sent(agg)
        elif both_complete(agg) or (
            not is_two_signer(agg) and str(agg.facts.get("send_s1")) == "sent"
        ):
            if not is_two_signer(agg) and str(agg.facts.get("send_s1")) != "sent":
                agg = mark_signer_done(agg, 1)
            if is_two_signer(agg):
                if str(agg.facts.get("send_s1")) == "sent" and str(agg.facts.get("send_s2")) == "sent":
                    agg = commit_sent(agg)
            else:
                agg = commit_sent(agg)
        return payload_fields(agg)
    return payload_fields(agg)


COMMANDS = {
    "create-envelope": cmd_create,
    "send": cmd_send,
    "sign": cmd_sign,
    "decline": cmd_decline,
    "archive": cmd_archive,
    "reconcile": cmd_reconcile,
    "status": cmd_status,
    "callback": cmd_callback,
    "extend-deadline": cmd_extend,
}


def main(argv) -> int:
    if len(argv) < 1:
        print(json.dumps({"error": "bad_args"}))
        return 2
    name = argv[0]
    handler = COMMANDS.get(name)
    if handler is None:
        print(json.dumps({"error": "bad_args"}))
        return 2
    try:
        result = handler(argv[1:])
        print(json.dumps(result, separators=(",", ":")))
        return 0
    except AppError as err:
        print(json.dumps({"error": err.code}, separators=(",", ":")))
        return 2
    except KernelError:
        print(json.dumps({"error": "service_unavailable"}, separators=(",", ":")))
        return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
