# Process-level tests for the e-signature desk.
from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import tempfile
import time
import unittest
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NODE = "<home>/.nvm/versions/node/v22.17.1/bin/node"
RUN = os.path.join(ROOT, "run")


def start_stub():
    proc = subprocess.Popen(
        [NODE, os.path.join(ROOT, "stub", "server.mjs")],
        cwd=os.path.join(ROOT, "stub"),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    line = proc.stdout.readline()
    info = json.loads(line)
    return proc, info["service_url"]


def run_cmd(state_dir, service_url, args, crash_at=None, check=False):
    env = os.environ.copy()
    env["STATE_DIR"] = state_dir
    env["SERVICE_URL"] = service_url
    env["IK_BINARY"] = os.path.join(ROOT, "KIT", "bin", "ik")
    if crash_at:
        env["CRASH_AT"] = crash_at
    else:
        env.pop("CRASH_AT", None)
    completed = subprocess.run(
        [RUN] + args,
        env=env,
        capture_output=True,
        text=True,
    )
    if check and completed.returncode != 0:
        raise AssertionError(completed.stdout + completed.stderr)
    body = completed.stdout.strip().splitlines()[-1] if completed.stdout.strip() else "{}"
    return completed.returncode, json.loads(body)


class DeskTests(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp(prefix="desk-")
        self.stub, self.url = start_stub()
        self.state = os.path.join(self.tmpdir, "state")
        os.makedirs(self.state, exist_ok=True)

    def tearDown(self):
        self.stub.terminate()
        try:
            self.stub.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.stub.kill()
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def cmd(self, args, crash_at=None):
        return run_cmd(self.state, self.url, args, crash_at=crash_at)

    def test_create_status_restart(self):
        code, body = self.cmd(
            ["create-envelope", "env1", "doc1", "sig1", "a@b.c", "100", "10"]
        )
        self.assertEqual(code, 0)
        self.assertEqual(body["state"], "draft")
        self.assertEqual(body["send"], "none")
        self.assertEqual(body["document_id"], "doc1")
        code, st = self.cmd(["status", "env1"])
        self.assertEqual(code, 0)
        self.assertEqual(st["signer_id"], "sig1")
        self.assertEqual(st["address"], "a@b.c")
        self.assertEqual(st["deadline_ms"], 100)
        self.assertEqual(st["now_ms"], 10)
        code, again = run_cmd(self.state, self.url, ["status", "env1"])
        self.assertEqual(code, 0)
        self.assertEqual(again["envelope_id"], "env1")

    def test_id_in_use(self):
        self.cmd(["create-envelope", "env1", "doc1", "sig1", "a@b.c", "100", "10"])
        code, body = self.cmd(
            ["create-envelope", "env1", "doc2", "sig1", "a@b.c", "100", "10"]
        )
        self.assertNotEqual(code, 0)
        self.assertEqual(body["error"], "id_in_use")
        code, body = self.cmd(
            ["create-envelope", "env2", "doc1", "sig1", "a@b.c", "100", "10"]
        )
        self.assertNotEqual(code, 0)
        self.assertEqual(body["error"], "id_in_use")

    def test_send_sign_archive(self):
        self.cmd(["create-envelope", "env1", "doc1", "sig1", "a@b.c", "100", "10"])
        code, body = self.cmd(["send", "env1"])
        self.assertEqual(code, 0, body)
        self.assertEqual(body["state"], "sent")
        self.assertEqual(body["send"], "sent")
        code, body = self.cmd(["send", "env1"])
        self.assertEqual(code, 0)
        self.assertEqual(body["state"], "sent")
        code, body = self.cmd(["sign", "env1", "100"])
        self.assertEqual(code, 0)
        self.assertEqual(body["state"], "signed")
        code, body = self.cmd(["sign", "env1", "100"])
        self.assertNotEqual(code, 0)
        self.assertEqual(body["error"], "invalid_state")
        code, body = self.cmd(["archive", "env1", "101"])
        self.assertEqual(code, 0)
        self.assertEqual(body["state"], "archived")
        code, body = self.cmd(["send", "env1"])
        self.assertNotEqual(code, 0)
        self.assertEqual(body["error"], "invalid_state")

    def test_deadline_and_not_sent(self):
        self.cmd(["create-envelope", "env1", "doc1", "sig1", "a@b.c", "100", "10"])
        code, body = self.cmd(["sign", "env1", "10"])
        self.assertEqual(body["error"], "not_sent")
        self.cmd(["send", "env1"])
        code, body = self.cmd(["sign", "env1", "101"])
        self.assertEqual(body["error"], "expired")
        code, body = self.cmd(["decline", "env1", "100"])
        self.assertEqual(code, 0)
        self.assertEqual(body["state"], "declined")

    def test_unrelated_writer(self):
        other = os.path.join(self.state, "other.bin")
        with open(other, "wb") as handle:
            handle.write(b"keep-me-\x00\xff")
        before = open(other, "rb").read()
        self.cmd(["create-envelope", "env1", "doc1", "sig1", "a@b.c", "100", "10"])
        self.cmd(["status", "nope"])
        after = open(other, "rb").read()
        self.assertEqual(before, after)

    def test_crash_before_request(self):
        self.cmd(["create-envelope", "env1", "doc1", "sig1", "a@b.c", "100", "10"])
        code, _body = self.cmd(["send", "env1"], crash_at="after-attempt-saved-before-request")
        self.assertNotEqual(code, 0)
        code, st = self.cmd(["status", "env1"])
        self.assertEqual(st["send"], "attempt_saved")
        req = urllib.request.Request(self.url + "/v1/requests/env1")
        try:
            urllib.request.urlopen(req, timeout=5)
            present = True
        except urllib.error.HTTPError as err:
            present = err.code != 404
        self.assertFalse(present)
        code, body = self.cmd(["send", "env1"])
        self.assertEqual(code, 0)
        self.assertEqual(body["send"], "sent")
        code, body = self.cmd(["send", "env1"], crash_at="after-attempt-saved-before-request")
        self.assertEqual(code, 0)

    def test_crash_after_accept(self):
        self.cmd(["create-envelope", "env1", "doc1", "sig1", "a@b.c", "100", "10"])
        code, _body = self.cmd(["send", "env1"], crash_at="after-accept-before-record")
        self.assertNotEqual(code, 0)
        code, st = self.cmd(["status", "env1"])
        self.assertEqual(st["send"], "attempt_saved")
        req = urllib.request.Request(self.url + "/v1/requests/env1")
        with urllib.request.urlopen(req, timeout=5) as resp:
            accepted = json.loads(resp.read().decode("utf-8"))
        self.assertEqual(accepted["outcome"], "accepted")
        code, body = self.cmd(["send", "env1"], crash_at="after-accept-before-record")
        self.assertEqual(code, 0)
        self.assertEqual(body["send"], "sent")

    def test_crash_after_record(self):
        self.cmd(["create-envelope", "env1", "doc1", "sig1", "a@b.c", "100", "10"])
        code, _body = self.cmd(["send", "env1"], crash_at="after-record-before-exit")
        self.assertNotEqual(code, 0)
        code, st = self.cmd(["status", "env1"])
        self.assertEqual(st["send"], "sent")
        code, body = self.cmd(["send", "env1"], crash_at="after-record-before-exit")
        self.assertEqual(code, 0)

    def test_lost_reply_reconcile(self):
        self.cmd(["create-envelope", "env1", "doc1", "sig1", "a@b.c", "100", "10"])
        self.cmd(["send", "env1"], crash_at="after-accept-before-record")
        code, body = self.cmd(["reconcile", "env1"])
        self.assertEqual(code, 0)
        self.assertEqual(body["send"], "sent")
        self.assertEqual(body["state"], "sent")

    def test_callback_late_and_unknown(self):
        self.cmd(["create-envelope", "env1", "doc1", "sig1", "a@b.c", "100", "10"])
        self.cmd(["send", "env1"])
        cb = os.path.join(self.tmpdir, "cb.json")
        payload = {
            "callback_id": "cb-env1",
            "request_id": "env1",
            "envelope_id": "env1",
            "document_id": "other",
            "signer_id": "x",
            "address": "z@z.z",
            "deadline_ms": 1,
            "kind": "signature_request",
            "outcome": "rejected",
        }
        with open(cb, "w", encoding="utf-8") as handle:
            json.dump(payload, handle)
        before = self.cmd(["status", "env1"])[1]
        code, after = self.cmd(["callback", cb])
        self.assertEqual(code, 0)
        self.assertEqual(after["document_id"], before["document_id"])
        self.assertEqual(after["state"], "sent")
        payload["request_id"] = "unknown-id"
        payload["envelope_id"] = "unknown-id"
        with open(cb, "w", encoding="utf-8") as handle:
            json.dump(payload, handle)
        code, body = self.cmd(["callback", cb])
        self.assertEqual(code, 0)

    def test_bad_args(self):
        code, body = self.cmd(["create-envelope", "bad id", "doc", "s", "a@b.c", "1", "1"])
        self.assertEqual(body["error"], "bad_args")
        code, body = self.cmd(["status", "missing"])
        self.assertEqual(body["error"], "unknown_envelope")

    def test_two_signer_send_sign_grace_and_extend(self):
        code, body = self.cmd(
            [
                "create-envelope",
                "env2",
                "doc2",
                "sigA",
                "a@b.c",
                "sigB",
                "b@c.d",
                "100",
                "10",
            ]
        )
        self.assertEqual(code, 0, body)
        self.assertEqual(body["signer2_id"], "sigB")
        self.assertEqual(body["address2"], "b@c.d")
        code, body = self.cmd(["send", "env2"])
        self.assertEqual(code, 0, body)
        self.assertEqual(body["state"], "sent")
        self.assertEqual(body["send"], "sent")
        self.assertEqual(body["request_id"], "env2.s1")
        self.assertEqual(body["request_id_s2"], "env2.s2")
        for rid in ("env2.s1", "env2.s2"):
            req = urllib.request.Request(self.url + "/v1/requests/" + rid)
            with urllib.request.urlopen(req, timeout=5) as resp:
                accepted = json.loads(resp.read().decode("utf-8"))
            self.assertEqual(accepted["outcome"], "accepted")
        code, body = self.cmd(["sign", "env2", "86400100"])
        self.assertEqual(code, 0, body)
        self.assertEqual(body["state"], "signed")

    def test_two_signer_duplicate_and_one_signer_deadline(self):
        code, body = self.cmd(
            [
                "create-envelope",
                "envd",
                "docd",
                "same",
                "a@b.c",
                "same",
                "b@c.d",
                "100",
                "10",
            ]
        )
        self.assertNotEqual(code, 0)
        self.assertEqual(body["error"], "bad_args")
        self.cmd(["create-envelope", "env1", "doc1", "sig1", "a@b.c", "100", "10"])
        self.cmd(["send", "env1"])
        code, body = self.cmd(["sign", "env1", "86400100"])
        self.assertEqual(body["error"], "expired")
        code, body = self.cmd(["extend-deadline", "env1", "200", "20"])
        self.assertEqual(code, 0, body)
        self.assertEqual(body["deadline_ms"], 200)
        code, body = self.cmd(["sign", "env1", "150"])
        self.assertEqual(code, 0, body)

    def test_two_signer_crash_then_reconcile(self):
        self.cmd(
            [
                "create-envelope",
                "envc",
                "docc",
                "s1a",
                "a@b.c",
                "s1b",
                "b@c.d",
                "100",
                "10",
            ]
        )
        code, _body = self.cmd(["send", "envc"], crash_at="after-accept-before-record")
        self.assertNotEqual(code, 0)
        code, st = self.cmd(["status", "envc"])
        self.assertEqual(st["send"], "attempt_saved")
        code, body = self.cmd(["reconcile", "envc"])
        self.assertEqual(code, 0, body)
        if body["send"] != "sent":
            code, body = self.cmd(["send", "envc"])
            self.assertEqual(code, 0, body)
        self.assertEqual(body["state"], "sent")
        self.assertEqual(body["send"], "sent")
        code2, st2 = self.cmd(["status", "envc"])
        self.assertEqual(st2["signer2_id"], "s1b")


if __name__ == "__main__":
    unittest.main()

