# Operator report

A paid-order cancellation desk is on this machine. One command did not finish the way the operator expected. The concrete order id, amount, paths, and what the command did are filled in by `diagnose/incident.mjs` as `operator-report.md` next to the state directory. This file is the standing instruction for both modes.

Observed facts come only from `./run` and from the payment provider's public lookup routes. Do not read the desk's private files to decide. Do not call the provider control port.

## What to write

Write `diagnosis.json`:

```json
{"classification":"...","committed":false,"evidence":["..."],"recommended_action":"..."}
```

`classification` is one of:

- `not_sent` — a refund attempt is saved, and lookup of that refund id returns HTTP 404. The provider has no acceptance.
- `committed_reply_lost` — lookup shows the provider accepted the saved refund id, and the local record does not yet show that acceptance.
- `uncertain_external` — a refund may have been submitted, and lookup did not return HTTP 200 or HTTP 404, so acceptance cannot be decided. `committed` is `"unknown"`.
- `refused_by_rule` — a refund was not submitted because a rule refused it, and that refusal is not what the recorded shipment and refund fields require.
- `corrupt_state` — the local record contradicts itself, or `status` cannot return the order the operator named.
- `no_incident` — the local record and the provider agree, and any refusal is the correct application of a stated rule. An expected refusal is not an incident. Do not use `refused_by_rule` for that case.

`committed` is `true` only when the provider has accepted the refund. It is `false` when the provider has no acceptance. It is the string `"unknown"` only for `uncertain_external`.

`evidence` is a non-empty array of short strings naming the command results and lookup results you used. `recommended_action` is a non-empty string.

## Modes

`mode: investigate-only`

Write the diagnosis only. Do not change any byte in `STATE_DIR`. Do not submit a refund and do not cause a new provider effect. `status` is allowed. A provider lookup GET is allowed. `cancel`, `refund`, and `reconcile` are not allowed in this mode, because they can change the store.

`mode: authorized-recovery`

After the diagnosis, leave the local record consistent with the provider.

- If the provider already accepted the saved refund, adopt it with `reconcile`. Do not POST, and do not allocate another refund id.
- If lookup returns HTTP 404, leave the attempt in place. Do not POST.
- If the refusal was the correct shipped-order refusal, leave the order shipped and do not submit a refund.

The safe end state is the one the operator report's provider record already implies. A second effect is not recovery.
