# `publish_approval_v3.ik.toml` usability/conformance report

## Scope and missing specialist backend

I ran the installed Ikaros tools only. I did not install, download, or search outside `project/` for a checker.

Command:

```sh
./node_modules/.bin/ikaros doctor --dir . --json
```

Relevant observed output:

```json
{
  "executed_adapters": false,
  "fetched": false,
  "checks_toml": {"path": ".ik/checks.toml", "exists": false},
  "adapters": [],
  "unavailable": []
}
```

The same output reported runtime `@ikaros/runtime` `0.5.0`, `ik` `0.5.0`, protocol `1.0`, and `"versions_match": true`. Thus no adapter manifest or external checker was configured for this project. No specialist `ik analysis describe/run/conformance` check could be run: there was no manifest to describe or execute. This is an unavailable/unconfigured backend, not a failed lifecycle check and not a pass.

## Native inspection

Commands:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik identity machines/publish_approval_v3.ik.toml
./node_modules/@ikaros/darwin-arm64/bin/ik laws machines/publish_approval_v3.ik.toml
./node_modules/@ikaros/darwin-arm64/bin/ik schema machines/publish_approval_v3.ik.toml
```

`identity` observed:

```text
{"machine_id":"publish_approval","spec_hash":"5c0c111ae815fde7394570ada00f091f5615d881f7ec61b1ed782bc206130850","version":3}
```

`laws` reported `"advisory":true`. Its invariant entry reported:

```text
"reason":"`ik check` has no verifier for this obligation kind; runtime enforcement is the only evidence","status":"not_examined"
```

The machine source declares `draft`, `approved`, `publishing`, and terminal `published`. The declared nonterminal transitions are `draft -> draft` (`edit`), `draft -> approved` (`approve`), `approved -> draft` (`revise` and `withdraw`), `approved -> publishing` (`authorize_publish`), and `publishing -> published` (`complete`). The source guard for `authorize_publish` requires the payload digest, approved digest, and current artifact digest to match; `complete` requires its published digest to match the approved digest.

## Native bounded check

Command:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik check machines/publish_approval_v3.ik.toml --corpus machines/publish_approval_v3.cases.json
```

Observed output included:

```text
VERDICT
  ACCEPT
ASSURANCE
  class bounded_checked
  exploration complete_within_corpus
  ACCEPT is corpus-relative, not a proof

RELEASE POLICY (strict; separate from developer ACCEPT)
  verdict release_pass
  obligation status: not_examined=11 satisfied=16
  corpus 89163d94f2243f62f94f0d9810e3d0bc363fb573dbbc076e5bf5fd6796051b6c (8 cases), exploration complete within the supplied corpus, nodes 6
  excluded: evidence is bounded and relative to the supplied finite corpus; it is not exhaustive proof
  excluded: runtime artifact digest is unavailable: this report is not bound to a specific binary
  excluded: external reducers, hosts, and effect executors are outside this check
  excluded: obligation kinds with no verifier in this lane stay not_examined, not satisfied: OBL-CAP-001, OBL-DETERMINISM-001, OBL-EFFECT-001, OBL-EFFECT-002, OBL-EFFECT-003, OBL-EFFECT-004, OBL-EVENT-001, OBL-INV-001, OBL-REFUSE-001, OBL-REPLAY-001, OBL-TERM-002
```

This native check did run and returned `ACCEPT`, but its own output limits that result to the supplied eight-case finite corpus. It did not prove the invariant, external effect execution, or the unverified termination obligation (`OBL-TERM-002`).

I also ran a native profile using a temporary profile (then removed it):

```toml
profile_version = 1
[limits]
max_nodes = 4096
max_depth = 16
[[goals]]
id = "published"
kind = "reach_terminal"
terminal = "published"
required = true
[[goals]]
id = "not-stuck"
kind = "no_stuck_states"
required = true
```

Command:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik check machines/publish_approval_v3.ik.toml --corpus machines/publish_approval_v3.cases.json --profile .x09-t5-checks.toml
```

Observed profile output:

```text
PROFILE
  profile_digest 12c908b2923c146647a22800004fce58529be8b2395b87a4a1dd744e298c540
  machine_spec_hash 5c0c111ae815fde7394570ada00f091f5615d881f7ec61b1ed782bc206130850
  corpus_digest 89163d94f2243f62f94f0d9810e3d0bc363fb573dbbc076e5bf5fd6796051b6c
  bounds max_nodes=4096 max_depth=16
  search_complete true
  goal published witness_found required=true
    witness: edit[a] approve[a] authorize_publish[approved-bytes] complete[authorized]
  goal not-stuck no_stuck_states_found required=true
    no stuck states found among executably reached states; a terminal state with no outgoing command is not stuck
```

The profile establishes those two goals only within the supplied corpus and completed bounded search. It does not establish a universal property over all artifact values, command schedules, or external systems.

## Runtime scenarios

I first attempted this command with the scenario path accidentally supplied as both positional arguments:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik scenario run .x09-t5-scenario.json .x09-t5-scenario.json --out .x09-t5-run
```

It exited `2` and reported:

```text
ik scenario: scenario machine path does not match the machine argument
```

I then corrected it and ran a scratch scenario containing `edit(aaaa)`, `approve(aaaa)`, `authorize_publish(aaaa)`, and `complete(aaaa)`:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik scenario run machines/publish_approval_v3.ik.toml .x09-t5-scenario.json --out .x09-t5-run
```

Observed output:

```text
all expectations met
```

The observed result had `all_expectations_met: true`; the steps committed through `draft`, `approved`, `publishing`, and `published`. At the final `published` state, the result still showed `effect.status: "pending"` and `published_digest: "aaaa"`. This is an observed runtime distinction: reaching the kernel's `published` state did not show an external executor outcome.

I also ran a scratch revision scenario:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik scenario run machines/publish_approval_v3.ik.toml .x09-t5-revision.json --out .x09-t5-revision-run
```

It also observed:

```text
all expectations met
```

The result recorded committed steps `edit-a`, `approve-a`, `revise-b`, `approve-b`, `authorize-b`, and `complete-b`. After `revise-b`, the state was `draft` with `approved_digest: "aaaa"` and `artifact_digest: "bbbb"`; after `complete-b`, the state was `published` with facts:

```json
{
  "approved_digest": "bbbb",
  "artifact_digest": "bbbb",
  "published_digest": "bbbb"
}
```

There was no `published_digest: "aaaa"`. This is a concrete observed path in which an entered/approved artifact `aaaa` is revised away and only `bbbb` is published by the lifecycle.

## Answers

### 1. Can the lifecycle reach a dead end?

**No dead end was found in the reachable states explored by the native profile.** The profile completed within the supplied corpus and reported `no_stuck_states_found`; it also found a witness to `published`.

**Limit:** this is not an unbounded proof. The native checker explored six nodes from eight corpus cases, and the check output explicitly says the evidence is bounded and corpus-relative. The unverified termination obligation remained `not_examined`; no external checker was available. The conclusion is therefore “no dead end observed/found in this finite native run,” not “all possible inputs and schedules are deadlock-free.”

### 2. Is every submitted artifact eventually published?

**No, not as a universal artifact-identity claim.** The revision scenario is a concrete counterexample: `aaaa` was edited and approved, then `revise-b` replaced the current artifact and the lifecycle published `bbbb`; the final facts contain only `bbbb`. The machine also declares `withdraw` from `approved` back to `draft`, so the definition permits leaving approval without reaching `published`.

If “published” means an external publishing system actually received the bytes, that claim is **not established either**. The successful runtime scenario ended in kernel state `published` while its effect remained `pending`; scenarios do not call an external executor. The native check itself excludes “external reducers, hosts, and effect executors.”

## Overall conclusion and limits

The installed native tooling supports a bounded, corpus-relative acceptance and found a terminal witness plus no stuck state among reached states. It does not supply the missing specialist/external checker, and eleven obligations—including the invariant and termination obligation—remained `not_examined`. The machine has a concrete revision path showing that an earlier submitted/approved digest need not be the one eventually published, and kernel `published` does not by itself evidence external publication. No production store or external effect was used.
