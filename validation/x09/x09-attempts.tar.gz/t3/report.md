# Publish-approval v3 stale-handle evidence

## Scope and conclusion

This is a fresh-scratch, installed-tooling reproduction of one lifecycle schedule for
`machines/publish_approval_v3.ik.toml`. The machine identity observed was
`machine_id=publish_approval`, `version=3`, `spec_hash=5c0c111ae815fde7394570ada00f091f5615d881f7ec61b1ed782bc206130850`.
The installed runtime was `invariant-kernel 0.5.0 protocol 1.0`.

The stale-handle attempt was an `edit(artifact_digest=artifact-a)` resubmission
with operation id `op-resend-original`, using the capability retained from the
first edit (generation 1). Before that resubmission, a separate edit committed
`artifact-b`, advancing the aggregate to generation 2. The resubmission was
refused with `IK_CAPABILITY_STALE`; its state-after remained `draft`, with
`artifact_digest=artifact-b`, generation 2. No change was committed by the
stale attempt.

The separate `other-edit` reply was deliberately dropped after that edit had
committed. Reconciliation by operation id returned `committed_exact`, proving
that the missing reply did not mean that the edit failed. The historical result
is not a current capability handle.

## Exact commands run and observed output

All commands below were run from the project directory.

### Installation and identity

Command:

```sh
node_modules/.bin/ikaros doctor --dir . --json && node_modules/@ikaros/darwin-arm64/bin/ik --version && node_modules/@ikaros/darwin-arm64/bin/ik identity machines/publish_approval_v3.ik.toml
```

Observed output (relevant lines quoted verbatim):

```text
"package_version": "0.5.0"
"ik_version_line": "invariant-kernel 0.5.0 protocol 1.0"
"versions_match": true
"checks_toml": {"path": ".ik/checks.toml", "exists": false}
"skill": {"path": ".agents/skills/ikaros", "installed": true, "complete": true, "missing": []}
invariant-kernel 0.5.0 protocol 1.0
{"machine_id":"publish_approval","spec_hash":"5c0c111ae815fde7394570ada00f091f5615d881f7ec61b1ed782bc206130850","version":3}
```

The doctor output also observed `executed_adapters: false`, `fetched: false`,
and no unavailable adapters. It found the assigned machine and the packaged
skill. No `.ik/checks.toml` exists in this project; no `ik check` was claimed
or run.

### Scenario run

The evidence input is
`out/input/stale-handle-lost-reply.json`. The installed scenario command was:

```sh
node_modules/@ikaros/darwin-arm64/bin/ik scenario run machines/publish_approval_v3.ik.toml out/input/stale-handle-lost-reply.json --out out/stale-handle-lost-reply
```

Observed output:

```text
all expectations met
```

The scenario bundle is `out/stale-handle-lost-reply/`. Its
`result.json` records `"all_expectations_met":true` and
`seams_fired:["reply_dropped","stale_handle_used","reopened"]`.

The authoritative result rows observed in
`out/stale-handle-lost-reply/result.json` were:

| Step | Observed response | State after |
|---|---|---|
| implicit `genesis` | `committed` | `draft`, generation 0, no facts |
| `original-edit` (`artifact-a`, `op-original-edit`) | `committed` | `draft`, generation 1, `artifact_digest=artifact-a` |
| `other-edit` (`artifact-b`, `op-other-edit`) | `committed` | `draft`, generation 2, `artifact_digest=artifact-b` |
| `lost-other-edit-reply` | `reply_dropped` | unchanged: `draft`, generation 2, `artifact_digest=artifact-b` |
| `resend-original-with-old-handle` (`artifact-a`, `op-resend-original`, old `cap-original-edit`) | `refused`, diagnostic `IK_CAPABILITY_STALE` | unchanged: `draft`, generation 2, `artifact_digest=artifact-b` |
| `stale-attempt-lookup` (`op-resend-original`) | `not_recorded` | unchanged: `draft`, generation 2, `artifact_digest=artifact-b` |
| `lost-reply-reconciliation` (`op-other-edit`) | `committed_exact` | unchanged: `draft`, generation 2, `artifact_digest=artifact-b` |
| `reopen-after-refusal` | `reopened` | unchanged: `draft`, generation 2, `artifact_digest=artifact-b` |

The trace independently recorded the distinction:

```text
{"attempted":"edit","code":"IK_CAPABILITY_STALE","fromState":"draft","generation":"2","kind":"refusal","message":"capability generation 1 is stale; current generation is 2"}
{"attempted":"lookup op-resend-original","generation":"2","kind":"read","message":"not_recorded","state":"draft"}
{"attempted":"lookup op-other-edit","firstSequence":"2","kind":"historical","lastSequence":"2","operationId":"op-other-edit"}
```

The dropped-reply proof in `result.json` was:

```text
{"name":"reply_dropped","proof":{"generation":2,"lookup":{"first_sequence":2,"generation":2,"last_sequence":2,"outcome":"committed_exact"},"named_step_committed":true,"of":"other-edit","operation_id":"op-other-edit"},"seam_fired":true}
```

The stale-handle proof was:

```text
{"name":"stale_handle_used","proof":{"diagnostic_code":"IK_CAPABILITY_STALE","generation":2},"seam_fired":true}
```

### Reproduction

Command:

```sh
node_modules/@ikaros/darwin-arm64/bin/ik scenario reproduce out/stale-handle-lost-reply --out out/stale-handle-lost-reply-reproduced
```

Observed output:

```text
reproduced
```

This created the second bundle at
`out/stale-handle-lost-reply-reproduced/`. Its scenario, machine, result,
and trace bytes match the first bundle; the scratch SQLite stores have
runtime-specific store identity bytes.

### Current read, journal verification, and replay

Command:

```sh
printf '%s\n' '{"protocol":{"major":1,"minor":0},"runtime_version":"0.5.0","request_id":"read-1","op":"show","aggregate_id":"paper-stale-reply-1"}' | node_modules/@ikaros/darwin-arm64/bin/ik --store out/stale-handle-lost-reply/scratch/store.sqlite --machine machines/publish_approval_v3.ik.toml show
```

Observed result fields:

```text
"generation":2
"sequence":2
"state":{"artifact_digest":"artifact-b","state":"draft"}
```

The same response contained a current capability at generation 2 and a last
receipt at sequence 2. This `show` is a current-state read; it is not, by
itself, attribution of a past request.

Command:

```sh
printf '%s\n' '{"protocol":{"major":1,"minor":0},"runtime_version":"0.5.0","request_id":"verify-1","op":"verify"}' | node_modules/@ikaros/darwin-arm64/bin/ik --store out/stale-handle-lost-reply/scratch/store.sqlite --machine machines/publish_approval_v3.ik.toml verify
```

Observed output:

```text
{"ok":true,"protocol":{"major":1,"minor":0},"request_id":"verify-1","result":{"aggregates":1,"journal_ok":true,"projection_ok":true,"store_id":"ik-store-a8707229-6862-428d-8585-f84e081f9eab","verified":true},"runtime_version":"0.5.0"}
```

Command:

```sh
printf '%s\n' '{"protocol":{"major":1,"minor":0},"runtime_version":"0.5.0","request_id":"replay-1","op":"replay"}' | node_modules/@ikaros/darwin-arm64/bin/ik --store out/stale-handle-lost-reply/scratch/store.sqlite --machine machines/publish_approval_v3.ik.toml replay
```

Observed output:

```text
{"ok":true,"protocol":{"major":1,"minor":0},"request_id":"replay-1","result":{"aggregates":[{"aggregate_id":"paper-stale-reply-1","generation":2,"rebuilt":false,"sequence":2,"state":{"artifact_digest":"artifact-b","state":"draft"}}],"store_id":"ik-store-a8707229-6862-428d-8585-f84e081f9eab"},"runtime_version":"0.5.0"}
```

`verify` and `replay` are journal audits. They corroborate the final
aggregate state but do not answer whether a particular operation committed;
that answer came from the scenario's operation lookups.

### Byte-hash checks

Commands:

```sh
shasum -a 256 -c SHA256SUMS
```

run once in each of `out/stale-handle-lost-reply/` and
`out/stale-handle-lost-reply-reproduced/`.

Observed output for each bundle:

```text
machine.ik.toml: OK
result.json: OK
scenario.json: OK
trace.json: OK
```

Recomputed SHA-256 values (the two bundle manifests contain the same four
listed hashes):

```text
7f832e17ebf0b2c6dcdd0512057ba27a5c034e98e0d0f304510e949d885a9aa3  machine.ik.toml
cff0fd79fbf0321944d0cf7b8fa09d2f671e402fd5e4843e51f87b73bc70d043  result.json
15843b213667b6193609c3e56c2f647c331433114b76875302b98c468d020386  scenario.json
a22c140b450318069ec26fd40775b3f258e33d775cb20dc420f373295a3ae73b  trace.json
```

Additional recomputed hashes (not listed in the bundle manifests):

```text
27a28e3c076a74da81deaf65e4125c9ff4ccbcc85a8439668f0059c17bf30d18  out/stale-handle-lost-reply/scratch/store.sqlite
d8b8db8b61afbf72abdf2695e15f44e38546ce1a8359bd0f334499a0691ff3ae  out/stale-handle-lost-reply-reproduced/scratch/store.sqlite
15843b213667b6193609c3e56c2f647c331433114b76875302b98c468d020386  out/input/stale-handle-lost-reply.json
```

## What was attempted, what committed, and why refusal is not a commit

1. The aggregate was created in `draft` at generation 0.
2. The client submitted the original edit to `artifact-a`; it committed at
generation 1 and returned the retained handle `cap-original-edit`.
3. Another edit submitted `artifact-b`; it committed at generation 2. This
made the retained generation-1 capability stale.
4. The client explicitly re-sent the original `artifact-a` edit under a new
operation id, using that old handle. The runtime observed current generation
2 versus capability generation 1 and returned `IK_CAPABILITY_STALE`.
5. The refusal had no destination state, no generation increment, and no
operation record for `op-resend-original`; the subsequent lookup observed
`not_recorded`. The direct refusal observation is the evidence that this
attempt was rejected. The `not_recorded` read alone is weaker: an absent row
can also mean the request never arrived or is still running, and is not by
itself proof of refusal or permission to retry.
6. The final committed state was therefore still `draft` with
`artifact_digest=artifact-b`, generation 2. The only lifecycle edits committed
were `artifact-a` and then `artifact-b`.

A refusal is an observed response to an attempted command and does not create
a new state. A commit is an observed mutation with a new generation and state
(or an operation history row for a committed mutation). A read, including
`show`, `lookup_operation`, `replay`, or `verify`, is not a mutation.

## Meaning of the lost reply

The `other-edit` command committed at sequence 2 and generation 2, but its
reply was discarded. The client therefore could not conclude from the missing
reply that nothing happened. It had to reconcile using the original operation
id `op-other-edit`; the observed `committed_exact` result established that the
operation committed. That historical result does not provide a current handle;
the current state is separately shown at generation 2.

If reconciliation had instead returned `not_recorded`, the only safe claim
would have been “no matching operation row was observed as of that read.” It
would not distinguish refusal, non-delivery, or an operation still in flight,
and would not authorize a retry with a refreshed handle or a new operation id.

## Evidence files created

- `report.md` (this report).
- `out/input/stale-handle-lost-reply.json` (scenario input).
- `out/stale-handle-lost-reply/{scenario.json,machine.ik.toml,result.json,trace.json,SHA256SUMS,scratch/store.sqlite}`.
- `out/stale-handle-lost-reply-reproduced/{scenario.json,machine.ik.toml,result.json,trace.json,SHA256SUMS,scratch/store.sqlite}`.

## Unsuccessful command probes (not lifecycle evidence)

These exploratory commands were also run and are recorded so the command
history is complete. Their failures were CLI-usage/protocol errors, not
lifecycle outcomes:

```sh
node_modules/@ikaros/darwin-arm64/bin/ik scenario run out/input/stale-handle-lost-reply.json --out out/stale-handle-lost-reply
```

Observed output:

```text
ik scenario: run requires <machine.ik.toml> <scenario.json> --out <dir>
```

The corrected command is the one documented in “Scenario run” above.

```sh
printf 'show\n' | node_modules/@ikaros/darwin-arm64/bin/ik --store out/stale-handle-lost-reply/scratch/store.sqlite --machine machines/publish_approval_v3.ik.toml show
```

Observed output:

```text
IK_PROTOCOL_INVALID: malformed request: expected value at line 1 column 1
```

```sh
printf '%s\n' '{"op":"show","aggregate_id":"paper-stale-reply-1"}' | node_modules/@ikaros/darwin-arm64/bin/ik --store out/stale-handle-lost-reply/scratch/store.sqlite --machine machines/publish_approval_v3.ik.toml show
```

Observed output:

```text
IK_PROTOCOL_INVALID: malformed request: missing field `protocol`
```

```sh
printf '%s\n' '{"protocol":{"major":1,"minor":0},"request_id":"read-1","op":"show","aggregate_id":"paper-stale-reply-1"}' | node_modules/@ikaros/darwin-arm64/bin/ik --store out/stale-handle-lost-reply/scratch/store.sqlite --machine machines/publish_approval_v3.ik.toml show
```

Observed output:

```text
IK_PROTOCOL_INVALID: malformed request: missing field `runtime_version`
```

The complete envelope, including `runtime_version`, is the successful command
documented above. A no-stdin replay probe likewise returned
`IK_PROTOCOL_INVALID: malformed request: EOF while parsing a value at line 1 column 0`.
An initial hash-check invocation from the project directory returned missing-file
errors because the manifest paths are bundle-relative; the two corrected
bundle-local checks are the successful checks documented above.

## Limits and unresolved contract risks

- This is one fresh scratch-store schedule on the installed Darwin arm64
runtime 0.5.0. It does not prove behavior for other versions, platforms,
stores, schedules, or concurrent timing.
- The scenario's dropped reply is a deterministic harness fault; no real
network transport or client process was killed, and no external publisher was
called. The evidence proves kernel lifecycle behavior only.
- The machine remains in `draft`; this run does not exercise approval,
publish authorization, effect execution, or completion.
- `verify` and `replay` reported success for this store, but neither is an
operation-outcome query. The operation conclusions above rely on the explicit
scenario steps and their lookups.
- No `.ik/checks.toml` was present, so no `ik check` claim is made. No provider,
adapter, formatter, linter, test suite, or model worker was run.
