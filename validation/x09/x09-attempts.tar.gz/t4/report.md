# Cold usability/conformance report

## Scope and identity

I analyzed `machines/publish_approval_v3.ik.toml` with the installed Ikaros package and the shipped TLC finite-graph adapter. I did not modify the machine or its case corpus. The machine identity command was:

```sh
node_modules/@ikaros/darwin-arm64/bin/ik identity machines/publish_approval_v3.ik.toml
```

Observed output:

```text
{"machine_id":"publish_approval","spec_hash":"5c0c111ae815fde7394570ada00f091f5615d881f7ec61b1ed782bc206130850","version":3}
```

The installed integration was checked with:

```sh
node_modules/.bin/ikaros doctor --dir .
```

Relevant observed output:

```text
runtime: @ikaros/runtime 0.5.0
ik: invariant-kernel 0.5.0 protocol 1.0
versions_match: true
adapters: none
```

`adapters: none` is the project doctor inventory; the TLC adapter was then registered for this run from the shipped file `KIT/adapters/tlc/ik_tlc_adapter.py` using a temporary manifest under `.x09-t4/`. The adapter executable SHA-256 was `30722ead57522a2fb6a70f9b4febbd0158832fd133ecb6970dc45d1b7f27f664`. The pinned TLC jar SHA-256 was `936a262061c914694dfd669a543be24573c45d5aa0ff20a8b96b23d01e050e88`.

## Finite graph and bounds

I exported the graph with:

```sh
node_modules/@ikaros/darwin-arm64/bin/ik graph export machines/publish_approval_v3.ik.toml --corpus machines/publish_approval_v3.cases.json --max-nodes 4096 --max-depth 16 --out .x09-t4/graph.json
```

I summarized the resulting `ik.graph.v1` document with:

```sh
jq '{schema,machine_id,spec_hash,bounds,complete,incomplete_reason,restrictions,node_count:(.nodes|length),edge_count:(.edges|length),frontier_count:(.frontier|length),labels:(.nodes|map(.label)|unique),committed_edges:(.edges|map(select(.outcome=="committed"))|length),terminal_nodes:(.nodes|map(select(.terminal==true)|.label))}' .x09-t4/graph.json
```

Observed output:

```json
{
  "schema": "ik.graph.v1",
  "machine_id": "publish_approval",
  "spec_hash": "5c0c111ae815fde7394570ada00f091f5615d881f7ec61b1ed782bc206130850",
  "bounds": {"max_depth":16,"max_nodes":4096},
  "complete": true,
  "incomplete_reason": null,
  "restrictions": [
    {"command":"approve","limit":"corpus_cases:a"},
    {"command":"authorize_publish","limit":"corpus_cases:approved-bytes,changed-bytes"},
    {"command":"complete","limit":"corpus_cases:authorized,substituted"},
    {"command":"edit","limit":"corpus_cases:a"},
    {"command":"revise","limit":"corpus_cases:b"}
  ],
  "node_count": 7,
  "edge_count": 48,
  "frontier_count": 0,
  "labels": ["approved","draft","published","publishing"],
  "committed_edges": 10,
  "terminal_nodes": ["published"]
}
```

The graph is complete for this exported, corpus-restricted finite graph: it has no frontier and reports `complete: true`. It is not coverage of every possible string argument; the command restrictions above are part of the declared scope.

## Preliminary integration attempts

The first host invocation used a scratch root outside the output directory:

```sh
IK_TLC_JAR=~/.ik-toolchain/tla2tools-1.7.4.jar node_modules/@ikaros/darwin-arm64/bin/ik analysis run .x09-t4/manifest.json --request .x09-t4/stuck-request.json --out .x09-t4/stuck-run --timeout-seconds 120
```

Its host report observed `rejection_reason: "scratch_not_permitted"` and `executed: false`; it was not used as evidence.

The next host invocation used the corrected scratch location before the staged toolchain file was placed beside the adapter:

```sh
IK_TLC_JAR=~/.ik-toolchain/tla2tools-1.7.4.jar node_modules/@ikaros/darwin-arm64/bin/ik analysis run .x09-t4/manifest.json --request .x09-t4/stuck-request.json --out .x09-t4/stuck-run2 --timeout-seconds 120
```

Its adapter result observed `execution_status: "tool_unavailable"`. A direct adapter invocation had the same result:

```sh
IK_TLC_JAR=~/.ik-toolchain/tla2tools-1.7.4.jar .x09-t4/adapter.py run --request .x09-t4/stuck-request.json --out .x09-t4/direct-stuck
```

After placing the pinned toolchain file beside the staged adapter, the final host run below probed TLC successfully and completed. The preliminary runs are retained as evidence-build artifacts but are not part of either conclusion.

## Question 1 — dead end

Question: can the lifecycle reach a non-terminal, non-frontier state from which no command has a committed transition?

The request was `property_class: finite_scope_stuck` with TLC control `question: stuck`. I ran:

```sh
IK_TLC_JAR=~/.ik-toolchain/tla2tools-1.7.4.jar node_modules/@ikaros/darwin-arm64/bin/ik analysis run .x09-t4/manifest.json --request .x09-t4/stuck-request.json --out .x09-t4/stuck-run3 --timeout-seconds 120
```

Observed host result (from `.x09-t4/stuck-run3/host-report.json`) included:

```json
{"result_accepted":true,"execution_status":"completed"}
```

Observed adapter property (from `.x09-t4/stuck-run3/adapter/result.json`):

```json
{
  "goal_id":"dead_end",
  "property_class":"finite_scope_stuck",
  "finding":"holds_in_scope",
  "evidence_class":"exhaustive_finite_model",
  "coverage":{"complete":true,"reason":"exhaustive TLC over the exported finite graph; model-level evidence only"},
  "reproduction":{"status":"not_attempted"}
}
```

The native TLC output reported:

```text
TLC2 Version 2.19 of 08 August 2024 (rev: 5a47802)
Model checking completed. No error has been found.
12 states generated, 7 distinct states found, 0 states left on queue.
The depth of the complete state graph search is 5.
```

The adapter's graph/TLC fidelity record also reported:

```json
{"match":true,"checked":true,"native_reachable":7,"tlc_distinct":7,"reason":"committed-edge reachable set matches TLC distinct states"}
```

**Result:** No dead end was found in the declared finite graph; the stuck property `holds_in_scope`.

**Evidence class:** `exhaustive_finite_model`.

**Bounds and coverage:** TLC exhaustively checked the 7-state committed-edge model generated from the graph export (`max_depth: 16`, `max_nodes: 4096`, graph `complete: true`, frontier count 0). The graph itself is restricted to the named corpus cases listed above.

**Runtime/model limit:** This is a model-level finding for the exported finite graph, not a runtime fact or proof for all executable inputs. The adapter reported `reproduction.status: not_attempted`; I did not replay a witness because none was found, and I did not run a runtime scenario as part of this question.

## Question 2 — eventual publication liveness

Question: is every submitted artifact eventually published?

I submitted this as `property_class: temporal` with TLC control `question: liveness` and ran:

```sh
IK_TLC_JAR=~/.ik-toolchain/tla2tools-1.7.4.jar node_modules/@ikaros/darwin-arm64/bin/ik analysis run .x09-t4/manifest.json --request .x09-t4/liveness-request.json --out .x09-t4/liveness-run-1 --timeout-seconds 120
```

Observed host result:

```json
{"result_accepted":true,"execution_status":"unsupported","findings":[]}
```

Observed adapter result (`.x09-t4/liveness-run-1/adapter/result.json`):

```json
{"execution_status":"unsupported","properties":[],"artifacts":[]}
```

**Result:** The installed TLC adapter declines to answer this liveness question. There is no liveness verdict, witness, or counterexample from this run.

**Evidence class, bounds, and coverage:** None were emitted for this question because execution was `unsupported`; the finite graph bounds above were not used to establish a temporal property. This is neither a runtime fact nor a model-level liveness finding.

**Tooling limit:** The shipped adapter supports `temporal` as a declared property class but explicitly reports the `temporal`/`liveness` question as unsupported. Therefore this run cannot establish that every artifact is eventually published, nor can it establish a liveness violation.

## Overall conclusion and limits

- **Dead end:** no dead end in the complete, corpus-restricted finite graph; `holds_in_scope` with `exhaustive_finite_model` evidence. This does not cover arbitrary input strings or prove the executable runtime.
- **Eventual publication:** unanswered; the installed backend returned `unsupported`. No liveness claim is justified.

No provider or model worker was called. No tests, formatters, linters, or project-wide builds were run.

## Implementation artifacts and unresolved risks

Created files are `report.md` and the following evidence-build files under `.x09-t4/`:

```text
.x09-t4/adapter.py
.x09-t4/direct-stuck/result.json
.x09-t4/graph.json
.x09-t4/liveness-request.json
.x09-t4/liveness-run-1/adapter/result.json
.x09-t4/liveness-run-1/host-report.json
.x09-t4/manifest.json
.x09-t4/stuck-request.json
.x09-t4/stuck-run/host-report.json
.x09-t4/stuck-run2/adapter/result.json
.x09-t4/stuck-run2/host-report.json
.x09-t4/stuck-run3/adapter/native/IkGraph.cfg
.x09-t4/stuck-run3/adapter/native/IkGraph.tla
.x09-t4/stuck-run3/adapter/native/conformance.json
.x09-t4/stuck-run3/adapter/native/provenance.json
.x09-t4/stuck-run3/adapter/native/stderr.log
.x09-t4/stuck-run3/adapter/native/stdout.log
.x09-t4/stuck-run3/adapter/result.json
.x09-t4/stuck-run3/host-report.json
.x09-t4/toolchain.json
```

SHA-256 values recomputed with:

```sh
shasum -a 256 $(find .x09-t4 -type f -print | sort)
```

Observed hashes:

```text
30722ead57522a2fb6a70f9b4febbd0158832fd133ecb6970dc45d1b7f27f664  .x09-t4/adapter.py
c797c20723f18f5d6ea8758143b744d767eb251c2b19be8511116fbb0c099302  .x09-t4/direct-stuck/result.json
c389e00e52b415d36b93ce5dc035c3833482ba4d18b55dc8fb29cf2274e3f678  .x09-t4/graph.json
5e6ef3c58c86043a0a993de0ed8906175eaa11306f8583f3a285b7db13b33de6  .x09-t4/liveness-request.json
adc0045dd02996fc4d1f5df9efd9ca5c1c63595b648ab8f95e31324ef5d31fe4  .x09-t4/liveness-run-1/adapter/result.json
65ef4e1148138d1974faf4d741bf4bf620a4501741be2bd7d87390cca4c3615b  .x09-t4/liveness-run-1/host-report.json
c219076d8c5e9aa752fbf6328b6b7e066481f1ab12f7f1b6b4bce92eedde0e67  .x09-t4/manifest.json
f2ea0a7715138d634f349c317ef8ad509c92f07e8e521af7e29917e8648aa041  .x09-t4/stuck-request.json
c67d8a3d0b4e1805610bd8c52b4b90f90d6eb584c927ce24856b71ea9795b1ad  .x09-t4/stuck-run/host-report.json
c797c20723f18f5d6ea8758143b744d767eb251c2b19be8511116fbb0c099302  .x09-t4/stuck-run2/adapter/result.json
48e2f59b741efcf97ccd236e1fb5d860403574111deb2421de05d84301c901c0  .x09-t4/stuck-run2/host-report.json
7f1b201aff42a6d76bd001a6c8957df2a6380e984fffcf475f951bd1e37f9308  .x09-t4/stuck-run3/adapter/native/IkGraph.cfg
d5c6e5b9e9ba2f250e0e66ab8b771831dc10c7af3bf4d22e5bdaea60a0791011  .x09-t4/stuck-run3/adapter/native/IkGraph.tla
2ed6026f28fced5315465b552c1b94082eaf0ccc30f4dc813e79496cb2126379  .x09-t4/stuck-run3/adapter/native/conformance.json
e4d9fbba86fbc0fbc2bc107b04faa22eec7e22673837b1cff28b571a5ada2461  .x09-t4/stuck-run3/adapter/native/provenance.json
e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855  .x09-t4/stuck-run3/adapter/native/stderr.log
b96e8002148d1790ac5a35852d4191435832e39057bc59908af48e8e4f2a0387  .x09-t4/stuck-run3/adapter/native/stdout.log
5fa456d3817fffa63fea46cba8b30e8c3f3a8db8d8bd568b92df76299945660c  .x09-t4/stuck-run3/adapter/result.json
a2877cacfc661794b4c8971c7d4acd4e31340ca0896b5313b6018c8bfedcd6a9  .x09-t4/stuck-run3/host-report.json
fa6a2eaec11cf6230ce084ba16a29f149821bbe6130fcc64c379e716ddc6e42c  .x09-t4/toolchain.json
```

Unresolved contract risks are exactly the declared limits: the dead-end result is only for the complete graph generated from the supplied named cases, is model-level rather than runtime evidence, and was not concretely replayed; the eventual-publication liveness goal remains unanswered because the installed adapter returned `unsupported`.
