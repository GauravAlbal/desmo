# Publish-approval archive conformance report

## Deliverables

Created under `machines/`:

- `machines/publish_approval_v4.ik.toml`
- `machines/publish_approval_v4.cases.json`
- `evidence.v4.json`
- `report.md` (this file)

The v3 machine, v3 corpus, and `evidence.v3.json` were not written by this task. SHA-256 hashes observed after the work are:

```text
7f832e17ebf0b2c6dcdd0512057ba27a5c034e98e0d0f304510e949d885a9aa3  machines/publish_approval_v3.ik.toml
5e3d3773584314f42a27779a9371848790982b07fb03f5836633e166cd91f19c  machines/publish_approval_v3.cases.json
f63d88c1fdc25dd4989f966945bd1d81b73ad1c8da070275c6ac3bcd27550293  evidence.v3.json
493e474130d06f017b7bd2993ee22b3ce3018df5d2393182f83d998cd402039b  machines/publish_approval_v4.ik.toml
3a4bbd38d1d76264c7e38ef3527a6467e2bf2bc69e395e6c8f2cc06b7ca52419  machines/publish_approval_v4.cases.json
8228856d7569614b7c71bb2fb8af40cff2d4573d8cb663ec2a061df3a09b743d  evidence.v4.json
```

The v4 machine keeps the existing commands and `pub_inv_001`, adds `archive` from `published` to a new terminal `archived` state, and adds an archived-state copy of the publication invariant. `published` is non-terminal in v4 so that the new archive transition is reachable; no edit/revise/withdraw/publish command is declared from `published` or `archived`. The v4 corpus adds one zero-argument `archive` case.

## Commands run and observations

All commands below were run from the project directory with the installed package binaries.

### Installed surface

Command:

```sh
./node_modules/.bin/ikaros doctor --dir . --json
```

Observed output included:

```json
{"runtime":{"package_name":"@ikaros/runtime","package_version":"0.5.0","ik_version_line":"invariant-kernel 0.5.0 protocol 1.0","ik_version":"0.5.0","protocol":"1.0","versions_match":true},"checks_toml":{"path":".ik/checks.toml","exists":false},"scenarios":{"path":"scenarios","exists":false,"files":[]},"skill":{"path":".agents/skills/ikaros","installed":true,"complete":true,"missing":[]}}
```

This establishes the installed runtime/binary version and that no project check profile or scenario directory was present. It does not prove lifecycle behavior.

### Identities and derived schema

Command:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik identity machines/publish_approval_v3.ik.toml
./node_modules/@ikaros/darwin-arm64/bin/ik identity machines/publish_approval_v4.ik.toml
```

Observed output:

```text
{"machine_id":"publish_approval","spec_hash":"5c0c111ae815fde7394570ada00f091f5615d881f7ec61b1ed782bc206130850","version":3}
{"machine_id":"publish_approval","spec_hash":"f796c99ddc46fd027ccaebe0ef5f05a3b580cd0c707f7953911dc0a10f9db84d","version":4}
```

The new definition has version 4 and a different spec hash.
Command:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik laws machines/publish_approval_v4.ik.toml
```

Observed relevant output listed `archive` alongside the existing commands and listed `archived_inv_001` and `pub_inv_001` as runtime-enforced laws; the advisory inventory marked both invariant obligations `not_examined` for `ik check`.


Command:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik schema machines/publish_approval_v4.ik.toml
```

Observed relevant output:

```json
{"commands":[{"from":["published"],"name":"archive","successors":["archived"]},...],"states":[{"name":"archived","terminal":true},{"name":"draft","initial":true,"terminal":false},{"name":"published","terminal":false},...]}
```

This is tooling-derived confirmation that `archive` has no arguments, is sourced only from `published`, and reaches terminal `archived`. The schema is metadata; it does not execute a command or prove post-archive refusal.

### Fresh check evidence

Command:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik check machines/publish_approval_v4.ik.toml --prior machines/publish_approval_v3.ik.toml --corpus machines/publish_approval_v4.cases.json --json > evidence.v4.json
```

Observed in `evidence.v4.json`:

```text
"judgment":{"reasons":[],"verdict":"accept"}
"release":{"...","verdict":"release_pass"}
"report":{"...","obligations":{"falsified":0,"incomplete":0,"satisfied":19,"total":31,"uncovered":12},"verdict":"ACCEPT"}
```

The same evidence records:

```text
command/archive/from/published/executable -> satisfied
outcome/archive/0/executable -> satisfied
state/archived/executable -> satisfied
terminal/archived/reachable -> satisfied
terminal/archived/mutation_refused -> not_examined
```

The candidate exploration was complete within the recorded bounds (`max_nodes=4096`, `max_depth=16`, `explored_nodes=7`, `corpus_cases=9`, `exploration_complete=true`). The release evidence still has 12 `not_examined` obligations, including invariant, refusal, effect, replay, and terminal-mutation-refusal obligations. Therefore this check demonstrates bounded reachability/executability, not a proof that every post-archive edit is refused.

### Evidence verification

Command:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik evidence verify evidence.v3.json --machine machines/publish_approval_v3.ik.toml --corpus machines/publish_approval_v3.cases.json --json
```

Observed output:

```json
{"axes":{"corpus":{"status":"current"},"machine":{"status":"current"},"profile":{"status":"not_recorded"},"runtime":{"status":"not_recorded"},"scenario":{"status":"not_recorded"}},"overall":"current","schema":"ik.evidence.verify.v1"}
```

Command:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik evidence verify evidence.v3.json --machine machines/publish_approval_v4.ik.toml --corpus machines/publish_approval_v4.cases.json --json
```

Observed output (the command exited 1):

```json
{"axes":{"corpus":{"status":"stale","field":"corpus_digest","mismatches":[{"current":"4a2b11e48aca3719a056804b0e06b68fe8a6519310cccca3b994b7a42199a506","recorded":"89163d94f2243f62f94f0d9810e3d0bc363fb573dbbc076e5bf5fd6796051b6c"}]},"machine":{"status":"stale","field":"spec_hash","mismatches":[{"current":"f796c99ddc46fd027ccaebe0ef5f05a3b580cd0c707f7953911dc0a10f9db84d","recorded":"5c0c111ae815fde7394570ada00f091f5615d881f7ec61b1ed782bc206130850"}]},"profile":{"status":"not_recorded"},"runtime":{"status":"not_recorded"},"scenario":{"status":"not_recorded"}},"note":"no rebind or migration occurs: evidence for a new definition can never satisfy a persisted old-identity claim, and a persisted old identity cannot satisfy a new definition","overall":"different_machine_version","schema":"ik.evidence.verify.v1"}
```

Therefore `evidence.v3.json` is not accepted as evidence for v4. It remains current for v3, but the changed machine identity and changed corpus identity make it `different_machine_version` for v4.

Command:

```sh
./node_modules/@ikaros/darwin-arm64/bin/ik evidence verify evidence.v4.json --machine machines/publish_approval_v4.ik.toml --corpus machines/publish_approval_v4.cases.json --json
```

Observed output:

```json
{"axes":{"corpus":{"status":"current"},"machine":{"status":"current"},"profile":{"status":"not_recorded"},"runtime":{"status":"not_recorded"},"scenario":{"status":"not_recorded"}},"overall":"current","schema":"ik.evidence.verify.v1"}
```

Thus the newly generated evidence is current for the v4 machine and v4 corpus. No runtime binary digest or profile digest was recorded, so those axes were not recorded rather than verified.

### Hashes

Command:

```sh
shasum -a 256 machines/publish_approval_v3.ik.toml machines/publish_approval_v3.cases.json evidence.v3.json machines/publish_approval_v4.ik.toml machines/publish_approval_v4.cases.json evidence.v4.json
```

Observed output is the six-line hash block in **Deliverables** above.

## Old aggregates and stores

The shipped change-evidence and machine-evolution guidance says that evidence is identity-bound, analysis does not upcast state, and old aggregates retain their original `(machine_id, version, spec_hash)`. New aggregates may use v4; there is no generic historical-state migrator. The `evidence verify` output above directly observed the corresponding no-rebind/no-migration statement for evidence.

No production or scratch store was created or opened in this run, so there is no live `show`, replay, or cross-version command observation to report. The store/aggregate conclusion is therefore the documented Ikaros contract, not a claim of a store execution in this task. The check/evidence run also did not execute a post-archive edit refusal: `terminal/archived/mutation_refused` is explicitly `not_examined`.

## Conclusion and limits

- **Concluded from tooling:** v4 has a reachable `published -> archived` command; fresh v4 evidence was generated and verifies `current`; v3 evidence verifies for v3 but is rejected for v4 as `different_machine_version` with stale machine and corpus axes.
- **Not concluded:** exhaustive lifecycle correctness, runtime effect-executor behavior, invariant evaluation, replay equivalence, or an observed refusal of edits after archive. The fresh check explicitly leaves those obligations `not_examined` or outside its bounded finite corpus, and no store or scenario run was performed.
